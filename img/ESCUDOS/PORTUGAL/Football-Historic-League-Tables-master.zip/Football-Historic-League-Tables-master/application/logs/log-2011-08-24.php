<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-24 00:20:15 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:15 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Router Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Output Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Input Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 00:20:15 --> Language Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Loader Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Controller Class Initialized
ERROR - 2011-08-24 00:20:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 00:20:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 00:20:15 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 00:20:15 --> Database Driver Class Initialized
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 00:20:15 --> Helper loaded: url_helper
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 00:20:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 00:20:15 --> Final output sent to browser
DEBUG - 2011-08-24 00:20:15 --> Total execution time: 0.3169
DEBUG - 2011-08-24 00:20:15 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:15 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Router Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Output Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Input Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 00:20:15 --> Language Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Loader Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Controller Class Initialized
DEBUG - 2011-08-24 00:20:15 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:16 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 00:20:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 00:20:16 --> Final output sent to browser
DEBUG - 2011-08-24 00:20:16 --> Total execution time: 1.0479
DEBUG - 2011-08-24 00:20:17 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:17 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:17 --> Router Class Initialized
ERROR - 2011-08-24 00:20:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 00:20:18 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:18 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Router Class Initialized
ERROR - 2011-08-24 00:20:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 00:20:18 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:18 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:18 --> Router Class Initialized
ERROR - 2011-08-24 00:20:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 00:20:47 --> Config Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:20:47 --> URI Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Router Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Output Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Input Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 00:20:47 --> Language Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Loader Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Controller Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Model Class Initialized
DEBUG - 2011-08-24 00:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 00:20:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 00:20:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 00:20:47 --> Helper loaded: url_helper
DEBUG - 2011-08-24 00:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 00:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 00:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 00:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 00:20:47 --> Final output sent to browser
DEBUG - 2011-08-24 00:20:47 --> Total execution time: 0.3314
DEBUG - 2011-08-24 00:37:54 --> Config Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 00:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 00:37:54 --> URI Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Router Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Output Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Input Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 00:37:54 --> Language Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Loader Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Controller Class Initialized
ERROR - 2011-08-24 00:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 00:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 00:37:54 --> Model Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Model Class Initialized
DEBUG - 2011-08-24 00:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 00:37:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 00:37:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 00:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 00:37:54 --> Final output sent to browser
DEBUG - 2011-08-24 00:37:54 --> Total execution time: 0.0359
DEBUG - 2011-08-24 02:05:53 --> Config Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:05:53 --> URI Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Router Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Output Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Input Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:05:53 --> Language Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Loader Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Controller Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Model Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Model Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Model Class Initialized
DEBUG - 2011-08-24 02:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:05:53 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Config Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:05:55 --> URI Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Router Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Output Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Input Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:05:55 --> Language Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Loader Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Controller Class Initialized
ERROR - 2011-08-24 02:05:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:05:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:05:55 --> Model Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Model Class Initialized
DEBUG - 2011-08-24 02:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:05:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 02:05:55 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:05:55 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:05:55 --> Final output sent to browser
DEBUG - 2011-08-24 02:05:55 --> Total execution time: 0.5264
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:05:55 --> Final output sent to browser
DEBUG - 2011-08-24 02:05:55 --> Total execution time: 2.5646
DEBUG - 2011-08-24 02:05:57 --> Config Class Initialized
DEBUG - 2011-08-24 02:05:57 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:05:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:05:57 --> URI Class Initialized
DEBUG - 2011-08-24 02:05:57 --> Router Class Initialized
ERROR - 2011-08-24 02:05:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:06:07 --> Config Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:06:07 --> URI Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Router Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Output Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Input Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:06:07 --> Language Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Loader Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Controller Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:06:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Config Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:06:07 --> URI Class Initialized
DEBUG - 2011-08-24 02:06:07 --> Router Class Initialized
ERROR - 2011-08-24 02:06:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:06:07 --> Final output sent to browser
DEBUG - 2011-08-24 02:06:07 --> Total execution time: 0.5710
DEBUG - 2011-08-24 02:06:08 --> Config Class Initialized
DEBUG - 2011-08-24 02:06:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:06:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:06:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:06:08 --> URI Class Initialized
DEBUG - 2011-08-24 02:06:08 --> Router Class Initialized
ERROR - 2011-08-24 02:06:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:06:19 --> Config Class Initialized
DEBUG - 2011-08-24 02:06:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:06:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:06:19 --> URI Class Initialized
DEBUG - 2011-08-24 02:06:19 --> Router Class Initialized
ERROR - 2011-08-24 02:06:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:07:05 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:05 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:05 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:06 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Controller Class Initialized
ERROR - 2011-08-24 02:07:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:07:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:06 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:07:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:07:06 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:06 --> Total execution time: 0.0864
DEBUG - 2011-08-24 02:07:07 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:07 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:07 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Controller Class Initialized
ERROR - 2011-08-24 02:07:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:07:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:07:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:07:07 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:07 --> Total execution time: 0.0961
DEBUG - 2011-08-24 02:07:07 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:07 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:07 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Controller Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:08 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:08 --> Total execution time: 0.6916
DEBUG - 2011-08-24 02:07:13 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:13 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:13 --> Router Class Initialized
ERROR - 2011-08-24 02:07:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:07:14 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:14 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:14 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Controller Class Initialized
ERROR - 2011-08-24 02:07:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:07:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:14 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:07:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:07:14 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:14 --> Total execution time: 0.0692
DEBUG - 2011-08-24 02:07:17 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:17 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:17 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Controller Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:17 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:18 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:18 --> Total execution time: 0.6390
DEBUG - 2011-08-24 02:07:21 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:21 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:21 --> Router Class Initialized
ERROR - 2011-08-24 02:07:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:07:29 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:29 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:29 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Controller Class Initialized
ERROR - 2011-08-24 02:07:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:29 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:07:29 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:29 --> Total execution time: 0.0374
DEBUG - 2011-08-24 02:07:33 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:33 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Router Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Output Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Input Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:07:33 --> Language Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Loader Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Controller Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Model Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:07:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:07:33 --> Final output sent to browser
DEBUG - 2011-08-24 02:07:33 --> Total execution time: 0.5887
DEBUG - 2011-08-24 02:07:42 --> Config Class Initialized
DEBUG - 2011-08-24 02:07:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:07:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:07:42 --> URI Class Initialized
DEBUG - 2011-08-24 02:07:42 --> Router Class Initialized
ERROR - 2011-08-24 02:07:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:08:00 --> Config Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:08:00 --> URI Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Router Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Output Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Input Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:08:00 --> Language Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Loader Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Controller Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:08:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:08:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 02:08:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:08:00 --> Final output sent to browser
DEBUG - 2011-08-24 02:08:00 --> Total execution time: 0.5805
DEBUG - 2011-08-24 02:08:06 --> Config Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:08:06 --> URI Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Router Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Output Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Input Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:08:06 --> Language Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Loader Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Controller Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Model Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:08:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:08:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 02:08:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:08:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:08:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:08:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:08:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:08:06 --> Final output sent to browser
DEBUG - 2011-08-24 02:08:06 --> Total execution time: 0.0543
DEBUG - 2011-08-24 02:08:06 --> Config Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:08:06 --> URI Class Initialized
DEBUG - 2011-08-24 02:08:06 --> Router Class Initialized
ERROR - 2011-08-24 02:08:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:27:14 --> Config Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:27:14 --> URI Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Router Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Output Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Input Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:27:14 --> Language Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Loader Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Controller Class Initialized
ERROR - 2011-08-24 02:27:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:27:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:27:14 --> Model Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Model Class Initialized
DEBUG - 2011-08-24 02:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:27:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:27:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:27:15 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:27:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:27:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:27:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:27:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:27:15 --> Final output sent to browser
DEBUG - 2011-08-24 02:27:15 --> Total execution time: 0.3575
DEBUG - 2011-08-24 02:32:31 --> Config Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:32:31 --> URI Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Router Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Output Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Input Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:32:31 --> Language Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Loader Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Controller Class Initialized
ERROR - 2011-08-24 02:32:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:32:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:32:31 --> Model Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Model Class Initialized
DEBUG - 2011-08-24 02:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:32:31 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:32:31 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:32:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:32:31 --> Final output sent to browser
DEBUG - 2011-08-24 02:32:31 --> Total execution time: 0.1004
DEBUG - 2011-08-24 02:32:34 --> Config Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:32:34 --> URI Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Router Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Output Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Input Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:32:34 --> Language Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Loader Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Controller Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Model Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Model Class Initialized
DEBUG - 2011-08-24 02:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:32:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:32:36 --> Final output sent to browser
DEBUG - 2011-08-24 02:32:36 --> Total execution time: 1.6316
DEBUG - 2011-08-24 02:32:39 --> Config Class Initialized
DEBUG - 2011-08-24 02:32:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:32:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:32:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:32:39 --> URI Class Initialized
DEBUG - 2011-08-24 02:32:39 --> Router Class Initialized
ERROR - 2011-08-24 02:32:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:37:33 --> Config Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:37:33 --> URI Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Router Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Output Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Input Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:37:33 --> Language Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Loader Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Controller Class Initialized
ERROR - 2011-08-24 02:37:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:37:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:37:33 --> Model Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Model Class Initialized
DEBUG - 2011-08-24 02:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:37:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:37:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:37:33 --> Final output sent to browser
DEBUG - 2011-08-24 02:37:33 --> Total execution time: 0.0305
DEBUG - 2011-08-24 02:37:35 --> Config Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:37:35 --> URI Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Router Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Output Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Input Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:37:35 --> Language Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Loader Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Controller Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Model Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Model Class Initialized
DEBUG - 2011-08-24 02:37:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:37:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:37:37 --> Final output sent to browser
DEBUG - 2011-08-24 02:37:37 --> Total execution time: 2.6247
DEBUG - 2011-08-24 02:37:39 --> Config Class Initialized
DEBUG - 2011-08-24 02:37:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:37:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:37:39 --> URI Class Initialized
DEBUG - 2011-08-24 02:37:39 --> Router Class Initialized
ERROR - 2011-08-24 02:37:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:38:05 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:05 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Router Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Output Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Input Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:38:05 --> Language Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Loader Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Controller Class Initialized
ERROR - 2011-08-24 02:38:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:38:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:38:05 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:38:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:38:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:38:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:38:05 --> Final output sent to browser
DEBUG - 2011-08-24 02:38:05 --> Total execution time: 0.0824
DEBUG - 2011-08-24 02:38:07 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:07 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Router Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Output Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Input Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:38:07 --> Language Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Loader Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Controller Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:38:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:38:08 --> Final output sent to browser
DEBUG - 2011-08-24 02:38:08 --> Total execution time: 1.7509
DEBUG - 2011-08-24 02:38:10 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:10 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:10 --> Router Class Initialized
ERROR - 2011-08-24 02:38:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 02:38:26 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:26 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Router Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Output Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Input Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:38:26 --> Language Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Loader Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Controller Class Initialized
ERROR - 2011-08-24 02:38:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 02:38:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:38:26 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:38:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 02:38:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 02:38:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 02:38:26 --> Final output sent to browser
DEBUG - 2011-08-24 02:38:26 --> Total execution time: 0.0284
DEBUG - 2011-08-24 02:38:28 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:28 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Router Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Output Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Input Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 02:38:28 --> Language Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Loader Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Controller Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Model Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 02:38:28 --> Database Driver Class Initialized
DEBUG - 2011-08-24 02:38:28 --> Final output sent to browser
DEBUG - 2011-08-24 02:38:28 --> Total execution time: 0.5526
DEBUG - 2011-08-24 02:38:31 --> Config Class Initialized
DEBUG - 2011-08-24 02:38:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 02:38:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 02:38:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 02:38:31 --> URI Class Initialized
DEBUG - 2011-08-24 02:38:31 --> Router Class Initialized
ERROR - 2011-08-24 02:38:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:03 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:03 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Router Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Output Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Input Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 03:02:03 --> Language Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Loader Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Controller Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 03:02:03 --> Database Driver Class Initialized
DEBUG - 2011-08-24 03:02:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 03:02:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 03:02:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 03:02:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 03:02:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 03:02:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 03:02:04 --> Final output sent to browser
DEBUG - 2011-08-24 03:02:04 --> Total execution time: 1.6501
DEBUG - 2011-08-24 03:02:06 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:06 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:06 --> Router Class Initialized
ERROR - 2011-08-24 03:02:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:20 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:20 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Router Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Output Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Input Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 03:02:20 --> Language Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Loader Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Controller Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 03:02:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 03:02:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 03:02:20 --> Helper loaded: url_helper
DEBUG - 2011-08-24 03:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 03:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 03:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 03:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 03:02:20 --> Final output sent to browser
DEBUG - 2011-08-24 03:02:20 --> Total execution time: 0.1914
DEBUG - 2011-08-24 03:02:22 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:22 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Router Class Initialized
ERROR - 2011-08-24 03:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:22 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:22 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:22 --> Router Class Initialized
ERROR - 2011-08-24 03:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:33 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:33 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Router Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Output Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Input Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 03:02:33 --> Language Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Loader Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Controller Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 03:02:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 03:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 03:02:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 03:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 03:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 03:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 03:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 03:02:34 --> Final output sent to browser
DEBUG - 2011-08-24 03:02:34 --> Total execution time: 0.2339
DEBUG - 2011-08-24 03:02:35 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:35 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Router Class Initialized
ERROR - 2011-08-24 03:02:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:35 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:35 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:35 --> Router Class Initialized
ERROR - 2011-08-24 03:02:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 03:02:38 --> Config Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:02:38 --> URI Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Router Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Output Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Input Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 03:02:38 --> Language Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Loader Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Controller Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Model Class Initialized
DEBUG - 2011-08-24 03:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 03:02:38 --> Database Driver Class Initialized
DEBUG - 2011-08-24 03:02:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 03:02:38 --> Helper loaded: url_helper
DEBUG - 2011-08-24 03:02:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 03:02:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 03:02:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 03:02:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 03:02:38 --> Final output sent to browser
DEBUG - 2011-08-24 03:02:38 --> Total execution time: 0.1433
DEBUG - 2011-08-24 03:44:11 --> Config Class Initialized
DEBUG - 2011-08-24 03:44:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 03:44:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 03:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 03:44:11 --> URI Class Initialized
DEBUG - 2011-08-24 03:44:11 --> Router Class Initialized
ERROR - 2011-08-24 03:44:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 04:52:10 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:10 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:10 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Controller Class Initialized
ERROR - 2011-08-24 04:52:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 04:52:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 04:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:10 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:10 --> Helper loaded: url_helper
DEBUG - 2011-08-24 04:52:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 04:52:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 04:52:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 04:52:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 04:52:11 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:11 --> Total execution time: 0.9072
DEBUG - 2011-08-24 04:52:12 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:12 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:12 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Controller Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:12 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:12 --> Total execution time: 0.7726
DEBUG - 2011-08-24 04:52:18 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:18 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:18 --> Router Class Initialized
ERROR - 2011-08-24 04:52:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 04:52:19 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:19 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:19 --> Router Class Initialized
ERROR - 2011-08-24 04:52:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 04:52:30 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:30 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:30 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Controller Class Initialized
ERROR - 2011-08-24 04:52:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 04:52:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 04:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 04:52:30 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:30 --> Total execution time: 0.0295
DEBUG - 2011-08-24 04:52:30 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:30 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:30 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Controller Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:31 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:31 --> Total execution time: 0.5643
DEBUG - 2011-08-24 04:52:32 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:32 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:32 --> Router Class Initialized
ERROR - 2011-08-24 04:52:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 04:52:38 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:38 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:38 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Controller Class Initialized
ERROR - 2011-08-24 04:52:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 04:52:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:38 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:38 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 04:52:38 --> Helper loaded: url_helper
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 04:52:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 04:52:38 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:38 --> Total execution time: 0.0273
DEBUG - 2011-08-24 04:52:39 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:39 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Router Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Output Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Input Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 04:52:39 --> Language Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Loader Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Controller Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Model Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 04:52:39 --> Database Driver Class Initialized
DEBUG - 2011-08-24 04:52:39 --> Final output sent to browser
DEBUG - 2011-08-24 04:52:39 --> Total execution time: 0.8322
DEBUG - 2011-08-24 04:52:41 --> Config Class Initialized
DEBUG - 2011-08-24 04:52:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 04:52:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 04:52:41 --> URI Class Initialized
DEBUG - 2011-08-24 04:52:41 --> Router Class Initialized
ERROR - 2011-08-24 04:52:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 05:25:05 --> Config Class Initialized
DEBUG - 2011-08-24 05:25:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 05:25:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 05:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 05:25:05 --> URI Class Initialized
DEBUG - 2011-08-24 05:25:05 --> Router Class Initialized
DEBUG - 2011-08-24 05:25:05 --> No URI present. Default controller set.
DEBUG - 2011-08-24 05:25:06 --> Output Class Initialized
DEBUG - 2011-08-24 05:25:06 --> Input Class Initialized
DEBUG - 2011-08-24 05:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 05:25:06 --> Language Class Initialized
DEBUG - 2011-08-24 05:25:06 --> Loader Class Initialized
DEBUG - 2011-08-24 05:25:06 --> Controller Class Initialized
DEBUG - 2011-08-24 05:25:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 05:25:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 05:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 05:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 05:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 05:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 05:25:07 --> Final output sent to browser
DEBUG - 2011-08-24 05:25:07 --> Total execution time: 1.4679
DEBUG - 2011-08-24 06:04:16 --> Config Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:04:16 --> URI Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Router Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Output Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Input Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:04:16 --> Language Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Loader Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Controller Class Initialized
ERROR - 2011-08-24 06:04:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 06:04:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 06:04:16 --> Model Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Model Class Initialized
DEBUG - 2011-08-24 06:04:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:04:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 06:04:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:04:16 --> Final output sent to browser
DEBUG - 2011-08-24 06:04:16 --> Total execution time: 0.2891
DEBUG - 2011-08-24 06:04:19 --> Config Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:04:19 --> URI Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Router Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Output Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Input Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:04:19 --> Language Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Loader Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Controller Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Model Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Model Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:04:19 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:04:19 --> Final output sent to browser
DEBUG - 2011-08-24 06:04:19 --> Total execution time: 0.6055
DEBUG - 2011-08-24 06:04:21 --> Config Class Initialized
DEBUG - 2011-08-24 06:04:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:04:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:04:21 --> URI Class Initialized
DEBUG - 2011-08-24 06:04:21 --> Router Class Initialized
ERROR - 2011-08-24 06:04:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 06:56:18 --> Config Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:56:18 --> URI Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Router Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Output Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Input Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:56:18 --> Language Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Loader Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Controller Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:56:18 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:56:19 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:56:19 --> Final output sent to browser
DEBUG - 2011-08-24 06:56:19 --> Total execution time: 0.9573
DEBUG - 2011-08-24 06:56:48 --> Config Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:56:48 --> URI Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Router Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Output Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Input Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:56:48 --> Language Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Loader Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Controller Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:56:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:56:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:56:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:56:49 --> Final output sent to browser
DEBUG - 2011-08-24 06:56:49 --> Total execution time: 0.3179
DEBUG - 2011-08-24 06:56:51 --> Config Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:56:51 --> URI Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Router Class Initialized
ERROR - 2011-08-24 06:56:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 06:56:51 --> Config Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:56:51 --> URI Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Router Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Output Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Input Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:56:51 --> Language Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Loader Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Controller Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:56:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:56:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:56:51 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:56:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:56:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:56:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:56:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:56:51 --> Final output sent to browser
DEBUG - 2011-08-24 06:56:51 --> Total execution time: 0.0428
DEBUG - 2011-08-24 06:57:11 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:11 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:11 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:11 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:11 --> Total execution time: 0.2660
DEBUG - 2011-08-24 06:57:12 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:12 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:12 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:12 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:12 --> Total execution time: 0.0464
DEBUG - 2011-08-24 06:57:12 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:12 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:12 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:12 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:12 --> Total execution time: 0.0456
DEBUG - 2011-08-24 06:57:40 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:40 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:40 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:40 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:40 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:40 --> Total execution time: 0.2650
DEBUG - 2011-08-24 06:57:41 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:41 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:41 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:41 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:41 --> Total execution time: 0.0432
DEBUG - 2011-08-24 06:57:41 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:41 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:41 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:41 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:41 --> Total execution time: 0.0434
DEBUG - 2011-08-24 06:57:55 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:55 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:55 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:55 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:55 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:55 --> Total execution time: 0.4309
DEBUG - 2011-08-24 06:57:56 --> Config Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:57:56 --> URI Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Router Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Output Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Input Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:57:56 --> Language Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Loader Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Controller Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:57:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:57:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:57:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:57:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:57:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:57:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:57:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:57:56 --> Final output sent to browser
DEBUG - 2011-08-24 06:57:56 --> Total execution time: 0.0793
DEBUG - 2011-08-24 06:58:08 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:08 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:08 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:08 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:08 --> Total execution time: 0.3159
DEBUG - 2011-08-24 06:58:09 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:09 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:09 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:09 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:09 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:09 --> Total execution time: 0.0444
DEBUG - 2011-08-24 06:58:24 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:24 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:24 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:24 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:24 --> Total execution time: 0.2729
DEBUG - 2011-08-24 06:58:25 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:25 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:25 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:25 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:25 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:25 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:25 --> Total execution time: 0.0445
DEBUG - 2011-08-24 06:58:40 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:40 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:40 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:40 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:40 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:40 --> Total execution time: 0.0456
DEBUG - 2011-08-24 06:58:48 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:48 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:48 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:49 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:49 --> Total execution time: 1.0614
DEBUG - 2011-08-24 06:58:51 --> Config Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:58:51 --> URI Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Router Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Output Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Input Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:58:51 --> Language Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Loader Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Controller Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Model Class Initialized
DEBUG - 2011-08-24 06:58:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:58:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:58:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:58:51 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:58:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:58:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:58:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:58:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:58:51 --> Final output sent to browser
DEBUG - 2011-08-24 06:58:51 --> Total execution time: 0.0440
DEBUG - 2011-08-24 06:59:04 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:04 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:04 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:04 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:04 --> Total execution time: 0.6945
DEBUG - 2011-08-24 06:59:14 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:14 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:14 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:14 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:14 --> Total execution time: 0.2342
DEBUG - 2011-08-24 06:59:33 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:33 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:33 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:33 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:33 --> Total execution time: 0.0875
DEBUG - 2011-08-24 06:59:41 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:41 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:41 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:41 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:41 --> Total execution time: 0.2257
DEBUG - 2011-08-24 06:59:45 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:45 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:45 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:46 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:46 --> Total execution time: 0.3018
DEBUG - 2011-08-24 06:59:46 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:46 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:46 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:46 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:46 --> Total execution time: 0.1028
DEBUG - 2011-08-24 06:59:56 --> Config Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 06:59:56 --> URI Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Router Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Output Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Input Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 06:59:56 --> Language Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Loader Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Controller Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Model Class Initialized
DEBUG - 2011-08-24 06:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 06:59:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 06:59:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 06:59:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 06:59:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 06:59:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 06:59:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 06:59:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 06:59:56 --> Final output sent to browser
DEBUG - 2011-08-24 06:59:56 --> Total execution time: 0.0510
DEBUG - 2011-08-24 07:00:26 --> Config Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:00:26 --> URI Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Router Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Output Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Input Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:00:26 --> Language Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Loader Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Controller Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:00:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:00:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 07:00:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:00:27 --> Final output sent to browser
DEBUG - 2011-08-24 07:00:27 --> Total execution time: 0.3319
DEBUG - 2011-08-24 07:00:28 --> Config Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:00:28 --> URI Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Router Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Output Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Input Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:00:28 --> Language Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Loader Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Controller Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:00:28 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:00:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 07:00:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:00:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:00:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:00:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:00:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:00:28 --> Final output sent to browser
DEBUG - 2011-08-24 07:00:28 --> Total execution time: 0.1051
DEBUG - 2011-08-24 07:00:41 --> Config Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:00:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:00:41 --> URI Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Router Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Output Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Input Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:00:41 --> Language Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Loader Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Controller Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:00:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:00:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 07:00:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:00:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:00:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:00:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:00:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:00:42 --> Final output sent to browser
DEBUG - 2011-08-24 07:00:42 --> Total execution time: 1.1470
DEBUG - 2011-08-24 07:00:44 --> Config Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:00:44 --> URI Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Router Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Output Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Input Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:00:44 --> Language Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Loader Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Controller Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Model Class Initialized
DEBUG - 2011-08-24 07:00:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:00:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:00:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 07:00:44 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:00:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:00:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:00:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:00:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:00:44 --> Final output sent to browser
DEBUG - 2011-08-24 07:00:44 --> Total execution time: 0.0577
DEBUG - 2011-08-24 07:01:09 --> Config Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:01:09 --> URI Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Router Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Output Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Input Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:01:09 --> Language Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Loader Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Controller Class Initialized
ERROR - 2011-08-24 07:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 07:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:01:09 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:01:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:01:09 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:01:09 --> Final output sent to browser
DEBUG - 2011-08-24 07:01:09 --> Total execution time: 0.1311
DEBUG - 2011-08-24 07:01:10 --> Config Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:01:10 --> URI Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Router Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Output Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Input Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:01:10 --> Language Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Loader Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Controller Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:01:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:01:11 --> Final output sent to browser
DEBUG - 2011-08-24 07:01:11 --> Total execution time: 0.8722
DEBUG - 2011-08-24 07:01:32 --> Config Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:01:32 --> URI Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Router Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Output Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Input Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:01:32 --> Language Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Loader Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Controller Class Initialized
ERROR - 2011-08-24 07:01:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 07:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:01:32 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:01:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:01:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:01:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:01:32 --> Final output sent to browser
DEBUG - 2011-08-24 07:01:32 --> Total execution time: 0.0291
DEBUG - 2011-08-24 07:01:32 --> Config Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:01:32 --> URI Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Router Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Output Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Input Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:01:32 --> Language Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Loader Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Controller Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Model Class Initialized
DEBUG - 2011-08-24 07:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:01:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:01:33 --> Final output sent to browser
DEBUG - 2011-08-24 07:01:33 --> Total execution time: 0.5078
DEBUG - 2011-08-24 07:24:34 --> Config Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:24:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:24:34 --> URI Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Router Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Output Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Input Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:24:34 --> Language Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Loader Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Controller Class Initialized
ERROR - 2011-08-24 07:24:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 07:24:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:24:34 --> Model Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Model Class Initialized
DEBUG - 2011-08-24 07:24:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:24:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:24:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:24:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:24:34 --> Final output sent to browser
DEBUG - 2011-08-24 07:24:34 --> Total execution time: 0.3003
DEBUG - 2011-08-24 07:24:35 --> Config Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:24:35 --> URI Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Router Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Output Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Input Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:24:35 --> Language Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Loader Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Controller Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Model Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Model Class Initialized
DEBUG - 2011-08-24 07:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:24:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Final output sent to browser
DEBUG - 2011-08-24 07:24:37 --> Total execution time: 1.7383
DEBUG - 2011-08-24 07:24:37 --> Config Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:24:37 --> URI Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Router Class Initialized
ERROR - 2011-08-24 07:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 07:24:37 --> Config Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:24:37 --> URI Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Router Class Initialized
ERROR - 2011-08-24 07:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 07:24:37 --> Config Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:24:37 --> URI Class Initialized
DEBUG - 2011-08-24 07:24:37 --> Router Class Initialized
ERROR - 2011-08-24 07:24:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 07:25:17 --> Config Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:25:17 --> URI Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Router Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Output Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Input Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:25:17 --> Language Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Loader Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Controller Class Initialized
ERROR - 2011-08-24 07:25:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 07:25:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:25:17 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:25:17 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:25:17 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:25:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:25:17 --> Final output sent to browser
DEBUG - 2011-08-24 07:25:17 --> Total execution time: 0.0300
DEBUG - 2011-08-24 07:25:18 --> Config Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:25:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:25:18 --> URI Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Router Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Output Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Input Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:25:18 --> Language Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Loader Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Controller Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:25:18 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:25:19 --> Final output sent to browser
DEBUG - 2011-08-24 07:25:19 --> Total execution time: 1.1073
DEBUG - 2011-08-24 07:25:59 --> Config Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:25:59 --> URI Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Router Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Output Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Input Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:25:59 --> Language Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Loader Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Controller Class Initialized
ERROR - 2011-08-24 07:25:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 07:25:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:25:59 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Model Class Initialized
DEBUG - 2011-08-24 07:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:25:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 07:25:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:25:59 --> Final output sent to browser
DEBUG - 2011-08-24 07:25:59 --> Total execution time: 0.0286
DEBUG - 2011-08-24 07:26:00 --> Config Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:26:00 --> URI Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Router Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Output Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Input Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:26:00 --> Language Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Loader Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Controller Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Model Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Model Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:26:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:26:00 --> Final output sent to browser
DEBUG - 2011-08-24 07:26:00 --> Total execution time: 0.4535
DEBUG - 2011-08-24 07:27:00 --> Config Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 07:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 07:27:00 --> URI Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Router Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Output Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Input Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 07:27:00 --> Language Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Loader Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Controller Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Model Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Model Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Model Class Initialized
DEBUG - 2011-08-24 07:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 07:27:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 07:27:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 07:27:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 07:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 07:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 07:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 07:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 07:27:00 --> Final output sent to browser
DEBUG - 2011-08-24 07:27:00 --> Total execution time: 0.3067
DEBUG - 2011-08-24 08:00:33 --> Config Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 08:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 08:00:33 --> URI Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Router Class Initialized
DEBUG - 2011-08-24 08:00:33 --> No URI present. Default controller set.
DEBUG - 2011-08-24 08:00:33 --> Output Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Input Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 08:00:33 --> Language Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Loader Class Initialized
DEBUG - 2011-08-24 08:00:33 --> Controller Class Initialized
DEBUG - 2011-08-24 08:00:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 08:00:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 08:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 08:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 08:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 08:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 08:00:33 --> Final output sent to browser
DEBUG - 2011-08-24 08:00:33 --> Total execution time: 0.2535
DEBUG - 2011-08-24 08:32:57 --> Config Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Hooks Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 08:32:57 --> URI Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Router Class Initialized
DEBUG - 2011-08-24 08:32:57 --> No URI present. Default controller set.
DEBUG - 2011-08-24 08:32:57 --> Output Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Input Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 08:32:57 --> Language Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Loader Class Initialized
DEBUG - 2011-08-24 08:32:57 --> Controller Class Initialized
DEBUG - 2011-08-24 08:32:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 08:32:57 --> Helper loaded: url_helper
DEBUG - 2011-08-24 08:32:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 08:32:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 08:32:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 08:32:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 08:32:57 --> Final output sent to browser
DEBUG - 2011-08-24 08:32:57 --> Total execution time: 0.0767
DEBUG - 2011-08-24 08:49:24 --> Config Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 08:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 08:49:24 --> URI Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Router Class Initialized
DEBUG - 2011-08-24 08:49:24 --> No URI present. Default controller set.
DEBUG - 2011-08-24 08:49:24 --> Output Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Input Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 08:49:24 --> Language Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Loader Class Initialized
DEBUG - 2011-08-24 08:49:24 --> Controller Class Initialized
DEBUG - 2011-08-24 08:49:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 08:49:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 08:49:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 08:49:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 08:49:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 08:49:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 08:49:24 --> Final output sent to browser
DEBUG - 2011-08-24 08:49:24 --> Total execution time: 0.0570
DEBUG - 2011-08-24 08:55:09 --> Config Class Initialized
DEBUG - 2011-08-24 08:55:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 08:55:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 08:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 08:55:09 --> URI Class Initialized
DEBUG - 2011-08-24 08:55:09 --> Router Class Initialized
ERROR - 2011-08-24 08:55:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 09:28:37 --> Config Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:28:37 --> URI Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Router Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Output Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Input Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:28:37 --> Language Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Loader Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Controller Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 09:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:28:38 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:28:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 09:28:38 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:28:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:28:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:28:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:28:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:28:38 --> Final output sent to browser
DEBUG - 2011-08-24 09:28:38 --> Total execution time: 0.7342
DEBUG - 2011-08-24 09:28:55 --> Config Class Initialized
DEBUG - 2011-08-24 09:28:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:28:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:28:55 --> URI Class Initialized
DEBUG - 2011-08-24 09:28:55 --> Router Class Initialized
ERROR - 2011-08-24 09:28:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:29:11 --> Config Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:29:11 --> URI Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Router Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Output Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Input Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:29:11 --> Language Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Loader Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Controller Class Initialized
ERROR - 2011-08-24 09:29:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:29:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:29:11 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:29:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:29:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:29:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:29:11 --> Final output sent to browser
DEBUG - 2011-08-24 09:29:11 --> Total execution time: 0.0943
DEBUG - 2011-08-24 09:29:12 --> Config Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:29:12 --> URI Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Router Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Output Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Input Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:29:12 --> Language Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Loader Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Controller Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:29:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:29:14 --> Final output sent to browser
DEBUG - 2011-08-24 09:29:14 --> Total execution time: 1.8096
DEBUG - 2011-08-24 09:29:14 --> Config Class Initialized
DEBUG - 2011-08-24 09:29:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:29:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:29:14 --> URI Class Initialized
DEBUG - 2011-08-24 09:29:14 --> Router Class Initialized
ERROR - 2011-08-24 09:29:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:29:46 --> Config Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:29:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:29:46 --> URI Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Router Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Output Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Input Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:29:46 --> Language Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Loader Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Controller Class Initialized
ERROR - 2011-08-24 09:29:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:29:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:29:46 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:29:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:29:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:29:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:29:46 --> Final output sent to browser
DEBUG - 2011-08-24 09:29:46 --> Total execution time: 0.0758
DEBUG - 2011-08-24 09:29:47 --> Config Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:29:47 --> URI Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Router Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Output Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Input Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:29:47 --> Language Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Loader Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Controller Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Model Class Initialized
DEBUG - 2011-08-24 09:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:29:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:29:48 --> Final output sent to browser
DEBUG - 2011-08-24 09:29:48 --> Total execution time: 1.1073
DEBUG - 2011-08-24 09:30:32 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:32 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Router Class Initialized
ERROR - 2011-08-24 09:30:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:30:32 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:32 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Router Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Output Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Input Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:30:32 --> Language Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Loader Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Controller Class Initialized
ERROR - 2011-08-24 09:30:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:30:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:30:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:30:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:30:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:30:32 --> Final output sent to browser
DEBUG - 2011-08-24 09:30:32 --> Total execution time: 0.0293
DEBUG - 2011-08-24 09:30:33 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:33 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Router Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Output Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Input Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:30:33 --> Language Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Loader Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Controller Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:30:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:30:34 --> Final output sent to browser
DEBUG - 2011-08-24 09:30:34 --> Total execution time: 1.0083
DEBUG - 2011-08-24 09:30:42 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:42 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:42 --> Router Class Initialized
ERROR - 2011-08-24 09:30:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:30:46 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:46 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Router Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Output Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Input Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:30:46 --> Language Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Loader Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Controller Class Initialized
ERROR - 2011-08-24 09:30:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:30:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:30:46 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:30:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:30:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:30:46 --> Final output sent to browser
DEBUG - 2011-08-24 09:30:46 --> Total execution time: 0.0844
DEBUG - 2011-08-24 09:30:47 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:47 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Router Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Output Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Input Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:30:47 --> Language Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Loader Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Controller Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Model Class Initialized
DEBUG - 2011-08-24 09:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:30:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:30:48 --> Final output sent to browser
DEBUG - 2011-08-24 09:30:48 --> Total execution time: 1.2049
DEBUG - 2011-08-24 09:30:53 --> Config Class Initialized
DEBUG - 2011-08-24 09:30:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:30:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:30:53 --> URI Class Initialized
DEBUG - 2011-08-24 09:30:53 --> Router Class Initialized
ERROR - 2011-08-24 09:30:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:31:00 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:00 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:00 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Controller Class Initialized
ERROR - 2011-08-24 09:31:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:31:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:31:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:31:00 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:00 --> Total execution time: 0.0309
DEBUG - 2011-08-24 09:31:00 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:00 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:00 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Controller Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:02 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:02 --> Total execution time: 1.3244
DEBUG - 2011-08-24 09:31:04 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:04 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:04 --> Router Class Initialized
ERROR - 2011-08-24 09:31:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:31:32 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:32 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:32 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Controller Class Initialized
ERROR - 2011-08-24 09:31:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:31:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:31:32 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:32 --> Total execution time: 0.1129
DEBUG - 2011-08-24 09:31:33 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:33 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:33 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Controller Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:35 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:35 --> Total execution time: 1.5603
DEBUG - 2011-08-24 09:31:37 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:37 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:37 --> Router Class Initialized
ERROR - 2011-08-24 09:31:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:31:49 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:49 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:49 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Controller Class Initialized
ERROR - 2011-08-24 09:31:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:31:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:49 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:31:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:31:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:31:49 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:49 --> Total execution time: 0.0292
DEBUG - 2011-08-24 09:31:50 --> Config Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:31:50 --> URI Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Router Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Output Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Input Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:31:50 --> Language Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Loader Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Controller Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Model Class Initialized
DEBUG - 2011-08-24 09:31:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:31:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:31:51 --> Final output sent to browser
DEBUG - 2011-08-24 09:31:51 --> Total execution time: 0.8990
DEBUG - 2011-08-24 09:32:00 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:00 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Router Class Initialized
ERROR - 2011-08-24 09:32:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:32:00 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:00 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:00 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Controller Class Initialized
ERROR - 2011-08-24 09:32:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:32:00 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:00 --> Total execution time: 0.0285
DEBUG - 2011-08-24 09:32:01 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:01 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:01 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Controller Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:02 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:02 --> Total execution time: 1.2895
DEBUG - 2011-08-24 09:32:12 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:12 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:12 --> Router Class Initialized
ERROR - 2011-08-24 09:32:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:32:22 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:22 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:22 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Controller Class Initialized
ERROR - 2011-08-24 09:32:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:32:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:22 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:22 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:32:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:32:22 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:22 --> Total execution time: 0.0284
DEBUG - 2011-08-24 09:32:23 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:23 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:23 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Controller Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:24 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:24 --> Total execution time: 1.0036
DEBUG - 2011-08-24 09:32:31 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:31 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:31 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Controller Class Initialized
ERROR - 2011-08-24 09:32:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:32:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:31 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:31 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:31 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:32:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:32:31 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:31 --> Total execution time: 0.0356
DEBUG - 2011-08-24 09:32:31 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:31 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:31 --> Router Class Initialized
ERROR - 2011-08-24 09:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:32:32 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:32 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:32 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Controller Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:33 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:33 --> Total execution time: 1.4588
DEBUG - 2011-08-24 09:32:38 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:38 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:38 --> Router Class Initialized
ERROR - 2011-08-24 09:32:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:32:54 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:54 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:54 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Controller Class Initialized
ERROR - 2011-08-24 09:32:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:32:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:54 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:32:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:32:54 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:54 --> Total execution time: 0.0295
DEBUG - 2011-08-24 09:32:55 --> Config Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:32:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:32:55 --> URI Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Router Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Output Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Input Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:32:55 --> Language Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Loader Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Controller Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Model Class Initialized
DEBUG - 2011-08-24 09:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:32:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:32:56 --> Final output sent to browser
DEBUG - 2011-08-24 09:32:56 --> Total execution time: 0.7363
DEBUG - 2011-08-24 09:33:04 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:04 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:04 --> Router Class Initialized
ERROR - 2011-08-24 09:33:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:33:11 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:11 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Router Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Output Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Input Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:33:11 --> Language Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Loader Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Controller Class Initialized
ERROR - 2011-08-24 09:33:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:33:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:33:11 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:33:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:33:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:33:11 --> Final output sent to browser
DEBUG - 2011-08-24 09:33:11 --> Total execution time: 0.0341
DEBUG - 2011-08-24 09:33:12 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:12 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Router Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Output Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Input Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:33:12 --> Language Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Loader Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Controller Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:33:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:33:13 --> Final output sent to browser
DEBUG - 2011-08-24 09:33:13 --> Total execution time: 1.6970
DEBUG - 2011-08-24 09:33:18 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:18 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:18 --> Router Class Initialized
ERROR - 2011-08-24 09:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:33:36 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:36 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Router Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Output Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Input Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:33:36 --> Language Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Loader Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Controller Class Initialized
ERROR - 2011-08-24 09:33:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:33:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:33:36 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:33:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:33:36 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:33:36 --> Final output sent to browser
DEBUG - 2011-08-24 09:33:36 --> Total execution time: 0.0285
DEBUG - 2011-08-24 09:33:36 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:36 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Router Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Output Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Input Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:33:36 --> Language Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Loader Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Controller Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Model Class Initialized
DEBUG - 2011-08-24 09:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:33:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:33:37 --> Final output sent to browser
DEBUG - 2011-08-24 09:33:37 --> Total execution time: 0.6619
DEBUG - 2011-08-24 09:33:40 --> Config Class Initialized
DEBUG - 2011-08-24 09:33:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:33:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:33:40 --> URI Class Initialized
DEBUG - 2011-08-24 09:33:40 --> Router Class Initialized
ERROR - 2011-08-24 09:33:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:34:08 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:08 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:08 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Controller Class Initialized
ERROR - 2011-08-24 09:34:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:34:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:08 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:34:08 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:08 --> Total execution time: 0.0315
DEBUG - 2011-08-24 09:34:09 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:09 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:09 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Controller Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:10 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:10 --> Total execution time: 1.3039
DEBUG - 2011-08-24 09:34:12 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:12 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:12 --> Router Class Initialized
ERROR - 2011-08-24 09:34:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:34:21 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:21 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:21 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Controller Class Initialized
ERROR - 2011-08-24 09:34:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:34:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:21 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:34:21 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:21 --> Total execution time: 0.0288
DEBUG - 2011-08-24 09:34:21 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:21 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:21 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Controller Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:22 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:22 --> Total execution time: 0.7891
DEBUG - 2011-08-24 09:34:25 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:25 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:25 --> Router Class Initialized
ERROR - 2011-08-24 09:34:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 09:34:28 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:28 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:28 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Controller Class Initialized
ERROR - 2011-08-24 09:34:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 09:34:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:28 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:28 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 09:34:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 09:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 09:34:28 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:28 --> Total execution time: 0.0283
DEBUG - 2011-08-24 09:34:29 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:29 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Router Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Output Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Input Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 09:34:29 --> Language Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Loader Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Controller Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Model Class Initialized
DEBUG - 2011-08-24 09:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 09:34:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 09:34:30 --> Final output sent to browser
DEBUG - 2011-08-24 09:34:30 --> Total execution time: 0.7797
DEBUG - 2011-08-24 09:34:34 --> Config Class Initialized
DEBUG - 2011-08-24 09:34:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 09:34:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 09:34:34 --> URI Class Initialized
DEBUG - 2011-08-24 09:34:34 --> Router Class Initialized
ERROR - 2011-08-24 09:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 10:58:19 --> Config Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 10:58:19 --> URI Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Router Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Output Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Input Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 10:58:19 --> Language Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Loader Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Controller Class Initialized
ERROR - 2011-08-24 10:58:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 10:58:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 10:58:19 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 10:58:19 --> Database Driver Class Initialized
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 10:58:19 --> Helper loaded: url_helper
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 10:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 10:58:19 --> Final output sent to browser
DEBUG - 2011-08-24 10:58:19 --> Total execution time: 0.0567
DEBUG - 2011-08-24 10:58:21 --> Config Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 10:58:21 --> URI Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Router Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Output Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Input Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 10:58:21 --> Language Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Loader Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Controller Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 10:58:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 10:58:21 --> Final output sent to browser
DEBUG - 2011-08-24 10:58:21 --> Total execution time: 0.5583
DEBUG - 2011-08-24 10:58:44 --> Config Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 10:58:44 --> URI Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Router Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Output Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Input Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 10:58:44 --> Language Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Loader Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Controller Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Model Class Initialized
DEBUG - 2011-08-24 10:58:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 10:58:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 10:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 10:58:45 --> Helper loaded: url_helper
DEBUG - 2011-08-24 10:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 10:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 10:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 10:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 10:58:45 --> Final output sent to browser
DEBUG - 2011-08-24 10:58:45 --> Total execution time: 0.6424
DEBUG - 2011-08-24 11:09:42 --> Config Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 11:09:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 11:09:42 --> URI Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Router Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Output Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Input Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 11:09:42 --> Language Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Loader Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Controller Class Initialized
ERROR - 2011-08-24 11:09:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 11:09:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 11:09:42 --> Model Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Model Class Initialized
DEBUG - 2011-08-24 11:09:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 11:09:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 11:09:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 11:09:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 11:09:42 --> Final output sent to browser
DEBUG - 2011-08-24 11:09:42 --> Total execution time: 0.0319
DEBUG - 2011-08-24 11:44:43 --> Config Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 11:44:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 11:44:43 --> URI Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Router Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Output Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Input Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 11:44:43 --> Language Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Loader Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Controller Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Model Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Model Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Model Class Initialized
DEBUG - 2011-08-24 11:44:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 11:44:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 11:44:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 11:44:44 --> Helper loaded: url_helper
DEBUG - 2011-08-24 11:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 11:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 11:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 11:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 11:44:44 --> Final output sent to browser
DEBUG - 2011-08-24 11:44:44 --> Total execution time: 0.8989
DEBUG - 2011-08-24 12:36:57 --> Config Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Hooks Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 12:36:57 --> URI Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Router Class Initialized
DEBUG - 2011-08-24 12:36:57 --> No URI present. Default controller set.
DEBUG - 2011-08-24 12:36:57 --> Output Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Input Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 12:36:57 --> Language Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Loader Class Initialized
DEBUG - 2011-08-24 12:36:57 --> Controller Class Initialized
DEBUG - 2011-08-24 12:36:57 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 12:36:57 --> Helper loaded: url_helper
DEBUG - 2011-08-24 12:36:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 12:36:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 12:36:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 12:36:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 12:36:57 --> Final output sent to browser
DEBUG - 2011-08-24 12:36:57 --> Total execution time: 0.0870
DEBUG - 2011-08-24 12:47:28 --> Config Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 12:47:28 --> URI Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Router Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Output Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Input Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 12:47:28 --> Language Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Loader Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Controller Class Initialized
ERROR - 2011-08-24 12:47:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 12:47:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 12:47:28 --> Model Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Model Class Initialized
DEBUG - 2011-08-24 12:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 12:47:28 --> Database Driver Class Initialized
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 12:47:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 12:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 12:47:28 --> Final output sent to browser
DEBUG - 2011-08-24 12:47:28 --> Total execution time: 0.0909
DEBUG - 2011-08-24 12:47:29 --> Config Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 12:47:29 --> URI Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Router Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Output Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Input Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 12:47:29 --> Language Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Loader Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Controller Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Model Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Model Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 12:47:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 12:47:29 --> Final output sent to browser
DEBUG - 2011-08-24 12:47:29 --> Total execution time: 0.6429
DEBUG - 2011-08-24 12:47:31 --> Config Class Initialized
DEBUG - 2011-08-24 12:47:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 12:47:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 12:47:31 --> URI Class Initialized
DEBUG - 2011-08-24 12:47:31 --> Router Class Initialized
ERROR - 2011-08-24 12:47:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 13:33:34 --> Config Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:33:34 --> URI Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Router Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Output Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Input Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:33:34 --> Language Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Loader Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Controller Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:33:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:33:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:33:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:33:35 --> Final output sent to browser
DEBUG - 2011-08-24 13:33:35 --> Total execution time: 0.2422
DEBUG - 2011-08-24 13:34:02 --> Config Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:34:02 --> URI Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Router Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Output Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Input Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:34:02 --> Language Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Loader Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Controller Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:34:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:34:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:34:03 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:34:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:34:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:34:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:34:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:34:03 --> Final output sent to browser
DEBUG - 2011-08-24 13:34:03 --> Total execution time: 1.0971
DEBUG - 2011-08-24 13:34:05 --> Config Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:34:05 --> URI Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Router Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Output Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Input Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:34:05 --> Language Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Loader Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Controller Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:34:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:34:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:34:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:34:05 --> Final output sent to browser
DEBUG - 2011-08-24 13:34:05 --> Total execution time: 0.0580
DEBUG - 2011-08-24 13:34:26 --> Config Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:34:26 --> URI Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Router Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Output Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Input Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:34:26 --> Language Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Loader Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Controller Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Model Class Initialized
DEBUG - 2011-08-24 13:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:34:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:34:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:34:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:34:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:34:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:34:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:34:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:34:26 --> Final output sent to browser
DEBUG - 2011-08-24 13:34:26 --> Total execution time: 0.2936
DEBUG - 2011-08-24 13:35:07 --> Config Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:35:07 --> URI Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Router Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Output Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Input Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:35:07 --> Language Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Loader Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Controller Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:35:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:35:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:35:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:35:08 --> Final output sent to browser
DEBUG - 2011-08-24 13:35:08 --> Total execution time: 0.4529
DEBUG - 2011-08-24 13:35:18 --> Config Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:35:18 --> URI Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Router Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Output Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Input Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:35:18 --> Language Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Loader Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Controller Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:35:18 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:35:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:35:18 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:35:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:35:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:35:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:35:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:35:18 --> Final output sent to browser
DEBUG - 2011-08-24 13:35:18 --> Total execution time: 0.5509
DEBUG - 2011-08-24 13:35:37 --> Config Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:35:37 --> URI Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Router Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Output Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Input Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:35:37 --> Language Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Loader Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Controller Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:35:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:35:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:35:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:35:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:35:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:35:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:35:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:35:37 --> Final output sent to browser
DEBUG - 2011-08-24 13:35:37 --> Total execution time: 0.2724
DEBUG - 2011-08-24 13:35:49 --> Config Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:35:49 --> URI Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Router Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Output Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Input Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:35:49 --> Language Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Loader Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Controller Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:35:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:35:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:35:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:35:49 --> Final output sent to browser
DEBUG - 2011-08-24 13:35:49 --> Total execution time: 0.2297
DEBUG - 2011-08-24 13:36:02 --> Config Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:36:02 --> URI Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Router Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Output Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Input Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:36:02 --> Language Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Loader Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Controller Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:36:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:36:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:36:02 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:36:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:36:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:36:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:36:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:36:02 --> Final output sent to browser
DEBUG - 2011-08-24 13:36:02 --> Total execution time: 0.2935
DEBUG - 2011-08-24 13:36:22 --> Config Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:36:22 --> URI Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Router Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Output Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Input Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:36:22 --> Language Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Loader Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Controller Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:36:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:36:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:36:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:36:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:36:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:36:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:36:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:36:23 --> Final output sent to browser
DEBUG - 2011-08-24 13:36:23 --> Total execution time: 0.9587
DEBUG - 2011-08-24 13:36:32 --> Config Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:36:32 --> URI Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Router Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Output Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Input Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:36:32 --> Language Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Loader Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Controller Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:36:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:36:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:36:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:36:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:36:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:36:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:36:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:36:33 --> Final output sent to browser
DEBUG - 2011-08-24 13:36:33 --> Total execution time: 0.7178
DEBUG - 2011-08-24 13:36:42 --> Config Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:36:42 --> URI Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Router Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Output Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Input Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:36:42 --> Language Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Loader Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Controller Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:36:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:36:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:36:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:36:42 --> Final output sent to browser
DEBUG - 2011-08-24 13:36:42 --> Total execution time: 0.2611
DEBUG - 2011-08-24 13:36:54 --> Config Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:36:54 --> URI Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Router Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Output Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Input Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:36:54 --> Language Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Loader Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Controller Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Model Class Initialized
DEBUG - 2011-08-24 13:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:36:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:36:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:36:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:36:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:36:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:36:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:36:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:36:54 --> Final output sent to browser
DEBUG - 2011-08-24 13:36:54 --> Total execution time: 0.2137
DEBUG - 2011-08-24 13:37:06 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:06 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:06 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:07 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:07 --> Total execution time: 0.3027
DEBUG - 2011-08-24 13:37:08 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:08 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:08 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:08 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:08 --> Total execution time: 0.0728
DEBUG - 2011-08-24 13:37:08 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:08 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:08 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:08 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:08 --> Total execution time: 0.0731
DEBUG - 2011-08-24 13:37:16 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:16 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:16 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:16 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:16 --> Total execution time: 0.0724
DEBUG - 2011-08-24 13:37:27 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:27 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:27 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:27 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:27 --> Total execution time: 0.2839
DEBUG - 2011-08-24 13:37:38 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:38 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:38 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:38 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:39 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:39 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:39 --> Total execution time: 0.2531
DEBUG - 2011-08-24 13:37:47 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:47 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:47 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:48 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:48 --> Total execution time: 0.2447
DEBUG - 2011-08-24 13:37:49 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:49 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:49 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:49 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:49 --> Total execution time: 0.0451
DEBUG - 2011-08-24 13:37:57 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:57 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:57 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:57 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:57 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:57 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:57 --> Total execution time: 0.2652
DEBUG - 2011-08-24 13:37:59 --> Config Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:37:59 --> URI Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Router Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Output Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Input Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:37:59 --> Language Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Loader Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Controller Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Model Class Initialized
DEBUG - 2011-08-24 13:37:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:37:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:37:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:37:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:37:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:37:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:37:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:37:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:37:59 --> Final output sent to browser
DEBUG - 2011-08-24 13:37:59 --> Total execution time: 0.0464
DEBUG - 2011-08-24 13:38:13 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:13 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:13 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:14 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:14 --> Total execution time: 0.5511
DEBUG - 2011-08-24 13:38:16 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:16 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:16 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:16 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:16 --> Total execution time: 0.0440
DEBUG - 2011-08-24 13:38:24 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:24 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:24 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:25 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:25 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:25 --> Total execution time: 0.9340
DEBUG - 2011-08-24 13:38:27 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:27 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:27 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:27 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:27 --> Total execution time: 0.0453
DEBUG - 2011-08-24 13:38:34 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:34 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:34 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:35 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:35 --> Total execution time: 1.0773
DEBUG - 2011-08-24 13:38:42 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:42 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:42 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:43 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:43 --> Total execution time: 0.9978
DEBUG - 2011-08-24 13:38:45 --> Config Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:38:45 --> URI Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Router Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Output Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Input Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:38:45 --> Language Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Loader Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Controller Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Model Class Initialized
DEBUG - 2011-08-24 13:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:38:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:38:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 13:38:45 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:38:45 --> Final output sent to browser
DEBUG - 2011-08-24 13:38:45 --> Total execution time: 0.0443
DEBUG - 2011-08-24 13:55:53 --> Config Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:55:53 --> URI Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Router Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Output Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Input Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:55:53 --> Language Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Loader Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Controller Class Initialized
ERROR - 2011-08-24 13:55:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 13:55:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 13:55:53 --> Model Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Model Class Initialized
DEBUG - 2011-08-24 13:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:55:53 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 13:55:53 --> Helper loaded: url_helper
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 13:55:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 13:55:53 --> Final output sent to browser
DEBUG - 2011-08-24 13:55:53 --> Total execution time: 0.0399
DEBUG - 2011-08-24 13:55:54 --> Config Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:55:54 --> URI Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Router Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Output Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Input Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 13:55:54 --> Language Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Loader Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Controller Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Model Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Model Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 13:55:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 13:55:54 --> Final output sent to browser
DEBUG - 2011-08-24 13:55:54 --> Total execution time: 0.6368
DEBUG - 2011-08-24 13:55:57 --> Config Class Initialized
DEBUG - 2011-08-24 13:55:57 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:55:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:55:57 --> URI Class Initialized
DEBUG - 2011-08-24 13:55:57 --> Router Class Initialized
ERROR - 2011-08-24 13:55:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 13:55:58 --> Config Class Initialized
DEBUG - 2011-08-24 13:55:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 13:55:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 13:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 13:55:58 --> URI Class Initialized
DEBUG - 2011-08-24 13:55:58 --> Router Class Initialized
ERROR - 2011-08-24 13:55:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:02:23 --> Config Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:02:23 --> URI Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Router Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Output Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Input Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:02:23 --> Language Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Loader Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Controller Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Model Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Model Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Model Class Initialized
DEBUG - 2011-08-24 14:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:02:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:02:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:02:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:02:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:02:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:02:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:02:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:02:23 --> Final output sent to browser
DEBUG - 2011-08-24 14:02:23 --> Total execution time: 0.2007
DEBUG - 2011-08-24 14:02:26 --> Config Class Initialized
DEBUG - 2011-08-24 14:02:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:02:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:02:26 --> URI Class Initialized
DEBUG - 2011-08-24 14:02:26 --> Router Class Initialized
ERROR - 2011-08-24 14:02:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:05:30 --> Config Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:05:30 --> URI Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Router Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Output Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Input Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:05:30 --> Language Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Loader Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Controller Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:05:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:05:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:05:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:05:30 --> Final output sent to browser
DEBUG - 2011-08-24 14:05:30 --> Total execution time: 0.0447
DEBUG - 2011-08-24 14:05:33 --> Config Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:05:33 --> URI Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Router Class Initialized
ERROR - 2011-08-24 14:05:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:05:33 --> Config Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:05:33 --> URI Class Initialized
DEBUG - 2011-08-24 14:05:33 --> Router Class Initialized
ERROR - 2011-08-24 14:05:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:05:36 --> Config Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:05:36 --> URI Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Router Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Output Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Input Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:05:36 --> Language Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Loader Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Controller Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:05:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:05:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:05:36 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:05:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:05:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:05:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:05:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:05:36 --> Final output sent to browser
DEBUG - 2011-08-24 14:05:36 --> Total execution time: 0.2170
DEBUG - 2011-08-24 14:05:41 --> Config Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:05:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:05:41 --> URI Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Router Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Output Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Input Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:05:41 --> Language Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Loader Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Controller Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Model Class Initialized
DEBUG - 2011-08-24 14:05:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:05:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:05:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:05:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:05:41 --> Final output sent to browser
DEBUG - 2011-08-24 14:05:41 --> Total execution time: 0.1103
DEBUG - 2011-08-24 14:12:47 --> Config Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:12:47 --> URI Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Router Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Output Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Input Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:12:47 --> Language Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Loader Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Controller Class Initialized
ERROR - 2011-08-24 14:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:12:47 --> Model Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Model Class Initialized
DEBUG - 2011-08-24 14:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:12:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:12:47 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:12:47 --> Final output sent to browser
DEBUG - 2011-08-24 14:12:47 --> Total execution time: 0.0387
DEBUG - 2011-08-24 14:12:56 --> Config Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:12:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:12:56 --> URI Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Router Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Output Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Input Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:12:56 --> Language Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Loader Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Controller Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:12:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:12:56 --> Final output sent to browser
DEBUG - 2011-08-24 14:12:56 --> Total execution time: 0.5527
DEBUG - 2011-08-24 14:13:03 --> Config Class Initialized
DEBUG - 2011-08-24 14:13:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:13:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:13:03 --> URI Class Initialized
DEBUG - 2011-08-24 14:13:03 --> Router Class Initialized
ERROR - 2011-08-24 14:13:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:17:54 --> Config Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:17:54 --> URI Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Router Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Output Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Input Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:17:54 --> Language Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Loader Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Controller Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Model Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Model Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Model Class Initialized
DEBUG - 2011-08-24 14:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:17:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:17:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:17:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:17:54 --> Final output sent to browser
DEBUG - 2011-08-24 14:17:54 --> Total execution time: 0.0532
DEBUG - 2011-08-24 14:17:58 --> Config Class Initialized
DEBUG - 2011-08-24 14:17:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:17:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:17:58 --> URI Class Initialized
DEBUG - 2011-08-24 14:17:58 --> Router Class Initialized
ERROR - 2011-08-24 14:17:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:18:00 --> Config Class Initialized
DEBUG - 2011-08-24 14:18:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:18:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:18:00 --> URI Class Initialized
DEBUG - 2011-08-24 14:18:00 --> Router Class Initialized
ERROR - 2011-08-24 14:18:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:20:24 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:24 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:24 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Controller Class Initialized
ERROR - 2011-08-24 14:20:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:20:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:20:24 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:24 --> Total execution time: 0.0287
DEBUG - 2011-08-24 14:20:26 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:26 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:26 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Controller Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:27 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:27 --> Total execution time: 0.4476
DEBUG - 2011-08-24 14:20:28 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:28 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:28 --> Router Class Initialized
ERROR - 2011-08-24 14:20:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:20:42 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:42 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:42 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Controller Class Initialized
ERROR - 2011-08-24 14:20:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:20:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:42 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:20:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:20:42 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:42 --> Total execution time: 0.0327
DEBUG - 2011-08-24 14:20:43 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:43 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:43 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Controller Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:44 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:44 --> Total execution time: 0.7187
DEBUG - 2011-08-24 14:20:45 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:45 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:45 --> Router Class Initialized
ERROR - 2011-08-24 14:20:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:20:50 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:50 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:50 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Controller Class Initialized
ERROR - 2011-08-24 14:20:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:20:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:20:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:20:50 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:50 --> Total execution time: 0.0357
DEBUG - 2011-08-24 14:20:51 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:51 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Router Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Output Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Input Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:20:51 --> Language Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Loader Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Controller Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Model Class Initialized
DEBUG - 2011-08-24 14:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:20:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:20:52 --> Final output sent to browser
DEBUG - 2011-08-24 14:20:52 --> Total execution time: 0.5754
DEBUG - 2011-08-24 14:20:53 --> Config Class Initialized
DEBUG - 2011-08-24 14:20:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:20:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:20:53 --> URI Class Initialized
DEBUG - 2011-08-24 14:20:53 --> Router Class Initialized
ERROR - 2011-08-24 14:20:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:21:02 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:02 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Router Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Output Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Input Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:21:02 --> Language Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Loader Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Controller Class Initialized
ERROR - 2011-08-24 14:21:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:21:02 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:21:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:21:02 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:21:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:21:02 --> Final output sent to browser
DEBUG - 2011-08-24 14:21:02 --> Total execution time: 0.0288
DEBUG - 2011-08-24 14:21:03 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:03 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Router Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Output Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Input Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:21:03 --> Language Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Loader Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Controller Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:21:03 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:21:03 --> Final output sent to browser
DEBUG - 2011-08-24 14:21:03 --> Total execution time: 0.5117
DEBUG - 2011-08-24 14:21:05 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:05 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:05 --> Router Class Initialized
ERROR - 2011-08-24 14:21:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:21:36 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:36 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:36 --> Router Class Initialized
ERROR - 2011-08-24 14:21:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:21:43 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:43 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Router Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Output Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Input Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:21:43 --> Language Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Loader Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Controller Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:21:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:21:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:21:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:21:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:21:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:21:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:21:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:21:43 --> Final output sent to browser
DEBUG - 2011-08-24 14:21:43 --> Total execution time: 0.0509
DEBUG - 2011-08-24 14:21:59 --> Config Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:21:59 --> URI Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Router Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Output Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Input Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:21:59 --> Language Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Loader Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Controller Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Model Class Initialized
DEBUG - 2011-08-24 14:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:21:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:21:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:21:59 --> Final output sent to browser
DEBUG - 2011-08-24 14:21:59 --> Total execution time: 0.2484
DEBUG - 2011-08-24 14:22:02 --> Config Class Initialized
DEBUG - 2011-08-24 14:22:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:22:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:22:02 --> URI Class Initialized
DEBUG - 2011-08-24 14:22:02 --> Router Class Initialized
ERROR - 2011-08-24 14:22:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:24:19 --> Config Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:24:19 --> URI Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Router Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Output Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Input Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:24:19 --> Language Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Loader Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Controller Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Model Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Model Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Model Class Initialized
DEBUG - 2011-08-24 14:24:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:24:19 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:24:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:24:19 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:24:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:24:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:24:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:24:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:24:19 --> Final output sent to browser
DEBUG - 2011-08-24 14:24:19 --> Total execution time: 0.0559
DEBUG - 2011-08-24 14:24:27 --> Config Class Initialized
DEBUG - 2011-08-24 14:24:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:24:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:24:27 --> URI Class Initialized
DEBUG - 2011-08-24 14:24:27 --> Router Class Initialized
ERROR - 2011-08-24 14:24:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:25:12 --> Config Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:25:12 --> URI Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Router Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Output Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Input Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:25:12 --> Language Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Loader Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Controller Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:25:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:25:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:25:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:25:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:25:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:25:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:25:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:25:12 --> Final output sent to browser
DEBUG - 2011-08-24 14:25:12 --> Total execution time: 0.3656
DEBUG - 2011-08-24 14:25:20 --> Config Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:25:20 --> URI Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Router Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Output Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Input Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:25:20 --> Language Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Loader Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Controller Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:25:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:25:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:25:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:25:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:25:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:25:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:25:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:25:21 --> Final output sent to browser
DEBUG - 2011-08-24 14:25:21 --> Total execution time: 1.3530
DEBUG - 2011-08-24 14:25:24 --> Config Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:25:24 --> URI Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Router Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Output Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Input Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:25:24 --> Language Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Loader Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Controller Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:25:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:25:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:25:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:25:24 --> Final output sent to browser
DEBUG - 2011-08-24 14:25:24 --> Total execution time: 0.0644
DEBUG - 2011-08-24 14:28:37 --> Config Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:28:37 --> URI Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Router Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Output Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Input Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:28:37 --> Language Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Loader Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Controller Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:28:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:28:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:28:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:28:37 --> Final output sent to browser
DEBUG - 2011-08-24 14:28:37 --> Total execution time: 0.0484
DEBUG - 2011-08-24 14:28:39 --> Config Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:28:39 --> URI Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Router Class Initialized
ERROR - 2011-08-24 14:28:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:28:39 --> Config Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:28:39 --> URI Class Initialized
DEBUG - 2011-08-24 14:28:39 --> Router Class Initialized
ERROR - 2011-08-24 14:28:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:28:56 --> Config Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:28:56 --> URI Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Router Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Output Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Input Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:28:56 --> Language Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Loader Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Controller Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:28:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:28:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:28:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:28:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:28:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:28:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:28:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:28:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:28:56 --> Final output sent to browser
DEBUG - 2011-08-24 14:28:56 --> Total execution time: 0.0705
DEBUG - 2011-08-24 14:29:06 --> Config Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:29:06 --> URI Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Router Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Output Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Input Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:29:06 --> Language Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Loader Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Controller Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Model Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Model Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Model Class Initialized
DEBUG - 2011-08-24 14:29:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:29:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:29:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:29:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:29:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:29:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:29:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:29:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:29:06 --> Final output sent to browser
DEBUG - 2011-08-24 14:29:06 --> Total execution time: 0.3615
DEBUG - 2011-08-24 14:32:09 --> Config Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:32:09 --> URI Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Router Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Output Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Input Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:32:09 --> Language Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Loader Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Controller Class Initialized
ERROR - 2011-08-24 14:32:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:32:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:32:09 --> Model Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Model Class Initialized
DEBUG - 2011-08-24 14:32:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:32:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:32:09 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:32:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:32:09 --> Final output sent to browser
DEBUG - 2011-08-24 14:32:09 --> Total execution time: 0.0407
DEBUG - 2011-08-24 14:32:10 --> Config Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:32:10 --> URI Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Router Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Output Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Input Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:32:10 --> Language Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Loader Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Controller Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Model Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Model Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:32:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:32:10 --> Final output sent to browser
DEBUG - 2011-08-24 14:32:10 --> Total execution time: 0.6515
DEBUG - 2011-08-24 14:32:12 --> Config Class Initialized
DEBUG - 2011-08-24 14:32:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:32:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:32:12 --> URI Class Initialized
DEBUG - 2011-08-24 14:32:12 --> Router Class Initialized
ERROR - 2011-08-24 14:32:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:32:13 --> Config Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:32:13 --> URI Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Router Class Initialized
ERROR - 2011-08-24 14:32:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:32:13 --> Config Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:32:13 --> URI Class Initialized
DEBUG - 2011-08-24 14:32:13 --> Router Class Initialized
ERROR - 2011-08-24 14:32:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:36:07 --> Config Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:36:07 --> URI Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Router Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Output Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Input Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:36:07 --> Language Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Loader Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Controller Class Initialized
ERROR - 2011-08-24 14:36:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:36:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:36:07 --> Model Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Model Class Initialized
DEBUG - 2011-08-24 14:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:36:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:36:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:36:07 --> Final output sent to browser
DEBUG - 2011-08-24 14:36:07 --> Total execution time: 0.0295
DEBUG - 2011-08-24 14:36:08 --> Config Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:36:08 --> URI Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Router Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Output Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Input Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:36:08 --> Language Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Loader Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Controller Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Model Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Model Class Initialized
DEBUG - 2011-08-24 14:36:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:36:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:36:09 --> Final output sent to browser
DEBUG - 2011-08-24 14:36:09 --> Total execution time: 0.8815
DEBUG - 2011-08-24 14:36:10 --> Config Class Initialized
DEBUG - 2011-08-24 14:36:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:36:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:36:10 --> URI Class Initialized
DEBUG - 2011-08-24 14:36:10 --> Router Class Initialized
ERROR - 2011-08-24 14:36:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:37:14 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:14 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:14 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Controller Class Initialized
ERROR - 2011-08-24 14:37:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:37:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:37:14 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:37:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:37:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:37:14 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:14 --> Total execution time: 0.0951
DEBUG - 2011-08-24 14:37:16 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:16 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:16 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Controller Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:17 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:17 --> Total execution time: 0.8396
DEBUG - 2011-08-24 14:37:33 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:33 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:33 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Controller Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:37:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:37:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:37:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:37:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:37:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:37:33 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:33 --> Total execution time: 0.0556
DEBUG - 2011-08-24 14:37:36 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:36 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:36 --> Router Class Initialized
ERROR - 2011-08-24 14:37:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:37:43 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:43 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:43 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Controller Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:37:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:37:43 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:43 --> Total execution time: 0.0502
DEBUG - 2011-08-24 14:37:45 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:45 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:45 --> Router Class Initialized
ERROR - 2011-08-24 14:37:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:37:50 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:50 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:50 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Controller Class Initialized
ERROR - 2011-08-24 14:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:37:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:37:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:37:50 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:50 --> Total execution time: 0.0367
DEBUG - 2011-08-24 14:37:52 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:52 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Router Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Output Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Input Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:37:52 --> Language Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Loader Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Controller Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Model Class Initialized
DEBUG - 2011-08-24 14:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:37:52 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:37:53 --> Final output sent to browser
DEBUG - 2011-08-24 14:37:53 --> Total execution time: 1.0141
DEBUG - 2011-08-24 14:37:55 --> Config Class Initialized
DEBUG - 2011-08-24 14:37:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:37:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:37:55 --> URI Class Initialized
DEBUG - 2011-08-24 14:37:55 --> Router Class Initialized
ERROR - 2011-08-24 14:37:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:38:12 --> Config Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:38:12 --> URI Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Router Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Output Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Input Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:38:12 --> Language Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Loader Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Controller Class Initialized
ERROR - 2011-08-24 14:38:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:38:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:38:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:38:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:38:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:38:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:38:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:38:12 --> Final output sent to browser
DEBUG - 2011-08-24 14:38:12 --> Total execution time: 0.0355
DEBUG - 2011-08-24 14:38:13 --> Config Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:38:13 --> URI Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Router Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Output Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Input Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:38:13 --> Language Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Loader Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Controller Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Model Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Model Class Initialized
DEBUG - 2011-08-24 14:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:38:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:38:14 --> Final output sent to browser
DEBUG - 2011-08-24 14:38:14 --> Total execution time: 0.9337
DEBUG - 2011-08-24 14:38:14 --> Config Class Initialized
DEBUG - 2011-08-24 14:38:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:38:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:38:14 --> URI Class Initialized
DEBUG - 2011-08-24 14:38:14 --> Router Class Initialized
ERROR - 2011-08-24 14:38:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:39:42 --> Config Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:39:42 --> URI Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Router Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Output Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Input Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:39:42 --> Language Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Loader Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Controller Class Initialized
ERROR - 2011-08-24 14:39:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:39:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:39:42 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:39:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:39:42 --> Final output sent to browser
DEBUG - 2011-08-24 14:39:42 --> Total execution time: 0.0734
DEBUG - 2011-08-24 14:39:44 --> Config Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:39:44 --> URI Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Router Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Output Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Input Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:39:44 --> Language Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Loader Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Controller Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:39:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:39:45 --> Final output sent to browser
DEBUG - 2011-08-24 14:39:45 --> Total execution time: 0.9863
DEBUG - 2011-08-24 14:39:52 --> Config Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:39:52 --> URI Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Router Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Output Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Input Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:39:52 --> Language Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Loader Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Controller Class Initialized
ERROR - 2011-08-24 14:39:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:39:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:39:52 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:39:52 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:39:52 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:39:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:39:52 --> Final output sent to browser
DEBUG - 2011-08-24 14:39:52 --> Total execution time: 0.0317
DEBUG - 2011-08-24 14:39:55 --> Config Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:39:55 --> URI Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Router Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Output Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Input Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:39:55 --> Language Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Loader Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Controller Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Model Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:39:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:39:55 --> Final output sent to browser
DEBUG - 2011-08-24 14:39:55 --> Total execution time: 0.8164
DEBUG - 2011-08-24 14:42:24 --> Config Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:42:24 --> URI Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Router Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Output Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Input Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:42:24 --> Language Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Loader Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Controller Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:42:25 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:42:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:42:25 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:42:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:42:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:42:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:42:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:42:25 --> Final output sent to browser
DEBUG - 2011-08-24 14:42:25 --> Total execution time: 0.0499
DEBUG - 2011-08-24 14:42:26 --> Config Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:42:26 --> URI Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Router Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Output Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Input Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:42:26 --> Language Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Loader Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Controller Class Initialized
ERROR - 2011-08-24 14:42:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:42:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:42:26 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:42:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:42:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:42:26 --> Final output sent to browser
DEBUG - 2011-08-24 14:42:26 --> Total execution time: 0.0261
DEBUG - 2011-08-24 14:42:27 --> Config Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:42:27 --> URI Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Router Class Initialized
ERROR - 2011-08-24 14:42:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:42:27 --> Config Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:42:27 --> URI Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Router Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Output Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Input Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:42:27 --> Language Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Loader Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Controller Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:42:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Config Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:42:27 --> URI Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Router Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Output Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Input Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:42:27 --> Language Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Loader Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Controller Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Model Class Initialized
DEBUG - 2011-08-24 14:42:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:42:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:42:28 --> Final output sent to browser
DEBUG - 2011-08-24 14:42:28 --> Total execution time: 0.7923
DEBUG - 2011-08-24 14:42:28 --> Final output sent to browser
DEBUG - 2011-08-24 14:42:28 --> Total execution time: 0.7741
DEBUG - 2011-08-24 14:43:13 --> Config Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:43:13 --> URI Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Router Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Output Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Input Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:43:13 --> Language Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Loader Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Controller Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:43:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:43:13 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:43:13 --> Final output sent to browser
DEBUG - 2011-08-24 14:43:13 --> Total execution time: 0.1318
DEBUG - 2011-08-24 14:43:25 --> Config Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:43:25 --> URI Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Router Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Output Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Input Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:43:25 --> Language Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Loader Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Controller Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Model Class Initialized
DEBUG - 2011-08-24 14:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:43:25 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:43:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:43:25 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:43:25 --> Final output sent to browser
DEBUG - 2011-08-24 14:43:25 --> Total execution time: 0.2464
DEBUG - 2011-08-24 14:44:35 --> Config Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:44:35 --> URI Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Router Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Output Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Input Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:44:35 --> Language Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Loader Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Controller Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Model Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Model Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Model Class Initialized
DEBUG - 2011-08-24 14:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:44:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:44:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:44:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:44:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:44:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:44:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:44:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:44:35 --> Final output sent to browser
DEBUG - 2011-08-24 14:44:35 --> Total execution time: 0.8623
DEBUG - 2011-08-24 14:45:21 --> Config Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:45:21 --> URI Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Router Class Initialized
DEBUG - 2011-08-24 14:45:21 --> No URI present. Default controller set.
DEBUG - 2011-08-24 14:45:21 --> Output Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Input Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:45:21 --> Language Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Loader Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Controller Class Initialized
DEBUG - 2011-08-24 14:45:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 14:45:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:45:21 --> Final output sent to browser
DEBUG - 2011-08-24 14:45:21 --> Total execution time: 0.0162
DEBUG - 2011-08-24 14:45:21 --> Config Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:45:21 --> URI Class Initialized
DEBUG - 2011-08-24 14:45:21 --> Router Class Initialized
ERROR - 2011-08-24 14:45:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:54:20 --> Config Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:54:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:54:20 --> URI Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Router Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Output Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Input Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:54:20 --> Language Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Loader Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Controller Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Model Class Initialized
DEBUG - 2011-08-24 14:54:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:54:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:54:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:54:20 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:54:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:54:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:54:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:54:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:54:20 --> Final output sent to browser
DEBUG - 2011-08-24 14:54:20 --> Total execution time: 0.0568
DEBUG - 2011-08-24 14:54:27 --> Config Class Initialized
DEBUG - 2011-08-24 14:54:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:54:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:54:27 --> URI Class Initialized
DEBUG - 2011-08-24 14:54:27 --> Router Class Initialized
ERROR - 2011-08-24 14:54:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:56:00 --> Config Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:56:00 --> URI Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Router Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Output Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Input Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:56:00 --> Language Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Loader Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Controller Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Model Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Model Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Model Class Initialized
DEBUG - 2011-08-24 14:56:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:56:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:56:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 14:56:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:56:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:56:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:56:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:56:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:56:00 --> Final output sent to browser
DEBUG - 2011-08-24 14:56:00 --> Total execution time: 0.0491
DEBUG - 2011-08-24 14:56:07 --> Config Class Initialized
DEBUG - 2011-08-24 14:56:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:56:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:56:07 --> URI Class Initialized
DEBUG - 2011-08-24 14:56:07 --> Router Class Initialized
ERROR - 2011-08-24 14:56:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:57:50 --> Config Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:57:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:57:50 --> URI Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Router Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Output Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Input Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:57:50 --> Language Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Loader Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Controller Class Initialized
ERROR - 2011-08-24 14:57:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:57:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:57:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Model Class Initialized
DEBUG - 2011-08-24 14:57:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:57:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:57:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:57:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:57:50 --> Final output sent to browser
DEBUG - 2011-08-24 14:57:50 --> Total execution time: 0.0295
DEBUG - 2011-08-24 14:57:51 --> Config Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:57:51 --> URI Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Router Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Output Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Input Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:57:51 --> Language Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Loader Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Controller Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Model Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Model Class Initialized
DEBUG - 2011-08-24 14:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:57:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:57:52 --> Final output sent to browser
DEBUG - 2011-08-24 14:57:52 --> Total execution time: 1.1519
DEBUG - 2011-08-24 14:57:55 --> Config Class Initialized
DEBUG - 2011-08-24 14:57:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:57:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:57:55 --> URI Class Initialized
DEBUG - 2011-08-24 14:57:55 --> Router Class Initialized
ERROR - 2011-08-24 14:57:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:59:04 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:04 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:04 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Controller Class Initialized
ERROR - 2011-08-24 14:59:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:59:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:04 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:59:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:59:04 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:04 --> Total execution time: 0.0372
DEBUG - 2011-08-24 14:59:09 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:09 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:09 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Controller Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:12 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:12 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Controller Class Initialized
ERROR - 2011-08-24 14:59:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:59:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:59:12 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:12 --> Total execution time: 0.0301
DEBUG - 2011-08-24 14:59:14 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:14 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:14 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Controller Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:15 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:15 --> Total execution time: 1.0893
DEBUG - 2011-08-24 14:59:16 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:16 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:16 --> Router Class Initialized
ERROR - 2011-08-24 14:59:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:59:17 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:17 --> Total execution time: 8.3931
DEBUG - 2011-08-24 14:59:35 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:35 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:35 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Controller Class Initialized
ERROR - 2011-08-24 14:59:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:59:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:35 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:59:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:59:35 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:35 --> Total execution time: 0.0475
DEBUG - 2011-08-24 14:59:36 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:36 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:36 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Controller Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:37 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:37 --> Total execution time: 1.0928
DEBUG - 2011-08-24 14:59:39 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:39 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:39 --> Router Class Initialized
ERROR - 2011-08-24 14:59:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:59:40 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:40 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:40 --> Router Class Initialized
ERROR - 2011-08-24 14:59:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:59:45 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:45 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:45 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Controller Class Initialized
ERROR - 2011-08-24 14:59:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:59:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:45 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:45 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:59:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:59:45 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:45 --> Total execution time: 0.0337
DEBUG - 2011-08-24 14:59:47 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:47 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:47 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Controller Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:48 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:48 --> Total execution time: 1.0800
DEBUG - 2011-08-24 14:59:49 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:49 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:49 --> Router Class Initialized
ERROR - 2011-08-24 14:59:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 14:59:56 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:56 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:56 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Controller Class Initialized
ERROR - 2011-08-24 14:59:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 14:59:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 14:59:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 14:59:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 14:59:56 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:56 --> Total execution time: 0.0297
DEBUG - 2011-08-24 14:59:58 --> Config Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 14:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 14:59:58 --> URI Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Router Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Output Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Input Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 14:59:58 --> Language Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Loader Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Controller Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Model Class Initialized
DEBUG - 2011-08-24 14:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 14:59:58 --> Database Driver Class Initialized
DEBUG - 2011-08-24 14:59:59 --> Final output sent to browser
DEBUG - 2011-08-24 14:59:59 --> Total execution time: 0.8383
DEBUG - 2011-08-24 15:00:01 --> Config Class Initialized
DEBUG - 2011-08-24 15:00:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:00:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:00:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:00:01 --> URI Class Initialized
DEBUG - 2011-08-24 15:00:01 --> Router Class Initialized
ERROR - 2011-08-24 15:00:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:00:05 --> Config Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:00:05 --> URI Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Router Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Output Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Input Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:00:05 --> Language Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Loader Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Controller Class Initialized
ERROR - 2011-08-24 15:00:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 15:00:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:00:05 --> Model Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Model Class Initialized
DEBUG - 2011-08-24 15:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:00:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:00:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:00:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:00:05 --> Final output sent to browser
DEBUG - 2011-08-24 15:00:05 --> Total execution time: 0.2018
DEBUG - 2011-08-24 15:00:06 --> Config Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:00:06 --> URI Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Router Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Output Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Input Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:00:06 --> Language Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Loader Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Controller Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Model Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Model Class Initialized
DEBUG - 2011-08-24 15:00:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:00:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:00:09 --> Final output sent to browser
DEBUG - 2011-08-24 15:00:09 --> Total execution time: 2.4558
DEBUG - 2011-08-24 15:06:01 --> Config Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:06:01 --> URI Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Router Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Output Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Input Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:06:01 --> Language Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Loader Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Controller Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:06:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:06:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:06:01 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:06:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:06:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:06:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:06:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:06:01 --> Final output sent to browser
DEBUG - 2011-08-24 15:06:01 --> Total execution time: 0.0419
DEBUG - 2011-08-24 15:06:04 --> Config Class Initialized
DEBUG - 2011-08-24 15:06:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:06:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:06:04 --> URI Class Initialized
DEBUG - 2011-08-24 15:06:04 --> Router Class Initialized
ERROR - 2011-08-24 15:06:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:06:30 --> Config Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:06:30 --> URI Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Router Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Output Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Input Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:06:30 --> Language Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Loader Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Controller Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:06:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:06:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:06:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:06:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:06:30 --> Final output sent to browser
DEBUG - 2011-08-24 15:06:30 --> Total execution time: 0.0583
DEBUG - 2011-08-24 15:06:34 --> Config Class Initialized
DEBUG - 2011-08-24 15:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:06:34 --> URI Class Initialized
DEBUG - 2011-08-24 15:06:34 --> Router Class Initialized
ERROR - 2011-08-24 15:06:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:07:49 --> Config Class Initialized
DEBUG - 2011-08-24 15:07:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:07:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:07:49 --> URI Class Initialized
DEBUG - 2011-08-24 15:07:49 --> Router Class Initialized
ERROR - 2011-08-24 15:07:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 15:14:47 --> Config Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:14:47 --> URI Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Router Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Output Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Input Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:14:47 --> Language Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Loader Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Controller Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Model Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Model Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Model Class Initialized
DEBUG - 2011-08-24 15:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:14:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:14:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:14:47 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:14:47 --> Final output sent to browser
DEBUG - 2011-08-24 15:14:47 --> Total execution time: 0.0522
DEBUG - 2011-08-24 15:14:48 --> Config Class Initialized
DEBUG - 2011-08-24 15:14:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:14:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:14:48 --> URI Class Initialized
DEBUG - 2011-08-24 15:14:48 --> Router Class Initialized
ERROR - 2011-08-24 15:14:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:14:49 --> Config Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:14:49 --> URI Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Router Class Initialized
ERROR - 2011-08-24 15:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:14:49 --> Config Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:14:49 --> URI Class Initialized
DEBUG - 2011-08-24 15:14:49 --> Router Class Initialized
ERROR - 2011-08-24 15:14:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:15:05 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:05 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:05 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Controller Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:15:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:15:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:15:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:15:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:15:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:15:05 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:05 --> Total execution time: 0.2559
DEBUG - 2011-08-24 15:15:08 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:08 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:08 --> Router Class Initialized
ERROR - 2011-08-24 15:15:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:15:21 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:21 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:21 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Controller Class Initialized
ERROR - 2011-08-24 15:15:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 15:15:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:15:21 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:15:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:15:21 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:21 --> Total execution time: 0.0387
DEBUG - 2011-08-24 15:15:22 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:22 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:22 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Controller Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:23 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:23 --> Total execution time: 0.9260
DEBUG - 2011-08-24 15:15:33 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:33 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:33 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Controller Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:15:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:15:33 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:33 --> Total execution time: 0.2853
DEBUG - 2011-08-24 15:15:37 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:37 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:37 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Controller Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:15:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:15:37 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:37 --> Total execution time: 0.0425
DEBUG - 2011-08-24 15:15:37 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:37 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:37 --> Router Class Initialized
ERROR - 2011-08-24 15:15:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:15:48 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:48 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Router Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Output Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Input Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:15:48 --> Language Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Loader Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Controller Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Model Class Initialized
DEBUG - 2011-08-24 15:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:15:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:15:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:15:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:15:48 --> Final output sent to browser
DEBUG - 2011-08-24 15:15:48 --> Total execution time: 0.3312
DEBUG - 2011-08-24 15:15:51 --> Config Class Initialized
DEBUG - 2011-08-24 15:15:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:15:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:15:51 --> URI Class Initialized
DEBUG - 2011-08-24 15:15:51 --> Router Class Initialized
ERROR - 2011-08-24 15:15:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:17:14 --> Config Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:17:14 --> URI Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Router Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Output Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Input Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:17:14 --> Language Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Loader Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Controller Class Initialized
ERROR - 2011-08-24 15:17:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 15:17:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:17:14 --> Model Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Model Class Initialized
DEBUG - 2011-08-24 15:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:17:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:17:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:17:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:17:14 --> Final output sent to browser
DEBUG - 2011-08-24 15:17:14 --> Total execution time: 0.0307
DEBUG - 2011-08-24 15:18:51 --> Config Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:18:51 --> URI Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Router Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Output Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Input Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:18:51 --> Language Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Loader Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Controller Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Model Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Model Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Model Class Initialized
DEBUG - 2011-08-24 15:18:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:18:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:18:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:18:52 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:18:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:18:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:18:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:18:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:18:52 --> Final output sent to browser
DEBUG - 2011-08-24 15:18:52 --> Total execution time: 0.2601
DEBUG - 2011-08-24 15:18:56 --> Config Class Initialized
DEBUG - 2011-08-24 15:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:18:57 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:18:57 --> URI Class Initialized
DEBUG - 2011-08-24 15:18:57 --> Router Class Initialized
ERROR - 2011-08-24 15:18:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:19:43 --> Config Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:19:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:19:43 --> URI Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Router Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Output Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Input Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:19:43 --> Language Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Loader Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Controller Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Model Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Model Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Model Class Initialized
DEBUG - 2011-08-24 15:19:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:19:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:19:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:19:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:19:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:19:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:19:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:19:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:19:43 --> Final output sent to browser
DEBUG - 2011-08-24 15:19:43 --> Total execution time: 0.2851
DEBUG - 2011-08-24 15:20:17 --> Config Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:20:17 --> URI Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Router Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Output Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Input Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:20:17 --> Language Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Loader Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Controller Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:20:17 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:20:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:20:18 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:20:18 --> Final output sent to browser
DEBUG - 2011-08-24 15:20:18 --> Total execution time: 0.2508
DEBUG - 2011-08-24 15:20:31 --> Config Class Initialized
DEBUG - 2011-08-24 15:20:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:20:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:20:31 --> URI Class Initialized
DEBUG - 2011-08-24 15:20:31 --> Router Class Initialized
DEBUG - 2011-08-24 15:20:31 --> Output Class Initialized
DEBUG - 2011-08-24 15:20:31 --> Input Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:20:32 --> Language Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Loader Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Controller Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:20:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:20:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:20:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:20:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:20:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:20:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:20:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:20:32 --> Final output sent to browser
DEBUG - 2011-08-24 15:20:32 --> Total execution time: 0.2317
DEBUG - 2011-08-24 15:20:50 --> Config Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:20:50 --> URI Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Router Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Output Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Input Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:20:50 --> Language Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Loader Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Controller Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Model Class Initialized
DEBUG - 2011-08-24 15:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:20:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:20:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:20:51 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:20:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:20:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:20:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:20:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:20:51 --> Final output sent to browser
DEBUG - 2011-08-24 15:20:51 --> Total execution time: 0.9041
DEBUG - 2011-08-24 15:21:07 --> Config Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:21:07 --> URI Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Router Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Output Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Input Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:21:07 --> Language Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Loader Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Controller Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:21:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:21:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:21:08 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:21:08 --> Final output sent to browser
DEBUG - 2011-08-24 15:21:08 --> Total execution time: 0.4024
DEBUG - 2011-08-24 15:21:39 --> Config Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:21:39 --> URI Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Router Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Output Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Input Class Initialized
DEBUG - 2011-08-24 15:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:21:39 --> Language Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Loader Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Controller Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Model Class Initialized
DEBUG - 2011-08-24 15:21:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:21:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:21:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:21:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:21:41 --> Final output sent to browser
DEBUG - 2011-08-24 15:21:41 --> Total execution time: 1.0949
DEBUG - 2011-08-24 15:22:27 --> Config Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:22:27 --> URI Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Router Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Output Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Input Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:22:27 --> Language Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Loader Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Controller Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:22:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:22:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:22:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:22:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:22:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:22:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:22:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:22:28 --> Final output sent to browser
DEBUG - 2011-08-24 15:22:28 --> Total execution time: 0.8592
DEBUG - 2011-08-24 15:22:52 --> Config Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:22:52 --> URI Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Router Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Output Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Input Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:22:52 --> Language Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Loader Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Controller Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Model Class Initialized
DEBUG - 2011-08-24 15:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:22:52 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:22:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:22:53 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:22:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:22:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:22:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:22:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:22:53 --> Final output sent to browser
DEBUG - 2011-08-24 15:22:53 --> Total execution time: 0.6711
DEBUG - 2011-08-24 15:23:21 --> Config Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:23:21 --> URI Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Router Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Output Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Input Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:23:21 --> Language Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Loader Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Controller Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:23:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:23:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:23:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:23:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:23:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:23:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:23:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:23:21 --> Final output sent to browser
DEBUG - 2011-08-24 15:23:21 --> Total execution time: 0.2094
DEBUG - 2011-08-24 15:23:37 --> Config Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:23:37 --> URI Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Router Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Output Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Input Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:23:37 --> Language Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Loader Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Controller Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:23:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:23:38 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:23:38 --> Final output sent to browser
DEBUG - 2011-08-24 15:23:38 --> Total execution time: 0.8100
DEBUG - 2011-08-24 15:23:53 --> Config Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:23:53 --> URI Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Router Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Output Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Input Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:23:53 --> Language Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Loader Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Controller Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Model Class Initialized
DEBUG - 2011-08-24 15:23:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:23:53 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:23:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:23:53 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:23:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:23:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:23:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:23:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:23:53 --> Final output sent to browser
DEBUG - 2011-08-24 15:23:53 --> Total execution time: 0.2355
DEBUG - 2011-08-24 15:24:13 --> Config Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:24:13 --> URI Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Router Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Output Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Input Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:24:13 --> Language Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Loader Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Controller Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:24:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:24:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:24:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:24:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:24:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:24:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:24:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:24:14 --> Final output sent to browser
DEBUG - 2011-08-24 15:24:14 --> Total execution time: 0.4914
DEBUG - 2011-08-24 15:24:35 --> Config Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:24:35 --> URI Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Router Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Output Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Input Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:24:35 --> Language Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Loader Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Controller Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Model Class Initialized
DEBUG - 2011-08-24 15:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:24:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:24:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:24:35 --> Final output sent to browser
DEBUG - 2011-08-24 15:24:35 --> Total execution time: 0.0714
DEBUG - 2011-08-24 15:25:07 --> Config Class Initialized
DEBUG - 2011-08-24 15:25:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:25:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:25:07 --> URI Class Initialized
DEBUG - 2011-08-24 15:25:07 --> Router Class Initialized
ERROR - 2011-08-24 15:25:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:26:24 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:24 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Router Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Output Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Input Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:26:24 --> Language Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Loader Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Controller Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:26:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:26:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:26:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:26:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:26:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:26:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:26:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:26:24 --> Final output sent to browser
DEBUG - 2011-08-24 15:26:24 --> Total execution time: 0.0737
DEBUG - 2011-08-24 15:26:27 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:27 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Router Class Initialized
ERROR - 2011-08-24 15:26:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:26:27 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:27 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:27 --> Router Class Initialized
ERROR - 2011-08-24 15:26:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:26:28 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:28 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:28 --> Router Class Initialized
ERROR - 2011-08-24 15:26:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:26:30 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:30 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Router Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Output Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Input Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:26:30 --> Language Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Loader Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Controller Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:26:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:26:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:26:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:26:30 --> Final output sent to browser
DEBUG - 2011-08-24 15:26:30 --> Total execution time: 0.3506
DEBUG - 2011-08-24 15:26:44 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:44 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:44 --> Router Class Initialized
ERROR - 2011-08-24 15:26:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:26:45 --> Config Class Initialized
DEBUG - 2011-08-24 15:26:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:26:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:26:45 --> URI Class Initialized
DEBUG - 2011-08-24 15:26:45 --> Router Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Output Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Input Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:26:46 --> Language Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Loader Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Controller Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Model Class Initialized
DEBUG - 2011-08-24 15:26:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:26:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:26:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:26:46 --> Final output sent to browser
DEBUG - 2011-08-24 15:26:46 --> Total execution time: 0.0434
DEBUG - 2011-08-24 15:27:09 --> Config Class Initialized
DEBUG - 2011-08-24 15:27:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:27:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:27:09 --> URI Class Initialized
DEBUG - 2011-08-24 15:27:09 --> Router Class Initialized
ERROR - 2011-08-24 15:27:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:29:04 --> Config Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:29:04 --> URI Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Router Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Output Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Input Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:29:04 --> Language Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Loader Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Controller Class Initialized
ERROR - 2011-08-24 15:29:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 15:29:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:29:04 --> Model Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Model Class Initialized
DEBUG - 2011-08-24 15:29:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:29:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:29:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:29:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:29:04 --> Final output sent to browser
DEBUG - 2011-08-24 15:29:04 --> Total execution time: 0.0275
DEBUG - 2011-08-24 15:29:20 --> Config Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:29:20 --> URI Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Router Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Output Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Input Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:29:20 --> Language Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Loader Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Controller Class Initialized
ERROR - 2011-08-24 15:29:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 15:29:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:29:20 --> Model Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Model Class Initialized
DEBUG - 2011-08-24 15:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:29:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 15:29:20 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:29:20 --> Final output sent to browser
DEBUG - 2011-08-24 15:29:20 --> Total execution time: 0.0317
DEBUG - 2011-08-24 15:32:01 --> Config Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:32:01 --> URI Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Router Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Output Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Input Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:32:01 --> Language Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Loader Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Controller Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Model Class Initialized
DEBUG - 2011-08-24 15:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:32:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:32:01 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:32:01 --> Final output sent to browser
DEBUG - 2011-08-24 15:32:01 --> Total execution time: 0.0776
DEBUG - 2011-08-24 15:32:05 --> Config Class Initialized
DEBUG - 2011-08-24 15:32:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:32:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:32:05 --> URI Class Initialized
DEBUG - 2011-08-24 15:32:05 --> Router Class Initialized
ERROR - 2011-08-24 15:32:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 15:50:59 --> Config Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:50:59 --> URI Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Router Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Output Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Input Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:50:59 --> Language Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Loader Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Controller Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Model Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Model Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Model Class Initialized
DEBUG - 2011-08-24 15:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:50:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:50:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:50:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:50:59 --> Final output sent to browser
DEBUG - 2011-08-24 15:50:59 --> Total execution time: 0.0819
DEBUG - 2011-08-24 15:51:27 --> Config Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:51:27 --> URI Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Router Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Output Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Input Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:51:27 --> Language Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Loader Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Controller Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Model Class Initialized
DEBUG - 2011-08-24 15:51:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 15:51:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 15:51:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 15:51:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:51:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:51:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:51:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:51:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:51:27 --> Final output sent to browser
DEBUG - 2011-08-24 15:51:27 --> Total execution time: 0.2167
DEBUG - 2011-08-24 15:55:28 --> Config Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:55:28 --> URI Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Router Class Initialized
DEBUG - 2011-08-24 15:55:28 --> No URI present. Default controller set.
DEBUG - 2011-08-24 15:55:28 --> Output Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Input Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 15:55:28 --> Language Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Loader Class Initialized
DEBUG - 2011-08-24 15:55:28 --> Controller Class Initialized
DEBUG - 2011-08-24 15:55:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 15:55:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 15:55:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 15:55:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 15:55:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 15:55:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 15:55:28 --> Final output sent to browser
DEBUG - 2011-08-24 15:55:28 --> Total execution time: 0.0274
DEBUG - 2011-08-24 15:55:29 --> Config Class Initialized
DEBUG - 2011-08-24 15:55:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 15:55:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 15:55:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 15:55:29 --> URI Class Initialized
DEBUG - 2011-08-24 15:55:29 --> Router Class Initialized
ERROR - 2011-08-24 15:55:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:17:45 --> Config Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:17:45 --> URI Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Router Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Output Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Input Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:17:45 --> Language Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Loader Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Controller Class Initialized
ERROR - 2011-08-24 16:17:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:17:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:17:45 --> Model Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Model Class Initialized
DEBUG - 2011-08-24 16:17:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:17:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:17:45 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:17:45 --> Final output sent to browser
DEBUG - 2011-08-24 16:17:45 --> Total execution time: 0.0574
DEBUG - 2011-08-24 16:17:46 --> Config Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:17:46 --> URI Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Router Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Output Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Input Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:17:46 --> Language Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Loader Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Controller Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:17:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:17:47 --> Final output sent to browser
DEBUG - 2011-08-24 16:17:47 --> Total execution time: 1.0345
DEBUG - 2011-08-24 16:17:48 --> Config Class Initialized
DEBUG - 2011-08-24 16:17:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:17:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:17:48 --> URI Class Initialized
DEBUG - 2011-08-24 16:17:48 --> Router Class Initialized
ERROR - 2011-08-24 16:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:22:46 --> Config Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:22:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:22:46 --> URI Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Router Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Output Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Input Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:22:46 --> Language Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Loader Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Controller Class Initialized
ERROR - 2011-08-24 16:22:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:22:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:22:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:22:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:22:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:22:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:22:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:22:46 --> Final output sent to browser
DEBUG - 2011-08-24 16:22:46 --> Total execution time: 0.0498
DEBUG - 2011-08-24 16:22:47 --> Config Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:22:47 --> URI Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Router Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Output Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Input Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:22:47 --> Language Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Loader Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Controller Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Model Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Model Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:22:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:22:47 --> Final output sent to browser
DEBUG - 2011-08-24 16:22:47 --> Total execution time: 0.9055
DEBUG - 2011-08-24 16:22:49 --> Config Class Initialized
DEBUG - 2011-08-24 16:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:22:49 --> URI Class Initialized
DEBUG - 2011-08-24 16:22:49 --> Router Class Initialized
ERROR - 2011-08-24 16:22:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:23:04 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:04 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Router Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Output Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Input Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:23:04 --> Language Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Loader Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Controller Class Initialized
ERROR - 2011-08-24 16:23:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:23:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:23:04 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:23:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:23:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:23:04 --> Final output sent to browser
DEBUG - 2011-08-24 16:23:04 --> Total execution time: 0.0276
DEBUG - 2011-08-24 16:23:04 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:04 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Router Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Output Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Input Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:23:04 --> Language Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Loader Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Controller Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:23:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:23:05 --> Final output sent to browser
DEBUG - 2011-08-24 16:23:05 --> Total execution time: 0.8249
DEBUG - 2011-08-24 16:23:06 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:06 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:06 --> Router Class Initialized
ERROR - 2011-08-24 16:23:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:23:17 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:17 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Router Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Output Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Input Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:23:17 --> Language Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Loader Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Controller Class Initialized
ERROR - 2011-08-24 16:23:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:23:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:23:17 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:23:17 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:23:17 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:23:17 --> Final output sent to browser
DEBUG - 2011-08-24 16:23:17 --> Total execution time: 0.0296
DEBUG - 2011-08-24 16:23:18 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:18 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Router Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Output Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Input Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:23:18 --> Language Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Loader Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Controller Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Model Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:23:18 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:23:18 --> Final output sent to browser
DEBUG - 2011-08-24 16:23:18 --> Total execution time: 0.8153
DEBUG - 2011-08-24 16:23:19 --> Config Class Initialized
DEBUG - 2011-08-24 16:23:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:23:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:23:19 --> URI Class Initialized
DEBUG - 2011-08-24 16:23:19 --> Router Class Initialized
ERROR - 2011-08-24 16:23:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:31:05 --> Config Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:31:05 --> URI Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Router Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Output Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Input Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:31:05 --> Language Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Loader Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Controller Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Model Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Model Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Model Class Initialized
DEBUG - 2011-08-24 16:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:31:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:31:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:31:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:31:05 --> Final output sent to browser
DEBUG - 2011-08-24 16:31:05 --> Total execution time: 0.1998
DEBUG - 2011-08-24 16:32:54 --> Config Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:32:54 --> URI Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Router Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Output Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Input Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:32:54 --> Language Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Loader Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Controller Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Model Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Model Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Model Class Initialized
DEBUG - 2011-08-24 16:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:32:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:32:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:32:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:32:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:32:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:32:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:32:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:32:54 --> Final output sent to browser
DEBUG - 2011-08-24 16:32:54 --> Total execution time: 0.0498
DEBUG - 2011-08-24 16:33:00 --> Config Class Initialized
DEBUG - 2011-08-24 16:33:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:33:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:33:00 --> URI Class Initialized
DEBUG - 2011-08-24 16:33:00 --> Router Class Initialized
ERROR - 2011-08-24 16:33:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:33:25 --> Config Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:33:25 --> URI Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Router Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Output Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Input Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:33:25 --> Language Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Loader Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Controller Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:33:25 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:33:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:33:25 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:33:25 --> Final output sent to browser
DEBUG - 2011-08-24 16:33:25 --> Total execution time: 0.2288
DEBUG - 2011-08-24 16:33:29 --> Config Class Initialized
DEBUG - 2011-08-24 16:33:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:33:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:33:29 --> URI Class Initialized
DEBUG - 2011-08-24 16:33:29 --> Router Class Initialized
ERROR - 2011-08-24 16:33:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:33:46 --> Config Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:33:46 --> URI Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Router Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Output Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Input Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:33:46 --> Language Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Loader Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Controller Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Model Class Initialized
DEBUG - 2011-08-24 16:33:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:33:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:33:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:33:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:33:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:33:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:33:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:33:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:33:46 --> Final output sent to browser
DEBUG - 2011-08-24 16:33:46 --> Total execution time: 0.2430
DEBUG - 2011-08-24 16:33:52 --> Config Class Initialized
DEBUG - 2011-08-24 16:33:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:33:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:33:52 --> URI Class Initialized
DEBUG - 2011-08-24 16:33:52 --> Router Class Initialized
ERROR - 2011-08-24 16:33:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:34:09 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:09 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Router Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Output Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Input Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:34:09 --> Language Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Loader Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Controller Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:34:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:34:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:34:09 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:34:09 --> Final output sent to browser
DEBUG - 2011-08-24 16:34:09 --> Total execution time: 0.1929
DEBUG - 2011-08-24 16:34:13 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:13 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:13 --> Router Class Initialized
ERROR - 2011-08-24 16:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:34:22 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:22 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Router Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Output Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Input Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:34:22 --> Language Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Loader Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Controller Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:34:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:34:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:34:22 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:34:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:34:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:34:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:34:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:34:22 --> Final output sent to browser
DEBUG - 2011-08-24 16:34:22 --> Total execution time: 0.1994
DEBUG - 2011-08-24 16:34:26 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:26 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:26 --> Router Class Initialized
ERROR - 2011-08-24 16:34:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:34:36 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:36 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Router Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Output Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Input Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:34:36 --> Language Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Loader Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Controller Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:34:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:34:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:34:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:34:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:34:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:34:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:34:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:34:37 --> Final output sent to browser
DEBUG - 2011-08-24 16:34:37 --> Total execution time: 0.2734
DEBUG - 2011-08-24 16:34:40 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:40 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:40 --> Router Class Initialized
ERROR - 2011-08-24 16:34:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:34:49 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:49 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Router Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Output Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Input Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:34:49 --> Language Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Loader Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Controller Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:34:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:34:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:34:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:34:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:34:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:34:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:34:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:34:50 --> Final output sent to browser
DEBUG - 2011-08-24 16:34:50 --> Total execution time: 0.2159
DEBUG - 2011-08-24 16:34:53 --> Config Class Initialized
DEBUG - 2011-08-24 16:34:53 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:34:53 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:34:53 --> URI Class Initialized
DEBUG - 2011-08-24 16:34:53 --> Router Class Initialized
ERROR - 2011-08-24 16:34:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:01 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:01 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:01 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:03 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:03 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:03 --> Total execution time: 1.4813
DEBUG - 2011-08-24 16:35:08 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:08 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:08 --> Router Class Initialized
ERROR - 2011-08-24 16:35:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:22 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:22 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:22 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:22 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:22 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:22 --> Total execution time: 0.2968
DEBUG - 2011-08-24 16:35:27 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:27 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:27 --> Router Class Initialized
ERROR - 2011-08-24 16:35:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:32 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:32 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:32 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:32 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:32 --> Total execution time: 0.2651
DEBUG - 2011-08-24 16:35:36 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:36 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:36 --> Router Class Initialized
ERROR - 2011-08-24 16:35:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:41 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:41 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:41 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:41 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:41 --> Total execution time: 0.1885
DEBUG - 2011-08-24 16:35:45 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:45 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:45 --> Router Class Initialized
ERROR - 2011-08-24 16:35:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:49 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:49 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:49 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:50 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:50 --> Total execution time: 0.4296
DEBUG - 2011-08-24 16:35:54 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:54 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:54 --> Router Class Initialized
ERROR - 2011-08-24 16:35:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:35:58 --> Config Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:35:58 --> URI Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Router Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Output Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Input Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:35:58 --> Language Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Loader Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Controller Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Model Class Initialized
DEBUG - 2011-08-24 16:35:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:35:58 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:35:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:35:58 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:35:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:35:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:35:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:35:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:35:58 --> Final output sent to browser
DEBUG - 2011-08-24 16:35:58 --> Total execution time: 0.2181
DEBUG - 2011-08-24 16:36:02 --> Config Class Initialized
DEBUG - 2011-08-24 16:36:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:36:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:36:02 --> URI Class Initialized
DEBUG - 2011-08-24 16:36:02 --> Router Class Initialized
ERROR - 2011-08-24 16:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:36:07 --> Config Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:36:07 --> URI Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Router Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Output Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Input Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:36:07 --> Language Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Loader Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Controller Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Model Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Model Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Model Class Initialized
DEBUG - 2011-08-24 16:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:36:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:36:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 16:36:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:36:07 --> Final output sent to browser
DEBUG - 2011-08-24 16:36:07 --> Total execution time: 0.1797
DEBUG - 2011-08-24 16:36:10 --> Config Class Initialized
DEBUG - 2011-08-24 16:36:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:36:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:36:10 --> URI Class Initialized
DEBUG - 2011-08-24 16:36:10 --> Router Class Initialized
ERROR - 2011-08-24 16:36:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:41:01 --> Config Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:41:01 --> URI Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Router Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Output Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Input Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:41:01 --> Language Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Loader Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Controller Class Initialized
ERROR - 2011-08-24 16:41:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:41:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:41:01 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:41:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:41:01 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:41:01 --> Final output sent to browser
DEBUG - 2011-08-24 16:41:01 --> Total execution time: 0.0294
DEBUG - 2011-08-24 16:41:03 --> Config Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:41:03 --> URI Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Router Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Output Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Input Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:41:03 --> Language Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Loader Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Controller Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:41:03 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:41:04 --> Final output sent to browser
DEBUG - 2011-08-24 16:41:04 --> Total execution time: 0.8329
DEBUG - 2011-08-24 16:41:05 --> Config Class Initialized
DEBUG - 2011-08-24 16:41:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:41:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:41:05 --> URI Class Initialized
DEBUG - 2011-08-24 16:41:05 --> Router Class Initialized
ERROR - 2011-08-24 16:41:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 16:41:26 --> Config Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:41:26 --> URI Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Router Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Output Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Input Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:41:26 --> Language Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Loader Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Controller Class Initialized
ERROR - 2011-08-24 16:41:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 16:41:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:41:26 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:41:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 16:41:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 16:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 16:41:26 --> Final output sent to browser
DEBUG - 2011-08-24 16:41:26 --> Total execution time: 0.0311
DEBUG - 2011-08-24 16:41:27 --> Config Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 16:41:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 16:41:27 --> URI Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Router Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Output Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Input Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 16:41:27 --> Language Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Loader Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Controller Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Model Class Initialized
DEBUG - 2011-08-24 16:41:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 16:41:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 16:41:28 --> Final output sent to browser
DEBUG - 2011-08-24 16:41:28 --> Total execution time: 0.8358
DEBUG - 2011-08-24 17:04:45 --> Config Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:04:45 --> URI Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Router Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Output Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Input Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:04:45 --> Language Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Loader Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Controller Class Initialized
ERROR - 2011-08-24 17:04:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:04:45 --> Model Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Model Class Initialized
DEBUG - 2011-08-24 17:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:04:45 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:04:45 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:04:45 --> Final output sent to browser
DEBUG - 2011-08-24 17:04:45 --> Total execution time: 0.0348
DEBUG - 2011-08-24 17:04:46 --> Config Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:04:46 --> URI Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Router Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Output Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Input Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:04:46 --> Language Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Loader Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Controller Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Model Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Model Class Initialized
DEBUG - 2011-08-24 17:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:04:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:04:47 --> Final output sent to browser
DEBUG - 2011-08-24 17:04:47 --> Total execution time: 0.9565
DEBUG - 2011-08-24 17:04:48 --> Config Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:04:48 --> URI Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Router Class Initialized
ERROR - 2011-08-24 17:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:04:48 --> Config Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:04:48 --> URI Class Initialized
DEBUG - 2011-08-24 17:04:48 --> Router Class Initialized
ERROR - 2011-08-24 17:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:05:35 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:35 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Router Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Output Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Input Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:05:35 --> Language Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Loader Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Controller Class Initialized
ERROR - 2011-08-24 17:05:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:05:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:05:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:05:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:05:35 --> Final output sent to browser
DEBUG - 2011-08-24 17:05:35 --> Total execution time: 0.0273
DEBUG - 2011-08-24 17:05:35 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:35 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Router Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Output Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Input Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:05:35 --> Language Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Loader Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Controller Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:05:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:05:36 --> Final output sent to browser
DEBUG - 2011-08-24 17:05:36 --> Total execution time: 0.8384
DEBUG - 2011-08-24 17:05:37 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:37 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:37 --> Router Class Initialized
ERROR - 2011-08-24 17:05:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:05:47 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:47 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Router Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Output Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Input Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:05:47 --> Language Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Loader Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Controller Class Initialized
ERROR - 2011-08-24 17:05:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:05:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:47 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:05:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:47 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:05:47 --> Final output sent to browser
DEBUG - 2011-08-24 17:05:47 --> Total execution time: 0.0370
DEBUG - 2011-08-24 17:05:48 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:48 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Router Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Output Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Input Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:05:48 --> Language Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Loader Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Controller Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:05:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:48 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Router Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Output Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Input Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:05:48 --> Language Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Loader Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Controller Class Initialized
ERROR - 2011-08-24 17:05:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:05:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:48 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Model Class Initialized
DEBUG - 2011-08-24 17:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:05:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:05:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:05:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:05:48 --> Final output sent to browser
DEBUG - 2011-08-24 17:05:48 --> Total execution time: 0.0314
DEBUG - 2011-08-24 17:05:48 --> Final output sent to browser
DEBUG - 2011-08-24 17:05:48 --> Total execution time: 0.8639
DEBUG - 2011-08-24 17:05:49 --> Config Class Initialized
DEBUG - 2011-08-24 17:05:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:05:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:05:49 --> URI Class Initialized
DEBUG - 2011-08-24 17:05:49 --> Router Class Initialized
ERROR - 2011-08-24 17:05:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:06:00 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:00 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:00 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Controller Class Initialized
ERROR - 2011-08-24 17:06:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:06:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:06:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:06:00 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:00 --> Total execution time: 0.0645
DEBUG - 2011-08-24 17:06:01 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:01 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:01 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Controller Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:02 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:02 --> Total execution time: 1.2370
DEBUG - 2011-08-24 17:06:03 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:03 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:03 --> Router Class Initialized
ERROR - 2011-08-24 17:06:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:06:20 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:20 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:20 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Controller Class Initialized
ERROR - 2011-08-24 17:06:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:06:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:21 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:06:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:06:21 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:21 --> Total execution time: 0.0273
DEBUG - 2011-08-24 17:06:21 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:21 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:21 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Controller Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:21 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:22 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:22 --> Total execution time: 0.9217
DEBUG - 2011-08-24 17:06:23 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:23 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:23 --> Router Class Initialized
ERROR - 2011-08-24 17:06:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:06:34 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:34 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:34 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Controller Class Initialized
ERROR - 2011-08-24 17:06:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:06:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:34 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:06:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:06:34 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:34 --> Total execution time: 0.0285
DEBUG - 2011-08-24 17:06:35 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:35 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:35 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Controller Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:36 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:36 --> Total execution time: 0.8646
DEBUG - 2011-08-24 17:06:37 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:37 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:37 --> Router Class Initialized
ERROR - 2011-08-24 17:06:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:06:46 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:46 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:46 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Controller Class Initialized
ERROR - 2011-08-24 17:06:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:06:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:46 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:06:46 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:46 --> Total execution time: 0.1222
DEBUG - 2011-08-24 17:06:47 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:47 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:47 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Controller Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:47 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:47 --> Total execution time: 0.9033
DEBUG - 2011-08-24 17:06:49 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:49 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:49 --> Router Class Initialized
ERROR - 2011-08-24 17:06:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:06:58 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:58 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:58 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Controller Class Initialized
ERROR - 2011-08-24 17:06:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:06:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:58 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:58 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:06:58 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:06:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:06:58 --> Final output sent to browser
DEBUG - 2011-08-24 17:06:58 --> Total execution time: 0.0377
DEBUG - 2011-08-24 17:06:59 --> Config Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:06:59 --> URI Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Router Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Output Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Input Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:06:59 --> Language Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Loader Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Controller Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:06:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:06:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:00 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:00 --> Total execution time: 0.8007
DEBUG - 2011-08-24 17:07:03 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:03 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:03 --> Router Class Initialized
ERROR - 2011-08-24 17:07:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:07:10 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:10 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:10 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Controller Class Initialized
ERROR - 2011-08-24 17:07:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:07:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:10 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:10 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:07:10 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:10 --> Total execution time: 0.0299
DEBUG - 2011-08-24 17:07:11 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:11 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:11 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Controller Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:11 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:11 --> Total execution time: 0.9133
DEBUG - 2011-08-24 17:07:14 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:14 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:14 --> Router Class Initialized
ERROR - 2011-08-24 17:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:07:16 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:16 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:16 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Controller Class Initialized
ERROR - 2011-08-24 17:07:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:07:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:07:16 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:16 --> Total execution time: 0.0296
DEBUG - 2011-08-24 17:07:16 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:16 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:16 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Controller Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:17 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:17 --> Total execution time: 0.8588
DEBUG - 2011-08-24 17:07:20 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:20 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:20 --> Router Class Initialized
ERROR - 2011-08-24 17:07:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:07:26 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:26 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:26 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Controller Class Initialized
ERROR - 2011-08-24 17:07:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:07:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:26 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:07:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:07:26 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:26 --> Total execution time: 0.0276
DEBUG - 2011-08-24 17:07:27 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:27 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:27 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Controller Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:27 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:27 --> Total execution time: 0.8681
DEBUG - 2011-08-24 17:07:29 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:29 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:29 --> Router Class Initialized
ERROR - 2011-08-24 17:07:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:07:36 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:36 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:36 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Controller Class Initialized
ERROR - 2011-08-24 17:07:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:07:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:36 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:36 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:07:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:07:36 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:36 --> Total execution time: 0.0316
DEBUG - 2011-08-24 17:07:36 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:36 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:36 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Controller Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:37 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:37 --> Total execution time: 0.8222
DEBUG - 2011-08-24 17:07:39 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:39 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:39 --> Router Class Initialized
ERROR - 2011-08-24 17:07:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:07:43 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:43 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:43 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Controller Class Initialized
ERROR - 2011-08-24 17:07:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:07:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:43 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:07:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:07:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:07:43 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:43 --> Total execution time: 0.0297
DEBUG - 2011-08-24 17:07:44 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:44 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Router Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Output Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Input Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:07:44 --> Language Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Loader Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Controller Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Model Class Initialized
DEBUG - 2011-08-24 17:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:07:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:07:45 --> Final output sent to browser
DEBUG - 2011-08-24 17:07:45 --> Total execution time: 0.8114
DEBUG - 2011-08-24 17:07:46 --> Config Class Initialized
DEBUG - 2011-08-24 17:07:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:07:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:07:46 --> URI Class Initialized
DEBUG - 2011-08-24 17:07:46 --> Router Class Initialized
ERROR - 2011-08-24 17:07:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:08:00 --> Config Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:08:00 --> URI Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Router Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Output Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Input Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:08:00 --> Language Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Loader Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Controller Class Initialized
ERROR - 2011-08-24 17:08:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:08:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:08:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:08:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:08:00 --> Final output sent to browser
DEBUG - 2011-08-24 17:08:00 --> Total execution time: 0.0288
DEBUG - 2011-08-24 17:08:00 --> Config Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:08:00 --> URI Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Router Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Output Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Input Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:08:00 --> Language Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Loader Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Controller Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Model Class Initialized
DEBUG - 2011-08-24 17:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:08:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:08:01 --> Final output sent to browser
DEBUG - 2011-08-24 17:08:01 --> Total execution time: 0.9008
DEBUG - 2011-08-24 17:08:02 --> Config Class Initialized
DEBUG - 2011-08-24 17:08:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:08:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:08:02 --> URI Class Initialized
DEBUG - 2011-08-24 17:08:02 --> Router Class Initialized
ERROR - 2011-08-24 17:08:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:29:34 --> Config Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:29:34 --> URI Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Router Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Output Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Input Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:29:34 --> Language Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Loader Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Controller Class Initialized
ERROR - 2011-08-24 17:29:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:29:34 --> Model Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Model Class Initialized
DEBUG - 2011-08-24 17:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:29:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:29:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:29:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:29:34 --> Final output sent to browser
DEBUG - 2011-08-24 17:29:34 --> Total execution time: 0.0337
DEBUG - 2011-08-24 17:29:35 --> Config Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:29:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:29:35 --> URI Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Router Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Output Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Input Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:29:35 --> Language Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Loader Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Controller Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Model Class Initialized
DEBUG - 2011-08-24 17:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:29:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:29:36 --> Final output sent to browser
DEBUG - 2011-08-24 17:29:36 --> Total execution time: 0.8784
DEBUG - 2011-08-24 17:29:37 --> Config Class Initialized
DEBUG - 2011-08-24 17:29:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:29:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:29:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:29:37 --> URI Class Initialized
DEBUG - 2011-08-24 17:29:37 --> Router Class Initialized
ERROR - 2011-08-24 17:29:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:29:38 --> Config Class Initialized
DEBUG - 2011-08-24 17:29:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:29:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:29:38 --> URI Class Initialized
DEBUG - 2011-08-24 17:29:38 --> Router Class Initialized
ERROR - 2011-08-24 17:29:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:30:06 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:06 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Router Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Output Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Input Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:30:06 --> Language Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Loader Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Controller Class Initialized
ERROR - 2011-08-24 17:30:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:30:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:30:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:30:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:30:06 --> Final output sent to browser
DEBUG - 2011-08-24 17:30:06 --> Total execution time: 0.1355
DEBUG - 2011-08-24 17:30:09 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:09 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Router Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Output Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Input Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:30:09 --> Language Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Loader Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Controller Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:30:09 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:30:10 --> Final output sent to browser
DEBUG - 2011-08-24 17:30:10 --> Total execution time: 1.2538
DEBUG - 2011-08-24 17:30:13 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:13 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:13 --> Router Class Initialized
ERROR - 2011-08-24 17:30:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:30:38 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:38 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Router Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Output Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Input Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:30:38 --> Language Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Loader Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Controller Class Initialized
ERROR - 2011-08-24 17:30:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:38 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:30:38 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:38 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:30:38 --> Final output sent to browser
DEBUG - 2011-08-24 17:30:38 --> Total execution time: 0.0284
DEBUG - 2011-08-24 17:30:39 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:39 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Router Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Output Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Input Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:30:39 --> Language Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Loader Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Controller Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Final output sent to browser
DEBUG - 2011-08-24 17:30:40 --> Total execution time: 1.3250
DEBUG - 2011-08-24 17:30:40 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:40 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Router Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Output Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Input Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:30:40 --> Language Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Loader Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Controller Class Initialized
ERROR - 2011-08-24 17:30:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:30:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:40 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Model Class Initialized
DEBUG - 2011-08-24 17:30:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:30:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:30:40 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:30:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:30:40 --> Final output sent to browser
DEBUG - 2011-08-24 17:30:40 --> Total execution time: 0.0284
DEBUG - 2011-08-24 17:30:41 --> Config Class Initialized
DEBUG - 2011-08-24 17:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:30:41 --> URI Class Initialized
DEBUG - 2011-08-24 17:30:41 --> Router Class Initialized
ERROR - 2011-08-24 17:30:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:33:10 --> Config Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:33:10 --> URI Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Router Class Initialized
DEBUG - 2011-08-24 17:33:10 --> No URI present. Default controller set.
DEBUG - 2011-08-24 17:33:10 --> Output Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Input Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:33:10 --> Language Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Loader Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Controller Class Initialized
DEBUG - 2011-08-24 17:33:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 17:33:10 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:33:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:33:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:33:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:33:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:33:10 --> Final output sent to browser
DEBUG - 2011-08-24 17:33:10 --> Total execution time: 0.0161
DEBUG - 2011-08-24 17:33:10 --> Config Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:33:10 --> URI Class Initialized
DEBUG - 2011-08-24 17:33:10 --> Router Class Initialized
ERROR - 2011-08-24 17:33:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:35:06 --> Config Class Initialized
DEBUG - 2011-08-24 17:35:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:35:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:35:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:35:06 --> URI Class Initialized
DEBUG - 2011-08-24 17:35:06 --> Router Class Initialized
ERROR - 2011-08-24 17:35:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 17:51:07 --> Config Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:51:07 --> URI Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Router Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Output Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Input Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:51:07 --> Language Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Loader Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Controller Class Initialized
ERROR - 2011-08-24 17:51:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:51:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:51:07 --> Model Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Model Class Initialized
DEBUG - 2011-08-24 17:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:51:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:51:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:51:07 --> Final output sent to browser
DEBUG - 2011-08-24 17:51:07 --> Total execution time: 0.0324
DEBUG - 2011-08-24 17:51:08 --> Config Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:51:08 --> URI Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Router Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Output Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Input Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:51:08 --> Language Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Loader Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Controller Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Model Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Model Class Initialized
DEBUG - 2011-08-24 17:51:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:51:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:51:09 --> Final output sent to browser
DEBUG - 2011-08-24 17:51:09 --> Total execution time: 0.8934
DEBUG - 2011-08-24 17:51:10 --> Config Class Initialized
DEBUG - 2011-08-24 17:51:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:51:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:51:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:51:10 --> URI Class Initialized
DEBUG - 2011-08-24 17:51:10 --> Router Class Initialized
ERROR - 2011-08-24 17:51:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:52:06 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:06 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:06 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Controller Class Initialized
ERROR - 2011-08-24 17:52:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:52:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:52:06 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:06 --> Total execution time: 0.0280
DEBUG - 2011-08-24 17:52:06 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:06 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:06 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Controller Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:07 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:07 --> Total execution time: 0.8207
DEBUG - 2011-08-24 17:52:08 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:08 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:08 --> Router Class Initialized
ERROR - 2011-08-24 17:52:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:52:29 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:29 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:29 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Controller Class Initialized
ERROR - 2011-08-24 17:52:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:52:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:29 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:52:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:52:29 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:29 --> Total execution time: 0.0273
DEBUG - 2011-08-24 17:52:30 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:30 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:30 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Controller Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:31 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:31 --> Total execution time: 0.8283
DEBUG - 2011-08-24 17:52:32 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:32 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:32 --> Router Class Initialized
ERROR - 2011-08-24 17:52:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:52:50 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:50 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:50 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Controller Class Initialized
ERROR - 2011-08-24 17:52:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:52:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:52:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:52:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:52:50 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:50 --> Total execution time: 0.0300
DEBUG - 2011-08-24 17:52:51 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:51 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Router Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Output Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Input Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:52:51 --> Language Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Loader Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Controller Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Model Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:52:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:52:51 --> Final output sent to browser
DEBUG - 2011-08-24 17:52:51 --> Total execution time: 0.9039
DEBUG - 2011-08-24 17:52:52 --> Config Class Initialized
DEBUG - 2011-08-24 17:52:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:52:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:52:52 --> URI Class Initialized
DEBUG - 2011-08-24 17:52:52 --> Router Class Initialized
ERROR - 2011-08-24 17:52:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:53:19 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:19 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:19 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Controller Class Initialized
ERROR - 2011-08-24 17:53:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:53:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:19 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:19 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:19 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:53:19 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:19 --> Total execution time: 0.0285
DEBUG - 2011-08-24 17:53:20 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:20 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:20 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Controller Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:21 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:21 --> Total execution time: 0.7462
DEBUG - 2011-08-24 17:53:21 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:21 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:21 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:21 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:21 --> Router Class Initialized
ERROR - 2011-08-24 17:53:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:53:24 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:24 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:24 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Controller Class Initialized
ERROR - 2011-08-24 17:53:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:53:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:24 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:53:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:53:24 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:24 --> Total execution time: 0.0270
DEBUG - 2011-08-24 17:53:25 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:25 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:25 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Controller Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:25 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:26 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:26 --> Total execution time: 0.9006
DEBUG - 2011-08-24 17:53:27 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:27 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:27 --> Router Class Initialized
ERROR - 2011-08-24 17:53:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:53:39 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:39 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:39 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Controller Class Initialized
ERROR - 2011-08-24 17:53:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:53:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:39 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:39 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:39 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:53:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:53:39 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:39 --> Total execution time: 0.0276
DEBUG - 2011-08-24 17:53:40 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:40 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:40 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Controller Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:40 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:40 --> Total execution time: 0.8847
DEBUG - 2011-08-24 17:53:41 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:41 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:41 --> Router Class Initialized
ERROR - 2011-08-24 17:53:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:53:50 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:50 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:50 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Controller Class Initialized
ERROR - 2011-08-24 17:53:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:53:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:50 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:53:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:53:50 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:50 --> Total execution time: 0.0310
DEBUG - 2011-08-24 17:53:50 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:50 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:50 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Controller Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:50 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:51 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:51 --> Total execution time: 0.9741
DEBUG - 2011-08-24 17:53:52 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:52 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:52 --> Router Class Initialized
ERROR - 2011-08-24 17:53:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:53:59 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:59 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:59 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Controller Class Initialized
ERROR - 2011-08-24 17:53:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:53:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:53:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:53:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:53:59 --> Final output sent to browser
DEBUG - 2011-08-24 17:53:59 --> Total execution time: 0.0287
DEBUG - 2011-08-24 17:53:59 --> Config Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:53:59 --> URI Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Router Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Output Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Input Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:53:59 --> Language Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Loader Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Controller Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Model Class Initialized
DEBUG - 2011-08-24 17:53:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:53:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:54:00 --> Final output sent to browser
DEBUG - 2011-08-24 17:54:00 --> Total execution time: 0.8032
DEBUG - 2011-08-24 17:54:01 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:01 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:01 --> Router Class Initialized
ERROR - 2011-08-24 17:54:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:54:05 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:05 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Router Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Output Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Input Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:54:05 --> Language Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Loader Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Controller Class Initialized
ERROR - 2011-08-24 17:54:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:54:05 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:54:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:54:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:54:05 --> Final output sent to browser
DEBUG - 2011-08-24 17:54:05 --> Total execution time: 0.0693
DEBUG - 2011-08-24 17:54:05 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:05 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Router Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Output Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Input Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:54:05 --> Language Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Loader Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Controller Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:54:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:54:06 --> Final output sent to browser
DEBUG - 2011-08-24 17:54:06 --> Total execution time: 0.8483
DEBUG - 2011-08-24 17:54:07 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:07 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:07 --> Router Class Initialized
ERROR - 2011-08-24 17:54:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 17:54:10 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:10 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Router Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Output Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Input Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:54:10 --> Language Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Loader Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Controller Class Initialized
ERROR - 2011-08-24 17:54:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 17:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:54:10 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:54:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 17:54:10 --> Helper loaded: url_helper
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 17:54:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 17:54:10 --> Final output sent to browser
DEBUG - 2011-08-24 17:54:10 --> Total execution time: 0.0375
DEBUG - 2011-08-24 17:54:11 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:11 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Router Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Output Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Input Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 17:54:11 --> Language Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Loader Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Controller Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Model Class Initialized
DEBUG - 2011-08-24 17:54:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 17:54:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 17:54:12 --> Final output sent to browser
DEBUG - 2011-08-24 17:54:12 --> Total execution time: 0.9026
DEBUG - 2011-08-24 17:54:12 --> Config Class Initialized
DEBUG - 2011-08-24 17:54:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 17:54:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 17:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 17:54:12 --> URI Class Initialized
DEBUG - 2011-08-24 17:54:12 --> Router Class Initialized
ERROR - 2011-08-24 17:54:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:19:34 --> Config Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:19:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:19:34 --> URI Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Router Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Output Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Input Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:19:34 --> Language Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Loader Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Controller Class Initialized
ERROR - 2011-08-24 18:19:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 18:19:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 18:19:34 --> Model Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Model Class Initialized
DEBUG - 2011-08-24 18:19:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:19:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 18:19:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:19:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:19:34 --> Final output sent to browser
DEBUG - 2011-08-24 18:19:34 --> Total execution time: 0.0351
DEBUG - 2011-08-24 18:20:36 --> Config Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:20:36 --> URI Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Router Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Output Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Input Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:20:36 --> Language Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Loader Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Controller Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Model Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Model Class Initialized
DEBUG - 2011-08-24 18:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:20:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:20:37 --> Final output sent to browser
DEBUG - 2011-08-24 18:20:37 --> Total execution time: 0.9595
DEBUG - 2011-08-24 18:20:40 --> Config Class Initialized
DEBUG - 2011-08-24 18:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:20:40 --> URI Class Initialized
DEBUG - 2011-08-24 18:20:40 --> Router Class Initialized
ERROR - 2011-08-24 18:20:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:21:32 --> Config Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:21:32 --> URI Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Router Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Output Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Input Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:21:32 --> Language Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Loader Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Controller Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Model Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Model Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Model Class Initialized
DEBUG - 2011-08-24 18:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:21:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:21:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:21:32 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:21:32 --> Final output sent to browser
DEBUG - 2011-08-24 18:21:32 --> Total execution time: 0.2079
DEBUG - 2011-08-24 18:27:12 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:12 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:12 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:12 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:12 --> Total execution time: 0.0581
DEBUG - 2011-08-24 18:27:15 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:15 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Router Class Initialized
ERROR - 2011-08-24 18:27:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:27:15 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:15 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:15 --> Router Class Initialized
ERROR - 2011-08-24 18:27:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:27:27 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:27 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:27 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:27 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:27 --> Total execution time: 0.1633
DEBUG - 2011-08-24 18:27:30 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:30 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:30 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:30 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:30 --> Total execution time: 0.0452
DEBUG - 2011-08-24 18:27:37 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:37 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:37 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:37 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:37 --> Total execution time: 0.2572
DEBUG - 2011-08-24 18:27:48 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:48 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:48 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:48 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:48 --> Total execution time: 0.2280
DEBUG - 2011-08-24 18:27:56 --> Config Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:27:56 --> URI Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Router Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Output Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Input Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:27:56 --> Language Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Loader Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Controller Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Model Class Initialized
DEBUG - 2011-08-24 18:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:27:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:27:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:27:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:27:56 --> Final output sent to browser
DEBUG - 2011-08-24 18:27:56 --> Total execution time: 0.2490
DEBUG - 2011-08-24 18:28:04 --> Config Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:28:04 --> URI Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Router Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Output Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Input Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:28:04 --> Language Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Loader Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Controller Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Model Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Model Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Model Class Initialized
DEBUG - 2011-08-24 18:28:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:28:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:28:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:28:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:28:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:28:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:28:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:28:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:28:04 --> Final output sent to browser
DEBUG - 2011-08-24 18:28:04 --> Total execution time: 0.2303
DEBUG - 2011-08-24 18:39:41 --> Config Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:39:41 --> URI Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Router Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Output Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Input Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:39:41 --> Language Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Loader Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Controller Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:39:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:39:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:39:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:39:41 --> Final output sent to browser
DEBUG - 2011-08-24 18:39:41 --> Total execution time: 0.0462
DEBUG - 2011-08-24 18:39:44 --> Config Class Initialized
DEBUG - 2011-08-24 18:39:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:39:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:39:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:39:44 --> URI Class Initialized
DEBUG - 2011-08-24 18:39:44 --> Router Class Initialized
ERROR - 2011-08-24 18:39:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:39:51 --> Config Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:39:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:39:51 --> URI Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Router Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Output Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Input Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:39:51 --> Language Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Loader Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Controller Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:39:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:39:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:39:51 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:39:51 --> Final output sent to browser
DEBUG - 2011-08-24 18:39:51 --> Total execution time: 0.2293
DEBUG - 2011-08-24 18:39:52 --> Config Class Initialized
DEBUG - 2011-08-24 18:39:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:39:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:39:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:39:52 --> URI Class Initialized
DEBUG - 2011-08-24 18:39:52 --> Router Class Initialized
ERROR - 2011-08-24 18:39:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:39:59 --> Config Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:39:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:39:59 --> URI Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Router Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Output Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Input Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:39:59 --> Language Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Loader Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Controller Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Model Class Initialized
DEBUG - 2011-08-24 18:39:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:39:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:39:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:39:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:39:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:39:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:39:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:39:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:39:59 --> Final output sent to browser
DEBUG - 2011-08-24 18:39:59 --> Total execution time: 0.0429
DEBUG - 2011-08-24 18:40:00 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:00 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:00 --> Router Class Initialized
ERROR - 2011-08-24 18:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:40:05 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:05 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Router Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Output Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Input Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:40:05 --> Language Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Loader Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Controller Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:40:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:40:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:40:05 --> Final output sent to browser
DEBUG - 2011-08-24 18:40:05 --> Total execution time: 0.1895
DEBUG - 2011-08-24 18:40:08 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:08 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:08 --> Router Class Initialized
ERROR - 2011-08-24 18:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:40:09 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:09 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:09 --> Router Class Initialized
ERROR - 2011-08-24 18:40:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:40:23 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:23 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Router Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Output Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Input Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:40:23 --> Language Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Loader Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Controller Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:40:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:40:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:40:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:40:23 --> Final output sent to browser
DEBUG - 2011-08-24 18:40:23 --> Total execution time: 0.0480
DEBUG - 2011-08-24 18:40:25 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:25 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:25 --> Router Class Initialized
ERROR - 2011-08-24 18:40:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:40:29 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:29 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Router Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Output Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Input Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:40:29 --> Language Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Loader Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Controller Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Model Class Initialized
DEBUG - 2011-08-24 18:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:40:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:40:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:40:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:40:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:40:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:40:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:40:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:40:29 --> Final output sent to browser
DEBUG - 2011-08-24 18:40:29 --> Total execution time: 0.0501
DEBUG - 2011-08-24 18:40:30 --> Config Class Initialized
DEBUG - 2011-08-24 18:40:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:40:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:40:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:40:30 --> URI Class Initialized
DEBUG - 2011-08-24 18:40:30 --> Router Class Initialized
ERROR - 2011-08-24 18:40:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:49:08 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:08 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:08 --> Router Class Initialized
ERROR - 2011-08-24 18:49:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:49:26 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:26 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Router Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Output Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Input Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:49:26 --> Language Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Loader Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Controller Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:49:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:49:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 18:49:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:49:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:49:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:49:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:49:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:49:26 --> Final output sent to browser
DEBUG - 2011-08-24 18:49:26 --> Total execution time: 0.0716
DEBUG - 2011-08-24 18:49:28 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:28 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:28 --> Router Class Initialized
ERROR - 2011-08-24 18:49:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:49:41 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:41 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Router Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Output Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Input Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:49:41 --> Language Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Loader Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Controller Class Initialized
ERROR - 2011-08-24 18:49:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 18:49:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 18:49:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:49:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 18:49:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 18:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 18:49:41 --> Final output sent to browser
DEBUG - 2011-08-24 18:49:41 --> Total execution time: 0.0280
DEBUG - 2011-08-24 18:49:41 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:41 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Router Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Output Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Input Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 18:49:41 --> Language Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Loader Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Controller Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Model Class Initialized
DEBUG - 2011-08-24 18:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 18:49:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 18:49:42 --> Final output sent to browser
DEBUG - 2011-08-24 18:49:42 --> Total execution time: 0.8725
DEBUG - 2011-08-24 18:49:43 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:43 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:43 --> Router Class Initialized
ERROR - 2011-08-24 18:49:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 18:49:45 --> Config Class Initialized
DEBUG - 2011-08-24 18:49:45 --> Hooks Class Initialized
DEBUG - 2011-08-24 18:49:45 --> Utf8 Class Initialized
DEBUG - 2011-08-24 18:49:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 18:49:45 --> URI Class Initialized
DEBUG - 2011-08-24 18:49:45 --> Router Class Initialized
ERROR - 2011-08-24 18:49:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:04:41 --> Config Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:04:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:04:41 --> URI Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Router Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Output Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Input Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:04:41 --> Language Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Loader Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Controller Class Initialized
ERROR - 2011-08-24 19:04:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:04:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:04:41 --> Model Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Model Class Initialized
DEBUG - 2011-08-24 19:04:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:04:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:04:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:04:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:04:41 --> Final output sent to browser
DEBUG - 2011-08-24 19:04:41 --> Total execution time: 0.0316
DEBUG - 2011-08-24 19:04:47 --> Config Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:04:47 --> URI Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Router Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Output Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Input Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:04:47 --> Language Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Loader Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Controller Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Model Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Model Class Initialized
DEBUG - 2011-08-24 19:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:04:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Config Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:09:49 --> URI Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Router Class Initialized
ERROR - 2011-08-24 19:09:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 19:09:49 --> Config Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:09:49 --> URI Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Router Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Output Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Input Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:09:49 --> Language Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Loader Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Controller Class Initialized
ERROR - 2011-08-24 19:09:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:09:49 --> Model Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Model Class Initialized
DEBUG - 2011-08-24 19:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:09:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:09:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:09:49 --> Final output sent to browser
DEBUG - 2011-08-24 19:09:49 --> Total execution time: 0.0317
DEBUG - 2011-08-24 19:39:12 --> Config Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:39:12 --> URI Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Router Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Output Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Input Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:39:12 --> Language Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Loader Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Controller Class Initialized
ERROR - 2011-08-24 19:39:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:39:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:39:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:39:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:39:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:39:12 --> Final output sent to browser
DEBUG - 2011-08-24 19:39:12 --> Total execution time: 0.0585
DEBUG - 2011-08-24 19:39:15 --> Config Class Initialized
DEBUG - 2011-08-24 19:39:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:39:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:39:15 --> URI Class Initialized
DEBUG - 2011-08-24 19:39:15 --> Router Class Initialized
ERROR - 2011-08-24 19:39:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:39:16 --> Config Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:39:16 --> URI Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Router Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Output Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Input Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:39:16 --> Language Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Loader Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Controller Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:39:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:39:17 --> Final output sent to browser
DEBUG - 2011-08-24 19:39:17 --> Total execution time: 1.0203
DEBUG - 2011-08-24 19:45:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:45:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:45:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Controller Class Initialized
ERROR - 2011-08-24 19:45:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:45:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:45:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:45:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:45:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:45:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:45:23 --> Final output sent to browser
DEBUG - 2011-08-24 19:45:23 --> Total execution time: 0.0312
DEBUG - 2011-08-24 19:45:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:45:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:45:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Controller Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:45:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:45:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:45:24 --> Final output sent to browser
DEBUG - 2011-08-24 19:45:24 --> Total execution time: 0.7644
DEBUG - 2011-08-24 19:45:25 --> Config Class Initialized
DEBUG - 2011-08-24 19:45:25 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:45:25 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:45:25 --> URI Class Initialized
DEBUG - 2011-08-24 19:45:25 --> Router Class Initialized
ERROR - 2011-08-24 19:45:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:46:12 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:12 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:12 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Controller Class Initialized
ERROR - 2011-08-24 19:46:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:46:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:46:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:46:12 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:12 --> Total execution time: 0.0267
DEBUG - 2011-08-24 19:46:13 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:13 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:13 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Controller Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:13 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:13 --> Total execution time: 0.7005
DEBUG - 2011-08-24 19:46:14 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:14 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Router Class Initialized
ERROR - 2011-08-24 19:46:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-24 19:46:14 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:14 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Router Class Initialized
ERROR - 2011-08-24 19:46:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:46:14 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:14 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:14 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Controller Class Initialized
ERROR - 2011-08-24 19:46:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:46:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:14 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:46:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:46:14 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:14 --> Total execution time: 0.0313
DEBUG - 2011-08-24 19:46:27 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:27 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:27 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Controller Class Initialized
ERROR - 2011-08-24 19:46:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:46:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:46:27 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:27 --> Total execution time: 0.0266
DEBUG - 2011-08-24 19:46:27 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:27 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:27 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Controller Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:28 --> Total execution time: 0.9330
DEBUG - 2011-08-24 19:46:28 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:28 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Router Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Output Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Input Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:46:28 --> Language Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Loader Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Controller Class Initialized
ERROR - 2011-08-24 19:46:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:46:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:28 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Model Class Initialized
DEBUG - 2011-08-24 19:46:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:46:28 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:46:28 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:46:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:46:28 --> Final output sent to browser
DEBUG - 2011-08-24 19:46:28 --> Total execution time: 0.0283
DEBUG - 2011-08-24 19:46:29 --> Config Class Initialized
DEBUG - 2011-08-24 19:46:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:46:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:46:29 --> URI Class Initialized
DEBUG - 2011-08-24 19:46:29 --> Router Class Initialized
ERROR - 2011-08-24 19:46:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:06 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:06 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:06 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:06 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:06 --> Total execution time: 0.0303
DEBUG - 2011-08-24 19:47:06 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:06 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:06 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:06 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:06 --> Total execution time: 0.0269
DEBUG - 2011-08-24 19:47:06 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:06 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:06 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:07 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:07 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:07 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:07 --> Total execution time: 0.9316
DEBUG - 2011-08-24 19:47:07 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:07 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:07 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:07 --> Total execution time: 0.0281
DEBUG - 2011-08-24 19:47:07 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:07 --> Total execution time: 0.7637
DEBUG - 2011-08-24 19:47:08 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:08 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Router Class Initialized
ERROR - 2011-08-24 19:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:08 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:08 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:08 --> Router Class Initialized
ERROR - 2011-08-24 19:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:14 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:14 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:14 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:14 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:14 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:14 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:14 --> Total execution time: 0.0297
DEBUG - 2011-08-24 19:47:15 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:15 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:15 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:15 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:15 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:15 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:16 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:16 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:16 --> Total execution time: 0.0278
DEBUG - 2011-08-24 19:47:16 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:16 --> Total execution time: 0.8334
DEBUG - 2011-08-24 19:47:17 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:17 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Router Class Initialized
ERROR - 2011-08-24 19:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:17 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:17 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:17 --> Router Class Initialized
ERROR - 2011-08-24 19:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:23 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:23 --> Total execution time: 0.0308
DEBUG - 2011-08-24 19:47:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:23 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:23 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:23 --> Total execution time: 0.0285
DEBUG - 2011-08-24 19:47:24 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:24 --> Total execution time: 0.8245
DEBUG - 2011-08-24 19:47:26 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:26 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:26 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:26 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:26 --> Total execution time: 0.0271
DEBUG - 2011-08-24 19:47:26 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:26 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:26 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:27 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:27 --> Total execution time: 0.8221
DEBUG - 2011-08-24 19:47:27 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:27 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:27 --> Router Class Initialized
ERROR - 2011-08-24 19:47:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:28 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:28 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:28 --> Router Class Initialized
ERROR - 2011-08-24 19:47:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:36 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:36 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:36 --> Router Class Initialized
ERROR - 2011-08-24 19:47:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:47:39 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:39 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:39 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Controller Class Initialized
ERROR - 2011-08-24 19:47:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:47:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:39 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:39 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:47:39 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:47:39 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:39 --> Total execution time: 0.0296
DEBUG - 2011-08-24 19:47:40 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:40 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Router Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Output Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Input Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:47:40 --> Language Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Loader Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Controller Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Model Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:47:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:47:40 --> Final output sent to browser
DEBUG - 2011-08-24 19:47:40 --> Total execution time: 0.9469
DEBUG - 2011-08-24 19:47:41 --> Config Class Initialized
DEBUG - 2011-08-24 19:47:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:47:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:47:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:47:41 --> URI Class Initialized
DEBUG - 2011-08-24 19:47:41 --> Router Class Initialized
ERROR - 2011-08-24 19:47:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:06 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:06 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:06 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:06 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:06 --> Total execution time: 0.0274
DEBUG - 2011-08-24 19:48:07 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:07 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:07 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:07 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:07 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:07 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:07 --> Total execution time: 0.0298
DEBUG - 2011-08-24 19:48:08 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:08 --> Total execution time: 0.8178
DEBUG - 2011-08-24 19:48:09 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:09 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:09 --> Router Class Initialized
ERROR - 2011-08-24 19:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:16 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:16 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:16 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:16 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:16 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:16 --> Total execution time: 0.0561
DEBUG - 2011-08-24 19:48:16 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:16 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:16 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:16 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:16 --> Total execution time: 0.6341
DEBUG - 2011-08-24 19:48:17 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:17 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:17 --> Router Class Initialized
ERROR - 2011-08-24 19:48:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:29 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:29 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:29 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:29 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:29 --> Total execution time: 0.0285
DEBUG - 2011-08-24 19:48:30 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:30 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:30 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:30 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:30 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:30 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:30 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:30 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:30 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:30 --> Total execution time: 0.0284
DEBUG - 2011-08-24 19:48:30 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:30 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:30 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:30 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:31 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:31 --> Total execution time: 0.9230
DEBUG - 2011-08-24 19:48:31 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:31 --> Total execution time: 0.9016
DEBUG - 2011-08-24 19:48:31 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:31 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:31 --> Router Class Initialized
ERROR - 2011-08-24 19:48:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:32 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:32 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:32 --> Router Class Initialized
ERROR - 2011-08-24 19:48:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:33 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:33 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:33 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:33 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:33 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:33 --> Total execution time: 0.1177
DEBUG - 2011-08-24 19:48:33 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:33 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:33 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:33 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:34 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:34 --> Total execution time: 0.0801
DEBUG - 2011-08-24 19:48:37 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:37 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:37 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:37 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:37 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:37 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:37 --> Total execution time: 0.0709
DEBUG - 2011-08-24 19:48:37 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:37 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:37 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:37 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:38 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:38 --> Total execution time: 1.0546
DEBUG - 2011-08-24 19:48:39 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:39 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:39 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:39 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:39 --> Router Class Initialized
ERROR - 2011-08-24 19:48:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:40 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:40 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:40 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:40 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:40 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:40 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:40 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:40 --> Total execution time: 0.0552
DEBUG - 2011-08-24 19:48:41 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:41 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:41 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:41 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:42 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:42 --> Total execution time: 0.0792
DEBUG - 2011-08-24 19:48:42 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:42 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:42 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:42 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:42 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:42 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:42 --> Total execution time: 0.0579
DEBUG - 2011-08-24 19:48:42 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:42 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:42 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:42 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:42 --> Total execution time: 0.0365
DEBUG - 2011-08-24 19:48:43 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:43 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:43 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:43 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:43 --> Total execution time: 1.0984
DEBUG - 2011-08-24 19:48:44 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:44 --> Total execution time: 0.8855
DEBUG - 2011-08-24 19:48:44 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:44 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Router Class Initialized
ERROR - 2011-08-24 19:48:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:44 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:44 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:44 --> Router Class Initialized
ERROR - 2011-08-24 19:48:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:48 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:48 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:48 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:48 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:48 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:48 --> Total execution time: 0.0323
DEBUG - 2011-08-24 19:48:48 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:48 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:48 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:48 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:49 --> Total execution time: 0.9612
DEBUG - 2011-08-24 19:48:49 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:49 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Router Class Initialized
ERROR - 2011-08-24 19:48:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:48:49 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:49 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:49 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:49 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:49 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:49 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:49 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:49 --> Total execution time: 0.0292
DEBUG - 2011-08-24 19:48:54 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:54 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:54 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:54 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:54 --> Total execution time: 0.0339
DEBUG - 2011-08-24 19:48:54 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:54 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:54 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Controller Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:55 --> Total execution time: 1.0673
DEBUG - 2011-08-24 19:48:55 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:55 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Router Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Output Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Input Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:48:55 --> Language Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Loader Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Controller Class Initialized
ERROR - 2011-08-24 19:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:55 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Model Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:48:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:48:55 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:48:55 --> Final output sent to browser
DEBUG - 2011-08-24 19:48:55 --> Total execution time: 0.0628
DEBUG - 2011-08-24 19:48:55 --> Config Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:48:55 --> URI Class Initialized
DEBUG - 2011-08-24 19:48:55 --> Router Class Initialized
ERROR - 2011-08-24 19:48:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:49:01 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:01 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:01 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Controller Class Initialized
ERROR - 2011-08-24 19:49:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:49:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:01 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:01 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:49:01 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:01 --> Total execution time: 0.0275
DEBUG - 2011-08-24 19:49:02 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:02 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:02 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Controller Class Initialized
ERROR - 2011-08-24 19:49:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:49:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:02 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:49:02 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:02 --> Total execution time: 0.0289
DEBUG - 2011-08-24 19:49:02 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:02 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:02 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Controller Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:03 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:03 --> Total execution time: 0.7728
DEBUG - 2011-08-24 19:49:03 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:03 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:03 --> Router Class Initialized
ERROR - 2011-08-24 19:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:49:22 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:22 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:22 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Controller Class Initialized
ERROR - 2011-08-24 19:49:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:49:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:22 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:22 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:22 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:49:22 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:22 --> Total execution time: 0.0294
DEBUG - 2011-08-24 19:49:23 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:23 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:23 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Controller Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:23 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:24 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:24 --> Total execution time: 0.7306
DEBUG - 2011-08-24 19:49:24 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:24 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:24 --> Router Class Initialized
ERROR - 2011-08-24 19:49:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:49:29 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:29 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:29 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Controller Class Initialized
ERROR - 2011-08-24 19:49:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:49:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:49:29 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:29 --> Total execution time: 0.0277
DEBUG - 2011-08-24 19:49:29 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:29 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:29 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Controller Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:30 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:30 --> Total execution time: 0.8714
DEBUG - 2011-08-24 19:49:31 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:31 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:31 --> Router Class Initialized
ERROR - 2011-08-24 19:49:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:49:44 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:44 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:44 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Controller Class Initialized
ERROR - 2011-08-24 19:49:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:49:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:49:44 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:49:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:49:44 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:44 --> Total execution time: 0.0289
DEBUG - 2011-08-24 19:49:44 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:44 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Router Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Output Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Input Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:49:44 --> Language Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Loader Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Controller Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:49:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:49:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:49:45 --> Final output sent to browser
DEBUG - 2011-08-24 19:49:45 --> Total execution time: 0.7627
DEBUG - 2011-08-24 19:49:46 --> Config Class Initialized
DEBUG - 2011-08-24 19:49:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:49:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:49:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:49:46 --> URI Class Initialized
DEBUG - 2011-08-24 19:49:46 --> Router Class Initialized
ERROR - 2011-08-24 19:49:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:50:00 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:00 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:00 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:00 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:00 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:00 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:00 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:00 --> Total execution time: 0.0270
DEBUG - 2011-08-24 19:50:26 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:26 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:26 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:26 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:26 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:26 --> Total execution time: 0.0782
DEBUG - 2011-08-24 19:50:27 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:27 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:27 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Controller Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:27 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:27 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:27 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:27 --> Total execution time: 0.0324
DEBUG - 2011-08-24 19:50:28 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:28 --> Total execution time: 0.7465
DEBUG - 2011-08-24 19:50:28 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:28 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:28 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:28 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:28 --> Router Class Initialized
ERROR - 2011-08-24 19:50:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:50:35 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:35 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:35 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:35 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:35 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:35 --> Total execution time: 0.0309
DEBUG - 2011-08-24 19:50:35 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:35 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:35 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Controller Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:36 --> Total execution time: 0.7546
DEBUG - 2011-08-24 19:50:36 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:36 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:36 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:36 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:36 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:36 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:36 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:36 --> Total execution time: 0.0298
DEBUG - 2011-08-24 19:50:37 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:37 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:37 --> Router Class Initialized
ERROR - 2011-08-24 19:50:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:50:43 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:43 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:43 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:43 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:43 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:43 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:43 --> Total execution time: 0.0597
DEBUG - 2011-08-24 19:50:44 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:44 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:44 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Controller Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:45 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:45 --> Total execution time: 0.7611
DEBUG - 2011-08-24 19:50:46 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:46 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:46 --> Router Class Initialized
ERROR - 2011-08-24 19:50:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:50:54 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:54 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:54 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:54 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:54 --> Total execution time: 0.0736
DEBUG - 2011-08-24 19:50:55 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:55 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:55 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Controller Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:56 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Router Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Output Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Input Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:50:56 --> Language Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Loader Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Controller Class Initialized
ERROR - 2011-08-24 19:50:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:50:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:56 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Model Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:50:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:50:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:50:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:50:56 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:56 --> Total execution time: 0.0295
DEBUG - 2011-08-24 19:50:56 --> Final output sent to browser
DEBUG - 2011-08-24 19:50:56 --> Total execution time: 1.0495
DEBUG - 2011-08-24 19:50:56 --> Config Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:50:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:50:56 --> URI Class Initialized
DEBUG - 2011-08-24 19:50:56 --> Router Class Initialized
ERROR - 2011-08-24 19:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:51:04 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:04 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:04 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Controller Class Initialized
ERROR - 2011-08-24 19:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:51:04 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:04 --> Total execution time: 0.0301
DEBUG - 2011-08-24 19:51:04 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:04 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:04 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Controller Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:04 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:04 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Controller Class Initialized
ERROR - 2011-08-24 19:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:04 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:04 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:51:04 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:04 --> Total execution time: 0.0283
DEBUG - 2011-08-24 19:51:05 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:05 --> Total execution time: 0.7788
DEBUG - 2011-08-24 19:51:05 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:05 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:05 --> Router Class Initialized
ERROR - 2011-08-24 19:51:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:51:11 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:11 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:11 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Controller Class Initialized
ERROR - 2011-08-24 19:51:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:51:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:11 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:51:11 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:11 --> Total execution time: 0.0353
DEBUG - 2011-08-24 19:51:12 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:12 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:12 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Controller Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:12 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:12 --> Total execution time: 0.9241
DEBUG - 2011-08-24 19:51:13 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:13 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:13 --> Router Class Initialized
ERROR - 2011-08-24 19:51:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:51:34 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:34 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:34 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Controller Class Initialized
ERROR - 2011-08-24 19:51:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:51:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:34 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:51:34 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:34 --> Total execution time: 0.0584
DEBUG - 2011-08-24 19:51:34 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:34 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:34 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Controller Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:35 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:35 --> Total execution time: 0.8260
DEBUG - 2011-08-24 19:51:36 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:36 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:36 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:36 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:36 --> Router Class Initialized
ERROR - 2011-08-24 19:51:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:51:51 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:51 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:51 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Controller Class Initialized
ERROR - 2011-08-24 19:51:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:51 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:51:51 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:51:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:51:51 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:51 --> Total execution time: 0.0354
DEBUG - 2011-08-24 19:51:51 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:51 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Router Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Output Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Input Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:51:51 --> Language Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Loader Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Controller Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Model Class Initialized
DEBUG - 2011-08-24 19:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:51:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:51:52 --> Final output sent to browser
DEBUG - 2011-08-24 19:51:52 --> Total execution time: 0.8622
DEBUG - 2011-08-24 19:51:54 --> Config Class Initialized
DEBUG - 2011-08-24 19:51:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:51:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:51:54 --> URI Class Initialized
DEBUG - 2011-08-24 19:51:54 --> Router Class Initialized
ERROR - 2011-08-24 19:51:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:52:01 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:01 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Router Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Output Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Input Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:52:01 --> Language Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Loader Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Controller Class Initialized
ERROR - 2011-08-24 19:52:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:52:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:52:01 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:52:01 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:52:01 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:52:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:52:01 --> Final output sent to browser
DEBUG - 2011-08-24 19:52:01 --> Total execution time: 0.0291
DEBUG - 2011-08-24 19:52:02 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:02 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Router Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Output Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Input Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:52:02 --> Language Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Loader Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Controller Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:52:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:52:03 --> Final output sent to browser
DEBUG - 2011-08-24 19:52:03 --> Total execution time: 0.8253
DEBUG - 2011-08-24 19:52:04 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:04 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:04 --> Router Class Initialized
ERROR - 2011-08-24 19:52:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:52:07 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:07 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Router Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Output Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Input Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:52:07 --> Language Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Loader Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Controller Class Initialized
ERROR - 2011-08-24 19:52:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:52:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:52:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:52:07 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:52:07 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:52:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:52:07 --> Final output sent to browser
DEBUG - 2011-08-24 19:52:07 --> Total execution time: 0.0280
DEBUG - 2011-08-24 19:52:08 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:08 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Router Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Output Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Input Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:52:08 --> Language Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Loader Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Controller Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Model Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:52:08 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:52:08 --> Final output sent to browser
DEBUG - 2011-08-24 19:52:08 --> Total execution time: 0.8175
DEBUG - 2011-08-24 19:52:09 --> Config Class Initialized
DEBUG - 2011-08-24 19:52:09 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:52:09 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:52:09 --> URI Class Initialized
DEBUG - 2011-08-24 19:52:09 --> Router Class Initialized
ERROR - 2011-08-24 19:52:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 19:58:46 --> Config Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:58:46 --> URI Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Router Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Output Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Input Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:58:46 --> Language Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Loader Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Controller Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Model Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Model Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Model Class Initialized
DEBUG - 2011-08-24 19:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:58:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:58:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 19:58:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:58:46 --> Final output sent to browser
DEBUG - 2011-08-24 19:58:46 --> Total execution time: 0.2377
DEBUG - 2011-08-24 19:58:47 --> Config Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 19:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 19:58:47 --> URI Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Router Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Output Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Input Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 19:58:47 --> Language Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Loader Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Controller Class Initialized
ERROR - 2011-08-24 19:58:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 19:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:58:47 --> Model Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Model Class Initialized
DEBUG - 2011-08-24 19:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 19:58:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 19:58:47 --> Helper loaded: url_helper
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 19:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 19:58:47 --> Final output sent to browser
DEBUG - 2011-08-24 19:58:47 --> Total execution time: 0.0292
DEBUG - 2011-08-24 20:00:18 --> Config Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 20:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 20:00:18 --> URI Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Router Class Initialized
DEBUG - 2011-08-24 20:00:18 --> No URI present. Default controller set.
DEBUG - 2011-08-24 20:00:18 --> Output Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Input Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 20:00:18 --> Language Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Loader Class Initialized
DEBUG - 2011-08-24 20:00:18 --> Controller Class Initialized
DEBUG - 2011-08-24 20:00:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-24 20:00:18 --> Helper loaded: url_helper
DEBUG - 2011-08-24 20:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 20:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 20:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 20:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 20:00:18 --> Final output sent to browser
DEBUG - 2011-08-24 20:00:18 --> Total execution time: 0.0780
DEBUG - 2011-08-24 21:32:54 --> Config Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 21:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 21:32:54 --> URI Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Router Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Output Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Input Class Initialized
DEBUG - 2011-08-24 21:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 21:32:54 --> Language Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Loader Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Controller Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Model Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Model Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Model Class Initialized
DEBUG - 2011-08-24 21:32:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 21:32:55 --> Database Driver Class Initialized
DEBUG - 2011-08-24 21:32:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 21:32:55 --> Helper loaded: url_helper
DEBUG - 2011-08-24 21:32:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 21:32:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 21:32:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 21:32:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 21:32:55 --> Final output sent to browser
DEBUG - 2011-08-24 21:32:55 --> Total execution time: 0.2581
DEBUG - 2011-08-24 21:50:06 --> Config Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Hooks Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Utf8 Class Initialized
DEBUG - 2011-08-24 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 21:50:06 --> URI Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Router Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Output Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Input Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 21:50:06 --> Language Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Loader Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Controller Class Initialized
ERROR - 2011-08-24 21:50:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 21:50:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 21:50:06 --> Model Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Model Class Initialized
DEBUG - 2011-08-24 21:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 21:50:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 21:50:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 21:50:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 21:50:06 --> Final output sent to browser
DEBUG - 2011-08-24 21:50:06 --> Total execution time: 0.0303
DEBUG - 2011-08-24 21:50:10 --> Config Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Hooks Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Utf8 Class Initialized
DEBUG - 2011-08-24 21:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 21:50:10 --> URI Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Router Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Output Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Input Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 21:50:10 --> Language Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Loader Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Controller Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Model Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Model Class Initialized
DEBUG - 2011-08-24 21:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 21:50:10 --> Database Driver Class Initialized
DEBUG - 2011-08-24 21:50:11 --> Final output sent to browser
DEBUG - 2011-08-24 21:50:11 --> Total execution time: 0.7299
DEBUG - 2011-08-24 21:50:12 --> Config Class Initialized
DEBUG - 2011-08-24 21:50:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 21:50:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 21:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 21:50:12 --> URI Class Initialized
DEBUG - 2011-08-24 21:50:12 --> Router Class Initialized
ERROR - 2011-08-24 21:50:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 21:50:13 --> Config Class Initialized
DEBUG - 2011-08-24 21:50:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 21:50:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 21:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 21:50:13 --> URI Class Initialized
DEBUG - 2011-08-24 21:50:13 --> Router Class Initialized
ERROR - 2011-08-24 21:50:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 22:22:35 --> Config Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:22:35 --> URI Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Router Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Output Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Input Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:22:35 --> Language Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Loader Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Controller Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:22:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:22:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:22:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:22:35 --> Final output sent to browser
DEBUG - 2011-08-24 22:22:35 --> Total execution time: 0.2586
DEBUG - 2011-08-24 22:22:38 --> Config Class Initialized
DEBUG - 2011-08-24 22:22:38 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:22:38 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:22:38 --> URI Class Initialized
DEBUG - 2011-08-24 22:22:38 --> Router Class Initialized
ERROR - 2011-08-24 22:22:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 22:22:54 --> Config Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:22:54 --> URI Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Router Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Output Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Input Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:22:54 --> Language Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Loader Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Controller Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Model Class Initialized
DEBUG - 2011-08-24 22:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:22:54 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:22:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:22:54 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:22:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:22:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:22:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:22:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:22:54 --> Final output sent to browser
DEBUG - 2011-08-24 22:22:54 --> Total execution time: 0.2201
DEBUG - 2011-08-24 22:23:12 --> Config Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:23:12 --> URI Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Router Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Output Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Input Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:23:12 --> Language Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Loader Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Controller Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:23:12 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:23:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:23:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:23:12 --> Final output sent to browser
DEBUG - 2011-08-24 22:23:12 --> Total execution time: 0.2448
DEBUG - 2011-08-24 22:23:31 --> Config Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:23:31 --> URI Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Router Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Output Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Input Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:23:31 --> Language Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Loader Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Controller Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:23:31 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:23:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:23:31 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:23:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:23:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:23:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:23:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:23:31 --> Final output sent to browser
DEBUG - 2011-08-24 22:23:31 --> Total execution time: 0.3034
DEBUG - 2011-08-24 22:23:51 --> Config Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:23:51 --> URI Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Router Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Output Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Input Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:23:51 --> Language Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Loader Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Controller Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:23:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:23:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:23:52 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:23:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:23:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:23:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:23:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:23:52 --> Final output sent to browser
DEBUG - 2011-08-24 22:23:52 --> Total execution time: 0.2315
DEBUG - 2011-08-24 22:24:05 --> Config Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:24:05 --> URI Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Router Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Output Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Input Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:24:05 --> Language Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Loader Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Controller Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:24:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:24:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:24:05 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:24:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:24:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:24:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:24:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:24:05 --> Final output sent to browser
DEBUG - 2011-08-24 22:24:05 --> Total execution time: 0.2802
DEBUG - 2011-08-24 22:24:15 --> Config Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:24:15 --> URI Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Router Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Output Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Input Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:24:15 --> Language Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Loader Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Controller Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:24:15 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:24:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:24:15 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:24:15 --> Final output sent to browser
DEBUG - 2011-08-24 22:24:15 --> Total execution time: 0.2516
DEBUG - 2011-08-24 22:24:29 --> Config Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:24:29 --> URI Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Router Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Output Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Input Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:24:29 --> Language Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Loader Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Controller Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:24:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:24:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:24:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:24:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:24:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:24:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:24:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:24:29 --> Final output sent to browser
DEBUG - 2011-08-24 22:24:29 --> Total execution time: 0.2144
DEBUG - 2011-08-24 22:24:41 --> Config Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:24:41 --> URI Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Router Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Output Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Input Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:24:41 --> Language Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Loader Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Controller Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:24:41 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:24:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:24:41 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:24:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:24:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:24:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:24:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:24:41 --> Final output sent to browser
DEBUG - 2011-08-24 22:24:41 --> Total execution time: 0.1978
DEBUG - 2011-08-24 22:24:52 --> Config Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:24:52 --> URI Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Router Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Output Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Input Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:24:52 --> Language Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Loader Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Controller Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Model Class Initialized
DEBUG - 2011-08-24 22:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:24:52 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:24:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:24:52 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:24:52 --> Final output sent to browser
DEBUG - 2011-08-24 22:24:52 --> Total execution time: 0.2972
DEBUG - 2011-08-24 22:25:02 --> Config Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:25:02 --> URI Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Router Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Output Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Input Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:25:02 --> Language Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Loader Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Controller Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:25:02 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:25:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:25:03 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:25:03 --> Final output sent to browser
DEBUG - 2011-08-24 22:25:03 --> Total execution time: 0.9012
DEBUG - 2011-08-24 22:25:11 --> Config Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:25:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:25:11 --> URI Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Router Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Output Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Input Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:25:11 --> Language Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Loader Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Controller Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:25:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:25:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:25:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:25:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:25:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:25:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:25:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:25:11 --> Final output sent to browser
DEBUG - 2011-08-24 22:25:11 --> Total execution time: 0.2432
DEBUG - 2011-08-24 22:25:34 --> Config Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:25:34 --> URI Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Router Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Output Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Input Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:25:34 --> Language Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Loader Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Controller Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:25:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:25:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:25:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:25:34 --> Final output sent to browser
DEBUG - 2011-08-24 22:25:34 --> Total execution time: 0.2036
DEBUG - 2011-08-24 22:25:43 --> Config Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:25:43 --> URI Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Router Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Output Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Input Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:25:43 --> Language Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Loader Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Controller Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:25:43 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:25:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:25:44 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:25:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:25:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:25:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:25:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:25:44 --> Final output sent to browser
DEBUG - 2011-08-24 22:25:44 --> Total execution time: 0.1971
DEBUG - 2011-08-24 22:25:59 --> Config Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:25:59 --> URI Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Router Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Output Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Input Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:25:59 --> Language Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Loader Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Controller Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:25:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:25:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:25:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:25:59 --> Final output sent to browser
DEBUG - 2011-08-24 22:25:59 --> Total execution time: 0.1913
DEBUG - 2011-08-24 22:26:24 --> Config Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:26:24 --> URI Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Router Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Output Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Input Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:26:24 --> Language Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Loader Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Controller Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:26:24 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:26:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:26:24 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:26:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:26:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:26:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:26:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:26:24 --> Final output sent to browser
DEBUG - 2011-08-24 22:26:24 --> Total execution time: 0.2422
DEBUG - 2011-08-24 22:26:32 --> Config Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:26:32 --> URI Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Router Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Output Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Input Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:26:32 --> Language Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Loader Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Controller Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:26:32 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:26:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:26:33 --> Final output sent to browser
DEBUG - 2011-08-24 22:26:33 --> Total execution time: 0.2161
DEBUG - 2011-08-24 22:26:44 --> Config Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:26:44 --> URI Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Router Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Output Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Input Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:26:44 --> Language Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Loader Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Controller Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Model Class Initialized
DEBUG - 2011-08-24 22:26:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:26:44 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:26:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:26:44 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:26:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:26:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:26:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:26:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:26:44 --> Final output sent to browser
DEBUG - 2011-08-24 22:26:44 --> Total execution time: 0.0447
DEBUG - 2011-08-24 22:44:11 --> Config Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:44:11 --> URI Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Router Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Output Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Input Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:44:11 --> Language Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Loader Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Controller Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:44:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:44:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:44:11 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:44:11 --> Final output sent to browser
DEBUG - 2011-08-24 22:44:11 --> Total execution time: 0.1242
DEBUG - 2011-08-24 22:44:13 --> Config Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:44:13 --> URI Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Router Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Output Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Input Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:44:13 --> Language Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Loader Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Controller Class Initialized
ERROR - 2011-08-24 22:44:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 22:44:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 22:44:13 --> Model Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Model Class Initialized
DEBUG - 2011-08-24 22:44:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:44:13 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 22:44:13 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:44:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:44:13 --> Final output sent to browser
DEBUG - 2011-08-24 22:44:13 --> Total execution time: 0.0317
DEBUG - 2011-08-24 22:54:03 --> Config Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:54:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:54:03 --> URI Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Router Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Output Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Input Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:54:03 --> Language Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Loader Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Controller Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:54:03 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:54:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:54:03 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:54:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:54:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:54:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:54:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:54:03 --> Final output sent to browser
DEBUG - 2011-08-24 22:54:03 --> Total execution time: 0.0720
DEBUG - 2011-08-24 22:54:04 --> Config Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:54:04 --> URI Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Router Class Initialized
ERROR - 2011-08-24 22:54:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 22:54:04 --> Config Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:54:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:54:04 --> URI Class Initialized
DEBUG - 2011-08-24 22:54:04 --> Router Class Initialized
ERROR - 2011-08-24 22:54:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 22:54:29 --> Config Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:54:29 --> URI Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Router Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Output Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Input Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:54:29 --> Language Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Loader Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Controller Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:54:29 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:54:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:54:29 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:54:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:54:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:54:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:54:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:54:29 --> Final output sent to browser
DEBUG - 2011-08-24 22:54:29 --> Total execution time: 0.3807
DEBUG - 2011-08-24 22:54:47 --> Config Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:54:47 --> URI Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Router Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Output Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Input Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:54:47 --> Language Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Loader Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Controller Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Model Class Initialized
DEBUG - 2011-08-24 22:54:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:54:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:54:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:54:48 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:54:48 --> Final output sent to browser
DEBUG - 2011-08-24 22:54:48 --> Total execution time: 0.4036
DEBUG - 2011-08-24 22:55:19 --> Config Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:55:19 --> URI Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Router Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Output Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Input Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:55:19 --> Language Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Loader Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Controller Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:55:19 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:55:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:55:21 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:55:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:55:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:55:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:55:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:55:21 --> Final output sent to browser
DEBUG - 2011-08-24 22:55:21 --> Total execution time: 2.1832
DEBUG - 2011-08-24 22:55:30 --> Config Class Initialized
DEBUG - 2011-08-24 22:55:30 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:55:30 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:55:30 --> URI Class Initialized
DEBUG - 2011-08-24 22:55:30 --> Router Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Output Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Input Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:55:31 --> Language Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Loader Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Controller Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:55:31 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:55:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:55:31 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:55:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:55:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:55:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:55:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:55:31 --> Final output sent to browser
DEBUG - 2011-08-24 22:55:31 --> Total execution time: 0.8329
DEBUG - 2011-08-24 22:55:42 --> Config Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:55:42 --> URI Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Router Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Output Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Input Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:55:42 --> Language Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Loader Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Controller Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:55:42 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:55:42 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:55:42 --> Final output sent to browser
DEBUG - 2011-08-24 22:55:42 --> Total execution time: 0.3413
DEBUG - 2011-08-24 22:55:59 --> Config Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:55:59 --> URI Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Router Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Output Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Input Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:55:59 --> Language Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Loader Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Controller Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Model Class Initialized
DEBUG - 2011-08-24 22:55:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:55:59 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:55:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:55:59 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:55:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:55:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:55:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:55:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:55:59 --> Final output sent to browser
DEBUG - 2011-08-24 22:55:59 --> Total execution time: 0.2022
DEBUG - 2011-08-24 22:56:05 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:05 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:05 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:05 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:06 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:06 --> Total execution time: 0.2949
DEBUG - 2011-08-24 22:56:11 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:11 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:11 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:11 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:12 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:12 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:12 --> Total execution time: 0.6264
DEBUG - 2011-08-24 22:56:18 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:18 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:18 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:18 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:18 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:18 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:18 --> Total execution time: 0.2074
DEBUG - 2011-08-24 22:56:26 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:26 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:26 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:26 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:27 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:27 --> Total execution time: 0.4315
DEBUG - 2011-08-24 22:56:33 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:33 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:33 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:33 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:33 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:33 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:33 --> Total execution time: 0.4285
DEBUG - 2011-08-24 22:56:51 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:51 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:51 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:51 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:52 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:52 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:52 --> Total execution time: 0.2285
DEBUG - 2011-08-24 22:56:58 --> Config Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:56:58 --> URI Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Router Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Output Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Input Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:56:58 --> Language Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Loader Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Controller Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Model Class Initialized
DEBUG - 2011-08-24 22:56:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:56:58 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:56:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:56:58 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:56:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:56:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:56:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:56:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:56:58 --> Final output sent to browser
DEBUG - 2011-08-24 22:56:58 --> Total execution time: 0.3323
DEBUG - 2011-08-24 22:57:05 --> Config Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:57:05 --> URI Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Router Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Output Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Input Class Initialized
DEBUG - 2011-08-24 22:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:57:05 --> Language Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Loader Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Controller Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:57:06 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:57:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:57:06 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:57:06 --> Final output sent to browser
DEBUG - 2011-08-24 22:57:06 --> Total execution time: 0.2566
DEBUG - 2011-08-24 22:57:14 --> Config Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:57:14 --> URI Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Router Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Output Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Input Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:57:14 --> Language Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Loader Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Controller Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:57:14 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:57:15 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:57:15 --> Final output sent to browser
DEBUG - 2011-08-24 22:57:15 --> Total execution time: 0.2154
DEBUG - 2011-08-24 22:57:20 --> Config Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:57:20 --> URI Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Router Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Output Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Input Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:57:20 --> Language Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Loader Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Controller Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:57:20 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:57:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:57:20 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:57:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:57:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:57:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:57:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:57:20 --> Final output sent to browser
DEBUG - 2011-08-24 22:57:20 --> Total execution time: 0.2451
DEBUG - 2011-08-24 22:57:27 --> Config Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:57:27 --> URI Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Router Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Output Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Input Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:57:27 --> Language Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Loader Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Controller Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:57:27 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:57:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:57:27 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:57:27 --> Final output sent to browser
DEBUG - 2011-08-24 22:57:27 --> Total execution time: 0.2729
DEBUG - 2011-08-24 22:57:34 --> Config Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Hooks Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Utf8 Class Initialized
DEBUG - 2011-08-24 22:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 22:57:34 --> URI Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Router Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Output Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Input Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 22:57:34 --> Language Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Loader Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Controller Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Model Class Initialized
DEBUG - 2011-08-24 22:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 22:57:34 --> Database Driver Class Initialized
DEBUG - 2011-08-24 22:57:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-24 22:57:34 --> Helper loaded: url_helper
DEBUG - 2011-08-24 22:57:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 22:57:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 22:57:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 22:57:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 22:57:34 --> Final output sent to browser
DEBUG - 2011-08-24 22:57:34 --> Total execution time: 0.0759
DEBUG - 2011-08-24 23:25:46 --> Config Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:25:46 --> URI Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Router Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Output Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Input Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:25:46 --> Language Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Loader Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Controller Class Initialized
ERROR - 2011-08-24 23:25:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 23:25:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:25:46 --> Model Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Model Class Initialized
DEBUG - 2011-08-24 23:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:25:46 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:25:46 --> Helper loaded: url_helper
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 23:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 23:25:46 --> Final output sent to browser
DEBUG - 2011-08-24 23:25:46 --> Total execution time: 0.0555
DEBUG - 2011-08-24 23:25:47 --> Config Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:25:47 --> URI Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Router Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Output Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Input Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:25:47 --> Language Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Loader Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Controller Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Model Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Model Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:25:47 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:25:47 --> Final output sent to browser
DEBUG - 2011-08-24 23:25:47 --> Total execution time: 0.6386
DEBUG - 2011-08-24 23:25:48 --> Config Class Initialized
DEBUG - 2011-08-24 23:25:48 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:25:48 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:25:48 --> URI Class Initialized
DEBUG - 2011-08-24 23:25:48 --> Router Class Initialized
ERROR - 2011-08-24 23:25:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 23:26:15 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:15 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:15 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Controller Class Initialized
ERROR - 2011-08-24 23:26:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 23:26:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:15 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:15 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:15 --> Helper loaded: url_helper
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 23:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 23:26:15 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:15 --> Total execution time: 0.0297
DEBUG - 2011-08-24 23:26:16 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:16 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:16 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Controller Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:16 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:16 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:16 --> Total execution time: 0.6444
DEBUG - 2011-08-24 23:26:17 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:17 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:17 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:17 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:17 --> Router Class Initialized
ERROR - 2011-08-24 23:26:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 23:26:35 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:35 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:35 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Controller Class Initialized
ERROR - 2011-08-24 23:26:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 23:26:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:35 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:35 --> Helper loaded: url_helper
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 23:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 23:26:35 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:35 --> Total execution time: 0.0284
DEBUG - 2011-08-24 23:26:35 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:35 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:35 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Controller Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:35 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:36 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:36 --> Total execution time: 0.5170
DEBUG - 2011-08-24 23:26:37 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:37 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:37 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:37 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:37 --> Router Class Initialized
ERROR - 2011-08-24 23:26:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-24 23:26:56 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:56 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:56 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Controller Class Initialized
ERROR - 2011-08-24 23:26:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-24 23:26:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:56 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-24 23:26:56 --> Helper loaded: url_helper
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-24 23:26:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-24 23:26:56 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:56 --> Total execution time: 0.0318
DEBUG - 2011-08-24 23:26:56 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:56 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Router Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Output Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Input Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-24 23:26:56 --> Language Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Loader Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Controller Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Model Class Initialized
DEBUG - 2011-08-24 23:26:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-24 23:26:56 --> Database Driver Class Initialized
DEBUG - 2011-08-24 23:26:57 --> Final output sent to browser
DEBUG - 2011-08-24 23:26:57 --> Total execution time: 0.6427
DEBUG - 2011-08-24 23:26:58 --> Config Class Initialized
DEBUG - 2011-08-24 23:26:58 --> Hooks Class Initialized
DEBUG - 2011-08-24 23:26:58 --> Utf8 Class Initialized
DEBUG - 2011-08-24 23:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-24 23:26:58 --> URI Class Initialized
DEBUG - 2011-08-24 23:26:58 --> Router Class Initialized
ERROR - 2011-08-24 23:26:58 --> 404 Page Not Found --> favicon.ico

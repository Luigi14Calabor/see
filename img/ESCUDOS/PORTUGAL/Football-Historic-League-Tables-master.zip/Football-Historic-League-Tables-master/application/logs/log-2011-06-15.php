<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-15 01:12:07 --> Config Class Initialized
DEBUG - 2011-06-15 01:12:07 --> Hooks Class Initialized
DEBUG - 2011-06-15 01:12:07 --> Utf8 Class Initialized
DEBUG - 2011-06-15 01:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 01:12:07 --> URI Class Initialized
DEBUG - 2011-06-15 01:12:07 --> Router Class Initialized
ERROR - 2011-06-15 01:12:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 01:12:08 --> Config Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Hooks Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Utf8 Class Initialized
DEBUG - 2011-06-15 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 01:12:08 --> URI Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Router Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Output Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Input Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 01:12:08 --> Language Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Loader Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Controller Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Model Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Model Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Model Class Initialized
DEBUG - 2011-06-15 01:12:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 01:12:08 --> Database Driver Class Initialized
DEBUG - 2011-06-15 01:12:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 01:12:08 --> Helper loaded: url_helper
DEBUG - 2011-06-15 01:12:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 01:12:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 01:12:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 01:12:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 01:12:08 --> Final output sent to browser
DEBUG - 2011-06-15 01:12:08 --> Total execution time: 0.5132
DEBUG - 2011-06-15 01:12:39 --> Config Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Hooks Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Utf8 Class Initialized
DEBUG - 2011-06-15 01:12:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 01:12:39 --> URI Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Router Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Output Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Input Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 01:12:39 --> Language Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Loader Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Controller Class Initialized
ERROR - 2011-06-15 01:12:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 01:12:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 01:12:39 --> Model Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Model Class Initialized
DEBUG - 2011-06-15 01:12:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 01:12:39 --> Database Driver Class Initialized
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 01:12:39 --> Helper loaded: url_helper
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 01:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 01:12:39 --> Final output sent to browser
DEBUG - 2011-06-15 01:12:39 --> Total execution time: 0.0934
DEBUG - 2011-06-15 03:07:47 --> Config Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Hooks Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Utf8 Class Initialized
DEBUG - 2011-06-15 03:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 03:07:47 --> URI Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Router Class Initialized
DEBUG - 2011-06-15 03:07:47 --> No URI present. Default controller set.
DEBUG - 2011-06-15 03:07:47 --> Output Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Input Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 03:07:47 --> Language Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Loader Class Initialized
DEBUG - 2011-06-15 03:07:47 --> Controller Class Initialized
DEBUG - 2011-06-15 03:07:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 03:07:48 --> Helper loaded: url_helper
DEBUG - 2011-06-15 03:07:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 03:07:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 03:07:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 03:07:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 03:07:48 --> Final output sent to browser
DEBUG - 2011-06-15 03:07:48 --> Total execution time: 0.3144
DEBUG - 2011-06-15 03:26:11 --> Config Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Hooks Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Utf8 Class Initialized
DEBUG - 2011-06-15 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 03:26:11 --> URI Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Router Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Output Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Input Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 03:26:11 --> Language Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Loader Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Controller Class Initialized
ERROR - 2011-06-15 03:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 03:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 03:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 03:26:11 --> Model Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Model Class Initialized
DEBUG - 2011-06-15 03:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 03:26:11 --> Database Driver Class Initialized
DEBUG - 2011-06-15 03:26:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 03:26:12 --> Helper loaded: url_helper
DEBUG - 2011-06-15 03:26:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 03:26:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 03:26:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 03:26:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 03:26:12 --> Final output sent to browser
DEBUG - 2011-06-15 03:26:12 --> Total execution time: 1.5471
DEBUG - 2011-06-15 03:26:14 --> Config Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Hooks Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Utf8 Class Initialized
DEBUG - 2011-06-15 03:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 03:26:14 --> URI Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Router Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Output Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Input Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 03:26:14 --> Language Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Loader Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Controller Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Model Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Model Class Initialized
DEBUG - 2011-06-15 03:26:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 03:26:14 --> Database Driver Class Initialized
DEBUG - 2011-06-15 03:26:16 --> Final output sent to browser
DEBUG - 2011-06-15 03:26:16 --> Total execution time: 2.5722
DEBUG - 2011-06-15 03:26:19 --> Config Class Initialized
DEBUG - 2011-06-15 03:26:19 --> Hooks Class Initialized
DEBUG - 2011-06-15 03:26:19 --> Utf8 Class Initialized
DEBUG - 2011-06-15 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 03:26:19 --> URI Class Initialized
DEBUG - 2011-06-15 03:26:19 --> Router Class Initialized
ERROR - 2011-06-15 03:26:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 06:48:20 --> Config Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Hooks Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Utf8 Class Initialized
DEBUG - 2011-06-15 06:48:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 06:48:20 --> URI Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Router Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Output Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Input Class Initialized
DEBUG - 2011-06-15 06:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 06:48:21 --> Language Class Initialized
DEBUG - 2011-06-15 06:48:21 --> Loader Class Initialized
DEBUG - 2011-06-15 06:48:21 --> Controller Class Initialized
ERROR - 2011-06-15 06:48:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 06:48:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 06:48:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 06:48:21 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:21 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 06:48:21 --> Database Driver Class Initialized
DEBUG - 2011-06-15 06:48:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 06:48:22 --> Helper loaded: url_helper
DEBUG - 2011-06-15 06:48:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 06:48:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 06:48:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 06:48:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 06:48:22 --> Final output sent to browser
DEBUG - 2011-06-15 06:48:22 --> Total execution time: 1.5519
DEBUG - 2011-06-15 06:48:27 --> Config Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Hooks Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Utf8 Class Initialized
DEBUG - 2011-06-15 06:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 06:48:27 --> URI Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Router Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Output Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Input Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 06:48:27 --> Language Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Loader Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Controller Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 06:48:27 --> Database Driver Class Initialized
DEBUG - 2011-06-15 06:48:28 --> Final output sent to browser
DEBUG - 2011-06-15 06:48:28 --> Total execution time: 0.9086
DEBUG - 2011-06-15 06:48:31 --> Config Class Initialized
DEBUG - 2011-06-15 06:48:31 --> Hooks Class Initialized
DEBUG - 2011-06-15 06:48:31 --> Utf8 Class Initialized
DEBUG - 2011-06-15 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 06:48:31 --> URI Class Initialized
DEBUG - 2011-06-15 06:48:31 --> Router Class Initialized
ERROR - 2011-06-15 06:48:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 06:48:51 --> Config Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Hooks Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Utf8 Class Initialized
DEBUG - 2011-06-15 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 06:48:51 --> URI Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Router Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Output Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Input Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 06:48:51 --> Language Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Loader Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Controller Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Model Class Initialized
DEBUG - 2011-06-15 06:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 06:48:51 --> Database Driver Class Initialized
DEBUG - 2011-06-15 06:48:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 06:48:52 --> Helper loaded: url_helper
DEBUG - 2011-06-15 06:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 06:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 06:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 06:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 06:48:52 --> Final output sent to browser
DEBUG - 2011-06-15 06:48:52 --> Total execution time: 1.1078
DEBUG - 2011-06-15 06:48:59 --> Config Class Initialized
DEBUG - 2011-06-15 06:48:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 06:48:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 06:48:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 06:48:59 --> URI Class Initialized
DEBUG - 2011-06-15 06:48:59 --> Router Class Initialized
ERROR - 2011-06-15 06:48:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:08:21 --> Config Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:08:21 --> URI Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Router Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Output Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Input Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:08:21 --> Language Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Loader Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Controller Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:08:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:08:21 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 08:08:22 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:08:22 --> Final output sent to browser
DEBUG - 2011-06-15 08:08:22 --> Total execution time: 1.6349
DEBUG - 2011-06-15 08:08:24 --> Config Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:08:24 --> URI Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Router Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Output Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Input Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:08:24 --> Language Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Loader Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Controller Class Initialized
ERROR - 2011-06-15 08:08:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:08:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:08:24 --> Model Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Model Class Initialized
DEBUG - 2011-06-15 08:08:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:08:24 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:08:24 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:08:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:08:24 --> Final output sent to browser
DEBUG - 2011-06-15 08:08:24 --> Total execution time: 0.1046
DEBUG - 2011-06-15 08:24:37 --> Config Class Initialized
DEBUG - 2011-06-15 08:24:37 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:24:37 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:24:37 --> URI Class Initialized
DEBUG - 2011-06-15 08:24:37 --> Router Class Initialized
ERROR - 2011-06-15 08:24:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 08:25:39 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:39 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Router Class Initialized
DEBUG - 2011-06-15 08:25:39 --> No URI present. Default controller set.
DEBUG - 2011-06-15 08:25:39 --> Output Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Input Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:25:39 --> Language Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Loader Class Initialized
DEBUG - 2011-06-15 08:25:39 --> Controller Class Initialized
DEBUG - 2011-06-15 08:25:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 08:25:39 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:25:39 --> Final output sent to browser
DEBUG - 2011-06-15 08:25:39 --> Total execution time: 0.5474
DEBUG - 2011-06-15 08:25:42 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:42 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Router Class Initialized
ERROR - 2011-06-15 08:25:42 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 08:25:42 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:42 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Router Class Initialized
ERROR - 2011-06-15 08:25:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:25:42 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:42 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Router Class Initialized
DEBUG - 2011-06-15 08:25:42 --> No URI present. Default controller set.
DEBUG - 2011-06-15 08:25:42 --> Output Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Input Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:25:42 --> Language Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Loader Class Initialized
DEBUG - 2011-06-15 08:25:42 --> Controller Class Initialized
DEBUG - 2011-06-15 08:25:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 08:25:42 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:25:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:25:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:25:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:25:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:25:42 --> Final output sent to browser
DEBUG - 2011-06-15 08:25:42 --> Total execution time: 0.0120
DEBUG - 2011-06-15 08:25:43 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:43 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Router Class Initialized
ERROR - 2011-06-15 08:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:25:43 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:43 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:43 --> Router Class Initialized
ERROR - 2011-06-15 08:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:25:46 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:46 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Router Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Output Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Input Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:25:46 --> Language Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Loader Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Controller Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:25:46 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:25:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 08:25:47 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:25:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:25:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:25:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:25:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:25:47 --> Final output sent to browser
DEBUG - 2011-06-15 08:25:47 --> Total execution time: 0.1805
DEBUG - 2011-06-15 08:25:56 --> Config Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:25:56 --> URI Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Router Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Output Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Input Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:25:56 --> Language Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Loader Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Controller Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Model Class Initialized
DEBUG - 2011-06-15 08:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:25:56 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:25:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 08:25:57 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:25:57 --> Final output sent to browser
DEBUG - 2011-06-15 08:25:57 --> Total execution time: 0.7976
DEBUG - 2011-06-15 08:26:03 --> Config Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:26:03 --> URI Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Router Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Output Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Input Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:26:03 --> Language Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Loader Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Controller Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Model Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Model Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Model Class Initialized
DEBUG - 2011-06-15 08:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:26:03 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:26:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 08:26:03 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:26:03 --> Final output sent to browser
DEBUG - 2011-06-15 08:26:03 --> Total execution time: 0.0488
DEBUG - 2011-06-15 08:40:50 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:50 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Router Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Output Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Input Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:40:50 --> Language Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Loader Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Controller Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:40:50 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:50 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Router Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Output Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Input Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:40:50 --> Language Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Loader Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Controller Class Initialized
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/table/main.php
ERROR - 2011-06-15 08:40:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:40:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:40:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:40:50 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:40:50 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:40:50 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:40:50 --> Final output sent to browser
DEBUG - 2011-06-15 08:40:50 --> Total execution time: 0.3360
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:40:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:40:50 --> Final output sent to browser
DEBUG - 2011-06-15 08:40:50 --> Total execution time: 1.1266
DEBUG - 2011-06-15 08:40:51 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:51 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Router Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Output Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Input Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:40:51 --> Language Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Loader Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Controller Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:40:51 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:40:52 --> Final output sent to browser
DEBUG - 2011-06-15 08:40:52 --> Total execution time: 0.6898
DEBUG - 2011-06-15 08:40:53 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:53 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Router Class Initialized
ERROR - 2011-06-15 08:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:40:53 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:53 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Router Class Initialized
ERROR - 2011-06-15 08:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:40:53 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:53 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:53 --> Router Class Initialized
ERROR - 2011-06-15 08:40:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 08:40:58 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:58 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Router Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Output Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Input Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:40:58 --> Language Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Loader Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Controller Class Initialized
ERROR - 2011-06-15 08:40:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:40:58 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:40:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:40:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:40:59 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:40:59 --> Final output sent to browser
DEBUG - 2011-06-15 08:40:59 --> Total execution time: 0.0372
DEBUG - 2011-06-15 08:40:59 --> Config Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:40:59 --> URI Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Router Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Output Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Input Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:40:59 --> Language Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Loader Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Controller Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:40:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:00 --> Total execution time: 0.6570
DEBUG - 2011-06-15 08:41:00 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:00 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:00 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:00 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:00 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:00 --> Total execution time: 0.0330
DEBUG - 2011-06-15 08:41:14 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:14 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:14 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:14 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:14 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:14 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:14 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:14 --> Total execution time: 0.0296
DEBUG - 2011-06-15 08:41:15 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:15 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:15 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:15 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:15 --> Total execution time: 0.7525
DEBUG - 2011-06-15 08:41:20 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:20 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:20 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:20 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:20 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:20 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:20 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:20 --> Total execution time: 0.0384
DEBUG - 2011-06-15 08:41:21 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:21 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:21 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:21 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:21 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:21 --> Total execution time: 0.5055
DEBUG - 2011-06-15 08:41:26 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:26 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:26 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:26 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:26 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:26 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:26 --> Total execution time: 0.1217
DEBUG - 2011-06-15 08:41:26 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:26 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:26 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:26 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:27 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:27 --> Total execution time: 0.8212
DEBUG - 2011-06-15 08:41:30 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:30 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:30 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:30 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:30 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:30 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:30 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:30 --> Total execution time: 0.0347
DEBUG - 2011-06-15 08:41:32 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:32 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:32 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:32 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:32 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:32 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:32 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:32 --> Total execution time: 0.0304
DEBUG - 2011-06-15 08:41:35 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:35 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:35 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:35 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:36 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:36 --> Total execution time: 0.7109
DEBUG - 2011-06-15 08:41:39 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:39 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:39 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:39 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:39 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:39 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:39 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:39 --> Total execution time: 0.0982
DEBUG - 2011-06-15 08:41:40 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:40 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:40 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:40 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:40 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:40 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:40 --> Total execution time: 0.0326
DEBUG - 2011-06-15 08:41:40 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:40 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:40 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:40 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:41 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:41 --> Total execution time: 0.6862
DEBUG - 2011-06-15 08:41:44 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:44 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:44 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:44 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:44 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:44 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:44 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:44 --> Total execution time: 0.0421
DEBUG - 2011-06-15 08:41:45 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:45 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:45 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:45 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:46 --> Total execution time: 0.8616
DEBUG - 2011-06-15 08:41:46 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:46 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:46 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:46 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:46 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:46 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:46 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:46 --> Total execution time: 0.0450
DEBUG - 2011-06-15 08:41:58 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:58 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:58 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Controller Class Initialized
ERROR - 2011-06-15 08:41:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:41:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:58 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:58 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:41:58 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:41:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:41:58 --> Final output sent to browser
DEBUG - 2011-06-15 08:41:58 --> Total execution time: 0.1401
DEBUG - 2011-06-15 08:41:59 --> Config Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:41:59 --> URI Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Router Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Output Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Input Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:41:59 --> Language Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Loader Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Controller Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:41:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:42:00 --> Total execution time: 0.5582
DEBUG - 2011-06-15 08:42:00 --> Config Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:42:00 --> URI Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Router Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Output Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Input Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:42:00 --> Language Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Loader Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Controller Class Initialized
ERROR - 2011-06-15 08:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:42:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:42:00 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:42:00 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:42:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:42:00 --> Total execution time: 0.0314
DEBUG - 2011-06-15 08:43:06 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:06 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:06 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:06 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:06 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:06 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:06 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:06 --> Total execution time: 0.0816
DEBUG - 2011-06-15 08:43:07 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:07 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:07 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Controller Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:07 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:07 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:07 --> Total execution time: 0.7929
DEBUG - 2011-06-15 08:43:12 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:12 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:12 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:12 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:12 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:12 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:12 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:12 --> Total execution time: 0.0460
DEBUG - 2011-06-15 08:43:21 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:21 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:21 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:21 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:21 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:21 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:21 --> Total execution time: 0.0304
DEBUG - 2011-06-15 08:43:22 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:22 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:22 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Controller Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:22 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:23 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:23 --> Total execution time: 1.3628
DEBUG - 2011-06-15 08:43:25 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:25 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:25 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:25 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:25 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:25 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:25 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:25 --> Total execution time: 0.0315
DEBUG - 2011-06-15 08:43:32 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:32 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:32 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:32 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:32 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:32 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:32 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:33 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:33 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:33 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:33 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:33 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:33 --> Total execution time: 0.0472
DEBUG - 2011-06-15 08:43:33 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:33 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:33 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Controller Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:33 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:34 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:34 --> Total execution time: 0.5246
DEBUG - 2011-06-15 08:43:36 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:36 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:36 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:36 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:36 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:36 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:36 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:36 --> Total execution time: 0.0364
DEBUG - 2011-06-15 08:43:49 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:49 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:49 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:49 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:49 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:49 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:49 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:49 --> Total execution time: 0.0773
DEBUG - 2011-06-15 08:43:50 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:50 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:50 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Controller Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:50 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:51 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:51 --> Total execution time: 0.6470
DEBUG - 2011-06-15 08:43:59 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:59 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:59 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Controller Class Initialized
ERROR - 2011-06-15 08:43:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:43:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:43:59 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:43:59 --> Final output sent to browser
DEBUG - 2011-06-15 08:43:59 --> Total execution time: 0.0330
DEBUG - 2011-06-15 08:43:59 --> Config Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:43:59 --> URI Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Router Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Output Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Input Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:43:59 --> Language Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Loader Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Controller Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Model Class Initialized
DEBUG - 2011-06-15 08:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:43:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:00 --> Total execution time: 0.5072
DEBUG - 2011-06-15 08:44:00 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:00 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:00 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:00 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:00 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:00 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:00 --> Total execution time: 0.0345
DEBUG - 2011-06-15 08:44:15 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:15 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:15 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:15 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:15 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:15 --> Total execution time: 0.0339
DEBUG - 2011-06-15 08:44:15 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:15 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:15 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Controller Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:16 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:16 --> Total execution time: 0.5087
DEBUG - 2011-06-15 08:44:22 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:22 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:22 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:22 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:22 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:22 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:22 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:22 --> Total execution time: 0.0341
DEBUG - 2011-06-15 08:44:26 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:26 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:26 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:26 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:26 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:26 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:26 --> Total execution time: 0.0274
DEBUG - 2011-06-15 08:44:26 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:26 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:26 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Controller Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:26 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:27 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:27 --> Total execution time: 0.5167
DEBUG - 2011-06-15 08:44:40 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:40 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:40 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:40 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:40 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:40 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:40 --> Total execution time: 0.0299
DEBUG - 2011-06-15 08:44:44 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:44 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:44 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:44 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:44 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:44 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:44 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:44 --> Total execution time: 0.0799
DEBUG - 2011-06-15 08:44:45 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:45 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:45 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Controller Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:45 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Config Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Hooks Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Utf8 Class Initialized
DEBUG - 2011-06-15 08:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 08:44:45 --> URI Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Router Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Output Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Input Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 08:44:45 --> Language Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Loader Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Controller Class Initialized
ERROR - 2011-06-15 08:44:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 08:44:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Model Class Initialized
DEBUG - 2011-06-15 08:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 08:44:45 --> Database Driver Class Initialized
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 08:44:45 --> Helper loaded: url_helper
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 08:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 08:44:45 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:45 --> Total execution time: 0.0307
DEBUG - 2011-06-15 08:44:45 --> Final output sent to browser
DEBUG - 2011-06-15 08:44:45 --> Total execution time: 0.5704
DEBUG - 2011-06-15 09:45:03 --> Config Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Hooks Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Utf8 Class Initialized
DEBUG - 2011-06-15 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 09:45:03 --> URI Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Router Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Output Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Input Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 09:45:03 --> Language Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Loader Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Controller Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Model Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Model Class Initialized
DEBUG - 2011-06-15 09:45:03 --> Model Class Initialized
DEBUG - 2011-06-15 09:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 09:45:04 --> Database Driver Class Initialized
DEBUG - 2011-06-15 09:45:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 09:45:05 --> Helper loaded: url_helper
DEBUG - 2011-06-15 09:45:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 09:45:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 09:45:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 09:45:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 09:45:05 --> Final output sent to browser
DEBUG - 2011-06-15 09:45:05 --> Total execution time: 2.2268
DEBUG - 2011-06-15 09:45:08 --> Config Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Hooks Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Utf8 Class Initialized
DEBUG - 2011-06-15 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 09:45:08 --> URI Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Router Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Output Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Input Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 09:45:08 --> Language Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Loader Class Initialized
DEBUG - 2011-06-15 09:45:08 --> Controller Class Initialized
ERROR - 2011-06-15 09:45:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 09:45:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 09:45:09 --> Model Class Initialized
DEBUG - 2011-06-15 09:45:09 --> Model Class Initialized
DEBUG - 2011-06-15 09:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 09:45:09 --> Database Driver Class Initialized
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 09:45:09 --> Helper loaded: url_helper
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 09:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 09:45:09 --> Final output sent to browser
DEBUG - 2011-06-15 09:45:09 --> Total execution time: 1.0889
DEBUG - 2011-06-15 11:22:48 --> Config Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Hooks Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Utf8 Class Initialized
DEBUG - 2011-06-15 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 11:22:48 --> URI Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Router Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Output Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Input Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 11:22:48 --> Language Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Loader Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Controller Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Model Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Model Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Model Class Initialized
DEBUG - 2011-06-15 11:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 11:22:48 --> Database Driver Class Initialized
DEBUG - 2011-06-15 11:22:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 11:22:49 --> Helper loaded: url_helper
DEBUG - 2011-06-15 11:22:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 11:22:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 11:22:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 11:22:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 11:22:49 --> Final output sent to browser
DEBUG - 2011-06-15 11:22:49 --> Total execution time: 1.4837
DEBUG - 2011-06-15 11:22:51 --> Config Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Hooks Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Utf8 Class Initialized
DEBUG - 2011-06-15 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 11:22:51 --> URI Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Router Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Output Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Input Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 11:22:51 --> Language Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Loader Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Controller Class Initialized
ERROR - 2011-06-15 11:22:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 11:22:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 11:22:51 --> Model Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Model Class Initialized
DEBUG - 2011-06-15 11:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 11:22:51 --> Database Driver Class Initialized
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 11:22:51 --> Helper loaded: url_helper
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 11:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 11:22:51 --> Final output sent to browser
DEBUG - 2011-06-15 11:22:51 --> Total execution time: 0.1550
DEBUG - 2011-06-15 12:11:57 --> Config Class Initialized
DEBUG - 2011-06-15 12:11:57 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:11:58 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:11:58 --> URI Class Initialized
DEBUG - 2011-06-15 12:11:58 --> Router Class Initialized
DEBUG - 2011-06-15 12:11:58 --> Output Class Initialized
DEBUG - 2011-06-15 12:11:58 --> Input Class Initialized
DEBUG - 2011-06-15 12:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:11:58 --> Language Class Initialized
DEBUG - 2011-06-15 12:11:59 --> Loader Class Initialized
DEBUG - 2011-06-15 12:11:59 --> Controller Class Initialized
ERROR - 2011-06-15 12:11:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 12:11:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 12:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:11:59 --> Model Class Initialized
DEBUG - 2011-06-15 12:11:59 --> Model Class Initialized
DEBUG - 2011-06-15 12:11:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:11:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:11:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:12:00 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:12:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:12:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:12:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:12:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:12:00 --> Final output sent to browser
DEBUG - 2011-06-15 12:12:00 --> Total execution time: 3.5947
DEBUG - 2011-06-15 12:12:07 --> Config Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:12:07 --> URI Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Router Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Output Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Input Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:12:07 --> Language Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Loader Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Controller Class Initialized
ERROR - 2011-06-15 12:12:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 12:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:12:07 --> Model Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Model Class Initialized
DEBUG - 2011-06-15 12:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:12:07 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:12:07 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:12:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:12:07 --> Final output sent to browser
DEBUG - 2011-06-15 12:12:07 --> Total execution time: 0.0737
DEBUG - 2011-06-15 12:33:26 --> Config Class Initialized
DEBUG - 2011-06-15 12:33:26 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:33:26 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:33:26 --> URI Class Initialized
DEBUG - 2011-06-15 12:33:26 --> Router Class Initialized
ERROR - 2011-06-15 12:33:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 12:33:27 --> Config Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:33:27 --> URI Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Router Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Output Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Input Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:33:27 --> Language Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Loader Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Controller Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Model Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Model Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Model Class Initialized
DEBUG - 2011-06-15 12:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:33:27 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 12:33:29 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:33:29 --> Final output sent to browser
DEBUG - 2011-06-15 12:33:29 --> Total execution time: 2.0252
DEBUG - 2011-06-15 12:33:59 --> Config Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:33:59 --> URI Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Router Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Output Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Input Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:33:59 --> Language Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Loader Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Controller Class Initialized
ERROR - 2011-06-15 12:33:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 12:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:33:59 --> Model Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Model Class Initialized
DEBUG - 2011-06-15 12:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:33:59 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:33:59 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:33:59 --> Final output sent to browser
DEBUG - 2011-06-15 12:33:59 --> Total execution time: 0.1191
DEBUG - 2011-06-15 12:52:53 --> Config Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:52:53 --> URI Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Router Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Output Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Input Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:52:53 --> Language Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Loader Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Controller Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Model Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Model Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Model Class Initialized
DEBUG - 2011-06-15 12:52:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:52:53 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:52:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 12:52:53 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:52:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:52:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:52:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:52:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:52:53 --> Final output sent to browser
DEBUG - 2011-06-15 12:52:53 --> Total execution time: 0.5989
DEBUG - 2011-06-15 12:52:56 --> Config Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Hooks Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Utf8 Class Initialized
DEBUG - 2011-06-15 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 12:52:56 --> URI Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Router Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Output Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Input Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 12:52:56 --> Language Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Loader Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Controller Class Initialized
ERROR - 2011-06-15 12:52:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 12:52:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:52:56 --> Model Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Model Class Initialized
DEBUG - 2011-06-15 12:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 12:52:56 --> Database Driver Class Initialized
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 12:52:56 --> Helper loaded: url_helper
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 12:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 12:52:56 --> Final output sent to browser
DEBUG - 2011-06-15 12:52:56 --> Total execution time: 0.0906
DEBUG - 2011-06-15 13:41:39 --> Config Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Hooks Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Utf8 Class Initialized
DEBUG - 2011-06-15 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 13:41:39 --> URI Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Router Class Initialized
DEBUG - 2011-06-15 13:41:39 --> No URI present. Default controller set.
DEBUG - 2011-06-15 13:41:39 --> Output Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Input Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 13:41:39 --> Language Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Loader Class Initialized
DEBUG - 2011-06-15 13:41:39 --> Controller Class Initialized
DEBUG - 2011-06-15 13:41:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 13:41:39 --> Helper loaded: url_helper
DEBUG - 2011-06-15 13:41:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 13:41:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 13:41:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 13:41:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 13:41:39 --> Final output sent to browser
DEBUG - 2011-06-15 13:41:39 --> Total execution time: 0.6629
DEBUG - 2011-06-15 13:41:46 --> Config Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Hooks Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Utf8 Class Initialized
DEBUG - 2011-06-15 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 13:41:46 --> URI Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Router Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Output Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Input Class Initialized
DEBUG - 2011-06-15 13:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 13:41:46 --> Language Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Loader Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Controller Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Model Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Model Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Model Class Initialized
DEBUG - 2011-06-15 13:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 13:41:48 --> Database Driver Class Initialized
DEBUG - 2011-06-15 13:41:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 13:41:49 --> Helper loaded: url_helper
DEBUG - 2011-06-15 13:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 13:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 13:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 13:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 13:41:49 --> Final output sent to browser
DEBUG - 2011-06-15 13:41:49 --> Total execution time: 2.7330
DEBUG - 2011-06-15 13:42:01 --> Config Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Hooks Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Utf8 Class Initialized
DEBUG - 2011-06-15 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 13:42:01 --> URI Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Router Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Output Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Input Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 13:42:01 --> Language Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Loader Class Initialized
DEBUG - 2011-06-15 13:42:01 --> Controller Class Initialized
ERROR - 2011-06-15 13:42:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 13:42:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 13:42:02 --> Model Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Model Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 13:42:02 --> Database Driver Class Initialized
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 13:42:02 --> Helper loaded: url_helper
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 13:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 13:42:02 --> Final output sent to browser
DEBUG - 2011-06-15 13:42:02 --> Total execution time: 0.1004
DEBUG - 2011-06-15 13:42:02 --> Config Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Hooks Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Utf8 Class Initialized
DEBUG - 2011-06-15 13:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 13:42:02 --> URI Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Router Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Output Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Input Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 13:42:02 --> Language Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Loader Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Controller Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Model Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Model Class Initialized
DEBUG - 2011-06-15 13:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 13:42:02 --> Database Driver Class Initialized
DEBUG - 2011-06-15 13:42:03 --> Final output sent to browser
DEBUG - 2011-06-15 13:42:03 --> Total execution time: 0.7065
DEBUG - 2011-06-15 14:19:14 --> Config Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:19:14 --> URI Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Router Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Output Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Input Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:19:14 --> Language Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Loader Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Controller Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Model Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Model Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Model Class Initialized
DEBUG - 2011-06-15 14:19:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 14:19:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 14:19:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 14:19:15 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:19:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:19:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:19:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:19:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:19:15 --> Final output sent to browser
DEBUG - 2011-06-15 14:19:15 --> Total execution time: 0.5413
DEBUG - 2011-06-15 14:19:16 --> Config Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:19:16 --> URI Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Router Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Output Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Input Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:19:16 --> Language Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Loader Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Controller Class Initialized
ERROR - 2011-06-15 14:19:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 14:19:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 14:19:16 --> Model Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Model Class Initialized
DEBUG - 2011-06-15 14:19:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 14:19:16 --> Database Driver Class Initialized
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 14:19:16 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:19:16 --> Final output sent to browser
DEBUG - 2011-06-15 14:19:16 --> Total execution time: 0.1196
DEBUG - 2011-06-15 14:25:24 --> Config Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:25:24 --> URI Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Router Class Initialized
DEBUG - 2011-06-15 14:25:24 --> No URI present. Default controller set.
DEBUG - 2011-06-15 14:25:24 --> Output Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Input Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:25:24 --> Language Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Loader Class Initialized
DEBUG - 2011-06-15 14:25:24 --> Controller Class Initialized
DEBUG - 2011-06-15 14:25:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 14:25:24 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:25:24 --> Final output sent to browser
DEBUG - 2011-06-15 14:25:24 --> Total execution time: 0.0745
DEBUG - 2011-06-15 14:26:49 --> Config Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:26:49 --> URI Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Router Class Initialized
DEBUG - 2011-06-15 14:26:49 --> No URI present. Default controller set.
DEBUG - 2011-06-15 14:26:49 --> Output Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Input Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:26:49 --> Language Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Loader Class Initialized
DEBUG - 2011-06-15 14:26:49 --> Controller Class Initialized
DEBUG - 2011-06-15 14:26:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 14:26:49 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:26:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:26:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:26:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:26:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:26:49 --> Final output sent to browser
DEBUG - 2011-06-15 14:26:49 --> Total execution time: 0.0141
DEBUG - 2011-06-15 14:32:25 --> Config Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:32:25 --> URI Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Router Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Output Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Input Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:32:25 --> Language Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Loader Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Controller Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Model Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Model Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Model Class Initialized
DEBUG - 2011-06-15 14:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 14:32:25 --> Database Driver Class Initialized
DEBUG - 2011-06-15 14:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 14:32:25 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:32:25 --> Final output sent to browser
DEBUG - 2011-06-15 14:32:25 --> Total execution time: 0.1038
DEBUG - 2011-06-15 14:34:08 --> Config Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Hooks Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Utf8 Class Initialized
DEBUG - 2011-06-15 14:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 14:34:08 --> URI Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Router Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Output Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Input Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 14:34:08 --> Language Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Loader Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Controller Class Initialized
ERROR - 2011-06-15 14:34:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 14:34:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 14:34:08 --> Model Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Model Class Initialized
DEBUG - 2011-06-15 14:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 14:34:08 --> Database Driver Class Initialized
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 14:34:08 --> Helper loaded: url_helper
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 14:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 14:34:08 --> Final output sent to browser
DEBUG - 2011-06-15 14:34:08 --> Total execution time: 0.0621
DEBUG - 2011-06-15 15:09:04 --> Config Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:09:04 --> URI Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Router Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Output Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Input Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:09:04 --> Language Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Loader Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Controller Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Model Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Model Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Model Class Initialized
DEBUG - 2011-06-15 15:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:09:04 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:09:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 15:09:04 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:09:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:09:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:09:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:09:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:09:04 --> Final output sent to browser
DEBUG - 2011-06-15 15:09:04 --> Total execution time: 0.6313
DEBUG - 2011-06-15 15:09:06 --> Config Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:09:06 --> URI Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Router Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Output Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Input Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:09:06 --> Language Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Loader Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Controller Class Initialized
ERROR - 2011-06-15 15:09:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 15:09:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:09:06 --> Model Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Model Class Initialized
DEBUG - 2011-06-15 15:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:09:06 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:09:06 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:09:06 --> Final output sent to browser
DEBUG - 2011-06-15 15:09:06 --> Total execution time: 0.0984
DEBUG - 2011-06-15 15:54:43 --> Config Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:54:43 --> URI Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Router Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Output Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Input Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:54:43 --> Language Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Loader Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Controller Class Initialized
ERROR - 2011-06-15 15:54:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 15:54:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:54:43 --> Model Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Model Class Initialized
DEBUG - 2011-06-15 15:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:54:43 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:54:43 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:54:43 --> Final output sent to browser
DEBUG - 2011-06-15 15:54:43 --> Total execution time: 0.4009
DEBUG - 2011-06-15 15:54:45 --> Config Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:54:45 --> URI Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Router Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Output Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Input Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:54:45 --> Language Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Loader Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Controller Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Model Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Model Class Initialized
DEBUG - 2011-06-15 15:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:54:45 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:54:46 --> Final output sent to browser
DEBUG - 2011-06-15 15:54:46 --> Total execution time: 0.8621
DEBUG - 2011-06-15 15:54:46 --> Config Class Initialized
DEBUG - 2011-06-15 15:54:46 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:54:46 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:54:46 --> URI Class Initialized
DEBUG - 2011-06-15 15:54:46 --> Router Class Initialized
ERROR - 2011-06-15 15:54:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 15:55:21 --> Config Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:55:21 --> URI Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Router Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Output Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Input Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:55:21 --> Language Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Loader Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Controller Class Initialized
ERROR - 2011-06-15 15:55:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 15:55:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:21 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:55:21 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:21 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:55:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:55:21 --> Final output sent to browser
DEBUG - 2011-06-15 15:55:21 --> Total execution time: 0.0520
DEBUG - 2011-06-15 15:55:22 --> Config Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:55:22 --> URI Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Router Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Output Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Input Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:55:22 --> Language Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Loader Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Controller Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:55:22 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Config Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:55:22 --> URI Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Router Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Output Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Input Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:55:22 --> Language Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Loader Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Controller Class Initialized
ERROR - 2011-06-15 15:55:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 15:55:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:55:22 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:22 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:55:22 --> Final output sent to browser
DEBUG - 2011-06-15 15:55:22 --> Total execution time: 0.0300
DEBUG - 2011-06-15 15:55:22 --> Config Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:55:22 --> URI Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Router Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Output Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Input Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 15:55:22 --> Language Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Loader Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Controller Class Initialized
ERROR - 2011-06-15 15:55:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 15:55:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Model Class Initialized
DEBUG - 2011-06-15 15:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 15:55:22 --> Database Driver Class Initialized
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 15:55:22 --> Helper loaded: url_helper
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 15:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 15:55:22 --> Final output sent to browser
DEBUG - 2011-06-15 15:55:22 --> Total execution time: 0.0280
DEBUG - 2011-06-15 15:55:22 --> Final output sent to browser
DEBUG - 2011-06-15 15:55:22 --> Total execution time: 0.7587
DEBUG - 2011-06-15 15:55:23 --> Config Class Initialized
DEBUG - 2011-06-15 15:55:23 --> Hooks Class Initialized
DEBUG - 2011-06-15 15:55:23 --> Utf8 Class Initialized
DEBUG - 2011-06-15 15:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 15:55:23 --> URI Class Initialized
DEBUG - 2011-06-15 15:55:23 --> Router Class Initialized
ERROR - 2011-06-15 15:55:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 16:50:15 --> Config Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Hooks Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Utf8 Class Initialized
DEBUG - 2011-06-15 16:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 16:50:15 --> URI Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Router Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Output Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Input Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 16:50:15 --> Language Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Loader Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Controller Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Model Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Model Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Model Class Initialized
DEBUG - 2011-06-15 16:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 16:50:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 16:50:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 16:50:16 --> Helper loaded: url_helper
DEBUG - 2011-06-15 16:50:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 16:50:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 16:50:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 16:50:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 16:50:16 --> Final output sent to browser
DEBUG - 2011-06-15 16:50:16 --> Total execution time: 0.8529
DEBUG - 2011-06-15 18:04:00 --> Config Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Hooks Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Utf8 Class Initialized
DEBUG - 2011-06-15 18:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 18:04:00 --> URI Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Router Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Output Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Input Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 18:04:00 --> Language Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Loader Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Controller Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Model Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Model Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Model Class Initialized
DEBUG - 2011-06-15 18:04:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 18:04:00 --> Database Driver Class Initialized
DEBUG - 2011-06-15 18:04:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 18:04:01 --> Helper loaded: url_helper
DEBUG - 2011-06-15 18:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 18:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 18:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 18:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 18:04:01 --> Final output sent to browser
DEBUG - 2011-06-15 18:04:01 --> Total execution time: 0.5316
DEBUG - 2011-06-15 18:04:02 --> Config Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Hooks Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Utf8 Class Initialized
DEBUG - 2011-06-15 18:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 18:04:02 --> URI Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Router Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Output Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Input Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 18:04:02 --> Language Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Loader Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Controller Class Initialized
ERROR - 2011-06-15 18:04:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 18:04:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 18:04:02 --> Model Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Model Class Initialized
DEBUG - 2011-06-15 18:04:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 18:04:02 --> Database Driver Class Initialized
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 18:04:02 --> Helper loaded: url_helper
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 18:04:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 18:04:02 --> Final output sent to browser
DEBUG - 2011-06-15 18:04:02 --> Total execution time: 0.1194
DEBUG - 2011-06-15 20:54:27 --> Config Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Hooks Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Utf8 Class Initialized
DEBUG - 2011-06-15 20:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 20:54:27 --> URI Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Router Class Initialized
ERROR - 2011-06-15 20:54:27 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 20:54:27 --> Config Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Hooks Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Utf8 Class Initialized
DEBUG - 2011-06-15 20:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 20:54:27 --> URI Class Initialized
DEBUG - 2011-06-15 20:54:27 --> Router Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Output Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Input Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 20:54:28 --> Language Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Loader Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Controller Class Initialized
ERROR - 2011-06-15 20:54:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 20:54:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 20:54:28 --> Model Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Model Class Initialized
DEBUG - 2011-06-15 20:54:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 20:54:28 --> Database Driver Class Initialized
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 20:54:28 --> Helper loaded: url_helper
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 20:54:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 20:54:28 --> Final output sent to browser
DEBUG - 2011-06-15 20:54:28 --> Total execution time: 0.5460
DEBUG - 2011-06-15 20:56:15 --> Config Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Hooks Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Utf8 Class Initialized
DEBUG - 2011-06-15 20:56:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 20:56:15 --> URI Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Router Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Output Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Input Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 20:56:15 --> Language Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Loader Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Controller Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Model Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Model Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Model Class Initialized
DEBUG - 2011-06-15 20:56:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 20:56:15 --> Database Driver Class Initialized
DEBUG - 2011-06-15 20:56:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 20:56:15 --> Helper loaded: url_helper
DEBUG - 2011-06-15 20:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 20:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 20:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 20:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 20:56:15 --> Final output sent to browser
DEBUG - 2011-06-15 20:56:15 --> Total execution time: 0.4027
DEBUG - 2011-06-15 20:56:16 --> Config Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Hooks Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Utf8 Class Initialized
DEBUG - 2011-06-15 20:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 20:56:16 --> URI Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Router Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Output Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Input Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 20:56:16 --> Language Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Loader Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Controller Class Initialized
ERROR - 2011-06-15 20:56:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 20:56:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 20:56:16 --> Model Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Model Class Initialized
DEBUG - 2011-06-15 20:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 20:56:16 --> Database Driver Class Initialized
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 20:56:16 --> Helper loaded: url_helper
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 20:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 20:56:16 --> Final output sent to browser
DEBUG - 2011-06-15 20:56:16 --> Total execution time: 0.0273
DEBUG - 2011-06-15 21:11:55 --> Config Class Initialized
DEBUG - 2011-06-15 21:11:55 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:11:55 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:11:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:11:55 --> URI Class Initialized
DEBUG - 2011-06-15 21:11:55 --> Router Class Initialized
ERROR - 2011-06-15 21:11:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 21:11:56 --> Config Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:11:56 --> URI Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Router Class Initialized
DEBUG - 2011-06-15 21:11:56 --> No URI present. Default controller set.
DEBUG - 2011-06-15 21:11:56 --> Output Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Input Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 21:11:56 --> Language Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Loader Class Initialized
DEBUG - 2011-06-15 21:11:56 --> Controller Class Initialized
DEBUG - 2011-06-15 21:11:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 21:11:56 --> Helper loaded: url_helper
DEBUG - 2011-06-15 21:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 21:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 21:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 21:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 21:11:56 --> Final output sent to browser
DEBUG - 2011-06-15 21:11:56 --> Total execution time: 0.2316
DEBUG - 2011-06-15 21:19:24 --> Config Class Initialized
DEBUG - 2011-06-15 21:19:24 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:19:24 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:19:24 --> URI Class Initialized
DEBUG - 2011-06-15 21:19:24 --> Router Class Initialized
ERROR - 2011-06-15 21:19:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-15 21:20:11 --> Config Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:20:11 --> URI Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Router Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Output Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Input Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 21:20:11 --> Language Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Loader Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Controller Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Model Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Model Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Model Class Initialized
DEBUG - 2011-06-15 21:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 21:20:11 --> Database Driver Class Initialized
DEBUG - 2011-06-15 21:20:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 21:20:12 --> Helper loaded: url_helper
DEBUG - 2011-06-15 21:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 21:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 21:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 21:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 21:20:12 --> Final output sent to browser
DEBUG - 2011-06-15 21:20:12 --> Total execution time: 0.3297
DEBUG - 2011-06-15 21:22:51 --> Config Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:22:51 --> URI Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Router Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Output Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Input Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 21:22:51 --> Language Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Loader Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Controller Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Model Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Model Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Model Class Initialized
DEBUG - 2011-06-15 21:22:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 21:22:51 --> Database Driver Class Initialized
DEBUG - 2011-06-15 21:22:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 21:22:51 --> Helper loaded: url_helper
DEBUG - 2011-06-15 21:22:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 21:22:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 21:22:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 21:22:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 21:22:51 --> Final output sent to browser
DEBUG - 2011-06-15 21:22:51 --> Total execution time: 0.0427
DEBUG - 2011-06-15 21:22:56 --> Config Class Initialized
DEBUG - 2011-06-15 21:22:56 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:22:56 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:22:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:22:56 --> URI Class Initialized
DEBUG - 2011-06-15 21:22:56 --> Router Class Initialized
ERROR - 2011-06-15 21:22:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 21:22:57 --> Config Class Initialized
DEBUG - 2011-06-15 21:22:57 --> Hooks Class Initialized
DEBUG - 2011-06-15 21:22:57 --> Utf8 Class Initialized
DEBUG - 2011-06-15 21:22:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 21:22:57 --> URI Class Initialized
DEBUG - 2011-06-15 21:22:57 --> Router Class Initialized
ERROR - 2011-06-15 21:22:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-15 22:38:33 --> Config Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Hooks Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Utf8 Class Initialized
DEBUG - 2011-06-15 22:38:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 22:38:33 --> URI Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Router Class Initialized
DEBUG - 2011-06-15 22:38:33 --> No URI present. Default controller set.
DEBUG - 2011-06-15 22:38:33 --> Output Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Input Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 22:38:33 --> Language Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Loader Class Initialized
DEBUG - 2011-06-15 22:38:33 --> Controller Class Initialized
DEBUG - 2011-06-15 22:38:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-15 22:38:33 --> Helper loaded: url_helper
DEBUG - 2011-06-15 22:38:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 22:38:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 22:38:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 22:38:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 22:38:33 --> Final output sent to browser
DEBUG - 2011-06-15 22:38:33 --> Total execution time: 0.3153
DEBUG - 2011-06-15 22:46:59 --> Config Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Hooks Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Utf8 Class Initialized
DEBUG - 2011-06-15 22:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 22:46:59 --> URI Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Router Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Output Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Input Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 22:46:59 --> Language Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Loader Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Controller Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Model Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Model Class Initialized
DEBUG - 2011-06-15 22:46:59 --> Model Class Initialized
DEBUG - 2011-06-15 22:47:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 22:47:00 --> Database Driver Class Initialized
DEBUG - 2011-06-15 22:47:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 22:47:00 --> Helper loaded: url_helper
DEBUG - 2011-06-15 22:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 22:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 22:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 22:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 22:47:00 --> Final output sent to browser
DEBUG - 2011-06-15 22:47:00 --> Total execution time: 0.4275
DEBUG - 2011-06-15 22:47:01 --> Config Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Hooks Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Utf8 Class Initialized
DEBUG - 2011-06-15 22:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 22:47:01 --> URI Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Router Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Output Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Input Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 22:47:01 --> Language Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Loader Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Controller Class Initialized
ERROR - 2011-06-15 22:47:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 22:47:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 22:47:01 --> Model Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Model Class Initialized
DEBUG - 2011-06-15 22:47:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 22:47:01 --> Database Driver Class Initialized
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 22:47:01 --> Helper loaded: url_helper
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 22:47:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 22:47:01 --> Final output sent to browser
DEBUG - 2011-06-15 22:47:01 --> Total execution time: 0.1403
DEBUG - 2011-06-15 23:41:32 --> Config Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Hooks Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Utf8 Class Initialized
DEBUG - 2011-06-15 23:41:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 23:41:32 --> URI Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Router Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Output Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Input Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 23:41:32 --> Language Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Loader Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Controller Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Model Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Model Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Model Class Initialized
DEBUG - 2011-06-15 23:41:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 23:41:32 --> Database Driver Class Initialized
DEBUG - 2011-06-15 23:41:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-15 23:41:33 --> Helper loaded: url_helper
DEBUG - 2011-06-15 23:41:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 23:41:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 23:41:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 23:41:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 23:41:33 --> Final output sent to browser
DEBUG - 2011-06-15 23:41:33 --> Total execution time: 0.6388
DEBUG - 2011-06-15 23:41:33 --> Config Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Hooks Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Utf8 Class Initialized
DEBUG - 2011-06-15 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-15 23:41:33 --> URI Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Router Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Output Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Input Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-15 23:41:33 --> Language Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Loader Class Initialized
DEBUG - 2011-06-15 23:41:33 --> Controller Class Initialized
ERROR - 2011-06-15 23:41:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-15 23:41:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 23:41:34 --> Model Class Initialized
DEBUG - 2011-06-15 23:41:34 --> Model Class Initialized
DEBUG - 2011-06-15 23:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-15 23:41:34 --> Database Driver Class Initialized
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-15 23:41:34 --> Helper loaded: url_helper
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-15 23:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-15 23:41:34 --> Final output sent to browser
DEBUG - 2011-06-15 23:41:34 --> Total execution time: 0.0902

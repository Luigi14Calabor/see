<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-29 00:08:46 --> Config Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:08:46 --> URI Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Router Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Output Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Input Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:08:46 --> Language Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Loader Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Controller Class Initialized
ERROR - 2011-09-29 00:08:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:08:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:08:46 --> Model Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Model Class Initialized
DEBUG - 2011-09-29 00:08:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:08:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:08:46 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:08:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:08:46 --> Final output sent to browser
DEBUG - 2011-09-29 00:08:46 --> Total execution time: 0.4278
DEBUG - 2011-09-29 00:08:48 --> Config Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:08:48 --> URI Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Router Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Output Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Input Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:08:48 --> Language Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Loader Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Controller Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Model Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Model Class Initialized
DEBUG - 2011-09-29 00:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:08:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:08:49 --> Final output sent to browser
DEBUG - 2011-09-29 00:08:49 --> Total execution time: 0.6341
DEBUG - 2011-09-29 00:08:51 --> Config Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:08:51 --> URI Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Router Class Initialized
ERROR - 2011-09-29 00:08:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:08:51 --> Config Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:08:51 --> URI Class Initialized
DEBUG - 2011-09-29 00:08:51 --> Router Class Initialized
ERROR - 2011-09-29 00:08:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:15:16 --> Config Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:15:16 --> URI Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Router Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Output Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Input Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:15:16 --> Language Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Loader Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Controller Class Initialized
ERROR - 2011-09-29 00:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:15:16 --> Model Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Model Class Initialized
DEBUG - 2011-09-29 00:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:15:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:15:16 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:15:16 --> Final output sent to browser
DEBUG - 2011-09-29 00:15:16 --> Total execution time: 0.0736
DEBUG - 2011-09-29 00:15:34 --> Config Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:15:34 --> URI Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Router Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Output Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Input Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:15:34 --> Language Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Loader Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Controller Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Model Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Model Class Initialized
DEBUG - 2011-09-29 00:15:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:15:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:15:35 --> Final output sent to browser
DEBUG - 2011-09-29 00:15:35 --> Total execution time: 0.6326
DEBUG - 2011-09-29 00:16:44 --> Config Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:16:44 --> URI Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Router Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Output Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Input Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:16:44 --> Language Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Loader Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Controller Class Initialized
ERROR - 2011-09-29 00:16:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:16:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:16:44 --> Model Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Model Class Initialized
DEBUG - 2011-09-29 00:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:16:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:16:44 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:16:44 --> Final output sent to browser
DEBUG - 2011-09-29 00:16:44 --> Total execution time: 0.0320
DEBUG - 2011-09-29 00:16:51 --> Config Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:16:51 --> URI Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Router Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Output Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Input Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:16:51 --> Language Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Loader Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Controller Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Model Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Model Class Initialized
DEBUG - 2011-09-29 00:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:16:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:16:52 --> Final output sent to browser
DEBUG - 2011-09-29 00:16:52 --> Total execution time: 0.5643
DEBUG - 2011-09-29 00:26:04 --> Config Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:26:04 --> URI Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Router Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Output Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Input Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:26:04 --> Language Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Loader Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Controller Class Initialized
ERROR - 2011-09-29 00:26:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:26:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:26:04 --> Model Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Model Class Initialized
DEBUG - 2011-09-29 00:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:26:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:26:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:26:04 --> Final output sent to browser
DEBUG - 2011-09-29 00:26:04 --> Total execution time: 0.0711
DEBUG - 2011-09-29 00:26:06 --> Config Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:26:06 --> URI Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Router Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Output Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Input Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:26:06 --> Language Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Loader Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Controller Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:26:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:26:06 --> Final output sent to browser
DEBUG - 2011-09-29 00:26:06 --> Total execution time: 0.5708
DEBUG - 2011-09-29 00:26:09 --> Config Class Initialized
DEBUG - 2011-09-29 00:26:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:26:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:26:09 --> URI Class Initialized
DEBUG - 2011-09-29 00:26:09 --> Router Class Initialized
ERROR - 2011-09-29 00:26:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:28:48 --> Config Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:28:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:28:48 --> URI Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Router Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Output Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Input Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:28:48 --> Language Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Loader Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Controller Class Initialized
ERROR - 2011-09-29 00:28:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:28:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:28:48 --> Model Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Model Class Initialized
DEBUG - 2011-09-29 00:28:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:28:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:28:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:28:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:28:48 --> Final output sent to browser
DEBUG - 2011-09-29 00:28:48 --> Total execution time: 0.0337
DEBUG - 2011-09-29 00:28:49 --> Config Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:28:49 --> URI Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Router Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Output Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Input Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:28:49 --> Language Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Loader Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Controller Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Model Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Model Class Initialized
DEBUG - 2011-09-29 00:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:28:49 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:28:50 --> Final output sent to browser
DEBUG - 2011-09-29 00:28:50 --> Total execution time: 0.7578
DEBUG - 2011-09-29 00:28:51 --> Config Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:28:51 --> URI Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Router Class Initialized
ERROR - 2011-09-29 00:28:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:28:51 --> Config Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:28:51 --> URI Class Initialized
DEBUG - 2011-09-29 00:28:51 --> Router Class Initialized
ERROR - 2011-09-29 00:28:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:28:52 --> Config Class Initialized
DEBUG - 2011-09-29 00:28:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:28:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:28:52 --> URI Class Initialized
DEBUG - 2011-09-29 00:28:52 --> Router Class Initialized
ERROR - 2011-09-29 00:28:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:29:16 --> Config Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:29:16 --> URI Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Router Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Output Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Input Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:29:16 --> Language Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Loader Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Controller Class Initialized
ERROR - 2011-09-29 00:29:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:29:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:29:16 --> Model Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Model Class Initialized
DEBUG - 2011-09-29 00:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:29:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:29:16 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:29:16 --> Final output sent to browser
DEBUG - 2011-09-29 00:29:16 --> Total execution time: 0.0346
DEBUG - 2011-09-29 00:29:17 --> Config Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:29:17 --> URI Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Router Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Output Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Input Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:29:17 --> Language Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Loader Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Controller Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Model Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Model Class Initialized
DEBUG - 2011-09-29 00:29:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:29:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:29:18 --> Final output sent to browser
DEBUG - 2011-09-29 00:29:18 --> Total execution time: 0.7470
DEBUG - 2011-09-29 00:31:06 --> Config Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:31:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:31:06 --> URI Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Router Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Output Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Input Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:31:06 --> Language Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Loader Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Controller Class Initialized
ERROR - 2011-09-29 00:31:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:31:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:31:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:31:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:31:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:31:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:31:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:31:06 --> Final output sent to browser
DEBUG - 2011-09-29 00:31:06 --> Total execution time: 0.0732
DEBUG - 2011-09-29 00:31:13 --> Config Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:31:13 --> URI Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Router Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Output Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Input Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:31:13 --> Language Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Loader Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Controller Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:31:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:31:13 --> Final output sent to browser
DEBUG - 2011-09-29 00:31:13 --> Total execution time: 0.6791
DEBUG - 2011-09-29 00:32:02 --> Config Class Initialized
DEBUG - 2011-09-29 00:32:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:32:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:32:02 --> URI Class Initialized
DEBUG - 2011-09-29 00:32:02 --> Router Class Initialized
ERROR - 2011-09-29 00:32:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:34:08 --> Config Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:34:08 --> URI Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Router Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Output Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Input Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:34:08 --> Language Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Loader Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Controller Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Model Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Model Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Model Class Initialized
DEBUG - 2011-09-29 00:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:34:08 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:34:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 00:34:08 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:34:08 --> Final output sent to browser
DEBUG - 2011-09-29 00:34:08 --> Total execution time: 0.3671
DEBUG - 2011-09-29 00:34:12 --> Config Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:34:12 --> URI Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Router Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Output Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Input Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:34:12 --> Language Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Loader Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Controller Class Initialized
ERROR - 2011-09-29 00:34:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:34:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:34:12 --> Model Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Model Class Initialized
DEBUG - 2011-09-29 00:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:34:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:34:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:34:12 --> Final output sent to browser
DEBUG - 2011-09-29 00:34:12 --> Total execution time: 0.0315
DEBUG - 2011-09-29 00:37:12 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:12 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Router Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Output Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Input Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:37:12 --> Language Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Loader Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Controller Class Initialized
ERROR - 2011-09-29 00:37:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:37:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:37:12 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:37:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:37:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:37:12 --> Final output sent to browser
DEBUG - 2011-09-29 00:37:12 --> Total execution time: 0.1280
DEBUG - 2011-09-29 00:37:19 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:19 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Router Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Output Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Input Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:37:19 --> Language Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Loader Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Controller Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:37:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:37:20 --> Final output sent to browser
DEBUG - 2011-09-29 00:37:20 --> Total execution time: 0.5279
DEBUG - 2011-09-29 00:37:26 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:26 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:26 --> Router Class Initialized
ERROR - 2011-09-29 00:37:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:37:28 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:28 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:28 --> Router Class Initialized
ERROR - 2011-09-29 00:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:37:54 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:54 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Router Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Output Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Input Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:37:54 --> Language Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Loader Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Controller Class Initialized
ERROR - 2011-09-29 00:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:37:54 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:37:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:37:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:37:54 --> Final output sent to browser
DEBUG - 2011-09-29 00:37:54 --> Total execution time: 0.0676
DEBUG - 2011-09-29 00:37:55 --> Config Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:37:55 --> URI Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Router Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Output Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Input Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:37:55 --> Language Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Loader Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Controller Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Model Class Initialized
DEBUG - 2011-09-29 00:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:37:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:37:56 --> Final output sent to browser
DEBUG - 2011-09-29 00:37:56 --> Total execution time: 0.5966
DEBUG - 2011-09-29 00:38:00 --> Config Class Initialized
DEBUG - 2011-09-29 00:38:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:38:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:38:00 --> URI Class Initialized
DEBUG - 2011-09-29 00:38:00 --> Router Class Initialized
ERROR - 2011-09-29 00:38:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:38:09 --> Config Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:38:09 --> URI Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Router Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Output Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Input Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:38:09 --> Language Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Loader Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Controller Class Initialized
ERROR - 2011-09-29 00:38:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:38:09 --> Model Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Model Class Initialized
DEBUG - 2011-09-29 00:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:38:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:38:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:38:09 --> Final output sent to browser
DEBUG - 2011-09-29 00:38:09 --> Total execution time: 0.0564
DEBUG - 2011-09-29 00:38:11 --> Config Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:38:11 --> URI Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Router Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Output Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Input Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:38:11 --> Language Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Loader Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Controller Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Model Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Model Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:38:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:38:11 --> Final output sent to browser
DEBUG - 2011-09-29 00:38:11 --> Total execution time: 0.6078
DEBUG - 2011-09-29 00:38:16 --> Config Class Initialized
DEBUG - 2011-09-29 00:38:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:38:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:38:16 --> URI Class Initialized
DEBUG - 2011-09-29 00:38:16 --> Router Class Initialized
ERROR - 2011-09-29 00:38:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:39:20 --> Config Class Initialized
DEBUG - 2011-09-29 00:39:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:39:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:39:20 --> URI Class Initialized
DEBUG - 2011-09-29 00:39:20 --> Router Class Initialized
ERROR - 2011-09-29 00:39:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:46:13 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:13 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Router Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Output Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Input Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:46:13 --> Language Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Loader Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Controller Class Initialized
ERROR - 2011-09-29 00:46:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:46:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:46:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:46:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:46:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:46:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:46:13 --> Final output sent to browser
DEBUG - 2011-09-29 00:46:13 --> Total execution time: 0.0394
DEBUG - 2011-09-29 00:46:14 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:14 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Router Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Output Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Input Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:46:14 --> Language Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Loader Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Controller Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:46:14 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:46:15 --> Final output sent to browser
DEBUG - 2011-09-29 00:46:15 --> Total execution time: 0.6294
DEBUG - 2011-09-29 00:46:17 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:17 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Router Class Initialized
ERROR - 2011-09-29 00:46:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:46:17 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:17 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:17 --> Router Class Initialized
ERROR - 2011-09-29 00:46:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:46:45 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:45 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Router Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Output Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Input Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:46:45 --> Language Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Loader Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Controller Class Initialized
ERROR - 2011-09-29 00:46:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:46:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:46:45 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:46:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:46:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:46:45 --> Final output sent to browser
DEBUG - 2011-09-29 00:46:45 --> Total execution time: 0.0608
DEBUG - 2011-09-29 00:46:46 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:46 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Router Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Output Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Input Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:46:46 --> Language Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Loader Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Controller Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Model Class Initialized
DEBUG - 2011-09-29 00:46:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:46:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:46:47 --> Final output sent to browser
DEBUG - 2011-09-29 00:46:47 --> Total execution time: 0.8312
DEBUG - 2011-09-29 00:46:48 --> Config Class Initialized
DEBUG - 2011-09-29 00:46:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:46:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:46:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:46:48 --> URI Class Initialized
DEBUG - 2011-09-29 00:46:48 --> Router Class Initialized
ERROR - 2011-09-29 00:46:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 00:50:03 --> Config Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:50:03 --> URI Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Router Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Output Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Input Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:50:03 --> Language Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Loader Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Controller Class Initialized
ERROR - 2011-09-29 00:50:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:50:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:50:03 --> Model Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Model Class Initialized
DEBUG - 2011-09-29 00:50:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:50:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:50:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:50:04 --> Final output sent to browser
DEBUG - 2011-09-29 00:50:04 --> Total execution time: 0.1467
DEBUG - 2011-09-29 00:50:13 --> Config Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:50:13 --> URI Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Router Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Output Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Input Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:50:13 --> Language Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Loader Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Controller Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Model Class Initialized
DEBUG - 2011-09-29 00:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:50:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:50:15 --> Final output sent to browser
DEBUG - 2011-09-29 00:50:15 --> Total execution time: 1.7520
DEBUG - 2011-09-29 00:51:04 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:04 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:04 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Controller Class Initialized
ERROR - 2011-09-29 00:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:04 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:51:04 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:04 --> Total execution time: 0.0313
DEBUG - 2011-09-29 00:51:06 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:06 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:06 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Controller Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:06 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:06 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Controller Class Initialized
ERROR - 2011-09-29 00:51:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:51:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:51:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:51:06 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:06 --> Total execution time: 0.0340
DEBUG - 2011-09-29 00:51:07 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:07 --> Total execution time: 0.5887
DEBUG - 2011-09-29 00:51:20 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:20 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:20 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Controller Class Initialized
ERROR - 2011-09-29 00:51:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:51:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:20 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:51:20 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:20 --> Total execution time: 0.0312
DEBUG - 2011-09-29 00:51:22 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:22 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:22 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Controller Class Initialized
ERROR - 2011-09-29 00:51:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:51:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:22 --> Config Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:51:22 --> URI Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Router Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Output Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Input Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:51:22 --> Language Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Loader Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Controller Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:22 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Model Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:51:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:51:22 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:51:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:51:22 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:22 --> Total execution time: 0.0850
DEBUG - 2011-09-29 00:51:22 --> Final output sent to browser
DEBUG - 2011-09-29 00:51:22 --> Total execution time: 0.5508
DEBUG - 2011-09-29 00:54:56 --> Config Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:54:56 --> URI Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Router Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Output Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Input Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:54:56 --> Language Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Loader Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Controller Class Initialized
ERROR - 2011-09-29 00:54:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 00:54:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:54:56 --> Model Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Model Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:54:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 00:54:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 00:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 00:54:56 --> Final output sent to browser
DEBUG - 2011-09-29 00:54:56 --> Total execution time: 0.0327
DEBUG - 2011-09-29 00:54:56 --> Config Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:54:56 --> URI Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Router Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Output Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Input Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 00:54:56 --> Language Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Loader Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Controller Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Model Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Model Class Initialized
DEBUG - 2011-09-29 00:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 00:54:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 00:54:57 --> Final output sent to browser
DEBUG - 2011-09-29 00:54:57 --> Total execution time: 0.5972
DEBUG - 2011-09-29 00:54:58 --> Config Class Initialized
DEBUG - 2011-09-29 00:54:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 00:54:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 00:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 00:54:58 --> URI Class Initialized
DEBUG - 2011-09-29 00:54:58 --> Router Class Initialized
ERROR - 2011-09-29 00:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:04:54 --> Config Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:04:54 --> URI Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Router Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Output Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Input Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:04:54 --> Language Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Loader Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Controller Class Initialized
ERROR - 2011-09-29 01:04:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:04:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:04:54 --> Model Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Model Class Initialized
DEBUG - 2011-09-29 01:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:04:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:04:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:04:54 --> Final output sent to browser
DEBUG - 2011-09-29 01:04:54 --> Total execution time: 0.0329
DEBUG - 2011-09-29 01:04:55 --> Config Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:04:55 --> URI Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Router Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Output Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Input Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:04:55 --> Language Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Loader Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Controller Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Model Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Model Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:04:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:04:55 --> Final output sent to browser
DEBUG - 2011-09-29 01:04:55 --> Total execution time: 0.6771
DEBUG - 2011-09-29 01:04:57 --> Config Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:04:57 --> URI Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Router Class Initialized
ERROR - 2011-09-29 01:04:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:04:57 --> Config Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:04:57 --> URI Class Initialized
DEBUG - 2011-09-29 01:04:57 --> Router Class Initialized
ERROR - 2011-09-29 01:04:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:05:31 --> Config Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:05:31 --> URI Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Router Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Output Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Input Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:05:31 --> Language Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Loader Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Controller Class Initialized
ERROR - 2011-09-29 01:05:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:05:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:05:31 --> Model Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Model Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:05:31 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:05:31 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:05:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:05:31 --> Final output sent to browser
DEBUG - 2011-09-29 01:05:31 --> Total execution time: 0.0319
DEBUG - 2011-09-29 01:05:31 --> Config Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:05:31 --> URI Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Router Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Output Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Input Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:05:31 --> Language Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Loader Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Controller Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Model Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Model Class Initialized
DEBUG - 2011-09-29 01:05:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:05:31 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:05:32 --> Final output sent to browser
DEBUG - 2011-09-29 01:05:32 --> Total execution time: 0.6464
DEBUG - 2011-09-29 01:06:19 --> Config Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:06:19 --> URI Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Router Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Output Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Input Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:06:19 --> Language Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Loader Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Controller Class Initialized
ERROR - 2011-09-29 01:06:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:06:19 --> Model Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Model Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:06:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:06:19 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:06:19 --> Final output sent to browser
DEBUG - 2011-09-29 01:06:19 --> Total execution time: 0.0752
DEBUG - 2011-09-29 01:06:19 --> Config Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:06:19 --> URI Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Router Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Output Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Input Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:06:19 --> Language Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Loader Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Controller Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Model Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Model Class Initialized
DEBUG - 2011-09-29 01:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:06:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:06:20 --> Final output sent to browser
DEBUG - 2011-09-29 01:06:20 --> Total execution time: 0.6491
DEBUG - 2011-09-29 01:08:32 --> Config Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:08:32 --> URI Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Router Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Output Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Input Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:08:32 --> Language Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Loader Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Controller Class Initialized
ERROR - 2011-09-29 01:08:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:08:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:08:32 --> Model Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Model Class Initialized
DEBUG - 2011-09-29 01:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:08:32 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:08:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:08:32 --> Final output sent to browser
DEBUG - 2011-09-29 01:08:32 --> Total execution time: 0.0742
DEBUG - 2011-09-29 01:08:38 --> Config Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:08:38 --> URI Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Router Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Output Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Input Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:08:38 --> Language Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Loader Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Controller Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Model Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Model Class Initialized
DEBUG - 2011-09-29 01:08:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:08:38 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:08:39 --> Final output sent to browser
DEBUG - 2011-09-29 01:08:39 --> Total execution time: 0.6081
DEBUG - 2011-09-29 01:08:47 --> Config Class Initialized
DEBUG - 2011-09-29 01:08:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:08:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:08:47 --> URI Class Initialized
DEBUG - 2011-09-29 01:08:47 --> Router Class Initialized
ERROR - 2011-09-29 01:08:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:09:57 --> Config Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:09:57 --> URI Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Router Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Output Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Input Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:09:57 --> Language Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Loader Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Controller Class Initialized
ERROR - 2011-09-29 01:09:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:09:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:09:57 --> Model Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Model Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:09:57 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:09:57 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:09:57 --> Final output sent to browser
DEBUG - 2011-09-29 01:09:57 --> Total execution time: 0.0330
DEBUG - 2011-09-29 01:09:57 --> Config Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:09:57 --> URI Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Router Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Output Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Input Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:09:57 --> Language Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Loader Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Controller Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Model Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Model Class Initialized
DEBUG - 2011-09-29 01:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:09:57 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:09:58 --> Final output sent to browser
DEBUG - 2011-09-29 01:09:58 --> Total execution time: 0.5710
DEBUG - 2011-09-29 01:14:42 --> Config Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:14:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:14:42 --> URI Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Router Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Output Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Input Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:14:42 --> Language Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Loader Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Controller Class Initialized
ERROR - 2011-09-29 01:14:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:14:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:14:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:14:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:14:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:14:42 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:14:42 --> Final output sent to browser
DEBUG - 2011-09-29 01:14:42 --> Total execution time: 0.0436
DEBUG - 2011-09-29 01:14:44 --> Config Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:14:44 --> URI Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Router Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Output Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Input Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:14:44 --> Language Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Loader Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Controller Class Initialized
ERROR - 2011-09-29 01:14:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:14:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:14:44 --> Model Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Model Class Initialized
DEBUG - 2011-09-29 01:14:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:14:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:14:44 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:14:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:14:44 --> Final output sent to browser
DEBUG - 2011-09-29 01:14:44 --> Total execution time: 0.0332
DEBUG - 2011-09-29 01:14:46 --> Config Class Initialized
DEBUG - 2011-09-29 01:14:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:14:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:14:46 --> URI Class Initialized
DEBUG - 2011-09-29 01:14:46 --> Router Class Initialized
ERROR - 2011-09-29 01:14:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:16:13 --> Config Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:16:13 --> URI Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Router Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Output Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Input Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:16:13 --> Language Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Loader Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Controller Class Initialized
ERROR - 2011-09-29 01:16:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:16:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:16:13 --> Model Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Model Class Initialized
DEBUG - 2011-09-29 01:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:16:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:16:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:16:13 --> Final output sent to browser
DEBUG - 2011-09-29 01:16:13 --> Total execution time: 0.0982
DEBUG - 2011-09-29 01:16:15 --> Config Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:16:15 --> URI Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Router Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Output Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Input Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:16:15 --> Language Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Loader Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Controller Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:16:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:16:15 --> Final output sent to browser
DEBUG - 2011-09-29 01:16:15 --> Total execution time: 0.5490
DEBUG - 2011-09-29 01:16:17 --> Config Class Initialized
DEBUG - 2011-09-29 01:16:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:16:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:16:17 --> URI Class Initialized
DEBUG - 2011-09-29 01:16:17 --> Router Class Initialized
ERROR - 2011-09-29 01:16:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:17:48 --> Config Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:17:48 --> URI Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Router Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Output Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Input Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:17:48 --> Language Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Loader Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Controller Class Initialized
ERROR - 2011-09-29 01:17:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:17:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:17:48 --> Model Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Model Class Initialized
DEBUG - 2011-09-29 01:17:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:17:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:17:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:17:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:17:48 --> Final output sent to browser
DEBUG - 2011-09-29 01:17:48 --> Total execution time: 0.0345
DEBUG - 2011-09-29 01:31:45 --> Config Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:31:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:31:45 --> URI Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Router Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Output Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Input Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:31:45 --> Language Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Loader Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Controller Class Initialized
ERROR - 2011-09-29 01:31:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:31:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:31:45 --> Model Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Model Class Initialized
DEBUG - 2011-09-29 01:31:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:31:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:31:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:31:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:31:45 --> Final output sent to browser
DEBUG - 2011-09-29 01:31:45 --> Total execution time: 0.0338
DEBUG - 2011-09-29 01:31:46 --> Config Class Initialized
DEBUG - 2011-09-29 01:31:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:31:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:31:46 --> URI Class Initialized
DEBUG - 2011-09-29 01:31:46 --> Router Class Initialized
ERROR - 2011-09-29 01:31:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:31:47 --> Config Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:31:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:31:47 --> URI Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Router Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Output Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Input Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:31:47 --> Language Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Loader Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Controller Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Model Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Model Class Initialized
DEBUG - 2011-09-29 01:31:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:31:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:31:48 --> Final output sent to browser
DEBUG - 2011-09-29 01:31:48 --> Total execution time: 0.7227
DEBUG - 2011-09-29 01:32:48 --> Config Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:32:48 --> URI Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Router Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Output Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Input Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:32:48 --> Language Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Loader Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Controller Class Initialized
ERROR - 2011-09-29 01:32:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:32:48 --> Model Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Model Class Initialized
DEBUG - 2011-09-29 01:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:32:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:32:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:32:48 --> Final output sent to browser
DEBUG - 2011-09-29 01:32:48 --> Total execution time: 0.0368
DEBUG - 2011-09-29 01:32:49 --> Config Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:32:49 --> URI Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Router Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Output Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Input Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:32:49 --> Language Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Loader Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Controller Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Model Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Model Class Initialized
DEBUG - 2011-09-29 01:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:32:49 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:32:50 --> Final output sent to browser
DEBUG - 2011-09-29 01:32:50 --> Total execution time: 0.5914
DEBUG - 2011-09-29 01:32:52 --> Config Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:32:52 --> URI Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Router Class Initialized
ERROR - 2011-09-29 01:32:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:32:52 --> Config Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:32:52 --> URI Class Initialized
DEBUG - 2011-09-29 01:32:52 --> Router Class Initialized
ERROR - 2011-09-29 01:32:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 01:33:04 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:04 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:04 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Controller Class Initialized
ERROR - 2011-09-29 01:33:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:33:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:04 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:33:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:33:04 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:04 --> Total execution time: 0.2059
DEBUG - 2011-09-29 01:33:05 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:05 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:05 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Controller Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:06 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:06 --> Total execution time: 0.7273
DEBUG - 2011-09-29 01:33:15 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:15 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:15 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Controller Class Initialized
ERROR - 2011-09-29 01:33:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:33:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:15 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:33:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:33:15 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:15 --> Total execution time: 0.0329
DEBUG - 2011-09-29 01:33:16 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:16 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:16 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Controller Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:17 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:17 --> Total execution time: 0.9107
DEBUG - 2011-09-29 01:33:25 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:25 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:25 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Controller Class Initialized
ERROR - 2011-09-29 01:33:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:33:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:25 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:25 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:25 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:33:25 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:25 --> Total execution time: 0.0382
DEBUG - 2011-09-29 01:33:26 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:26 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:26 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Controller Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:26 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:27 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:27 --> Total execution time: 1.0199
DEBUG - 2011-09-29 01:33:42 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:42 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:42 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Controller Class Initialized
ERROR - 2011-09-29 01:33:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:33:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:42 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:33:42 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:42 --> Total execution time: 0.0674
DEBUG - 2011-09-29 01:33:43 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:43 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:43 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Controller Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:43 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:44 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:44 --> Total execution time: 0.8398
DEBUG - 2011-09-29 01:33:59 --> Config Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:33:59 --> URI Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Router Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Output Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Input Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:33:59 --> Language Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Loader Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Controller Class Initialized
ERROR - 2011-09-29 01:33:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:59 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Model Class Initialized
DEBUG - 2011-09-29 01:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:33:59 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:33:59 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:33:59 --> Final output sent to browser
DEBUG - 2011-09-29 01:33:59 --> Total execution time: 0.0522
DEBUG - 2011-09-29 01:34:00 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:00 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:00 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Controller Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:00 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:00 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:00 --> Total execution time: 0.5369
DEBUG - 2011-09-29 01:34:13 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:13 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:13 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Controller Class Initialized
ERROR - 2011-09-29 01:34:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:34:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:13 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:34:13 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:13 --> Total execution time: 0.0333
DEBUG - 2011-09-29 01:34:15 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:15 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:15 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Controller Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:15 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:15 --> Total execution time: 0.6171
DEBUG - 2011-09-29 01:34:26 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:26 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:26 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Controller Class Initialized
ERROR - 2011-09-29 01:34:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:34:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:34:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:26 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:34:27 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:27 --> Total execution time: 0.1556
DEBUG - 2011-09-29 01:34:27 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:27 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:27 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Controller Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:28 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:28 --> Total execution time: 0.5903
DEBUG - 2011-09-29 01:34:42 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:42 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:42 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Controller Class Initialized
ERROR - 2011-09-29 01:34:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:34:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:34:42 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:34:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:34:42 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:42 --> Total execution time: 0.0398
DEBUG - 2011-09-29 01:34:44 --> Config Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:34:44 --> URI Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Router Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Output Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Input Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:34:44 --> Language Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Loader Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Controller Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Model Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:34:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:34:44 --> Final output sent to browser
DEBUG - 2011-09-29 01:34:44 --> Total execution time: 0.5899
DEBUG - 2011-09-29 01:59:52 --> Config Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:59:52 --> URI Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Router Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Output Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Input Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:59:52 --> Language Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Loader Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Controller Class Initialized
ERROR - 2011-09-29 01:59:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 01:59:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 01:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:59:52 --> Model Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Model Class Initialized
DEBUG - 2011-09-29 01:59:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:59:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:59:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 01:59:55 --> Helper loaded: url_helper
DEBUG - 2011-09-29 01:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 01:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 01:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 01:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 01:59:55 --> Final output sent to browser
DEBUG - 2011-09-29 01:59:55 --> Total execution time: 2.3885
DEBUG - 2011-09-29 01:59:56 --> Config Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:59:56 --> URI Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Router Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Output Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Input Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 01:59:56 --> Language Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Loader Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Controller Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Model Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Model Class Initialized
DEBUG - 2011-09-29 01:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 01:59:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 01:59:57 --> Final output sent to browser
DEBUG - 2011-09-29 01:59:57 --> Total execution time: 0.8151
DEBUG - 2011-09-29 01:59:58 --> Config Class Initialized
DEBUG - 2011-09-29 01:59:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 01:59:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 01:59:58 --> URI Class Initialized
DEBUG - 2011-09-29 01:59:58 --> Router Class Initialized
ERROR - 2011-09-29 01:59:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 02:02:34 --> Config Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:02:34 --> URI Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Router Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Output Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Input Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:02:34 --> Language Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Loader Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Controller Class Initialized
ERROR - 2011-09-29 02:02:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 02:02:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:02:34 --> Model Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Model Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:02:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:02:34 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:02:34 --> Final output sent to browser
DEBUG - 2011-09-29 02:02:34 --> Total execution time: 0.0466
DEBUG - 2011-09-29 02:02:34 --> Config Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:02:34 --> URI Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Router Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Output Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Input Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:02:34 --> Language Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Loader Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Controller Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Model Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Model Class Initialized
DEBUG - 2011-09-29 02:02:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:02:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:02:35 --> Final output sent to browser
DEBUG - 2011-09-29 02:02:35 --> Total execution time: 0.6377
DEBUG - 2011-09-29 02:07:55 --> Config Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:07:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:07:55 --> URI Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Router Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Output Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Input Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:07:55 --> Language Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Loader Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Controller Class Initialized
ERROR - 2011-09-29 02:07:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 02:07:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Model Class Initialized
DEBUG - 2011-09-29 02:07:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:07:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:07:55 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:07:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:07:55 --> Final output sent to browser
DEBUG - 2011-09-29 02:07:55 --> Total execution time: 0.0630
DEBUG - 2011-09-29 02:07:56 --> Config Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:07:56 --> URI Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Router Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Output Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Input Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:07:56 --> Language Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Loader Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Controller Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Model Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Model Class Initialized
DEBUG - 2011-09-29 02:07:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:07:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:07:57 --> Final output sent to browser
DEBUG - 2011-09-29 02:07:57 --> Total execution time: 1.0461
DEBUG - 2011-09-29 02:07:58 --> Config Class Initialized
DEBUG - 2011-09-29 02:07:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:07:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:07:58 --> URI Class Initialized
DEBUG - 2011-09-29 02:07:58 --> Router Class Initialized
ERROR - 2011-09-29 02:07:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 02:08:26 --> Config Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:08:26 --> URI Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Router Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Output Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Input Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:08:26 --> Language Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Loader Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Controller Class Initialized
ERROR - 2011-09-29 02:08:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 02:08:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:08:26 --> Model Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Model Class Initialized
DEBUG - 2011-09-29 02:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:08:26 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:08:26 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:08:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:08:26 --> Final output sent to browser
DEBUG - 2011-09-29 02:08:26 --> Total execution time: 0.0981
DEBUG - 2011-09-29 02:08:27 --> Config Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:08:27 --> URI Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Router Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Output Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Input Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:08:27 --> Language Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Loader Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Controller Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Model Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Model Class Initialized
DEBUG - 2011-09-29 02:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:08:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:08:28 --> Final output sent to browser
DEBUG - 2011-09-29 02:08:28 --> Total execution time: 0.7358
DEBUG - 2011-09-29 02:08:29 --> Config Class Initialized
DEBUG - 2011-09-29 02:08:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:08:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:08:29 --> URI Class Initialized
DEBUG - 2011-09-29 02:08:29 --> Router Class Initialized
ERROR - 2011-09-29 02:08:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 02:11:44 --> Config Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:11:44 --> URI Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Router Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Output Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Input Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:11:44 --> Language Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Loader Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Controller Class Initialized
ERROR - 2011-09-29 02:11:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 02:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:11:44 --> Model Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Model Class Initialized
DEBUG - 2011-09-29 02:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:11:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:11:44 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:11:44 --> Final output sent to browser
DEBUG - 2011-09-29 02:11:44 --> Total execution time: 0.0461
DEBUG - 2011-09-29 02:11:51 --> Config Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:11:51 --> URI Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Router Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Output Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Input Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:11:51 --> Language Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Loader Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Controller Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Model Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Model Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:11:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:11:51 --> Final output sent to browser
DEBUG - 2011-09-29 02:11:51 --> Total execution time: 0.5696
DEBUG - 2011-09-29 02:19:44 --> Config Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:19:44 --> URI Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Router Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Output Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Input Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:19:44 --> Language Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Loader Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Controller Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Model Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Model Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Model Class Initialized
DEBUG - 2011-09-29 02:19:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:19:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:19:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 02:19:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:19:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:19:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:19:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:19:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:19:45 --> Final output sent to browser
DEBUG - 2011-09-29 02:19:45 --> Total execution time: 1.3553
DEBUG - 2011-09-29 02:20:08 --> Config Class Initialized
DEBUG - 2011-09-29 02:20:08 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:20:08 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:20:08 --> URI Class Initialized
DEBUG - 2011-09-29 02:20:08 --> Router Class Initialized
ERROR - 2011-09-29 02:20:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 02:21:02 --> Config Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:21:02 --> URI Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Router Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Output Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Input Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:21:02 --> Language Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Loader Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Controller Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:21:02 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 02:21:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:21:05 --> Final output sent to browser
DEBUG - 2011-09-29 02:21:05 --> Total execution time: 3.1529
DEBUG - 2011-09-29 02:21:09 --> Config Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:21:09 --> URI Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Router Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Output Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Input Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:21:09 --> Language Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Loader Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Controller Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:21:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 02:21:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:21:09 --> Final output sent to browser
DEBUG - 2011-09-29 02:21:09 --> Total execution time: 0.0659
DEBUG - 2011-09-29 02:21:09 --> Config Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:21:09 --> URI Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Router Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Output Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Input Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:21:09 --> Language Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Loader Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Controller Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Model Class Initialized
DEBUG - 2011-09-29 02:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:21:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 02:21:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:21:09 --> Final output sent to browser
DEBUG - 2011-09-29 02:21:09 --> Total execution time: 0.0713
DEBUG - 2011-09-29 02:30:51 --> Config Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:30:51 --> URI Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Router Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Output Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Input Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:30:51 --> Language Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Loader Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Controller Class Initialized
ERROR - 2011-09-29 02:30:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 02:30:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:30:51 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:30:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 02:30:51 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:30:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:30:51 --> Final output sent to browser
DEBUG - 2011-09-29 02:30:51 --> Total execution time: 0.1948
DEBUG - 2011-09-29 02:30:52 --> Config Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:30:52 --> URI Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Router Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Output Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Input Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:30:52 --> Language Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Loader Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Controller Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:30:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:30:53 --> Final output sent to browser
DEBUG - 2011-09-29 02:30:53 --> Total execution time: 0.9038
DEBUG - 2011-09-29 02:30:54 --> Config Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:30:54 --> URI Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Router Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Output Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Input Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:30:54 --> Language Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Loader Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Controller Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Model Class Initialized
DEBUG - 2011-09-29 02:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:30:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:30:55 --> Final output sent to browser
DEBUG - 2011-09-29 02:30:55 --> Total execution time: 0.7940
DEBUG - 2011-09-29 02:31:01 --> Config Class Initialized
DEBUG - 2011-09-29 02:31:01 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:31:01 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:31:01 --> URI Class Initialized
DEBUG - 2011-09-29 02:31:01 --> Router Class Initialized
ERROR - 2011-09-29 02:31:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 02:43:59 --> Config Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:43:59 --> URI Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Router Class Initialized
DEBUG - 2011-09-29 02:43:59 --> No URI present. Default controller set.
DEBUG - 2011-09-29 02:43:59 --> Output Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Input Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:43:59 --> Language Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Loader Class Initialized
DEBUG - 2011-09-29 02:43:59 --> Controller Class Initialized
DEBUG - 2011-09-29 02:43:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 02:43:59 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:43:59 --> Final output sent to browser
DEBUG - 2011-09-29 02:43:59 --> Total execution time: 0.1139
DEBUG - 2011-09-29 02:44:07 --> Config Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Hooks Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Utf8 Class Initialized
DEBUG - 2011-09-29 02:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 02:44:07 --> URI Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Router Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Output Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Input Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 02:44:07 --> Language Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Loader Class Initialized
DEBUG - 2011-09-29 02:44:07 --> Controller Class Initialized
DEBUG - 2011-09-29 02:44:08 --> Model Class Initialized
DEBUG - 2011-09-29 02:44:08 --> Model Class Initialized
DEBUG - 2011-09-29 02:44:08 --> Model Class Initialized
DEBUG - 2011-09-29 02:44:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 02:44:08 --> Database Driver Class Initialized
DEBUG - 2011-09-29 02:44:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 02:44:11 --> Helper loaded: url_helper
DEBUG - 2011-09-29 02:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 02:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 02:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 02:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 02:44:11 --> Final output sent to browser
DEBUG - 2011-09-29 02:44:11 --> Total execution time: 3.5946
DEBUG - 2011-09-29 03:00:03 --> Config Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:00:03 --> URI Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Router Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Output Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Input Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:00:03 --> Language Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Loader Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Controller Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:00:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:00:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:00:27 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:00:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:00:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:00:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:00:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:00:27 --> Final output sent to browser
DEBUG - 2011-09-29 03:00:27 --> Total execution time: 24.3434
DEBUG - 2011-09-29 03:00:32 --> Config Class Initialized
DEBUG - 2011-09-29 03:00:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:00:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:00:32 --> URI Class Initialized
DEBUG - 2011-09-29 03:00:32 --> Router Class Initialized
ERROR - 2011-09-29 03:00:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 03:00:33 --> Config Class Initialized
DEBUG - 2011-09-29 03:00:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:00:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:00:33 --> URI Class Initialized
DEBUG - 2011-09-29 03:00:33 --> Router Class Initialized
ERROR - 2011-09-29 03:00:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 03:01:21 --> Config Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:01:21 --> URI Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Router Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Output Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Input Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:01:21 --> Language Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Loader Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Controller Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:01:21 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:01:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:01:21 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:01:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:01:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:01:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:01:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:01:21 --> Final output sent to browser
DEBUG - 2011-09-29 03:01:21 --> Total execution time: 0.3496
DEBUG - 2011-09-29 03:01:47 --> Config Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:01:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:01:47 --> URI Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Router Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Output Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Input Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:01:47 --> Language Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Loader Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Controller Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Model Class Initialized
DEBUG - 2011-09-29 03:01:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:01:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:01:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:01:53 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:01:53 --> Final output sent to browser
DEBUG - 2011-09-29 03:01:53 --> Total execution time: 5.8297
DEBUG - 2011-09-29 03:02:18 --> Config Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:02:18 --> URI Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Router Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Output Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Input Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:02:18 --> Language Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Loader Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Controller Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:02:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:02:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:02:19 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:02:19 --> Final output sent to browser
DEBUG - 2011-09-29 03:02:19 --> Total execution time: 0.6252
DEBUG - 2011-09-29 03:02:33 --> Config Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:02:33 --> URI Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Router Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Output Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Input Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:02:33 --> Language Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Loader Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Controller Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:02:33 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:02:34 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:02:34 --> Final output sent to browser
DEBUG - 2011-09-29 03:02:34 --> Total execution time: 0.7476
DEBUG - 2011-09-29 03:02:42 --> Config Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:02:42 --> URI Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Router Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Output Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Input Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:02:42 --> Language Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Loader Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Controller Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:02:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:02:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:02:43 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:02:43 --> Final output sent to browser
DEBUG - 2011-09-29 03:02:43 --> Total execution time: 0.6417
DEBUG - 2011-09-29 03:02:53 --> Config Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:02:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:02:53 --> URI Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Router Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Output Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Input Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:02:53 --> Language Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Loader Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Controller Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:02:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:02:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:02:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:02:53 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:02:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:02:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:02:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:02:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:02:53 --> Final output sent to browser
DEBUG - 2011-09-29 03:02:53 --> Total execution time: 0.4714
DEBUG - 2011-09-29 03:03:03 --> Config Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:03:03 --> URI Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Router Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Output Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Input Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:03:03 --> Language Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Loader Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Controller Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:03:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:03:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:03:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:03:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:03:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:03:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:03:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:03:04 --> Final output sent to browser
DEBUG - 2011-09-29 03:03:04 --> Total execution time: 0.7781
DEBUG - 2011-09-29 03:03:09 --> Config Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:03:09 --> URI Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Router Class Initialized
DEBUG - 2011-09-29 03:03:09 --> No URI present. Default controller set.
DEBUG - 2011-09-29 03:03:09 --> Output Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Input Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:03:09 --> Language Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Loader Class Initialized
DEBUG - 2011-09-29 03:03:09 --> Controller Class Initialized
DEBUG - 2011-09-29 03:03:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 03:03:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:03:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:03:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:03:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:03:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:03:09 --> Final output sent to browser
DEBUG - 2011-09-29 03:03:09 --> Total execution time: 0.0242
DEBUG - 2011-09-29 03:03:13 --> Config Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:03:13 --> URI Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Router Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Output Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Input Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:03:13 --> Language Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Loader Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Controller Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:03:14 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:03:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:03:15 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:03:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:03:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:03:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:03:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:03:15 --> Final output sent to browser
DEBUG - 2011-09-29 03:03:15 --> Total execution time: 1.4628
DEBUG - 2011-09-29 03:44:27 --> Config Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:44:27 --> URI Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Router Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Output Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Input Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:44:27 --> Language Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Loader Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Controller Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:44:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:44:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:44:29 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:44:29 --> Final output sent to browser
DEBUG - 2011-09-29 03:44:29 --> Total execution time: 2.1153
DEBUG - 2011-09-29 03:44:52 --> Config Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:44:52 --> URI Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Router Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Output Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Input Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:44:52 --> Language Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Loader Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Controller Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:44:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:44:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:44:55 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:44:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:44:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:44:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:44:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:44:55 --> Final output sent to browser
DEBUG - 2011-09-29 03:44:55 --> Total execution time: 2.8057
DEBUG - 2011-09-29 03:44:59 --> Config Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:44:59 --> URI Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Router Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Output Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Input Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:44:59 --> Language Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Loader Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Controller Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Model Class Initialized
DEBUG - 2011-09-29 03:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:44:59 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:44:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:44:59 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:44:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:44:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:44:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:44:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:44:59 --> Final output sent to browser
DEBUG - 2011-09-29 03:44:59 --> Total execution time: 0.0529
DEBUG - 2011-09-29 03:45:10 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:10 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:10 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:10 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:10 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:10 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:10 --> Total execution time: 0.4581
DEBUG - 2011-09-29 03:45:16 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:16 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:16 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:16 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:16 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:16 --> Total execution time: 0.0980
DEBUG - 2011-09-29 03:45:30 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:31 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:31 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:31 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:31 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:31 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:31 --> Total execution time: 0.9472
DEBUG - 2011-09-29 03:45:36 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:36 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:36 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:36 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:36 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:36 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:36 --> Total execution time: 0.1732
DEBUG - 2011-09-29 03:45:48 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:48 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:48 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:48 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:48 --> Total execution time: 0.3743
DEBUG - 2011-09-29 03:45:54 --> Config Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:45:54 --> URI Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Router Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Output Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Input Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:45:54 --> Language Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Loader Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Controller Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:45:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:45:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:45:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:45:54 --> Final output sent to browser
DEBUG - 2011-09-29 03:45:54 --> Total execution time: 0.0698
DEBUG - 2011-09-29 03:46:05 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:05 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:05 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:05 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:05 --> Total execution time: 0.3537
DEBUG - 2011-09-29 03:46:07 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:07 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:07 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:07 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:07 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:07 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:07 --> Total execution time: 0.0668
DEBUG - 2011-09-29 03:46:17 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:17 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:17 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:20 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:20 --> Total execution time: 2.5325
DEBUG - 2011-09-29 03:46:26 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:26 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:26 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:26 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:26 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:26 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:26 --> Total execution time: 0.0594
DEBUG - 2011-09-29 03:46:41 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:41 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:41 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:41 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:41 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:41 --> Total execution time: 0.4208
DEBUG - 2011-09-29 03:46:45 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:45 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:45 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:45 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:45 --> Total execution time: 0.0447
DEBUG - 2011-09-29 03:46:53 --> Config Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:46:53 --> URI Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Router Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Output Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Input Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:46:53 --> Language Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Loader Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Controller Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Model Class Initialized
DEBUG - 2011-09-29 03:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:46:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:46:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:46:55 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:46:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:46:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:46:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:46:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:46:55 --> Final output sent to browser
DEBUG - 2011-09-29 03:46:55 --> Total execution time: 2.3583
DEBUG - 2011-09-29 03:47:03 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:03 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:03 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:03 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:03 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:03 --> Total execution time: 0.1085
DEBUG - 2011-09-29 03:47:08 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:08 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:08 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:08 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:09 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:09 --> Total execution time: 0.7056
DEBUG - 2011-09-29 03:47:16 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:16 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:16 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:16 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:16 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:16 --> Total execution time: 0.0691
DEBUG - 2011-09-29 03:47:28 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:28 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:28 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:28 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:28 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Controller Class Initialized
ERROR - 2011-09-29 03:47:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 03:47:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 03:47:28 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 03:47:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:28 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:28 --> Total execution time: 0.0699
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:28 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:28 --> Total execution time: 0.3369
DEBUG - 2011-09-29 03:47:32 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:32 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:32 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:32 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:33 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:33 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:33 --> Total execution time: 0.2388
DEBUG - 2011-09-29 03:47:46 --> Config Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:47:46 --> URI Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Router Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Output Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Input Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:47:46 --> Language Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Loader Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Controller Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Model Class Initialized
DEBUG - 2011-09-29 03:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:47:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:47:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:47:47 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:47:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:47:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:47:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:47:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:47:47 --> Final output sent to browser
DEBUG - 2011-09-29 03:47:47 --> Total execution time: 0.3907
DEBUG - 2011-09-29 03:48:03 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:03 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:03 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:03 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:03 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:03 --> Total execution time: 0.4951
DEBUG - 2011-09-29 03:48:05 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:05 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:05 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:05 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:05 --> Total execution time: 0.0518
DEBUG - 2011-09-29 03:48:25 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:25 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:25 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:25 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:26 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:26 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:26 --> Total execution time: 0.3387
DEBUG - 2011-09-29 03:48:30 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:30 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:30 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:30 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:30 --> Total execution time: 0.0620
DEBUG - 2011-09-29 03:48:42 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:42 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:42 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:43 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:43 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:43 --> Total execution time: 0.3684
DEBUG - 2011-09-29 03:48:45 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:45 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:45 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:45 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:45 --> Total execution time: 0.0508
DEBUG - 2011-09-29 03:48:58 --> Config Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:48:58 --> URI Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Router Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Output Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Input Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:48:58 --> Language Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Loader Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Controller Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Model Class Initialized
DEBUG - 2011-09-29 03:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:48:58 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:48:58 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:48:58 --> Final output sent to browser
DEBUG - 2011-09-29 03:48:58 --> Total execution time: 0.4462
DEBUG - 2011-09-29 03:49:01 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:01 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:01 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:01 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:01 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:01 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:01 --> Total execution time: 0.0751
DEBUG - 2011-09-29 03:49:20 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:20 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:20 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:20 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:20 --> Total execution time: 0.4106
DEBUG - 2011-09-29 03:49:29 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:29 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:29 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:29 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:29 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:29 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:29 --> Total execution time: 0.0599
DEBUG - 2011-09-29 03:49:36 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:36 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:36 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:36 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:37 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:37 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:37 --> Total execution time: 0.5751
DEBUG - 2011-09-29 03:49:41 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:41 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:41 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:41 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:41 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:41 --> Total execution time: 0.0799
DEBUG - 2011-09-29 03:49:50 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:50 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:50 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:50 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:50 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:50 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:50 --> Total execution time: 0.0571
DEBUG - 2011-09-29 03:49:54 --> Config Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:49:54 --> URI Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Router Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Output Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Input Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:49:54 --> Language Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Loader Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Controller Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Model Class Initialized
DEBUG - 2011-09-29 03:49:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:49:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:49:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:49:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:49:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:49:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:49:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:49:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:49:54 --> Final output sent to browser
DEBUG - 2011-09-29 03:49:54 --> Total execution time: 0.0508
DEBUG - 2011-09-29 03:50:13 --> Config Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:50:13 --> URI Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Router Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Output Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Input Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:50:13 --> Language Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Loader Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Controller Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:50:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:50:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:50:15 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:50:15 --> Final output sent to browser
DEBUG - 2011-09-29 03:50:15 --> Total execution time: 1.3645
DEBUG - 2011-09-29 03:50:22 --> Config Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 03:50:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 03:50:22 --> URI Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Router Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Output Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Input Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 03:50:22 --> Language Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Loader Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Controller Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Model Class Initialized
DEBUG - 2011-09-29 03:50:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 03:50:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 03:50:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 03:50:22 --> Helper loaded: url_helper
DEBUG - 2011-09-29 03:50:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 03:50:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 03:50:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 03:50:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 03:50:22 --> Final output sent to browser
DEBUG - 2011-09-29 03:50:22 --> Total execution time: 0.0661
DEBUG - 2011-09-29 04:05:33 --> Config Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:05:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:05:33 --> URI Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Router Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Output Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Input Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:05:33 --> Language Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Loader Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Controller Class Initialized
ERROR - 2011-09-29 04:05:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:05:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:05:33 --> Model Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Model Class Initialized
DEBUG - 2011-09-29 04:05:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:05:33 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:05:33 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:05:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:05:33 --> Final output sent to browser
DEBUG - 2011-09-29 04:05:33 --> Total execution time: 0.1132
DEBUG - 2011-09-29 04:05:34 --> Config Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:05:34 --> URI Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Router Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Output Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Input Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:05:34 --> Language Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Loader Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Controller Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Model Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Model Class Initialized
DEBUG - 2011-09-29 04:05:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:05:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:05:35 --> Final output sent to browser
DEBUG - 2011-09-29 04:05:35 --> Total execution time: 0.8931
DEBUG - 2011-09-29 04:05:38 --> Config Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:05:38 --> URI Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Router Class Initialized
ERROR - 2011-09-29 04:05:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 04:05:38 --> Config Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:05:38 --> URI Class Initialized
DEBUG - 2011-09-29 04:05:38 --> Router Class Initialized
ERROR - 2011-09-29 04:05:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 04:06:33 --> Config Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:06:33 --> URI Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Router Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Output Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Input Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:06:33 --> Language Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Loader Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Controller Class Initialized
ERROR - 2011-09-29 04:06:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:06:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:06:33 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:06:33 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:06:33 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:06:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:06:33 --> Final output sent to browser
DEBUG - 2011-09-29 04:06:33 --> Total execution time: 0.0315
DEBUG - 2011-09-29 04:06:34 --> Config Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:06:34 --> URI Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Router Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Output Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Input Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:06:34 --> Language Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Loader Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Controller Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:06:35 --> Final output sent to browser
DEBUG - 2011-09-29 04:06:35 --> Total execution time: 1.0022
DEBUG - 2011-09-29 04:06:47 --> Config Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:06:47 --> URI Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Router Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Output Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Input Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:06:47 --> Language Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Loader Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Controller Class Initialized
ERROR - 2011-09-29 04:06:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:06:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:06:47 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:06:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:06:47 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:06:47 --> Final output sent to browser
DEBUG - 2011-09-29 04:06:47 --> Total execution time: 0.0875
DEBUG - 2011-09-29 04:06:49 --> Config Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:06:49 --> URI Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Router Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Output Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Input Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:06:49 --> Language Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Loader Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Controller Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Model Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:06:49 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:06:49 --> Final output sent to browser
DEBUG - 2011-09-29 04:06:49 --> Total execution time: 0.8078
DEBUG - 2011-09-29 04:07:03 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:03 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:03 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Controller Class Initialized
ERROR - 2011-09-29 04:07:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:07:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:03 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:03 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:07:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:07:03 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:03 --> Total execution time: 0.1196
DEBUG - 2011-09-29 04:07:04 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:04 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:04 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Controller Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:06 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:06 --> Total execution time: 2.4209
DEBUG - 2011-09-29 04:07:11 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:11 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:11 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Controller Class Initialized
ERROR - 2011-09-29 04:07:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:07:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:11 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:11 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:07:11 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:11 --> Total execution time: 0.0494
DEBUG - 2011-09-29 04:07:12 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:12 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:12 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Controller Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:13 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:13 --> Total execution time: 0.7602
DEBUG - 2011-09-29 04:07:23 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:23 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:23 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Controller Class Initialized
ERROR - 2011-09-29 04:07:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:07:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:23 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:23 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:07:23 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:07:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:07:23 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:23 --> Total execution time: 0.0636
DEBUG - 2011-09-29 04:07:24 --> Config Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:07:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:07:24 --> URI Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Router Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Output Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Input Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:07:24 --> Language Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Loader Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Controller Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Model Class Initialized
DEBUG - 2011-09-29 04:07:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:07:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:07:25 --> Final output sent to browser
DEBUG - 2011-09-29 04:07:25 --> Total execution time: 0.9273
DEBUG - 2011-09-29 04:14:24 --> Config Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:14:24 --> URI Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Router Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Output Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Input Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:14:24 --> Language Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Loader Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Controller Class Initialized
ERROR - 2011-09-29 04:14:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:14:24 --> Model Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Model Class Initialized
DEBUG - 2011-09-29 04:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:14:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:14:24 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:14:24 --> Final output sent to browser
DEBUG - 2011-09-29 04:14:24 --> Total execution time: 0.1028
DEBUG - 2011-09-29 04:28:50 --> Config Class Initialized
DEBUG - 2011-09-29 04:28:50 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:28:50 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:28:50 --> URI Class Initialized
DEBUG - 2011-09-29 04:28:50 --> Router Class Initialized
ERROR - 2011-09-29 04:28:50 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-29 04:29:35 --> Config Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:29:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:29:35 --> URI Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Router Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Output Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Input Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:29:35 --> Language Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Loader Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Controller Class Initialized
ERROR - 2011-09-29 04:29:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:29:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:29:35 --> Model Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Model Class Initialized
DEBUG - 2011-09-29 04:29:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:29:35 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:29:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:29:35 --> Final output sent to browser
DEBUG - 2011-09-29 04:29:35 --> Total execution time: 0.0722
DEBUG - 2011-09-29 04:41:05 --> Config Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:41:05 --> URI Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Router Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Output Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Input Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:41:05 --> Language Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Loader Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Controller Class Initialized
ERROR - 2011-09-29 04:41:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 04:41:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:41:05 --> Model Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Model Class Initialized
DEBUG - 2011-09-29 04:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:41:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 04:41:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 04:41:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 04:41:05 --> Final output sent to browser
DEBUG - 2011-09-29 04:41:05 --> Total execution time: 0.1171
DEBUG - 2011-09-29 04:41:06 --> Config Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 04:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 04:41:06 --> URI Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Router Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Output Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Input Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 04:41:06 --> Language Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Loader Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Controller Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Model Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Model Class Initialized
DEBUG - 2011-09-29 04:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 04:41:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 04:41:07 --> Final output sent to browser
DEBUG - 2011-09-29 04:41:07 --> Total execution time: 1.1998
DEBUG - 2011-09-29 05:03:17 --> Config Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:03:17 --> URI Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Router Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Output Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Input Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:03:17 --> Language Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Loader Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Controller Class Initialized
ERROR - 2011-09-29 05:03:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:03:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:03:17 --> Model Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Model Class Initialized
DEBUG - 2011-09-29 05:03:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:03:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:03:17 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:03:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:03:17 --> Final output sent to browser
DEBUG - 2011-09-29 05:03:17 --> Total execution time: 0.0597
DEBUG - 2011-09-29 05:03:18 --> Config Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:03:18 --> URI Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Router Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Output Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Input Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:03:18 --> Language Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Loader Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Controller Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Model Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Model Class Initialized
DEBUG - 2011-09-29 05:03:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:03:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:03:19 --> Final output sent to browser
DEBUG - 2011-09-29 05:03:19 --> Total execution time: 0.6455
DEBUG - 2011-09-29 05:03:20 --> Config Class Initialized
DEBUG - 2011-09-29 05:03:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:03:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:03:20 --> URI Class Initialized
DEBUG - 2011-09-29 05:03:20 --> Router Class Initialized
ERROR - 2011-09-29 05:03:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 05:11:20 --> Config Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:11:20 --> URI Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Router Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Output Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Input Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:11:20 --> Language Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Loader Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Controller Class Initialized
ERROR - 2011-09-29 05:11:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:11:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:11:20 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:11:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:11:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:11:20 --> Final output sent to browser
DEBUG - 2011-09-29 05:11:20 --> Total execution time: 0.0625
DEBUG - 2011-09-29 05:11:21 --> Config Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:11:21 --> URI Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Router Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Output Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Input Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:11:21 --> Language Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Loader Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Controller Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:11:21 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:11:22 --> Final output sent to browser
DEBUG - 2011-09-29 05:11:22 --> Total execution time: 0.9069
DEBUG - 2011-09-29 05:11:45 --> Config Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:11:45 --> URI Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Router Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Output Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Input Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:11:45 --> Language Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Loader Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Controller Class Initialized
ERROR - 2011-09-29 05:11:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:11:45 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:11:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:11:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:11:45 --> Final output sent to browser
DEBUG - 2011-09-29 05:11:45 --> Total execution time: 0.0306
DEBUG - 2011-09-29 05:11:46 --> Config Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:11:46 --> URI Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Router Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Output Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Input Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:11:46 --> Language Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Loader Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Controller Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:11:55 --> Final output sent to browser
DEBUG - 2011-09-29 05:11:55 --> Total execution time: 9.0231
DEBUG - 2011-09-29 05:12:46 --> Config Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:12:46 --> URI Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Router Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Output Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Input Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:12:46 --> Language Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Loader Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Controller Class Initialized
ERROR - 2011-09-29 05:12:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:12:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:12:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:12:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:12:46 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:12:46 --> Final output sent to browser
DEBUG - 2011-09-29 05:12:46 --> Total execution time: 0.0517
DEBUG - 2011-09-29 05:12:46 --> Config Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:12:46 --> URI Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Router Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Output Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Input Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:12:46 --> Language Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Loader Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Controller Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Model Class Initialized
DEBUG - 2011-09-29 05:12:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:12:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:12:50 --> Final output sent to browser
DEBUG - 2011-09-29 05:12:50 --> Total execution time: 3.2120
DEBUG - 2011-09-29 05:13:16 --> Config Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:13:16 --> URI Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Router Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Output Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Input Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:13:16 --> Language Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Loader Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Controller Class Initialized
ERROR - 2011-09-29 05:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:13:16 --> Model Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Model Class Initialized
DEBUG - 2011-09-29 05:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:13:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:13:16 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:13:16 --> Final output sent to browser
DEBUG - 2011-09-29 05:13:16 --> Total execution time: 0.0441
DEBUG - 2011-09-29 05:13:17 --> Config Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:13:17 --> URI Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Router Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Output Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Input Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:13:17 --> Language Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Loader Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Controller Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Model Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Model Class Initialized
DEBUG - 2011-09-29 05:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:13:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:13:20 --> Final output sent to browser
DEBUG - 2011-09-29 05:13:20 --> Total execution time: 3.0555
DEBUG - 2011-09-29 05:14:00 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:00 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:00 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Controller Class Initialized
ERROR - 2011-09-29 05:14:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:00 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:00 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:00 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:14:00 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:00 --> Total execution time: 0.0734
DEBUG - 2011-09-29 05:14:01 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:01 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:01 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Controller Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:01 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:02 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:02 --> Total execution time: 1.0279
DEBUG - 2011-09-29 05:14:27 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:27 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:27 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Controller Class Initialized
ERROR - 2011-09-29 05:14:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:14:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:27 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:27 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:14:27 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:27 --> Total execution time: 0.0345
DEBUG - 2011-09-29 05:14:27 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:27 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:27 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Controller Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:28 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:28 --> Total execution time: 0.8093
DEBUG - 2011-09-29 05:14:39 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:39 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:39 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Controller Class Initialized
ERROR - 2011-09-29 05:14:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:14:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:39 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:39 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:39 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:14:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:14:39 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:39 --> Total execution time: 0.0369
DEBUG - 2011-09-29 05:14:39 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:39 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:39 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Controller Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:39 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:40 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:40 --> Total execution time: 0.6414
DEBUG - 2011-09-29 05:14:56 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:56 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:56 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Controller Class Initialized
ERROR - 2011-09-29 05:14:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:14:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:56 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:14:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:14:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:14:56 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:56 --> Total execution time: 0.1214
DEBUG - 2011-09-29 05:14:57 --> Config Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:14:57 --> URI Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Router Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Output Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Input Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:14:57 --> Language Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Loader Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Controller Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Model Class Initialized
DEBUG - 2011-09-29 05:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:14:57 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:14:58 --> Final output sent to browser
DEBUG - 2011-09-29 05:14:58 --> Total execution time: 0.6804
DEBUG - 2011-09-29 05:15:21 --> Config Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:15:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:15:21 --> URI Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Router Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Output Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Input Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:15:21 --> Language Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Loader Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Controller Class Initialized
ERROR - 2011-09-29 05:15:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:15:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:15:21 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:15:21 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:15:21 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:15:21 --> Final output sent to browser
DEBUG - 2011-09-29 05:15:21 --> Total execution time: 0.0320
DEBUG - 2011-09-29 05:15:22 --> Config Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:15:22 --> URI Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Router Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Output Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Input Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:15:22 --> Language Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Loader Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Controller Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:15:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:15:23 --> Final output sent to browser
DEBUG - 2011-09-29 05:15:23 --> Total execution time: 1.2619
DEBUG - 2011-09-29 05:15:52 --> Config Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:15:52 --> URI Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Router Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Output Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Input Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:15:52 --> Language Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Loader Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Controller Class Initialized
ERROR - 2011-09-29 05:15:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:15:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:15:52 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:15:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:15:52 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:15:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:15:52 --> Final output sent to browser
DEBUG - 2011-09-29 05:15:52 --> Total execution time: 0.0608
DEBUG - 2011-09-29 05:15:53 --> Config Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:15:53 --> URI Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Router Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Output Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Input Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:15:53 --> Language Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Loader Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Controller Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Model Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:15:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:15:53 --> Final output sent to browser
DEBUG - 2011-09-29 05:15:53 --> Total execution time: 0.5477
DEBUG - 2011-09-29 05:16:12 --> Config Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:16:12 --> URI Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Router Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Output Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Input Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:16:12 --> Language Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Loader Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Controller Class Initialized
ERROR - 2011-09-29 05:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:16:12 --> Model Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Model Class Initialized
DEBUG - 2011-09-29 05:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:16:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:16:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:16:12 --> Final output sent to browser
DEBUG - 2011-09-29 05:16:12 --> Total execution time: 0.0518
DEBUG - 2011-09-29 05:16:13 --> Config Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:16:13 --> URI Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Router Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Output Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Input Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:16:13 --> Language Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Loader Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Controller Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Model Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Model Class Initialized
DEBUG - 2011-09-29 05:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:16:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:16:16 --> Final output sent to browser
DEBUG - 2011-09-29 05:16:16 --> Total execution time: 3.0052
DEBUG - 2011-09-29 05:59:30 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:30 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:30 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Controller Class Initialized
ERROR - 2011-09-29 05:59:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:59:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:30 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:59:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:59:30 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:30 --> Total execution time: 0.7514
DEBUG - 2011-09-29 05:59:34 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:34 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:34 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Controller Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:34 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:34 --> Total execution time: 0.7209
DEBUG - 2011-09-29 05:59:38 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:38 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:38 --> Router Class Initialized
ERROR - 2011-09-29 05:59:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 05:59:43 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:43 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:43 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Controller Class Initialized
ERROR - 2011-09-29 05:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:43 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:43 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:43 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:59:43 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:43 --> Total execution time: 0.0320
DEBUG - 2011-09-29 05:59:44 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:44 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:44 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Controller Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:45 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:45 --> Total execution time: 0.7124
DEBUG - 2011-09-29 05:59:48 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:48 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:48 --> Router Class Initialized
ERROR - 2011-09-29 05:59:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 05:59:52 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:52 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:52 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Controller Class Initialized
ERROR - 2011-09-29 05:59:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 05:59:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:52 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 05:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 05:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 05:59:52 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:52 --> Total execution time: 0.0320
DEBUG - 2011-09-29 05:59:53 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:53 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Router Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Output Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Input Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 05:59:53 --> Language Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Loader Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Controller Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Model Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 05:59:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 05:59:53 --> Final output sent to browser
DEBUG - 2011-09-29 05:59:53 --> Total execution time: 0.7136
DEBUG - 2011-09-29 05:59:56 --> Config Class Initialized
DEBUG - 2011-09-29 05:59:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 05:59:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 05:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 05:59:56 --> URI Class Initialized
DEBUG - 2011-09-29 05:59:56 --> Router Class Initialized
ERROR - 2011-09-29 05:59:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 06:00:20 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:20 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Router Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Output Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Input Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:00:20 --> Language Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Loader Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Controller Class Initialized
ERROR - 2011-09-29 06:00:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:00:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:00:20 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:00:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:00:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:00:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:00:20 --> Final output sent to browser
DEBUG - 2011-09-29 06:00:20 --> Total execution time: 0.0432
DEBUG - 2011-09-29 06:00:20 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:21 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Router Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Output Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Input Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:00:21 --> Language Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Loader Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Controller Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:00:21 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:00:21 --> Final output sent to browser
DEBUG - 2011-09-29 06:00:21 --> Total execution time: 0.6510
DEBUG - 2011-09-29 06:00:24 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:24 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:24 --> Router Class Initialized
ERROR - 2011-09-29 06:00:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 06:00:35 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:35 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Router Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Output Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Input Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:00:35 --> Language Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Loader Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Controller Class Initialized
ERROR - 2011-09-29 06:00:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:00:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:00:35 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:00:35 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:00:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:00:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:00:35 --> Final output sent to browser
DEBUG - 2011-09-29 06:00:35 --> Total execution time: 0.0338
DEBUG - 2011-09-29 06:00:36 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:36 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Router Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Output Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Input Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:00:36 --> Language Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Loader Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Controller Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Model Class Initialized
DEBUG - 2011-09-29 06:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:00:36 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:00:37 --> Final output sent to browser
DEBUG - 2011-09-29 06:00:37 --> Total execution time: 0.5129
DEBUG - 2011-09-29 06:00:40 --> Config Class Initialized
DEBUG - 2011-09-29 06:00:40 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:00:40 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:00:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:00:40 --> URI Class Initialized
DEBUG - 2011-09-29 06:00:40 --> Router Class Initialized
ERROR - 2011-09-29 06:00:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 06:01:30 --> Config Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:01:30 --> URI Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Router Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Output Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Input Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:01:30 --> Language Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Loader Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Controller Class Initialized
ERROR - 2011-09-29 06:01:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:01:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:01:30 --> Model Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Model Class Initialized
DEBUG - 2011-09-29 06:01:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:01:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:01:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:01:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:01:30 --> Final output sent to browser
DEBUG - 2011-09-29 06:01:30 --> Total execution time: 0.1147
DEBUG - 2011-09-29 06:01:31 --> Config Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:01:31 --> URI Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Router Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Output Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Input Class Initialized
DEBUG - 2011-09-29 06:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:01:31 --> Language Class Initialized
DEBUG - 2011-09-29 06:01:32 --> Loader Class Initialized
DEBUG - 2011-09-29 06:01:32 --> Controller Class Initialized
DEBUG - 2011-09-29 06:01:32 --> Model Class Initialized
DEBUG - 2011-09-29 06:01:32 --> Model Class Initialized
DEBUG - 2011-09-29 06:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:01:32 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:01:33 --> Final output sent to browser
DEBUG - 2011-09-29 06:01:33 --> Total execution time: 1.1611
DEBUG - 2011-09-29 06:01:35 --> Config Class Initialized
DEBUG - 2011-09-29 06:01:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:01:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:01:35 --> URI Class Initialized
DEBUG - 2011-09-29 06:01:35 --> Router Class Initialized
ERROR - 2011-09-29 06:01:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 06:03:51 --> Config Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:03:52 --> URI Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Router Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Output Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Input Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:03:52 --> Language Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Loader Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Controller Class Initialized
ERROR - 2011-09-29 06:03:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:03:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:03:52 --> Model Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Model Class Initialized
DEBUG - 2011-09-29 06:03:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:03:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:03:52 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:03:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:03:52 --> Final output sent to browser
DEBUG - 2011-09-29 06:03:52 --> Total execution time: 0.6251
DEBUG - 2011-09-29 06:04:06 --> Config Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:04:06 --> URI Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Router Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Output Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Input Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:04:06 --> Language Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Loader Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Controller Class Initialized
ERROR - 2011-09-29 06:04:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:04:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:04:06 --> Model Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Model Class Initialized
DEBUG - 2011-09-29 06:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:04:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:04:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:04:06 --> Final output sent to browser
DEBUG - 2011-09-29 06:04:06 --> Total execution time: 0.0991
DEBUG - 2011-09-29 06:04:07 --> Config Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Hooks Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Utf8 Class Initialized
DEBUG - 2011-09-29 06:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 06:04:07 --> URI Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Router Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Output Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Input Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 06:04:07 --> Language Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Loader Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Controller Class Initialized
ERROR - 2011-09-29 06:04:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 06:04:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:04:07 --> Model Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Model Class Initialized
DEBUG - 2011-09-29 06:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 06:04:07 --> Database Driver Class Initialized
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 06:04:07 --> Helper loaded: url_helper
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 06:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 06:04:07 --> Final output sent to browser
DEBUG - 2011-09-29 06:04:07 --> Total execution time: 0.3224
DEBUG - 2011-09-29 07:41:53 --> Config Class Initialized
DEBUG - 2011-09-29 07:41:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 07:41:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 07:41:53 --> URI Class Initialized
DEBUG - 2011-09-29 07:41:53 --> Router Class Initialized
ERROR - 2011-09-29 07:41:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-29 07:41:55 --> Config Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 07:41:55 --> URI Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Router Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Output Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Input Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 07:41:55 --> Language Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Loader Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Controller Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Model Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Model Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Model Class Initialized
DEBUG - 2011-09-29 07:41:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 07:41:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 07:41:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 07:41:57 --> Helper loaded: url_helper
DEBUG - 2011-09-29 07:41:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 07:41:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 07:41:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 07:41:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 07:41:57 --> Final output sent to browser
DEBUG - 2011-09-29 07:41:57 --> Total execution time: 1.4827
DEBUG - 2011-09-29 07:59:21 --> Config Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 07:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 07:59:21 --> URI Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Router Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Output Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Input Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 07:59:21 --> Language Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Loader Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Controller Class Initialized
ERROR - 2011-09-29 07:59:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 07:59:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 07:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 07:59:21 --> Model Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Model Class Initialized
DEBUG - 2011-09-29 07:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 07:59:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 07:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 07:59:22 --> Helper loaded: url_helper
DEBUG - 2011-09-29 07:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 07:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 07:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 07:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 07:59:22 --> Final output sent to browser
DEBUG - 2011-09-29 07:59:22 --> Total execution time: 0.3070
DEBUG - 2011-09-29 07:59:25 --> Config Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 07:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 07:59:25 --> URI Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Router Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Output Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Input Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 07:59:25 --> Language Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Loader Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Controller Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Model Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Model Class Initialized
DEBUG - 2011-09-29 07:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 07:59:25 --> Database Driver Class Initialized
DEBUG - 2011-09-29 07:59:27 --> Final output sent to browser
DEBUG - 2011-09-29 07:59:27 --> Total execution time: 1.7071
DEBUG - 2011-09-29 07:59:31 --> Config Class Initialized
DEBUG - 2011-09-29 07:59:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 07:59:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 07:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 07:59:31 --> URI Class Initialized
DEBUG - 2011-09-29 07:59:31 --> Router Class Initialized
ERROR - 2011-09-29 07:59:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:01:56 --> Config Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:01:56 --> URI Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Router Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Output Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Input Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:01:56 --> Language Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Loader Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Controller Class Initialized
ERROR - 2011-09-29 08:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:01:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:01:56 --> Final output sent to browser
DEBUG - 2011-09-29 08:01:56 --> Total execution time: 0.0584
DEBUG - 2011-09-29 08:01:57 --> Config Class Initialized
DEBUG - 2011-09-29 08:01:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:01:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:01:57 --> URI Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Router Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Output Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Input Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:01:58 --> Language Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Loader Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Controller Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Model Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Model Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:01:58 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:01:58 --> Final output sent to browser
DEBUG - 2011-09-29 08:01:58 --> Total execution time: 0.8486
DEBUG - 2011-09-29 08:02:00 --> Config Class Initialized
DEBUG - 2011-09-29 08:02:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:02:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:02:00 --> URI Class Initialized
DEBUG - 2011-09-29 08:02:00 --> Router Class Initialized
ERROR - 2011-09-29 08:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:02:06 --> Config Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:02:06 --> URI Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Router Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Output Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Input Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:02:06 --> Language Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Loader Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Controller Class Initialized
ERROR - 2011-09-29 08:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:02:06 --> Model Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Model Class Initialized
DEBUG - 2011-09-29 08:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:02:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:02:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:02:06 --> Final output sent to browser
DEBUG - 2011-09-29 08:02:06 --> Total execution time: 0.0913
DEBUG - 2011-09-29 08:16:04 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:04 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:04 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Controller Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 08:16:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:16:06 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:06 --> Total execution time: 2.4850
DEBUG - 2011-09-29 08:16:16 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:16 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:16 --> Router Class Initialized
ERROR - 2011-09-29 08:16:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:16:19 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:19 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:19 --> Router Class Initialized
ERROR - 2011-09-29 08:16:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:16:31 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:31 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:31 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Controller Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:31 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 08:16:33 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:16:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:16:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:16:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:16:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:16:33 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:33 --> Total execution time: 1.9950
DEBUG - 2011-09-29 08:16:34 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:34 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:34 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Controller Class Initialized
ERROR - 2011-09-29 08:16:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:16:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:16:34 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:16:34 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:16:34 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:34 --> Total execution time: 0.0765
DEBUG - 2011-09-29 08:16:41 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:41 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:41 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Controller Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:42 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:42 --> Total execution time: 1.2319
DEBUG - 2011-09-29 08:16:47 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:47 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:47 --> Router Class Initialized
ERROR - 2011-09-29 08:16:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:16:48 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:48 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:48 --> Router Class Initialized
ERROR - 2011-09-29 08:16:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:16:54 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:54 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:54 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Controller Class Initialized
ERROR - 2011-09-29 08:16:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:16:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:16:54 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:16:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:16:54 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:54 --> Total execution time: 0.2898
DEBUG - 2011-09-29 08:16:56 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:56 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Router Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Output Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Input Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:16:56 --> Language Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Loader Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Controller Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:16:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:16:57 --> Final output sent to browser
DEBUG - 2011-09-29 08:16:57 --> Total execution time: 0.6883
DEBUG - 2011-09-29 08:16:58 --> Config Class Initialized
DEBUG - 2011-09-29 08:16:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:16:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:16:58 --> URI Class Initialized
DEBUG - 2011-09-29 08:16:58 --> Router Class Initialized
ERROR - 2011-09-29 08:16:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:30:33 --> Config Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:30:33 --> URI Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Router Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Output Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Input Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:30:33 --> Language Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Loader Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Controller Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:30:33 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:30:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 08:30:33 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:30:33 --> Final output sent to browser
DEBUG - 2011-09-29 08:30:33 --> Total execution time: 0.0717
DEBUG - 2011-09-29 08:30:35 --> Config Class Initialized
DEBUG - 2011-09-29 08:30:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:30:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:30:35 --> URI Class Initialized
DEBUG - 2011-09-29 08:30:35 --> Router Class Initialized
ERROR - 2011-09-29 08:30:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:30:56 --> Config Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:30:56 --> URI Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Router Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Output Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Input Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:30:56 --> Language Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Loader Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Controller Class Initialized
ERROR - 2011-09-29 08:30:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:30:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:30:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:30:56 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:30:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:30:56 --> Final output sent to browser
DEBUG - 2011-09-29 08:30:56 --> Total execution time: 0.0341
DEBUG - 2011-09-29 08:30:57 --> Config Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:30:57 --> URI Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Router Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Output Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Input Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:30:57 --> Language Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Loader Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Controller Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Model Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:30:57 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:30:57 --> Final output sent to browser
DEBUG - 2011-09-29 08:30:57 --> Total execution time: 0.5396
DEBUG - 2011-09-29 08:30:59 --> Config Class Initialized
DEBUG - 2011-09-29 08:30:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:30:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:30:59 --> URI Class Initialized
DEBUG - 2011-09-29 08:30:59 --> Router Class Initialized
ERROR - 2011-09-29 08:30:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:31:41 --> Config Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:31:41 --> URI Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Router Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Output Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Input Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:31:41 --> Language Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Loader Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Controller Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Model Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Model Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Model Class Initialized
DEBUG - 2011-09-29 08:31:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:31:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:31:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 08:31:41 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:31:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:31:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:31:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:31:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:31:41 --> Final output sent to browser
DEBUG - 2011-09-29 08:31:41 --> Total execution time: 0.0474
DEBUG - 2011-09-29 08:46:22 --> Config Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:46:22 --> URI Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Router Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Output Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Input Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:46:22 --> Language Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Loader Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Controller Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:46:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 08:46:22 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:46:22 --> Final output sent to browser
DEBUG - 2011-09-29 08:46:22 --> Total execution time: 0.1640
DEBUG - 2011-09-29 08:46:23 --> Config Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:46:23 --> URI Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Router Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Output Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Input Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:46:23 --> Language Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Loader Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Controller Class Initialized
ERROR - 2011-09-29 08:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:46:23 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:46:23 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:46:23 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:46:23 --> Final output sent to browser
DEBUG - 2011-09-29 08:46:23 --> Total execution time: 0.0465
DEBUG - 2011-09-29 08:46:24 --> Config Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:46:24 --> URI Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Router Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Output Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Input Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:46:24 --> Language Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Loader Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Controller Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Model Class Initialized
DEBUG - 2011-09-29 08:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:46:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:46:25 --> Config Class Initialized
DEBUG - 2011-09-29 08:46:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:46:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:46:25 --> URI Class Initialized
DEBUG - 2011-09-29 08:46:25 --> Router Class Initialized
ERROR - 2011-09-29 08:46:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:46:26 --> Final output sent to browser
DEBUG - 2011-09-29 08:46:26 --> Total execution time: 1.3280
DEBUG - 2011-09-29 08:47:34 --> Config Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:47:34 --> URI Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Router Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Output Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Input Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:47:34 --> Language Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Loader Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Controller Class Initialized
ERROR - 2011-09-29 08:47:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:47:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:47:34 --> Model Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Model Class Initialized
DEBUG - 2011-09-29 08:47:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:47:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:47:34 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:47:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:47:34 --> Final output sent to browser
DEBUG - 2011-09-29 08:47:34 --> Total execution time: 0.0550
DEBUG - 2011-09-29 08:47:36 --> Config Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:47:36 --> URI Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Router Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Output Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Input Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:47:36 --> Language Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Loader Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Controller Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Model Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Model Class Initialized
DEBUG - 2011-09-29 08:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:47:36 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:47:37 --> Final output sent to browser
DEBUG - 2011-09-29 08:47:37 --> Total execution time: 0.6102
DEBUG - 2011-09-29 08:47:42 --> Config Class Initialized
DEBUG - 2011-09-29 08:47:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:47:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:47:42 --> URI Class Initialized
DEBUG - 2011-09-29 08:47:42 --> Router Class Initialized
ERROR - 2011-09-29 08:47:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 08:49:05 --> Config Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:49:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:49:05 --> URI Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Router Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Output Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Input Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:49:05 --> Language Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Loader Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Controller Class Initialized
ERROR - 2011-09-29 08:49:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 08:49:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:49:05 --> Model Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Model Class Initialized
DEBUG - 2011-09-29 08:49:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:49:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 08:49:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 08:49:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 08:49:05 --> Final output sent to browser
DEBUG - 2011-09-29 08:49:05 --> Total execution time: 0.1029
DEBUG - 2011-09-29 08:49:07 --> Config Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:49:07 --> URI Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Router Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Output Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Input Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 08:49:07 --> Language Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Loader Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Controller Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Model Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Model Class Initialized
DEBUG - 2011-09-29 08:49:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 08:49:07 --> Database Driver Class Initialized
DEBUG - 2011-09-29 08:49:08 --> Final output sent to browser
DEBUG - 2011-09-29 08:49:08 --> Total execution time: 1.1735
DEBUG - 2011-09-29 08:49:11 --> Config Class Initialized
DEBUG - 2011-09-29 08:49:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 08:49:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 08:49:11 --> URI Class Initialized
DEBUG - 2011-09-29 08:49:11 --> Router Class Initialized
ERROR - 2011-09-29 08:49:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 09:33:47 --> Config Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 09:33:47 --> URI Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Router Class Initialized
DEBUG - 2011-09-29 09:33:47 --> No URI present. Default controller set.
DEBUG - 2011-09-29 09:33:47 --> Output Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Input Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 09:33:47 --> Language Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Loader Class Initialized
DEBUG - 2011-09-29 09:33:47 --> Controller Class Initialized
DEBUG - 2011-09-29 09:33:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 09:33:47 --> Helper loaded: url_helper
DEBUG - 2011-09-29 09:33:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 09:33:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 09:33:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 09:33:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 09:33:47 --> Final output sent to browser
DEBUG - 2011-09-29 09:33:47 --> Total execution time: 0.1180
DEBUG - 2011-09-29 10:02:02 --> Config Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:02:02 --> URI Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Router Class Initialized
DEBUG - 2011-09-29 10:02:02 --> No URI present. Default controller set.
DEBUG - 2011-09-29 10:02:02 --> Output Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Input Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:02:02 --> Language Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Loader Class Initialized
DEBUG - 2011-09-29 10:02:02 --> Controller Class Initialized
DEBUG - 2011-09-29 10:02:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 10:02:02 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:02:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:02:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:02:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:02:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:02:02 --> Final output sent to browser
DEBUG - 2011-09-29 10:02:02 --> Total execution time: 0.3252
DEBUG - 2011-09-29 10:34:53 --> Config Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:34:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:34:53 --> URI Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Router Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Output Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Input Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:34:53 --> Language Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Loader Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Controller Class Initialized
ERROR - 2011-09-29 10:34:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:34:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:34:53 --> Model Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Model Class Initialized
DEBUG - 2011-09-29 10:34:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:34:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:34:53 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:34:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:34:53 --> Final output sent to browser
DEBUG - 2011-09-29 10:34:53 --> Total execution time: 0.4722
DEBUG - 2011-09-29 10:34:54 --> Config Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:34:54 --> URI Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Router Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Output Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Input Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:34:54 --> Language Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Loader Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Controller Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Model Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Model Class Initialized
DEBUG - 2011-09-29 10:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:34:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:34:56 --> Final output sent to browser
DEBUG - 2011-09-29 10:34:56 --> Total execution time: 1.1819
DEBUG - 2011-09-29 10:34:58 --> Config Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:34:58 --> URI Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Router Class Initialized
ERROR - 2011-09-29 10:34:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:34:58 --> Config Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:34:58 --> URI Class Initialized
DEBUG - 2011-09-29 10:34:58 --> Router Class Initialized
ERROR - 2011-09-29 10:34:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:34:59 --> Config Class Initialized
DEBUG - 2011-09-29 10:34:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:34:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:34:59 --> URI Class Initialized
DEBUG - 2011-09-29 10:34:59 --> Router Class Initialized
ERROR - 2011-09-29 10:34:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:35:18 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:18 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:18 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Controller Class Initialized
ERROR - 2011-09-29 10:35:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:35:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:35:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:18 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:19 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:35:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:35:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:35:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:35:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:35:19 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:19 --> Total execution time: 0.0528
DEBUG - 2011-09-29 10:35:20 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:20 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:20 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Controller Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:20 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:20 --> Total execution time: 0.6077
DEBUG - 2011-09-29 10:35:28 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:28 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:28 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Controller Class Initialized
ERROR - 2011-09-29 10:35:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:35:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:28 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:35:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:35:28 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:28 --> Total execution time: 0.0334
DEBUG - 2011-09-29 10:35:29 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:29 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:29 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Controller Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:29 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:30 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:30 --> Total execution time: 0.6437
DEBUG - 2011-09-29 10:35:53 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:53 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:53 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Controller Class Initialized
ERROR - 2011-09-29 10:35:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:35:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:53 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:35:53 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:35:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:35:53 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:53 --> Total execution time: 0.0350
DEBUG - 2011-09-29 10:35:55 --> Config Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:35:55 --> URI Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Router Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Output Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Input Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:35:55 --> Language Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Loader Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Controller Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Model Class Initialized
DEBUG - 2011-09-29 10:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:35:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:35:56 --> Final output sent to browser
DEBUG - 2011-09-29 10:35:56 --> Total execution time: 0.8304
DEBUG - 2011-09-29 10:36:00 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:00 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:00 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:00 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:00 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:01 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:01 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:01 --> Total execution time: 0.1267
DEBUG - 2011-09-29 10:36:02 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:02 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:02 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:02 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:03 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:03 --> Total execution time: 0.7262
DEBUG - 2011-09-29 10:36:17 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:17 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:17 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:17 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:18 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:18 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:18 --> Total execution time: 0.0303
DEBUG - 2011-09-29 10:36:19 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:19 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:19 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:20 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:20 --> Total execution time: 0.7296
DEBUG - 2011-09-29 10:36:32 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:32 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:32 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:32 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:32 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:32 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:32 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:32 --> Total execution time: 0.0375
DEBUG - 2011-09-29 10:36:34 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:34 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:34 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:34 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:34 --> Total execution time: 0.5254
DEBUG - 2011-09-29 10:36:40 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:40 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:40 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:40 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:41 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:41 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:41 --> Total execution time: 0.1410
DEBUG - 2011-09-29 10:36:42 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:42 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:42 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:43 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:43 --> Total execution time: 0.9503
DEBUG - 2011-09-29 10:36:51 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:51 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:51 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:51 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:51 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:51 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:51 --> Total execution time: 0.0551
DEBUG - 2011-09-29 10:36:52 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:52 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:52 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:53 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:53 --> Total execution time: 0.7156
DEBUG - 2011-09-29 10:36:58 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:58 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:58 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Controller Class Initialized
ERROR - 2011-09-29 10:36:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:36:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:58 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:58 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:36:58 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:36:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:36:58 --> Final output sent to browser
DEBUG - 2011-09-29 10:36:58 --> Total execution time: 0.0328
DEBUG - 2011-09-29 10:36:59 --> Config Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:36:59 --> URI Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Router Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Output Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Input Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:36:59 --> Language Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Loader Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Controller Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Model Class Initialized
DEBUG - 2011-09-29 10:36:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:36:59 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:37:00 --> Final output sent to browser
DEBUG - 2011-09-29 10:37:00 --> Total execution time: 0.5180
DEBUG - 2011-09-29 10:49:30 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:30 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Router Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Output Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Input Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:49:30 --> Language Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Loader Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Controller Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:49:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:49:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 10:49:31 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:49:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:49:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:49:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:49:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:49:31 --> Final output sent to browser
DEBUG - 2011-09-29 10:49:31 --> Total execution time: 0.4720
DEBUG - 2011-09-29 10:49:35 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:35 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Router Class Initialized
ERROR - 2011-09-29 10:49:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:49:35 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:35 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:35 --> Router Class Initialized
ERROR - 2011-09-29 10:49:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:49:36 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:36 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:36 --> Router Class Initialized
ERROR - 2011-09-29 10:49:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 10:49:47 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:47 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Router Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Output Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Input Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:49:47 --> Language Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Loader Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Controller Class Initialized
ERROR - 2011-09-29 10:49:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:49:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:49:47 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:49:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:49:47 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:49:47 --> Final output sent to browser
DEBUG - 2011-09-29 10:49:47 --> Total execution time: 0.0353
DEBUG - 2011-09-29 10:49:47 --> Config Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:49:47 --> URI Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Router Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Output Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Input Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:49:47 --> Language Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Loader Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Controller Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Model Class Initialized
DEBUG - 2011-09-29 10:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:49:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:49:48 --> Final output sent to browser
DEBUG - 2011-09-29 10:49:48 --> Total execution time: 0.6056
DEBUG - 2011-09-29 10:50:08 --> Config Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:50:08 --> URI Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Router Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Output Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Input Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:50:08 --> Language Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Loader Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Controller Class Initialized
ERROR - 2011-09-29 10:50:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 10:50:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:50:08 --> Model Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Model Class Initialized
DEBUG - 2011-09-29 10:50:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:50:08 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 10:50:08 --> Helper loaded: url_helper
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 10:50:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 10:50:08 --> Final output sent to browser
DEBUG - 2011-09-29 10:50:08 --> Total execution time: 0.0492
DEBUG - 2011-09-29 10:50:09 --> Config Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 10:50:09 --> URI Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Router Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Output Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Input Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 10:50:09 --> Language Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Loader Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Controller Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Model Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Model Class Initialized
DEBUG - 2011-09-29 10:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 10:50:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 10:50:10 --> Final output sent to browser
DEBUG - 2011-09-29 10:50:10 --> Total execution time: 0.7736
DEBUG - 2011-09-29 11:21:58 --> Config Class Initialized
DEBUG - 2011-09-29 11:21:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:21:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:21:58 --> URI Class Initialized
DEBUG - 2011-09-29 11:21:58 --> Router Class Initialized
ERROR - 2011-09-29 11:21:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-29 11:22:35 --> Config Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:22:35 --> URI Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Router Class Initialized
DEBUG - 2011-09-29 11:22:35 --> No URI present. Default controller set.
DEBUG - 2011-09-29 11:22:35 --> Output Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Input Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:22:35 --> Language Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Loader Class Initialized
DEBUG - 2011-09-29 11:22:35 --> Controller Class Initialized
DEBUG - 2011-09-29 11:22:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 11:22:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 11:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 11:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 11:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 11:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 11:22:35 --> Final output sent to browser
DEBUG - 2011-09-29 11:22:35 --> Total execution time: 0.0515
DEBUG - 2011-09-29 11:36:09 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:09 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:09 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Controller Class Initialized
ERROR - 2011-09-29 11:36:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 11:36:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 11:36:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 11:36:09 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 11:36:10 --> Helper loaded: url_helper
DEBUG - 2011-09-29 11:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 11:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 11:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 11:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 11:36:10 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:10 --> Total execution time: 0.5021
DEBUG - 2011-09-29 11:36:11 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:11 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:11 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Controller Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:12 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:12 --> Total execution time: 1.3456
DEBUG - 2011-09-29 11:36:13 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:13 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:13 --> Router Class Initialized
ERROR - 2011-09-29 11:36:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:14 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:14 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:14 --> Router Class Initialized
ERROR - 2011-09-29 11:36:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:15 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:15 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Router Class Initialized
ERROR - 2011-09-29 11:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:15 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:15 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:15 --> Router Class Initialized
ERROR - 2011-09-29 11:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:30 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:30 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:30 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Controller Class Initialized
ERROR - 2011-09-29 11:36:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 11:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 11:36:30 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 11:36:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 11:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 11:36:30 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:30 --> Total execution time: 0.0853
DEBUG - 2011-09-29 11:36:31 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:31 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:31 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Controller Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:31 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:32 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:32 --> Total execution time: 1.0480
DEBUG - 2011-09-29 11:36:32 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:32 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:32 --> Router Class Initialized
ERROR - 2011-09-29 11:36:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:45 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:45 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:45 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Controller Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 11:36:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 11:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 11:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 11:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 11:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 11:36:48 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:48 --> Total execution time: 2.9665
DEBUG - 2011-09-29 11:36:49 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:49 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:49 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:49 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:49 --> Router Class Initialized
ERROR - 2011-09-29 11:36:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 11:36:55 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:55 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Router Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Output Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Input Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 11:36:55 --> Language Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Loader Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Controller Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Model Class Initialized
DEBUG - 2011-09-29 11:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 11:36:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 11:36:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 11:36:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 11:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 11:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 11:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 11:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 11:36:56 --> Final output sent to browser
DEBUG - 2011-09-29 11:36:56 --> Total execution time: 0.4341
DEBUG - 2011-09-29 11:36:57 --> Config Class Initialized
DEBUG - 2011-09-29 11:36:57 --> Hooks Class Initialized
DEBUG - 2011-09-29 11:36:57 --> Utf8 Class Initialized
DEBUG - 2011-09-29 11:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 11:36:57 --> URI Class Initialized
DEBUG - 2011-09-29 11:36:57 --> Router Class Initialized
ERROR - 2011-09-29 11:36:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 13:07:18 --> Config Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:07:18 --> URI Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Router Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Output Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Input Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:07:18 --> Language Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Loader Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Controller Class Initialized
ERROR - 2011-09-29 13:07:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:07:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:07:18 --> Model Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Model Class Initialized
DEBUG - 2011-09-29 13:07:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:07:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:07:18 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:07:18 --> Final output sent to browser
DEBUG - 2011-09-29 13:07:18 --> Total execution time: 0.5550
DEBUG - 2011-09-29 13:07:32 --> Config Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:07:32 --> URI Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Router Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Output Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Input Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:07:32 --> Language Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Loader Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Controller Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Model Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Model Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:07:32 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:07:32 --> Final output sent to browser
DEBUG - 2011-09-29 13:07:32 --> Total execution time: 0.7351
DEBUG - 2011-09-29 13:07:53 --> Config Class Initialized
DEBUG - 2011-09-29 13:07:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:07:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:07:53 --> URI Class Initialized
DEBUG - 2011-09-29 13:07:53 --> Router Class Initialized
ERROR - 2011-09-29 13:07:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 13:08:00 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:00 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:00 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Controller Class Initialized
ERROR - 2011-09-29 13:08:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:08:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:00 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:00 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:00 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:08:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:08:00 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:00 --> Total execution time: 0.0355
DEBUG - 2011-09-29 13:08:02 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:02 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:02 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Controller Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:02 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:03 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:03 --> Total execution time: 0.7258
DEBUG - 2011-09-29 13:08:15 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:15 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:15 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Controller Class Initialized
ERROR - 2011-09-29 13:08:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:08:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:15 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:15 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:08:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:08:15 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:15 --> Total execution time: 0.0337
DEBUG - 2011-09-29 13:08:17 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:17 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Router Class Initialized
ERROR - 2011-09-29 13:08:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-29 13:08:17 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:17 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:17 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Controller Class Initialized
ERROR - 2011-09-29 13:08:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:08:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:17 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:08:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:08:17 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:17 --> Total execution time: 0.0442
DEBUG - 2011-09-29 13:08:17 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:17 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:17 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Controller Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:18 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:18 --> Total execution time: 0.7223
DEBUG - 2011-09-29 13:08:44 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:44 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:44 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Controller Class Initialized
ERROR - 2011-09-29 13:08:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:08:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:44 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:08:44 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:08:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:08:44 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:44 --> Total execution time: 0.0336
DEBUG - 2011-09-29 13:08:45 --> Config Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:08:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:08:45 --> URI Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Router Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Output Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Input Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:08:45 --> Language Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Loader Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Controller Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Model Class Initialized
DEBUG - 2011-09-29 13:08:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:08:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:08:46 --> Final output sent to browser
DEBUG - 2011-09-29 13:08:46 --> Total execution time: 0.5237
DEBUG - 2011-09-29 13:09:54 --> Config Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:09:54 --> URI Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Router Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Output Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Input Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:09:54 --> Language Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Loader Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Controller Class Initialized
ERROR - 2011-09-29 13:09:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:09:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:09:54 --> Model Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Model Class Initialized
DEBUG - 2011-09-29 13:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:09:54 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:09:54 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:09:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:09:54 --> Final output sent to browser
DEBUG - 2011-09-29 13:09:54 --> Total execution time: 0.0362
DEBUG - 2011-09-29 13:10:17 --> Config Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:10:17 --> URI Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Router Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Output Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Input Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:10:17 --> Language Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Loader Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Controller Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Model Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:10:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:10:17 --> Final output sent to browser
DEBUG - 2011-09-29 13:10:17 --> Total execution time: 0.6482
DEBUG - 2011-09-29 13:10:29 --> Config Class Initialized
DEBUG - 2011-09-29 13:10:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:10:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:10:29 --> URI Class Initialized
DEBUG - 2011-09-29 13:10:29 --> Router Class Initialized
ERROR - 2011-09-29 13:10:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 13:11:11 --> Config Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:11:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:11:11 --> URI Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Router Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Output Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Input Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:11:11 --> Language Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Loader Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Controller Class Initialized
ERROR - 2011-09-29 13:11:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 13:11:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:11:11 --> Model Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Model Class Initialized
DEBUG - 2011-09-29 13:11:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:11:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 13:11:11 --> Helper loaded: url_helper
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 13:11:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 13:11:11 --> Final output sent to browser
DEBUG - 2011-09-29 13:11:11 --> Total execution time: 0.1489
DEBUG - 2011-09-29 13:11:14 --> Config Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:11:14 --> URI Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Router Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Output Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Input Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 13:11:14 --> Language Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Loader Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Controller Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Model Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Model Class Initialized
DEBUG - 2011-09-29 13:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 13:11:14 --> Database Driver Class Initialized
DEBUG - 2011-09-29 13:11:15 --> Final output sent to browser
DEBUG - 2011-09-29 13:11:15 --> Total execution time: 1.0052
DEBUG - 2011-09-29 13:11:26 --> Config Class Initialized
DEBUG - 2011-09-29 13:11:26 --> Hooks Class Initialized
DEBUG - 2011-09-29 13:11:26 --> Utf8 Class Initialized
DEBUG - 2011-09-29 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 13:11:26 --> URI Class Initialized
DEBUG - 2011-09-29 13:11:26 --> Router Class Initialized
ERROR - 2011-09-29 13:11:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:41:18 --> Config Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:41:18 --> URI Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Router Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Output Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Input Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:41:18 --> Language Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Loader Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Controller Class Initialized
ERROR - 2011-09-29 15:41:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:41:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:41:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:41:18 --> Model Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Model Class Initialized
DEBUG - 2011-09-29 15:41:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:41:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:41:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:41:19 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:41:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:41:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:41:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:41:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:41:19 --> Final output sent to browser
DEBUG - 2011-09-29 15:41:19 --> Total execution time: 0.7586
DEBUG - 2011-09-29 15:41:20 --> Config Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:41:20 --> URI Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Router Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Output Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Input Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:41:20 --> Language Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Loader Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Controller Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Model Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Model Class Initialized
DEBUG - 2011-09-29 15:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:41:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:41:21 --> Final output sent to browser
DEBUG - 2011-09-29 15:41:21 --> Total execution time: 0.9531
DEBUG - 2011-09-29 15:41:21 --> Config Class Initialized
DEBUG - 2011-09-29 15:41:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:41:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:41:21 --> URI Class Initialized
DEBUG - 2011-09-29 15:41:21 --> Router Class Initialized
ERROR - 2011-09-29 15:41:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:42:02 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:02 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:02 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:02 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:02 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:02 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:02 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:02 --> Total execution time: 0.0354
DEBUG - 2011-09-29 15:42:02 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:02 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:02 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Controller Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:02 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:03 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:03 --> Total execution time: 0.5786
DEBUG - 2011-09-29 15:42:03 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:03 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:03 --> Router Class Initialized
ERROR - 2011-09-29 15:42:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:42:19 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:19 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:19 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:19 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:19 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:19 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:19 --> Total execution time: 0.0309
DEBUG - 2011-09-29 15:42:20 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:20 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:20 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Controller Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:20 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:20 --> Total execution time: 0.5736
DEBUG - 2011-09-29 15:42:21 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:21 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:21 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:21 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:21 --> Router Class Initialized
ERROR - 2011-09-29 15:42:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:42:28 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:28 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:28 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:28 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:28 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:28 --> Total execution time: 0.0356
DEBUG - 2011-09-29 15:42:28 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:28 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:28 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Controller Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:29 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:29 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:29 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:29 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:29 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:29 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:29 --> Total execution time: 0.0351
DEBUG - 2011-09-29 15:42:29 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:29 --> Total execution time: 0.6376
DEBUG - 2011-09-29 15:42:29 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:29 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:29 --> Router Class Initialized
ERROR - 2011-09-29 15:42:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:42:38 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:38 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:38 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:38 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:38 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:38 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:38 --> Total execution time: 0.0308
DEBUG - 2011-09-29 15:42:38 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:38 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:38 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Controller Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:38 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:39 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:39 --> Total execution time: 0.6218
DEBUG - 2011-09-29 15:42:39 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:39 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:39 --> Router Class Initialized
ERROR - 2011-09-29 15:42:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:42:58 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:58 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:58 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Controller Class Initialized
ERROR - 2011-09-29 15:42:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:42:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:58 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:58 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:42:58 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:42:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:42:58 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:58 --> Total execution time: 0.0318
DEBUG - 2011-09-29 15:42:58 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:58 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Router Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Output Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Input Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:42:58 --> Language Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Loader Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Controller Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Model Class Initialized
DEBUG - 2011-09-29 15:42:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:42:58 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:42:59 --> Final output sent to browser
DEBUG - 2011-09-29 15:42:59 --> Total execution time: 0.5980
DEBUG - 2011-09-29 15:42:59 --> Config Class Initialized
DEBUG - 2011-09-29 15:42:59 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:42:59 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:42:59 --> URI Class Initialized
DEBUG - 2011-09-29 15:42:59 --> Router Class Initialized
ERROR - 2011-09-29 15:42:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:43:05 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:05 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Router Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Output Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Input Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:43:05 --> Language Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Loader Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Controller Class Initialized
ERROR - 2011-09-29 15:43:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:43:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:43:05 --> Final output sent to browser
DEBUG - 2011-09-29 15:43:05 --> Total execution time: 0.0764
DEBUG - 2011-09-29 15:43:05 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:05 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Router Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Output Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Input Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:43:05 --> Language Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Loader Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Controller Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:43:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Final output sent to browser
DEBUG - 2011-09-29 15:43:06 --> Total execution time: 0.6163
DEBUG - 2011-09-29 15:43:06 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:06 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Router Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Output Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Input Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:43:06 --> Language Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Loader Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Controller Class Initialized
ERROR - 2011-09-29 15:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:06 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:43:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:43:06 --> Final output sent to browser
DEBUG - 2011-09-29 15:43:06 --> Total execution time: 0.0366
DEBUG - 2011-09-29 15:43:06 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:06 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:06 --> Router Class Initialized
ERROR - 2011-09-29 15:43:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:43:11 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:11 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Router Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Output Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Input Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:43:11 --> Language Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Loader Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Controller Class Initialized
ERROR - 2011-09-29 15:43:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:43:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:11 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:43:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:43:11 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:43:11 --> Final output sent to browser
DEBUG - 2011-09-29 15:43:11 --> Total execution time: 0.0308
DEBUG - 2011-09-29 15:43:11 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:11 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Router Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Output Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Input Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:43:11 --> Language Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Loader Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Controller Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Model Class Initialized
DEBUG - 2011-09-29 15:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:43:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:43:12 --> Final output sent to browser
DEBUG - 2011-09-29 15:43:12 --> Total execution time: 0.8870
DEBUG - 2011-09-29 15:43:13 --> Config Class Initialized
DEBUG - 2011-09-29 15:43:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:43:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:43:13 --> URI Class Initialized
DEBUG - 2011-09-29 15:43:13 --> Router Class Initialized
ERROR - 2011-09-29 15:43:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 15:57:45 --> Config Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:57:45 --> URI Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Router Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Output Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Input Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:57:45 --> Language Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Loader Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Controller Class Initialized
ERROR - 2011-09-29 15:57:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 15:57:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:57:45 --> Model Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Model Class Initialized
DEBUG - 2011-09-29 15:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:57:45 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 15:57:45 --> Helper loaded: url_helper
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 15:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 15:57:45 --> Final output sent to browser
DEBUG - 2011-09-29 15:57:45 --> Total execution time: 0.0706
DEBUG - 2011-09-29 15:57:53 --> Config Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 15:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 15:57:53 --> URI Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Router Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Output Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Input Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 15:57:53 --> Language Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Loader Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Controller Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Model Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Model Class Initialized
DEBUG - 2011-09-29 15:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 15:57:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 15:57:54 --> Final output sent to browser
DEBUG - 2011-09-29 15:57:54 --> Total execution time: 0.5648
DEBUG - 2011-09-29 16:48:13 --> Config Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 16:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 16:48:13 --> URI Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Router Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Output Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Input Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 16:48:13 --> Language Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Loader Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Controller Class Initialized
ERROR - 2011-09-29 16:48:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 16:48:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 16:48:13 --> Model Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Model Class Initialized
DEBUG - 2011-09-29 16:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 16:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 16:48:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 16:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 16:48:13 --> Final output sent to browser
DEBUG - 2011-09-29 16:48:13 --> Total execution time: 0.3147
DEBUG - 2011-09-29 16:56:09 --> Config Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 16:56:09 --> URI Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Router Class Initialized
DEBUG - 2011-09-29 16:56:09 --> No URI present. Default controller set.
DEBUG - 2011-09-29 16:56:09 --> Output Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Input Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 16:56:09 --> Language Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Loader Class Initialized
DEBUG - 2011-09-29 16:56:09 --> Controller Class Initialized
DEBUG - 2011-09-29 16:56:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 16:56:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 16:56:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 16:56:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 16:56:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 16:56:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 16:56:09 --> Final output sent to browser
DEBUG - 2011-09-29 16:56:09 --> Total execution time: 0.0430
DEBUG - 2011-09-29 17:07:39 --> Config Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:07:39 --> URI Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Router Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Output Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Input Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:07:39 --> Language Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Loader Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Controller Class Initialized
ERROR - 2011-09-29 17:07:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 17:07:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 17:07:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:07:39 --> Model Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Model Class Initialized
DEBUG - 2011-09-29 17:07:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:07:39 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:07:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:07:40 --> Helper loaded: url_helper
DEBUG - 2011-09-29 17:07:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 17:07:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 17:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 17:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 17:07:40 --> Final output sent to browser
DEBUG - 2011-09-29 17:07:40 --> Total execution time: 0.0382
DEBUG - 2011-09-29 17:07:41 --> Config Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:07:41 --> URI Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Router Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Output Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Input Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:07:41 --> Language Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Loader Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Controller Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Model Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Model Class Initialized
DEBUG - 2011-09-29 17:07:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:07:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:07:43 --> Final output sent to browser
DEBUG - 2011-09-29 17:07:43 --> Total execution time: 1.2652
DEBUG - 2011-09-29 17:07:44 --> Config Class Initialized
DEBUG - 2011-09-29 17:07:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:07:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:07:44 --> URI Class Initialized
DEBUG - 2011-09-29 17:07:44 --> Router Class Initialized
ERROR - 2011-09-29 17:07:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 17:11:12 --> Config Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:11:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:11:12 --> URI Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Router Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Output Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Input Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:11:12 --> Language Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Loader Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Controller Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Model Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Model Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Model Class Initialized
DEBUG - 2011-09-29 17:11:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:11:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:11:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 17:11:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 17:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 17:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 17:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 17:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 17:11:13 --> Final output sent to browser
DEBUG - 2011-09-29 17:11:13 --> Total execution time: 0.6226
DEBUG - 2011-09-29 17:11:14 --> Config Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:11:14 --> URI Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Router Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Output Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Input Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:11:14 --> Language Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Loader Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Controller Class Initialized
ERROR - 2011-09-29 17:11:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 17:11:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:11:14 --> Model Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Model Class Initialized
DEBUG - 2011-09-29 17:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:11:14 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:11:14 --> Helper loaded: url_helper
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 17:11:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 17:11:14 --> Final output sent to browser
DEBUG - 2011-09-29 17:11:14 --> Total execution time: 0.0544
DEBUG - 2011-09-29 17:46:34 --> Config Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:46:34 --> URI Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Router Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Output Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Input Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:46:34 --> Language Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Loader Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Controller Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Model Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Model Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Model Class Initialized
DEBUG - 2011-09-29 17:46:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:46:34 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:46:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 17:46:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 17:46:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 17:46:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 17:46:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 17:46:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 17:46:35 --> Final output sent to browser
DEBUG - 2011-09-29 17:46:35 --> Total execution time: 1.0092
DEBUG - 2011-09-29 17:46:36 --> Config Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 17:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 17:46:36 --> URI Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Router Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Output Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Input Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 17:46:36 --> Language Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Loader Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Controller Class Initialized
ERROR - 2011-09-29 17:46:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 17:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 17:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:46:36 --> Model Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Model Class Initialized
DEBUG - 2011-09-29 17:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 17:46:37 --> Database Driver Class Initialized
DEBUG - 2011-09-29 17:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 17:46:37 --> Helper loaded: url_helper
DEBUG - 2011-09-29 17:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 17:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 17:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 17:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 17:46:37 --> Final output sent to browser
DEBUG - 2011-09-29 17:46:37 --> Total execution time: 0.1103
DEBUG - 2011-09-29 18:37:15 --> Config Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 18:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 18:37:15 --> URI Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Router Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Output Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Input Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 18:37:15 --> Language Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Loader Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Controller Class Initialized
ERROR - 2011-09-29 18:37:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 18:37:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 18:37:15 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 18:37:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 18:37:15 --> Helper loaded: url_helper
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 18:37:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 18:37:15 --> Final output sent to browser
DEBUG - 2011-09-29 18:37:15 --> Total execution time: 0.2542
DEBUG - 2011-09-29 18:37:16 --> Config Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 18:37:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 18:37:16 --> URI Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Router Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Output Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Input Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 18:37:16 --> Language Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Loader Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Controller Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 18:37:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 18:37:17 --> Final output sent to browser
DEBUG - 2011-09-29 18:37:17 --> Total execution time: 0.8807
DEBUG - 2011-09-29 18:37:19 --> Config Class Initialized
DEBUG - 2011-09-29 18:37:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 18:37:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 18:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 18:37:19 --> URI Class Initialized
DEBUG - 2011-09-29 18:37:19 --> Router Class Initialized
ERROR - 2011-09-29 18:37:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 18:37:51 --> Config Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 18:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 18:37:51 --> URI Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Router Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Output Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Input Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 18:37:51 --> Language Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Loader Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Controller Class Initialized
ERROR - 2011-09-29 18:37:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 18:37:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 18:37:51 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 18:37:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 18:37:51 --> Helper loaded: url_helper
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 18:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 18:37:51 --> Final output sent to browser
DEBUG - 2011-09-29 18:37:51 --> Total execution time: 0.1248
DEBUG - 2011-09-29 18:37:52 --> Config Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 18:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 18:37:52 --> URI Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Router Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Output Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Input Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 18:37:52 --> Language Class Initialized
DEBUG - 2011-09-29 18:37:52 --> Loader Class Initialized
DEBUG - 2011-09-29 18:37:53 --> Controller Class Initialized
DEBUG - 2011-09-29 18:37:53 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:53 --> Model Class Initialized
DEBUG - 2011-09-29 18:37:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 18:37:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 18:37:53 --> Final output sent to browser
DEBUG - 2011-09-29 18:37:53 --> Total execution time: 0.8218
DEBUG - 2011-09-29 19:09:48 --> Config Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:09:48 --> URI Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Router Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Output Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Input Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:09:48 --> Language Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Loader Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Controller Class Initialized
ERROR - 2011-09-29 19:09:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:09:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:09:48 --> Model Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Model Class Initialized
DEBUG - 2011-09-29 19:09:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:09:48 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:09:48 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:09:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:09:48 --> Final output sent to browser
DEBUG - 2011-09-29 19:09:48 --> Total execution time: 0.1330
DEBUG - 2011-09-29 19:09:51 --> Config Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:09:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:09:51 --> URI Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Router Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Output Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Input Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:09:51 --> Language Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Loader Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Controller Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Model Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Model Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:09:51 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:09:51 --> Final output sent to browser
DEBUG - 2011-09-29 19:09:51 --> Total execution time: 0.7353
DEBUG - 2011-09-29 19:10:43 --> Config Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:10:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:10:43 --> URI Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Router Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Output Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Input Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:10:43 --> Language Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Loader Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Controller Class Initialized
ERROR - 2011-09-29 19:10:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:10:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:10:43 --> Model Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Model Class Initialized
DEBUG - 2011-09-29 19:10:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:10:43 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:10:43 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:10:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:10:43 --> Final output sent to browser
DEBUG - 2011-09-29 19:10:43 --> Total execution time: 0.0420
DEBUG - 2011-09-29 19:10:46 --> Config Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:10:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:10:46 --> URI Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Router Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Output Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Input Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:10:46 --> Language Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Loader Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Controller Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Model Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Model Class Initialized
DEBUG - 2011-09-29 19:10:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:10:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:10:47 --> Final output sent to browser
DEBUG - 2011-09-29 19:10:47 --> Total execution time: 0.6770
DEBUG - 2011-09-29 19:11:46 --> Config Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:11:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:11:46 --> URI Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Router Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Output Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Input Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:11:46 --> Language Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Loader Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Controller Class Initialized
ERROR - 2011-09-29 19:11:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:11:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:11:46 --> Model Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Model Class Initialized
DEBUG - 2011-09-29 19:11:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:11:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:11:46 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:11:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:11:46 --> Final output sent to browser
DEBUG - 2011-09-29 19:11:46 --> Total execution time: 0.0387
DEBUG - 2011-09-29 19:11:49 --> Config Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:11:49 --> URI Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Router Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Output Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Input Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:11:49 --> Language Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Loader Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Controller Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Model Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Model Class Initialized
DEBUG - 2011-09-29 19:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:11:49 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:11:50 --> Final output sent to browser
DEBUG - 2011-09-29 19:11:50 --> Total execution time: 1.4691
DEBUG - 2011-09-29 19:13:27 --> Config Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:13:27 --> URI Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Router Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Output Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Input Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:13:27 --> Language Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Loader Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Controller Class Initialized
ERROR - 2011-09-29 19:13:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:13:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:27 --> Config Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:13:27 --> URI Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Router Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Output Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Input Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:13:27 --> Language Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Loader Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Controller Class Initialized
ERROR - 2011-09-29 19:13:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
ERROR - 2011-09-29 19:13:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:13:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:27 --> Config Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:13:27 --> URI Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Router Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Output Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Input Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:13:27 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:13:27 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:27 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:13:27 --> Language Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Loader Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Controller Class Initialized
ERROR - 2011-09-29 19:13:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:13:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Model Class Initialized
DEBUG - 2011-09-29 19:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:13:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:13:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:13:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:13:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:13:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:13:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:13:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:13:28 --> Final output sent to browser
DEBUG - 2011-09-29 19:13:28 --> Total execution time: 0.3992
DEBUG - 2011-09-29 19:14:03 --> Config Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:14:03 --> URI Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Router Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Output Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Input Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:14:03 --> Language Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Loader Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Controller Class Initialized
ERROR - 2011-09-29 19:14:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:14:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:14:03 --> Model Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Model Class Initialized
DEBUG - 2011-09-29 19:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:14:03 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:14:03 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:14:03 --> Final output sent to browser
DEBUG - 2011-09-29 19:14:03 --> Total execution time: 0.0314
DEBUG - 2011-09-29 19:14:04 --> Config Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:14:04 --> URI Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Router Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Output Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Input Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:14:04 --> Language Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Loader Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Controller Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Model Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Model Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:14:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:14:04 --> Final output sent to browser
DEBUG - 2011-09-29 19:14:04 --> Total execution time: 0.6043
DEBUG - 2011-09-29 19:14:05 --> Config Class Initialized
DEBUG - 2011-09-29 19:14:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:14:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:14:05 --> URI Class Initialized
DEBUG - 2011-09-29 19:14:05 --> Router Class Initialized
ERROR - 2011-09-29 19:14:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 19:14:06 --> Config Class Initialized
DEBUG - 2011-09-29 19:14:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:14:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:14:06 --> URI Class Initialized
DEBUG - 2011-09-29 19:14:06 --> Router Class Initialized
ERROR - 2011-09-29 19:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 19:15:37 --> Config Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:15:37 --> URI Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Router Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Output Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Input Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:15:37 --> Language Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Loader Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Controller Class Initialized
ERROR - 2011-09-29 19:15:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:15:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:15:37 --> Model Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Model Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:15:37 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:15:37 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:15:37 --> Final output sent to browser
DEBUG - 2011-09-29 19:15:37 --> Total execution time: 0.0346
DEBUG - 2011-09-29 19:15:37 --> Config Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:15:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:15:37 --> URI Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Router Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Output Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Input Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:15:37 --> Language Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Loader Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Controller Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Model Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Model Class Initialized
DEBUG - 2011-09-29 19:15:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:15:38 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:15:38 --> Final output sent to browser
DEBUG - 2011-09-29 19:15:38 --> Total execution time: 0.6651
DEBUG - 2011-09-29 19:17:05 --> Config Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:17:05 --> URI Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Router Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Output Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Input Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:17:05 --> Language Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Loader Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Controller Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:17:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:17:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 19:17:06 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:17:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:17:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:17:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:17:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:17:06 --> Final output sent to browser
DEBUG - 2011-09-29 19:17:06 --> Total execution time: 0.8447
DEBUG - 2011-09-29 19:17:12 --> Config Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:17:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:17:12 --> URI Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Router Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Output Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Input Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:17:12 --> Language Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Loader Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Controller Class Initialized
ERROR - 2011-09-29 19:17:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 19:17:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:17:12 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:17:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 19:17:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:17:12 --> Final output sent to browser
DEBUG - 2011-09-29 19:17:12 --> Total execution time: 0.0424
DEBUG - 2011-09-29 19:17:16 --> Config Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:17:16 --> URI Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Router Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Output Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Input Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:17:16 --> Language Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Loader Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Controller Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Model Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:17:16 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:17:16 --> Final output sent to browser
DEBUG - 2011-09-29 19:17:16 --> Total execution time: 0.5684
DEBUG - 2011-09-29 19:17:38 --> Config Class Initialized
DEBUG - 2011-09-29 19:17:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:17:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:17:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:17:38 --> URI Class Initialized
DEBUG - 2011-09-29 19:17:38 --> Router Class Initialized
ERROR - 2011-09-29 19:17:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 19:18:11 --> Config Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:18:11 --> URI Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Router Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Output Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Input Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:18:11 --> Language Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Loader Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Controller Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:18:11 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:18:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 19:18:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:18:12 --> Final output sent to browser
DEBUG - 2011-09-29 19:18:12 --> Total execution time: 0.4242
DEBUG - 2011-09-29 19:18:17 --> Config Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 19:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 19:18:17 --> URI Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Router Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Output Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Input Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 19:18:17 --> Language Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Loader Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Controller Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Model Class Initialized
DEBUG - 2011-09-29 19:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 19:18:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 19:18:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 19:18:17 --> Helper loaded: url_helper
DEBUG - 2011-09-29 19:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 19:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 19:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 19:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 19:18:17 --> Final output sent to browser
DEBUG - 2011-09-29 19:18:17 --> Total execution time: 0.0529
DEBUG - 2011-09-29 20:01:24 --> Config Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 20:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 20:01:24 --> URI Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Router Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Output Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Input Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 20:01:24 --> Language Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Loader Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Controller Class Initialized
ERROR - 2011-09-29 20:01:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 20:01:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 20:01:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 20:01:24 --> Model Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Model Class Initialized
DEBUG - 2011-09-29 20:01:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 20:01:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 20:01:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 20:01:25 --> Helper loaded: url_helper
DEBUG - 2011-09-29 20:01:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 20:01:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 20:01:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 20:01:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 20:01:25 --> Final output sent to browser
DEBUG - 2011-09-29 20:01:25 --> Total execution time: 0.2593
DEBUG - 2011-09-29 20:01:28 --> Config Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 20:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 20:01:28 --> URI Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Router Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Output Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Input Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 20:01:28 --> Language Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Loader Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Controller Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Model Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Model Class Initialized
DEBUG - 2011-09-29 20:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 20:01:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 20:01:30 --> Final output sent to browser
DEBUG - 2011-09-29 20:01:30 --> Total execution time: 2.2477
DEBUG - 2011-09-29 20:01:48 --> Config Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Hooks Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Utf8 Class Initialized
DEBUG - 2011-09-29 20:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 20:01:48 --> URI Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Router Class Initialized
DEBUG - 2011-09-29 20:01:48 --> No URI present. Default controller set.
DEBUG - 2011-09-29 20:01:48 --> Output Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Input Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 20:01:48 --> Language Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Loader Class Initialized
DEBUG - 2011-09-29 20:01:48 --> Controller Class Initialized
DEBUG - 2011-09-29 20:01:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 20:01:49 --> Helper loaded: url_helper
DEBUG - 2011-09-29 20:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 20:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 20:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 20:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 20:01:49 --> Final output sent to browser
DEBUG - 2011-09-29 20:01:49 --> Total execution time: 0.0401
DEBUG - 2011-09-29 21:02:18 --> Config Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:02:18 --> URI Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Router Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Output Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Input Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:02:18 --> Language Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Loader Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Controller Class Initialized
ERROR - 2011-09-29 21:02:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:02:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:02:18 --> Model Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Model Class Initialized
DEBUG - 2011-09-29 21:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:02:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:02:18 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:02:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:02:18 --> Final output sent to browser
DEBUG - 2011-09-29 21:02:18 --> Total execution time: 0.1045
DEBUG - 2011-09-29 21:02:19 --> Config Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:02:19 --> URI Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Router Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Output Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Input Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:02:19 --> Language Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Loader Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Controller Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Model Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Model Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:02:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:02:19 --> Final output sent to browser
DEBUG - 2011-09-29 21:02:19 --> Total execution time: 0.7330
DEBUG - 2011-09-29 21:02:40 --> Config Class Initialized
DEBUG - 2011-09-29 21:02:40 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:02:40 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:02:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:02:40 --> URI Class Initialized
DEBUG - 2011-09-29 21:02:40 --> Router Class Initialized
ERROR - 2011-09-29 21:02:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 21:02:41 --> Config Class Initialized
DEBUG - 2011-09-29 21:02:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:02:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:02:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:02:41 --> URI Class Initialized
DEBUG - 2011-09-29 21:02:41 --> Router Class Initialized
ERROR - 2011-09-29 21:02:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-29 21:11:08 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:08 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:08 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:08 --> Controller Class Initialized
ERROR - 2011-09-29 21:11:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:11:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:09 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:09 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:11:09 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:09 --> Total execution time: 0.0406
DEBUG - 2011-09-29 21:11:09 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:09 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:09 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Controller Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:09 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:10 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:10 --> Total execution time: 0.7062
DEBUG - 2011-09-29 21:11:24 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:24 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:24 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Controller Class Initialized
ERROR - 2011-09-29 21:11:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:11:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:24 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:24 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:11:24 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:24 --> Total execution time: 0.2376
DEBUG - 2011-09-29 21:11:25 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:25 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:25 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Controller Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:25 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:25 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:25 --> Total execution time: 0.7723
DEBUG - 2011-09-29 21:11:36 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:36 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:36 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Controller Class Initialized
ERROR - 2011-09-29 21:11:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:11:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:36 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:36 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:36 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:11:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:11:36 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:36 --> Total execution time: 0.0311
DEBUG - 2011-09-29 21:11:37 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:37 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:37 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Controller Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:37 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:38 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:38 --> Total execution time: 0.8013
DEBUG - 2011-09-29 21:11:41 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:41 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:41 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Controller Class Initialized
ERROR - 2011-09-29 21:11:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:11:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:41 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:41 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:41 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:11:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:11:41 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:41 --> Total execution time: 0.0338
DEBUG - 2011-09-29 21:11:47 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:47 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:47 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Controller Class Initialized
ERROR - 2011-09-29 21:11:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:11:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:11:47 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:11:47 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:47 --> Total execution time: 0.0346
DEBUG - 2011-09-29 21:11:47 --> Config Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:11:47 --> URI Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Router Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Output Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Input Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:11:47 --> Language Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Loader Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Controller Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Model Class Initialized
DEBUG - 2011-09-29 21:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:11:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:11:49 --> Final output sent to browser
DEBUG - 2011-09-29 21:11:49 --> Total execution time: 1.5747
DEBUG - 2011-09-29 21:12:04 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:04 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:04 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:04 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:04 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:04 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:04 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:04 --> Total execution time: 0.0337
DEBUG - 2011-09-29 21:12:05 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:05 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:05 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Controller Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:06 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:06 --> Total execution time: 0.9893
DEBUG - 2011-09-29 21:12:20 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:20 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:20 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:20 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:20 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:20 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:20 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:20 --> Total execution time: 0.0495
DEBUG - 2011-09-29 21:12:22 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:22 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:22 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Controller Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:22 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:22 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:22 --> Total execution time: 0.6943
DEBUG - 2011-09-29 21:12:28 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:28 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:28 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:28 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:28 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:28 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:28 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:28 --> Total execution time: 0.0374
DEBUG - 2011-09-29 21:12:29 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:29 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:29 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Controller Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:29 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:29 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:29 --> Total execution time: 0.6083
DEBUG - 2011-09-29 21:12:30 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:30 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:30 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:30 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:30 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:30 --> Total execution time: 0.0344
DEBUG - 2011-09-29 21:12:38 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:38 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:38 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:38 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:38 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:39 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:39 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:39 --> Total execution time: 0.4618
DEBUG - 2011-09-29 21:12:40 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:40 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:40 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Controller Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:40 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:41 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:41 --> Total execution time: 0.8054
DEBUG - 2011-09-29 21:12:42 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:42 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:42 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Controller Class Initialized
ERROR - 2011-09-29 21:12:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:12:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:12:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:42 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:12:43 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:12:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:12:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:12:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:12:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:12:43 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:43 --> Total execution time: 0.8206
DEBUG - 2011-09-29 21:12:44 --> Config Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:12:44 --> URI Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Router Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Output Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Input Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:12:44 --> Language Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Loader Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Controller Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Model Class Initialized
DEBUG - 2011-09-29 21:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:12:44 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:12:45 --> Final output sent to browser
DEBUG - 2011-09-29 21:12:45 --> Total execution time: 0.9788
DEBUG - 2011-09-29 21:13:17 --> Config Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:13:17 --> URI Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Router Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Output Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Input Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:13:17 --> Language Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Loader Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Controller Class Initialized
ERROR - 2011-09-29 21:13:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:13:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:13:17 --> Model Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Model Class Initialized
DEBUG - 2011-09-29 21:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:13:17 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:13:17 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:13:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:13:17 --> Final output sent to browser
DEBUG - 2011-09-29 21:13:17 --> Total execution time: 0.0775
DEBUG - 2011-09-29 21:38:13 --> Config Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:38:13 --> URI Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Router Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Output Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Input Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:38:13 --> Language Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Loader Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Controller Class Initialized
ERROR - 2011-09-29 21:38:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 21:38:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:38:13 --> Model Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Model Class Initialized
DEBUG - 2011-09-29 21:38:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:38:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 21:38:13 --> Helper loaded: url_helper
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 21:38:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 21:38:13 --> Final output sent to browser
DEBUG - 2011-09-29 21:38:13 --> Total execution time: 0.1066
DEBUG - 2011-09-29 21:38:15 --> Config Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Hooks Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Utf8 Class Initialized
DEBUG - 2011-09-29 21:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 21:38:15 --> URI Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Router Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Output Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Input Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 21:38:15 --> Language Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Loader Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Controller Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Model Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Model Class Initialized
DEBUG - 2011-09-29 21:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 21:38:15 --> Database Driver Class Initialized
DEBUG - 2011-09-29 21:38:16 --> Final output sent to browser
DEBUG - 2011-09-29 21:38:16 --> Total execution time: 1.1584
DEBUG - 2011-09-29 22:35:30 --> Config Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 22:35:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 22:35:30 --> URI Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Router Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Output Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Input Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 22:35:30 --> Language Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Loader Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Controller Class Initialized
ERROR - 2011-09-29 22:35:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 22:35:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 22:35:30 --> Model Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Model Class Initialized
DEBUG - 2011-09-29 22:35:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 22:35:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 22:35:30 --> Helper loaded: url_helper
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 22:35:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 22:35:30 --> Final output sent to browser
DEBUG - 2011-09-29 22:35:30 --> Total execution time: 0.2283
DEBUG - 2011-09-29 22:35:33 --> Config Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Hooks Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Utf8 Class Initialized
DEBUG - 2011-09-29 22:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 22:35:33 --> URI Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Router Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Output Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Input Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 22:35:33 --> Language Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Loader Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Controller Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Model Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Model Class Initialized
DEBUG - 2011-09-29 22:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 22:35:33 --> Database Driver Class Initialized
DEBUG - 2011-09-29 22:35:34 --> Final output sent to browser
DEBUG - 2011-09-29 22:35:34 --> Total execution time: 0.6728
DEBUG - 2011-09-29 23:16:58 --> Config Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:16:58 --> URI Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Router Class Initialized
DEBUG - 2011-09-29 23:16:58 --> No URI present. Default controller set.
DEBUG - 2011-09-29 23:16:58 --> Output Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Input Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:16:58 --> Language Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Loader Class Initialized
DEBUG - 2011-09-29 23:16:58 --> Controller Class Initialized
DEBUG - 2011-09-29 23:16:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-29 23:16:58 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:16:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:16:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:16:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:16:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:16:58 --> Final output sent to browser
DEBUG - 2011-09-29 23:16:58 --> Total execution time: 0.0551
DEBUG - 2011-09-29 23:17:55 --> Config Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:17:55 --> URI Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Router Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Output Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Input Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:17:55 --> Language Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Loader Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Controller Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Model Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Model Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Model Class Initialized
DEBUG - 2011-09-29 23:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:17:55 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:17:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 23:17:56 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:17:56 --> Final output sent to browser
DEBUG - 2011-09-29 23:17:56 --> Total execution time: 0.7486
DEBUG - 2011-09-29 23:18:05 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:05 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:05 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:05 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:05 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:05 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:05 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:05 --> Total execution time: 0.0315
DEBUG - 2011-09-29 23:18:06 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:06 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:06 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:06 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:07 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:07 --> Total execution time: 0.8491
DEBUG - 2011-09-29 23:18:12 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:12 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:12 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:12 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:12 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:12 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:12 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:12 --> Total execution time: 0.0451
DEBUG - 2011-09-29 23:18:13 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:13 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:13 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:13 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:14 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:14 --> Total execution time: 0.6638
DEBUG - 2011-09-29 23:18:18 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:18 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:18 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:18 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:18 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:18 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:18 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:18 --> Total execution time: 0.0329
DEBUG - 2011-09-29 23:18:19 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:19 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:19 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:19 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:20 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:20 --> Total execution time: 0.6076
DEBUG - 2011-09-29 23:18:24 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:24 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:24 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:24 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:24 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:24 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:24 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:24 --> Total execution time: 0.0310
DEBUG - 2011-09-29 23:18:25 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:25 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:25 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:25 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:25 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:25 --> Total execution time: 0.7819
DEBUG - 2011-09-29 23:18:29 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:29 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:29 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:29 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:29 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:29 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:29 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:29 --> Total execution time: 0.0329
DEBUG - 2011-09-29 23:18:30 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:30 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:30 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:30 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:31 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:31 --> Total execution time: 0.5953
DEBUG - 2011-09-29 23:18:35 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:35 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:35 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:35 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-29 23:18:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:35 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:35 --> Total execution time: 0.2612
DEBUG - 2011-09-29 23:18:35 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:35 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:35 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:35 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:35 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:35 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:35 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:35 --> Total execution time: 0.0351
DEBUG - 2011-09-29 23:18:37 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:37 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:37 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:37 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:37 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:37 --> Total execution time: 0.6298
DEBUG - 2011-09-29 23:18:40 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:40 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:40 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:40 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:40 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:40 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:40 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:40 --> Total execution time: 0.0314
DEBUG - 2011-09-29 23:18:42 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:42 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:42 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:42 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:42 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:42 --> Total execution time: 0.5772
DEBUG - 2011-09-29 23:18:46 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:46 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:46 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:46 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:46 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:46 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:46 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:46 --> Total execution time: 0.0966
DEBUG - 2011-09-29 23:18:47 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:47 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:47 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:47 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:48 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:48 --> Total execution time: 0.5144
DEBUG - 2011-09-29 23:18:52 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:52 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:52 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Controller Class Initialized
ERROR - 2011-09-29 23:18:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-29 23:18:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:52 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:52 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-29 23:18:52 --> Helper loaded: url_helper
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-29 23:18:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-29 23:18:52 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:52 --> Total execution time: 0.0333
DEBUG - 2011-09-29 23:18:53 --> Config Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Hooks Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Utf8 Class Initialized
DEBUG - 2011-09-29 23:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-29 23:18:53 --> URI Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Router Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Output Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Input Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-29 23:18:53 --> Language Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Loader Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Controller Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Model Class Initialized
DEBUG - 2011-09-29 23:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-29 23:18:53 --> Database Driver Class Initialized
DEBUG - 2011-09-29 23:18:54 --> Final output sent to browser
DEBUG - 2011-09-29 23:18:54 --> Total execution time: 0.6365

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-14 00:46:22 --> Config Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Hooks Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Utf8 Class Initialized
DEBUG - 2011-06-14 00:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 00:46:22 --> URI Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Router Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Output Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Input Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 00:46:22 --> Language Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Loader Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Controller Class Initialized
ERROR - 2011-06-14 00:46:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 00:46:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 00:46:22 --> Model Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Model Class Initialized
DEBUG - 2011-06-14 00:46:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 00:46:22 --> Database Driver Class Initialized
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 00:46:22 --> Helper loaded: url_helper
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 00:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 00:46:22 --> Final output sent to browser
DEBUG - 2011-06-14 00:46:22 --> Total execution time: 0.4475
DEBUG - 2011-06-14 01:00:45 --> Config Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Hooks Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Utf8 Class Initialized
DEBUG - 2011-06-14 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 01:00:45 --> URI Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Router Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Output Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Input Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 01:00:45 --> Language Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Loader Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Controller Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Model Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Model Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Model Class Initialized
DEBUG - 2011-06-14 01:00:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 01:00:45 --> Database Driver Class Initialized
DEBUG - 2011-06-14 01:00:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 01:00:45 --> Helper loaded: url_helper
DEBUG - 2011-06-14 01:00:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 01:00:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 01:00:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 01:00:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 01:00:45 --> Final output sent to browser
DEBUG - 2011-06-14 01:00:45 --> Total execution time: 0.4868
DEBUG - 2011-06-14 01:00:50 --> Config Class Initialized
DEBUG - 2011-06-14 01:00:50 --> Hooks Class Initialized
DEBUG - 2011-06-14 01:00:50 --> Utf8 Class Initialized
DEBUG - 2011-06-14 01:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 01:00:50 --> URI Class Initialized
DEBUG - 2011-06-14 01:00:50 --> Router Class Initialized
ERROR - 2011-06-14 01:00:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 01:13:28 --> Config Class Initialized
DEBUG - 2011-06-14 01:13:28 --> Hooks Class Initialized
DEBUG - 2011-06-14 01:13:28 --> Utf8 Class Initialized
DEBUG - 2011-06-14 01:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 01:13:28 --> URI Class Initialized
DEBUG - 2011-06-14 01:13:28 --> Router Class Initialized
ERROR - 2011-06-14 01:13:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 01:13:29 --> Config Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Hooks Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Utf8 Class Initialized
DEBUG - 2011-06-14 01:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 01:13:29 --> URI Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Router Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Output Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Input Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 01:13:29 --> Language Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Loader Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Controller Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Model Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Model Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Model Class Initialized
DEBUG - 2011-06-14 01:13:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 01:13:29 --> Database Driver Class Initialized
DEBUG - 2011-06-14 01:13:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 01:13:29 --> Helper loaded: url_helper
DEBUG - 2011-06-14 01:13:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 01:13:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 01:13:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 01:13:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 01:13:29 --> Final output sent to browser
DEBUG - 2011-06-14 01:13:29 --> Total execution time: 0.1693
DEBUG - 2011-06-14 01:13:59 --> Config Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Hooks Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Utf8 Class Initialized
DEBUG - 2011-06-14 01:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 01:13:59 --> URI Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Router Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Output Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Input Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 01:13:59 --> Language Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Loader Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Controller Class Initialized
ERROR - 2011-06-14 01:13:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 01:13:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 01:13:59 --> Model Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Model Class Initialized
DEBUG - 2011-06-14 01:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 01:13:59 --> Database Driver Class Initialized
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 01:13:59 --> Helper loaded: url_helper
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 01:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 01:13:59 --> Final output sent to browser
DEBUG - 2011-06-14 01:13:59 --> Total execution time: 0.0457
DEBUG - 2011-06-14 03:09:19 --> Config Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Hooks Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Utf8 Class Initialized
DEBUG - 2011-06-14 03:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 03:09:19 --> URI Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Router Class Initialized
DEBUG - 2011-06-14 03:09:19 --> No URI present. Default controller set.
DEBUG - 2011-06-14 03:09:19 --> Output Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Input Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 03:09:19 --> Language Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Loader Class Initialized
DEBUG - 2011-06-14 03:09:19 --> Controller Class Initialized
DEBUG - 2011-06-14 03:09:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-14 03:09:19 --> Helper loaded: url_helper
DEBUG - 2011-06-14 03:09:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 03:09:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 03:09:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 03:09:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 03:09:19 --> Final output sent to browser
DEBUG - 2011-06-14 03:09:19 --> Total execution time: 0.4270
DEBUG - 2011-06-14 06:42:40 --> Config Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Hooks Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Utf8 Class Initialized
DEBUG - 2011-06-14 06:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 06:42:40 --> URI Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Router Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Output Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Input Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 06:42:40 --> Language Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Loader Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Controller Class Initialized
ERROR - 2011-06-14 06:42:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 06:42:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 06:42:40 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 06:42:40 --> Database Driver Class Initialized
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 06:42:40 --> Helper loaded: url_helper
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 06:42:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 06:42:40 --> Final output sent to browser
DEBUG - 2011-06-14 06:42:40 --> Total execution time: 0.7985
DEBUG - 2011-06-14 06:42:42 --> Config Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Hooks Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Utf8 Class Initialized
DEBUG - 2011-06-14 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 06:42:42 --> URI Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Router Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Output Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Input Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 06:42:42 --> Language Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Loader Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Controller Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 06:42:42 --> Database Driver Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Final output sent to browser
DEBUG - 2011-06-14 06:42:43 --> Total execution time: 0.9658
DEBUG - 2011-06-14 06:42:43 --> Config Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Hooks Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Utf8 Class Initialized
DEBUG - 2011-06-14 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 06:42:43 --> URI Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Router Class Initialized
ERROR - 2011-06-14 06:42:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 06:42:43 --> Config Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Hooks Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Utf8 Class Initialized
DEBUG - 2011-06-14 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 06:42:43 --> URI Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Router Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Output Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Input Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 06:42:43 --> Language Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Loader Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Controller Class Initialized
ERROR - 2011-06-14 06:42:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 06:42:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 06:42:43 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Model Class Initialized
DEBUG - 2011-06-14 06:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 06:42:43 --> Database Driver Class Initialized
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 06:42:43 --> Helper loaded: url_helper
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 06:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 06:42:43 --> Final output sent to browser
DEBUG - 2011-06-14 06:42:43 --> Total execution time: 0.0288
DEBUG - 2011-06-14 06:42:44 --> Config Class Initialized
DEBUG - 2011-06-14 06:42:44 --> Hooks Class Initialized
DEBUG - 2011-06-14 06:42:44 --> Utf8 Class Initialized
DEBUG - 2011-06-14 06:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 06:42:44 --> URI Class Initialized
DEBUG - 2011-06-14 06:42:44 --> Router Class Initialized
ERROR - 2011-06-14 06:42:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 07:05:30 --> Config Class Initialized
DEBUG - 2011-06-14 07:05:31 --> Hooks Class Initialized
DEBUG - 2011-06-14 07:05:31 --> Utf8 Class Initialized
DEBUG - 2011-06-14 07:05:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 07:05:31 --> URI Class Initialized
DEBUG - 2011-06-14 07:05:31 --> Router Class Initialized
ERROR - 2011-06-14 07:05:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 12:18:08 --> Config Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:18:08 --> URI Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Router Class Initialized
ERROR - 2011-06-14 12:18:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 12:18:08 --> Config Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:18:08 --> URI Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Router Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Output Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Input Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 12:18:08 --> Language Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Loader Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Controller Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Model Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Model Class Initialized
DEBUG - 2011-06-14 12:18:08 --> Model Class Initialized
DEBUG - 2011-06-14 12:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 12:18:09 --> Database Driver Class Initialized
DEBUG - 2011-06-14 12:18:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 12:18:09 --> Helper loaded: url_helper
DEBUG - 2011-06-14 12:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 12:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 12:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 12:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 12:18:09 --> Final output sent to browser
DEBUG - 2011-06-14 12:18:09 --> Total execution time: 1.0643
DEBUG - 2011-06-14 12:18:40 --> Config Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:18:40 --> URI Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Router Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Output Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Input Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 12:18:40 --> Language Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Loader Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Controller Class Initialized
ERROR - 2011-06-14 12:18:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 12:18:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 12:18:40 --> Model Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Model Class Initialized
DEBUG - 2011-06-14 12:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 12:18:40 --> Database Driver Class Initialized
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 12:18:40 --> Helper loaded: url_helper
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 12:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 12:18:40 --> Final output sent to browser
DEBUG - 2011-06-14 12:18:40 --> Total execution time: 0.1283
DEBUG - 2011-06-14 12:50:41 --> Config Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:50:41 --> URI Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Router Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Output Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Input Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 12:50:41 --> Language Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Loader Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Controller Class Initialized
ERROR - 2011-06-14 12:50:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 12:50:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 12:50:41 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 12:50:41 --> Database Driver Class Initialized
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 12:50:41 --> Helper loaded: url_helper
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 12:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 12:50:41 --> Final output sent to browser
DEBUG - 2011-06-14 12:50:41 --> Total execution time: 0.4891
DEBUG - 2011-06-14 12:50:42 --> Config Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:50:42 --> URI Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Router Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Output Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Input Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 12:50:42 --> Language Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Loader Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Controller Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 12:50:42 --> Database Driver Class Initialized
DEBUG - 2011-06-14 12:50:43 --> Final output sent to browser
DEBUG - 2011-06-14 12:50:43 --> Total execution time: 0.8500
DEBUG - 2011-06-14 12:50:44 --> Config Class Initialized
DEBUG - 2011-06-14 12:50:44 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:50:44 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:50:44 --> URI Class Initialized
DEBUG - 2011-06-14 12:50:44 --> Router Class Initialized
ERROR - 2011-06-14 12:50:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 12:50:59 --> Config Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:50:59 --> URI Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Router Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Output Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Input Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 12:50:59 --> Language Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Loader Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Controller Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Model Class Initialized
DEBUG - 2011-06-14 12:50:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 12:50:59 --> Database Driver Class Initialized
DEBUG - 2011-06-14 12:50:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 12:50:59 --> Helper loaded: url_helper
DEBUG - 2011-06-14 12:50:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 12:50:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 12:50:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 12:50:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 12:50:59 --> Final output sent to browser
DEBUG - 2011-06-14 12:50:59 --> Total execution time: 0.6555
DEBUG - 2011-06-14 12:51:00 --> Config Class Initialized
DEBUG - 2011-06-14 12:51:00 --> Hooks Class Initialized
DEBUG - 2011-06-14 12:51:00 --> Utf8 Class Initialized
DEBUG - 2011-06-14 12:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 12:51:00 --> URI Class Initialized
DEBUG - 2011-06-14 12:51:00 --> Router Class Initialized
ERROR - 2011-06-14 12:51:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 14:11:33 --> Config Class Initialized
DEBUG - 2011-06-14 14:11:33 --> Hooks Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Utf8 Class Initialized
DEBUG - 2011-06-14 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 14:11:34 --> URI Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Router Class Initialized
DEBUG - 2011-06-14 14:11:34 --> No URI present. Default controller set.
DEBUG - 2011-06-14 14:11:34 --> Output Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Input Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 14:11:34 --> Language Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Loader Class Initialized
DEBUG - 2011-06-14 14:11:34 --> Controller Class Initialized
DEBUG - 2011-06-14 14:11:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-14 14:11:34 --> Helper loaded: url_helper
DEBUG - 2011-06-14 14:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 14:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 14:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 14:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 14:11:34 --> Final output sent to browser
DEBUG - 2011-06-14 14:11:34 --> Total execution time: 0.2491
DEBUG - 2011-06-14 14:21:18 --> Config Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Hooks Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Utf8 Class Initialized
DEBUG - 2011-06-14 14:21:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 14:21:18 --> URI Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Router Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Output Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Input Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 14:21:18 --> Language Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Loader Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Controller Class Initialized
ERROR - 2011-06-14 14:21:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 14:21:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 14:21:18 --> Model Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Model Class Initialized
DEBUG - 2011-06-14 14:21:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 14:21:18 --> Database Driver Class Initialized
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 14:21:18 --> Helper loaded: url_helper
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 14:21:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 14:21:18 --> Final output sent to browser
DEBUG - 2011-06-14 14:21:18 --> Total execution time: 0.3253
DEBUG - 2011-06-14 15:03:12 --> Config Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:03:12 --> URI Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Router Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Output Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Input Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 15:03:12 --> Language Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Loader Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Controller Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 15:03:12 --> Database Driver Class Initialized
DEBUG - 2011-06-14 15:03:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 15:03:13 --> Helper loaded: url_helper
DEBUG - 2011-06-14 15:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 15:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 15:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 15:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 15:03:13 --> Final output sent to browser
DEBUG - 2011-06-14 15:03:13 --> Total execution time: 1.4316
DEBUG - 2011-06-14 15:03:16 --> Config Class Initialized
DEBUG - 2011-06-14 15:03:16 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:03:16 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:03:16 --> URI Class Initialized
DEBUG - 2011-06-14 15:03:16 --> Router Class Initialized
ERROR - 2011-06-14 15:03:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 15:03:34 --> Config Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:03:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:03:34 --> URI Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Router Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Output Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Input Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 15:03:34 --> Language Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Loader Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Controller Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 15:03:34 --> Database Driver Class Initialized
DEBUG - 2011-06-14 15:03:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 15:03:35 --> Helper loaded: url_helper
DEBUG - 2011-06-14 15:03:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 15:03:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 15:03:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 15:03:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 15:03:35 --> Final output sent to browser
DEBUG - 2011-06-14 15:03:35 --> Total execution time: 0.8204
DEBUG - 2011-06-14 15:03:35 --> Config Class Initialized
DEBUG - 2011-06-14 15:03:35 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:03:35 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:03:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:03:35 --> URI Class Initialized
DEBUG - 2011-06-14 15:03:35 --> Router Class Initialized
DEBUG - 2011-06-14 15:03:35 --> Output Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Input Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 15:03:36 --> Language Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Loader Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Controller Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Model Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 15:03:36 --> Database Driver Class Initialized
DEBUG - 2011-06-14 15:03:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 15:03:36 --> Helper loaded: url_helper
DEBUG - 2011-06-14 15:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 15:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 15:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 15:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 15:03:36 --> Final output sent to browser
DEBUG - 2011-06-14 15:03:36 --> Total execution time: 0.0633
DEBUG - 2011-06-14 15:03:36 --> Config Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:03:36 --> URI Class Initialized
DEBUG - 2011-06-14 15:03:36 --> Router Class Initialized
ERROR - 2011-06-14 15:03:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 15:46:03 --> Config Class Initialized
DEBUG - 2011-06-14 15:46:03 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:46:03 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:46:03 --> URI Class Initialized
DEBUG - 2011-06-14 15:46:03 --> Router Class Initialized
ERROR - 2011-06-14 15:46:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 15:46:41 --> Config Class Initialized
DEBUG - 2011-06-14 15:46:41 --> Hooks Class Initialized
DEBUG - 2011-06-14 15:46:41 --> Utf8 Class Initialized
DEBUG - 2011-06-14 15:46:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 15:46:41 --> URI Class Initialized
DEBUG - 2011-06-14 15:46:41 --> Router Class Initialized
DEBUG - 2011-06-14 15:46:42 --> Output Class Initialized
DEBUG - 2011-06-14 15:46:42 --> Input Class Initialized
DEBUG - 2011-06-14 15:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 15:46:42 --> Language Class Initialized
DEBUG - 2011-06-14 15:46:42 --> Loader Class Initialized
DEBUG - 2011-06-14 15:46:43 --> Controller Class Initialized
DEBUG - 2011-06-14 15:46:43 --> Model Class Initialized
DEBUG - 2011-06-14 15:46:43 --> Model Class Initialized
DEBUG - 2011-06-14 15:46:43 --> Model Class Initialized
DEBUG - 2011-06-14 15:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 15:46:44 --> Database Driver Class Initialized
DEBUG - 2011-06-14 15:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 15:46:45 --> Helper loaded: url_helper
DEBUG - 2011-06-14 15:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 15:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 15:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 15:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 15:46:45 --> Final output sent to browser
DEBUG - 2011-06-14 15:46:45 --> Total execution time: 3.5581
DEBUG - 2011-06-14 18:08:03 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:03 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:03 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Controller Class Initialized
ERROR - 2011-06-14 18:08:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:08:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:03 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:03 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:03 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:08:03 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:03 --> Total execution time: 0.3235
DEBUG - 2011-06-14 18:08:04 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:04 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:04 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Controller Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:04 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:04 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:04 --> Total execution time: 0.5883
DEBUG - 2011-06-14 18:08:06 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:06 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Router Class Initialized
ERROR - 2011-06-14 18:08:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 18:08:06 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:06 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Router Class Initialized
ERROR - 2011-06-14 18:08:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 18:08:06 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:06 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:06 --> Router Class Initialized
ERROR - 2011-06-14 18:08:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 18:08:36 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:36 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:36 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Controller Class Initialized
ERROR - 2011-06-14 18:08:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:08:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:36 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:36 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:36 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:08:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:08:36 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:36 --> Total execution time: 0.0561
DEBUG - 2011-06-14 18:08:36 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:36 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:36 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Controller Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:36 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:37 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:37 --> Total execution time: 0.5288
DEBUG - 2011-06-14 18:08:41 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:41 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:41 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Controller Class Initialized
ERROR - 2011-06-14 18:08:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:08:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:41 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:41 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:41 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:08:41 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:41 --> Total execution time: 0.0270
DEBUG - 2011-06-14 18:08:55 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:55 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:55 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Controller Class Initialized
ERROR - 2011-06-14 18:08:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:08:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:55 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:55 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:55 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:08:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:08:55 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:55 --> Total execution time: 0.0314
DEBUG - 2011-06-14 18:08:56 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:56 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:56 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Controller Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:56 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Config Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:08:56 --> URI Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Router Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Output Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Input Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:08:56 --> Language Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Loader Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Controller Class Initialized
ERROR - 2011-06-14 18:08:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:08:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:56 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Model Class Initialized
DEBUG - 2011-06-14 18:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:08:56 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:08:56 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:08:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:08:56 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:56 --> Total execution time: 0.0264
DEBUG - 2011-06-14 18:08:57 --> Final output sent to browser
DEBUG - 2011-06-14 18:08:57 --> Total execution time: 0.8194
DEBUG - 2011-06-14 18:09:11 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:11 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:11 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:11 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:11 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:11 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:11 --> Total execution time: 0.0338
DEBUG - 2011-06-14 18:09:11 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:11 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:11 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:11 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Controller Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:11 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:11 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:11 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:11 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:11 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:11 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:11 --> Total execution time: 0.0286
DEBUG - 2011-06-14 18:09:12 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:12 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:12 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:12 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:12 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:12 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:12 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:12 --> Total execution time: 0.0278
DEBUG - 2011-06-14 18:09:12 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:12 --> Total execution time: 0.7128
DEBUG - 2011-06-14 18:09:16 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:16 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:16 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:16 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:16 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:16 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:16 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:16 --> Total execution time: 0.0281
DEBUG - 2011-06-14 18:09:17 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:17 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:17 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Controller Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:17 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:17 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:17 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:17 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:17 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:17 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:17 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:17 --> Total execution time: 0.0273
DEBUG - 2011-06-14 18:09:17 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:17 --> Total execution time: 0.6091
DEBUG - 2011-06-14 18:09:57 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:57 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:57 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Controller Class Initialized
ERROR - 2011-06-14 18:09:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:09:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:57 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:57 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:09:57 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:09:57 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:57 --> Total execution time: 0.0285
DEBUG - 2011-06-14 18:09:57 --> Config Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:09:57 --> URI Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Router Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Output Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Input Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:09:57 --> Language Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Loader Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Controller Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Model Class Initialized
DEBUG - 2011-06-14 18:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:09:57 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:09:58 --> Final output sent to browser
DEBUG - 2011-06-14 18:09:58 --> Total execution time: 0.4941
DEBUG - 2011-06-14 18:10:52 --> Config Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:10:52 --> URI Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Router Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Output Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Input Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:10:52 --> Language Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Loader Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Controller Class Initialized
ERROR - 2011-06-14 18:10:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:10:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:10:52 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:10:52 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:10:52 --> Final output sent to browser
DEBUG - 2011-06-14 18:10:52 --> Total execution time: 0.0265
DEBUG - 2011-06-14 18:10:52 --> Config Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:10:52 --> URI Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Router Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Output Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Input Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:10:52 --> Language Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Loader Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Controller Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:10:52 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Config Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:10:52 --> URI Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Router Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Output Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Input Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:10:52 --> Language Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Loader Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Controller Class Initialized
ERROR - 2011-06-14 18:10:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:10:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Model Class Initialized
DEBUG - 2011-06-14 18:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:10:52 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:10:52 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:10:52 --> Final output sent to browser
DEBUG - 2011-06-14 18:10:52 --> Total execution time: 0.0266
DEBUG - 2011-06-14 18:10:53 --> Final output sent to browser
DEBUG - 2011-06-14 18:10:53 --> Total execution time: 0.5574
DEBUG - 2011-06-14 18:11:07 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:07 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:07 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Controller Class Initialized
ERROR - 2011-06-14 18:11:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:11:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:07 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:07 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:07 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:11:07 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:07 --> Total execution time: 0.0281
DEBUG - 2011-06-14 18:11:07 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:07 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:07 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Controller Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:07 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:08 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:08 --> Total execution time: 0.5737
DEBUG - 2011-06-14 18:11:09 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:09 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:09 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Controller Class Initialized
ERROR - 2011-06-14 18:11:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:11:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:09 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:09 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:09 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:11:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:11:09 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:09 --> Total execution time: 0.0294
DEBUG - 2011-06-14 18:11:44 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:44 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:44 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Controller Class Initialized
ERROR - 2011-06-14 18:11:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:44 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:44 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:44 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:11:44 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:44 --> Total execution time: 0.0266
DEBUG - 2011-06-14 18:11:44 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:44 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:44 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Controller Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:44 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:44 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:44 --> Total execution time: 0.4881
DEBUG - 2011-06-14 18:11:45 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:45 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:45 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Controller Class Initialized
ERROR - 2011-06-14 18:11:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:45 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:45 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:45 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:11:45 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:45 --> Total execution time: 0.0285
DEBUG - 2011-06-14 18:11:45 --> Config Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Utf8 Class Initialized
DEBUG - 2011-06-14 18:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 18:11:45 --> URI Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Router Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Output Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Input Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 18:11:45 --> Language Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Loader Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Controller Class Initialized
ERROR - 2011-06-14 18:11:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 18:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:45 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Model Class Initialized
DEBUG - 2011-06-14 18:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 18:11:45 --> Database Driver Class Initialized
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 18:11:45 --> Helper loaded: url_helper
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 18:11:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 18:11:45 --> Final output sent to browser
DEBUG - 2011-06-14 18:11:45 --> Total execution time: 0.0591
DEBUG - 2011-06-14 19:53:15 --> Config Class Initialized
DEBUG - 2011-06-14 19:53:15 --> Hooks Class Initialized
DEBUG - 2011-06-14 19:53:15 --> Utf8 Class Initialized
DEBUG - 2011-06-14 19:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 19:53:15 --> URI Class Initialized
DEBUG - 2011-06-14 19:53:15 --> Router Class Initialized
ERROR - 2011-06-14 19:53:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 19:53:18 --> Config Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Hooks Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Utf8 Class Initialized
DEBUG - 2011-06-14 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 19:53:18 --> URI Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Router Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Output Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Input Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 19:53:18 --> Language Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Loader Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Controller Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Model Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Model Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Model Class Initialized
DEBUG - 2011-06-14 19:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 19:53:18 --> Database Driver Class Initialized
DEBUG - 2011-06-14 19:53:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 19:53:19 --> Helper loaded: url_helper
DEBUG - 2011-06-14 19:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 19:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 19:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 19:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 19:53:19 --> Final output sent to browser
DEBUG - 2011-06-14 19:53:19 --> Total execution time: 1.1087
DEBUG - 2011-06-14 20:56:30 --> Config Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Hooks Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Utf8 Class Initialized
DEBUG - 2011-06-14 20:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 20:56:30 --> URI Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Router Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Output Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Input Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 20:56:30 --> Language Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Loader Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Controller Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Model Class Initialized
DEBUG - 2011-06-14 20:56:30 --> Model Class Initialized
DEBUG - 2011-06-14 20:56:31 --> Model Class Initialized
DEBUG - 2011-06-14 20:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 20:56:31 --> Database Driver Class Initialized
DEBUG - 2011-06-14 20:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 20:56:32 --> Helper loaded: url_helper
DEBUG - 2011-06-14 20:56:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 20:56:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 20:56:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 20:56:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 20:56:32 --> Final output sent to browser
DEBUG - 2011-06-14 20:56:32 --> Total execution time: 1.2978
DEBUG - 2011-06-14 20:56:33 --> Config Class Initialized
DEBUG - 2011-06-14 20:56:33 --> Hooks Class Initialized
DEBUG - 2011-06-14 20:56:33 --> Utf8 Class Initialized
DEBUG - 2011-06-14 20:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 20:56:33 --> URI Class Initialized
DEBUG - 2011-06-14 20:56:33 --> Router Class Initialized
ERROR - 2011-06-14 20:56:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 20:56:35 --> Config Class Initialized
DEBUG - 2011-06-14 20:56:35 --> Hooks Class Initialized
DEBUG - 2011-06-14 20:56:35 --> Utf8 Class Initialized
DEBUG - 2011-06-14 20:56:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 20:56:35 --> URI Class Initialized
DEBUG - 2011-06-14 20:56:35 --> Router Class Initialized
ERROR - 2011-06-14 20:56:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 21:25:43 --> Config Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:25:43 --> URI Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Router Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Output Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Input Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:25:43 --> Language Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Loader Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Controller Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Model Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Model Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Model Class Initialized
DEBUG - 2011-06-14 21:25:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:25:43 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:25:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:25:44 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:25:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:25:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:25:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:25:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:25:44 --> Final output sent to browser
DEBUG - 2011-06-14 21:25:44 --> Total execution time: 1.2526
DEBUG - 2011-06-14 21:25:51 --> Config Class Initialized
DEBUG - 2011-06-14 21:25:51 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:25:51 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:25:51 --> URI Class Initialized
DEBUG - 2011-06-14 21:25:51 --> Router Class Initialized
ERROR - 2011-06-14 21:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 21:25:52 --> Config Class Initialized
DEBUG - 2011-06-14 21:25:52 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:25:52 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:25:52 --> URI Class Initialized
DEBUG - 2011-06-14 21:25:52 --> Router Class Initialized
ERROR - 2011-06-14 21:25:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-14 21:26:13 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:13 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:13 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:13 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:13 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:13 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:13 --> Total execution time: 0.6071
DEBUG - 2011-06-14 21:26:15 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:15 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Router Class Initialized
ERROR - 2011-06-14 21:26:15 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 21:26:15 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:15 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:15 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:15 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:15 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:15 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:15 --> Total execution time: 0.0447
DEBUG - 2011-06-14 21:26:31 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:31 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:31 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:31 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:32 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:32 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:32 --> Total execution time: 0.3309
DEBUG - 2011-06-14 21:26:33 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:33 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:33 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:33 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:33 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:33 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:33 --> Total execution time: 0.0515
DEBUG - 2011-06-14 21:26:33 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:33 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:33 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:33 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:33 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:33 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:33 --> Total execution time: 0.0444
DEBUG - 2011-06-14 21:26:47 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:47 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:47 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:47 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:47 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:47 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:47 --> Total execution time: 0.2108
DEBUG - 2011-06-14 21:26:48 --> Config Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Hooks Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Utf8 Class Initialized
DEBUG - 2011-06-14 21:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 21:26:48 --> URI Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Router Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Output Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Input Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 21:26:48 --> Language Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Loader Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Controller Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Model Class Initialized
DEBUG - 2011-06-14 21:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 21:26:48 --> Database Driver Class Initialized
DEBUG - 2011-06-14 21:26:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 21:26:48 --> Helper loaded: url_helper
DEBUG - 2011-06-14 21:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 21:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 21:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 21:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 21:26:48 --> Final output sent to browser
DEBUG - 2011-06-14 21:26:48 --> Total execution time: 0.0666
DEBUG - 2011-06-14 22:21:45 --> Config Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Hooks Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Utf8 Class Initialized
DEBUG - 2011-06-14 22:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 22:21:46 --> URI Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Router Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Output Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Input Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 22:21:46 --> Language Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Loader Class Initialized
DEBUG - 2011-06-14 22:21:46 --> Controller Class Initialized
DEBUG - 2011-06-14 22:21:47 --> Model Class Initialized
DEBUG - 2011-06-14 22:21:47 --> Model Class Initialized
DEBUG - 2011-06-14 22:21:47 --> Model Class Initialized
DEBUG - 2011-06-14 22:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 22:21:47 --> Database Driver Class Initialized
DEBUG - 2011-06-14 22:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-14 22:21:49 --> Helper loaded: url_helper
DEBUG - 2011-06-14 22:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 22:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 22:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 22:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 22:21:50 --> Final output sent to browser
DEBUG - 2011-06-14 22:21:50 --> Total execution time: 5.1355
DEBUG - 2011-06-14 22:52:06 --> Config Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Hooks Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Utf8 Class Initialized
DEBUG - 2011-06-14 22:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 22:52:06 --> URI Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Router Class Initialized
ERROR - 2011-06-14 22:52:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-14 22:52:06 --> Config Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Hooks Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Utf8 Class Initialized
DEBUG - 2011-06-14 22:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-14 22:52:06 --> URI Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Router Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Output Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Input Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-14 22:52:06 --> Language Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Loader Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Controller Class Initialized
ERROR - 2011-06-14 22:52:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-14 22:52:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 22:52:06 --> Model Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Model Class Initialized
DEBUG - 2011-06-14 22:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-14 22:52:06 --> Database Driver Class Initialized
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-14 22:52:06 --> Helper loaded: url_helper
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-14 22:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-14 22:52:06 --> Final output sent to browser
DEBUG - 2011-06-14 22:52:06 --> Total execution time: 0.1942

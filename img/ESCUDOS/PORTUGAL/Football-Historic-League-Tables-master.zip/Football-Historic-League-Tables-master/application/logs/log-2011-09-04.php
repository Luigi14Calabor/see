<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-04 00:19:38 --> Config Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:19:38 --> URI Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Router Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Output Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Input Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:19:38 --> Language Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Loader Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Controller Class Initialized
ERROR - 2011-09-04 00:19:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:19:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:19:38 --> Model Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Model Class Initialized
DEBUG - 2011-09-04 00:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:19:38 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:19:38 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:19:38 --> Final output sent to browser
DEBUG - 2011-09-04 00:19:38 --> Total execution time: 0.0662
DEBUG - 2011-09-04 00:19:41 --> Config Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:19:41 --> URI Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Router Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Output Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Input Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:19:41 --> Language Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Loader Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Controller Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:19:41 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:19:42 --> Final output sent to browser
DEBUG - 2011-09-04 00:19:42 --> Total execution time: 0.5956
DEBUG - 2011-09-04 00:19:44 --> Config Class Initialized
DEBUG - 2011-09-04 00:19:44 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:19:44 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:19:44 --> URI Class Initialized
DEBUG - 2011-09-04 00:19:44 --> Router Class Initialized
ERROR - 2011-09-04 00:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:20:37 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:37 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Router Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Output Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Input Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:20:37 --> Language Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Loader Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Controller Class Initialized
ERROR - 2011-09-04 00:20:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:20:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:20:37 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:20:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:20:37 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:20:37 --> Final output sent to browser
DEBUG - 2011-09-04 00:20:37 --> Total execution time: 0.0282
DEBUG - 2011-09-04 00:20:37 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:37 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Router Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Output Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Input Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:20:37 --> Language Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Loader Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Controller Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:20:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:20:38 --> Final output sent to browser
DEBUG - 2011-09-04 00:20:38 --> Total execution time: 0.6123
DEBUG - 2011-09-04 00:20:42 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:42 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:42 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:42 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:42 --> Router Class Initialized
ERROR - 2011-09-04 00:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:20:49 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:49 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Router Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Output Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Input Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:20:49 --> Language Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Loader Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Controller Class Initialized
ERROR - 2011-09-04 00:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:20:49 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:20:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:20:49 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:20:49 --> Final output sent to browser
DEBUG - 2011-09-04 00:20:49 --> Total execution time: 0.0290
DEBUG - 2011-09-04 00:20:50 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:50 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Router Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Output Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Input Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:20:50 --> Language Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Loader Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Controller Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Model Class Initialized
DEBUG - 2011-09-04 00:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:20:50 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:20:51 --> Final output sent to browser
DEBUG - 2011-09-04 00:20:51 --> Total execution time: 0.6426
DEBUG - 2011-09-04 00:20:52 --> Config Class Initialized
DEBUG - 2011-09-04 00:20:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:20:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:20:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:20:52 --> URI Class Initialized
DEBUG - 2011-09-04 00:20:52 --> Router Class Initialized
ERROR - 2011-09-04 00:20:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:21:06 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:06 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:06 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Controller Class Initialized
ERROR - 2011-09-04 00:21:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:21:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:06 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:06 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:06 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:21:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:21:06 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:06 --> Total execution time: 0.0323
DEBUG - 2011-09-04 00:21:07 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:07 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:07 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Controller Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:07 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:07 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:07 --> Total execution time: 0.5705
DEBUG - 2011-09-04 00:21:08 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:08 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:08 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:08 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:08 --> Router Class Initialized
ERROR - 2011-09-04 00:21:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:21:20 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:20 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:20 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Controller Class Initialized
ERROR - 2011-09-04 00:21:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:21:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:21:20 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:20 --> Total execution time: 0.0283
DEBUG - 2011-09-04 00:21:21 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:21 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:21 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Controller Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:22 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:22 --> Total execution time: 0.8412
DEBUG - 2011-09-04 00:21:24 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:24 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:24 --> Router Class Initialized
ERROR - 2011-09-04 00:21:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:21:41 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:41 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:41 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Controller Class Initialized
ERROR - 2011-09-04 00:21:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:21:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:41 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:21:41 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:21:41 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:41 --> Total execution time: 0.0292
DEBUG - 2011-09-04 00:21:41 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:41 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Router Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Output Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Input Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:21:41 --> Language Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Loader Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Controller Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Model Class Initialized
DEBUG - 2011-09-04 00:21:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:21:41 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:21:42 --> Final output sent to browser
DEBUG - 2011-09-04 00:21:42 --> Total execution time: 0.5965
DEBUG - 2011-09-04 00:21:45 --> Config Class Initialized
DEBUG - 2011-09-04 00:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:21:45 --> URI Class Initialized
DEBUG - 2011-09-04 00:21:45 --> Router Class Initialized
ERROR - 2011-09-04 00:21:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:22:03 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:03 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Router Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Output Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Input Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:22:03 --> Language Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Loader Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Controller Class Initialized
ERROR - 2011-09-04 00:22:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:22:03 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:22:03 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:22:03 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:22:03 --> Final output sent to browser
DEBUG - 2011-09-04 00:22:03 --> Total execution time: 0.0408
DEBUG - 2011-09-04 00:22:04 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:04 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Router Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Output Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Input Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:22:04 --> Language Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Loader Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Controller Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:22:04 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:22:04 --> Final output sent to browser
DEBUG - 2011-09-04 00:22:04 --> Total execution time: 0.5581
DEBUG - 2011-09-04 00:22:06 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:06 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:06 --> Router Class Initialized
ERROR - 2011-09-04 00:22:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:22:14 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:14 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:14 --> Router Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Output Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Input Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:22:15 --> Language Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Loader Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Controller Class Initialized
ERROR - 2011-09-04 00:22:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 00:22:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:22:15 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 00:22:15 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:22:15 --> Final output sent to browser
DEBUG - 2011-09-04 00:22:15 --> Total execution time: 0.0289
DEBUG - 2011-09-04 00:22:15 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:15 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Router Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Output Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Input Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:22:15 --> Language Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Loader Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Controller Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:22:16 --> Final output sent to browser
DEBUG - 2011-09-04 00:22:16 --> Total execution time: 0.5041
DEBUG - 2011-09-04 00:22:20 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:20 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:20 --> Router Class Initialized
ERROR - 2011-09-04 00:22:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:22:28 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:28 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Router Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Output Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Input Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:22:28 --> Language Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Loader Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Controller Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Model Class Initialized
DEBUG - 2011-09-04 00:22:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:22:28 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:22:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:22:28 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:22:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:22:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:22:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:22:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:22:28 --> Final output sent to browser
DEBUG - 2011-09-04 00:22:28 --> Total execution time: 0.3341
DEBUG - 2011-09-04 00:22:30 --> Config Class Initialized
DEBUG - 2011-09-04 00:22:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:22:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:22:30 --> URI Class Initialized
DEBUG - 2011-09-04 00:22:30 --> Router Class Initialized
ERROR - 2011-09-04 00:22:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:23:14 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:14 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Router Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Output Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Input Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:23:14 --> Language Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Loader Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Controller Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:23:14 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:23:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:23:14 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:23:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:23:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:23:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:23:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:23:14 --> Final output sent to browser
DEBUG - 2011-09-04 00:23:14 --> Total execution time: 0.3736
DEBUG - 2011-09-04 00:23:16 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:16 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:16 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:16 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:16 --> Router Class Initialized
ERROR - 2011-09-04 00:23:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 00:23:17 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:17 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Router Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Output Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Input Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:23:17 --> Language Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Loader Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Controller Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:23:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:23:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:23:17 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:23:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:23:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:23:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:23:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:23:17 --> Final output sent to browser
DEBUG - 2011-09-04 00:23:17 --> Total execution time: 0.1618
DEBUG - 2011-09-04 00:23:22 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:22 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:22 --> Router Class Initialized
ERROR - 2011-09-04 00:23:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:23:36 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:36 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Router Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Output Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Input Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:23:36 --> Language Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Loader Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Controller Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:23:36 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:23:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:23:36 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:23:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:23:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:23:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:23:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:23:36 --> Final output sent to browser
DEBUG - 2011-09-04 00:23:36 --> Total execution time: 0.3638
DEBUG - 2011-09-04 00:23:38 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:38 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Router Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Output Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Input Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:23:38 --> Language Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Loader Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Controller Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-04 00:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:23:38 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:23:38 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:23:38 --> Final output sent to browser
DEBUG - 2011-09-04 00:23:38 --> Total execution time: 0.0471
DEBUG - 2011-09-04 00:23:40 --> Config Class Initialized
DEBUG - 2011-09-04 00:23:40 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:23:40 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:23:40 --> URI Class Initialized
DEBUG - 2011-09-04 00:23:40 --> Router Class Initialized
ERROR - 2011-09-04 00:23:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:24:01 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:01 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:01 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:01 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:01 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:01 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:01 --> Total execution time: 0.6201
DEBUG - 2011-09-04 00:24:02 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:02 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:02 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:02 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:02 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:02 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:02 --> Total execution time: 0.0478
DEBUG - 2011-09-04 00:24:03 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:03 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:03 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:03 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:03 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:03 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:03 --> Total execution time: 0.0501
DEBUG - 2011-09-04 00:24:05 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:05 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:05 --> Router Class Initialized
ERROR - 2011-09-04 00:24:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:24:24 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:24 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:24 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:24 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:24 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:24 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:24 --> Total execution time: 0.2029
DEBUG - 2011-09-04 00:24:25 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:25 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:25 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:25 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:25 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:25 --> Total execution time: 0.0434
DEBUG - 2011-09-04 00:24:33 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:33 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:33 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:33 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:33 --> Router Class Initialized
ERROR - 2011-09-04 00:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:24:54 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:54 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:54 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:54 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:54 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:54 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:54 --> Total execution time: 0.2564
DEBUG - 2011-09-04 00:24:56 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:56 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Router Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Output Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Input Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:24:56 --> Language Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Loader Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Controller Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Model Class Initialized
DEBUG - 2011-09-04 00:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:24:56 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:24:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:24:56 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:24:56 --> Final output sent to browser
DEBUG - 2011-09-04 00:24:56 --> Total execution time: 0.0564
DEBUG - 2011-09-04 00:24:57 --> Config Class Initialized
DEBUG - 2011-09-04 00:24:57 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:24:57 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:24:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:24:57 --> URI Class Initialized
DEBUG - 2011-09-04 00:24:57 --> Router Class Initialized
ERROR - 2011-09-04 00:24:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:25:20 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:20 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Router Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Output Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Input Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:25:20 --> Language Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Loader Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Controller Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:25:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:25:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:25:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:25:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:25:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:25:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:25:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:25:20 --> Final output sent to browser
DEBUG - 2011-09-04 00:25:20 --> Total execution time: 0.2453
DEBUG - 2011-09-04 00:25:22 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:22 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Router Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Output Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Input Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:25:22 --> Language Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Loader Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Controller Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:25:22 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:25:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:25:22 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:25:22 --> Final output sent to browser
DEBUG - 2011-09-04 00:25:22 --> Total execution time: 0.0513
DEBUG - 2011-09-04 00:25:24 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:24 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:24 --> Router Class Initialized
ERROR - 2011-09-04 00:25:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:25:50 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:50 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Router Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Output Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Input Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:25:50 --> Language Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Loader Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Controller Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:25:50 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:25:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:25:50 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:25:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:25:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:25:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:25:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:25:50 --> Final output sent to browser
DEBUG - 2011-09-04 00:25:50 --> Total execution time: 0.2577
DEBUG - 2011-09-04 00:25:52 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:52 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Router Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Output Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Input Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:25:52 --> Language Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Loader Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Controller Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Model Class Initialized
DEBUG - 2011-09-04 00:25:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:25:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:25:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:25:52 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:25:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:25:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:25:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:25:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:25:52 --> Final output sent to browser
DEBUG - 2011-09-04 00:25:52 --> Total execution time: 0.0468
DEBUG - 2011-09-04 00:25:54 --> Config Class Initialized
DEBUG - 2011-09-04 00:25:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:25:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:25:54 --> URI Class Initialized
DEBUG - 2011-09-04 00:25:54 --> Router Class Initialized
ERROR - 2011-09-04 00:25:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 00:26:20 --> Config Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:26:20 --> URI Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Router Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Output Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Input Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:26:20 --> Language Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Loader Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Controller Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:26:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:26:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:26:20 --> Final output sent to browser
DEBUG - 2011-09-04 00:26:20 --> Total execution time: 0.2273
DEBUG - 2011-09-04 00:26:21 --> Config Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:26:21 --> URI Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Router Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Output Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Input Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 00:26:21 --> Language Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Loader Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Controller Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Model Class Initialized
DEBUG - 2011-09-04 00:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 00:26:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 00:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 00:26:21 --> Helper loaded: url_helper
DEBUG - 2011-09-04 00:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 00:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 00:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 00:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 00:26:21 --> Final output sent to browser
DEBUG - 2011-09-04 00:26:21 --> Total execution time: 0.0446
DEBUG - 2011-09-04 00:26:26 --> Config Class Initialized
DEBUG - 2011-09-04 00:26:26 --> Hooks Class Initialized
DEBUG - 2011-09-04 00:26:26 --> Utf8 Class Initialized
DEBUG - 2011-09-04 00:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 00:26:26 --> URI Class Initialized
DEBUG - 2011-09-04 00:26:26 --> Router Class Initialized
ERROR - 2011-09-04 00:26:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 01:40:51 --> Config Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:40:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:40:51 --> URI Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Router Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Output Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Input Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 01:40:51 --> Language Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Loader Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Controller Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Model Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Model Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Model Class Initialized
DEBUG - 2011-09-04 01:40:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 01:40:51 --> Database Driver Class Initialized
DEBUG - 2011-09-04 01:40:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 01:40:51 --> Helper loaded: url_helper
DEBUG - 2011-09-04 01:40:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 01:40:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 01:40:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 01:40:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 01:40:51 --> Final output sent to browser
DEBUG - 2011-09-04 01:40:51 --> Total execution time: 0.8228
DEBUG - 2011-09-04 01:40:54 --> Config Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:40:54 --> URI Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Router Class Initialized
ERROR - 2011-09-04 01:40:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 01:40:54 --> Config Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:40:54 --> URI Class Initialized
DEBUG - 2011-09-04 01:40:54 --> Router Class Initialized
ERROR - 2011-09-04 01:40:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 01:41:08 --> Config Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:41:08 --> URI Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Router Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Output Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Input Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 01:41:08 --> Language Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Loader Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Controller Class Initialized
ERROR - 2011-09-04 01:41:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 01:41:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 01:41:08 --> Model Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Model Class Initialized
DEBUG - 2011-09-04 01:41:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 01:41:08 --> Database Driver Class Initialized
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 01:41:08 --> Helper loaded: url_helper
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 01:41:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 01:41:08 --> Final output sent to browser
DEBUG - 2011-09-04 01:41:08 --> Total execution time: 0.0717
DEBUG - 2011-09-04 01:41:09 --> Config Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:41:09 --> URI Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Router Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Output Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Input Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 01:41:09 --> Language Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Loader Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Controller Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Model Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Model Class Initialized
DEBUG - 2011-09-04 01:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 01:41:09 --> Database Driver Class Initialized
DEBUG - 2011-09-04 01:41:10 --> Final output sent to browser
DEBUG - 2011-09-04 01:41:10 --> Total execution time: 0.8093
DEBUG - 2011-09-04 01:59:52 --> Config Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:59:52 --> URI Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Router Class Initialized
ERROR - 2011-09-04 01:59:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 01:59:52 --> Config Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 01:59:52 --> URI Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Router Class Initialized
DEBUG - 2011-09-04 01:59:52 --> No URI present. Default controller set.
DEBUG - 2011-09-04 01:59:52 --> Output Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Input Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 01:59:52 --> Language Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Loader Class Initialized
DEBUG - 2011-09-04 01:59:52 --> Controller Class Initialized
DEBUG - 2011-09-04 01:59:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 01:59:52 --> Helper loaded: url_helper
DEBUG - 2011-09-04 01:59:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 01:59:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 01:59:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 01:59:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 01:59:52 --> Final output sent to browser
DEBUG - 2011-09-04 01:59:52 --> Total execution time: 0.0703
DEBUG - 2011-09-04 02:17:39 --> Config Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 02:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 02:17:39 --> URI Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Router Class Initialized
DEBUG - 2011-09-04 02:17:39 --> No URI present. Default controller set.
DEBUG - 2011-09-04 02:17:39 --> Output Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Input Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 02:17:39 --> Language Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Loader Class Initialized
DEBUG - 2011-09-04 02:17:39 --> Controller Class Initialized
DEBUG - 2011-09-04 02:17:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 02:17:39 --> Helper loaded: url_helper
DEBUG - 2011-09-04 02:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 02:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 02:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 02:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 02:17:39 --> Final output sent to browser
DEBUG - 2011-09-04 02:17:39 --> Total execution time: 0.2252
DEBUG - 2011-09-04 03:13:30 --> Config Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:13:30 --> URI Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Router Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Output Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Input Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:13:30 --> Language Class Initialized
DEBUG - 2011-09-04 03:13:30 --> Loader Class Initialized
DEBUG - 2011-09-04 03:13:31 --> Controller Class Initialized
DEBUG - 2011-09-04 03:13:31 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:31 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:31 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:13:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:13:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:13:32 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:13:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:13:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:13:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:13:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:13:32 --> Final output sent to browser
DEBUG - 2011-09-04 03:13:32 --> Total execution time: 1.6201
DEBUG - 2011-09-04 03:13:34 --> Config Class Initialized
DEBUG - 2011-09-04 03:13:34 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:13:34 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:13:34 --> URI Class Initialized
DEBUG - 2011-09-04 03:13:34 --> Router Class Initialized
ERROR - 2011-09-04 03:13:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:13:55 --> Config Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:13:55 --> URI Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Router Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Output Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Input Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:13:55 --> Language Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Loader Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Controller Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:55 --> Model Class Initialized
DEBUG - 2011-09-04 03:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:13:56 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:00 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:00 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:00 --> Total execution time: 4.4425
DEBUG - 2011-09-04 03:14:02 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:02 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:02 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:02 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:02 --> Router Class Initialized
ERROR - 2011-09-04 03:14:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:14:05 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:05 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Router Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Output Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Input Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:14:05 --> Language Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Loader Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Controller Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:14:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:05 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:05 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:05 --> Total execution time: 0.0478
DEBUG - 2011-09-04 03:14:28 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:28 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Router Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Output Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Input Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:14:28 --> Language Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Loader Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Controller Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:14:28 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:29 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:29 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:29 --> Total execution time: 0.6048
DEBUG - 2011-09-04 03:14:30 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:30 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Router Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Output Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Input Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:14:30 --> Language Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Loader Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Controller Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:14:30 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:30 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:30 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:30 --> Total execution time: 0.0516
DEBUG - 2011-09-04 03:14:31 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:31 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:31 --> Router Class Initialized
ERROR - 2011-09-04 03:14:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:14:41 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:41 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Router Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Output Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Input Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:14:41 --> Language Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Loader Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Controller Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:14:41 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:42 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:42 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:42 --> Total execution time: 0.9413
DEBUG - 2011-09-04 03:14:44 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:44 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:44 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:44 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:44 --> Router Class Initialized
ERROR - 2011-09-04 03:14:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:14:47 --> Config Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:14:47 --> URI Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Router Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Output Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Input Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:14:47 --> Language Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Loader Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Controller Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Model Class Initialized
DEBUG - 2011-09-04 03:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:14:47 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:14:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:14:47 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:14:47 --> Final output sent to browser
DEBUG - 2011-09-04 03:14:47 --> Total execution time: 0.0530
DEBUG - 2011-09-04 03:16:27 --> Config Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:16:27 --> URI Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Router Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Output Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Input Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:16:27 --> Language Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Loader Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Controller Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Model Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Model Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Model Class Initialized
DEBUG - 2011-09-04 03:16:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:16:27 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:16:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:16:27 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:16:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:16:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:16:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:16:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:16:27 --> Final output sent to browser
DEBUG - 2011-09-04 03:16:27 --> Total execution time: 0.4507
DEBUG - 2011-09-04 03:16:29 --> Config Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:16:29 --> URI Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Router Class Initialized
ERROR - 2011-09-04 03:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:16:29 --> Config Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:16:29 --> URI Class Initialized
DEBUG - 2011-09-04 03:16:29 --> Router Class Initialized
ERROR - 2011-09-04 03:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:39:50 --> Config Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:39:50 --> URI Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Router Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Output Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Input Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:39:50 --> Language Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Loader Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Controller Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Model Class Initialized
DEBUG - 2011-09-04 03:39:50 --> Model Class Initialized
DEBUG - 2011-09-04 03:39:51 --> Model Class Initialized
DEBUG - 2011-09-04 03:39:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:39:51 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:39:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 03:39:51 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:39:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:39:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:39:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:39:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:39:51 --> Final output sent to browser
DEBUG - 2011-09-04 03:39:51 --> Total execution time: 0.2587
DEBUG - 2011-09-04 03:39:57 --> Config Class Initialized
DEBUG - 2011-09-04 03:39:57 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:39:57 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:39:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:39:57 --> URI Class Initialized
DEBUG - 2011-09-04 03:39:57 --> Router Class Initialized
ERROR - 2011-09-04 03:39:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:39:58 --> Config Class Initialized
DEBUG - 2011-09-04 03:39:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:39:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:39:58 --> URI Class Initialized
DEBUG - 2011-09-04 03:39:58 --> Router Class Initialized
ERROR - 2011-09-04 03:39:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:40:38 --> Config Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:40:38 --> URI Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Router Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Output Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Input Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:40:38 --> Language Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Loader Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Controller Class Initialized
ERROR - 2011-09-04 03:40:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:40:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:40:38 --> Model Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Model Class Initialized
DEBUG - 2011-09-04 03:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:40:38 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:40:38 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:40:38 --> Final output sent to browser
DEBUG - 2011-09-04 03:40:38 --> Total execution time: 0.0984
DEBUG - 2011-09-04 03:40:39 --> Config Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:40:39 --> URI Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Router Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Output Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Input Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:40:39 --> Language Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Loader Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Controller Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Model Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Model Class Initialized
DEBUG - 2011-09-04 03:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:40:39 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:40:40 --> Final output sent to browser
DEBUG - 2011-09-04 03:40:40 --> Total execution time: 0.9385
DEBUG - 2011-09-04 03:40:40 --> Config Class Initialized
DEBUG - 2011-09-04 03:40:40 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:40:40 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:40:40 --> URI Class Initialized
DEBUG - 2011-09-04 03:40:40 --> Router Class Initialized
ERROR - 2011-09-04 03:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 03:41:11 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:11 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:11 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Controller Class Initialized
ERROR - 2011-09-04 03:41:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:41:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:11 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:11 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:11 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:41:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:41:11 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:11 --> Total execution time: 0.0268
DEBUG - 2011-09-04 03:41:11 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:11 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:11 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Controller Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:11 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:12 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:12 --> Total execution time: 0.8378
DEBUG - 2011-09-04 03:41:21 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:21 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:21 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Controller Class Initialized
ERROR - 2011-09-04 03:41:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:41:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:21 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:21 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:41:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:41:21 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:21 --> Total execution time: 0.0373
DEBUG - 2011-09-04 03:41:21 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:21 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:21 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Controller Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:22 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:22 --> Total execution time: 0.6989
DEBUG - 2011-09-04 03:41:30 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:30 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:30 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Controller Class Initialized
ERROR - 2011-09-04 03:41:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:41:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:30 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:30 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:30 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:41:30 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:30 --> Total execution time: 0.0286
DEBUG - 2011-09-04 03:41:31 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:31 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:31 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Controller Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:33 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:33 --> Total execution time: 1.7424
DEBUG - 2011-09-04 03:41:42 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:42 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:42 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Controller Class Initialized
ERROR - 2011-09-04 03:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:42 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:42 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:42 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:41:42 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:42 --> Total execution time: 0.0281
DEBUG - 2011-09-04 03:41:43 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:43 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:43 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Controller Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:43 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:43 --> Total execution time: 0.5870
DEBUG - 2011-09-04 03:41:49 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:49 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:49 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Controller Class Initialized
ERROR - 2011-09-04 03:41:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:41:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:41:49 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:41:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:41:49 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:49 --> Total execution time: 0.0346
DEBUG - 2011-09-04 03:41:49 --> Config Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:41:49 --> URI Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Router Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Output Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Input Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:41:49 --> Language Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Loader Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Controller Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:41:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:41:49 --> Final output sent to browser
DEBUG - 2011-09-04 03:41:49 --> Total execution time: 0.5683
DEBUG - 2011-09-04 03:42:00 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:00 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:00 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:00 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:00 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:00 --> Total execution time: 0.0447
DEBUG - 2011-09-04 03:42:00 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:00 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:00 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:01 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:01 --> Total execution time: 0.8776
DEBUG - 2011-09-04 03:42:12 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:12 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:12 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:12 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:12 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:12 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:12 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:12 --> Total execution time: 0.0597
DEBUG - 2011-09-04 03:42:13 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:13 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:13 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:13 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:14 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:14 --> Total execution time: 1.4310
DEBUG - 2011-09-04 03:42:32 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:32 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:32 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:32 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:32 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:32 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:32 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:32 --> Total execution time: 0.0473
DEBUG - 2011-09-04 03:42:32 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:32 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:32 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:33 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:33 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:33 --> Total execution time: 0.7458
DEBUG - 2011-09-04 03:42:42 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:42 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:42 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:42 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:42 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:42 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:42 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:42 --> Total execution time: 0.0299
DEBUG - 2011-09-04 03:42:43 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:43 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:43 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:43 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:43 --> Total execution time: 0.6380
DEBUG - 2011-09-04 03:42:47 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:47 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:47 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:47 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:47 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:47 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:47 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:47 --> Total execution time: 0.0473
DEBUG - 2011-09-04 03:42:48 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:48 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:48 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:48 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:49 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:49 --> Total execution time: 0.8242
DEBUG - 2011-09-04 03:42:54 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:54 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:54 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:54 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:54 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:54 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:54 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:54 --> Total execution time: 0.0732
DEBUG - 2011-09-04 03:42:55 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:55 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:55 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Controller Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:55 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:55 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:55 --> Total execution time: 0.7578
DEBUG - 2011-09-04 03:42:59 --> Config Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:42:59 --> URI Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Router Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Output Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Input Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:42:59 --> Language Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Loader Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Controller Class Initialized
ERROR - 2011-09-04 03:42:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:42:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:59 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Model Class Initialized
DEBUG - 2011-09-04 03:42:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:42:59 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:42:59 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:42:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:42:59 --> Final output sent to browser
DEBUG - 2011-09-04 03:42:59 --> Total execution time: 0.0398
DEBUG - 2011-09-04 03:43:00 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:00 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:00 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Controller Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:00 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:00 --> Total execution time: 0.6626
DEBUG - 2011-09-04 03:43:09 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:09 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:09 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Controller Class Initialized
ERROR - 2011-09-04 03:43:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:43:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:09 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:09 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:09 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:43:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:43:09 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:09 --> Total execution time: 0.0703
DEBUG - 2011-09-04 03:43:09 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:09 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:09 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Controller Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:10 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:10 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:10 --> Total execution time: 0.9989
DEBUG - 2011-09-04 03:43:19 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:19 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:19 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Controller Class Initialized
ERROR - 2011-09-04 03:43:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:43:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:19 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:19 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:19 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:43:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:43:19 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:19 --> Total execution time: 0.0772
DEBUG - 2011-09-04 03:43:19 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:19 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:19 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Controller Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:19 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:20 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:20 --> Total execution time: 1.0424
DEBUG - 2011-09-04 03:43:24 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:24 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:24 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Controller Class Initialized
ERROR - 2011-09-04 03:43:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:43:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:43:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:24 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:24 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:43:25 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:43:25 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:25 --> Total execution time: 0.0291
DEBUG - 2011-09-04 03:43:25 --> Config Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:43:25 --> URI Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Router Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Output Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Input Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:43:25 --> Language Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Loader Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Controller Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Model Class Initialized
DEBUG - 2011-09-04 03:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:43:27 --> Final output sent to browser
DEBUG - 2011-09-04 03:43:27 --> Total execution time: 1.7147
DEBUG - 2011-09-04 03:45:48 --> Config Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:45:48 --> URI Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Router Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Output Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Input Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:45:48 --> Language Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Loader Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Controller Class Initialized
ERROR - 2011-09-04 03:45:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 03:45:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:45:48 --> Model Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Model Class Initialized
DEBUG - 2011-09-04 03:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:45:48 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 03:45:48 --> Helper loaded: url_helper
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 03:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 03:45:48 --> Final output sent to browser
DEBUG - 2011-09-04 03:45:48 --> Total execution time: 0.1224
DEBUG - 2011-09-04 03:45:49 --> Config Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 03:45:49 --> URI Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Router Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Output Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Input Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 03:45:49 --> Language Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Loader Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Controller Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Model Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 03:45:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 03:45:49 --> Final output sent to browser
DEBUG - 2011-09-04 03:45:49 --> Total execution time: 0.5050
DEBUG - 2011-09-04 04:22:27 --> Config Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-04 04:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 04:22:27 --> URI Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Router Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Output Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Input Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 04:22:27 --> Language Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Loader Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Controller Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Model Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Model Class Initialized
DEBUG - 2011-09-04 04:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 04:22:27 --> Database Driver Class Initialized
DEBUG - 2011-09-04 04:22:28 --> Final output sent to browser
DEBUG - 2011-09-04 04:22:28 --> Total execution time: 0.8456
DEBUG - 2011-09-04 06:29:30 --> Config Class Initialized
DEBUG - 2011-09-04 06:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 06:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 06:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 06:29:30 --> URI Class Initialized
DEBUG - 2011-09-04 06:29:30 --> Router Class Initialized
ERROR - 2011-09-04 06:29:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 06:29:31 --> Config Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 06:29:31 --> URI Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Router Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Output Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Input Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 06:29:31 --> Language Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Loader Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Controller Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Model Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Model Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 06:29:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 06:29:31 --> Final output sent to browser
DEBUG - 2011-09-04 06:29:31 --> Total execution time: 0.6736
DEBUG - 2011-09-04 06:29:56 --> Config Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Hooks Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Utf8 Class Initialized
DEBUG - 2011-09-04 06:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 06:29:56 --> URI Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Router Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Output Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Input Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 06:29:56 --> Language Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Loader Class Initialized
DEBUG - 2011-09-04 06:29:56 --> Controller Class Initialized
ERROR - 2011-09-04 06:29:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 06:29:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 06:29:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 06:29:57 --> Model Class Initialized
DEBUG - 2011-09-04 06:29:57 --> Model Class Initialized
DEBUG - 2011-09-04 06:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 06:29:57 --> Database Driver Class Initialized
DEBUG - 2011-09-04 06:29:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 06:29:58 --> Helper loaded: url_helper
DEBUG - 2011-09-04 06:29:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 06:29:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 06:29:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 06:29:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 06:29:58 --> Final output sent to browser
DEBUG - 2011-09-04 06:29:58 --> Total execution time: 1.8419
DEBUG - 2011-09-04 07:55:26 --> Config Class Initialized
DEBUG - 2011-09-04 07:55:26 --> Hooks Class Initialized
DEBUG - 2011-09-04 07:55:26 --> Utf8 Class Initialized
DEBUG - 2011-09-04 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 07:55:26 --> URI Class Initialized
DEBUG - 2011-09-04 07:55:26 --> Router Class Initialized
ERROR - 2011-09-04 07:55:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 07:55:32 --> Config Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Hooks Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Utf8 Class Initialized
DEBUG - 2011-09-04 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 07:55:32 --> URI Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Router Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Output Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Input Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 07:55:32 --> Language Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Loader Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Controller Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 07:55:32 --> Database Driver Class Initialized
DEBUG - 2011-09-04 07:55:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 07:55:33 --> Helper loaded: url_helper
DEBUG - 2011-09-04 07:55:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 07:55:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 07:55:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 07:55:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 07:55:33 --> Final output sent to browser
DEBUG - 2011-09-04 07:55:33 --> Total execution time: 0.6396
DEBUG - 2011-09-04 07:55:33 --> Config Class Initialized
DEBUG - 2011-09-04 07:55:33 --> Hooks Class Initialized
DEBUG - 2011-09-04 07:55:33 --> Utf8 Class Initialized
DEBUG - 2011-09-04 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 07:55:33 --> URI Class Initialized
DEBUG - 2011-09-04 07:55:33 --> Router Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Output Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Input Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 07:55:34 --> Language Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Loader Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Controller Class Initialized
ERROR - 2011-09-04 07:55:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 07:55:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 07:55:34 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 07:55:34 --> Database Driver Class Initialized
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 07:55:34 --> Helper loaded: url_helper
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 07:55:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 07:55:34 --> Final output sent to browser
DEBUG - 2011-09-04 07:55:34 --> Total execution time: 0.1202
DEBUG - 2011-09-04 07:55:56 --> Config Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Hooks Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Utf8 Class Initialized
DEBUG - 2011-09-04 07:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 07:55:56 --> URI Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Router Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Output Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Input Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 07:55:56 --> Language Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Loader Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Controller Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 07:55:56 --> Database Driver Class Initialized
DEBUG - 2011-09-04 07:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 07:55:56 --> Helper loaded: url_helper
DEBUG - 2011-09-04 07:55:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 07:55:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 07:55:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 07:55:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 07:55:56 --> Final output sent to browser
DEBUG - 2011-09-04 07:55:56 --> Total execution time: 0.0698
DEBUG - 2011-09-04 07:55:57 --> Config Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Hooks Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Utf8 Class Initialized
DEBUG - 2011-09-04 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 07:55:57 --> URI Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Router Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Output Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Input Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 07:55:57 --> Language Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Loader Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Controller Class Initialized
ERROR - 2011-09-04 07:55:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 07:55:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 07:55:57 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Model Class Initialized
DEBUG - 2011-09-04 07:55:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 07:55:57 --> Database Driver Class Initialized
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 07:55:57 --> Helper loaded: url_helper
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 07:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 07:55:57 --> Final output sent to browser
DEBUG - 2011-09-04 07:55:57 --> Total execution time: 0.0289
DEBUG - 2011-09-04 09:01:53 --> Config Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:01:53 --> URI Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Router Class Initialized
DEBUG - 2011-09-04 09:01:53 --> No URI present. Default controller set.
DEBUG - 2011-09-04 09:01:53 --> Output Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Input Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:01:53 --> Language Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Loader Class Initialized
DEBUG - 2011-09-04 09:01:53 --> Controller Class Initialized
DEBUG - 2011-09-04 09:01:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 09:01:53 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:01:53 --> Final output sent to browser
DEBUG - 2011-09-04 09:01:53 --> Total execution time: 0.2071
DEBUG - 2011-09-04 09:47:14 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:14 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Router Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Output Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Input Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:47:14 --> Language Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Loader Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Controller Class Initialized
ERROR - 2011-09-04 09:47:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:47:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:47:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:47:14 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:47:14 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:47:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:47:14 --> Final output sent to browser
DEBUG - 2011-09-04 09:47:14 --> Total execution time: 0.1856
DEBUG - 2011-09-04 09:47:14 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:14 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Router Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Output Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Input Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:47:14 --> Language Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Loader Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Controller Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:47:14 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:47:15 --> Final output sent to browser
DEBUG - 2011-09-04 09:47:15 --> Total execution time: 0.5644
DEBUG - 2011-09-04 09:47:17 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:17 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Router Class Initialized
ERROR - 2011-09-04 09:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 09:47:17 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:17 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:17 --> Router Class Initialized
ERROR - 2011-09-04 09:47:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 09:47:58 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:58 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Router Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Output Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Input Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:47:58 --> Language Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Loader Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Controller Class Initialized
ERROR - 2011-09-04 09:47:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:47:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:47:58 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:47:58 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:47:58 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:47:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:47:58 --> Final output sent to browser
DEBUG - 2011-09-04 09:47:58 --> Total execution time: 0.0294
DEBUG - 2011-09-04 09:47:58 --> Config Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:47:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:47:58 --> URI Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Router Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Output Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Input Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:47:58 --> Language Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Loader Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Controller Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Model Class Initialized
DEBUG - 2011-09-04 09:47:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:47:58 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:47:59 --> Final output sent to browser
DEBUG - 2011-09-04 09:47:59 --> Total execution time: 0.5234
DEBUG - 2011-09-04 09:48:13 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:13 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:13 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Controller Class Initialized
ERROR - 2011-09-04 09:48:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:48:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:13 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:48:13 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:13 --> Total execution time: 0.0298
DEBUG - 2011-09-04 09:48:13 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:13 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:13 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Controller Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:13 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:14 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:14 --> Total execution time: 0.6554
DEBUG - 2011-09-04 09:48:23 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:23 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:23 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Controller Class Initialized
ERROR - 2011-09-04 09:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:23 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:23 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:48:23 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:23 --> Total execution time: 0.0289
DEBUG - 2011-09-04 09:48:24 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:24 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:24 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Controller Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:24 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:24 --> Total execution time: 0.6168
DEBUG - 2011-09-04 09:48:35 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:35 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:35 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Controller Class Initialized
ERROR - 2011-09-04 09:48:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:48:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:35 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:35 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:48:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:48:35 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:35 --> Total execution time: 0.0279
DEBUG - 2011-09-04 09:48:35 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:35 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:35 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Controller Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:36 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:36 --> Total execution time: 0.5748
DEBUG - 2011-09-04 09:48:43 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:43 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:43 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Controller Class Initialized
ERROR - 2011-09-04 09:48:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:48:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:43 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:43 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:48:43 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:43 --> Total execution time: 0.0269
DEBUG - 2011-09-04 09:48:43 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:43 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:43 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Controller Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:44 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:44 --> Total execution time: 0.5668
DEBUG - 2011-09-04 09:48:54 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:54 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:54 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Controller Class Initialized
ERROR - 2011-09-04 09:48:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:48:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:54 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:54 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:48:54 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:48:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:48:54 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:54 --> Total execution time: 0.0317
DEBUG - 2011-09-04 09:48:54 --> Config Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:48:54 --> URI Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Router Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Output Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Input Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:48:54 --> Language Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Loader Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Controller Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Model Class Initialized
DEBUG - 2011-09-04 09:48:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:48:54 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:48:55 --> Final output sent to browser
DEBUG - 2011-09-04 09:48:55 --> Total execution time: 0.6331
DEBUG - 2011-09-04 09:49:02 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:02 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:02 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:02 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:02 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:02 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:02 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:02 --> Total execution time: 0.1154
DEBUG - 2011-09-04 09:49:02 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:02 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:02 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Controller Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:02 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:03 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:03 --> Total execution time: 0.6306
DEBUG - 2011-09-04 09:49:17 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:17 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:17 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:17 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:17 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:17 --> Total execution time: 0.0291
DEBUG - 2011-09-04 09:49:17 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:17 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:17 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Controller Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:18 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:18 --> Total execution time: 0.5343
DEBUG - 2011-09-04 09:49:21 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:21 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:21 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:21 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:21 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:21 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:21 --> Total execution time: 0.0263
DEBUG - 2011-09-04 09:49:22 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:22 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:22 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Controller Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:22 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:22 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:22 --> Total execution time: 0.6023
DEBUG - 2011-09-04 09:49:52 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:52 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:52 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:52 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:52 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:52 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:52 --> Total execution time: 0.0283
DEBUG - 2011-09-04 09:49:52 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:52 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:52 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Controller Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:52 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:52 --> Total execution time: 0.5009
DEBUG - 2011-09-04 09:49:55 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:55 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:55 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:55 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:55 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:55 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:55 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:55 --> Total execution time: 0.0430
DEBUG - 2011-09-04 09:49:55 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:55 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:55 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Controller Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:55 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:56 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:56 --> Total execution time: 0.6639
DEBUG - 2011-09-04 09:49:59 --> Config Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:49:59 --> URI Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Router Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Output Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Input Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:49:59 --> Language Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Loader Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Controller Class Initialized
ERROR - 2011-09-04 09:49:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:49:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:59 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Model Class Initialized
DEBUG - 2011-09-04 09:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:49:59 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:49:59 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:49:59 --> Final output sent to browser
DEBUG - 2011-09-04 09:49:59 --> Total execution time: 0.0394
DEBUG - 2011-09-04 09:50:00 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:00 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:00 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Controller Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:01 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:01 --> Total execution time: 0.5728
DEBUG - 2011-09-04 09:50:04 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:04 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:04 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Controller Class Initialized
ERROR - 2011-09-04 09:50:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:50:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:04 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:04 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:04 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:50:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:50:04 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:04 --> Total execution time: 0.0649
DEBUG - 2011-09-04 09:50:05 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:05 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:05 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Controller Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:05 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:05 --> Total execution time: 0.5766
DEBUG - 2011-09-04 09:50:10 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:10 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:10 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Controller Class Initialized
ERROR - 2011-09-04 09:50:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:50:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:10 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:10 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:10 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:50:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:50:10 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:10 --> Total execution time: 0.0278
DEBUG - 2011-09-04 09:50:10 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:10 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:10 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Controller Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:10 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:11 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:11 --> Total execution time: 0.5479
DEBUG - 2011-09-04 09:50:13 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:13 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:13 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Controller Class Initialized
ERROR - 2011-09-04 09:50:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:50:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:13 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:13 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:50:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:50:13 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:13 --> Total execution time: 0.0292
DEBUG - 2011-09-04 09:50:14 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:14 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:14 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Controller Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:14 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:15 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:15 --> Total execution time: 1.5008
DEBUG - 2011-09-04 09:50:37 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:37 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:37 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Controller Class Initialized
ERROR - 2011-09-04 09:50:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 09:50:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:37 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 09:50:37 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:50:37 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:37 --> Total execution time: 0.0318
DEBUG - 2011-09-04 09:50:37 --> Config Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:50:37 --> URI Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Router Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Output Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Input Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:50:37 --> Language Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Loader Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Controller Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Model Class Initialized
DEBUG - 2011-09-04 09:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:50:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:50:38 --> Final output sent to browser
DEBUG - 2011-09-04 09:50:38 --> Total execution time: 0.4492
DEBUG - 2011-09-04 09:59:45 --> Config Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Hooks Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Utf8 Class Initialized
DEBUG - 2011-09-04 09:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 09:59:45 --> URI Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Router Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Output Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Input Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 09:59:45 --> Language Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Loader Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Controller Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Model Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Model Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Model Class Initialized
DEBUG - 2011-09-04 09:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 09:59:45 --> Database Driver Class Initialized
DEBUG - 2011-09-04 09:59:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 09:59:46 --> Helper loaded: url_helper
DEBUG - 2011-09-04 09:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 09:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 09:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 09:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 09:59:46 --> Final output sent to browser
DEBUG - 2011-09-04 09:59:46 --> Total execution time: 0.2830
DEBUG - 2011-09-04 10:04:20 --> Config Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:04:20 --> URI Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Router Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Output Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Input Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:04:20 --> Language Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Loader Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Controller Class Initialized
ERROR - 2011-09-04 10:04:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:04:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:04:20 --> Model Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Model Class Initialized
DEBUG - 2011-09-04 10:04:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:04:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:04:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:04:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:04:20 --> Final output sent to browser
DEBUG - 2011-09-04 10:04:20 --> Total execution time: 0.0319
DEBUG - 2011-09-04 10:18:59 --> Config Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:18:59 --> URI Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Router Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Output Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Input Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:18:59 --> Language Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Loader Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Controller Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Model Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Model Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Model Class Initialized
DEBUG - 2011-09-04 10:18:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:18:59 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:18:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 10:18:59 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:18:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:18:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:18:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:18:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:18:59 --> Final output sent to browser
DEBUG - 2011-09-04 10:18:59 --> Total execution time: 0.0837
DEBUG - 2011-09-04 10:19:01 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:01 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:01 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:01 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:01 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:01 --> Router Class Initialized
ERROR - 2011-09-04 10:19:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:19:01 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 10:19:01 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:01 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:01 --> Total execution time: 0.0478
DEBUG - 2011-09-04 10:19:04 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:04 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:04 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Controller Class Initialized
ERROR - 2011-09-04 10:19:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:19:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:04 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:04 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:04 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:04 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:04 --> Total execution time: 0.0403
DEBUG - 2011-09-04 10:19:05 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:05 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:05 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:06 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:06 --> Total execution time: 0.7380
DEBUG - 2011-09-04 10:19:07 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:07 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:07 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:07 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:07 --> Router Class Initialized
ERROR - 2011-09-04 10:19:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:19:23 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:23 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:23 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Controller Class Initialized
ERROR - 2011-09-04 10:19:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:19:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:23 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:23 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:23 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:23 --> Total execution time: 0.0377
DEBUG - 2011-09-04 10:19:23 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:23 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:23 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:24 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:24 --> Total execution time: 0.6077
DEBUG - 2011-09-04 10:19:25 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:25 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:25 --> Router Class Initialized
ERROR - 2011-09-04 10:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:19:31 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:31 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:31 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Controller Class Initialized
ERROR - 2011-09-04 10:19:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:19:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:31 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:31 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:31 --> Total execution time: 0.0293
DEBUG - 2011-09-04 10:19:32 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:32 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:32 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:32 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:32 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:32 --> Total execution time: 0.5499
DEBUG - 2011-09-04 10:19:33 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:33 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:33 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:33 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:33 --> Router Class Initialized
ERROR - 2011-09-04 10:19:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:19:39 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:39 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:39 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Controller Class Initialized
ERROR - 2011-09-04 10:19:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:19:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:39 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:39 --> Total execution time: 0.0317
DEBUG - 2011-09-04 10:19:39 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:39 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:39 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:39 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:40 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:40 --> Total execution time: 0.5408
DEBUG - 2011-09-04 10:19:41 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:41 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:41 --> Router Class Initialized
ERROR - 2011-09-04 10:19:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:19:51 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:51 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:51 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Controller Class Initialized
ERROR - 2011-09-04 10:19:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:19:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:51 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:51 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:19:51 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:19:51 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:51 --> Total execution time: 0.0269
DEBUG - 2011-09-04 10:19:52 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:52 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Router Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Output Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Input Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:19:52 --> Language Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Loader Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Controller Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Model Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:19:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:19:52 --> Final output sent to browser
DEBUG - 2011-09-04 10:19:52 --> Total execution time: 0.6205
DEBUG - 2011-09-04 10:19:54 --> Config Class Initialized
DEBUG - 2011-09-04 10:19:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:19:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:19:54 --> URI Class Initialized
DEBUG - 2011-09-04 10:19:54 --> Router Class Initialized
ERROR - 2011-09-04 10:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:20:01 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:01 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:01 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Controller Class Initialized
ERROR - 2011-09-04 10:20:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:20:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:01 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:01 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:01 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:20:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:20:01 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:01 --> Total execution time: 0.0293
DEBUG - 2011-09-04 10:20:02 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:02 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:02 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Controller Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:02 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:03 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:03 --> Total execution time: 1.0160
DEBUG - 2011-09-04 10:20:05 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:05 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:05 --> Router Class Initialized
ERROR - 2011-09-04 10:20:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:20:17 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:17 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:17 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Controller Class Initialized
ERROR - 2011-09-04 10:20:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:20:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:17 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:17 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:20:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:20:17 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:17 --> Total execution time: 0.0281
DEBUG - 2011-09-04 10:20:18 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:18 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:18 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Controller Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:18 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:19 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:19 --> Total execution time: 0.6399
DEBUG - 2011-09-04 10:20:20 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:20 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:20 --> Router Class Initialized
ERROR - 2011-09-04 10:20:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:20:31 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:31 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:31 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Controller Class Initialized
ERROR - 2011-09-04 10:20:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 10:20:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 10:20:31 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:20:31 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:31 --> Total execution time: 0.0352
DEBUG - 2011-09-04 10:20:31 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:31 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Router Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Output Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Input Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:20:31 --> Language Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Loader Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Controller Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Model Class Initialized
DEBUG - 2011-09-04 10:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:20:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:20:32 --> Final output sent to browser
DEBUG - 2011-09-04 10:20:32 --> Total execution time: 0.7272
DEBUG - 2011-09-04 10:20:34 --> Config Class Initialized
DEBUG - 2011-09-04 10:20:34 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:20:34 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:20:34 --> URI Class Initialized
DEBUG - 2011-09-04 10:20:34 --> Router Class Initialized
ERROR - 2011-09-04 10:20:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 10:47:43 --> Config Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 10:47:43 --> URI Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Router Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Output Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Input Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 10:47:43 --> Language Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Loader Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Controller Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Model Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Model Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Model Class Initialized
DEBUG - 2011-09-04 10:47:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 10:47:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 10:47:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 10:47:43 --> Helper loaded: url_helper
DEBUG - 2011-09-04 10:47:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 10:47:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 10:47:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 10:47:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 10:47:43 --> Final output sent to browser
DEBUG - 2011-09-04 10:47:43 --> Total execution time: 0.2048
DEBUG - 2011-09-04 11:30:53 --> Config Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:30:53 --> URI Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Router Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Output Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Input Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:30:53 --> Language Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Loader Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Controller Class Initialized
ERROR - 2011-09-04 11:30:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 11:30:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:30:53 --> Model Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Model Class Initialized
DEBUG - 2011-09-04 11:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:30:53 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:30:53 --> Helper loaded: url_helper
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 11:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 11:30:53 --> Final output sent to browser
DEBUG - 2011-09-04 11:30:53 --> Total execution time: 0.0582
DEBUG - 2011-09-04 11:58:03 --> Config Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:58:03 --> URI Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Router Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Output Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Input Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:58:03 --> Language Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Loader Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Controller Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Model Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Model Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:58:03 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:58:03 --> Final output sent to browser
DEBUG - 2011-09-04 11:58:03 --> Total execution time: 0.3811
DEBUG - 2011-09-04 11:58:30 --> Config Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:58:30 --> URI Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Router Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Output Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Input Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:58:30 --> Language Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Loader Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Controller Class Initialized
ERROR - 2011-09-04 11:58:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 11:58:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:58:30 --> Model Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Model Class Initialized
DEBUG - 2011-09-04 11:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:58:30 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:58:30 --> Helper loaded: url_helper
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 11:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 11:58:30 --> Final output sent to browser
DEBUG - 2011-09-04 11:58:30 --> Total execution time: 0.0693
DEBUG - 2011-09-04 11:59:25 --> Config Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:59:25 --> URI Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Router Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Output Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Input Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:59:25 --> Language Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Loader Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Controller Class Initialized
ERROR - 2011-09-04 11:59:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 11:59:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:59:25 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:59:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:59:25 --> Helper loaded: url_helper
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 11:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 11:59:25 --> Final output sent to browser
DEBUG - 2011-09-04 11:59:25 --> Total execution time: 0.0277
DEBUG - 2011-09-04 11:59:26 --> Config Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:59:26 --> URI Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Router Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Output Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Input Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:59:26 --> Language Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Loader Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Controller Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:59:26 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:59:26 --> Final output sent to browser
DEBUG - 2011-09-04 11:59:26 --> Total execution time: 0.6181
DEBUG - 2011-09-04 11:59:27 --> Config Class Initialized
DEBUG - 2011-09-04 11:59:27 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:59:27 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:59:27 --> URI Class Initialized
DEBUG - 2011-09-04 11:59:27 --> Router Class Initialized
ERROR - 2011-09-04 11:59:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 11:59:50 --> Config Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:59:50 --> URI Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Router Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Output Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Input Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:59:50 --> Language Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Loader Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Controller Class Initialized
ERROR - 2011-09-04 11:59:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 11:59:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:59:50 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:59:50 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 11:59:50 --> Helper loaded: url_helper
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 11:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 11:59:50 --> Final output sent to browser
DEBUG - 2011-09-04 11:59:50 --> Total execution time: 0.0273
DEBUG - 2011-09-04 11:59:51 --> Config Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Hooks Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Utf8 Class Initialized
DEBUG - 2011-09-04 11:59:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 11:59:51 --> URI Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Router Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Output Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Input Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 11:59:51 --> Language Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Loader Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Controller Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Model Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 11:59:51 --> Database Driver Class Initialized
DEBUG - 2011-09-04 11:59:51 --> Final output sent to browser
DEBUG - 2011-09-04 11:59:51 --> Total execution time: 0.6172
DEBUG - 2011-09-04 12:09:48 --> Config Class Initialized
DEBUG - 2011-09-04 12:09:48 --> Hooks Class Initialized
DEBUG - 2011-09-04 12:09:48 --> Utf8 Class Initialized
DEBUG - 2011-09-04 12:09:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 12:09:48 --> URI Class Initialized
DEBUG - 2011-09-04 12:09:48 --> Router Class Initialized
ERROR - 2011-09-04 12:09:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 13:24:52 --> Config Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:24:52 --> URI Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Router Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Output Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Input Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:24:52 --> Language Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Loader Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Controller Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Model Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Model Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Model Class Initialized
DEBUG - 2011-09-04 13:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:24:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:24:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:24:53 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:24:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:24:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:24:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:24:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:24:53 --> Final output sent to browser
DEBUG - 2011-09-04 13:24:53 --> Total execution time: 0.6593
DEBUG - 2011-09-04 13:24:55 --> Config Class Initialized
DEBUG - 2011-09-04 13:24:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:24:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:24:55 --> URI Class Initialized
DEBUG - 2011-09-04 13:24:55 --> Router Class Initialized
ERROR - 2011-09-04 13:24:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 13:25:14 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:14 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Router Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Output Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Input Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:25:14 --> Language Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Loader Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Controller Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:25:14 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:25:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:25:14 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:25:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:25:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:25:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:25:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:25:14 --> Final output sent to browser
DEBUG - 2011-09-04 13:25:14 --> Total execution time: 0.2729
DEBUG - 2011-09-04 13:25:25 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:25 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Router Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Output Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Input Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:25:25 --> Language Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Loader Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Controller Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:25:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:25:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:25:26 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:25:26 --> Final output sent to browser
DEBUG - 2011-09-04 13:25:26 --> Total execution time: 0.2310
DEBUG - 2011-09-04 13:25:39 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:39 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Router Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Output Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Input Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:25:39 --> Language Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Loader Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Controller Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:25:39 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:25:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:25:39 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:25:39 --> Final output sent to browser
DEBUG - 2011-09-04 13:25:39 --> Total execution time: 0.2301
DEBUG - 2011-09-04 13:25:41 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:41 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Router Class Initialized
ERROR - 2011-09-04 13:25:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 13:25:41 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:41 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Router Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Output Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Input Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:25:41 --> Language Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Loader Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Controller Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:25:41 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:25:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:25:41 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:25:41 --> Final output sent to browser
DEBUG - 2011-09-04 13:25:41 --> Total execution time: 0.0440
DEBUG - 2011-09-04 13:25:51 --> Config Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:25:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:25:51 --> URI Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Router Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Output Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Input Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:25:51 --> Language Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Loader Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Controller Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Model Class Initialized
DEBUG - 2011-09-04 13:25:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:25:51 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:25:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:25:51 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:25:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:25:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:25:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:25:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:25:51 --> Final output sent to browser
DEBUG - 2011-09-04 13:25:51 --> Total execution time: 0.2393
DEBUG - 2011-09-04 13:26:00 --> Config Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:26:00 --> URI Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Router Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Output Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Input Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:26:00 --> Language Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Loader Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Controller Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:26:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:26:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:26:00 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:26:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:26:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:26:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:26:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:26:00 --> Final output sent to browser
DEBUG - 2011-09-04 13:26:00 --> Total execution time: 0.3817
DEBUG - 2011-09-04 13:26:09 --> Config Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:26:09 --> URI Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Router Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Output Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Input Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:26:09 --> Language Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Loader Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Controller Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:26:09 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:26:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:26:09 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:26:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:26:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:26:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:26:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:26:09 --> Final output sent to browser
DEBUG - 2011-09-04 13:26:09 --> Total execution time: 0.2385
DEBUG - 2011-09-04 13:26:35 --> Config Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:26:35 --> URI Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Router Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Output Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Input Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:26:35 --> Language Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Loader Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Controller Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Model Class Initialized
DEBUG - 2011-09-04 13:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:26:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:26:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:26:35 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:26:35 --> Final output sent to browser
DEBUG - 2011-09-04 13:26:35 --> Total execution time: 0.2100
DEBUG - 2011-09-04 13:28:17 --> Config Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:28:17 --> URI Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Router Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Output Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Input Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 13:28:17 --> Language Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Loader Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Controller Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Model Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Model Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Model Class Initialized
DEBUG - 2011-09-04 13:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 13:28:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 13:28:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 13:28:17 --> Helper loaded: url_helper
DEBUG - 2011-09-04 13:28:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 13:28:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 13:28:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 13:28:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 13:28:17 --> Final output sent to browser
DEBUG - 2011-09-04 13:28:17 --> Total execution time: 0.0470
DEBUG - 2011-09-04 13:28:34 --> Config Class Initialized
DEBUG - 2011-09-04 13:28:34 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:28:34 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:28:34 --> URI Class Initialized
DEBUG - 2011-09-04 13:28:34 --> Router Class Initialized
ERROR - 2011-09-04 13:28:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 13:32:35 --> Config Class Initialized
DEBUG - 2011-09-04 13:32:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 13:32:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 13:32:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 13:32:35 --> URI Class Initialized
DEBUG - 2011-09-04 13:32:35 --> Router Class Initialized
ERROR - 2011-09-04 13:32:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-04 14:06:31 --> Config Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 14:06:31 --> URI Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Router Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Output Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Input Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 14:06:31 --> Language Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Loader Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Controller Class Initialized
ERROR - 2011-09-04 14:06:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 14:06:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 14:06:31 --> Model Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Model Class Initialized
DEBUG - 2011-09-04 14:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 14:06:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 14:06:31 --> Helper loaded: url_helper
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 14:06:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 14:06:31 --> Final output sent to browser
DEBUG - 2011-09-04 14:06:31 --> Total execution time: 0.0347
DEBUG - 2011-09-04 14:23:20 --> Config Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 14:23:20 --> URI Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Router Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Output Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Input Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 14:23:20 --> Language Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Loader Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Controller Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Model Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Model Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Model Class Initialized
DEBUG - 2011-09-04 14:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 14:23:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 14:23:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 14:23:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 14:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 14:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 14:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 14:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 14:23:20 --> Final output sent to browser
DEBUG - 2011-09-04 14:23:20 --> Total execution time: 0.3007
DEBUG - 2011-09-04 14:39:31 --> Config Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Hooks Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Utf8 Class Initialized
DEBUG - 2011-09-04 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 14:39:31 --> URI Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Router Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Output Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Input Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 14:39:31 --> Language Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Loader Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Controller Class Initialized
ERROR - 2011-09-04 14:39:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 14:39:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 14:39:31 --> Model Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Model Class Initialized
DEBUG - 2011-09-04 14:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 14:39:31 --> Database Driver Class Initialized
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 14:39:31 --> Helper loaded: url_helper
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 14:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 14:39:31 --> Final output sent to browser
DEBUG - 2011-09-04 14:39:31 --> Total execution time: 0.0487
DEBUG - 2011-09-04 15:07:46 --> Config Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:07:46 --> URI Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Router Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Output Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Input Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:07:46 --> Language Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Loader Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Controller Class Initialized
ERROR - 2011-09-04 15:07:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 15:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:07:46 --> Model Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Model Class Initialized
DEBUG - 2011-09-04 15:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:07:46 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:07:46 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:07:46 --> Final output sent to browser
DEBUG - 2011-09-04 15:07:46 --> Total execution time: 0.0303
DEBUG - 2011-09-04 15:07:47 --> Config Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:07:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:07:47 --> URI Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Router Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Output Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Input Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:07:47 --> Language Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Loader Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Controller Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Model Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Model Class Initialized
DEBUG - 2011-09-04 15:07:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:07:47 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:07:48 --> Final output sent to browser
DEBUG - 2011-09-04 15:07:48 --> Total execution time: 0.6597
DEBUG - 2011-09-04 15:07:49 --> Config Class Initialized
DEBUG - 2011-09-04 15:07:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:07:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:07:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:07:49 --> URI Class Initialized
DEBUG - 2011-09-04 15:07:49 --> Router Class Initialized
ERROR - 2011-09-04 15:07:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 15:08:20 --> Config Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:08:20 --> URI Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Router Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Output Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Input Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:08:20 --> Language Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Loader Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Controller Class Initialized
ERROR - 2011-09-04 15:08:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 15:08:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:08:20 --> Model Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Model Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:08:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:08:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:08:20 --> Final output sent to browser
DEBUG - 2011-09-04 15:08:20 --> Total execution time: 0.0286
DEBUG - 2011-09-04 15:08:20 --> Config Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:08:20 --> URI Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Router Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Output Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Input Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:08:20 --> Language Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Loader Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Controller Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Model Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Model Class Initialized
DEBUG - 2011-09-04 15:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:08:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:08:21 --> Final output sent to browser
DEBUG - 2011-09-04 15:08:21 --> Total execution time: 0.6790
DEBUG - 2011-09-04 15:08:24 --> Config Class Initialized
DEBUG - 2011-09-04 15:08:24 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:08:24 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:08:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:08:24 --> URI Class Initialized
DEBUG - 2011-09-04 15:08:24 --> Router Class Initialized
ERROR - 2011-09-04 15:08:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 15:23:46 --> Config Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:23:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:23:46 --> URI Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Router Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Output Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Input Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:23:46 --> Language Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Loader Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Controller Class Initialized
ERROR - 2011-09-04 15:23:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 15:23:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:23:46 --> Model Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Model Class Initialized
DEBUG - 2011-09-04 15:23:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:23:46 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 15:23:46 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:23:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:23:46 --> Final output sent to browser
DEBUG - 2011-09-04 15:23:46 --> Total execution time: 0.0330
DEBUG - 2011-09-04 15:29:15 --> Config Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:29:15 --> URI Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Router Class Initialized
DEBUG - 2011-09-04 15:29:15 --> No URI present. Default controller set.
DEBUG - 2011-09-04 15:29:15 --> Output Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Input Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:29:15 --> Language Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Loader Class Initialized
DEBUG - 2011-09-04 15:29:15 --> Controller Class Initialized
DEBUG - 2011-09-04 15:29:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 15:29:15 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:29:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:29:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:29:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:29:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:29:15 --> Final output sent to browser
DEBUG - 2011-09-04 15:29:15 --> Total execution time: 0.0686
DEBUG - 2011-09-04 15:48:48 --> Config Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:48:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:48:48 --> URI Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Router Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Output Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Input Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:48:48 --> Language Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Loader Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Controller Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Model Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Model Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Model Class Initialized
DEBUG - 2011-09-04 15:48:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:48:48 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:48:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:48:48 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:48:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:48:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:48:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:48:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:48:48 --> Final output sent to browser
DEBUG - 2011-09-04 15:48:48 --> Total execution time: 0.2238
DEBUG - 2011-09-04 15:53:37 --> Config Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:53:37 --> URI Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Router Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Output Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Input Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:53:37 --> Language Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Loader Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Controller Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:53:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:53:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:53:37 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:53:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:53:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:53:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:53:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:53:37 --> Final output sent to browser
DEBUG - 2011-09-04 15:53:37 --> Total execution time: 0.0503
DEBUG - 2011-09-04 15:53:39 --> Config Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:53:39 --> URI Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Router Class Initialized
ERROR - 2011-09-04 15:53:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 15:53:39 --> Config Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:53:39 --> URI Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Router Class Initialized
ERROR - 2011-09-04 15:53:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 15:53:39 --> Config Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:53:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:53:39 --> URI Class Initialized
DEBUG - 2011-09-04 15:53:39 --> Router Class Initialized
ERROR - 2011-09-04 15:53:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 15:53:49 --> Config Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:53:49 --> URI Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Router Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Output Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Input Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:53:49 --> Language Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Loader Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Controller Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Model Class Initialized
DEBUG - 2011-09-04 15:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:53:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:53:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:53:49 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:53:49 --> Final output sent to browser
DEBUG - 2011-09-04 15:53:49 --> Total execution time: 0.1992
DEBUG - 2011-09-04 15:54:05 --> Config Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:54:05 --> URI Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Router Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Output Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Input Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:54:05 --> Language Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Loader Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Controller Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:54:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:54:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:54:05 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:54:05 --> Final output sent to browser
DEBUG - 2011-09-04 15:54:05 --> Total execution time: 0.2856
DEBUG - 2011-09-04 15:54:17 --> Config Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:54:17 --> URI Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Router Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Output Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Input Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:54:17 --> Language Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Loader Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Controller Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:54:17 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:54:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:54:18 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:54:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:54:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:54:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:54:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:54:18 --> Final output sent to browser
DEBUG - 2011-09-04 15:54:18 --> Total execution time: 0.2732
DEBUG - 2011-09-04 15:54:32 --> Config Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:54:32 --> URI Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Router Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Output Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Input Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:54:32 --> Language Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Loader Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Controller Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:54:32 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:54:32 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:54:32 --> Final output sent to browser
DEBUG - 2011-09-04 15:54:32 --> Total execution time: 0.3286
DEBUG - 2011-09-04 15:54:44 --> Config Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Hooks Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Utf8 Class Initialized
DEBUG - 2011-09-04 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 15:54:44 --> URI Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Router Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Output Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Input Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 15:54:44 --> Language Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Loader Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Controller Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Model Class Initialized
DEBUG - 2011-09-04 15:54:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 15:54:44 --> Database Driver Class Initialized
DEBUG - 2011-09-04 15:54:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 15:54:44 --> Helper loaded: url_helper
DEBUG - 2011-09-04 15:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 15:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 15:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 15:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 15:54:44 --> Final output sent to browser
DEBUG - 2011-09-04 15:54:44 --> Total execution time: 0.2745
DEBUG - 2011-09-04 16:02:23 --> Config Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:02:23 --> URI Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Router Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Output Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Input Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:02:23 --> Language Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Loader Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Controller Class Initialized
ERROR - 2011-09-04 16:02:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 16:02:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:02:23 --> Model Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Model Class Initialized
DEBUG - 2011-09-04 16:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:02:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:02:23 --> Helper loaded: url_helper
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 16:02:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 16:02:23 --> Final output sent to browser
DEBUG - 2011-09-04 16:02:23 --> Total execution time: 0.0283
DEBUG - 2011-09-04 16:17:21 --> Config Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:17:21 --> URI Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Router Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Output Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Input Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:17:21 --> Language Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Loader Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Controller Class Initialized
ERROR - 2011-09-04 16:17:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 16:17:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:17:21 --> Model Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Model Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:17:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:17:21 --> Helper loaded: url_helper
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 16:17:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 16:17:21 --> Final output sent to browser
DEBUG - 2011-09-04 16:17:21 --> Total execution time: 0.0308
DEBUG - 2011-09-04 16:17:21 --> Config Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:17:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:17:21 --> URI Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Router Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Output Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Input Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:17:21 --> Language Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Loader Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Controller Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Model Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Model Class Initialized
DEBUG - 2011-09-04 16:17:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:17:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:17:22 --> Final output sent to browser
DEBUG - 2011-09-04 16:17:22 --> Total execution time: 0.7540
DEBUG - 2011-09-04 16:59:20 --> Config Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:59:20 --> URI Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Router Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Output Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Input Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:59:20 --> Language Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Loader Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Controller Class Initialized
ERROR - 2011-09-04 16:59:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 16:59:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:59:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 16:59:20 --> Helper loaded: url_helper
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 16:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 16:59:20 --> Final output sent to browser
DEBUG - 2011-09-04 16:59:20 --> Total execution time: 0.0452
DEBUG - 2011-09-04 16:59:20 --> Config Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:59:20 --> URI Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Router Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Output Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Input Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:59:20 --> Language Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Loader Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Controller Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:59:20 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:59:21 --> Final output sent to browser
DEBUG - 2011-09-04 16:59:21 --> Total execution time: 0.6523
DEBUG - 2011-09-04 16:59:22 --> Config Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:59:22 --> URI Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Router Class Initialized
ERROR - 2011-09-04 16:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 16:59:22 --> Config Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:59:22 --> URI Class Initialized
DEBUG - 2011-09-04 16:59:22 --> Router Class Initialized
ERROR - 2011-09-04 16:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 16:59:50 --> Config Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 16:59:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 16:59:50 --> URI Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Router Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Output Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Input Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 16:59:50 --> Language Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Loader Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Controller Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Model Class Initialized
DEBUG - 2011-09-04 16:59:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 16:59:50 --> Database Driver Class Initialized
DEBUG - 2011-09-04 16:59:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 16:59:50 --> Helper loaded: url_helper
DEBUG - 2011-09-04 16:59:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 16:59:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 16:59:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 16:59:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 16:59:50 --> Final output sent to browser
DEBUG - 2011-09-04 16:59:50 --> Total execution time: 0.3661
DEBUG - 2011-09-04 18:01:43 --> Config Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 18:01:43 --> URI Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Router Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Output Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Input Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 18:01:43 --> Language Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Loader Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Controller Class Initialized
ERROR - 2011-09-04 18:01:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 18:01:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 18:01:43 --> Model Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Model Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 18:01:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 18:01:43 --> Helper loaded: url_helper
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 18:01:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 18:01:43 --> Final output sent to browser
DEBUG - 2011-09-04 18:01:43 --> Total execution time: 0.0494
DEBUG - 2011-09-04 18:01:43 --> Config Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Hooks Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Utf8 Class Initialized
DEBUG - 2011-09-04 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 18:01:43 --> URI Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Router Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Output Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Input Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 18:01:43 --> Language Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Loader Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Controller Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Model Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Model Class Initialized
DEBUG - 2011-09-04 18:01:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 18:01:43 --> Database Driver Class Initialized
DEBUG - 2011-09-04 18:01:44 --> Final output sent to browser
DEBUG - 2011-09-04 18:01:44 --> Total execution time: 0.6856
DEBUG - 2011-09-04 19:34:45 --> Config Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Hooks Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Utf8 Class Initialized
DEBUG - 2011-09-04 19:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 19:34:45 --> URI Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Router Class Initialized
DEBUG - 2011-09-04 19:34:45 --> No URI present. Default controller set.
DEBUG - 2011-09-04 19:34:45 --> Output Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Input Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 19:34:45 --> Language Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Loader Class Initialized
DEBUG - 2011-09-04 19:34:45 --> Controller Class Initialized
DEBUG - 2011-09-04 19:34:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 19:34:45 --> Helper loaded: url_helper
DEBUG - 2011-09-04 19:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 19:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 19:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 19:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 19:34:45 --> Final output sent to browser
DEBUG - 2011-09-04 19:34:45 --> Total execution time: 0.0549
DEBUG - 2011-09-04 19:52:35 --> Config Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 19:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 19:52:35 --> URI Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Router Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Output Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Input Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 19:52:35 --> Language Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Loader Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Controller Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Model Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Model Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Model Class Initialized
DEBUG - 2011-09-04 19:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 19:52:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 19:52:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 19:52:36 --> Helper loaded: url_helper
DEBUG - 2011-09-04 19:52:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 19:52:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 19:52:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 19:52:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 19:52:36 --> Final output sent to browser
DEBUG - 2011-09-04 19:52:36 --> Total execution time: 0.5563
DEBUG - 2011-09-04 19:52:37 --> Config Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 19:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 19:52:37 --> URI Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Router Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Output Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Input Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 19:52:37 --> Language Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Loader Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Controller Class Initialized
ERROR - 2011-09-04 19:52:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 19:52:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 19:52:37 --> Model Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Model Class Initialized
DEBUG - 2011-09-04 19:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 19:52:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 19:52:37 --> Helper loaded: url_helper
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 19:52:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 19:52:37 --> Final output sent to browser
DEBUG - 2011-09-04 19:52:37 --> Total execution time: 0.0281
DEBUG - 2011-09-04 21:18:57 --> Config Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:18:57 --> URI Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Router Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Output Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Input Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:18:57 --> Language Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Loader Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Controller Class Initialized
ERROR - 2011-09-04 21:18:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:18:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:18:57 --> Model Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Model Class Initialized
DEBUG - 2011-09-04 21:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:18:57 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:18:57 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:18:57 --> Final output sent to browser
DEBUG - 2011-09-04 21:18:57 --> Total execution time: 0.2090
DEBUG - 2011-09-04 21:18:58 --> Config Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:18:58 --> URI Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Router Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Output Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Input Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:18:58 --> Language Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Loader Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Controller Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:18:58 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:18:59 --> Final output sent to browser
DEBUG - 2011-09-04 21:18:59 --> Total execution time: 0.8100
DEBUG - 2011-09-04 21:19:00 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:00 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Router Class Initialized
ERROR - 2011-09-04 21:19:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 21:19:00 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:00 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:00 --> Router Class Initialized
ERROR - 2011-09-04 21:19:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-04 21:19:36 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:36 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Router Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Output Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Input Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:19:36 --> Language Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Loader Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Controller Class Initialized
ERROR - 2011-09-04 21:19:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:19:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:19:36 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:19:36 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:19:36 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:19:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:19:36 --> Final output sent to browser
DEBUG - 2011-09-04 21:19:36 --> Total execution time: 0.0630
DEBUG - 2011-09-04 21:19:36 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:36 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Router Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Output Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Input Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:19:36 --> Language Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Loader Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Controller Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:19:36 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:19:37 --> Final output sent to browser
DEBUG - 2011-09-04 21:19:37 --> Total execution time: 0.5371
DEBUG - 2011-09-04 21:19:58 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:58 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Router Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Output Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Input Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:19:58 --> Language Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Loader Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Controller Class Initialized
ERROR - 2011-09-04 21:19:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:19:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:19:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:19:58 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:19:58 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:19:58 --> Final output sent to browser
DEBUG - 2011-09-04 21:19:58 --> Total execution time: 0.0322
DEBUG - 2011-09-04 21:19:58 --> Config Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:19:58 --> URI Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Router Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Output Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Input Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:19:58 --> Language Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Loader Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Controller Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Model Class Initialized
DEBUG - 2011-09-04 21:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:19:58 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:19:59 --> Final output sent to browser
DEBUG - 2011-09-04 21:19:59 --> Total execution time: 0.7602
DEBUG - 2011-09-04 21:20:00 --> Config Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:20:00 --> URI Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Router Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Output Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Input Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:20:00 --> Language Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Loader Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Controller Class Initialized
ERROR - 2011-09-04 21:20:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:20:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:20:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:00 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:20:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:20:00 --> Final output sent to browser
DEBUG - 2011-09-04 21:20:00 --> Total execution time: 0.0294
DEBUG - 2011-09-04 21:20:49 --> Config Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:20:49 --> URI Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Router Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Output Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Input Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:20:49 --> Language Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Loader Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Controller Class Initialized
ERROR - 2011-09-04 21:20:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:49 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:20:49 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:49 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:20:49 --> Final output sent to browser
DEBUG - 2011-09-04 21:20:49 --> Total execution time: 0.0716
DEBUG - 2011-09-04 21:20:50 --> Config Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:20:50 --> URI Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Router Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Output Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Input Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:20:50 --> Language Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Loader Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Controller Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:20:50 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:20:50 --> Final output sent to browser
DEBUG - 2011-09-04 21:20:50 --> Total execution time: 0.7796
DEBUG - 2011-09-04 21:20:59 --> Config Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:20:59 --> URI Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Router Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Output Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Input Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:20:59 --> Language Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Loader Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Controller Class Initialized
ERROR - 2011-09-04 21:20:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:20:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:59 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Model Class Initialized
DEBUG - 2011-09-04 21:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:20:59 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:20:59 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:20:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:20:59 --> Final output sent to browser
DEBUG - 2011-09-04 21:20:59 --> Total execution time: 0.0875
DEBUG - 2011-09-04 21:21:00 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:00 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:00 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Controller Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:01 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:01 --> Total execution time: 0.7415
DEBUG - 2011-09-04 21:21:25 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:25 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:25 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Controller Class Initialized
ERROR - 2011-09-04 21:21:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:21:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:21:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:26 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:26 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:21:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:21:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:21:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:21:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:21:26 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:26 --> Total execution time: 0.0291
DEBUG - 2011-09-04 21:21:26 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:26 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:26 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Controller Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:26 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:27 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:27 --> Total execution time: 0.5807
DEBUG - 2011-09-04 21:21:45 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:45 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:45 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Controller Class Initialized
ERROR - 2011-09-04 21:21:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:21:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:45 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:45 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:45 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:21:45 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:45 --> Total execution time: 0.0443
DEBUG - 2011-09-04 21:21:45 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:45 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:45 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Controller Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:45 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:46 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:46 --> Total execution time: 0.7940
DEBUG - 2011-09-04 21:21:59 --> Config Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:21:59 --> URI Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Router Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Output Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Input Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:21:59 --> Language Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Loader Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Controller Class Initialized
ERROR - 2011-09-04 21:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:59 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Model Class Initialized
DEBUG - 2011-09-04 21:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:21:59 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:21:59 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:21:59 --> Final output sent to browser
DEBUG - 2011-09-04 21:21:59 --> Total execution time: 0.0279
DEBUG - 2011-09-04 21:22:00 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:00 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:00 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Controller Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:00 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:00 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:00 --> Total execution time: 0.5306
DEBUG - 2011-09-04 21:22:18 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:18 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:18 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Controller Class Initialized
ERROR - 2011-09-04 21:22:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:22:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:18 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:18 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:18 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:22:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:22:18 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:18 --> Total execution time: 0.1108
DEBUG - 2011-09-04 21:22:19 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:19 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:19 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Controller Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:19 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:19 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:19 --> Total execution time: 0.6238
DEBUG - 2011-09-04 21:22:35 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:35 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:35 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Controller Class Initialized
ERROR - 2011-09-04 21:22:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:22:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:35 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:22:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:22:35 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:35 --> Total execution time: 0.0307
DEBUG - 2011-09-04 21:22:35 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:35 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:35 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Controller Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:36 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:36 --> Total execution time: 0.5685
DEBUG - 2011-09-04 21:22:52 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:52 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:52 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Controller Class Initialized
ERROR - 2011-09-04 21:22:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:22:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:22:52 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:22:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:22:52 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:52 --> Total execution time: 0.0349
DEBUG - 2011-09-04 21:22:52 --> Config Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:22:52 --> URI Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Router Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Output Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Input Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:22:52 --> Language Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Loader Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Controller Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:22:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:22:53 --> Final output sent to browser
DEBUG - 2011-09-04 21:22:53 --> Total execution time: 0.6047
DEBUG - 2011-09-04 21:23:04 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:04 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:04 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:04 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Controller Class Initialized
ERROR - 2011-09-04 21:23:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:23:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:05 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:05 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:23:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:23:05 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:05 --> Total execution time: 0.1326
DEBUG - 2011-09-04 21:23:05 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:05 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:05 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Controller Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:05 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:06 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:06 --> Total execution time: 0.6585
DEBUG - 2011-09-04 21:23:21 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:21 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:21 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Controller Class Initialized
ERROR - 2011-09-04 21:23:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:23:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:21 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:21 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:21 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:23:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:23:21 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:21 --> Total execution time: 0.0310
DEBUG - 2011-09-04 21:23:22 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:22 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:22 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Controller Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:22 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:22 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:22 --> Total execution time: 0.5261
DEBUG - 2011-09-04 21:23:23 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:23 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:23 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Controller Class Initialized
ERROR - 2011-09-04 21:23:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:23:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:23 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:23 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:23:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:23:23 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:23 --> Total execution time: 0.0279
DEBUG - 2011-09-04 21:23:34 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:34 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:34 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Controller Class Initialized
ERROR - 2011-09-04 21:23:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:23:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:34 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:34 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:34 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:23:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:23:34 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:34 --> Total execution time: 0.0290
DEBUG - 2011-09-04 21:23:34 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:34 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:34 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Controller Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:34 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:35 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:35 --> Total execution time: 0.4997
DEBUG - 2011-09-04 21:23:54 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:54 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:54 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Controller Class Initialized
ERROR - 2011-09-04 21:23:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:23:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:54 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:54 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:23:54 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:23:54 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:54 --> Total execution time: 0.0406
DEBUG - 2011-09-04 21:23:55 --> Config Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:23:55 --> URI Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Router Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Output Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Input Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:23:55 --> Language Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Loader Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Controller Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Model Class Initialized
DEBUG - 2011-09-04 21:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:23:55 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:23:56 --> Final output sent to browser
DEBUG - 2011-09-04 21:23:56 --> Total execution time: 0.7225
DEBUG - 2011-09-04 21:24:11 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:11 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:11 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Controller Class Initialized
ERROR - 2011-09-04 21:24:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:24:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:11 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:11 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:11 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:24:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:24:11 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:11 --> Total execution time: 0.0398
DEBUG - 2011-09-04 21:24:12 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:12 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:12 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Controller Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:12 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:13 --> Total execution time: 0.7853
DEBUG - 2011-09-04 21:24:13 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:13 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:13 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Controller Class Initialized
ERROR - 2011-09-04 21:24:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:24:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:13 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:13 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:13 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:24:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:24:13 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:13 --> Total execution time: 0.0284
DEBUG - 2011-09-04 21:24:25 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:25 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:25 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Controller Class Initialized
ERROR - 2011-09-04 21:24:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:24:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:25 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:24:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:24:25 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:25 --> Total execution time: 0.0270
DEBUG - 2011-09-04 21:24:25 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:25 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:25 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Controller Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:25 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:26 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:26 --> Total execution time: 0.5606
DEBUG - 2011-09-04 21:24:37 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:37 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:37 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Controller Class Initialized
ERROR - 2011-09-04 21:24:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:24:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:37 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:37 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:24:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:24:37 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:37 --> Total execution time: 0.0328
DEBUG - 2011-09-04 21:24:37 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:37 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:37 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Controller Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:37 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:38 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:38 --> Total execution time: 0.6757
DEBUG - 2011-09-04 21:24:52 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:52 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:52 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Controller Class Initialized
ERROR - 2011-09-04 21:24:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:24:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:52 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:24:52 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:24:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:24:52 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:52 --> Total execution time: 0.0345
DEBUG - 2011-09-04 21:24:53 --> Config Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:24:53 --> URI Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Router Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Output Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Input Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:24:53 --> Language Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Loader Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Controller Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Model Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:24:53 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:24:53 --> Final output sent to browser
DEBUG - 2011-09-04 21:24:53 --> Total execution time: 0.4957
DEBUG - 2011-09-04 21:25:06 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:06 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:06 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Controller Class Initialized
ERROR - 2011-09-04 21:25:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:25:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:06 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:06 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:06 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:25:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:25:06 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:06 --> Total execution time: 0.0607
DEBUG - 2011-09-04 21:25:07 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:07 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:07 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Controller Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:07 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:08 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:08 --> Total execution time: 0.6483
DEBUG - 2011-09-04 21:25:22 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:22 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:22 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Controller Class Initialized
ERROR - 2011-09-04 21:25:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:25:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:22 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:22 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:22 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:25:22 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:22 --> Total execution time: 0.0274
DEBUG - 2011-09-04 21:25:23 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:23 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:23 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Controller Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:23 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:23 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:23 --> Total execution time: 0.4780
DEBUG - 2011-09-04 21:25:35 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:35 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:35 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Controller Class Initialized
ERROR - 2011-09-04 21:25:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-04 21:25:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-04 21:25:35 --> Helper loaded: url_helper
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 21:25:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 21:25:35 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:35 --> Total execution time: 0.0313
DEBUG - 2011-09-04 21:25:35 --> Config Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Hooks Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Utf8 Class Initialized
DEBUG - 2011-09-04 21:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 21:25:35 --> URI Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Router Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Output Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Input Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 21:25:35 --> Language Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Loader Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Controller Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Model Class Initialized
DEBUG - 2011-09-04 21:25:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 21:25:35 --> Database Driver Class Initialized
DEBUG - 2011-09-04 21:25:36 --> Final output sent to browser
DEBUG - 2011-09-04 21:25:36 --> Total execution time: 0.4712
DEBUG - 2011-09-04 22:01:28 --> Config Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Hooks Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Utf8 Class Initialized
DEBUG - 2011-09-04 22:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 22:01:28 --> URI Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Router Class Initialized
DEBUG - 2011-09-04 22:01:28 --> No URI present. Default controller set.
DEBUG - 2011-09-04 22:01:28 --> Output Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Input Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 22:01:28 --> Language Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Loader Class Initialized
DEBUG - 2011-09-04 22:01:28 --> Controller Class Initialized
DEBUG - 2011-09-04 22:01:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-04 22:01:28 --> Helper loaded: url_helper
DEBUG - 2011-09-04 22:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 22:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 22:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 22:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 22:01:28 --> Final output sent to browser
DEBUG - 2011-09-04 22:01:28 --> Total execution time: 0.0487
DEBUG - 2011-09-04 23:07:11 --> Config Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Hooks Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Utf8 Class Initialized
DEBUG - 2011-09-04 23:07:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-04 23:07:11 --> URI Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Router Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Output Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Input Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-04 23:07:11 --> Language Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Loader Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Controller Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Model Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Model Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Model Class Initialized
DEBUG - 2011-09-04 23:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-04 23:07:11 --> Database Driver Class Initialized
DEBUG - 2011-09-04 23:07:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-04 23:07:11 --> Helper loaded: url_helper
DEBUG - 2011-09-04 23:07:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-04 23:07:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-04 23:07:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-04 23:07:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-04 23:07:11 --> Final output sent to browser
DEBUG - 2011-09-04 23:07:11 --> Total execution time: 0.3178

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-11 00:56:22 --> Config Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Hooks Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Utf8 Class Initialized
DEBUG - 2011-06-11 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 00:56:22 --> URI Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Router Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Output Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Input Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 00:56:22 --> Language Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Loader Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Controller Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Model Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Model Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Model Class Initialized
DEBUG - 2011-06-11 00:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 00:56:22 --> Database Driver Class Initialized
DEBUG - 2011-06-11 00:56:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 00:56:22 --> Helper loaded: url_helper
DEBUG - 2011-06-11 00:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 00:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 00:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 00:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 00:56:22 --> Final output sent to browser
DEBUG - 2011-06-11 00:56:22 --> Total execution time: 0.4979
DEBUG - 2011-06-11 00:56:25 --> Config Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Hooks Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Utf8 Class Initialized
DEBUG - 2011-06-11 00:56:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 00:56:25 --> URI Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Router Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Output Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Input Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 00:56:25 --> Language Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Loader Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Controller Class Initialized
ERROR - 2011-06-11 00:56:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 00:56:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 00:56:25 --> Model Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Model Class Initialized
DEBUG - 2011-06-11 00:56:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 00:56:25 --> Database Driver Class Initialized
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 00:56:25 --> Helper loaded: url_helper
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 00:56:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 00:56:25 --> Final output sent to browser
DEBUG - 2011-06-11 00:56:25 --> Total execution time: 0.0855
DEBUG - 2011-06-11 01:30:52 --> Config Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Hooks Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Utf8 Class Initialized
DEBUG - 2011-06-11 01:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 01:30:52 --> URI Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Router Class Initialized
ERROR - 2011-06-11 01:30:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 01:30:52 --> Config Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Hooks Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Utf8 Class Initialized
DEBUG - 2011-06-11 01:30:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 01:30:52 --> URI Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Router Class Initialized
DEBUG - 2011-06-11 01:30:52 --> No URI present. Default controller set.
DEBUG - 2011-06-11 01:30:52 --> Output Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Input Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 01:30:52 --> Language Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Loader Class Initialized
DEBUG - 2011-06-11 01:30:52 --> Controller Class Initialized
DEBUG - 2011-06-11 01:30:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-11 01:30:52 --> Helper loaded: url_helper
DEBUG - 2011-06-11 01:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 01:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 01:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 01:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 01:30:52 --> Final output sent to browser
DEBUG - 2011-06-11 01:30:52 --> Total execution time: 0.1153
DEBUG - 2011-06-11 01:30:53 --> Config Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Hooks Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Utf8 Class Initialized
DEBUG - 2011-06-11 01:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 01:30:53 --> URI Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Router Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Output Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Input Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 01:30:53 --> Language Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Loader Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Controller Class Initialized
ERROR - 2011-06-11 01:30:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 01:30:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 01:30:53 --> Model Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Model Class Initialized
DEBUG - 2011-06-11 01:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 01:30:53 --> Database Driver Class Initialized
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 01:30:53 --> Helper loaded: url_helper
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 01:30:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 01:30:53 --> Final output sent to browser
DEBUG - 2011-06-11 01:30:53 --> Total execution time: 0.1865
DEBUG - 2011-06-11 01:30:54 --> Config Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Hooks Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Utf8 Class Initialized
DEBUG - 2011-06-11 01:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 01:30:54 --> URI Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Router Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Output Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Input Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 01:30:54 --> Language Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Loader Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Controller Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Model Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Model Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Model Class Initialized
DEBUG - 2011-06-11 01:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 01:30:54 --> Database Driver Class Initialized
DEBUG - 2011-06-11 01:30:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 01:30:55 --> Helper loaded: url_helper
DEBUG - 2011-06-11 01:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 01:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 01:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 01:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 01:30:55 --> Final output sent to browser
DEBUG - 2011-06-11 01:30:55 --> Total execution time: 1.2401
DEBUG - 2011-06-11 04:43:33 --> Config Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Hooks Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Utf8 Class Initialized
DEBUG - 2011-06-11 04:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 04:43:33 --> URI Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Router Class Initialized
DEBUG - 2011-06-11 04:43:33 --> No URI present. Default controller set.
DEBUG - 2011-06-11 04:43:33 --> Output Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Input Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 04:43:33 --> Language Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Loader Class Initialized
DEBUG - 2011-06-11 04:43:33 --> Controller Class Initialized
DEBUG - 2011-06-11 04:43:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-11 04:43:33 --> Helper loaded: url_helper
DEBUG - 2011-06-11 04:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 04:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 04:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 04:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 04:43:33 --> Final output sent to browser
DEBUG - 2011-06-11 04:43:33 --> Total execution time: 0.2987
DEBUG - 2011-06-11 04:51:22 --> Config Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Hooks Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Utf8 Class Initialized
DEBUG - 2011-06-11 04:51:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 04:51:22 --> URI Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Router Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Output Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Input Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 04:51:22 --> Language Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Loader Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Controller Class Initialized
ERROR - 2011-06-11 04:51:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 04:51:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 04:51:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 04:51:22 --> Model Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Model Class Initialized
DEBUG - 2011-06-11 04:51:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 04:51:22 --> Database Driver Class Initialized
DEBUG - 2011-06-11 04:51:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 04:51:23 --> Helper loaded: url_helper
DEBUG - 2011-06-11 04:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 04:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 04:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 04:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 04:51:23 --> Final output sent to browser
DEBUG - 2011-06-11 04:51:23 --> Total execution time: 0.9082
DEBUG - 2011-06-11 04:53:00 --> Config Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Hooks Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Utf8 Class Initialized
DEBUG - 2011-06-11 04:53:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 04:53:00 --> URI Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Router Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Output Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Input Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 04:53:00 --> Language Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Loader Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Controller Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Model Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Model Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Model Class Initialized
DEBUG - 2011-06-11 04:53:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 04:53:00 --> Database Driver Class Initialized
DEBUG - 2011-06-11 04:53:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 04:53:01 --> Helper loaded: url_helper
DEBUG - 2011-06-11 04:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 04:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 04:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 04:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 04:53:01 --> Final output sent to browser
DEBUG - 2011-06-11 04:53:01 --> Total execution time: 1.1695
DEBUG - 2011-06-11 05:33:18 --> Config Class Initialized
DEBUG - 2011-06-11 05:33:18 --> Hooks Class Initialized
DEBUG - 2011-06-11 05:33:18 --> Utf8 Class Initialized
DEBUG - 2011-06-11 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 05:33:18 --> URI Class Initialized
DEBUG - 2011-06-11 05:33:18 --> Router Class Initialized
ERROR - 2011-06-11 05:33:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 05:38:52 --> Config Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Hooks Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Utf8 Class Initialized
DEBUG - 2011-06-11 05:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 05:38:52 --> URI Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Router Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Output Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Input Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 05:38:52 --> Language Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Loader Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Controller Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Model Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Model Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Model Class Initialized
DEBUG - 2011-06-11 05:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 05:38:52 --> Database Driver Class Initialized
DEBUG - 2011-06-11 05:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 05:38:53 --> Helper loaded: url_helper
DEBUG - 2011-06-11 05:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 05:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 05:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 05:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 05:38:53 --> Final output sent to browser
DEBUG - 2011-06-11 05:38:53 --> Total execution time: 1.2360
DEBUG - 2011-06-11 05:38:56 --> Config Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Hooks Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Utf8 Class Initialized
DEBUG - 2011-06-11 05:38:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 05:38:56 --> URI Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Router Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Output Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Input Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 05:38:56 --> Language Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Loader Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Controller Class Initialized
ERROR - 2011-06-11 05:38:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 05:38:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 05:38:56 --> Model Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Model Class Initialized
DEBUG - 2011-06-11 05:38:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 05:38:56 --> Database Driver Class Initialized
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 05:38:56 --> Helper loaded: url_helper
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 05:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 05:38:56 --> Final output sent to browser
DEBUG - 2011-06-11 05:38:56 --> Total execution time: 0.1060
DEBUG - 2011-06-11 06:56:01 --> Config Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:56:01 --> URI Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Router Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Output Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Input Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:56:01 --> Language Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Loader Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Controller Class Initialized
ERROR - 2011-06-11 06:56:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:56:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:56:01 --> Model Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Model Class Initialized
DEBUG - 2011-06-11 06:56:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:56:01 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:56:01 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:56:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:56:01 --> Final output sent to browser
DEBUG - 2011-06-11 06:56:01 --> Total execution time: 0.3674
DEBUG - 2011-06-11 06:56:03 --> Config Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:56:03 --> URI Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Router Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Output Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Input Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:56:03 --> Language Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Loader Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Controller Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Model Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Model Class Initialized
DEBUG - 2011-06-11 06:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:56:03 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:56:04 --> Final output sent to browser
DEBUG - 2011-06-11 06:56:04 --> Total execution time: 0.7014
DEBUG - 2011-06-11 06:56:09 --> Config Class Initialized
DEBUG - 2011-06-11 06:56:09 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:56:09 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:56:09 --> URI Class Initialized
DEBUG - 2011-06-11 06:56:09 --> Router Class Initialized
ERROR - 2011-06-11 06:56:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:57:04 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:04 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:04 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:04 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:04 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:04 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:04 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:04 --> Total execution time: 0.0369
DEBUG - 2011-06-11 06:57:05 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:05 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:05 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Controller Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:05 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:06 --> Total execution time: 0.9167
DEBUG - 2011-06-11 06:57:06 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:06 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Router Class Initialized
ERROR - 2011-06-11 06:57:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 06:57:06 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:06 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:06 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:06 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:06 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:06 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:06 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:06 --> Total execution time: 0.0263
DEBUG - 2011-06-11 06:57:08 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:08 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:08 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:08 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:08 --> Router Class Initialized
ERROR - 2011-06-11 06:57:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:57:28 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:28 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:28 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:28 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:28 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:28 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:28 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:28 --> Total execution time: 0.0506
DEBUG - 2011-06-11 06:57:29 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:29 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:29 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Controller Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:29 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:29 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:29 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:29 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:29 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:29 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:29 --> Total execution time: 0.0278
DEBUG - 2011-06-11 06:57:29 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:29 --> Total execution time: 0.5979
DEBUG - 2011-06-11 06:57:32 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:32 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:32 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:32 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:32 --> Router Class Initialized
ERROR - 2011-06-11 06:57:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:57:39 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:39 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:39 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:39 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:39 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:39 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:39 --> Total execution time: 0.0264
DEBUG - 2011-06-11 06:57:40 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:40 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:40 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Controller Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:40 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:40 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:40 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:40 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:40 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:40 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:40 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:40 --> Total execution time: 0.0507
DEBUG - 2011-06-11 06:57:40 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:40 --> Total execution time: 0.5038
DEBUG - 2011-06-11 06:57:43 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:43 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:43 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:43 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:43 --> Router Class Initialized
ERROR - 2011-06-11 06:57:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:57:55 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:55 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:55 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:55 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:55 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:55 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:55 --> Total execution time: 0.0276
DEBUG - 2011-06-11 06:57:55 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:55 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:55 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Controller Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:55 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:55 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Router Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Output Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Input Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:57:55 --> Language Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Loader Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Controller Class Initialized
ERROR - 2011-06-11 06:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Model Class Initialized
DEBUG - 2011-06-11 06:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:57:55 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:57:55 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:57:55 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:55 --> Total execution time: 0.0275
DEBUG - 2011-06-11 06:57:56 --> Final output sent to browser
DEBUG - 2011-06-11 06:57:56 --> Total execution time: 0.5610
DEBUG - 2011-06-11 06:57:59 --> Config Class Initialized
DEBUG - 2011-06-11 06:57:59 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:57:59 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:57:59 --> URI Class Initialized
DEBUG - 2011-06-11 06:57:59 --> Router Class Initialized
ERROR - 2011-06-11 06:57:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:58:13 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:13 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:13 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:13 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:13 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:13 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:13 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:13 --> Total execution time: 0.0268
DEBUG - 2011-06-11 06:58:14 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:14 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:14 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:14 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Controller Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:14 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:14 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:14 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:14 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:14 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:14 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:14 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:14 --> Total execution time: 0.0635
DEBUG - 2011-06-11 06:58:14 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:14 --> Total execution time: 0.5955
DEBUG - 2011-06-11 06:58:17 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:17 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:17 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:17 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:17 --> Router Class Initialized
ERROR - 2011-06-11 06:58:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:58:29 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:29 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:29 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:29 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:29 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:29 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:29 --> Total execution time: 0.0273
DEBUG - 2011-06-11 06:58:30 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:30 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:30 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Controller Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:30 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:30 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:30 --> Total execution time: 0.5348
DEBUG - 2011-06-11 06:58:31 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:31 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:31 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:31 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:31 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:31 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:31 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:31 --> Total execution time: 0.0749
DEBUG - 2011-06-11 06:58:32 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:32 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:32 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:32 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:32 --> Router Class Initialized
ERROR - 2011-06-11 06:58:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 06:58:38 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:38 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:38 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:38 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:38 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:39 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:39 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:39 --> Total execution time: 0.0589
DEBUG - 2011-06-11 06:58:39 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:39 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:39 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Controller Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:39 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:39 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Router Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Output Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Input Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 06:58:39 --> Language Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Loader Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Controller Class Initialized
ERROR - 2011-06-11 06:58:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 06:58:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Model Class Initialized
DEBUG - 2011-06-11 06:58:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 06:58:39 --> Database Driver Class Initialized
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 06:58:39 --> Helper loaded: url_helper
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 06:58:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 06:58:39 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:39 --> Total execution time: 0.0267
DEBUG - 2011-06-11 06:58:40 --> Final output sent to browser
DEBUG - 2011-06-11 06:58:40 --> Total execution time: 0.5072
DEBUG - 2011-06-11 06:58:42 --> Config Class Initialized
DEBUG - 2011-06-11 06:58:42 --> Hooks Class Initialized
DEBUG - 2011-06-11 06:58:42 --> Utf8 Class Initialized
DEBUG - 2011-06-11 06:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 06:58:42 --> URI Class Initialized
DEBUG - 2011-06-11 06:58:42 --> Router Class Initialized
ERROR - 2011-06-11 06:58:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 07:06:25 --> Config Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:06:25 --> URI Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Router Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Output Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Input Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 07:06:25 --> Language Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Loader Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Controller Class Initialized
ERROR - 2011-06-11 07:06:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 07:06:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 07:06:25 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 07:06:25 --> Database Driver Class Initialized
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 07:06:25 --> Helper loaded: url_helper
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 07:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 07:06:25 --> Final output sent to browser
DEBUG - 2011-06-11 07:06:25 --> Total execution time: 0.0515
DEBUG - 2011-06-11 07:06:28 --> Config Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:06:28 --> URI Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Router Class Initialized
ERROR - 2011-06-11 07:06:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 07:06:28 --> Config Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:06:28 --> URI Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Router Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Output Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Input Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 07:06:28 --> Language Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Loader Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Controller Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 07:06:28 --> Database Driver Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Final output sent to browser
DEBUG - 2011-06-11 07:06:29 --> Total execution time: 0.7376
DEBUG - 2011-06-11 07:06:29 --> Config Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:06:29 --> URI Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Router Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Output Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Input Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 07:06:29 --> Language Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Loader Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Controller Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Model Class Initialized
DEBUG - 2011-06-11 07:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 07:06:29 --> Database Driver Class Initialized
DEBUG - 2011-06-11 07:06:30 --> Final output sent to browser
DEBUG - 2011-06-11 07:06:30 --> Total execution time: 0.4907
DEBUG - 2011-06-11 07:44:14 --> Config Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:44:14 --> URI Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Router Class Initialized
ERROR - 2011-06-11 07:44:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 07:44:14 --> Config Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Hooks Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Utf8 Class Initialized
DEBUG - 2011-06-11 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 07:44:14 --> URI Class Initialized
DEBUG - 2011-06-11 07:44:14 --> Router Class Initialized
DEBUG - 2011-06-11 07:44:14 --> No URI present. Default controller set.
DEBUG - 2011-06-11 07:44:14 --> Output Class Initialized
DEBUG - 2011-06-11 07:44:15 --> Input Class Initialized
DEBUG - 2011-06-11 07:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 07:44:15 --> Language Class Initialized
DEBUG - 2011-06-11 07:44:15 --> Loader Class Initialized
DEBUG - 2011-06-11 07:44:15 --> Controller Class Initialized
DEBUG - 2011-06-11 07:44:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-11 07:44:15 --> Helper loaded: url_helper
DEBUG - 2011-06-11 07:44:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 07:44:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 07:44:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 07:44:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 07:44:15 --> Final output sent to browser
DEBUG - 2011-06-11 07:44:15 --> Total execution time: 0.2059
DEBUG - 2011-06-11 11:43:01 --> Config Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Hooks Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Utf8 Class Initialized
DEBUG - 2011-06-11 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 11:43:01 --> URI Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Router Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Output Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Input Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 11:43:01 --> Language Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Loader Class Initialized
DEBUG - 2011-06-11 11:43:01 --> Controller Class Initialized
ERROR - 2011-06-11 11:43:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 11:43:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 11:43:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 11:43:02 --> Model Class Initialized
DEBUG - 2011-06-11 11:43:02 --> Model Class Initialized
DEBUG - 2011-06-11 11:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 11:43:03 --> Database Driver Class Initialized
DEBUG - 2011-06-11 11:43:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 11:43:03 --> Helper loaded: url_helper
DEBUG - 2011-06-11 11:43:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 11:43:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 11:43:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 11:43:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 11:43:03 --> Final output sent to browser
DEBUG - 2011-06-11 11:43:03 --> Total execution time: 1.5507
DEBUG - 2011-06-11 12:02:48 --> Config Class Initialized
DEBUG - 2011-06-11 12:02:48 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:02:48 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:02:48 --> URI Class Initialized
DEBUG - 2011-06-11 12:02:48 --> Router Class Initialized
ERROR - 2011-06-11 12:02:48 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 12:02:49 --> Config Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:02:49 --> URI Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Router Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Output Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Input Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:02:49 --> Language Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Loader Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Controller Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Model Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Model Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Model Class Initialized
DEBUG - 2011-06-11 12:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:02:49 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:02:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 12:02:49 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:02:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:02:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:02:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:02:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:02:49 --> Final output sent to browser
DEBUG - 2011-06-11 12:02:49 --> Total execution time: 0.6439
DEBUG - 2011-06-11 12:03:20 --> Config Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:03:20 --> URI Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Router Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Output Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Input Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:03:20 --> Language Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Loader Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Controller Class Initialized
ERROR - 2011-06-11 12:03:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 12:03:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:03:20 --> Model Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Model Class Initialized
DEBUG - 2011-06-11 12:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:03:20 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:03:20 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:03:20 --> Final output sent to browser
DEBUG - 2011-06-11 12:03:20 --> Total execution time: 0.0759
DEBUG - 2011-06-11 12:14:53 --> Config Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:14:53 --> URI Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Router Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Output Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Input Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:14:53 --> Language Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Loader Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Controller Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Model Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Model Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Model Class Initialized
DEBUG - 2011-06-11 12:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:14:53 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 12:14:53 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:14:53 --> Final output sent to browser
DEBUG - 2011-06-11 12:14:53 --> Total execution time: 0.1483
DEBUG - 2011-06-11 12:14:58 --> Config Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:14:58 --> URI Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Router Class Initialized
ERROR - 2011-06-11 12:14:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 12:14:58 --> Config Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:14:58 --> URI Class Initialized
DEBUG - 2011-06-11 12:14:58 --> Router Class Initialized
ERROR - 2011-06-11 12:14:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 12:17:36 --> Config Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:17:36 --> URI Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Router Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Output Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Input Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:17:36 --> Language Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Loader Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Controller Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Model Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Model Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:17:36 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:17:36 --> Final output sent to browser
DEBUG - 2011-06-11 12:17:36 --> Total execution time: 0.8542
DEBUG - 2011-06-11 12:34:01 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:01 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:01 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Controller Class Initialized
ERROR - 2011-06-11 12:34:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 12:34:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:01 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:01 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:01 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:34:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:34:01 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:01 --> Total execution time: 0.1964
DEBUG - 2011-06-11 12:34:02 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:02 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:02 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Controller Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:02 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:03 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:03 --> Total execution time: 0.5565
DEBUG - 2011-06-11 12:34:03 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:03 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:03 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:03 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:03 --> Router Class Initialized
ERROR - 2011-06-11 12:34:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 12:34:35 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:35 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:35 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Controller Class Initialized
ERROR - 2011-06-11 12:34:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 12:34:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:35 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:35 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:35 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:34:35 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:35 --> Total execution time: 0.0266
DEBUG - 2011-06-11 12:34:35 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:35 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:35 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Controller Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:35 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:36 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:36 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Controller Class Initialized
ERROR - 2011-06-11 12:34:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 12:34:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:36 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:36 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:36 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:34:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:34:36 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:36 --> Total execution time: 0.0751
DEBUG - 2011-06-11 12:34:36 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:36 --> Total execution time: 0.4891
DEBUG - 2011-06-11 12:34:36 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:36 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:36 --> Router Class Initialized
ERROR - 2011-06-11 12:34:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 12:34:44 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:44 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:44 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Controller Class Initialized
ERROR - 2011-06-11 12:34:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 12:34:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:44 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:44 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 12:34:44 --> Helper loaded: url_helper
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 12:34:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 12:34:44 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:44 --> Total execution time: 0.0276
DEBUG - 2011-06-11 12:34:45 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:45 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Router Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Output Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Input Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 12:34:45 --> Language Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Loader Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Controller Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Model Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 12:34:45 --> Database Driver Class Initialized
DEBUG - 2011-06-11 12:34:45 --> Final output sent to browser
DEBUG - 2011-06-11 12:34:45 --> Total execution time: 0.5207
DEBUG - 2011-06-11 12:34:46 --> Config Class Initialized
DEBUG - 2011-06-11 12:34:46 --> Hooks Class Initialized
DEBUG - 2011-06-11 12:34:46 --> Utf8 Class Initialized
DEBUG - 2011-06-11 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 12:34:46 --> URI Class Initialized
DEBUG - 2011-06-11 12:34:46 --> Router Class Initialized
ERROR - 2011-06-11 12:34:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 13:56:39 --> Config Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Hooks Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Utf8 Class Initialized
DEBUG - 2011-06-11 13:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 13:56:39 --> URI Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Router Class Initialized
DEBUG - 2011-06-11 13:56:39 --> No URI present. Default controller set.
DEBUG - 2011-06-11 13:56:39 --> Output Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Input Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 13:56:39 --> Language Class Initialized
DEBUG - 2011-06-11 13:56:39 --> Loader Class Initialized
DEBUG - 2011-06-11 13:56:40 --> Controller Class Initialized
DEBUG - 2011-06-11 13:56:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-11 13:56:40 --> Helper loaded: url_helper
DEBUG - 2011-06-11 13:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 13:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 13:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 13:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 13:56:40 --> Final output sent to browser
DEBUG - 2011-06-11 13:56:40 --> Total execution time: 0.4434
DEBUG - 2011-06-11 14:49:52 --> Config Class Initialized
DEBUG - 2011-06-11 14:49:52 --> Hooks Class Initialized
DEBUG - 2011-06-11 14:49:52 --> Utf8 Class Initialized
DEBUG - 2011-06-11 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 14:49:52 --> URI Class Initialized
DEBUG - 2011-06-11 14:49:52 --> Router Class Initialized
ERROR - 2011-06-11 14:49:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-11 17:48:32 --> Config Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Hooks Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Utf8 Class Initialized
DEBUG - 2011-06-11 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 17:48:32 --> URI Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Router Class Initialized
ERROR - 2011-06-11 17:48:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-11 17:48:32 --> Config Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Hooks Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Utf8 Class Initialized
DEBUG - 2011-06-11 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 17:48:32 --> URI Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Router Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Output Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Input Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 17:48:32 --> Language Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Loader Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Controller Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Model Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Model Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Model Class Initialized
DEBUG - 2011-06-11 17:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 17:48:32 --> Database Driver Class Initialized
DEBUG - 2011-06-11 17:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 17:48:33 --> Helper loaded: url_helper
DEBUG - 2011-06-11 17:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 17:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 17:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 17:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 17:48:33 --> Final output sent to browser
DEBUG - 2011-06-11 17:48:33 --> Total execution time: 0.4977
DEBUG - 2011-06-11 19:33:21 --> Config Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Hooks Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Utf8 Class Initialized
DEBUG - 2011-06-11 19:33:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 19:33:21 --> URI Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Router Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Output Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Input Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 19:33:21 --> Language Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Loader Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Controller Class Initialized
ERROR - 2011-06-11 19:33:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 19:33:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 19:33:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 19:33:21 --> Model Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Model Class Initialized
DEBUG - 2011-06-11 19:33:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 19:33:22 --> Database Driver Class Initialized
DEBUG - 2011-06-11 19:33:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 19:33:22 --> Helper loaded: url_helper
DEBUG - 2011-06-11 19:33:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 19:33:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 19:33:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 19:33:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 19:33:22 --> Final output sent to browser
DEBUG - 2011-06-11 19:33:22 --> Total execution time: 0.2992
DEBUG - 2011-06-11 20:18:49 --> Config Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Hooks Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Utf8 Class Initialized
DEBUG - 2011-06-11 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 20:18:49 --> URI Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Router Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Output Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Input Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 20:18:49 --> Language Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Loader Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Controller Class Initialized
ERROR - 2011-06-11 20:18:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 20:18:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 20:18:49 --> Model Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Model Class Initialized
DEBUG - 2011-06-11 20:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 20:18:49 --> Database Driver Class Initialized
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 20:18:49 --> Helper loaded: url_helper
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 20:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 20:18:49 --> Final output sent to browser
DEBUG - 2011-06-11 20:18:49 --> Total execution time: 0.2747
DEBUG - 2011-06-11 20:40:53 --> Config Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Hooks Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Utf8 Class Initialized
DEBUG - 2011-06-11 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 20:40:53 --> URI Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Router Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Output Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Input Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 20:40:53 --> Language Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Loader Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Controller Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Model Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Model Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Model Class Initialized
DEBUG - 2011-06-11 20:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 20:40:53 --> Database Driver Class Initialized
DEBUG - 2011-06-11 20:40:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 20:40:53 --> Helper loaded: url_helper
DEBUG - 2011-06-11 20:40:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 20:40:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 20:40:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 20:40:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 20:40:53 --> Final output sent to browser
DEBUG - 2011-06-11 20:40:53 --> Total execution time: 0.4155
DEBUG - 2011-06-11 22:07:28 --> Config Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Hooks Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Utf8 Class Initialized
DEBUG - 2011-06-11 22:07:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 22:07:28 --> URI Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Router Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Output Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Input Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 22:07:28 --> Language Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Loader Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Controller Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Model Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Model Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Model Class Initialized
DEBUG - 2011-06-11 22:07:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 22:07:29 --> Database Driver Class Initialized
DEBUG - 2011-06-11 22:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-11 22:07:29 --> Helper loaded: url_helper
DEBUG - 2011-06-11 22:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 22:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 22:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 22:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 22:07:29 --> Final output sent to browser
DEBUG - 2011-06-11 22:07:29 --> Total execution time: 0.6315
DEBUG - 2011-06-11 22:07:30 --> Config Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Hooks Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Utf8 Class Initialized
DEBUG - 2011-06-11 22:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-11 22:07:30 --> URI Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Router Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Output Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Input Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-11 22:07:30 --> Language Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Loader Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Controller Class Initialized
ERROR - 2011-06-11 22:07:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-11 22:07:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 22:07:30 --> Model Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Model Class Initialized
DEBUG - 2011-06-11 22:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-11 22:07:30 --> Database Driver Class Initialized
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-11 22:07:30 --> Helper loaded: url_helper
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-11 22:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-11 22:07:30 --> Final output sent to browser
DEBUG - 2011-06-11 22:07:30 --> Total execution time: 0.0860

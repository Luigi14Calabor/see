<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-06 01:04:36 --> Config Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Hooks Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Utf8 Class Initialized
DEBUG - 2011-10-06 01:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 01:04:36 --> URI Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Router Class Initialized
DEBUG - 2011-10-06 01:04:36 --> No URI present. Default controller set.
DEBUG - 2011-10-06 01:04:36 --> Output Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Input Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 01:04:36 --> Language Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Loader Class Initialized
DEBUG - 2011-10-06 01:04:36 --> Controller Class Initialized
DEBUG - 2011-10-06 01:04:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-06 01:04:36 --> Helper loaded: url_helper
DEBUG - 2011-10-06 01:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 01:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 01:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 01:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 01:04:36 --> Final output sent to browser
DEBUG - 2011-10-06 01:04:36 --> Total execution time: 0.0516
DEBUG - 2011-10-06 03:30:58 --> Config Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:30:58 --> URI Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Router Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Output Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Input Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:30:58 --> Language Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Loader Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Controller Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Model Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Model Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Model Class Initialized
DEBUG - 2011-10-06 03:30:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:30:59 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:31:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:31:01 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:31:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:31:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:31:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:31:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:31:01 --> Final output sent to browser
DEBUG - 2011-10-06 03:31:01 --> Total execution time: 2.8465
DEBUG - 2011-10-06 03:31:17 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:17 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:17 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:17 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:17 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:17 --> Router Class Initialized
ERROR - 2011-10-06 03:31:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:18 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:18 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:18 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:18 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:18 --> Router Class Initialized
ERROR - 2011-10-06 03:31:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:19 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:19 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:19 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:19 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:19 --> Router Class Initialized
ERROR - 2011-10-06 03:31:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:24 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:24 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Router Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Output Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Input Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:31:24 --> Language Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Loader Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Controller Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:31:24 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:31:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:31:26 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:31:26 --> Final output sent to browser
DEBUG - 2011-10-06 03:31:26 --> Total execution time: 1.5068
DEBUG - 2011-10-06 03:31:30 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:30 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Router Class Initialized
ERROR - 2011-10-06 03:31:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:30 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:30 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:30 --> Router Class Initialized
ERROR - 2011-10-06 03:31:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-06 03:31:31 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:31 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Router Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Output Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Input Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:31:31 --> Language Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Loader Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Controller Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Model Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:31:31 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:31:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:31:31 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:31:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:31:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:31:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:31:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:31:31 --> Final output sent to browser
DEBUG - 2011-10-06 03:31:31 --> Total execution time: 0.0661
DEBUG - 2011-10-06 03:31:31 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:31 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:31 --> Router Class Initialized
ERROR - 2011-10-06 03:31:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:32 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:32 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:32 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:32 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:32 --> Router Class Initialized
ERROR - 2011-10-06 03:31:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:31:33 --> Config Class Initialized
DEBUG - 2011-10-06 03:31:33 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:31:33 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:31:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:31:33 --> URI Class Initialized
DEBUG - 2011-10-06 03:31:33 --> Router Class Initialized
ERROR - 2011-10-06 03:31:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:32:27 --> Config Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:32:27 --> URI Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Router Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Output Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Input Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:32:27 --> Language Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Loader Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Controller Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Model Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Model Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Model Class Initialized
DEBUG - 2011-10-06 03:32:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:32:27 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:32:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:32:27 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:32:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:32:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:32:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:32:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:32:27 --> Final output sent to browser
DEBUG - 2011-10-06 03:32:27 --> Total execution time: 0.0939
DEBUG - 2011-10-06 03:32:31 --> Config Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:32:31 --> URI Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Router Class Initialized
ERROR - 2011-10-06 03:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:32:31 --> Config Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:32:31 --> URI Class Initialized
DEBUG - 2011-10-06 03:32:31 --> Router Class Initialized
ERROR - 2011-10-06 03:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:32:32 --> Config Class Initialized
DEBUG - 2011-10-06 03:32:32 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:32:32 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:32:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:32:32 --> URI Class Initialized
DEBUG - 2011-10-06 03:32:32 --> Router Class Initialized
ERROR - 2011-10-06 03:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:33:18 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:18 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Router Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Output Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Input Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:33:18 --> Language Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Loader Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Controller Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:33:18 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:33:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:33:19 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:33:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:33:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:33:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:33:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:33:19 --> Final output sent to browser
DEBUG - 2011-10-06 03:33:19 --> Total execution time: 1.3083
DEBUG - 2011-10-06 03:33:22 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:22 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Router Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Output Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Input Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:33:22 --> Language Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Loader Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Controller Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:33:22 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:33:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:33:22 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:33:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:33:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:33:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:33:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:33:22 --> Final output sent to browser
DEBUG - 2011-10-06 03:33:22 --> Total execution time: 0.0572
DEBUG - 2011-10-06 03:33:22 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:22 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:22 --> Router Class Initialized
ERROR - 2011-10-06 03:33:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:33:23 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:23 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:23 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:23 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:23 --> Router Class Initialized
ERROR - 2011-10-06 03:33:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:33:24 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:24 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:24 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:24 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:24 --> Router Class Initialized
ERROR - 2011-10-06 03:33:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:33:35 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:35 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Router Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Output Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Input Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:33:35 --> Language Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Loader Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Controller Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:33:35 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:33:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:33:39 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:33:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:33:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:33:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:33:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:33:39 --> Final output sent to browser
DEBUG - 2011-10-06 03:33:39 --> Total execution time: 3.7325
DEBUG - 2011-10-06 03:33:40 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:40 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Router Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Output Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Input Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:33:40 --> Language Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Loader Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Controller Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Model Class Initialized
DEBUG - 2011-10-06 03:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:33:40 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:33:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:33:40 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:33:40 --> Final output sent to browser
DEBUG - 2011-10-06 03:33:40 --> Total execution time: 0.1101
DEBUG - 2011-10-06 03:33:43 --> Config Class Initialized
DEBUG - 2011-10-06 03:33:43 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:33:43 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:33:43 --> URI Class Initialized
DEBUG - 2011-10-06 03:33:43 --> Router Class Initialized
ERROR - 2011-10-06 03:33:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:04 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:04 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Router Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Output Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Input Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:35:04 --> Language Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Loader Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Controller Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:35:04 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:35:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:35:05 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:35:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:35:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:35:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:35:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:35:05 --> Final output sent to browser
DEBUG - 2011-10-06 03:35:05 --> Total execution time: 1.1768
DEBUG - 2011-10-06 03:35:08 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:08 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Router Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Output Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Input Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:35:08 --> Language Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Loader Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Controller Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:35:08 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:35:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:35:08 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:35:08 --> Final output sent to browser
DEBUG - 2011-10-06 03:35:08 --> Total execution time: 0.1502
DEBUG - 2011-10-06 03:35:10 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:10 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:10 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:10 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:10 --> Router Class Initialized
ERROR - 2011-10-06 03:35:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:11 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:11 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:11 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:11 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:11 --> Router Class Initialized
ERROR - 2011-10-06 03:35:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:12 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:12 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:12 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:12 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:12 --> Router Class Initialized
ERROR - 2011-10-06 03:35:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:48 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:48 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Router Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Output Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Input Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:35:48 --> Language Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Loader Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Controller Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:35:48 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:35:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:35:49 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:35:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:35:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:35:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:35:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:35:49 --> Final output sent to browser
DEBUG - 2011-10-06 03:35:49 --> Total execution time: 0.7390
DEBUG - 2011-10-06 03:35:54 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:54 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Router Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Output Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Input Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:35:54 --> Language Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Loader Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Controller Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Model Class Initialized
DEBUG - 2011-10-06 03:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:35:54 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:35:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:35:54 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:35:54 --> Final output sent to browser
DEBUG - 2011-10-06 03:35:54 --> Total execution time: 0.0761
DEBUG - 2011-10-06 03:35:55 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:55 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:55 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:55 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:55 --> Router Class Initialized
ERROR - 2011-10-06 03:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:56 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:56 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:56 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:56 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:56 --> Router Class Initialized
ERROR - 2011-10-06 03:35:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:35:57 --> Config Class Initialized
DEBUG - 2011-10-06 03:35:57 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:35:57 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:35:57 --> URI Class Initialized
DEBUG - 2011-10-06 03:35:57 --> Router Class Initialized
ERROR - 2011-10-06 03:35:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:37:19 --> Config Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:37:19 --> URI Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Router Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Output Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Input Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:37:19 --> Language Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Loader Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Controller Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:37:19 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:37:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:37:22 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:37:22 --> Final output sent to browser
DEBUG - 2011-10-06 03:37:22 --> Total execution time: 3.6863
DEBUG - 2011-10-06 03:37:26 --> Config Class Initialized
DEBUG - 2011-10-06 03:37:26 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:37:26 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:37:26 --> URI Class Initialized
DEBUG - 2011-10-06 03:37:26 --> Router Class Initialized
ERROR - 2011-10-06 03:37:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:37:28 --> Config Class Initialized
DEBUG - 2011-10-06 03:37:28 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:37:28 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:37:28 --> URI Class Initialized
DEBUG - 2011-10-06 03:37:28 --> Router Class Initialized
ERROR - 2011-10-06 03:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:37:31 --> Config Class Initialized
DEBUG - 2011-10-06 03:37:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:37:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:37:31 --> URI Class Initialized
DEBUG - 2011-10-06 03:37:31 --> Router Class Initialized
ERROR - 2011-10-06 03:37:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:37:39 --> Config Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:37:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:37:39 --> URI Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Router Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Output Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Input Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:37:39 --> Language Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Loader Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Controller Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Model Class Initialized
DEBUG - 2011-10-06 03:37:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:37:39 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:37:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:37:39 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:37:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:37:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:37:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:37:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:37:39 --> Final output sent to browser
DEBUG - 2011-10-06 03:37:39 --> Total execution time: 0.0715
DEBUG - 2011-10-06 03:38:03 --> Config Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:38:03 --> URI Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Router Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Output Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Input Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:38:03 --> Language Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Loader Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Controller Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:38:03 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:38:04 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:38:04 --> Final output sent to browser
DEBUG - 2011-10-06 03:38:04 --> Total execution time: 1.6229
DEBUG - 2011-10-06 03:38:08 --> Config Class Initialized
DEBUG - 2011-10-06 03:38:08 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:38:08 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:38:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:38:08 --> URI Class Initialized
DEBUG - 2011-10-06 03:38:08 --> Router Class Initialized
ERROR - 2011-10-06 03:38:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:38:11 --> Config Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:38:11 --> URI Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Router Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Output Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Input Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 03:38:11 --> Language Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Loader Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Controller Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Model Class Initialized
DEBUG - 2011-10-06 03:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 03:38:11 --> Database Driver Class Initialized
DEBUG - 2011-10-06 03:38:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 03:38:11 --> Helper loaded: url_helper
DEBUG - 2011-10-06 03:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 03:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 03:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 03:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 03:38:11 --> Final output sent to browser
DEBUG - 2011-10-06 03:38:11 --> Total execution time: 0.0661
DEBUG - 2011-10-06 03:38:13 --> Config Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:38:13 --> URI Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Router Class Initialized
ERROR - 2011-10-06 03:38:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 03:38:13 --> Config Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Hooks Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Utf8 Class Initialized
DEBUG - 2011-10-06 03:38:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 03:38:13 --> URI Class Initialized
DEBUG - 2011-10-06 03:38:13 --> Router Class Initialized
ERROR - 2011-10-06 03:38:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 05:33:31 --> Config Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 05:33:31 --> URI Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Router Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Output Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Input Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 05:33:31 --> Language Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Loader Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Controller Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Model Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Model Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Model Class Initialized
DEBUG - 2011-10-06 05:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 05:33:31 --> Database Driver Class Initialized
DEBUG - 2011-10-06 05:33:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 05:33:32 --> Helper loaded: url_helper
DEBUG - 2011-10-06 05:33:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 05:33:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 05:33:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 05:33:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 05:33:32 --> Final output sent to browser
DEBUG - 2011-10-06 05:33:32 --> Total execution time: 1.6395
DEBUG - 2011-10-06 05:33:34 --> Config Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Hooks Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Utf8 Class Initialized
DEBUG - 2011-10-06 05:33:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 05:33:34 --> URI Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Router Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Output Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Input Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 05:33:34 --> Language Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Loader Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Controller Class Initialized
ERROR - 2011-10-06 05:33:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 05:33:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 05:33:34 --> Model Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Model Class Initialized
DEBUG - 2011-10-06 05:33:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 05:33:34 --> Database Driver Class Initialized
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 05:33:34 --> Helper loaded: url_helper
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 05:33:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 05:33:34 --> Final output sent to browser
DEBUG - 2011-10-06 05:33:34 --> Total execution time: 0.0890
DEBUG - 2011-10-06 07:18:28 --> Config Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Hooks Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Utf8 Class Initialized
DEBUG - 2011-10-06 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 07:18:28 --> URI Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Router Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Output Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Input Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 07:18:28 --> Language Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Loader Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Controller Class Initialized
ERROR - 2011-10-06 07:18:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 07:18:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 07:18:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 07:18:28 --> Model Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Model Class Initialized
DEBUG - 2011-10-06 07:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 07:18:28 --> Database Driver Class Initialized
DEBUG - 2011-10-06 07:18:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 07:18:29 --> Helper loaded: url_helper
DEBUG - 2011-10-06 07:18:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 07:18:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 07:18:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 07:18:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 07:18:29 --> Final output sent to browser
DEBUG - 2011-10-06 07:18:29 --> Total execution time: 1.3179
DEBUG - 2011-10-06 08:11:46 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:46 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:47 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Router Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Output Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Input Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:11:47 --> Language Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Loader Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Controller Class Initialized
ERROR - 2011-10-06 08:11:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:11:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:11:47 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:11:47 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:11:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:11:48 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:11:48 --> Final output sent to browser
DEBUG - 2011-10-06 08:11:48 --> Total execution time: 2.7359
DEBUG - 2011-10-06 08:11:48 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:48 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Router Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Output Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Input Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:11:48 --> Language Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Loader Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Controller Class Initialized
ERROR - 2011-10-06 08:11:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:11:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:11:48 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:11:48 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:11:48 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:11:48 --> Final output sent to browser
DEBUG - 2011-10-06 08:11:48 --> Total execution time: 0.0365
DEBUG - 2011-10-06 08:11:49 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:49 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Router Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Output Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Input Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:11:49 --> Language Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Loader Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Controller Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Model Class Initialized
DEBUG - 2011-10-06 08:11:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:11:49 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Final output sent to browser
DEBUG - 2011-10-06 08:11:50 --> Total execution time: 0.9169
DEBUG - 2011-10-06 08:11:50 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:50 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Router Class Initialized
ERROR - 2011-10-06 08:11:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:11:50 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:50 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:50 --> Router Class Initialized
ERROR - 2011-10-06 08:11:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:11:51 --> Config Class Initialized
DEBUG - 2011-10-06 08:11:51 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:11:51 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:11:51 --> URI Class Initialized
DEBUG - 2011-10-06 08:11:51 --> Router Class Initialized
ERROR - 2011-10-06 08:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:12:04 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:04 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:04 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Controller Class Initialized
ERROR - 2011-10-06 08:12:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:12:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:04 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:04 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:12:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:12:04 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:04 --> Total execution time: 0.0837
DEBUG - 2011-10-06 08:12:04 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:04 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:04 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Controller Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:04 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:05 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:05 --> Total execution time: 0.5990
DEBUG - 2011-10-06 08:12:12 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:12 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:12 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Controller Class Initialized
ERROR - 2011-10-06 08:12:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:12:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:12 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:12 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:12 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:12:12 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:12 --> Total execution time: 0.0336
DEBUG - 2011-10-06 08:12:13 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:13 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:13 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Controller Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:13 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:13 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:13 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:13 --> Total execution time: 0.6552
DEBUG - 2011-10-06 08:12:13 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Controller Class Initialized
ERROR - 2011-10-06 08:12:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:12:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:13 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:13 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:12:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:12:13 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:13 --> Total execution time: 0.0723
DEBUG - 2011-10-06 08:12:21 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:21 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:21 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Controller Class Initialized
ERROR - 2011-10-06 08:12:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 08:12:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:21 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:21 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 08:12:21 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:12:21 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:21 --> Total execution time: 0.0320
DEBUG - 2011-10-06 08:12:21 --> Config Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:12:21 --> URI Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Router Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Output Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Input Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:12:21 --> Language Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Loader Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Controller Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Model Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:12:21 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:12:21 --> Final output sent to browser
DEBUG - 2011-10-06 08:12:21 --> Total execution time: 0.4701
DEBUG - 2011-10-06 08:51:59 --> Config Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:51:59 --> URI Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Router Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Output Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Input Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:51:59 --> Language Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Loader Class Initialized
DEBUG - 2011-10-06 08:51:59 --> Controller Class Initialized
DEBUG - 2011-10-06 08:52:00 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:00 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:00 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:52:00 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:52:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:52:01 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:52:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:52:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:52:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:52:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:52:01 --> Final output sent to browser
DEBUG - 2011-10-06 08:52:01 --> Total execution time: 1.4192
DEBUG - 2011-10-06 08:52:03 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:03 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:03 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:03 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:03 --> Router Class Initialized
ERROR - 2011-10-06 08:52:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:52:05 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:05 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:05 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:05 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:05 --> Router Class Initialized
ERROR - 2011-10-06 08:52:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:52:37 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:37 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Router Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Output Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Input Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:52:37 --> Language Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Loader Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Controller Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:52:37 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:52:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:52:38 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:52:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:52:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:52:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:52:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:52:38 --> Final output sent to browser
DEBUG - 2011-10-06 08:52:38 --> Total execution time: 0.5032
DEBUG - 2011-10-06 08:52:39 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:39 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:39 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:39 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:39 --> Router Class Initialized
ERROR - 2011-10-06 08:52:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:52:46 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:46 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Router Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Output Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Input Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:52:46 --> Language Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Loader Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Controller Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:52:46 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:52:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:52:47 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:52:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:52:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:52:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:52:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:52:47 --> Final output sent to browser
DEBUG - 2011-10-06 08:52:47 --> Total execution time: 0.2444
DEBUG - 2011-10-06 08:52:48 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:48 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:48 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:48 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:48 --> Router Class Initialized
ERROR - 2011-10-06 08:52:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:52:52 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:52 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Router Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Output Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Input Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:52:52 --> Language Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Loader Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Controller Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:52:52 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:52:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:52:53 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:52:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:52:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:52:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:52:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:52:53 --> Final output sent to browser
DEBUG - 2011-10-06 08:52:53 --> Total execution time: 1.0875
DEBUG - 2011-10-06 08:52:54 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:54 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Router Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Output Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Input Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:52:54 --> Language Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Loader Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Controller Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Model Class Initialized
DEBUG - 2011-10-06 08:52:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:52:54 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:52:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:52:54 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:52:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:52:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:52:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:52:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:52:54 --> Final output sent to browser
DEBUG - 2011-10-06 08:52:54 --> Total execution time: 0.0475
DEBUG - 2011-10-06 08:52:55 --> Config Class Initialized
DEBUG - 2011-10-06 08:52:55 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:52:55 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:52:55 --> URI Class Initialized
DEBUG - 2011-10-06 08:52:55 --> Router Class Initialized
ERROR - 2011-10-06 08:52:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:02 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:02 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:02 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:02 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:02 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:02 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:02 --> Total execution time: 0.2531
DEBUG - 2011-10-06 08:53:03 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:03 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:03 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:03 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:03 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:03 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:03 --> Total execution time: 0.0510
DEBUG - 2011-10-06 08:53:04 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:04 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:04 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:04 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:04 --> Router Class Initialized
ERROR - 2011-10-06 08:53:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:11 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:11 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:11 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:11 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:12 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:12 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:12 --> Total execution time: 0.7759
DEBUG - 2011-10-06 08:53:13 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:13 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:13 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:13 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:13 --> Router Class Initialized
ERROR - 2011-10-06 08:53:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:20 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:20 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:20 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:20 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:20 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:20 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:20 --> Total execution time: 0.0796
DEBUG - 2011-10-06 08:53:21 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:21 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:21 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:21 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:21 --> Router Class Initialized
ERROR - 2011-10-06 08:53:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:29 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:29 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:29 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:29 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:30 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:30 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:30 --> Total execution time: 1.4243
DEBUG - 2011-10-06 08:53:31 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:31 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:31 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:31 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:31 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:31 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:31 --> Total execution time: 0.0727
DEBUG - 2011-10-06 08:53:32 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:32 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:32 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:32 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:32 --> Router Class Initialized
ERROR - 2011-10-06 08:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:41 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:41 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:41 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:41 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:43 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:43 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:43 --> Total execution time: 1.9618
DEBUG - 2011-10-06 08:53:45 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:45 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:45 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:45 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:45 --> Router Class Initialized
ERROR - 2011-10-06 08:53:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 08:53:50 --> Config Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Hooks Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Utf8 Class Initialized
DEBUG - 2011-10-06 08:53:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 08:53:50 --> URI Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Router Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Output Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Input Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 08:53:50 --> Language Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Loader Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Controller Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Model Class Initialized
DEBUG - 2011-10-06 08:53:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 08:53:50 --> Database Driver Class Initialized
DEBUG - 2011-10-06 08:53:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 08:53:50 --> Helper loaded: url_helper
DEBUG - 2011-10-06 08:53:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 08:53:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 08:53:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 08:53:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 08:53:50 --> Final output sent to browser
DEBUG - 2011-10-06 08:53:50 --> Total execution time: 0.0854
DEBUG - 2011-10-06 09:28:59 --> Config Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Hooks Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Utf8 Class Initialized
DEBUG - 2011-10-06 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 09:28:59 --> URI Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Router Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Output Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Input Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 09:28:59 --> Language Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Loader Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Controller Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Model Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Model Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Model Class Initialized
DEBUG - 2011-10-06 09:28:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 09:28:59 --> Database Driver Class Initialized
DEBUG - 2011-10-06 09:29:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 09:29:00 --> Helper loaded: url_helper
DEBUG - 2011-10-06 09:29:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 09:29:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 09:29:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 09:29:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 09:29:00 --> Final output sent to browser
DEBUG - 2011-10-06 09:29:00 --> Total execution time: 1.3062
DEBUG - 2011-10-06 09:29:02 --> Config Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Hooks Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Utf8 Class Initialized
DEBUG - 2011-10-06 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 09:29:02 --> URI Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Router Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Output Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Input Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 09:29:02 --> Language Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Loader Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Controller Class Initialized
ERROR - 2011-10-06 09:29:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 09:29:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 09:29:02 --> Model Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Model Class Initialized
DEBUG - 2011-10-06 09:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 09:29:02 --> Database Driver Class Initialized
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 09:29:02 --> Helper loaded: url_helper
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 09:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 09:29:02 --> Final output sent to browser
DEBUG - 2011-10-06 09:29:02 --> Total execution time: 0.1862
DEBUG - 2011-10-06 11:13:24 --> Config Class Initialized
DEBUG - 2011-10-06 11:13:24 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:13:24 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:13:24 --> URI Class Initialized
DEBUG - 2011-10-06 11:13:24 --> Router Class Initialized
ERROR - 2011-10-06 11:13:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-06 11:13:25 --> Config Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:13:25 --> URI Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Router Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Output Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Input Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 11:13:25 --> Language Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Loader Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Controller Class Initialized
ERROR - 2011-10-06 11:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 11:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 11:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:13:25 --> Model Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Model Class Initialized
DEBUG - 2011-10-06 11:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 11:13:25 --> Database Driver Class Initialized
DEBUG - 2011-10-06 11:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:13:26 --> Helper loaded: url_helper
DEBUG - 2011-10-06 11:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 11:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 11:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 11:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 11:13:26 --> Final output sent to browser
DEBUG - 2011-10-06 11:13:26 --> Total execution time: 1.6333
DEBUG - 2011-10-06 11:55:52 --> Config Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:55:52 --> URI Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Router Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Output Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Input Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 11:55:52 --> Language Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Loader Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Controller Class Initialized
ERROR - 2011-10-06 11:55:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 11:55:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Model Class Initialized
DEBUG - 2011-10-06 11:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 11:55:52 --> Database Driver Class Initialized
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:55:52 --> Helper loaded: url_helper
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 11:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 11:55:52 --> Final output sent to browser
DEBUG - 2011-10-06 11:55:52 --> Total execution time: 0.3153
DEBUG - 2011-10-06 11:55:53 --> Config Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:55:53 --> URI Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Router Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Output Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Input Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 11:55:53 --> Language Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Loader Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Controller Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Model Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Model Class Initialized
DEBUG - 2011-10-06 11:55:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 11:55:53 --> Database Driver Class Initialized
DEBUG - 2011-10-06 11:55:54 --> Final output sent to browser
DEBUG - 2011-10-06 11:55:54 --> Total execution time: 0.9050
DEBUG - 2011-10-06 11:55:56 --> Config Class Initialized
DEBUG - 2011-10-06 11:55:56 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:55:56 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:55:56 --> URI Class Initialized
DEBUG - 2011-10-06 11:55:56 --> Router Class Initialized
ERROR - 2011-10-06 11:55:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 11:55:57 --> Config Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:55:57 --> URI Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Router Class Initialized
ERROR - 2011-10-06 11:55:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 11:55:57 --> Config Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:55:57 --> URI Class Initialized
DEBUG - 2011-10-06 11:55:57 --> Router Class Initialized
ERROR - 2011-10-06 11:55:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 11:56:02 --> Config Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:56:02 --> URI Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Router Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Output Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Input Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 11:56:02 --> Language Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Loader Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Controller Class Initialized
ERROR - 2011-10-06 11:56:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 11:56:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:56:02 --> Model Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Model Class Initialized
DEBUG - 2011-10-06 11:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 11:56:02 --> Database Driver Class Initialized
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 11:56:02 --> Helper loaded: url_helper
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 11:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 11:56:02 --> Final output sent to browser
DEBUG - 2011-10-06 11:56:02 --> Total execution time: 0.0360
DEBUG - 2011-10-06 11:56:03 --> Config Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Hooks Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Utf8 Class Initialized
DEBUG - 2011-10-06 11:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 11:56:03 --> URI Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Router Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Output Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Input Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 11:56:03 --> Language Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Loader Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Controller Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Model Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Model Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 11:56:03 --> Database Driver Class Initialized
DEBUG - 2011-10-06 11:56:03 --> Final output sent to browser
DEBUG - 2011-10-06 11:56:03 --> Total execution time: 0.7065
DEBUG - 2011-10-06 12:00:01 --> Config Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:00:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:00:01 --> URI Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Router Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Output Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Input Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 12:00:01 --> Language Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Loader Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Controller Class Initialized
ERROR - 2011-10-06 12:00:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 12:00:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 12:00:01 --> Model Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Model Class Initialized
DEBUG - 2011-10-06 12:00:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 12:00:01 --> Database Driver Class Initialized
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 12:00:01 --> Helper loaded: url_helper
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 12:00:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 12:00:01 --> Final output sent to browser
DEBUG - 2011-10-06 12:00:01 --> Total execution time: 0.0553
DEBUG - 2011-10-06 12:00:03 --> Config Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:00:03 --> URI Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Router Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Output Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Input Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 12:00:03 --> Language Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Loader Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Controller Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Model Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Model Class Initialized
DEBUG - 2011-10-06 12:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 12:00:03 --> Database Driver Class Initialized
DEBUG - 2011-10-06 12:00:04 --> Final output sent to browser
DEBUG - 2011-10-06 12:00:04 --> Total execution time: 1.0089
DEBUG - 2011-10-06 12:10:20 --> Config Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:10:20 --> URI Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Router Class Initialized
DEBUG - 2011-10-06 12:10:20 --> No URI present. Default controller set.
DEBUG - 2011-10-06 12:10:20 --> Output Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Input Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 12:10:20 --> Language Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Loader Class Initialized
DEBUG - 2011-10-06 12:10:20 --> Controller Class Initialized
DEBUG - 2011-10-06 12:10:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-06 12:10:20 --> Helper loaded: url_helper
DEBUG - 2011-10-06 12:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 12:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 12:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 12:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 12:10:20 --> Final output sent to browser
DEBUG - 2011-10-06 12:10:20 --> Total execution time: 0.0693
DEBUG - 2011-10-06 12:23:37 --> Config Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:23:37 --> URI Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Router Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Output Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Input Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 12:23:37 --> Language Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Loader Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Controller Class Initialized
ERROR - 2011-10-06 12:23:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 12:23:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 12:23:37 --> Model Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Model Class Initialized
DEBUG - 2011-10-06 12:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 12:23:37 --> Database Driver Class Initialized
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 12:23:37 --> Helper loaded: url_helper
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 12:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 12:23:37 --> Final output sent to browser
DEBUG - 2011-10-06 12:23:37 --> Total execution time: 0.0431
DEBUG - 2011-10-06 12:23:39 --> Config Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:23:39 --> URI Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Router Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Output Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Input Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 12:23:39 --> Language Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Loader Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Controller Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Model Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Model Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 12:23:39 --> Database Driver Class Initialized
DEBUG - 2011-10-06 12:23:39 --> Final output sent to browser
DEBUG - 2011-10-06 12:23:39 --> Total execution time: 0.5161
DEBUG - 2011-10-06 12:23:41 --> Config Class Initialized
DEBUG - 2011-10-06 12:23:41 --> Hooks Class Initialized
DEBUG - 2011-10-06 12:23:41 --> Utf8 Class Initialized
DEBUG - 2011-10-06 12:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 12:23:41 --> URI Class Initialized
DEBUG - 2011-10-06 12:23:41 --> Router Class Initialized
ERROR - 2011-10-06 12:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 15:16:08 --> Config Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Hooks Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Utf8 Class Initialized
DEBUG - 2011-10-06 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 15:16:09 --> URI Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Router Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Output Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Input Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 15:16:09 --> Language Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Loader Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Controller Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Model Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Model Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Model Class Initialized
DEBUG - 2011-10-06 15:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 15:16:09 --> Database Driver Class Initialized
DEBUG - 2011-10-06 15:16:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 15:16:10 --> Helper loaded: url_helper
DEBUG - 2011-10-06 15:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 15:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 15:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 15:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 15:16:10 --> Final output sent to browser
DEBUG - 2011-10-06 15:16:10 --> Total execution time: 1.5862
DEBUG - 2011-10-06 15:16:50 --> Config Class Initialized
DEBUG - 2011-10-06 15:16:50 --> Hooks Class Initialized
DEBUG - 2011-10-06 15:16:50 --> Utf8 Class Initialized
DEBUG - 2011-10-06 15:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 15:16:50 --> URI Class Initialized
DEBUG - 2011-10-06 15:16:50 --> Router Class Initialized
ERROR - 2011-10-06 15:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 15:21:32 --> Config Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Hooks Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Utf8 Class Initialized
DEBUG - 2011-10-06 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 15:21:32 --> URI Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Router Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Output Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Input Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 15:21:32 --> Language Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Loader Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Controller Class Initialized
ERROR - 2011-10-06 15:21:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 15:21:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 15:21:32 --> Model Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Model Class Initialized
DEBUG - 2011-10-06 15:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 15:21:32 --> Database Driver Class Initialized
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 15:21:32 --> Helper loaded: url_helper
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 15:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 15:21:32 --> Final output sent to browser
DEBUG - 2011-10-06 15:21:32 --> Total execution time: 0.0787
DEBUG - 2011-10-06 15:21:33 --> Config Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Hooks Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Utf8 Class Initialized
DEBUG - 2011-10-06 15:21:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 15:21:33 --> URI Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Router Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Output Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Input Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 15:21:33 --> Language Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Loader Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Controller Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Model Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Model Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 15:21:33 --> Database Driver Class Initialized
DEBUG - 2011-10-06 15:21:33 --> Final output sent to browser
DEBUG - 2011-10-06 15:21:33 --> Total execution time: 0.5858
DEBUG - 2011-10-06 15:21:36 --> Config Class Initialized
DEBUG - 2011-10-06 15:21:36 --> Hooks Class Initialized
DEBUG - 2011-10-06 15:21:36 --> Utf8 Class Initialized
DEBUG - 2011-10-06 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 15:21:36 --> URI Class Initialized
DEBUG - 2011-10-06 15:21:36 --> Router Class Initialized
ERROR - 2011-10-06 15:21:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-06 17:01:07 --> Config Class Initialized
DEBUG - 2011-10-06 17:01:07 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:01:07 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:01:07 --> URI Class Initialized
DEBUG - 2011-10-06 17:01:07 --> Router Class Initialized
ERROR - 2011-10-06 17:01:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-06 17:01:09 --> Config Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:01:09 --> URI Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Router Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Output Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Input Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 17:01:09 --> Language Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Loader Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Controller Class Initialized
ERROR - 2011-10-06 17:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 17:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 17:01:09 --> Model Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Model Class Initialized
DEBUG - 2011-10-06 17:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 17:01:09 --> Database Driver Class Initialized
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 17:01:09 --> Helper loaded: url_helper
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 17:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 17:01:09 --> Final output sent to browser
DEBUG - 2011-10-06 17:01:09 --> Total execution time: 0.0319
DEBUG - 2011-10-06 17:01:11 --> Config Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:01:11 --> URI Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Router Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Output Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Input Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 17:01:11 --> Language Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Loader Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Controller Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Model Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Model Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Model Class Initialized
DEBUG - 2011-10-06 17:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 17:01:11 --> Database Driver Class Initialized
DEBUG - 2011-10-06 17:01:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 17:01:12 --> Helper loaded: url_helper
DEBUG - 2011-10-06 17:01:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 17:01:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 17:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 17:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 17:01:12 --> Final output sent to browser
DEBUG - 2011-10-06 17:01:12 --> Total execution time: 0.8086
DEBUG - 2011-10-06 17:22:33 --> Config Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:22:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:22:33 --> URI Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Router Class Initialized
DEBUG - 2011-10-06 17:22:33 --> No URI present. Default controller set.
DEBUG - 2011-10-06 17:22:33 --> Output Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Input Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 17:22:33 --> Language Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Loader Class Initialized
DEBUG - 2011-10-06 17:22:33 --> Controller Class Initialized
DEBUG - 2011-10-06 17:22:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-06 17:22:33 --> Helper loaded: url_helper
DEBUG - 2011-10-06 17:22:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 17:22:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 17:22:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 17:22:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 17:22:33 --> Final output sent to browser
DEBUG - 2011-10-06 17:22:33 --> Total execution time: 0.0466
DEBUG - 2011-10-06 17:30:56 --> Config Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:30:56 --> URI Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Router Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Output Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Input Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 17:30:56 --> Language Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Loader Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Controller Class Initialized
ERROR - 2011-10-06 17:30:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 17:30:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 17:30:56 --> Model Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Model Class Initialized
DEBUG - 2011-10-06 17:30:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 17:30:56 --> Database Driver Class Initialized
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 17:30:56 --> Helper loaded: url_helper
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 17:30:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 17:30:56 --> Final output sent to browser
DEBUG - 2011-10-06 17:30:56 --> Total execution time: 0.0578
DEBUG - 2011-10-06 17:32:42 --> Config Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Hooks Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Utf8 Class Initialized
DEBUG - 2011-10-06 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 17:32:42 --> URI Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Router Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Output Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Input Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 17:32:42 --> Language Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Loader Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Controller Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Model Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Model Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Model Class Initialized
DEBUG - 2011-10-06 17:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 17:32:42 --> Database Driver Class Initialized
DEBUG - 2011-10-06 17:32:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 17:32:42 --> Helper loaded: url_helper
DEBUG - 2011-10-06 17:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 17:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 17:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 17:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 17:32:42 --> Final output sent to browser
DEBUG - 2011-10-06 17:32:42 --> Total execution time: 0.7325
DEBUG - 2011-10-06 18:08:57 --> Config Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Hooks Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Utf8 Class Initialized
DEBUG - 2011-10-06 18:08:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 18:08:57 --> URI Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Router Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Output Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Input Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 18:08:57 --> Language Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Loader Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Controller Class Initialized
ERROR - 2011-10-06 18:08:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 18:08:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 18:08:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 18:08:57 --> Model Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Model Class Initialized
DEBUG - 2011-10-06 18:08:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 18:08:57 --> Database Driver Class Initialized
DEBUG - 2011-10-06 18:08:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 18:08:59 --> Helper loaded: url_helper
DEBUG - 2011-10-06 18:08:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 18:08:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 18:08:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 18:08:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 18:08:59 --> Final output sent to browser
DEBUG - 2011-10-06 18:08:59 --> Total execution time: 1.4490
DEBUG - 2011-10-06 18:49:34 --> Config Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Hooks Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Utf8 Class Initialized
DEBUG - 2011-10-06 18:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 18:49:34 --> URI Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Router Class Initialized
ERROR - 2011-10-06 18:49:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-06 18:49:34 --> Config Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Hooks Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Utf8 Class Initialized
DEBUG - 2011-10-06 18:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 18:49:34 --> URI Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Router Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Output Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Input Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 18:49:34 --> Language Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Loader Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Controller Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Model Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Model Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Model Class Initialized
DEBUG - 2011-10-06 18:49:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 18:49:34 --> Database Driver Class Initialized
DEBUG - 2011-10-06 18:49:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 18:49:35 --> Helper loaded: url_helper
DEBUG - 2011-10-06 18:49:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 18:49:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 18:49:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 18:49:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 18:49:35 --> Final output sent to browser
DEBUG - 2011-10-06 18:49:35 --> Total execution time: 0.5193
DEBUG - 2011-10-06 19:10:21 --> Config Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Hooks Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Utf8 Class Initialized
DEBUG - 2011-10-06 19:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 19:10:21 --> URI Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Router Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Output Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Input Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 19:10:21 --> Language Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Loader Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Controller Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Model Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Model Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Model Class Initialized
DEBUG - 2011-10-06 19:10:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 19:10:21 --> Database Driver Class Initialized
DEBUG - 2011-10-06 19:10:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 19:10:21 --> Helper loaded: url_helper
DEBUG - 2011-10-06 19:10:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 19:10:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 19:10:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 19:10:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 19:10:21 --> Final output sent to browser
DEBUG - 2011-10-06 19:10:21 --> Total execution time: 0.8103
DEBUG - 2011-10-06 19:10:23 --> Config Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Hooks Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Utf8 Class Initialized
DEBUG - 2011-10-06 19:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 19:10:23 --> URI Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Router Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Output Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Input Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 19:10:23 --> Language Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Loader Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Controller Class Initialized
ERROR - 2011-10-06 19:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 19:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 19:10:23 --> Model Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Model Class Initialized
DEBUG - 2011-10-06 19:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 19:10:23 --> Database Driver Class Initialized
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 19:10:23 --> Helper loaded: url_helper
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 19:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 19:10:23 --> Final output sent to browser
DEBUG - 2011-10-06 19:10:23 --> Total execution time: 0.0324
DEBUG - 2011-10-06 19:40:22 --> Config Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Hooks Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Utf8 Class Initialized
DEBUG - 2011-10-06 19:40:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 19:40:22 --> URI Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Router Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Output Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Input Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 19:40:22 --> Language Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Loader Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Controller Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Model Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Model Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Model Class Initialized
DEBUG - 2011-10-06 19:40:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 19:40:22 --> Database Driver Class Initialized
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-06 19:40:23 --> Helper loaded: url_helper
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 19:40:23 --> Final output sent to browser
DEBUG - 2011-10-06 19:40:23 --> Total execution time: 0.4506
DEBUG - 2011-10-06 19:40:23 --> Config Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Hooks Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Utf8 Class Initialized
DEBUG - 2011-10-06 19:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 19:40:23 --> URI Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Router Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Output Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Input Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-06 19:40:23 --> Language Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Loader Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Controller Class Initialized
ERROR - 2011-10-06 19:40:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-06 19:40:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 19:40:23 --> Model Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Model Class Initialized
DEBUG - 2011-10-06 19:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-06 19:40:23 --> Database Driver Class Initialized
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-06 19:40:23 --> Helper loaded: url_helper
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-06 19:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-06 19:40:23 --> Final output sent to browser
DEBUG - 2011-10-06 19:40:23 --> Total execution time: 0.0341
DEBUG - 2011-10-06 19:58:10 --> Config Class Initialized
DEBUG - 2011-10-06 19:58:10 --> Hooks Class Initialized
DEBUG - 2011-10-06 19:58:10 --> Utf8 Class Initialized
DEBUG - 2011-10-06 19:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-06 19:58:10 --> URI Class Initialized
DEBUG - 2011-10-06 19:58:10 --> Router Class Initialized
ERROR - 2011-10-06 19:58:10 --> 404 Page Not Found --> robots.txt

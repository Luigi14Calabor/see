<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-07 01:16:30 --> Config Class Initialized
DEBUG - 2011-06-07 01:16:30 --> Hooks Class Initialized
DEBUG - 2011-06-07 01:16:30 --> Utf8 Class Initialized
DEBUG - 2011-06-07 01:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 01:16:30 --> URI Class Initialized
DEBUG - 2011-06-07 01:16:30 --> Router Class Initialized
ERROR - 2011-06-07 01:16:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 01:16:31 --> Config Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Hooks Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Utf8 Class Initialized
DEBUG - 2011-06-07 01:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 01:16:31 --> URI Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Router Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Output Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Input Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 01:16:31 --> Language Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Loader Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Controller Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Model Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Model Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Model Class Initialized
DEBUG - 2011-06-07 01:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 01:16:31 --> Database Driver Class Initialized
DEBUG - 2011-06-07 01:16:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 01:16:31 --> Helper loaded: url_helper
DEBUG - 2011-06-07 01:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 01:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 01:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 01:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 01:16:31 --> Final output sent to browser
DEBUG - 2011-06-07 01:16:31 --> Total execution time: 0.8434
DEBUG - 2011-06-07 01:17:02 --> Config Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Hooks Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Utf8 Class Initialized
DEBUG - 2011-06-07 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 01:17:02 --> URI Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Router Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Output Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Input Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 01:17:02 --> Language Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Loader Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Controller Class Initialized
ERROR - 2011-06-07 01:17:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 01:17:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 01:17:02 --> Model Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Model Class Initialized
DEBUG - 2011-06-07 01:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 01:17:02 --> Database Driver Class Initialized
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 01:17:02 --> Helper loaded: url_helper
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 01:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 01:17:02 --> Final output sent to browser
DEBUG - 2011-06-07 01:17:02 --> Total execution time: 0.1054
DEBUG - 2011-06-07 02:31:36 --> Config Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 02:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 02:31:36 --> URI Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Router Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Output Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Input Class Initialized
DEBUG - 2011-06-07 02:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 02:31:37 --> Language Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Loader Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Controller Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Model Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Model Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Model Class Initialized
DEBUG - 2011-06-07 02:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 02:31:37 --> Database Driver Class Initialized
DEBUG - 2011-06-07 02:32:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 02:32:06 --> Helper loaded: url_helper
DEBUG - 2011-06-07 02:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 02:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 02:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 02:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 02:32:06 --> Final output sent to browser
DEBUG - 2011-06-07 02:32:06 --> Total execution time: 30.1845
DEBUG - 2011-06-07 02:32:07 --> Config Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Hooks Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Utf8 Class Initialized
DEBUG - 2011-06-07 02:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 02:32:07 --> URI Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Router Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Output Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Input Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 02:32:07 --> Language Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Loader Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Controller Class Initialized
ERROR - 2011-06-07 02:32:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 02:32:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 02:32:07 --> Model Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Model Class Initialized
DEBUG - 2011-06-07 02:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 02:32:07 --> Database Driver Class Initialized
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 02:32:07 --> Helper loaded: url_helper
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 02:32:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 02:32:07 --> Final output sent to browser
DEBUG - 2011-06-07 02:32:07 --> Total execution time: 0.1475
DEBUG - 2011-06-07 03:13:00 --> Config Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Hooks Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Utf8 Class Initialized
DEBUG - 2011-06-07 03:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 03:13:00 --> URI Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Router Class Initialized
DEBUG - 2011-06-07 03:13:00 --> No URI present. Default controller set.
DEBUG - 2011-06-07 03:13:00 --> Output Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Input Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 03:13:00 --> Language Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Loader Class Initialized
DEBUG - 2011-06-07 03:13:00 --> Controller Class Initialized
DEBUG - 2011-06-07 03:13:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-07 03:13:00 --> Helper loaded: url_helper
DEBUG - 2011-06-07 03:13:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 03:13:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 03:13:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 03:13:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 03:13:00 --> Final output sent to browser
DEBUG - 2011-06-07 03:13:00 --> Total execution time: 0.2317
DEBUG - 2011-06-07 03:31:02 --> Config Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Hooks Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Utf8 Class Initialized
DEBUG - 2011-06-07 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 03:31:02 --> URI Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Router Class Initialized
DEBUG - 2011-06-07 03:31:02 --> No URI present. Default controller set.
DEBUG - 2011-06-07 03:31:02 --> Output Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Input Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 03:31:02 --> Language Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Loader Class Initialized
DEBUG - 2011-06-07 03:31:02 --> Controller Class Initialized
DEBUG - 2011-06-07 03:31:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-07 03:31:03 --> Helper loaded: url_helper
DEBUG - 2011-06-07 03:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 03:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 03:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 03:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 03:31:03 --> Final output sent to browser
DEBUG - 2011-06-07 03:31:03 --> Total execution time: 0.3662
DEBUG - 2011-06-07 03:55:58 --> Config Class Initialized
DEBUG - 2011-06-07 03:55:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 03:55:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 03:55:58 --> URI Class Initialized
DEBUG - 2011-06-07 03:55:58 --> Router Class Initialized
ERROR - 2011-06-07 03:55:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 03:56:45 --> Config Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Hooks Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Utf8 Class Initialized
DEBUG - 2011-06-07 03:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 03:56:45 --> URI Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Router Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Output Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Input Class Initialized
DEBUG - 2011-06-07 03:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 03:56:46 --> Language Class Initialized
DEBUG - 2011-06-07 03:56:46 --> Loader Class Initialized
DEBUG - 2011-06-07 03:56:46 --> Controller Class Initialized
ERROR - 2011-06-07 03:56:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 03:56:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 03:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 03:56:46 --> Model Class Initialized
DEBUG - 2011-06-07 03:56:46 --> Model Class Initialized
DEBUG - 2011-06-07 03:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 03:56:46 --> Database Driver Class Initialized
DEBUG - 2011-06-07 03:56:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 03:56:57 --> Helper loaded: url_helper
DEBUG - 2011-06-07 03:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 03:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 03:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 03:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 03:56:57 --> Final output sent to browser
DEBUG - 2011-06-07 03:56:57 --> Total execution time: 11.8971
DEBUG - 2011-06-07 05:23:43 --> Config Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:23:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:23:43 --> URI Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Router Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Output Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Input Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:23:43 --> Language Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Loader Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Controller Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:23:43 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:23:45 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:23:45 --> Final output sent to browser
DEBUG - 2011-06-07 05:23:45 --> Total execution time: 2.6497
DEBUG - 2011-06-07 05:23:47 --> Config Class Initialized
DEBUG - 2011-06-07 05:23:47 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:23:47 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:23:47 --> URI Class Initialized
DEBUG - 2011-06-07 05:23:47 --> Router Class Initialized
ERROR - 2011-06-07 05:23:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:23:58 --> Config Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:23:58 --> URI Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Router Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Output Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Input Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:23:58 --> Language Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Loader Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Controller Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Model Class Initialized
DEBUG - 2011-06-07 05:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:23:58 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:23:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:23:59 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:23:59 --> Final output sent to browser
DEBUG - 2011-06-07 05:23:59 --> Total execution time: 0.9632
DEBUG - 2011-06-07 05:24:00 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:00 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:00 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:00 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:00 --> Router Class Initialized
ERROR - 2011-06-07 05:24:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:24:06 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:06 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Router Class Initialized
ERROR - 2011-06-07 05:24:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 05:24:06 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:06 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Router Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Output Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Input Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:24:06 --> Language Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Loader Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Controller Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:24:06 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:24:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:24:06 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:24:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:24:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:24:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:24:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:24:06 --> Final output sent to browser
DEBUG - 2011-06-07 05:24:06 --> Total execution time: 0.0525
DEBUG - 2011-06-07 05:24:08 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:08 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Router Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Output Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Input Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:24:08 --> Language Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Loader Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Controller Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:24:08 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:24:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:24:08 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:24:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:24:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:24:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:24:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:24:08 --> Final output sent to browser
DEBUG - 2011-06-07 05:24:08 --> Total execution time: 0.6181
DEBUG - 2011-06-07 05:24:10 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:10 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:10 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:10 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:10 --> Router Class Initialized
ERROR - 2011-06-07 05:24:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:24:15 --> Config Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:24:15 --> URI Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Router Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Output Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Input Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:24:15 --> Language Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Loader Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Controller Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Model Class Initialized
DEBUG - 2011-06-07 05:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:24:15 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:24:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:24:15 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:24:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:24:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:24:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:24:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:24:15 --> Final output sent to browser
DEBUG - 2011-06-07 05:24:15 --> Total execution time: 0.0644
DEBUG - 2011-06-07 05:57:23 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:23 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Router Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Output Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Input Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:57:23 --> Language Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Loader Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Controller Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:57:23 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:57:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:57:23 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:57:23 --> Final output sent to browser
DEBUG - 2011-06-07 05:57:23 --> Total execution time: 0.6739
DEBUG - 2011-06-07 05:57:26 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:26 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:26 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:26 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:26 --> Router Class Initialized
ERROR - 2011-06-07 05:57:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:57:28 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:28 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:28 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:28 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:28 --> Router Class Initialized
ERROR - 2011-06-07 05:57:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:57:51 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:51 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Router Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Output Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Input Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:57:51 --> Language Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Loader Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Controller Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:57:51 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:57:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:57:52 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:57:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:57:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:57:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:57:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:57:52 --> Final output sent to browser
DEBUG - 2011-06-07 05:57:52 --> Total execution time: 0.6317
DEBUG - 2011-06-07 05:57:53 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:53 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Router Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Output Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Input Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:57:53 --> Language Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Loader Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Controller Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:57:53 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:57:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:57:53 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:57:53 --> Final output sent to browser
DEBUG - 2011-06-07 05:57:53 --> Total execution time: 0.0418
DEBUG - 2011-06-07 05:57:54 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:54 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:54 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:54 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:54 --> Router Class Initialized
ERROR - 2011-06-07 05:57:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:57:55 --> Config Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:57:55 --> URI Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Router Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Output Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Input Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:57:55 --> Language Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Loader Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Controller Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:57:55 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:57:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:57:55 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:57:55 --> Final output sent to browser
DEBUG - 2011-06-07 05:57:55 --> Total execution time: 0.0618
DEBUG - 2011-06-07 05:58:12 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:12 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:12 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:12 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:13 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:13 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:13 --> Total execution time: 1.0296
DEBUG - 2011-06-07 05:58:15 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:15 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:15 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:15 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:15 --> Router Class Initialized
ERROR - 2011-06-07 05:58:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:58:34 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:34 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:34 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:34 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:35 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:35 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:35 --> Total execution time: 0.4792
DEBUG - 2011-06-07 05:58:36 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:36 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:36 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:36 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:36 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:36 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:36 --> Total execution time: 0.0752
DEBUG - 2011-06-07 05:58:36 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:36 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:36 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:36 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:36 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:36 --> Router Class Initialized
ERROR - 2011-06-07 05:58:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:36 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:36 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:36 --> Total execution time: 0.0692
DEBUG - 2011-06-07 05:58:55 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:55 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:55 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:55 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:56 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:56 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:56 --> Total execution time: 0.2547
DEBUG - 2011-06-07 05:58:57 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:57 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Router Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Output Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Input Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:58:57 --> Language Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Loader Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Controller Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Model Class Initialized
DEBUG - 2011-06-07 05:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:58:57 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:58:57 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:58:57 --> Final output sent to browser
DEBUG - 2011-06-07 05:58:57 --> Total execution time: 0.0451
DEBUG - 2011-06-07 05:58:58 --> Config Class Initialized
DEBUG - 2011-06-07 05:58:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:58:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:58:58 --> URI Class Initialized
DEBUG - 2011-06-07 05:58:58 --> Router Class Initialized
ERROR - 2011-06-07 05:58:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:59:07 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:07 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:07 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:07 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:07 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:07 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:07 --> Total execution time: 0.3000
DEBUG - 2011-06-07 05:59:09 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:09 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Router Class Initialized
ERROR - 2011-06-07 05:59:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:59:09 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:09 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:09 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:09 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:09 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:09 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:09 --> Total execution time: 0.0480
DEBUG - 2011-06-07 05:59:24 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:24 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:24 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:24 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:24 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:24 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:24 --> Total execution time: 0.2944
DEBUG - 2011-06-07 05:59:25 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:25 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:25 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:25 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:25 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:25 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:25 --> Total execution time: 0.0513
DEBUG - 2011-06-07 05:59:26 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:26 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:26 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:26 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:26 --> Router Class Initialized
ERROR - 2011-06-07 05:59:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:59:45 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:45 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:45 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:45 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:45 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:45 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:45 --> Total execution time: 0.2917
DEBUG - 2011-06-07 05:59:47 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:47 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Router Class Initialized
ERROR - 2011-06-07 05:59:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 05:59:47 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:47 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:47 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:47 --> Database Driver Class Initialized
DEBUG - 2011-06-07 05:59:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 05:59:47 --> Helper loaded: url_helper
DEBUG - 2011-06-07 05:59:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 05:59:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 05:59:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 05:59:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 05:59:47 --> Final output sent to browser
DEBUG - 2011-06-07 05:59:47 --> Total execution time: 0.0685
DEBUG - 2011-06-07 05:59:59 --> Config Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Hooks Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Utf8 Class Initialized
DEBUG - 2011-06-07 05:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 05:59:59 --> URI Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Router Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Output Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Input Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 05:59:59 --> Language Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Loader Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Controller Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Model Class Initialized
DEBUG - 2011-06-07 05:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 05:59:59 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:00:00 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:00:00 --> Final output sent to browser
DEBUG - 2011-06-07 06:00:00 --> Total execution time: 0.0902
DEBUG - 2011-06-07 06:00:03 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:03 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:03 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:03 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:03 --> Router Class Initialized
ERROR - 2011-06-07 06:00:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:00:10 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:10 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Router Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Output Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Input Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:00:10 --> Language Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Loader Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Controller Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:00:10 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:00:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:00:17 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:00:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:00:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:00:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:00:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:00:17 --> Final output sent to browser
DEBUG - 2011-06-07 06:00:17 --> Total execution time: 7.6915
DEBUG - 2011-06-07 06:00:20 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:20 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:20 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:20 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:20 --> Router Class Initialized
ERROR - 2011-06-07 06:00:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:00:22 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:22 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Router Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Output Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Input Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:00:22 --> Language Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Loader Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Controller Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:00:22 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:00:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:00:22 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:00:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:00:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:00:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:00:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:00:22 --> Final output sent to browser
DEBUG - 2011-06-07 06:00:22 --> Total execution time: 0.0535
DEBUG - 2011-06-07 06:00:35 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:35 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Router Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Output Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Input Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:00:35 --> Language Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Loader Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Controller Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:00:35 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:00:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:00:35 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:00:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:00:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:00:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:00:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:00:35 --> Final output sent to browser
DEBUG - 2011-06-07 06:00:35 --> Total execution time: 0.0564
DEBUG - 2011-06-07 06:00:37 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:37 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:37 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:37 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:37 --> Router Class Initialized
ERROR - 2011-06-07 06:00:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:00:53 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:53 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Router Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Output Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Input Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:00:53 --> Language Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Loader Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Controller Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Model Class Initialized
DEBUG - 2011-06-07 06:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:00:53 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:00:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:00:53 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:00:53 --> Final output sent to browser
DEBUG - 2011-06-07 06:00:53 --> Total execution time: 0.0524
DEBUG - 2011-06-07 06:00:55 --> Config Class Initialized
DEBUG - 2011-06-07 06:00:55 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:00:55 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:00:55 --> URI Class Initialized
DEBUG - 2011-06-07 06:00:55 --> Router Class Initialized
ERROR - 2011-06-07 06:00:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:01:04 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:04 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:04 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:04 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:04 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:04 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:04 --> Total execution time: 0.2918
DEBUG - 2011-06-07 06:01:06 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:06 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:06 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:06 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:06 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:06 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:06 --> Total execution time: 0.0974
DEBUG - 2011-06-07 06:01:06 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:06 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:06 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:06 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:06 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:06 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:06 --> Total execution time: 0.0489
DEBUG - 2011-06-07 06:01:06 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:06 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:06 --> Router Class Initialized
ERROR - 2011-06-07 06:01:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:01:22 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:22 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:22 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:22 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:22 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:22 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:22 --> Total execution time: 0.0507
DEBUG - 2011-06-07 06:01:24 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:24 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:24 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:24 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:24 --> Router Class Initialized
ERROR - 2011-06-07 06:01:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:01:34 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:34 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:34 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:34 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:34 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:34 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:34 --> Total execution time: 0.0759
DEBUG - 2011-06-07 06:01:36 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:36 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:36 --> Router Class Initialized
ERROR - 2011-06-07 06:01:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:01:46 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:46 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:46 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:46 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:46 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:46 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:46 --> Total execution time: 0.1015
DEBUG - 2011-06-07 06:01:49 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:49 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:49 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:49 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:49 --> Router Class Initialized
ERROR - 2011-06-07 06:01:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:01:57 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:57 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Router Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Output Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Input Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:01:57 --> Language Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Loader Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Controller Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Model Class Initialized
DEBUG - 2011-06-07 06:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:01:57 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:01:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:01:57 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:01:57 --> Final output sent to browser
DEBUG - 2011-06-07 06:01:57 --> Total execution time: 0.1206
DEBUG - 2011-06-07 06:01:59 --> Config Class Initialized
DEBUG - 2011-06-07 06:01:59 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:01:59 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:01:59 --> URI Class Initialized
DEBUG - 2011-06-07 06:01:59 --> Router Class Initialized
ERROR - 2011-06-07 06:01:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:02:10 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:10 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:10 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:10 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:10 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:10 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:10 --> Total execution time: 0.3580
DEBUG - 2011-06-07 06:02:12 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:12 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:12 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:12 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:12 --> Router Class Initialized
ERROR - 2011-06-07 06:02:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:02:15 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:15 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:15 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:15 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:15 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:15 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:15 --> Total execution time: 0.0507
DEBUG - 2011-06-07 06:02:28 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:28 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:28 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:28 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:29 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:29 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:29 --> Total execution time: 0.8895
DEBUG - 2011-06-07 06:02:30 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:30 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:30 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:30 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:30 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:30 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:30 --> Total execution time: 0.0925
DEBUG - 2011-06-07 06:02:31 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:31 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:31 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:31 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:31 --> Router Class Initialized
ERROR - 2011-06-07 06:02:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:02:43 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:43 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:43 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:43 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:43 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:43 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:43 --> Total execution time: 0.0518
DEBUG - 2011-06-07 06:02:45 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:45 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:45 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:45 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:45 --> Router Class Initialized
ERROR - 2011-06-07 06:02:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:02:52 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:52 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Router Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Output Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Input Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:02:52 --> Language Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Loader Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Controller Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Model Class Initialized
DEBUG - 2011-06-07 06:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:02:52 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:02:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:02:52 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:02:52 --> Final output sent to browser
DEBUG - 2011-06-07 06:02:52 --> Total execution time: 0.1204
DEBUG - 2011-06-07 06:02:54 --> Config Class Initialized
DEBUG - 2011-06-07 06:02:54 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:02:54 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:02:54 --> URI Class Initialized
DEBUG - 2011-06-07 06:02:54 --> Router Class Initialized
ERROR - 2011-06-07 06:02:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:03:02 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:02 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:02 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:02 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:02 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:02 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:02 --> Total execution time: 0.0884
DEBUG - 2011-06-07 06:03:03 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:03 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:03 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:03 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:03 --> Router Class Initialized
ERROR - 2011-06-07 06:03:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:03:12 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:12 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:12 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:12 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:12 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:12 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:12 --> Total execution time: 0.1460
DEBUG - 2011-06-07 06:03:14 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:14 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:14 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:14 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:14 --> Router Class Initialized
ERROR - 2011-06-07 06:03:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:03:23 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:23 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:23 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:23 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:24 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:24 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:24 --> Total execution time: 0.1247
DEBUG - 2011-06-07 06:03:25 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:25 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:25 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:25 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:25 --> Router Class Initialized
ERROR - 2011-06-07 06:03:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:03:37 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:37 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:37 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:37 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:37 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:37 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:37 --> Total execution time: 0.3947
DEBUG - 2011-06-07 06:03:39 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:39 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:39 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:39 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:39 --> Router Class Initialized
ERROR - 2011-06-07 06:03:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:03:50 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:50 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:50 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:50 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:50 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:50 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:50 --> Total execution time: 0.0467
DEBUG - 2011-06-07 06:03:55 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:55 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Router Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Output Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Input Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:03:55 --> Language Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Loader Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Controller Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Model Class Initialized
DEBUG - 2011-06-07 06:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:03:55 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:03:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:03:56 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:03:56 --> Final output sent to browser
DEBUG - 2011-06-07 06:03:56 --> Total execution time: 0.4600
DEBUG - 2011-06-07 06:03:58 --> Config Class Initialized
DEBUG - 2011-06-07 06:03:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:03:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:03:58 --> URI Class Initialized
DEBUG - 2011-06-07 06:03:58 --> Router Class Initialized
ERROR - 2011-06-07 06:03:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:04:06 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:06 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Router Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Output Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Input Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:04:06 --> Language Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Loader Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Controller Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:04:06 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:04:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:04:06 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:04:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:04:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:04:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:04:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:04:06 --> Final output sent to browser
DEBUG - 2011-06-07 06:04:06 --> Total execution time: 0.0733
DEBUG - 2011-06-07 06:04:11 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:11 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Router Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Output Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Input Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:04:11 --> Language Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Loader Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Controller Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:04:11 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:04:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:04:11 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:04:11 --> Final output sent to browser
DEBUG - 2011-06-07 06:04:11 --> Total execution time: 0.4311
DEBUG - 2011-06-07 06:04:13 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:13 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:13 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:13 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:13 --> Router Class Initialized
ERROR - 2011-06-07 06:04:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 06:04:26 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:26 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Router Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Output Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Input Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:04:26 --> Language Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Loader Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Controller Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:04:26 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:04:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:04:26 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:04:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:04:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:04:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:04:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:04:26 --> Final output sent to browser
DEBUG - 2011-06-07 06:04:26 --> Total execution time: 0.0660
DEBUG - 2011-06-07 06:04:27 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:27 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Router Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Output Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Input Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 06:04:27 --> Language Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Loader Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Controller Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Model Class Initialized
DEBUG - 2011-06-07 06:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 06:04:27 --> Database Driver Class Initialized
DEBUG - 2011-06-07 06:04:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 06:04:27 --> Helper loaded: url_helper
DEBUG - 2011-06-07 06:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 06:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 06:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 06:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 06:04:27 --> Final output sent to browser
DEBUG - 2011-06-07 06:04:27 --> Total execution time: 0.1054
DEBUG - 2011-06-07 06:04:28 --> Config Class Initialized
DEBUG - 2011-06-07 06:04:28 --> Hooks Class Initialized
DEBUG - 2011-06-07 06:04:28 --> Utf8 Class Initialized
DEBUG - 2011-06-07 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 06:04:28 --> URI Class Initialized
DEBUG - 2011-06-07 06:04:28 --> Router Class Initialized
ERROR - 2011-06-07 06:04:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 07:29:25 --> Config Class Initialized
DEBUG - 2011-06-07 07:29:25 --> Hooks Class Initialized
DEBUG - 2011-06-07 07:29:25 --> Utf8 Class Initialized
DEBUG - 2011-06-07 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 07:29:25 --> URI Class Initialized
DEBUG - 2011-06-07 07:29:25 --> Router Class Initialized
DEBUG - 2011-06-07 07:29:25 --> No URI present. Default controller set.
DEBUG - 2011-06-07 07:29:25 --> Output Class Initialized
DEBUG - 2011-06-07 07:29:25 --> Input Class Initialized
DEBUG - 2011-06-07 07:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 07:29:25 --> Language Class Initialized
DEBUG - 2011-06-07 07:29:26 --> Loader Class Initialized
DEBUG - 2011-06-07 07:29:26 --> Controller Class Initialized
DEBUG - 2011-06-07 07:29:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-07 07:29:26 --> Helper loaded: url_helper
DEBUG - 2011-06-07 07:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 07:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 07:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 07:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 07:29:26 --> Final output sent to browser
DEBUG - 2011-06-07 07:29:26 --> Total execution time: 0.5563
DEBUG - 2011-06-07 07:29:32 --> Config Class Initialized
DEBUG - 2011-06-07 07:29:32 --> Hooks Class Initialized
DEBUG - 2011-06-07 07:29:32 --> Utf8 Class Initialized
DEBUG - 2011-06-07 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 07:29:32 --> URI Class Initialized
DEBUG - 2011-06-07 07:29:32 --> Router Class Initialized
ERROR - 2011-06-07 07:29:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 07:43:00 --> Config Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Hooks Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Utf8 Class Initialized
DEBUG - 2011-06-07 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 07:43:00 --> URI Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Router Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Output Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Input Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 07:43:00 --> Language Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Loader Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Controller Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Model Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Model Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Model Class Initialized
DEBUG - 2011-06-07 07:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 07:43:00 --> Database Driver Class Initialized
DEBUG - 2011-06-07 07:43:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 07:43:01 --> Helper loaded: url_helper
DEBUG - 2011-06-07 07:43:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 07:43:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 07:43:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 07:43:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 07:43:01 --> Final output sent to browser
DEBUG - 2011-06-07 07:43:01 --> Total execution time: 1.4104
DEBUG - 2011-06-07 07:43:02 --> Config Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Hooks Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Utf8 Class Initialized
DEBUG - 2011-06-07 07:43:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 07:43:02 --> URI Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Router Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Output Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Input Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 07:43:02 --> Language Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Loader Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Controller Class Initialized
ERROR - 2011-06-07 07:43:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 07:43:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 07:43:02 --> Model Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Model Class Initialized
DEBUG - 2011-06-07 07:43:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 07:43:02 --> Database Driver Class Initialized
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 07:43:02 --> Helper loaded: url_helper
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 07:43:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 07:43:02 --> Final output sent to browser
DEBUG - 2011-06-07 07:43:02 --> Total execution time: 0.1693
DEBUG - 2011-06-07 08:09:19 --> Config Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Hooks Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Utf8 Class Initialized
DEBUG - 2011-06-07 08:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 08:09:19 --> URI Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Router Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Output Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Input Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 08:09:19 --> Language Class Initialized
DEBUG - 2011-06-07 08:09:19 --> Loader Class Initialized
DEBUG - 2011-06-07 08:09:20 --> Controller Class Initialized
DEBUG - 2011-06-07 08:09:20 --> Model Class Initialized
DEBUG - 2011-06-07 08:09:20 --> Model Class Initialized
DEBUG - 2011-06-07 08:09:20 --> Model Class Initialized
DEBUG - 2011-06-07 08:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 08:09:20 --> Database Driver Class Initialized
DEBUG - 2011-06-07 08:09:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 08:09:20 --> Helper loaded: url_helper
DEBUG - 2011-06-07 08:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 08:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 08:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 08:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 08:09:20 --> Final output sent to browser
DEBUG - 2011-06-07 08:09:20 --> Total execution time: 1.2138
DEBUG - 2011-06-07 12:06:19 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:19 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Router Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Output Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Input Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:06:19 --> Language Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Loader Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Controller Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:06:19 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:06:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:06:19 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:06:19 --> Final output sent to browser
DEBUG - 2011-06-07 12:06:19 --> Total execution time: 0.6135
DEBUG - 2011-06-07 12:06:20 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:20 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:20 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:20 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:20 --> Router Class Initialized
ERROR - 2011-06-07 12:06:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:06:21 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:21 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:21 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:21 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:21 --> Router Class Initialized
ERROR - 2011-06-07 12:06:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:06:38 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:38 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Router Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Output Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Input Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:06:38 --> Language Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Loader Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Controller Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:06:38 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:06:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:06:39 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:06:39 --> Final output sent to browser
DEBUG - 2011-06-07 12:06:39 --> Total execution time: 0.8845
DEBUG - 2011-06-07 12:06:40 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:40 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Router Class Initialized
ERROR - 2011-06-07 12:06:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:06:40 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:40 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Router Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Output Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Input Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:06:40 --> Language Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Loader Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Controller Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:06:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:06:40 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:06:40 --> Final output sent to browser
DEBUG - 2011-06-07 12:06:40 --> Total execution time: 0.0838
DEBUG - 2011-06-07 12:06:53 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:53 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Router Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Output Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Input Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:06:53 --> Language Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Loader Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Controller Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:06:53 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:06:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:06:53 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:06:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:06:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:06:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:06:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:06:53 --> Final output sent to browser
DEBUG - 2011-06-07 12:06:53 --> Total execution time: 0.2546
DEBUG - 2011-06-07 12:06:54 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:54 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:54 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:54 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:54 --> Router Class Initialized
ERROR - 2011-06-07 12:06:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:06:56 --> Config Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:06:56 --> URI Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Router Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Output Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Input Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:06:56 --> Language Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Loader Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Controller Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Model Class Initialized
DEBUG - 2011-06-07 12:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:06:56 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:06:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:06:56 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:06:56 --> Final output sent to browser
DEBUG - 2011-06-07 12:06:56 --> Total execution time: 0.0509
DEBUG - 2011-06-07 12:07:00 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:00 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:00 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:00 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:01 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:01 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:01 --> Total execution time: 0.4457
DEBUG - 2011-06-07 12:07:02 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:02 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:02 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:02 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:02 --> Router Class Initialized
ERROR - 2011-06-07 12:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:05 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:05 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:05 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:05 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:05 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:05 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:05 --> Total execution time: 0.3465
DEBUG - 2011-06-07 12:07:06 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:06 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:06 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:06 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:06 --> Router Class Initialized
ERROR - 2011-06-07 12:07:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:17 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:17 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:17 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:17 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:17 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:17 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:17 --> Total execution time: 0.2552
DEBUG - 2011-06-07 12:07:18 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:18 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:18 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:18 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:18 --> Router Class Initialized
ERROR - 2011-06-07 12:07:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:23 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:23 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:23 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:23 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:24 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:24 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:24 --> Total execution time: 0.3625
DEBUG - 2011-06-07 12:07:25 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:25 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:25 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:25 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:25 --> Router Class Initialized
ERROR - 2011-06-07 12:07:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:30 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:30 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:30 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:30 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:30 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:30 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:30 --> Total execution time: 0.4050
DEBUG - 2011-06-07 12:07:31 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:31 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:31 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:31 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:31 --> Router Class Initialized
ERROR - 2011-06-07 12:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:37 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:37 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:37 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:37 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:37 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:37 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:37 --> Total execution time: 0.5938
DEBUG - 2011-06-07 12:07:38 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:38 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:38 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:38 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:38 --> Router Class Initialized
ERROR - 2011-06-07 12:07:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:43 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:43 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:43 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:44 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:44 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:44 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:44 --> Total execution time: 0.7579
DEBUG - 2011-06-07 12:07:45 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:45 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:45 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:45 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:45 --> Router Class Initialized
ERROR - 2011-06-07 12:07:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:50 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:50 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:50 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:50 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:51 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:51 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:51 --> Total execution time: 0.4010
DEBUG - 2011-06-07 12:07:52 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:52 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:52 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:52 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:52 --> Router Class Initialized
ERROR - 2011-06-07 12:07:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:07:57 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:57 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Router Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Output Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Input Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:07:57 --> Language Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Loader Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Controller Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Model Class Initialized
DEBUG - 2011-06-07 12:07:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:07:57 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:07:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:07:57 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:07:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:07:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:07:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:07:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:07:57 --> Final output sent to browser
DEBUG - 2011-06-07 12:07:57 --> Total execution time: 0.3393
DEBUG - 2011-06-07 12:07:58 --> Config Class Initialized
DEBUG - 2011-06-07 12:07:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:07:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:07:58 --> URI Class Initialized
DEBUG - 2011-06-07 12:07:58 --> Router Class Initialized
ERROR - 2011-06-07 12:07:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 12:08:03 --> Config Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:08:03 --> URI Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Router Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Output Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Input Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 12:08:03 --> Language Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Loader Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Controller Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Model Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Model Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Model Class Initialized
DEBUG - 2011-06-07 12:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 12:08:03 --> Database Driver Class Initialized
DEBUG - 2011-06-07 12:08:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 12:08:03 --> Helper loaded: url_helper
DEBUG - 2011-06-07 12:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 12:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 12:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 12:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 12:08:03 --> Final output sent to browser
DEBUG - 2011-06-07 12:08:03 --> Total execution time: 0.6946
DEBUG - 2011-06-07 12:08:04 --> Config Class Initialized
DEBUG - 2011-06-07 12:08:04 --> Hooks Class Initialized
DEBUG - 2011-06-07 12:08:04 --> Utf8 Class Initialized
DEBUG - 2011-06-07 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 12:08:04 --> URI Class Initialized
DEBUG - 2011-06-07 12:08:04 --> Router Class Initialized
ERROR - 2011-06-07 12:08:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 13:33:28 --> Config Class Initialized
DEBUG - 2011-06-07 13:33:28 --> Hooks Class Initialized
DEBUG - 2011-06-07 13:33:28 --> Utf8 Class Initialized
DEBUG - 2011-06-07 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 13:33:28 --> URI Class Initialized
DEBUG - 2011-06-07 13:33:28 --> Router Class Initialized
ERROR - 2011-06-07 13:33:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 13:33:29 --> Config Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Hooks Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Utf8 Class Initialized
DEBUG - 2011-06-07 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 13:33:29 --> URI Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Router Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Output Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Input Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 13:33:29 --> Language Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Loader Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Controller Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Model Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Model Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Model Class Initialized
DEBUG - 2011-06-07 13:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 13:33:29 --> Database Driver Class Initialized
DEBUG - 2011-06-07 13:33:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 13:33:30 --> Helper loaded: url_helper
DEBUG - 2011-06-07 13:33:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 13:33:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 13:33:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 13:33:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 13:33:30 --> Final output sent to browser
DEBUG - 2011-06-07 13:33:30 --> Total execution time: 0.6682
DEBUG - 2011-06-07 13:33:31 --> Config Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Hooks Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Utf8 Class Initialized
DEBUG - 2011-06-07 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 13:33:31 --> URI Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Router Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Output Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Input Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 13:33:31 --> Language Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Loader Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Controller Class Initialized
ERROR - 2011-06-07 13:33:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 13:33:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 13:33:31 --> Model Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Model Class Initialized
DEBUG - 2011-06-07 13:33:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 13:33:31 --> Database Driver Class Initialized
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 13:33:31 --> Helper loaded: url_helper
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 13:33:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 13:33:31 --> Final output sent to browser
DEBUG - 2011-06-07 13:33:31 --> Total execution time: 0.0953
DEBUG - 2011-06-07 16:54:43 --> Config Class Initialized
DEBUG - 2011-06-07 16:54:43 --> Hooks Class Initialized
DEBUG - 2011-06-07 16:54:43 --> Utf8 Class Initialized
DEBUG - 2011-06-07 16:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 16:54:43 --> URI Class Initialized
DEBUG - 2011-06-07 16:54:43 --> Router Class Initialized
ERROR - 2011-06-07 16:54:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 16:54:44 --> Config Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Hooks Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Utf8 Class Initialized
DEBUG - 2011-06-07 16:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 16:54:44 --> URI Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Router Class Initialized
DEBUG - 2011-06-07 16:54:44 --> No URI present. Default controller set.
DEBUG - 2011-06-07 16:54:44 --> Output Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Input Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 16:54:44 --> Language Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Loader Class Initialized
DEBUG - 2011-06-07 16:54:44 --> Controller Class Initialized
DEBUG - 2011-06-07 16:54:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-07 16:54:44 --> Helper loaded: url_helper
DEBUG - 2011-06-07 16:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 16:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 16:54:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 16:54:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 16:54:44 --> Final output sent to browser
DEBUG - 2011-06-07 16:54:44 --> Total execution time: 0.1961
DEBUG - 2011-06-07 17:03:42 --> Config Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:03:42 --> URI Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Router Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Output Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Input Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:03:42 --> Language Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Loader Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Controller Class Initialized
ERROR - 2011-06-07 17:03:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 17:03:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:03:42 --> Model Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Model Class Initialized
DEBUG - 2011-06-07 17:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:03:42 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:03:42 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:03:42 --> Final output sent to browser
DEBUG - 2011-06-07 17:03:42 --> Total execution time: 0.3564
DEBUG - 2011-06-07 17:03:43 --> Config Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:03:43 --> URI Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Router Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Output Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Input Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:03:43 --> Language Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Loader Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Controller Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Model Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Model Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:03:43 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:03:43 --> Final output sent to browser
DEBUG - 2011-06-07 17:03:43 --> Total execution time: 0.7666
DEBUG - 2011-06-07 17:03:44 --> Config Class Initialized
DEBUG - 2011-06-07 17:03:44 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:03:44 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:03:44 --> URI Class Initialized
DEBUG - 2011-06-07 17:03:44 --> Router Class Initialized
ERROR - 2011-06-07 17:03:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 17:04:35 --> Config Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:04:35 --> URI Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Router Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Output Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Input Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:04:35 --> Language Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Loader Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Controller Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:04:35 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:04:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:04:35 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:04:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:04:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:04:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:04:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:04:35 --> Final output sent to browser
DEBUG - 2011-06-07 17:04:35 --> Total execution time: 0.3184
DEBUG - 2011-06-07 17:04:56 --> Config Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:04:56 --> URI Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Router Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Output Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Input Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:04:56 --> Language Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Loader Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Controller Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:04:57 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:04:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:04:57 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:04:57 --> Final output sent to browser
DEBUG - 2011-06-07 17:04:57 --> Total execution time: 0.3386
DEBUG - 2011-06-07 17:04:59 --> Config Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:04:59 --> URI Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Router Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Output Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Input Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:04:59 --> Language Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Loader Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Controller Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Model Class Initialized
DEBUG - 2011-06-07 17:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:04:59 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:04:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:04:59 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:04:59 --> Final output sent to browser
DEBUG - 2011-06-07 17:04:59 --> Total execution time: 0.0449
DEBUG - 2011-06-07 17:05:09 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:09 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:09 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:09 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:09 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:09 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:09 --> Total execution time: 0.2383
DEBUG - 2011-06-07 17:05:10 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:10 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:10 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:10 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:10 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:10 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:10 --> Total execution time: 0.0507
DEBUG - 2011-06-07 17:05:10 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:10 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:10 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:10 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:10 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:10 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:10 --> Total execution time: 0.1452
DEBUG - 2011-06-07 17:05:21 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:21 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:21 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:21 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:21 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:21 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:21 --> Total execution time: 0.2612
DEBUG - 2011-06-07 17:05:22 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:22 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:22 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:22 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:22 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:22 --> Total execution time: 0.0664
DEBUG - 2011-06-07 17:05:22 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:22 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:22 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:22 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:22 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:22 --> Total execution time: 0.0448
DEBUG - 2011-06-07 17:05:36 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:36 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:36 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:36 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:37 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:37 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:37 --> Total execution time: 0.4560
DEBUG - 2011-06-07 17:05:38 --> Config Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:05:38 --> URI Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Router Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Output Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Input Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:05:38 --> Language Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Loader Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Controller Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Model Class Initialized
DEBUG - 2011-06-07 17:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:05:38 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 17:05:38 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:05:38 --> Final output sent to browser
DEBUG - 2011-06-07 17:05:38 --> Total execution time: 0.0560
DEBUG - 2011-06-07 17:55:58 --> Config Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:55:58 --> URI Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Router Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Output Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Input Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:55:58 --> Language Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Loader Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Controller Class Initialized
ERROR - 2011-06-07 17:55:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 17:55:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 17:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:55:58 --> Model Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Model Class Initialized
DEBUG - 2011-06-07 17:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:55:58 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:55:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:55:59 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:55:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:55:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:55:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:55:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:55:59 --> Final output sent to browser
DEBUG - 2011-06-07 17:55:59 --> Total execution time: 0.3233
DEBUG - 2011-06-07 17:56:00 --> Config Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:56:00 --> URI Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Router Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Output Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Input Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:56:00 --> Language Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Loader Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Controller Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:56:00 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:56:01 --> Final output sent to browser
DEBUG - 2011-06-07 17:56:01 --> Total execution time: 0.8305
DEBUG - 2011-06-07 17:56:03 --> Config Class Initialized
DEBUG - 2011-06-07 17:56:03 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:56:03 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:56:03 --> URI Class Initialized
DEBUG - 2011-06-07 17:56:03 --> Router Class Initialized
ERROR - 2011-06-07 17:56:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 17:56:04 --> Config Class Initialized
DEBUG - 2011-06-07 17:56:04 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:56:04 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:56:04 --> URI Class Initialized
DEBUG - 2011-06-07 17:56:04 --> Router Class Initialized
ERROR - 2011-06-07 17:56:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-07 17:56:30 --> Config Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:56:30 --> URI Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Config Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Hooks Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Router Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Utf8 Class Initialized
DEBUG - 2011-06-07 17:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 17:56:30 --> URI Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Output Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Router Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Input Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:56:30 --> Language Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Output Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Input Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 17:56:30 --> Language Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Loader Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Controller Class Initialized
ERROR - 2011-06-07 17:56:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 17:56:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:56:30 --> Loader Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Controller Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:56:30 --> Model Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 17:56:30 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:56:30 --> Database Driver Class Initialized
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 17:56:30 --> Helper loaded: url_helper
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 17:56:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 17:56:30 --> Final output sent to browser
DEBUG - 2011-06-07 17:56:30 --> Total execution time: 0.0298
DEBUG - 2011-06-07 17:56:30 --> Final output sent to browser
DEBUG - 2011-06-07 17:56:30 --> Total execution time: 0.4031
DEBUG - 2011-06-07 18:37:47 --> Config Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Hooks Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Utf8 Class Initialized
DEBUG - 2011-06-07 18:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 18:37:47 --> URI Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Router Class Initialized
ERROR - 2011-06-07 18:37:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-07 18:37:47 --> Config Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Hooks Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Utf8 Class Initialized
DEBUG - 2011-06-07 18:37:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 18:37:47 --> URI Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Router Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Output Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Input Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 18:37:47 --> Language Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Loader Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Controller Class Initialized
ERROR - 2011-06-07 18:37:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 18:37:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 18:37:47 --> Model Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Model Class Initialized
DEBUG - 2011-06-07 18:37:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 18:37:47 --> Database Driver Class Initialized
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 18:37:47 --> Helper loaded: url_helper
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 18:37:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 18:37:47 --> Final output sent to browser
DEBUG - 2011-06-07 18:37:47 --> Total execution time: 0.2707
DEBUG - 2011-06-07 18:38:07 --> Config Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Hooks Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Utf8 Class Initialized
DEBUG - 2011-06-07 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 18:38:07 --> URI Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Router Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Output Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Input Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 18:38:07 --> Language Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Loader Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Controller Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Model Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Model Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Model Class Initialized
DEBUG - 2011-06-07 18:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 18:38:07 --> Database Driver Class Initialized
DEBUG - 2011-06-07 18:38:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 18:38:08 --> Helper loaded: url_helper
DEBUG - 2011-06-07 18:38:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 18:38:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 18:38:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 18:38:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 18:38:08 --> Final output sent to browser
DEBUG - 2011-06-07 18:38:08 --> Total execution time: 0.4560
DEBUG - 2011-06-07 20:42:29 --> Config Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Hooks Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Utf8 Class Initialized
DEBUG - 2011-06-07 20:42:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 20:42:29 --> URI Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Router Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Output Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Input Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 20:42:29 --> Language Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Loader Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Controller Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 20:42:29 --> Database Driver Class Initialized
DEBUG - 2011-06-07 20:42:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 20:42:30 --> Helper loaded: url_helper
DEBUG - 2011-06-07 20:42:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 20:42:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 20:42:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 20:42:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 20:42:30 --> Final output sent to browser
DEBUG - 2011-06-07 20:42:30 --> Total execution time: 0.6849
DEBUG - 2011-06-07 20:42:35 --> Config Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Hooks Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Utf8 Class Initialized
DEBUG - 2011-06-07 20:42:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 20:42:35 --> URI Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Router Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Output Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Input Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 20:42:35 --> Language Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Loader Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Controller Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Model Class Initialized
DEBUG - 2011-06-07 20:42:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 20:42:35 --> Database Driver Class Initialized
DEBUG - 2011-06-07 20:42:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 20:42:35 --> Helper loaded: url_helper
DEBUG - 2011-06-07 20:42:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 20:42:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 20:42:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 20:42:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 20:42:35 --> Final output sent to browser
DEBUG - 2011-06-07 20:42:35 --> Total execution time: 0.2285
DEBUG - 2011-06-07 21:59:08 --> Config Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Hooks Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Utf8 Class Initialized
DEBUG - 2011-06-07 21:59:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 21:59:08 --> URI Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Router Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Output Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Input Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 21:59:08 --> Language Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Loader Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Controller Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Model Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Model Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Model Class Initialized
DEBUG - 2011-06-07 21:59:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 21:59:08 --> Database Driver Class Initialized
DEBUG - 2011-06-07 21:59:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-07 21:59:09 --> Helper loaded: url_helper
DEBUG - 2011-06-07 21:59:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 21:59:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 21:59:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 21:59:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 21:59:09 --> Final output sent to browser
DEBUG - 2011-06-07 21:59:09 --> Total execution time: 0.5648
DEBUG - 2011-06-07 21:59:12 --> Config Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Hooks Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Utf8 Class Initialized
DEBUG - 2011-06-07 21:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-07 21:59:12 --> URI Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Router Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Output Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Input Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-07 21:59:12 --> Language Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Loader Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Controller Class Initialized
ERROR - 2011-06-07 21:59:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-07 21:59:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 21:59:12 --> Model Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Model Class Initialized
DEBUG - 2011-06-07 21:59:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-07 21:59:12 --> Database Driver Class Initialized
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-07 21:59:12 --> Helper loaded: url_helper
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-07 21:59:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-07 21:59:12 --> Final output sent to browser
DEBUG - 2011-06-07 21:59:12 --> Total execution time: 0.1445

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-15 01:01:10 --> Config Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 01:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 01:01:10 --> URI Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Router Class Initialized
ERROR - 2011-04-15 01:01:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 01:01:10 --> Config Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 01:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 01:01:10 --> URI Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Router Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Output Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Input Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 01:01:10 --> Language Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Loader Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Controller Class Initialized
ERROR - 2011-04-15 01:01:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 01:01:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 01:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 01:01:10 --> Model Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Model Class Initialized
DEBUG - 2011-04-15 01:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 01:01:10 --> Database Driver Class Initialized
DEBUG - 2011-04-15 01:01:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 01:01:10 --> Helper loaded: url_helper
DEBUG - 2011-04-15 01:01:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 01:01:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 01:01:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 01:01:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 01:01:12 --> Final output sent to browser
DEBUG - 2011-04-15 01:01:12 --> Total execution time: 1.6855
DEBUG - 2011-04-15 01:05:06 --> Config Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Hooks Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Utf8 Class Initialized
DEBUG - 2011-04-15 01:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 01:05:06 --> URI Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Router Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Output Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Input Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 01:05:06 --> Language Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Loader Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Controller Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Model Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Model Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Model Class Initialized
DEBUG - 2011-04-15 01:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 01:05:06 --> Database Driver Class Initialized
DEBUG - 2011-04-15 01:05:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 01:05:06 --> Helper loaded: url_helper
DEBUG - 2011-04-15 01:05:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 01:05:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 01:05:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 01:05:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 01:05:06 --> Final output sent to browser
DEBUG - 2011-04-15 01:05:06 --> Total execution time: 0.3310
DEBUG - 2011-04-15 02:04:34 --> Config Class Initialized
DEBUG - 2011-04-15 02:04:34 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:04:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:04:35 --> URI Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Router Class Initialized
DEBUG - 2011-04-15 02:04:35 --> No URI present. Default controller set.
DEBUG - 2011-04-15 02:04:35 --> Output Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Input Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:04:35 --> Language Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Loader Class Initialized
DEBUG - 2011-04-15 02:04:35 --> Controller Class Initialized
DEBUG - 2011-04-15 02:04:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 02:04:36 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:04:36 --> Final output sent to browser
DEBUG - 2011-04-15 02:04:36 --> Total execution time: 3.7148
DEBUG - 2011-04-15 02:06:19 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:19 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Router Class Initialized
DEBUG - 2011-04-15 02:06:19 --> No URI present. Default controller set.
DEBUG - 2011-04-15 02:06:19 --> Output Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Input Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:06:19 --> Language Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Loader Class Initialized
DEBUG - 2011-04-15 02:06:19 --> Controller Class Initialized
DEBUG - 2011-04-15 02:06:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 02:06:19 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:06:19 --> Final output sent to browser
DEBUG - 2011-04-15 02:06:19 --> Total execution time: 0.4253
DEBUG - 2011-04-15 02:06:21 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:21 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:21 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:21 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:21 --> Router Class Initialized
ERROR - 2011-04-15 02:06:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 02:06:24 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:24 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Router Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Output Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Input Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:06:24 --> Language Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Loader Class Initialized
DEBUG - 2011-04-15 02:06:24 --> Controller Class Initialized
ERROR - 2011-04-15 02:06:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:06:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:06:25 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:25 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:06:25 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:06:25 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:06:25 --> Final output sent to browser
DEBUG - 2011-04-15 02:06:25 --> Total execution time: 1.0472
DEBUG - 2011-04-15 02:06:27 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:27 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Router Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Output Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Input Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:06:27 --> Language Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Loader Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Controller Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:06:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:06:29 --> Final output sent to browser
DEBUG - 2011-04-15 02:06:29 --> Total execution time: 2.5881
DEBUG - 2011-04-15 02:06:48 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:48 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Router Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Output Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Input Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:06:48 --> Language Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Loader Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Controller Class Initialized
ERROR - 2011-04-15 02:06:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:06:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:06:48 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:06:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:06:48 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:06:48 --> Final output sent to browser
DEBUG - 2011-04-15 02:06:48 --> Total execution time: 0.0854
DEBUG - 2011-04-15 02:06:49 --> Config Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:06:49 --> URI Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Router Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Output Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Input Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:06:49 --> Language Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Loader Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Controller Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Model Class Initialized
DEBUG - 2011-04-15 02:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:06:49 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:06:52 --> Final output sent to browser
DEBUG - 2011-04-15 02:06:52 --> Total execution time: 2.5946
DEBUG - 2011-04-15 02:11:37 --> Config Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:11:37 --> URI Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Router Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Output Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Input Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:11:37 --> Language Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Loader Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Controller Class Initialized
ERROR - 2011-04-15 02:11:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:11:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:11:37 --> Model Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Model Class Initialized
DEBUG - 2011-04-15 02:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:11:37 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:11:37 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:11:37 --> Final output sent to browser
DEBUG - 2011-04-15 02:11:37 --> Total execution time: 0.0663
DEBUG - 2011-04-15 02:11:39 --> Config Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:11:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:11:39 --> URI Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Router Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Output Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Input Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:11:39 --> Language Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Loader Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Controller Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Model Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Model Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:11:39 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:11:39 --> Final output sent to browser
DEBUG - 2011-04-15 02:11:39 --> Total execution time: 0.8108
DEBUG - 2011-04-15 02:11:42 --> Config Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:11:42 --> URI Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Router Class Initialized
ERROR - 2011-04-15 02:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 02:11:42 --> Config Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:11:42 --> URI Class Initialized
DEBUG - 2011-04-15 02:11:42 --> Router Class Initialized
ERROR - 2011-04-15 02:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 02:11:48 --> Config Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:11:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:11:48 --> URI Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Router Class Initialized
DEBUG - 2011-04-15 02:11:48 --> No URI present. Default controller set.
DEBUG - 2011-04-15 02:11:48 --> Output Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Input Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:11:48 --> Language Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Loader Class Initialized
DEBUG - 2011-04-15 02:11:48 --> Controller Class Initialized
DEBUG - 2011-04-15 02:11:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 02:11:48 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:11:48 --> Final output sent to browser
DEBUG - 2011-04-15 02:11:48 --> Total execution time: 0.7908
DEBUG - 2011-04-15 02:12:29 --> Config Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:12:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:12:29 --> URI Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Router Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Output Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Input Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:12:29 --> Language Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Loader Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Controller Class Initialized
ERROR - 2011-04-15 02:12:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:12:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:12:29 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:12:29 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:12:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:12:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:12:29 --> Final output sent to browser
DEBUG - 2011-04-15 02:12:29 --> Total execution time: 0.0355
DEBUG - 2011-04-15 02:12:30 --> Config Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:12:30 --> URI Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Router Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Output Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Input Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:12:30 --> Language Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Loader Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Controller Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:12:30 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:12:31 --> Final output sent to browser
DEBUG - 2011-04-15 02:12:31 --> Total execution time: 0.7433
DEBUG - 2011-04-15 02:12:38 --> Config Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:12:38 --> URI Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Router Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Output Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Input Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:12:38 --> Language Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Loader Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Controller Class Initialized
ERROR - 2011-04-15 02:12:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:12:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:12:38 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:12:38 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:12:38 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:12:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:12:38 --> Final output sent to browser
DEBUG - 2011-04-15 02:12:38 --> Total execution time: 0.0520
DEBUG - 2011-04-15 02:12:40 --> Config Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:12:40 --> URI Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Router Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Output Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Input Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:12:40 --> Language Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Loader Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Controller Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Model Class Initialized
DEBUG - 2011-04-15 02:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:12:40 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:12:43 --> Final output sent to browser
DEBUG - 2011-04-15 02:12:43 --> Total execution time: 3.2469
DEBUG - 2011-04-15 02:13:04 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:04 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:04 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Controller Class Initialized
ERROR - 2011-04-15 02:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:04 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:04 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:04 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:13:04 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:04 --> Total execution time: 0.1462
DEBUG - 2011-04-15 02:13:06 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:06 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:06 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Controller Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:06 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:06 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:06 --> Total execution time: 0.5455
DEBUG - 2011-04-15 02:13:13 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:13 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:13 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Controller Class Initialized
ERROR - 2011-04-15 02:13:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:13:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:13 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:13 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:13 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:13:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:13:13 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:13 --> Total execution time: 0.1774
DEBUG - 2011-04-15 02:13:15 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:15 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:15 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Controller Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:15 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:15 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:15 --> Total execution time: 0.5702
DEBUG - 2011-04-15 02:13:23 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:23 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:23 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Controller Class Initialized
ERROR - 2011-04-15 02:13:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:13:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:23 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:23 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:23 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:13:23 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:23 --> Total execution time: 0.0476
DEBUG - 2011-04-15 02:13:24 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:24 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:24 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Controller Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:24 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:25 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:25 --> Total execution time: 1.1812
DEBUG - 2011-04-15 02:13:27 --> Config Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:13:27 --> URI Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Router Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Output Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Input Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:13:27 --> Language Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Loader Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Controller Class Initialized
ERROR - 2011-04-15 02:13:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:13:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:13:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:13:27 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:13:27 --> Final output sent to browser
DEBUG - 2011-04-15 02:13:27 --> Total execution time: 0.0317
DEBUG - 2011-04-15 02:29:27 --> Config Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:29:27 --> URI Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Router Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Output Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Input Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:29:27 --> Language Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Loader Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Controller Class Initialized
ERROR - 2011-04-15 02:29:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:29:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:29:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:29:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:29:27 --> Model Class Initialized
DEBUG - 2011-04-15 02:29:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:29:28 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:29:28 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:29:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:29:28 --> Final output sent to browser
DEBUG - 2011-04-15 02:29:28 --> Total execution time: 1.3580
DEBUG - 2011-04-15 02:49:13 --> Config Class Initialized
DEBUG - 2011-04-15 02:49:13 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:49:13 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:49:13 --> URI Class Initialized
DEBUG - 2011-04-15 02:49:13 --> Router Class Initialized
DEBUG - 2011-04-15 02:49:15 --> Output Class Initialized
DEBUG - 2011-04-15 02:49:15 --> Input Class Initialized
DEBUG - 2011-04-15 02:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:49:16 --> Language Class Initialized
DEBUG - 2011-04-15 02:49:17 --> Loader Class Initialized
DEBUG - 2011-04-15 02:49:18 --> Controller Class Initialized
DEBUG - 2011-04-15 02:49:18 --> Model Class Initialized
DEBUG - 2011-04-15 02:49:18 --> Model Class Initialized
DEBUG - 2011-04-15 02:49:21 --> Model Class Initialized
DEBUG - 2011-04-15 02:49:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:49:23 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:49:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 02:49:35 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:49:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:49:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:49:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:49:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:49:35 --> Final output sent to browser
DEBUG - 2011-04-15 02:49:35 --> Total execution time: 22.2587
DEBUG - 2011-04-15 02:49:37 --> Config Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Hooks Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Utf8 Class Initialized
DEBUG - 2011-04-15 02:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 02:49:37 --> URI Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Router Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Output Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Input Class Initialized
DEBUG - 2011-04-15 02:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 02:49:37 --> Language Class Initialized
DEBUG - 2011-04-15 02:49:38 --> Loader Class Initialized
DEBUG - 2011-04-15 02:49:38 --> Controller Class Initialized
ERROR - 2011-04-15 02:49:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 02:49:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:49:38 --> Model Class Initialized
DEBUG - 2011-04-15 02:49:38 --> Model Class Initialized
DEBUG - 2011-04-15 02:49:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 02:49:38 --> Database Driver Class Initialized
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 02:49:38 --> Helper loaded: url_helper
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 02:49:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 02:49:38 --> Final output sent to browser
DEBUG - 2011-04-15 02:49:38 --> Total execution time: 0.5328
DEBUG - 2011-04-15 03:45:59 --> Config Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:45:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:45:59 --> URI Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Router Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Output Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Input Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:45:59 --> Language Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Loader Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Controller Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Model Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Model Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Model Class Initialized
DEBUG - 2011-04-15 03:45:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:45:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:46:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:46:01 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:46:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:46:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:46:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:46:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:46:01 --> Final output sent to browser
DEBUG - 2011-04-15 03:46:01 --> Total execution time: 2.0729
DEBUG - 2011-04-15 03:46:03 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:03 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:03 --> Router Class Initialized
ERROR - 2011-04-15 03:46:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:46:23 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:23 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Router Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Output Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Input Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:46:23 --> Language Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Loader Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Controller Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:46:23 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:46:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:46:27 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:46:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:46:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:46:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:46:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:46:27 --> Final output sent to browser
DEBUG - 2011-04-15 03:46:27 --> Total execution time: 4.4887
DEBUG - 2011-04-15 03:46:29 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:29 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:29 --> Router Class Initialized
ERROR - 2011-04-15 03:46:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:46:31 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:32 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Router Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Output Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Input Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:46:32 --> Language Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Loader Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Controller Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:46:32 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:46:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:46:32 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:46:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:46:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:46:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:46:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:46:32 --> Final output sent to browser
DEBUG - 2011-04-15 03:46:32 --> Total execution time: 0.0752
DEBUG - 2011-04-15 03:46:44 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:44 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Router Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Output Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Input Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:46:44 --> Language Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Loader Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Controller Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:44 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:46:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:46:45 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:46:45 --> Final output sent to browser
DEBUG - 2011-04-15 03:46:45 --> Total execution time: 0.3370
DEBUG - 2011-04-15 03:46:46 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:46 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Router Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Output Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Input Class Initialized
DEBUG - 2011-04-15 03:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:46:46 --> Language Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Loader Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Controller Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Model Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:46:47 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Config Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:46:47 --> URI Class Initialized
DEBUG - 2011-04-15 03:46:47 --> Router Class Initialized
ERROR - 2011-04-15 03:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:46:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:46:47 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:46:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:46:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:46:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:46:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:46:47 --> Final output sent to browser
DEBUG - 2011-04-15 03:46:47 --> Total execution time: 0.1085
DEBUG - 2011-04-15 03:52:21 --> Config Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:52:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:52:21 --> URI Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Router Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Output Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Input Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:52:21 --> Language Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Loader Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Controller Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:52:21 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:52:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:52:24 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:52:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:52:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:52:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:52:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:52:24 --> Final output sent to browser
DEBUG - 2011-04-15 03:52:24 --> Total execution time: 2.8820
DEBUG - 2011-04-15 03:52:26 --> Config Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:52:26 --> URI Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Router Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Output Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Input Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:52:26 --> Language Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Loader Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Controller Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Model Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:52:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:52:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:52:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:52:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:52:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:52:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:52:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:52:26 --> Final output sent to browser
DEBUG - 2011-04-15 03:52:26 --> Total execution time: 0.1061
DEBUG - 2011-04-15 03:52:26 --> Config Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:52:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:52:26 --> URI Class Initialized
DEBUG - 2011-04-15 03:52:26 --> Router Class Initialized
ERROR - 2011-04-15 03:52:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:55:56 --> Config Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:55:56 --> URI Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Router Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Output Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Input Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:55:56 --> Language Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Loader Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Controller Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:55:56 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:55:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:55:57 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:55:57 --> Final output sent to browser
DEBUG - 2011-04-15 03:55:57 --> Total execution time: 0.5608
DEBUG - 2011-04-15 03:55:58 --> Config Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:55:58 --> URI Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Router Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Output Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Input Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:55:58 --> Language Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Loader Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Controller Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Model Class Initialized
DEBUG - 2011-04-15 03:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:55:58 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:55:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:55:58 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:55:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:55:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:55:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:55:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:55:58 --> Final output sent to browser
DEBUG - 2011-04-15 03:55:58 --> Total execution time: 0.0665
DEBUG - 2011-04-15 03:55:59 --> Config Class Initialized
DEBUG - 2011-04-15 03:55:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:55:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:55:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:55:59 --> URI Class Initialized
DEBUG - 2011-04-15 03:55:59 --> Router Class Initialized
ERROR - 2011-04-15 03:55:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:56:03 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:03 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:03 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:03 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:03 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:03 --> Total execution time: 0.0838
DEBUG - 2011-04-15 03:56:03 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:03 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:03 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:03 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:03 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:03 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:03 --> Total execution time: 0.0548
DEBUG - 2011-04-15 03:56:04 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:04 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:04 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:04 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:04 --> Router Class Initialized
ERROR - 2011-04-15 03:56:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:56:38 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:38 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:38 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:38 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:38 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:38 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:38 --> Total execution time: 0.2344
DEBUG - 2011-04-15 03:56:40 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:40 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:40 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:40 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:40 --> Router Class Initialized
ERROR - 2011-04-15 03:56:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:56:45 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:45 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:45 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:45 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:45 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:45 --> Total execution time: 0.4957
DEBUG - 2011-04-15 03:56:47 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:47 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:47 --> Router Class Initialized
ERROR - 2011-04-15 03:56:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 03:56:48 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:48 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:48 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:48 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:48 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:48 --> Total execution time: 0.1217
DEBUG - 2011-04-15 03:56:49 --> Config Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-15 03:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 03:56:49 --> URI Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Router Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Output Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Input Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 03:56:49 --> Language Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Loader Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Controller Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Model Class Initialized
DEBUG - 2011-04-15 03:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 03:56:49 --> Database Driver Class Initialized
DEBUG - 2011-04-15 03:56:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 03:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-15 03:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 03:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 03:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 03:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 03:56:49 --> Final output sent to browser
DEBUG - 2011-04-15 03:56:49 --> Total execution time: 0.2135
DEBUG - 2011-04-15 04:00:50 --> Config Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:00:50 --> URI Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Router Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Output Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Input Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:00:50 --> Language Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Loader Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Controller Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Model Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Model Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Model Class Initialized
DEBUG - 2011-04-15 04:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:00:51 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:01:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:01:41 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:01:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:01:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:01:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:01:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:01:41 --> Final output sent to browser
DEBUG - 2011-04-15 04:01:41 --> Total execution time: 50.6156
DEBUG - 2011-04-15 04:01:43 --> Config Class Initialized
DEBUG - 2011-04-15 04:01:43 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:01:43 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:01:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:01:43 --> URI Class Initialized
DEBUG - 2011-04-15 04:01:43 --> Router Class Initialized
ERROR - 2011-04-15 04:01:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 04:02:25 --> Config Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:02:25 --> URI Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Router Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Output Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Input Class Initialized
DEBUG - 2011-04-15 04:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:02:25 --> Language Class Initialized
DEBUG - 2011-04-15 04:02:26 --> Loader Class Initialized
DEBUG - 2011-04-15 04:02:26 --> Controller Class Initialized
DEBUG - 2011-04-15 04:02:26 --> Model Class Initialized
DEBUG - 2011-04-15 04:02:27 --> Model Class Initialized
DEBUG - 2011-04-15 04:02:27 --> Model Class Initialized
DEBUG - 2011-04-15 04:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:02:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:02:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:02:27 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:02:27 --> Final output sent to browser
DEBUG - 2011-04-15 04:02:27 --> Total execution time: 1.2315
DEBUG - 2011-04-15 04:03:45 --> Config Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:03:45 --> URI Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Router Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Output Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Input Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:03:45 --> Language Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Loader Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Controller Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Model Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Model Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Model Class Initialized
DEBUG - 2011-04-15 04:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:03:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:03:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:03:49 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:03:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:03:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:03:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:03:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:03:49 --> Final output sent to browser
DEBUG - 2011-04-15 04:03:49 --> Total execution time: 3.6946
DEBUG - 2011-04-15 04:03:52 --> Config Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:03:52 --> URI Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Router Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Output Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Input Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:03:52 --> Language Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Loader Class Initialized
DEBUG - 2011-04-15 04:03:52 --> Controller Class Initialized
ERROR - 2011-04-15 04:03:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 04:03:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 04:03:53 --> Model Class Initialized
DEBUG - 2011-04-15 04:03:53 --> Model Class Initialized
DEBUG - 2011-04-15 04:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:03:53 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 04:03:53 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:03:53 --> Final output sent to browser
DEBUG - 2011-04-15 04:03:53 --> Total execution time: 0.1768
DEBUG - 2011-04-15 04:50:29 --> Config Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:50:29 --> URI Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Router Class Initialized
DEBUG - 2011-04-15 04:50:29 --> No URI present. Default controller set.
DEBUG - 2011-04-15 04:50:29 --> Output Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Input Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:50:29 --> Language Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Loader Class Initialized
DEBUG - 2011-04-15 04:50:29 --> Controller Class Initialized
DEBUG - 2011-04-15 04:50:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 04:50:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:50:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:50:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:50:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:50:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:50:29 --> Final output sent to browser
DEBUG - 2011-04-15 04:50:29 --> Total execution time: 0.5272
DEBUG - 2011-04-15 04:50:36 --> Config Class Initialized
DEBUG - 2011-04-15 04:50:36 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:50:36 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:50:36 --> URI Class Initialized
DEBUG - 2011-04-15 04:50:36 --> Router Class Initialized
ERROR - 2011-04-15 04:50:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 04:50:37 --> Config Class Initialized
DEBUG - 2011-04-15 04:50:37 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:50:37 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:50:37 --> URI Class Initialized
DEBUG - 2011-04-15 04:50:37 --> Router Class Initialized
ERROR - 2011-04-15 04:50:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 04:51:04 --> Config Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:51:04 --> URI Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Router Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Output Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Input Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:51:04 --> Language Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Loader Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Controller Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Model Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Model Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Model Class Initialized
DEBUG - 2011-04-15 04:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:51:04 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:51:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:51:10 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:51:10 --> Final output sent to browser
DEBUG - 2011-04-15 04:51:10 --> Total execution time: 6.1200
DEBUG - 2011-04-15 04:57:08 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:08 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:08 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:08 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:09 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:09 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:09 --> Total execution time: 1.0107
DEBUG - 2011-04-15 04:57:12 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:12 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:12 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:12 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:12 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:12 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:12 --> Total execution time: 0.1525
DEBUG - 2011-04-15 04:57:25 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:25 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:25 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:25 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:26 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:26 --> Total execution time: 0.5714
DEBUG - 2011-04-15 04:57:31 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:31 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:31 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:31 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:31 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:31 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:31 --> Total execution time: 0.0535
DEBUG - 2011-04-15 04:57:47 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:47 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:47 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:47 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:47 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:47 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:47 --> Total execution time: 0.2650
DEBUG - 2011-04-15 04:57:49 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:49 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:49 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:49 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:49 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:49 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:49 --> Total execution time: 0.0668
DEBUG - 2011-04-15 04:57:57 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:57 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:57 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:57 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:57 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:57 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:57 --> Total execution time: 0.4266
DEBUG - 2011-04-15 04:57:58 --> Config Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:57:58 --> URI Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Router Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Output Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Input Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:57:58 --> Language Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Loader Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Controller Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Model Class Initialized
DEBUG - 2011-04-15 04:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:57:58 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:57:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:57:58 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:57:58 --> Final output sent to browser
DEBUG - 2011-04-15 04:57:58 --> Total execution time: 0.0559
DEBUG - 2011-04-15 04:58:07 --> Config Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:58:07 --> URI Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Router Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Output Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Input Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:58:07 --> Language Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Loader Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Controller Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:58:07 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:58:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:58:07 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:58:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:58:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:58:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:58:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:58:07 --> Final output sent to browser
DEBUG - 2011-04-15 04:58:07 --> Total execution time: 0.2683
DEBUG - 2011-04-15 04:58:09 --> Config Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:58:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:58:09 --> URI Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Router Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Output Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Input Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:58:09 --> Language Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Loader Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Controller Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:58:09 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:58:09 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:58:09 --> Final output sent to browser
DEBUG - 2011-04-15 04:58:09 --> Total execution time: 0.0675
DEBUG - 2011-04-15 04:58:18 --> Config Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:58:18 --> URI Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Router Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Output Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Input Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:58:18 --> Language Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Loader Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Controller Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:58:18 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:58:19 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:58:19 --> Final output sent to browser
DEBUG - 2011-04-15 04:58:19 --> Total execution time: 1.0935
DEBUG - 2011-04-15 04:58:20 --> Config Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:58:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:58:20 --> URI Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Router Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Output Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Input Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:58:20 --> Language Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Loader Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Controller Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:58:20 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:58:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 04:58:20 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:58:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:58:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:58:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:58:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:58:20 --> Final output sent to browser
DEBUG - 2011-04-15 04:58:20 --> Total execution time: 0.0706
DEBUG - 2011-04-15 04:58:35 --> Config Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Hooks Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Utf8 Class Initialized
DEBUG - 2011-04-15 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 04:58:35 --> URI Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Router Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Output Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Input Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 04:58:35 --> Language Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Loader Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Controller Class Initialized
ERROR - 2011-04-15 04:58:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 04:58:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 04:58:35 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Model Class Initialized
DEBUG - 2011-04-15 04:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 04:58:35 --> Database Driver Class Initialized
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 04:58:35 --> Helper loaded: url_helper
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 04:58:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 04:58:35 --> Final output sent to browser
DEBUG - 2011-04-15 04:58:35 --> Total execution time: 0.1219
DEBUG - 2011-04-15 05:19:00 --> Config Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Hooks Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Utf8 Class Initialized
DEBUG - 2011-04-15 05:19:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 05:19:00 --> URI Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Router Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Output Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Input Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 05:19:00 --> Language Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Loader Class Initialized
DEBUG - 2011-04-15 05:19:00 --> Controller Class Initialized
DEBUG - 2011-04-15 05:19:01 --> Model Class Initialized
DEBUG - 2011-04-15 05:19:01 --> Model Class Initialized
DEBUG - 2011-04-15 05:19:01 --> Model Class Initialized
DEBUG - 2011-04-15 05:19:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 05:19:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 05:19:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 05:19:02 --> Helper loaded: url_helper
DEBUG - 2011-04-15 05:19:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 05:19:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 05:19:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 05:19:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 05:19:02 --> Final output sent to browser
DEBUG - 2011-04-15 05:19:02 --> Total execution time: 2.2516
DEBUG - 2011-04-15 05:19:08 --> Config Class Initialized
DEBUG - 2011-04-15 05:19:08 --> Hooks Class Initialized
DEBUG - 2011-04-15 05:19:08 --> Utf8 Class Initialized
DEBUG - 2011-04-15 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 05:19:08 --> URI Class Initialized
DEBUG - 2011-04-15 05:19:08 --> Router Class Initialized
ERROR - 2011-04-15 05:19:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:16:26 --> Config Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:16:26 --> URI Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Router Class Initialized
DEBUG - 2011-04-15 06:16:26 --> No URI present. Default controller set.
DEBUG - 2011-04-15 06:16:26 --> Output Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Input Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:16:26 --> Language Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Loader Class Initialized
DEBUG - 2011-04-15 06:16:26 --> Controller Class Initialized
DEBUG - 2011-04-15 06:16:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 06:16:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:16:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:16:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:16:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:16:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:16:26 --> Final output sent to browser
DEBUG - 2011-04-15 06:16:26 --> Total execution time: 0.2647
DEBUG - 2011-04-15 06:16:28 --> Config Class Initialized
DEBUG - 2011-04-15 06:16:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:16:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:16:28 --> URI Class Initialized
DEBUG - 2011-04-15 06:16:28 --> Router Class Initialized
ERROR - 2011-04-15 06:16:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:16:29 --> Config Class Initialized
DEBUG - 2011-04-15 06:16:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:16:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:16:29 --> URI Class Initialized
DEBUG - 2011-04-15 06:16:29 --> Router Class Initialized
ERROR - 2011-04-15 06:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:16:36 --> Config Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:16:36 --> URI Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Router Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Output Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Input Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:16:36 --> Language Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Loader Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Controller Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Model Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Model Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Model Class Initialized
DEBUG - 2011-04-15 06:16:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:16:36 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:16:41 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:16:41 --> Final output sent to browser
DEBUG - 2011-04-15 06:16:41 --> Total execution time: 5.5011
DEBUG - 2011-04-15 06:17:09 --> Config Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:17:09 --> URI Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Router Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Output Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Input Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:17:09 --> Language Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Loader Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Controller Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:17:09 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:17:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:17:11 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:17:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:17:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:17:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:17:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:17:11 --> Final output sent to browser
DEBUG - 2011-04-15 06:17:11 --> Total execution time: 1.8780
DEBUG - 2011-04-15 06:17:40 --> Config Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:17:40 --> URI Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Router Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Output Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Input Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:17:40 --> Language Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Loader Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Controller Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Model Class Initialized
DEBUG - 2011-04-15 06:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:17:40 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:17:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:17:40 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:17:40 --> Final output sent to browser
DEBUG - 2011-04-15 06:17:40 --> Total execution time: 0.4119
DEBUG - 2011-04-15 06:18:00 --> Config Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:18:00 --> URI Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Router Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Output Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Input Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:18:00 --> Language Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Loader Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Controller Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:18:00 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:18:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:18:01 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:18:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:18:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:18:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:18:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:18:01 --> Final output sent to browser
DEBUG - 2011-04-15 06:18:01 --> Total execution time: 0.5730
DEBUG - 2011-04-15 06:18:17 --> Config Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:18:17 --> URI Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Router Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Output Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Input Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:18:17 --> Language Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Loader Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Controller Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:18:17 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:18:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:18:17 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:18:17 --> Final output sent to browser
DEBUG - 2011-04-15 06:18:17 --> Total execution time: 0.0463
DEBUG - 2011-04-15 06:18:27 --> Config Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:18:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:18:27 --> URI Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Router Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Output Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Input Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:18:27 --> Language Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Loader Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Controller Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Model Class Initialized
DEBUG - 2011-04-15 06:18:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:18:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:18:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:18:27 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:18:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:18:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:18:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:18:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:18:27 --> Final output sent to browser
DEBUG - 2011-04-15 06:18:27 --> Total execution time: 0.0533
DEBUG - 2011-04-15 06:19:29 --> Config Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:19:29 --> URI Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Router Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Output Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Input Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:19:29 --> Language Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Loader Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Controller Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:19:29 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:19:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:19:29 --> Final output sent to browser
DEBUG - 2011-04-15 06:19:29 --> Total execution time: 0.1311
DEBUG - 2011-04-15 06:19:44 --> Config Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:19:44 --> URI Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Router Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Output Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Input Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:19:44 --> Language Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Loader Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Controller Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:19:44 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:19:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:19:44 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:19:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:19:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:19:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:19:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:19:44 --> Final output sent to browser
DEBUG - 2011-04-15 06:19:44 --> Total execution time: 0.2223
DEBUG - 2011-04-15 06:19:51 --> Config Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:19:51 --> URI Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Router Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Output Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Input Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:19:51 --> Language Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Loader Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Controller Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Model Class Initialized
DEBUG - 2011-04-15 06:19:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:19:51 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:19:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:19:51 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:19:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:19:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:19:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:19:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:19:51 --> Final output sent to browser
DEBUG - 2011-04-15 06:19:51 --> Total execution time: 0.0784
DEBUG - 2011-04-15 06:19:54 --> Config Class Initialized
DEBUG - 2011-04-15 06:19:54 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:19:54 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:19:54 --> URI Class Initialized
DEBUG - 2011-04-15 06:19:54 --> Router Class Initialized
ERROR - 2011-04-15 06:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:20:59 --> Config Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:20:59 --> URI Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Router Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Output Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Input Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:20:59 --> Language Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Loader Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Controller Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Model Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Model Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Model Class Initialized
DEBUG - 2011-04-15 06:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:20:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:00 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:00 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:00 --> Total execution time: 1.1027
DEBUG - 2011-04-15 06:21:02 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:02 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:02 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:02 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Router Class Initialized
ERROR - 2011-04-15 06:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:21:02 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:02 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:02 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:02 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:02 --> Total execution time: 0.1081
DEBUG - 2011-04-15 06:21:07 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:07 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:07 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:07 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:09 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:09 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:09 --> Total execution time: 1.3608
DEBUG - 2011-04-15 06:21:10 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:10 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:10 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:10 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:10 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:10 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:10 --> Total execution time: 0.0473
DEBUG - 2011-04-15 06:21:10 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:10 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:10 --> Router Class Initialized
ERROR - 2011-04-15 06:21:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 06:21:28 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:28 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:28 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:28 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:29 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:29 --> Total execution time: 0.5560
DEBUG - 2011-04-15 06:21:30 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:30 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:30 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:30 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:30 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:30 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:30 --> Total execution time: 0.0483
DEBUG - 2011-04-15 06:21:30 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:30 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Router Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Output Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Input Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 06:21:30 --> Language Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Loader Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Controller Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Model Class Initialized
DEBUG - 2011-04-15 06:21:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 06:21:30 --> Database Driver Class Initialized
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 06:21:30 --> Helper loaded: url_helper
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 06:21:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 06:21:30 --> Final output sent to browser
DEBUG - 2011-04-15 06:21:30 --> Total execution time: 0.1034
DEBUG - 2011-04-15 06:21:31 --> Config Class Initialized
DEBUG - 2011-04-15 06:21:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 06:21:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 06:21:31 --> URI Class Initialized
DEBUG - 2011-04-15 06:21:31 --> Router Class Initialized
ERROR - 2011-04-15 06:21:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 08:47:59 --> Config Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:47:59 --> URI Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Router Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Output Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Input Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:47:59 --> Language Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Loader Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Controller Class Initialized
ERROR - 2011-04-15 08:47:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 08:47:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 08:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:47:59 --> Model Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Model Class Initialized
DEBUG - 2011-04-15 08:47:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:47:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:47:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:48:00 --> Helper loaded: url_helper
DEBUG - 2011-04-15 08:48:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 08:48:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 08:48:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 08:48:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 08:48:00 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:00 --> Total execution time: 0.4099
DEBUG - 2011-04-15 08:48:01 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:01 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:01 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Controller Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:48:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:48:02 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:02 --> Total execution time: 0.8877
DEBUG - 2011-04-15 08:48:03 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:03 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:03 --> No URI present. Default controller set.
DEBUG - 2011-04-15 08:48:03 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:03 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:03 --> Controller Class Initialized
DEBUG - 2011-04-15 08:48:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 08:48:03 --> Helper loaded: url_helper
DEBUG - 2011-04-15 08:48:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 08:48:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 08:48:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 08:48:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 08:48:03 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:03 --> Total execution time: 0.0668
DEBUG - 2011-04-15 08:48:04 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:04 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Router Class Initialized
ERROR - 2011-04-15 08:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 08:48:04 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:04 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:04 --> Router Class Initialized
ERROR - 2011-04-15 08:48:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 08:48:10 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:10 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:10 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:11 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Controller Class Initialized
ERROR - 2011-04-15 08:48:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 08:48:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:48:11 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:48:11 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:48:11 --> Helper loaded: url_helper
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 08:48:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 08:48:11 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:11 --> Total execution time: 0.0949
DEBUG - 2011-04-15 08:48:12 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:12 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:12 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Controller Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:48:12 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:48:12 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:12 --> Total execution time: 0.6803
DEBUG - 2011-04-15 08:48:18 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:18 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:18 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Controller Class Initialized
ERROR - 2011-04-15 08:48:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 08:48:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:48:18 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:48:18 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 08:48:18 --> Helper loaded: url_helper
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 08:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 08:48:18 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:18 --> Total execution time: 0.0275
DEBUG - 2011-04-15 08:48:19 --> Config Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Hooks Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Utf8 Class Initialized
DEBUG - 2011-04-15 08:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 08:48:19 --> URI Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Router Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Output Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Input Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 08:48:19 --> Language Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Loader Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Controller Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Model Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 08:48:19 --> Database Driver Class Initialized
DEBUG - 2011-04-15 08:48:19 --> Final output sent to browser
DEBUG - 2011-04-15 08:48:19 --> Total execution time: 0.4550
DEBUG - 2011-04-15 09:20:29 --> Config Class Initialized
DEBUG - 2011-04-15 09:20:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:20:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:20:29 --> URI Class Initialized
DEBUG - 2011-04-15 09:20:29 --> Router Class Initialized
ERROR - 2011-04-15 09:20:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 09:21:11 --> Config Class Initialized
DEBUG - 2011-04-15 09:21:11 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:21:11 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:21:11 --> URI Class Initialized
DEBUG - 2011-04-15 09:21:11 --> Router Class Initialized
DEBUG - 2011-04-15 09:21:12 --> No URI present. Default controller set.
DEBUG - 2011-04-15 09:21:12 --> Output Class Initialized
DEBUG - 2011-04-15 09:21:12 --> Input Class Initialized
DEBUG - 2011-04-15 09:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:21:12 --> Language Class Initialized
DEBUG - 2011-04-15 09:21:12 --> Loader Class Initialized
DEBUG - 2011-04-15 09:21:12 --> Controller Class Initialized
DEBUG - 2011-04-15 09:21:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 09:21:12 --> Helper loaded: url_helper
DEBUG - 2011-04-15 09:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 09:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 09:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 09:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 09:21:12 --> Final output sent to browser
DEBUG - 2011-04-15 09:21:12 --> Total execution time: 1.0156
DEBUG - 2011-04-15 09:53:05 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:05 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:05 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:06 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:06 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Controller Class Initialized
ERROR - 2011-04-15 09:53:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 09:53:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:06 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:06 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:06 --> Helper loaded: url_helper
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 09:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 09:53:06 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:06 --> Total execution time: 0.4481
DEBUG - 2011-04-15 09:53:08 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:08 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:08 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Controller Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:08 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:08 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:08 --> Total execution time: 0.6367
DEBUG - 2011-04-15 09:53:25 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:25 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:25 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Controller Class Initialized
ERROR - 2011-04-15 09:53:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 09:53:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:25 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:25 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:25 --> Helper loaded: url_helper
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 09:53:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 09:53:25 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:25 --> Total execution time: 0.0413
DEBUG - 2011-04-15 09:53:26 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:26 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:26 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Controller Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:28 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:28 --> Total execution time: 1.3451
DEBUG - 2011-04-15 09:53:43 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:43 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:43 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Controller Class Initialized
ERROR - 2011-04-15 09:53:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 09:53:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:43 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:43 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:43 --> Helper loaded: url_helper
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 09:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 09:53:43 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:43 --> Total execution time: 0.0291
DEBUG - 2011-04-15 09:53:44 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:44 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:44 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Controller Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Config Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Hooks Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Utf8 Class Initialized
DEBUG - 2011-04-15 09:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 09:53:45 --> URI Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Router Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Output Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Input Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 09:53:45 --> Language Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Loader Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Controller Class Initialized
ERROR - 2011-04-15 09:53:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 09:53:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:45 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Model Class Initialized
DEBUG - 2011-04-15 09:53:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 09:53:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 09:53:45 --> Helper loaded: url_helper
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 09:53:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 09:53:45 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:45 --> Total execution time: 0.1421
DEBUG - 2011-04-15 09:53:46 --> Final output sent to browser
DEBUG - 2011-04-15 09:53:46 --> Total execution time: 1.9663
DEBUG - 2011-04-15 10:03:26 --> Config Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:03:26 --> URI Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Router Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Output Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Input Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:03:26 --> Language Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Loader Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Controller Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:03:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:03:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:03:28 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:03:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:03:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:03:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:03:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:03:28 --> Final output sent to browser
DEBUG - 2011-04-15 10:03:28 --> Total execution time: 2.1678
DEBUG - 2011-04-15 10:03:30 --> Config Class Initialized
DEBUG - 2011-04-15 10:03:30 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:03:30 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:03:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:03:30 --> URI Class Initialized
DEBUG - 2011-04-15 10:03:30 --> Router Class Initialized
ERROR - 2011-04-15 10:03:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 10:08:18 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:18 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Router Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Output Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Input Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:08:18 --> Language Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Loader Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Controller Class Initialized
ERROR - 2011-04-15 10:08:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:08:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:08:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:08:18 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:18 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:08:20 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:08:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:08:20 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:08:20 --> Final output sent to browser
DEBUG - 2011-04-15 10:08:20 --> Total execution time: 2.3151
DEBUG - 2011-04-15 10:08:21 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:21 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Router Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Output Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Input Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:08:21 --> Language Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Loader Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Controller Class Initialized
DEBUG - 2011-04-15 10:08:21 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:08:22 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:08:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:08:22 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:08:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:08:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:08:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:08:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:08:22 --> Final output sent to browser
DEBUG - 2011-04-15 10:08:22 --> Total execution time: 0.1218
DEBUG - 2011-04-15 10:08:22 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:22 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Router Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Output Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Input Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:08:22 --> Language Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Loader Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Controller Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:08:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:08:22 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:08:23 --> Final output sent to browser
DEBUG - 2011-04-15 10:08:23 --> Total execution time: 0.8622
DEBUG - 2011-04-15 10:08:31 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:31 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:31 --> Router Class Initialized
ERROR - 2011-04-15 10:08:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 10:08:32 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:32 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:32 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:32 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:32 --> Router Class Initialized
ERROR - 2011-04-15 10:08:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 10:08:33 --> Config Class Initialized
DEBUG - 2011-04-15 10:08:33 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:08:33 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:08:33 --> URI Class Initialized
DEBUG - 2011-04-15 10:08:33 --> Router Class Initialized
ERROR - 2011-04-15 10:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 10:09:24 --> Config Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:09:31 --> URI Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Router Class Initialized
DEBUG - 2011-04-15 10:09:31 --> No URI present. Default controller set.
DEBUG - 2011-04-15 10:09:31 --> Output Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Input Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:09:31 --> Language Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Loader Class Initialized
DEBUG - 2011-04-15 10:09:31 --> Controller Class Initialized
DEBUG - 2011-04-15 10:09:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 10:09:31 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:09:31 --> Final output sent to browser
DEBUG - 2011-04-15 10:09:31 --> Total execution time: 7.1554
DEBUG - 2011-04-15 10:09:55 --> Config Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:09:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:09:55 --> URI Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Router Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Output Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Input Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:09:55 --> Language Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Loader Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Controller Class Initialized
ERROR - 2011-04-15 10:09:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:09:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:09:55 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:09:55 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:09:55 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:09:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:09:55 --> Final output sent to browser
DEBUG - 2011-04-15 10:09:55 --> Total execution time: 0.0304
DEBUG - 2011-04-15 10:09:57 --> Config Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:09:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:09:57 --> URI Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Router Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Output Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Input Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:09:57 --> Language Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Loader Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Controller Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:09:57 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:09:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:09:57 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:09:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:09:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:09:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:09:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:09:57 --> Final output sent to browser
DEBUG - 2011-04-15 10:09:57 --> Total execution time: 0.4255
DEBUG - 2011-04-15 10:09:58 --> Config Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:09:58 --> URI Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Router Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Output Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Input Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:09:58 --> Language Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Loader Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Controller Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Model Class Initialized
DEBUG - 2011-04-15 10:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:09:58 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:09:59 --> Final output sent to browser
DEBUG - 2011-04-15 10:09:59 --> Total execution time: 0.5032
DEBUG - 2011-04-15 10:10:01 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:01 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:01 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Controller Class Initialized
ERROR - 2011-04-15 10:10:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:10:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:01 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:01 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:01 --> Total execution time: 0.1168
DEBUG - 2011-04-15 10:10:03 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:03 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:03 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:03 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:03 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:03 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Controller Class Initialized
ERROR - 2011-04-15 10:10:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:10:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:03 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:03 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:03 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:03 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:03 --> Total execution time: 0.1637
DEBUG - 2011-04-15 10:10:04 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:04 --> Total execution time: 1.5510
DEBUG - 2011-04-15 10:10:12 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:12 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:12 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Controller Class Initialized
ERROR - 2011-04-15 10:10:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:10:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:12 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:12 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:10:12 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:12 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:12 --> Total execution time: 0.0459
DEBUG - 2011-04-15 10:10:13 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:13 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:13 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:13 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:14 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:14 --> Total execution time: 0.6011
DEBUG - 2011-04-15 10:10:38 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:38 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:38 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:38 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:10:38 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:38 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:38 --> Total execution time: 0.1698
DEBUG - 2011-04-15 10:10:48 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:48 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:48 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:48 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:48 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:10:49 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:49 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:49 --> Total execution time: 0.1847
DEBUG - 2011-04-15 10:10:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:10:54 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:54 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:54 --> Total execution time: 6.1284
DEBUG - 2011-04-15 10:10:57 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:57 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:57 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:57 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:10:57 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:57 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:57 --> Total execution time: 0.1733
DEBUG - 2011-04-15 10:10:59 --> Config Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:10:59 --> URI Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Router Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Output Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Input Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:10:59 --> Language Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Loader Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Controller Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Model Class Initialized
DEBUG - 2011-04-15 10:10:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:10:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:10:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:10:59 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:10:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:10:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:10:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:10:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:10:59 --> Final output sent to browser
DEBUG - 2011-04-15 10:10:59 --> Total execution time: 0.2529
DEBUG - 2011-04-15 10:11:10 --> Config Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:11:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:11:10 --> URI Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Router Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Output Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Input Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:11:10 --> Language Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Loader Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Controller Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:11:10 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:11:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:11:11 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:11:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:11:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:11:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:11:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:11:11 --> Final output sent to browser
DEBUG - 2011-04-15 10:11:11 --> Total execution time: 1.1532
DEBUG - 2011-04-15 10:11:22 --> Config Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:11:22 --> URI Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Router Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Output Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Input Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:11:22 --> Language Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Loader Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Controller Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:11:22 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:11:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:11:23 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:11:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:11:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:11:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:11:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:11:23 --> Final output sent to browser
DEBUG - 2011-04-15 10:11:23 --> Total execution time: 1.3203
DEBUG - 2011-04-15 10:11:44 --> Config Class Initialized
DEBUG - 2011-04-15 10:11:57 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:11:57 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:11:57 --> URI Class Initialized
DEBUG - 2011-04-15 10:11:57 --> Router Class Initialized
DEBUG - 2011-04-15 10:11:57 --> Output Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Input Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:11:58 --> Language Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Loader Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Controller Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Model Class Initialized
DEBUG - 2011-04-15 10:11:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:11:58 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:11:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:11:59 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:11:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:11:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:11:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:11:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:11:59 --> Final output sent to browser
DEBUG - 2011-04-15 10:11:59 --> Total execution time: 15.1067
DEBUG - 2011-04-15 10:12:18 --> Config Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:12:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:12:18 --> URI Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Router Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Output Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Input Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:12:18 --> Language Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Loader Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Controller Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:12:18 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:12:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:12:19 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:12:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:12:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:12:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:12:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:12:19 --> Final output sent to browser
DEBUG - 2011-04-15 10:12:19 --> Total execution time: 1.0220
DEBUG - 2011-04-15 10:12:27 --> Config Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:12:27 --> URI Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Router Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Output Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Input Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:12:27 --> Language Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Loader Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Controller Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:12:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:12:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:12:27 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:12:27 --> Final output sent to browser
DEBUG - 2011-04-15 10:12:27 --> Total execution time: 0.7181
DEBUG - 2011-04-15 10:12:41 --> Config Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:12:41 --> URI Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Router Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Output Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Input Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:12:41 --> Language Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Loader Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Controller Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:12:41 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:12:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:12:41 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:12:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:12:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:12:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:12:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:12:41 --> Final output sent to browser
DEBUG - 2011-04-15 10:12:41 --> Total execution time: 0.7870
DEBUG - 2011-04-15 10:12:46 --> Config Class Initialized
DEBUG - 2011-04-15 10:12:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:12:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:12:46 --> URI Class Initialized
DEBUG - 2011-04-15 10:12:46 --> Router Class Initialized
DEBUG - 2011-04-15 10:12:46 --> Output Class Initialized
DEBUG - 2011-04-15 10:12:46 --> Input Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:12:48 --> Language Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Loader Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Controller Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:12:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:12:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:12:48 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:12:48 --> Final output sent to browser
DEBUG - 2011-04-15 10:12:48 --> Total execution time: 1.6446
DEBUG - 2011-04-15 10:12:52 --> Config Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:12:52 --> URI Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Router Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Output Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Input Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:12:52 --> Language Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Loader Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Controller Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Model Class Initialized
DEBUG - 2011-04-15 10:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:12:52 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:12:53 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:12:53 --> Final output sent to browser
DEBUG - 2011-04-15 10:12:53 --> Total execution time: 0.9456
DEBUG - 2011-04-15 10:13:07 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:07 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:07 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:07 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:07 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:07 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:07 --> Total execution time: 0.0826
DEBUG - 2011-04-15 10:13:07 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:07 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:07 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:07 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:07 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:07 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:07 --> Total execution time: 0.2952
DEBUG - 2011-04-15 10:13:25 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:25 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:25 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:25 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:26 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:26 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:26 --> Total execution time: 3.0223
DEBUG - 2011-04-15 10:13:46 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:46 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:46 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:46 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:46 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:46 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:46 --> Total execution time: 0.0983
DEBUG - 2011-04-15 10:13:46 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:46 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:46 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:46 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:46 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:46 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:46 --> Total execution time: 0.0698
DEBUG - 2011-04-15 10:13:46 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:46 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:46 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:46 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:46 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:46 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:46 --> Total execution time: 0.0572
DEBUG - 2011-04-15 10:13:48 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:48 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:48 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:48 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:48 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:48 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:48 --> Total execution time: 0.0716
DEBUG - 2011-04-15 10:13:51 --> Config Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:13:51 --> URI Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Router Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Output Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Input Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:13:51 --> Language Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Loader Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Controller Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Model Class Initialized
DEBUG - 2011-04-15 10:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:13:51 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:13:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 10:13:51 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:13:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:13:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:13:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:13:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:13:51 --> Final output sent to browser
DEBUG - 2011-04-15 10:13:51 --> Total execution time: 0.0565
DEBUG - 2011-04-15 10:56:59 --> Config Class Initialized
DEBUG - 2011-04-15 10:56:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:56:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:56:59 --> URI Class Initialized
DEBUG - 2011-04-15 10:56:59 --> Router Class Initialized
DEBUG - 2011-04-15 10:56:59 --> Output Class Initialized
DEBUG - 2011-04-15 10:57:00 --> Input Class Initialized
DEBUG - 2011-04-15 10:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:57:00 --> Language Class Initialized
DEBUG - 2011-04-15 10:57:00 --> Loader Class Initialized
DEBUG - 2011-04-15 10:57:00 --> Controller Class Initialized
ERROR - 2011-04-15 10:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 10:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 10:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:57:00 --> Model Class Initialized
DEBUG - 2011-04-15 10:57:01 --> Model Class Initialized
DEBUG - 2011-04-15 10:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:57:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 10:57:06 --> Helper loaded: url_helper
DEBUG - 2011-04-15 10:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 10:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 10:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 10:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 10:57:06 --> Final output sent to browser
DEBUG - 2011-04-15 10:57:06 --> Total execution time: 7.0607
DEBUG - 2011-04-15 10:57:10 --> Config Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Hooks Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Utf8 Class Initialized
DEBUG - 2011-04-15 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 10:57:10 --> URI Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Router Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Output Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Input Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 10:57:10 --> Language Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Loader Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Controller Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Model Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Model Class Initialized
DEBUG - 2011-04-15 10:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 10:57:10 --> Database Driver Class Initialized
DEBUG - 2011-04-15 10:57:12 --> Final output sent to browser
DEBUG - 2011-04-15 10:57:12 --> Total execution time: 2.6958
DEBUG - 2011-04-15 11:07:37 --> Config Class Initialized
DEBUG - 2011-04-15 11:07:37 --> Hooks Class Initialized
DEBUG - 2011-04-15 11:07:37 --> Utf8 Class Initialized
DEBUG - 2011-04-15 11:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 11:07:37 --> URI Class Initialized
DEBUG - 2011-04-15 11:07:37 --> Router Class Initialized
DEBUG - 2011-04-15 11:07:38 --> No URI present. Default controller set.
DEBUG - 2011-04-15 11:07:38 --> Output Class Initialized
DEBUG - 2011-04-15 11:07:38 --> Input Class Initialized
DEBUG - 2011-04-15 11:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 11:07:38 --> Language Class Initialized
DEBUG - 2011-04-15 11:07:38 --> Loader Class Initialized
DEBUG - 2011-04-15 11:07:38 --> Controller Class Initialized
DEBUG - 2011-04-15 11:07:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 11:07:39 --> Helper loaded: url_helper
DEBUG - 2011-04-15 11:07:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 11:07:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 11:07:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 11:07:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 11:07:40 --> Final output sent to browser
DEBUG - 2011-04-15 11:07:40 --> Total execution time: 5.8488
DEBUG - 2011-04-15 11:19:30 --> Config Class Initialized
DEBUG - 2011-04-15 11:19:30 --> Hooks Class Initialized
DEBUG - 2011-04-15 11:19:30 --> Utf8 Class Initialized
DEBUG - 2011-04-15 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 11:19:30 --> URI Class Initialized
DEBUG - 2011-04-15 11:19:30 --> Router Class Initialized
ERROR - 2011-04-15 11:19:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 11:19:31 --> Config Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 11:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 11:19:31 --> URI Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Router Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Output Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Input Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 11:19:31 --> Language Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Loader Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Controller Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Model Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Model Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Model Class Initialized
DEBUG - 2011-04-15 11:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 11:19:34 --> Database Driver Class Initialized
DEBUG - 2011-04-15 11:19:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 11:19:38 --> Helper loaded: url_helper
DEBUG - 2011-04-15 11:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 11:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 11:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 11:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 11:19:38 --> Final output sent to browser
DEBUG - 2011-04-15 11:19:38 --> Total execution time: 7.5370
DEBUG - 2011-04-15 11:20:09 --> Config Class Initialized
DEBUG - 2011-04-15 11:20:09 --> Hooks Class Initialized
DEBUG - 2011-04-15 11:20:09 --> Utf8 Class Initialized
DEBUG - 2011-04-15 11:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 11:20:09 --> URI Class Initialized
DEBUG - 2011-04-15 11:20:09 --> Router Class Initialized
DEBUG - 2011-04-15 11:20:10 --> Output Class Initialized
DEBUG - 2011-04-15 11:20:10 --> Input Class Initialized
DEBUG - 2011-04-15 11:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 11:20:10 --> Language Class Initialized
DEBUG - 2011-04-15 11:20:10 --> Loader Class Initialized
DEBUG - 2011-04-15 11:20:10 --> Controller Class Initialized
ERROR - 2011-04-15 11:20:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 11:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 11:20:12 --> Model Class Initialized
DEBUG - 2011-04-15 11:20:12 --> Model Class Initialized
DEBUG - 2011-04-15 11:20:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 11:20:12 --> Database Driver Class Initialized
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 11:20:12 --> Helper loaded: url_helper
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 11:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 11:20:12 --> Final output sent to browser
DEBUG - 2011-04-15 11:20:12 --> Total execution time: 3.3835
DEBUG - 2011-04-15 11:42:02 --> Config Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Hooks Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Utf8 Class Initialized
DEBUG - 2011-04-15 11:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 11:42:03 --> URI Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Router Class Initialized
DEBUG - 2011-04-15 11:42:03 --> No URI present. Default controller set.
DEBUG - 2011-04-15 11:42:03 --> Output Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Input Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 11:42:03 --> Language Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Loader Class Initialized
DEBUG - 2011-04-15 11:42:03 --> Controller Class Initialized
DEBUG - 2011-04-15 11:42:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 11:42:04 --> Helper loaded: url_helper
DEBUG - 2011-04-15 11:42:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 11:42:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 11:42:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 11:42:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 11:42:04 --> Final output sent to browser
DEBUG - 2011-04-15 11:42:04 --> Total execution time: 1.8013
DEBUG - 2011-04-15 13:19:24 --> Config Class Initialized
DEBUG - 2011-04-15 13:19:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 13:19:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 13:19:25 --> URI Class Initialized
DEBUG - 2011-04-15 13:19:26 --> Router Class Initialized
ERROR - 2011-04-15 13:19:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 13:19:26 --> Config Class Initialized
DEBUG - 2011-04-15 13:19:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 13:19:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 13:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 13:19:26 --> URI Class Initialized
DEBUG - 2011-04-15 13:19:26 --> Router Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Output Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Input Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 13:19:27 --> Language Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Loader Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Controller Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Model Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Model Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Model Class Initialized
DEBUG - 2011-04-15 13:19:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 13:19:27 --> Database Driver Class Initialized
DEBUG - 2011-04-15 13:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 13:19:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 13:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 13:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 13:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 13:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 13:19:29 --> Final output sent to browser
DEBUG - 2011-04-15 13:19:29 --> Total execution time: 2.3949
DEBUG - 2011-04-15 13:45:05 --> Config Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Utf8 Class Initialized
DEBUG - 2011-04-15 13:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 13:45:05 --> URI Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Router Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Output Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Input Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 13:45:05 --> Language Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Loader Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Controller Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Model Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Model Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Model Class Initialized
DEBUG - 2011-04-15 13:45:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 13:45:05 --> Database Driver Class Initialized
DEBUG - 2011-04-15 13:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 13:45:06 --> Helper loaded: url_helper
DEBUG - 2011-04-15 13:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 13:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 13:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 13:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 13:45:06 --> Final output sent to browser
DEBUG - 2011-04-15 13:45:06 --> Total execution time: 0.5557
DEBUG - 2011-04-15 13:45:08 --> Config Class Initialized
DEBUG - 2011-04-15 13:45:08 --> Hooks Class Initialized
DEBUG - 2011-04-15 13:45:08 --> Utf8 Class Initialized
DEBUG - 2011-04-15 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 13:45:08 --> URI Class Initialized
DEBUG - 2011-04-15 13:45:08 --> Router Class Initialized
ERROR - 2011-04-15 13:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 14:39:25 --> Config Class Initialized
DEBUG - 2011-04-15 14:39:25 --> Hooks Class Initialized
DEBUG - 2011-04-15 14:39:25 --> Utf8 Class Initialized
DEBUG - 2011-04-15 14:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 14:39:25 --> URI Class Initialized
DEBUG - 2011-04-15 14:39:25 --> Router Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Output Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Input Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 14:39:26 --> Language Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Loader Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Controller Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Model Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Model Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Model Class Initialized
DEBUG - 2011-04-15 14:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 14:39:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 14:39:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 14:39:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 14:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 14:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 14:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 14:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 14:39:26 --> Final output sent to browser
DEBUG - 2011-04-15 14:39:26 --> Total execution time: 1.9225
DEBUG - 2011-04-15 14:39:27 --> Config Class Initialized
DEBUG - 2011-04-15 14:39:27 --> Hooks Class Initialized
DEBUG - 2011-04-15 14:39:27 --> Utf8 Class Initialized
DEBUG - 2011-04-15 14:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 14:39:27 --> URI Class Initialized
DEBUG - 2011-04-15 14:39:27 --> Router Class Initialized
ERROR - 2011-04-15 14:39:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 14:39:28 --> Config Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 14:39:28 --> URI Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Router Class Initialized
ERROR - 2011-04-15 14:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 14:39:28 --> Config Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 14:39:28 --> URI Class Initialized
DEBUG - 2011-04-15 14:39:28 --> Router Class Initialized
ERROR - 2011-04-15 14:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 15:41:41 --> Config Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Hooks Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Utf8 Class Initialized
DEBUG - 2011-04-15 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 15:41:41 --> URI Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Router Class Initialized
ERROR - 2011-04-15 15:41:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 15:41:41 --> Config Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Hooks Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Utf8 Class Initialized
DEBUG - 2011-04-15 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 15:41:41 --> URI Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Router Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Output Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Input Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 15:41:41 --> Language Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Loader Class Initialized
DEBUG - 2011-04-15 15:41:41 --> Controller Class Initialized
ERROR - 2011-04-15 15:41:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 15:41:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 15:41:42 --> Model Class Initialized
DEBUG - 2011-04-15 15:41:42 --> Model Class Initialized
DEBUG - 2011-04-15 15:41:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 15:41:42 --> Database Driver Class Initialized
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 15:41:42 --> Helper loaded: url_helper
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 15:41:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 15:41:42 --> Final output sent to browser
DEBUG - 2011-04-15 15:41:42 --> Total execution time: 0.3797
DEBUG - 2011-04-15 15:42:53 --> Config Class Initialized
DEBUG - 2011-04-15 15:42:53 --> Hooks Class Initialized
DEBUG - 2011-04-15 15:42:53 --> Utf8 Class Initialized
DEBUG - 2011-04-15 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 15:42:53 --> URI Class Initialized
DEBUG - 2011-04-15 15:42:53 --> Router Class Initialized
ERROR - 2011-04-15 15:42:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 15:42:55 --> Config Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Hooks Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Utf8 Class Initialized
DEBUG - 2011-04-15 15:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 15:42:55 --> URI Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Router Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Output Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Input Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 15:42:55 --> Language Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Loader Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Controller Class Initialized
ERROR - 2011-04-15 15:42:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 15:42:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 15:42:55 --> Model Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Model Class Initialized
DEBUG - 2011-04-15 15:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 15:42:55 --> Database Driver Class Initialized
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 15:42:55 --> Helper loaded: url_helper
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 15:42:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 15:42:55 --> Final output sent to browser
DEBUG - 2011-04-15 15:42:55 --> Total execution time: 0.0408
DEBUG - 2011-04-15 15:58:58 --> Config Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Hooks Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Utf8 Class Initialized
DEBUG - 2011-04-15 15:58:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 15:58:58 --> URI Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Router Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Output Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Input Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 15:58:58 --> Language Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Loader Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Controller Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Model Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Model Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Model Class Initialized
DEBUG - 2011-04-15 15:58:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 15:58:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 15:58:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 15:58:59 --> Helper loaded: url_helper
DEBUG - 2011-04-15 15:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 15:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 15:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 15:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 15:58:59 --> Final output sent to browser
DEBUG - 2011-04-15 15:58:59 --> Total execution time: 0.3076
DEBUG - 2011-04-15 16:16:56 --> Config Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Hooks Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Utf8 Class Initialized
DEBUG - 2011-04-15 16:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 16:16:56 --> URI Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Router Class Initialized
DEBUG - 2011-04-15 16:16:56 --> No URI present. Default controller set.
DEBUG - 2011-04-15 16:16:56 --> Output Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Input Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 16:16:56 --> Language Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Loader Class Initialized
DEBUG - 2011-04-15 16:16:56 --> Controller Class Initialized
DEBUG - 2011-04-15 16:16:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 16:16:56 --> Helper loaded: url_helper
DEBUG - 2011-04-15 16:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 16:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 16:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 16:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 16:16:56 --> Final output sent to browser
DEBUG - 2011-04-15 16:16:56 --> Total execution time: 0.1258
DEBUG - 2011-04-15 17:25:44 --> Config Class Initialized
DEBUG - 2011-04-15 17:25:44 --> Hooks Class Initialized
DEBUG - 2011-04-15 17:25:44 --> Utf8 Class Initialized
DEBUG - 2011-04-15 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 17:25:44 --> URI Class Initialized
DEBUG - 2011-04-15 17:25:44 --> Router Class Initialized
ERROR - 2011-04-15 17:25:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 17:50:53 --> Config Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Hooks Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Utf8 Class Initialized
DEBUG - 2011-04-15 17:50:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 17:50:53 --> URI Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Router Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Output Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Input Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 17:50:53 --> Language Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Loader Class Initialized
DEBUG - 2011-04-15 17:50:53 --> Controller Class Initialized
ERROR - 2011-04-15 17:50:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 17:50:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 17:50:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 17:50:53 --> Model Class Initialized
DEBUG - 2011-04-15 17:50:54 --> Model Class Initialized
DEBUG - 2011-04-15 17:50:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 17:50:54 --> Database Driver Class Initialized
DEBUG - 2011-04-15 17:50:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 17:50:54 --> Helper loaded: url_helper
DEBUG - 2011-04-15 17:50:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 17:50:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 17:50:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 17:50:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 17:50:54 --> Final output sent to browser
DEBUG - 2011-04-15 17:50:54 --> Total execution time: 0.3083
DEBUG - 2011-04-15 17:51:46 --> Config Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 17:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 17:51:46 --> URI Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Router Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Output Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Input Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 17:51:46 --> Language Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Loader Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Controller Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Model Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Model Class Initialized
DEBUG - 2011-04-15 17:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 17:51:46 --> Database Driver Class Initialized
DEBUG - 2011-04-15 17:51:47 --> Final output sent to browser
DEBUG - 2011-04-15 17:51:47 --> Total execution time: 0.6959
DEBUG - 2011-04-15 21:26:00 --> Config Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Hooks Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Utf8 Class Initialized
DEBUG - 2011-04-15 21:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 21:26:00 --> URI Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Router Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Output Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Input Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 21:26:00 --> Language Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Loader Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Controller Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 21:26:00 --> Database Driver Class Initialized
DEBUG - 2011-04-15 21:26:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 21:26:01 --> Helper loaded: url_helper
DEBUG - 2011-04-15 21:26:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 21:26:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 21:26:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 21:26:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 21:26:01 --> Final output sent to browser
DEBUG - 2011-04-15 21:26:01 --> Total execution time: 1.9340
DEBUG - 2011-04-15 21:26:47 --> Config Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 21:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 21:26:47 --> URI Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Router Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Output Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Input Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 21:26:47 --> Language Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Loader Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Controller Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 21:26:47 --> Database Driver Class Initialized
DEBUG - 2011-04-15 21:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 21:26:47 --> Helper loaded: url_helper
DEBUG - 2011-04-15 21:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 21:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 21:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 21:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 21:26:47 --> Final output sent to browser
DEBUG - 2011-04-15 21:26:47 --> Total execution time: 0.0910
DEBUG - 2011-04-15 21:26:51 --> Config Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Hooks Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Utf8 Class Initialized
DEBUG - 2011-04-15 21:26:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 21:26:51 --> URI Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Router Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Output Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Input Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 21:26:51 --> Language Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Loader Class Initialized
DEBUG - 2011-04-15 21:26:51 --> Controller Class Initialized
ERROR - 2011-04-15 21:26:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 21:26:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 21:26:52 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:52 --> Model Class Initialized
DEBUG - 2011-04-15 21:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 21:26:52 --> Database Driver Class Initialized
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 21:26:52 --> Helper loaded: url_helper
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 21:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 21:26:52 --> Final output sent to browser
DEBUG - 2011-04-15 21:26:52 --> Total execution time: 1.2733
DEBUG - 2011-04-15 21:48:31 --> Config Class Initialized
DEBUG - 2011-04-15 21:48:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 21:48:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 21:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 21:48:31 --> URI Class Initialized
DEBUG - 2011-04-15 21:48:31 --> Router Class Initialized
ERROR - 2011-04-15 21:48:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 21:48:32 --> Config Class Initialized
DEBUG - 2011-04-15 21:48:32 --> Hooks Class Initialized
DEBUG - 2011-04-15 21:48:32 --> Utf8 Class Initialized
DEBUG - 2011-04-15 21:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 21:48:32 --> URI Class Initialized
DEBUG - 2011-04-15 21:48:32 --> Router Class Initialized
DEBUG - 2011-04-15 21:48:32 --> No URI present. Default controller set.
DEBUG - 2011-04-15 21:48:32 --> Output Class Initialized
DEBUG - 2011-04-15 21:48:32 --> Input Class Initialized
DEBUG - 2011-04-15 21:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 21:48:32 --> Language Class Initialized
DEBUG - 2011-04-15 21:48:33 --> Loader Class Initialized
DEBUG - 2011-04-15 21:48:33 --> Controller Class Initialized
DEBUG - 2011-04-15 21:48:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 21:48:33 --> Helper loaded: url_helper
DEBUG - 2011-04-15 21:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 21:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 21:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 21:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 21:48:33 --> Final output sent to browser
DEBUG - 2011-04-15 21:48:33 --> Total execution time: 1.1473
DEBUG - 2011-04-15 22:09:23 --> Config Class Initialized
DEBUG - 2011-04-15 22:09:23 --> Hooks Class Initialized
DEBUG - 2011-04-15 22:09:23 --> Utf8 Class Initialized
DEBUG - 2011-04-15 22:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 22:09:23 --> URI Class Initialized
DEBUG - 2011-04-15 22:09:23 --> Router Class Initialized
ERROR - 2011-04-15 22:09:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 22:09:24 --> Config Class Initialized
DEBUG - 2011-04-15 22:09:24 --> Hooks Class Initialized
DEBUG - 2011-04-15 22:09:24 --> Utf8 Class Initialized
DEBUG - 2011-04-15 22:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 22:09:24 --> URI Class Initialized
DEBUG - 2011-04-15 22:09:24 --> Router Class Initialized
DEBUG - 2011-04-15 22:09:25 --> Output Class Initialized
DEBUG - 2011-04-15 22:09:25 --> Input Class Initialized
DEBUG - 2011-04-15 22:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 22:09:26 --> Language Class Initialized
DEBUG - 2011-04-15 22:09:26 --> Loader Class Initialized
DEBUG - 2011-04-15 22:09:26 --> Controller Class Initialized
ERROR - 2011-04-15 22:09:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 22:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 22:09:26 --> Model Class Initialized
DEBUG - 2011-04-15 22:09:26 --> Model Class Initialized
DEBUG - 2011-04-15 22:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 22:09:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 22:09:26 --> Helper loaded: url_helper
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 22:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 22:09:26 --> Final output sent to browser
DEBUG - 2011-04-15 22:09:26 --> Total execution time: 2.2909
DEBUG - 2011-04-15 22:09:28 --> Config Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 22:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 22:09:28 --> URI Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Router Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Output Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Input Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 22:09:28 --> Language Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Loader Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Controller Class Initialized
DEBUG - 2011-04-15 22:09:28 --> Model Class Initialized
DEBUG - 2011-04-15 22:09:29 --> Model Class Initialized
DEBUG - 2011-04-15 22:09:29 --> Model Class Initialized
DEBUG - 2011-04-15 22:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 22:09:29 --> Database Driver Class Initialized
DEBUG - 2011-04-15 22:09:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 22:09:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 22:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 22:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 22:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 22:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 22:09:29 --> Final output sent to browser
DEBUG - 2011-04-15 22:09:29 --> Total execution time: 0.4652
DEBUG - 2011-04-15 22:41:59 --> Config Class Initialized
DEBUG - 2011-04-15 22:41:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 22:41:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 22:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 22:41:59 --> URI Class Initialized
DEBUG - 2011-04-15 22:41:59 --> Router Class Initialized
ERROR - 2011-04-15 22:41:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-15 23:03:40 --> Config Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:03:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:03:40 --> URI Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Router Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Output Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Input Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:03:40 --> Language Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Loader Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Controller Class Initialized
ERROR - 2011-04-15 23:03:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:03:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:03:40 --> Model Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Model Class Initialized
DEBUG - 2011-04-15 23:03:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:03:40 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:03:40 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:03:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:03:40 --> Final output sent to browser
DEBUG - 2011-04-15 23:03:40 --> Total execution time: 0.3144
DEBUG - 2011-04-15 23:03:44 --> Config Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:03:44 --> URI Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Router Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Output Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Input Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:03:44 --> Language Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Loader Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Controller Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Model Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Model Class Initialized
DEBUG - 2011-04-15 23:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:03:44 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:03:45 --> Final output sent to browser
DEBUG - 2011-04-15 23:03:45 --> Total execution time: 0.6161
DEBUG - 2011-04-15 23:03:50 --> Config Class Initialized
DEBUG - 2011-04-15 23:03:50 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:03:50 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:03:50 --> URI Class Initialized
DEBUG - 2011-04-15 23:03:50 --> Router Class Initialized
ERROR - 2011-04-15 23:03:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:04:28 --> Config Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:04:28 --> URI Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Router Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Output Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Input Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:04:28 --> Language Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Loader Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Controller Class Initialized
ERROR - 2011-04-15 23:04:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:04:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:04:28 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:04:28 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:04:28 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:04:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:04:28 --> Final output sent to browser
DEBUG - 2011-04-15 23:04:28 --> Total execution time: 0.0303
DEBUG - 2011-04-15 23:04:31 --> Config Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:04:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:04:31 --> URI Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Router Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Output Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Input Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:04:31 --> Language Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Loader Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Controller Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:04:31 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:04:32 --> Final output sent to browser
DEBUG - 2011-04-15 23:04:32 --> Total execution time: 0.5737
DEBUG - 2011-04-15 23:04:38 --> Config Class Initialized
DEBUG - 2011-04-15 23:04:38 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:04:38 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:04:38 --> URI Class Initialized
DEBUG - 2011-04-15 23:04:38 --> Router Class Initialized
ERROR - 2011-04-15 23:04:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:04:46 --> Config Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:04:46 --> URI Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Router Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Output Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Input Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:04:46 --> Language Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Loader Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Controller Class Initialized
ERROR - 2011-04-15 23:04:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:04:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:04:46 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:04:46 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:04:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:04:46 --> Final output sent to browser
DEBUG - 2011-04-15 23:04:46 --> Total execution time: 0.0283
DEBUG - 2011-04-15 23:04:47 --> Config Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:04:47 --> URI Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Router Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Output Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Input Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:04:47 --> Language Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Loader Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Controller Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Model Class Initialized
DEBUG - 2011-04-15 23:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:04:47 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:04:48 --> Final output sent to browser
DEBUG - 2011-04-15 23:04:48 --> Total execution time: 0.5076
DEBUG - 2011-04-15 23:05:36 --> Config Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:05:36 --> URI Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Router Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Output Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Input Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:05:36 --> Language Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Loader Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Controller Class Initialized
ERROR - 2011-04-15 23:05:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:05:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:05:36 --> Model Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Model Class Initialized
DEBUG - 2011-04-15 23:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:05:36 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:05:36 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:05:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:05:36 --> Final output sent to browser
DEBUG - 2011-04-15 23:05:36 --> Total execution time: 0.2332
DEBUG - 2011-04-15 23:05:42 --> Config Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:05:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:05:42 --> URI Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Router Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Output Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Input Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:05:42 --> Language Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Loader Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Controller Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Model Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Model Class Initialized
DEBUG - 2011-04-15 23:05:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:05:42 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:05:43 --> Final output sent to browser
DEBUG - 2011-04-15 23:05:43 --> Total execution time: 1.0186
DEBUG - 2011-04-15 23:05:45 --> Config Class Initialized
DEBUG - 2011-04-15 23:05:45 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:05:45 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:05:45 --> URI Class Initialized
DEBUG - 2011-04-15 23:05:45 --> Router Class Initialized
ERROR - 2011-04-15 23:05:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:05:49 --> Config Class Initialized
DEBUG - 2011-04-15 23:05:49 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:05:49 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:05:49 --> URI Class Initialized
DEBUG - 2011-04-15 23:05:49 --> Router Class Initialized
ERROR - 2011-04-15 23:05:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:06:13 --> Config Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:06:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:06:13 --> URI Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Router Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Output Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Input Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:06:13 --> Language Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Loader Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Controller Class Initialized
ERROR - 2011-04-15 23:06:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:06:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:06:13 --> Model Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Model Class Initialized
DEBUG - 2011-04-15 23:06:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:06:13 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:06:13 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:06:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:06:13 --> Final output sent to browser
DEBUG - 2011-04-15 23:06:13 --> Total execution time: 0.0683
DEBUG - 2011-04-15 23:06:14 --> Config Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:06:14 --> URI Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Router Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Output Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Input Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:06:14 --> Language Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Loader Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Controller Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:06:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:06:14 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:06:15 --> Final output sent to browser
DEBUG - 2011-04-15 23:06:15 --> Total execution time: 0.6747
DEBUG - 2011-04-15 23:06:19 --> Config Class Initialized
DEBUG - 2011-04-15 23:06:19 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:06:19 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:06:19 --> URI Class Initialized
DEBUG - 2011-04-15 23:06:19 --> Router Class Initialized
ERROR - 2011-04-15 23:06:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:09:12 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:12 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:12 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Controller Class Initialized
ERROR - 2011-04-15 23:09:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:12 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:12 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:12 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:09:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:09:12 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:12 --> Total execution time: 0.0564
DEBUG - 2011-04-15 23:09:14 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:14 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:14 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Controller Class Initialized
ERROR - 2011-04-15 23:09:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:09:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:14 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:14 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:09:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:09:14 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:14 --> Total execution time: 0.0275
DEBUG - 2011-04-15 23:09:14 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:14 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:14 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Controller Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:14 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:15 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:15 --> Total execution time: 0.6208
DEBUG - 2011-04-15 23:09:18 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:18 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:18 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:18 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:18 --> Router Class Initialized
ERROR - 2011-04-15 23:09:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:09:29 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:29 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:29 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Controller Class Initialized
ERROR - 2011-04-15 23:09:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:09:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:29 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:29 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:29 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:09:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:09:29 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:29 --> Total execution time: 0.0385
DEBUG - 2011-04-15 23:09:32 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:32 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:32 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Controller Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:32 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:32 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:32 --> Total execution time: 0.6099
DEBUG - 2011-04-15 23:09:36 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:36 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:36 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:36 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:36 --> Router Class Initialized
ERROR - 2011-04-15 23:09:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:09:45 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:45 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:45 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Controller Class Initialized
ERROR - 2011-04-15 23:09:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:45 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:45 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:45 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:09:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:09:45 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:45 --> Total execution time: 0.0315
DEBUG - 2011-04-15 23:09:47 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:47 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:47 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Controller Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:47 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:47 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:47 --> Total execution time: 0.6688
DEBUG - 2011-04-15 23:09:53 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:53 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:53 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:53 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:53 --> Router Class Initialized
ERROR - 2011-04-15 23:09:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:09:59 --> Config Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:09:59 --> URI Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Router Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Output Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Input Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:09:59 --> Language Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Loader Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Controller Class Initialized
ERROR - 2011-04-15 23:09:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:09:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:59 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Model Class Initialized
DEBUG - 2011-04-15 23:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:09:59 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:09:59 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:09:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:09:59 --> Final output sent to browser
DEBUG - 2011-04-15 23:09:59 --> Total execution time: 0.0335
DEBUG - 2011-04-15 23:10:01 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:01 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Router Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Output Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Input Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:10:01 --> Language Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Loader Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Controller Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:10:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Final output sent to browser
DEBUG - 2011-04-15 23:10:01 --> Total execution time: 0.5757
DEBUG - 2011-04-15 23:10:01 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:01 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Router Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Output Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Input Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:10:01 --> Language Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Loader Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Controller Class Initialized
ERROR - 2011-04-15 23:10:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:10:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:10:01 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:10:01 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:10:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:10:01 --> Final output sent to browser
DEBUG - 2011-04-15 23:10:01 --> Total execution time: 0.0313
DEBUG - 2011-04-15 23:10:06 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:06 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:06 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:06 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:06 --> Router Class Initialized
ERROR - 2011-04-15 23:10:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:10:23 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:23 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:23 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:23 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Router Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Output Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Input Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:10:24 --> Language Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Loader Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Controller Class Initialized
ERROR - 2011-04-15 23:10:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:10:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:10:24 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:10:24 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:10:24 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:10:24 --> Final output sent to browser
DEBUG - 2011-04-15 23:10:24 --> Total execution time: 0.0304
DEBUG - 2011-04-15 23:10:26 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:26 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Router Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Output Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Input Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:10:26 --> Language Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Loader Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Controller Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Model Class Initialized
DEBUG - 2011-04-15 23:10:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:10:26 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:10:27 --> Final output sent to browser
DEBUG - 2011-04-15 23:10:27 --> Total execution time: 0.8251
DEBUG - 2011-04-15 23:10:29 --> Config Class Initialized
DEBUG - 2011-04-15 23:10:29 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:10:29 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:10:29 --> URI Class Initialized
DEBUG - 2011-04-15 23:10:29 --> Router Class Initialized
ERROR - 2011-04-15 23:10:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-15 23:23:33 --> Config Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:23:33 --> URI Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Router Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Output Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Input Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:23:33 --> Language Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Loader Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Controller Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Model Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Model Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Model Class Initialized
DEBUG - 2011-04-15 23:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:23:33 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:23:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-15 23:23:33 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:23:33 --> Final output sent to browser
DEBUG - 2011-04-15 23:23:33 --> Total execution time: 0.2422
DEBUG - 2011-04-15 23:23:42 --> Config Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:23:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:23:42 --> URI Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Router Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Output Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Input Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:23:42 --> Language Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Loader Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Controller Class Initialized
ERROR - 2011-04-15 23:23:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-15 23:23:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:23:42 --> Model Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Model Class Initialized
DEBUG - 2011-04-15 23:23:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-15 23:23:42 --> Database Driver Class Initialized
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-15 23:23:42 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:23:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:23:42 --> Final output sent to browser
DEBUG - 2011-04-15 23:23:42 --> Total execution time: 0.0298
DEBUG - 2011-04-15 23:56:24 --> Config Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Hooks Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Utf8 Class Initialized
DEBUG - 2011-04-15 23:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-15 23:56:24 --> URI Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Router Class Initialized
DEBUG - 2011-04-15 23:56:24 --> No URI present. Default controller set.
DEBUG - 2011-04-15 23:56:24 --> Output Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Input Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-15 23:56:24 --> Language Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Loader Class Initialized
DEBUG - 2011-04-15 23:56:24 --> Controller Class Initialized
DEBUG - 2011-04-15 23:56:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-15 23:56:24 --> Helper loaded: url_helper
DEBUG - 2011-04-15 23:56:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-15 23:56:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-15 23:56:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-15 23:56:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-15 23:56:24 --> Final output sent to browser
DEBUG - 2011-04-15 23:56:24 --> Total execution time: 0.0617

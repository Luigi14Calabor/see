<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-04-12 00:00:02 --> Config Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:00:02 --> URI Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Router Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Output Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Input Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:00:02 --> Language Class Initialized
DEBUG - 2011-04-12 00:00:02 --> Loader Class Initialized
DEBUG - 2011-04-12 00:00:03 --> Controller Class Initialized
DEBUG - 2011-04-12 00:00:03 --> Model Class Initialized
DEBUG - 2011-04-12 00:00:03 --> Model Class Initialized
DEBUG - 2011-04-12 00:00:03 --> Model Class Initialized
DEBUG - 2011-04-12 00:00:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:00:03 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:00:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:00:07 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:00:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:00:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:00:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:00:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:00:07 --> Final output sent to browser
DEBUG - 2011-04-12 00:00:07 --> Total execution time: 5.0580
DEBUG - 2011-04-12 00:00:13 --> Config Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:00:13 --> URI Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Router Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Output Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Input Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:00:13 --> Language Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Loader Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Controller Class Initialized
ERROR - 2011-04-12 00:00:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:00:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:00:13 --> Model Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Model Class Initialized
DEBUG - 2011-04-12 00:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:00:13 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:00:13 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:00:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:00:13 --> Final output sent to browser
DEBUG - 2011-04-12 00:00:13 --> Total execution time: 0.1566
DEBUG - 2011-04-12 00:17:20 --> Config Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:17:20 --> URI Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Router Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Output Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Input Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:17:20 --> Language Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Loader Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Controller Class Initialized
ERROR - 2011-04-12 00:17:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:17:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:17:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:17:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:17:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:17:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:17:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:17:20 --> Final output sent to browser
DEBUG - 2011-04-12 00:17:20 --> Total execution time: 0.0290
DEBUG - 2011-04-12 00:18:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:18:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:18:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:18:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:18:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:18:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:18:54 --> Total execution time: 0.2190
DEBUG - 2011-04-12 00:20:31 --> Config Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:20:31 --> URI Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Router Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Output Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Input Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:20:31 --> Language Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Loader Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Controller Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Model Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Model Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Model Class Initialized
DEBUG - 2011-04-12 00:20:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:20:31 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:20:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:20:31 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:20:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:20:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:20:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:20:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:20:31 --> Final output sent to browser
DEBUG - 2011-04-12 00:20:31 --> Total execution time: 0.0560
DEBUG - 2011-04-12 00:20:34 --> Config Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:20:34 --> URI Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Router Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Output Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Input Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:20:34 --> Language Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Loader Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Controller Class Initialized
ERROR - 2011-04-12 00:20:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:20:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:20:34 --> Model Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Model Class Initialized
DEBUG - 2011-04-12 00:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:20:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:20:34 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:20:34 --> Final output sent to browser
DEBUG - 2011-04-12 00:20:34 --> Total execution time: 0.0279
DEBUG - 2011-04-12 00:21:09 --> Config Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:21:09 --> URI Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Router Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Output Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Input Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:21:09 --> Language Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Loader Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Controller Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:21:09 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:21:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:21:09 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:21:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:21:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:21:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:21:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:21:09 --> Final output sent to browser
DEBUG - 2011-04-12 00:21:09 --> Total execution time: 0.0470
DEBUG - 2011-04-12 00:21:14 --> Config Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:21:14 --> URI Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Router Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Output Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Input Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:21:14 --> Language Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Loader Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Controller Class Initialized
ERROR - 2011-04-12 00:21:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:21:14 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:21:14 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:21:14 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:21:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:21:14 --> Final output sent to browser
DEBUG - 2011-04-12 00:21:14 --> Total execution time: 0.0313
DEBUG - 2011-04-12 00:21:20 --> Config Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:21:20 --> URI Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Router Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Output Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Input Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:21:20 --> Language Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Loader Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Controller Class Initialized
ERROR - 2011-04-12 00:21:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:21:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:21:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:21:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:21:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:21:20 --> Final output sent to browser
DEBUG - 2011-04-12 00:21:20 --> Total execution time: 0.0286
DEBUG - 2011-04-12 00:22:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:22:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:22:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:22:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:22:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:22:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:22:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:22:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:22:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:22:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:22:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:22:54 --> Total execution time: 0.0442
DEBUG - 2011-04-12 00:25:20 --> Config Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:25:20 --> URI Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Router Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Output Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Input Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:25:20 --> Language Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Loader Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Controller Class Initialized
ERROR - 2011-04-12 00:25:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:25:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:25:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:25:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:25:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:25:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:25:20 --> Final output sent to browser
DEBUG - 2011-04-12 00:25:20 --> Total execution time: 0.0497
DEBUG - 2011-04-12 00:26:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:26:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:26:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:26:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:26:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:26:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:26:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:26:54 --> Total execution time: 0.0446
DEBUG - 2011-04-12 00:29:20 --> Config Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:29:20 --> URI Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Router Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Output Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Input Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:29:20 --> Language Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Loader Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Controller Class Initialized
ERROR - 2011-04-12 00:29:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:29:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:29:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:29:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:29:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:29:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:29:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:29:20 --> Final output sent to browser
DEBUG - 2011-04-12 00:29:20 --> Total execution time: 0.0298
DEBUG - 2011-04-12 00:30:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:30:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:30:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:30:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:30:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:30:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:30:54 --> Total execution time: 0.0507
DEBUG - 2011-04-12 00:37:20 --> Config Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:37:20 --> URI Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Router Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Output Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Input Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:37:20 --> Language Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Loader Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Controller Class Initialized
ERROR - 2011-04-12 00:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:37:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Model Class Initialized
DEBUG - 2011-04-12 00:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:37:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:37:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:37:20 --> Final output sent to browser
DEBUG - 2011-04-12 00:37:20 --> Total execution time: 0.0689
DEBUG - 2011-04-12 00:38:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:38:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:38:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:38:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:38:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:38:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:38:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:38:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:38:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:38:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:38:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:38:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:38:54 --> Total execution time: 0.0561
DEBUG - 2011-04-12 00:53:25 --> Config Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:53:25 --> URI Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Router Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Output Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Input Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:53:25 --> Language Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Loader Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Controller Class Initialized
ERROR - 2011-04-12 00:53:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 00:53:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:53:25 --> Model Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Model Class Initialized
DEBUG - 2011-04-12 00:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:53:25 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 00:53:25 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:53:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:53:25 --> Final output sent to browser
DEBUG - 2011-04-12 00:53:25 --> Total execution time: 0.0288
DEBUG - 2011-04-12 00:54:54 --> Config Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 00:54:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 00:54:54 --> URI Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Router Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Output Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Input Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 00:54:54 --> Language Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Loader Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Controller Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Model Class Initialized
DEBUG - 2011-04-12 00:54:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 00:54:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 00:54:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 00:54:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 00:54:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 00:54:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 00:54:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 00:54:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 00:54:54 --> Final output sent to browser
DEBUG - 2011-04-12 00:54:54 --> Total execution time: 0.2649
DEBUG - 2011-04-12 01:09:26 --> Config Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 01:09:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 01:09:26 --> URI Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Router Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Output Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Input Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 01:09:26 --> Language Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Loader Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Controller Class Initialized
ERROR - 2011-04-12 01:09:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 01:09:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 01:09:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 01:09:26 --> Model Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Model Class Initialized
DEBUG - 2011-04-12 01:09:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 01:09:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 01:09:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 01:09:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 01:09:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 01:09:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 01:09:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 01:09:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 01:09:27 --> Final output sent to browser
DEBUG - 2011-04-12 01:09:27 --> Total execution time: 1.4770
DEBUG - 2011-04-12 01:10:54 --> Config Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 01:10:54 --> URI Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Router Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Output Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Input Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 01:10:54 --> Language Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Loader Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Controller Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 01:10:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 01:10:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 01:10:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 01:10:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 01:10:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 01:10:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 01:10:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 01:10:54 --> Final output sent to browser
DEBUG - 2011-04-12 01:10:54 --> Total execution time: 0.3163
DEBUG - 2011-04-12 01:37:20 --> Config Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 01:37:20 --> URI Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Router Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Output Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Input Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 01:37:20 --> Language Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Loader Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Controller Class Initialized
ERROR - 2011-04-12 01:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 01:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 01:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 01:37:20 --> Model Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Model Class Initialized
DEBUG - 2011-04-12 01:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 01:37:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 01:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 01:37:21 --> Helper loaded: url_helper
DEBUG - 2011-04-12 01:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 01:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 01:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 01:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 01:37:21 --> Final output sent to browser
DEBUG - 2011-04-12 01:37:21 --> Total execution time: 0.7070
DEBUG - 2011-04-12 01:38:54 --> Config Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 01:38:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 01:38:54 --> URI Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Router Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Output Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Input Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 01:38:54 --> Language Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Loader Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Controller Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Model Class Initialized
DEBUG - 2011-04-12 01:38:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 01:38:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 01:38:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 01:38:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 01:38:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 01:38:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 01:38:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 01:38:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 01:38:56 --> Final output sent to browser
DEBUG - 2011-04-12 01:38:56 --> Total execution time: 1.7911
DEBUG - 2011-04-12 02:30:29 --> Config Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Hooks Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Utf8 Class Initialized
DEBUG - 2011-04-12 02:30:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 02:30:29 --> URI Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Router Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Output Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Input Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 02:30:29 --> Language Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Loader Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Controller Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Model Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Model Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Model Class Initialized
DEBUG - 2011-04-12 02:30:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 02:30:29 --> Database Driver Class Initialized
DEBUG - 2011-04-12 02:30:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 02:30:31 --> Helper loaded: url_helper
DEBUG - 2011-04-12 02:30:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 02:30:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 02:30:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 02:30:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 02:30:31 --> Final output sent to browser
DEBUG - 2011-04-12 02:30:31 --> Total execution time: 2.1913
DEBUG - 2011-04-12 02:30:34 --> Config Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 02:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 02:30:34 --> URI Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Router Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Output Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Input Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 02:30:34 --> Language Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Loader Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Controller Class Initialized
ERROR - 2011-04-12 02:30:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 02:30:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 02:30:34 --> Model Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Model Class Initialized
DEBUG - 2011-04-12 02:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 02:30:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 02:30:34 --> Helper loaded: url_helper
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 02:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 02:30:34 --> Final output sent to browser
DEBUG - 2011-04-12 02:30:34 --> Total execution time: 0.2927
DEBUG - 2011-04-12 02:30:47 --> Config Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 02:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 02:30:47 --> URI Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Router Class Initialized
DEBUG - 2011-04-12 02:30:47 --> No URI present. Default controller set.
DEBUG - 2011-04-12 02:30:47 --> Output Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Input Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 02:30:47 --> Language Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Loader Class Initialized
DEBUG - 2011-04-12 02:30:47 --> Controller Class Initialized
DEBUG - 2011-04-12 02:30:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 02:30:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 02:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 02:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 02:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 02:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 02:30:47 --> Final output sent to browser
DEBUG - 2011-04-12 02:30:47 --> Total execution time: 0.0643
DEBUG - 2011-04-12 02:33:27 --> Config Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 02:33:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 02:33:27 --> URI Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Router Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Output Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Input Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 02:33:27 --> Language Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Loader Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Controller Class Initialized
ERROR - 2011-04-12 02:33:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 02:33:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 02:33:27 --> Model Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Model Class Initialized
DEBUG - 2011-04-12 02:33:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 02:33:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 02:33:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 02:33:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 02:33:27 --> Final output sent to browser
DEBUG - 2011-04-12 02:33:27 --> Total execution time: 0.0808
DEBUG - 2011-04-12 02:34:54 --> Config Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 02:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 02:34:54 --> URI Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Router Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Output Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Input Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 02:34:54 --> Language Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Loader Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Controller Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Model Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Model Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Model Class Initialized
DEBUG - 2011-04-12 02:34:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 02:34:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 02:34:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 02:34:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 02:34:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 02:34:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 02:34:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 02:34:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 02:34:54 --> Final output sent to browser
DEBUG - 2011-04-12 02:34:54 --> Total execution time: 0.0999
DEBUG - 2011-04-12 03:17:02 --> Config Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:17:02 --> URI Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Router Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Output Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Input Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:17:02 --> Language Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Loader Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Controller Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:17:02 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:17:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:17:03 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:17:03 --> Final output sent to browser
DEBUG - 2011-04-12 03:17:03 --> Total execution time: 1.1269
DEBUG - 2011-04-12 03:17:05 --> Config Class Initialized
DEBUG - 2011-04-12 03:17:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:17:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:17:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:17:05 --> URI Class Initialized
DEBUG - 2011-04-12 03:17:05 --> Router Class Initialized
ERROR - 2011-04-12 03:17:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:17:06 --> Config Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:17:06 --> URI Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Router Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Output Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Input Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:17:06 --> Language Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Loader Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Controller Class Initialized
ERROR - 2011-04-12 03:17:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:17:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:17:06 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:17:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:17:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:17:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:17:06 --> Final output sent to browser
DEBUG - 2011-04-12 03:17:06 --> Total execution time: 0.1329
DEBUG - 2011-04-12 03:17:07 --> Config Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:17:07 --> URI Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Router Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Output Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Input Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:17:07 --> Language Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Loader Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Controller Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Model Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:17:07 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Config Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:17:07 --> URI Class Initialized
DEBUG - 2011-04-12 03:17:07 --> Router Class Initialized
ERROR - 2011-04-12 03:17:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:17:08 --> Final output sent to browser
DEBUG - 2011-04-12 03:17:08 --> Total execution time: 0.6193
DEBUG - 2011-04-12 03:29:21 --> Config Class Initialized
DEBUG - 2011-04-12 03:29:22 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:29:22 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:29:22 --> URI Class Initialized
DEBUG - 2011-04-12 03:29:22 --> Router Class Initialized
DEBUG - 2011-04-12 03:29:23 --> Output Class Initialized
DEBUG - 2011-04-12 03:29:24 --> Input Class Initialized
DEBUG - 2011-04-12 03:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:29:24 --> Language Class Initialized
DEBUG - 2011-04-12 03:29:24 --> Loader Class Initialized
DEBUG - 2011-04-12 03:29:24 --> Controller Class Initialized
ERROR - 2011-04-12 03:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:29:26 --> Model Class Initialized
DEBUG - 2011-04-12 03:29:26 --> Model Class Initialized
DEBUG - 2011-04-12 03:29:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:29:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:29:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:29:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:29:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:29:28 --> Final output sent to browser
DEBUG - 2011-04-12 03:29:28 --> Total execution time: 6.5163
DEBUG - 2011-04-12 03:30:54 --> Config Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:30:54 --> URI Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Router Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Output Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Input Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:30:54 --> Language Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Loader Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Controller Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 03:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:30:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:30:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:30:54 --> Final output sent to browser
DEBUG - 2011-04-12 03:30:54 --> Total execution time: 0.1406
DEBUG - 2011-04-12 03:34:41 --> Config Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:34:41 --> URI Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Router Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Output Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Input Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:34:41 --> Language Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Loader Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Controller Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Model Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Model Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Model Class Initialized
DEBUG - 2011-04-12 03:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:34:41 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:34:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:34:41 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:34:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:34:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:34:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:34:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:34:41 --> Final output sent to browser
DEBUG - 2011-04-12 03:34:41 --> Total execution time: 0.0477
DEBUG - 2011-04-12 03:35:03 --> Config Class Initialized
DEBUG - 2011-04-12 03:35:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:35:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:35:03 --> URI Class Initialized
DEBUG - 2011-04-12 03:35:03 --> Router Class Initialized
ERROR - 2011-04-12 03:35:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:35:05 --> Config Class Initialized
DEBUG - 2011-04-12 03:35:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:35:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:35:05 --> URI Class Initialized
DEBUG - 2011-04-12 03:35:06 --> Router Class Initialized
ERROR - 2011-04-12 03:35:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:40:58 --> Config Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:40:58 --> URI Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Router Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Output Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Input Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:40:58 --> Language Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Loader Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Controller Class Initialized
ERROR - 2011-04-12 03:40:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:40:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:40:58 --> Model Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Model Class Initialized
DEBUG - 2011-04-12 03:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:40:58 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:40:58 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:40:58 --> Final output sent to browser
DEBUG - 2011-04-12 03:40:58 --> Total execution time: 0.1369
DEBUG - 2011-04-12 03:41:00 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:00 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:00 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Controller Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:03 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:03 --> Total execution time: 2.5543
DEBUG - 2011-04-12 03:41:04 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:04 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:04 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:04 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:04 --> Router Class Initialized
ERROR - 2011-04-12 03:41:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:41:25 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:25 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:25 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Controller Class Initialized
ERROR - 2011-04-12 03:41:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:41:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:25 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:25 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:25 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:41:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:41:25 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:25 --> Total execution time: 0.0352
DEBUG - 2011-04-12 03:41:26 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:26 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:26 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Controller Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:26 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:27 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:27 --> Total execution time: 1.3873
DEBUG - 2011-04-12 03:41:28 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:28 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:28 --> Router Class Initialized
ERROR - 2011-04-12 03:41:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:41:37 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:37 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:37 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Controller Class Initialized
ERROR - 2011-04-12 03:41:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:41:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:37 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:37 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:37 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:41:37 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:37 --> Total execution time: 0.1190
DEBUG - 2011-04-12 03:41:38 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:38 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:38 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Controller Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:39 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:39 --> Total execution time: 1.2945
DEBUG - 2011-04-12 03:41:40 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:40 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:40 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Controller Class Initialized
ERROR - 2011-04-12 03:41:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:41:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:40 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:40 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:40 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:41:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:41:40 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:40 --> Total execution time: 0.0394
DEBUG - 2011-04-12 03:41:40 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:40 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:40 --> Router Class Initialized
ERROR - 2011-04-12 03:41:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:41:47 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:47 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:47 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Controller Class Initialized
ERROR - 2011-04-12 03:41:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:41:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:47 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:41:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:41:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:41:47 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:47 --> Total execution time: 0.1188
DEBUG - 2011-04-12 03:41:48 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:48 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Router Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Output Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Input Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:41:48 --> Language Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Loader Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Controller Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Model Class Initialized
DEBUG - 2011-04-12 03:41:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:41:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:41:50 --> Final output sent to browser
DEBUG - 2011-04-12 03:41:50 --> Total execution time: 1.2838
DEBUG - 2011-04-12 03:41:51 --> Config Class Initialized
DEBUG - 2011-04-12 03:41:51 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:41:51 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:41:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:41:51 --> URI Class Initialized
DEBUG - 2011-04-12 03:41:51 --> Router Class Initialized
ERROR - 2011-04-12 03:41:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:42:11 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:11 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:11 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Controller Class Initialized
ERROR - 2011-04-12 03:42:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:42:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:11 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:11 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:11 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:42:11 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:11 --> Total execution time: 0.0512
DEBUG - 2011-04-12 03:42:12 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:12 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:12 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Controller Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:12 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:13 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:13 --> Total execution time: 0.8252
DEBUG - 2011-04-12 03:42:14 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:14 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:14 --> Router Class Initialized
ERROR - 2011-04-12 03:42:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:42:22 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:22 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:22 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Controller Class Initialized
ERROR - 2011-04-12 03:42:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:42:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:22 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:22 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:22 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:42:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:42:22 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:22 --> Total execution time: 0.1302
DEBUG - 2011-04-12 03:42:24 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:24 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:24 --> Router Class Initialized
ERROR - 2011-04-12 03:42:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:42:38 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:38 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:38 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Controller Class Initialized
ERROR - 2011-04-12 03:42:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:42:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:38 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:42:38 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:38 --> Total execution time: 0.0371
DEBUG - 2011-04-12 03:42:40 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:40 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:40 --> Router Class Initialized
ERROR - 2011-04-12 03:42:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:42:43 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:43 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:43 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Controller Class Initialized
ERROR - 2011-04-12 03:42:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:42:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:43 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:42:43 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:42:43 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:43 --> Total execution time: 0.0553
DEBUG - 2011-04-12 03:42:44 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:44 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Router Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Output Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Input Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:42:44 --> Language Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Loader Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Controller Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Model Class Initialized
DEBUG - 2011-04-12 03:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:42:44 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:42:45 --> Final output sent to browser
DEBUG - 2011-04-12 03:42:45 --> Total execution time: 0.5725
DEBUG - 2011-04-12 03:42:46 --> Config Class Initialized
DEBUG - 2011-04-12 03:42:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:42:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:42:46 --> URI Class Initialized
DEBUG - 2011-04-12 03:42:46 --> Router Class Initialized
ERROR - 2011-04-12 03:42:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:43:00 --> Config Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:43:00 --> URI Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Router Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Output Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Input Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:43:00 --> Language Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Loader Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Controller Class Initialized
ERROR - 2011-04-12 03:43:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 03:43:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:43:00 --> Model Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Model Class Initialized
DEBUG - 2011-04-12 03:43:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:43:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 03:43:00 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:43:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:43:00 --> Final output sent to browser
DEBUG - 2011-04-12 03:43:00 --> Total execution time: 0.0320
DEBUG - 2011-04-12 03:43:01 --> Config Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:43:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:43:01 --> URI Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Router Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Output Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Input Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:43:01 --> Language Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Loader Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Controller Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Model Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Model Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:43:01 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:43:01 --> Final output sent to browser
DEBUG - 2011-04-12 03:43:01 --> Total execution time: 0.7474
DEBUG - 2011-04-12 03:43:03 --> Config Class Initialized
DEBUG - 2011-04-12 03:43:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:43:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:43:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:43:03 --> URI Class Initialized
DEBUG - 2011-04-12 03:43:03 --> Router Class Initialized
ERROR - 2011-04-12 03:43:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 03:51:37 --> Config Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:51:37 --> URI Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Router Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Output Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Input Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:51:37 --> Language Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Loader Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Controller Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Model Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Model Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:51:37 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:51:37 --> Final output sent to browser
DEBUG - 2011-04-12 03:51:37 --> Total execution time: 0.5460
DEBUG - 2011-04-12 03:52:56 --> Config Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:52:56 --> URI Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Router Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Output Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Input Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:52:56 --> Language Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Loader Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Controller Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Model Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Model Class Initialized
DEBUG - 2011-04-12 03:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:52:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:52:57 --> Final output sent to browser
DEBUG - 2011-04-12 03:52:57 --> Total execution time: 0.7908
DEBUG - 2011-04-12 03:56:49 --> Config Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:56:49 --> URI Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Router Class Initialized
DEBUG - 2011-04-12 03:56:49 --> No URI present. Default controller set.
DEBUG - 2011-04-12 03:56:49 --> Output Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Input Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:56:49 --> Language Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Loader Class Initialized
DEBUG - 2011-04-12 03:56:49 --> Controller Class Initialized
DEBUG - 2011-04-12 03:56:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 03:56:49 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:56:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:56:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:56:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:56:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:56:49 --> Final output sent to browser
DEBUG - 2011-04-12 03:56:49 --> Total execution time: 0.1278
DEBUG - 2011-04-12 03:57:03 --> Config Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:57:03 --> URI Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Router Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Output Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Input Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:57:03 --> Language Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Loader Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Controller Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:57:03 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:57:03 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:57:03 --> Final output sent to browser
DEBUG - 2011-04-12 03:57:03 --> Total execution time: 0.1275
DEBUG - 2011-04-12 03:57:39 --> Config Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:57:39 --> URI Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Router Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Output Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Input Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:57:39 --> Language Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Loader Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Controller Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:57:39 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:57:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:57:39 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:57:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:57:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:57:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:57:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:57:39 --> Final output sent to browser
DEBUG - 2011-04-12 03:57:39 --> Total execution time: 0.4474
DEBUG - 2011-04-12 03:57:46 --> Config Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:57:46 --> URI Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Router Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Output Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Input Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:57:46 --> Language Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Loader Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Controller Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Model Class Initialized
DEBUG - 2011-04-12 03:57:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:57:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:57:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:57:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:57:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:57:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:57:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:57:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:57:46 --> Final output sent to browser
DEBUG - 2011-04-12 03:57:46 --> Total execution time: 0.1210
DEBUG - 2011-04-12 03:58:07 --> Config Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 03:58:07 --> URI Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Router Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Output Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Input Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 03:58:07 --> Language Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Loader Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Controller Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Model Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Model Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Model Class Initialized
DEBUG - 2011-04-12 03:58:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 03:58:07 --> Database Driver Class Initialized
DEBUG - 2011-04-12 03:58:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 03:58:07 --> Helper loaded: url_helper
DEBUG - 2011-04-12 03:58:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 03:58:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 03:58:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 03:58:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 03:58:07 --> Final output sent to browser
DEBUG - 2011-04-12 03:58:07 --> Total execution time: 0.2837
DEBUG - 2011-04-12 04:03:31 --> Config Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:03:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:03:31 --> URI Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Router Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Output Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Input Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:03:31 --> Language Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Loader Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Controller Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Model Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Model Class Initialized
DEBUG - 2011-04-12 04:03:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:03:31 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:03:32 --> Final output sent to browser
DEBUG - 2011-04-12 04:03:32 --> Total execution time: 0.8161
DEBUG - 2011-04-12 04:06:24 --> Config Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:06:24 --> URI Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Router Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Output Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Input Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:06:24 --> Language Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Loader Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Controller Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Model Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Model Class Initialized
DEBUG - 2011-04-12 04:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:06:25 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:06:26 --> Final output sent to browser
DEBUG - 2011-04-12 04:06:26 --> Total execution time: 2.4655
DEBUG - 2011-04-12 04:47:24 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:24 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Router Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Output Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Input Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:47:24 --> Language Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Loader Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Controller Class Initialized
ERROR - 2011-04-12 04:47:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 04:47:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:47:24 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:47:24 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:47:24 --> Helper loaded: url_helper
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 04:47:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 04:47:24 --> Final output sent to browser
DEBUG - 2011-04-12 04:47:24 --> Total execution time: 0.5157
DEBUG - 2011-04-12 04:47:26 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:26 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Router Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Output Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Input Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:47:26 --> Language Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Loader Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Controller Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:47:26 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:47:27 --> Final output sent to browser
DEBUG - 2011-04-12 04:47:27 --> Total execution time: 0.7503
DEBUG - 2011-04-12 04:47:28 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:28 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:28 --> Router Class Initialized
ERROR - 2011-04-12 04:47:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 04:47:55 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:55 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Router Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Output Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Input Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:47:55 --> Language Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Loader Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Controller Class Initialized
ERROR - 2011-04-12 04:47:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 04:47:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:47:55 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:47:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:47:55 --> Helper loaded: url_helper
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 04:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 04:47:55 --> Final output sent to browser
DEBUG - 2011-04-12 04:47:55 --> Total execution time: 0.0355
DEBUG - 2011-04-12 04:47:56 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:56 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Router Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Output Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Input Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:47:56 --> Language Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Loader Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Controller Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Model Class Initialized
DEBUG - 2011-04-12 04:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:47:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:47:57 --> Final output sent to browser
DEBUG - 2011-04-12 04:47:57 --> Total execution time: 0.6403
DEBUG - 2011-04-12 04:47:59 --> Config Class Initialized
DEBUG - 2011-04-12 04:47:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:47:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:47:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:47:59 --> URI Class Initialized
DEBUG - 2011-04-12 04:47:59 --> Router Class Initialized
ERROR - 2011-04-12 04:47:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 04:57:03 --> Config Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:57:03 --> URI Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Router Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Output Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Input Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:57:03 --> Language Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Loader Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Controller Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Model Class Initialized
DEBUG - 2011-04-12 04:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:57:03 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 04:57:03 --> Helper loaded: url_helper
DEBUG - 2011-04-12 04:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 04:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 04:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 04:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 04:57:03 --> Final output sent to browser
DEBUG - 2011-04-12 04:57:03 --> Total execution time: 0.3829
DEBUG - 2011-04-12 04:57:06 --> Config Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 04:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 04:57:06 --> URI Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Router Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Output Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Input Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 04:57:06 --> Language Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Loader Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Controller Class Initialized
ERROR - 2011-04-12 04:57:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 04:57:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:57:06 --> Model Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Model Class Initialized
DEBUG - 2011-04-12 04:57:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 04:57:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 04:57:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 04:57:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 04:57:06 --> Final output sent to browser
DEBUG - 2011-04-12 04:57:06 --> Total execution time: 0.0287
DEBUG - 2011-04-12 05:17:23 --> Config Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 05:17:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 05:17:23 --> URI Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Router Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Output Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Input Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 05:17:23 --> Language Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Loader Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Controller Class Initialized
ERROR - 2011-04-12 05:17:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 05:17:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 05:17:23 --> Model Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Model Class Initialized
DEBUG - 2011-04-12 05:17:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 05:17:23 --> Database Driver Class Initialized
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 05:17:23 --> Helper loaded: url_helper
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 05:17:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 05:17:23 --> Final output sent to browser
DEBUG - 2011-04-12 05:17:23 --> Total execution time: 0.3600
DEBUG - 2011-04-12 05:18:54 --> Config Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 05:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 05:18:54 --> URI Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Router Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Output Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Input Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 05:18:54 --> Language Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Loader Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Controller Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Model Class Initialized
DEBUG - 2011-04-12 05:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 05:18:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 05:19:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 05:19:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 05:19:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 05:19:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 05:19:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 05:19:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 05:19:06 --> Final output sent to browser
DEBUG - 2011-04-12 05:19:06 --> Total execution time: 12.3533
DEBUG - 2011-04-12 05:21:59 --> Config Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 05:21:59 --> URI Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Router Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Output Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Input Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 05:21:59 --> Language Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Loader Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Controller Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 05:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 05:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 05:21:59 --> Final output sent to browser
DEBUG - 2011-04-12 05:21:59 --> Total execution time: 0.1074
DEBUG - 2011-04-12 05:21:59 --> Config Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 05:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 05:21:59 --> URI Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Router Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Output Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Input Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 05:21:59 --> Language Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Loader Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Controller Class Initialized
ERROR - 2011-04-12 05:21:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 05:21:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 05:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 05:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 05:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 05:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 05:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 05:21:59 --> Final output sent to browser
DEBUG - 2011-04-12 05:21:59 --> Total execution time: 0.0942
DEBUG - 2011-04-12 06:13:20 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:20 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Router Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Output Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Input Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:13:20 --> Language Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Loader Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Controller Class Initialized
ERROR - 2011-04-12 06:13:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 06:13:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:13:20 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:13:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:13:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 06:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 06:13:20 --> Final output sent to browser
DEBUG - 2011-04-12 06:13:20 --> Total execution time: 0.3399
DEBUG - 2011-04-12 06:13:23 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:23 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Router Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Output Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Input Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:13:23 --> Language Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Loader Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Controller Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:13:23 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:13:23 --> Final output sent to browser
DEBUG - 2011-04-12 06:13:23 --> Total execution time: 0.8605
DEBUG - 2011-04-12 06:13:25 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:25 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:25 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:25 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:25 --> Router Class Initialized
ERROR - 2011-04-12 06:13:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 06:13:26 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:26 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:26 --> Router Class Initialized
ERROR - 2011-04-12 06:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 06:13:47 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:47 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Router Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Output Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Input Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:13:47 --> Language Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Loader Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Controller Class Initialized
ERROR - 2011-04-12 06:13:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 06:13:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:13:47 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:13:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:13:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 06:13:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 06:13:47 --> Final output sent to browser
DEBUG - 2011-04-12 06:13:47 --> Total execution time: 0.0530
DEBUG - 2011-04-12 06:13:48 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:48 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Router Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Output Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Input Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:13:48 --> Language Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Loader Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Controller Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Model Class Initialized
DEBUG - 2011-04-12 06:13:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:13:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:13:51 --> Final output sent to browser
DEBUG - 2011-04-12 06:13:51 --> Total execution time: 2.9158
DEBUG - 2011-04-12 06:13:52 --> Config Class Initialized
DEBUG - 2011-04-12 06:13:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:13:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:13:52 --> URI Class Initialized
DEBUG - 2011-04-12 06:13:52 --> Router Class Initialized
ERROR - 2011-04-12 06:13:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 06:14:02 --> Config Class Initialized
DEBUG - 2011-04-12 06:14:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:14:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:14:02 --> URI Class Initialized
DEBUG - 2011-04-12 06:14:02 --> Router Class Initialized
ERROR - 2011-04-12 06:14:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 06:57:16 --> Config Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:57:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:57:16 --> URI Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Router Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Output Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Input Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:57:16 --> Language Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Loader Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Controller Class Initialized
ERROR - 2011-04-12 06:57:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 06:57:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:57:16 --> Model Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Model Class Initialized
DEBUG - 2011-04-12 06:57:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:57:16 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 06:57:16 --> Helper loaded: url_helper
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 06:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 06:57:16 --> Final output sent to browser
DEBUG - 2011-04-12 06:57:16 --> Total execution time: 0.6398
DEBUG - 2011-04-12 06:57:18 --> Config Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:57:18 --> URI Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Router Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Output Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Input Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 06:57:18 --> Language Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Loader Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Controller Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Model Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Model Class Initialized
DEBUG - 2011-04-12 06:57:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 06:57:18 --> Database Driver Class Initialized
DEBUG - 2011-04-12 06:57:19 --> Final output sent to browser
DEBUG - 2011-04-12 06:57:19 --> Total execution time: 0.8139
DEBUG - 2011-04-12 06:57:21 --> Config Class Initialized
DEBUG - 2011-04-12 06:57:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 06:57:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 06:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 06:57:21 --> URI Class Initialized
DEBUG - 2011-04-12 06:57:21 --> Router Class Initialized
ERROR - 2011-04-12 06:57:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 07:05:20 --> Config Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:05:20 --> URI Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Router Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Output Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Input Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:05:20 --> Language Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Loader Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Controller Class Initialized
ERROR - 2011-04-12 07:05:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 07:05:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:05:20 --> Model Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Model Class Initialized
DEBUG - 2011-04-12 07:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:05:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:05:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:05:20 --> Final output sent to browser
DEBUG - 2011-04-12 07:05:20 --> Total execution time: 0.0395
DEBUG - 2011-04-12 07:06:05 --> Config Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:06:05 --> URI Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Router Class Initialized
DEBUG - 2011-04-12 07:06:05 --> No URI present. Default controller set.
DEBUG - 2011-04-12 07:06:05 --> Output Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Input Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:06:05 --> Language Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Loader Class Initialized
DEBUG - 2011-04-12 07:06:05 --> Controller Class Initialized
DEBUG - 2011-04-12 07:06:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 07:06:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:06:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:06:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:06:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:06:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:06:05 --> Final output sent to browser
DEBUG - 2011-04-12 07:06:05 --> Total execution time: 0.0619
DEBUG - 2011-04-12 07:06:09 --> Config Class Initialized
DEBUG - 2011-04-12 07:06:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:06:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:06:09 --> URI Class Initialized
DEBUG - 2011-04-12 07:06:09 --> Router Class Initialized
ERROR - 2011-04-12 07:06:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 07:06:54 --> Config Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:06:54 --> URI Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Router Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Output Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Input Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:06:54 --> Language Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Loader Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Controller Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Model Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Model Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Model Class Initialized
DEBUG - 2011-04-12 07:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:06:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:06:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 07:06:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:06:54 --> Final output sent to browser
DEBUG - 2011-04-12 07:06:54 --> Total execution time: 0.4604
DEBUG - 2011-04-12 07:07:21 --> Config Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:07:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:07:21 --> URI Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Router Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Output Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Input Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:07:21 --> Language Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Loader Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Controller Class Initialized
ERROR - 2011-04-12 07:07:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 07:07:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:07:21 --> Model Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Model Class Initialized
DEBUG - 2011-04-12 07:07:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:07:21 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:07:21 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:07:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:07:21 --> Final output sent to browser
DEBUG - 2011-04-12 07:07:21 --> Total execution time: 0.0315
DEBUG - 2011-04-12 07:07:22 --> Config Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:07:22 --> URI Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Router Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Output Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Input Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:07:22 --> Language Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Loader Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Controller Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Model Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Model Class Initialized
DEBUG - 2011-04-12 07:07:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:07:22 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:07:24 --> Final output sent to browser
DEBUG - 2011-04-12 07:07:24 --> Total execution time: 1.1299
DEBUG - 2011-04-12 07:07:26 --> Config Class Initialized
DEBUG - 2011-04-12 07:07:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:07:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:07:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:07:26 --> URI Class Initialized
DEBUG - 2011-04-12 07:07:26 --> Router Class Initialized
ERROR - 2011-04-12 07:07:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 07:08:07 --> Config Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:08:07 --> URI Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Router Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Output Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Input Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:08:07 --> Language Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Loader Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Controller Class Initialized
ERROR - 2011-04-12 07:08:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 07:08:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:08:07 --> Model Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Model Class Initialized
DEBUG - 2011-04-12 07:08:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:08:07 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:08:07 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:08:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:08:07 --> Final output sent to browser
DEBUG - 2011-04-12 07:08:07 --> Total execution time: 0.1331
DEBUG - 2011-04-12 07:08:08 --> Config Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:08:08 --> URI Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Router Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Output Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Input Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:08:08 --> Language Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Loader Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Controller Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Model Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Model Class Initialized
DEBUG - 2011-04-12 07:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:08:08 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:08:09 --> Final output sent to browser
DEBUG - 2011-04-12 07:08:09 --> Total execution time: 0.9079
DEBUG - 2011-04-12 07:08:10 --> Config Class Initialized
DEBUG - 2011-04-12 07:08:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:08:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:08:10 --> URI Class Initialized
DEBUG - 2011-04-12 07:08:10 --> Router Class Initialized
ERROR - 2011-04-12 07:08:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 07:33:41 --> Config Class Initialized
DEBUG - 2011-04-12 07:33:41 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:33:41 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:33:41 --> URI Class Initialized
DEBUG - 2011-04-12 07:33:41 --> Router Class Initialized
ERROR - 2011-04-12 07:33:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 07:33:42 --> Config Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:33:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:33:42 --> URI Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Router Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Output Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Input Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:33:42 --> Language Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Loader Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Controller Class Initialized
ERROR - 2011-04-12 07:33:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 07:33:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:33:42 --> Model Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Model Class Initialized
DEBUG - 2011-04-12 07:33:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 07:33:42 --> Database Driver Class Initialized
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 07:33:42 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:33:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:33:42 --> Final output sent to browser
DEBUG - 2011-04-12 07:33:42 --> Total execution time: 0.2109
DEBUG - 2011-04-12 07:42:59 --> Config Class Initialized
DEBUG - 2011-04-12 07:42:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:42:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:42:59 --> URI Class Initialized
DEBUG - 2011-04-12 07:42:59 --> Router Class Initialized
ERROR - 2011-04-12 07:42:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 07:53:42 --> Config Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 07:53:42 --> URI Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Router Class Initialized
DEBUG - 2011-04-12 07:53:42 --> No URI present. Default controller set.
DEBUG - 2011-04-12 07:53:42 --> Output Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Input Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 07:53:42 --> Language Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Loader Class Initialized
DEBUG - 2011-04-12 07:53:42 --> Controller Class Initialized
DEBUG - 2011-04-12 07:53:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 07:53:42 --> Helper loaded: url_helper
DEBUG - 2011-04-12 07:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 07:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 07:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 07:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 07:53:42 --> Final output sent to browser
DEBUG - 2011-04-12 07:53:42 --> Total execution time: 0.1742
DEBUG - 2011-04-12 08:26:41 --> Config Class Initialized
DEBUG - 2011-04-12 08:26:41 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:26:41 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:26:41 --> URI Class Initialized
DEBUG - 2011-04-12 08:26:41 --> Router Class Initialized
ERROR - 2011-04-12 08:26:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 08:40:05 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:05 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:05 --> No URI present. Default controller set.
DEBUG - 2011-04-12 08:40:05 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:05 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:05 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 08:40:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:06 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:06 --> Total execution time: 0.3333
DEBUG - 2011-04-12 08:40:07 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:07 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Router Class Initialized
ERROR - 2011-04-12 08:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:07 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:07 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:07 --> Router Class Initialized
ERROR - 2011-04-12 08:40:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:09 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:09 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:09 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:09 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:11 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:11 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:11 --> Total execution time: 1.3964
DEBUG - 2011-04-12 08:40:12 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:12 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:12 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:12 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:12 --> Router Class Initialized
ERROR - 2011-04-12 08:40:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:21 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:21 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:21 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:21 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:22 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:22 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:22 --> Total execution time: 1.1608
DEBUG - 2011-04-12 08:40:23 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:23 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:23 --> Router Class Initialized
ERROR - 2011-04-12 08:40:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:27 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:27 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:27 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:27 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:27 --> Total execution time: 0.0469
DEBUG - 2011-04-12 08:40:34 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:34 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:34 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:35 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:35 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:35 --> Total execution time: 0.9156
DEBUG - 2011-04-12 08:40:36 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:36 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:36 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:36 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:36 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:36 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:36 --> Total execution time: 0.1379
DEBUG - 2011-04-12 08:40:36 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:36 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:36 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:36 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:36 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:36 --> Router Class Initialized
ERROR - 2011-04-12 08:40:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:36 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:36 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:36 --> Total execution time: 0.1589
DEBUG - 2011-04-12 08:40:43 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:43 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:43 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:44 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:44 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:44 --> Total execution time: 0.3756
DEBUG - 2011-04-12 08:40:44 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:44 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:45 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:45 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:45 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:45 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:45 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:45 --> Total execution time: 0.1020
DEBUG - 2011-04-12 08:40:45 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:45 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:45 --> Router Class Initialized
ERROR - 2011-04-12 08:40:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:40:47 --> Config Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:40:47 --> URI Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Router Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Output Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Input Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:40:47 --> Language Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Loader Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Controller Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Model Class Initialized
DEBUG - 2011-04-12 08:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:40:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:40:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:40:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:40:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:40:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:40:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:40:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:40:47 --> Final output sent to browser
DEBUG - 2011-04-12 08:40:47 --> Total execution time: 0.0549
DEBUG - 2011-04-12 08:41:00 --> Config Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:41:00 --> URI Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Router Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Output Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Input Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:41:00 --> Language Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Loader Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Controller Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:41:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:41:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:41:00 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:41:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:41:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:41:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:41:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:41:00 --> Final output sent to browser
DEBUG - 2011-04-12 08:41:00 --> Total execution time: 0.0631
DEBUG - 2011-04-12 08:41:03 --> Config Class Initialized
DEBUG - 2011-04-12 08:41:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:41:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:41:03 --> URI Class Initialized
DEBUG - 2011-04-12 08:41:03 --> Router Class Initialized
ERROR - 2011-04-12 08:41:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:41:07 --> Config Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:41:07 --> URI Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Router Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Output Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Input Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:41:07 --> Language Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Loader Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Controller Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Model Class Initialized
DEBUG - 2011-04-12 08:41:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:41:07 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:41:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:41:07 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:41:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:41:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:41:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:41:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:41:07 --> Final output sent to browser
DEBUG - 2011-04-12 08:41:07 --> Total execution time: 0.0525
DEBUG - 2011-04-12 08:45:05 --> Config Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:45:05 --> URI Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Router Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Output Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Input Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:45:05 --> Language Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Loader Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Controller Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:45:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:45:05 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:45:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 08:45:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:45:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:45:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:45:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:45:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:45:05 --> Final output sent to browser
DEBUG - 2011-04-12 08:45:05 --> Total execution time: 0.3200
DEBUG - 2011-04-12 08:45:08 --> Config Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:45:08 --> URI Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Router Class Initialized
ERROR - 2011-04-12 08:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:45:08 --> Config Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:45:08 --> URI Class Initialized
DEBUG - 2011-04-12 08:45:08 --> Router Class Initialized
ERROR - 2011-04-12 08:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:45:09 --> Config Class Initialized
DEBUG - 2011-04-12 08:45:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:45:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:45:09 --> URI Class Initialized
DEBUG - 2011-04-12 08:45:09 --> Router Class Initialized
ERROR - 2011-04-12 08:45:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:50:05 --> Config Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:50:05 --> URI Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Router Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Output Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Input Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:50:05 --> Language Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Loader Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Controller Class Initialized
ERROR - 2011-04-12 08:50:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:50:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:50:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:50:05 --> Config Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:50:05 --> URI Class Initialized
DEBUG - 2011-04-12 08:50:05 --> Router Class Initialized
ERROR - 2011-04-12 08:50:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 08:50:05 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:50:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:50:05 --> Final output sent to browser
DEBUG - 2011-04-12 08:50:05 --> Total execution time: 0.1508
DEBUG - 2011-04-12 08:50:06 --> Config Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:50:06 --> URI Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Router Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Output Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Input Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:50:06 --> Language Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Loader Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Controller Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Model Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Model Class Initialized
DEBUG - 2011-04-12 08:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:50:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:50:07 --> Final output sent to browser
DEBUG - 2011-04-12 08:50:07 --> Total execution time: 0.9344
DEBUG - 2011-04-12 08:51:35 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:35 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:35 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Controller Class Initialized
ERROR - 2011-04-12 08:51:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:51:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:35 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:35 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:35 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:51:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:51:35 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:35 --> Total execution time: 0.0587
DEBUG - 2011-04-12 08:51:36 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:36 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:36 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Controller Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:36 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:37 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:37 --> Total execution time: 1.0048
DEBUG - 2011-04-12 08:51:43 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:43 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:43 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Controller Class Initialized
ERROR - 2011-04-12 08:51:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:51:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:43 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:51:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:51:43 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:43 --> Total execution time: 0.0496
DEBUG - 2011-04-12 08:51:44 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:44 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:44 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Controller Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:44 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:45 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:45 --> Total execution time: 0.8391
DEBUG - 2011-04-12 08:51:46 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:46 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:46 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Controller Class Initialized
ERROR - 2011-04-12 08:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:46 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:51:46 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:46 --> Total execution time: 0.0417
DEBUG - 2011-04-12 08:51:59 --> Config Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:51:59 --> URI Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Router Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Output Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Input Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:51:59 --> Language Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Loader Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Controller Class Initialized
ERROR - 2011-04-12 08:51:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:51:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:59 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Model Class Initialized
DEBUG - 2011-04-12 08:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:51:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:51:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:51:59 --> Final output sent to browser
DEBUG - 2011-04-12 08:51:59 --> Total execution time: 0.0671
DEBUG - 2011-04-12 08:52:00 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:00 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:00 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:01 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:01 --> Total execution time: 0.7551
DEBUG - 2011-04-12 08:52:17 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:17 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:17 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:17 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:17 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:17 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:17 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:17 --> Total execution time: 0.0299
DEBUG - 2011-04-12 08:52:18 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:18 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:18 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:18 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:19 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:19 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:19 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:19 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:19 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:19 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:19 --> Total execution time: 0.0279
DEBUG - 2011-04-12 08:52:19 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:19 --> Total execution time: 0.9877
DEBUG - 2011-04-12 08:52:23 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:23 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:23 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:23 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:23 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:23 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:23 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:23 --> Total execution time: 0.0330
DEBUG - 2011-04-12 08:52:24 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:24 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:24 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:24 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:25 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:25 --> Total execution time: 1.0812
DEBUG - 2011-04-12 08:52:30 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:30 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:30 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:30 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:30 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:30 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:30 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:30 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:30 --> Total execution time: 0.1575
DEBUG - 2011-04-12 08:52:30 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:30 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:30 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:30 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:30 --> Total execution time: 0.1519
DEBUG - 2011-04-12 08:52:31 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:31 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:31 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:31 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:32 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:32 --> Total execution time: 0.7760
DEBUG - 2011-04-12 08:52:38 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:38 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:38 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:38 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:38 --> Total execution time: 0.0640
DEBUG - 2011-04-12 08:52:39 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:39 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:39 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:39 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:39 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:39 --> Total execution time: 0.8308
DEBUG - 2011-04-12 08:52:50 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:50 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:50 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:50 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:50 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:50 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:50 --> Total execution time: 0.1075
DEBUG - 2011-04-12 08:52:51 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:51 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:51 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:51 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:52 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:52 --> Total execution time: 0.8319
DEBUG - 2011-04-12 08:52:57 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:57 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:57 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:57 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:58 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Controller Class Initialized
ERROR - 2011-04-12 08:52:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:52:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:58 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:58 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:52:58 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:52:58 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:58 --> Total execution time: 0.2890
DEBUG - 2011-04-12 08:52:59 --> Config Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:52:59 --> URI Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Router Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Output Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Input Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:52:59 --> Language Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Loader Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Controller Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Model Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:52:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:52:59 --> Final output sent to browser
DEBUG - 2011-04-12 08:52:59 --> Total execution time: 0.7721
DEBUG - 2011-04-12 08:53:01 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:01 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:01 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:01 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:01 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:01 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:01 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:01 --> Total execution time: 0.0385
DEBUG - 2011-04-12 08:53:05 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:05 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:05 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:05 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:05 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:05 --> Total execution time: 0.0643
DEBUG - 2011-04-12 08:53:06 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:06 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:06 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:07 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:07 --> Total execution time: 0.8009
DEBUG - 2011-04-12 08:53:11 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:11 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:11 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:11 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:11 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:11 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:11 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:11 --> Total execution time: 0.1099
DEBUG - 2011-04-12 08:53:12 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:12 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:12 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:12 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:13 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:13 --> Total execution time: 0.7982
DEBUG - 2011-04-12 08:53:14 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:14 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:14 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:14 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:14 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:14 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:14 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:14 --> Total execution time: 0.0485
DEBUG - 2011-04-12 08:53:19 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:19 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:19 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:19 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:19 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:19 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:19 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:19 --> Total execution time: 0.0305
DEBUG - 2011-04-12 08:53:20 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:20 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:20 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:21 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:21 --> Total execution time: 0.6857
DEBUG - 2011-04-12 08:53:27 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:27 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:27 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:27 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:27 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:27 --> Total execution time: 0.0324
DEBUG - 2011-04-12 08:53:28 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:28 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:28 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:28 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:28 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:28 --> Total execution time: 0.6912
DEBUG - 2011-04-12 08:53:34 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:34 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:34 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:34 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:34 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:34 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:34 --> Total execution time: 0.0547
DEBUG - 2011-04-12 08:53:35 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:35 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:35 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:35 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:36 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:36 --> Total execution time: 0.6758
DEBUG - 2011-04-12 08:53:38 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:38 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:38 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:38 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:38 --> Total execution time: 0.0370
DEBUG - 2011-04-12 08:53:42 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:42 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:42 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:42 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:42 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:42 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:42 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:42 --> Total execution time: 0.0468
DEBUG - 2011-04-12 08:53:43 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:43 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:43 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:43 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:43 --> Total execution time: 0.5307
DEBUG - 2011-04-12 08:53:52 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:52 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:52 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Controller Class Initialized
ERROR - 2011-04-12 08:53:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:53:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:52 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:52 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:53:52 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:53:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:53:52 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:52 --> Total execution time: 0.1499
DEBUG - 2011-04-12 08:53:53 --> Config Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:53:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:53:53 --> URI Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Router Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Output Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Input Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:53:53 --> Language Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Loader Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Controller Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Model Class Initialized
DEBUG - 2011-04-12 08:53:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:53:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:53:54 --> Final output sent to browser
DEBUG - 2011-04-12 08:53:54 --> Total execution time: 0.7654
DEBUG - 2011-04-12 08:54:01 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:01 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:01 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Controller Class Initialized
ERROR - 2011-04-12 08:54:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:54:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:01 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:01 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:01 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:54:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:54:01 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:01 --> Total execution time: 0.0310
DEBUG - 2011-04-12 08:54:02 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:02 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:02 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Controller Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:02 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:02 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:02 --> Total execution time: 0.7907
DEBUG - 2011-04-12 08:54:38 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:38 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:38 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Controller Class Initialized
ERROR - 2011-04-12 08:54:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:54:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:54:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:54:38 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:38 --> Total execution time: 0.0780
DEBUG - 2011-04-12 08:54:39 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:39 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:39 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Controller Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:39 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:40 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:40 --> Total execution time: 0.8190
DEBUG - 2011-04-12 08:54:56 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:56 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:56 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Controller Class Initialized
ERROR - 2011-04-12 08:54:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 08:54:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:56 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 08:54:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:54:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:54:56 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:56 --> Total execution time: 0.0531
DEBUG - 2011-04-12 08:54:57 --> Config Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:54:57 --> URI Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Router Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Output Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Input Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:54:57 --> Language Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Loader Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Controller Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Model Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 08:54:57 --> Database Driver Class Initialized
DEBUG - 2011-04-12 08:54:57 --> Final output sent to browser
DEBUG - 2011-04-12 08:54:57 --> Total execution time: 0.5815
DEBUG - 2011-04-12 08:57:47 --> Config Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 08:57:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 08:57:47 --> URI Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Router Class Initialized
DEBUG - 2011-04-12 08:57:47 --> No URI present. Default controller set.
DEBUG - 2011-04-12 08:57:47 --> Output Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Input Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 08:57:47 --> Language Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Loader Class Initialized
DEBUG - 2011-04-12 08:57:47 --> Controller Class Initialized
DEBUG - 2011-04-12 08:57:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 08:57:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 08:57:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 08:57:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 08:57:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 08:57:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 08:57:47 --> Final output sent to browser
DEBUG - 2011-04-12 08:57:47 --> Total execution time: 0.5528
DEBUG - 2011-04-12 09:06:12 --> Config Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:06:12 --> URI Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Router Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Output Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Input Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:06:12 --> Language Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Loader Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Controller Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:06:12 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:06:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:06:13 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:06:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:06:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:06:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:06:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:06:13 --> Final output sent to browser
DEBUG - 2011-04-12 09:06:13 --> Total execution time: 0.8530
DEBUG - 2011-04-12 09:06:17 --> Config Class Initialized
DEBUG - 2011-04-12 09:06:17 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:06:17 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:06:17 --> URI Class Initialized
DEBUG - 2011-04-12 09:06:17 --> Router Class Initialized
ERROR - 2011-04-12 09:06:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:06:36 --> Config Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:06:36 --> URI Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Router Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Output Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Input Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:06:36 --> Language Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Loader Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Controller Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Model Class Initialized
DEBUG - 2011-04-12 09:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:06:36 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:06:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:06:37 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:06:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:06:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:06:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:06:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:06:37 --> Final output sent to browser
DEBUG - 2011-04-12 09:06:37 --> Total execution time: 0.8362
DEBUG - 2011-04-12 09:06:39 --> Config Class Initialized
DEBUG - 2011-04-12 09:06:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:06:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:06:39 --> URI Class Initialized
DEBUG - 2011-04-12 09:06:39 --> Router Class Initialized
ERROR - 2011-04-12 09:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:09:43 --> Config Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:09:43 --> URI Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Router Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Output Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Input Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:09:43 --> Language Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Loader Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Controller Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Model Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Model Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Model Class Initialized
DEBUG - 2011-04-12 09:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:09:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:09:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:09:43 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:09:43 --> Final output sent to browser
DEBUG - 2011-04-12 09:09:43 --> Total execution time: 0.1393
DEBUG - 2011-04-12 09:18:31 --> Config Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:18:31 --> URI Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Router Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Output Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Input Class Initialized
DEBUG - 2011-04-12 09:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:18:31 --> Language Class Initialized
DEBUG - 2011-04-12 09:18:32 --> Loader Class Initialized
DEBUG - 2011-04-12 09:18:32 --> Controller Class Initialized
ERROR - 2011-04-12 09:18:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 09:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 09:18:32 --> Model Class Initialized
DEBUG - 2011-04-12 09:18:32 --> Model Class Initialized
DEBUG - 2011-04-12 09:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:18:32 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 09:18:32 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:18:32 --> Final output sent to browser
DEBUG - 2011-04-12 09:18:32 --> Total execution time: 0.1584
DEBUG - 2011-04-12 09:18:34 --> Config Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:18:34 --> URI Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Router Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Output Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Input Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:18:34 --> Language Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Loader Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Controller Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Model Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Model Class Initialized
DEBUG - 2011-04-12 09:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:18:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:18:35 --> Final output sent to browser
DEBUG - 2011-04-12 09:18:35 --> Total execution time: 1.0444
DEBUG - 2011-04-12 09:18:37 --> Config Class Initialized
DEBUG - 2011-04-12 09:18:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:18:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:18:37 --> URI Class Initialized
DEBUG - 2011-04-12 09:18:37 --> Router Class Initialized
ERROR - 2011-04-12 09:18:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:24:48 --> Config Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:24:48 --> URI Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Router Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Output Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Input Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:24:48 --> Language Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Loader Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Controller Class Initialized
ERROR - 2011-04-12 09:24:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 09:24:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 09:24:48 --> Model Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Model Class Initialized
DEBUG - 2011-04-12 09:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:24:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 09:24:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:24:48 --> Final output sent to browser
DEBUG - 2011-04-12 09:24:48 --> Total execution time: 0.1296
DEBUG - 2011-04-12 09:24:50 --> Config Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:24:50 --> URI Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Router Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Output Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Input Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:24:50 --> Language Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Loader Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Controller Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Model Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Model Class Initialized
DEBUG - 2011-04-12 09:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:24:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:24:51 --> Final output sent to browser
DEBUG - 2011-04-12 09:24:51 --> Total execution time: 0.6810
DEBUG - 2011-04-12 09:24:53 --> Config Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:24:53 --> URI Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Router Class Initialized
ERROR - 2011-04-12 09:24:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:24:53 --> Config Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:24:53 --> URI Class Initialized
DEBUG - 2011-04-12 09:24:53 --> Router Class Initialized
ERROR - 2011-04-12 09:24:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:25:31 --> Config Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:25:31 --> URI Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Router Class Initialized
DEBUG - 2011-04-12 09:25:31 --> No URI present. Default controller set.
DEBUG - 2011-04-12 09:25:31 --> Output Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Input Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:25:31 --> Language Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Loader Class Initialized
DEBUG - 2011-04-12 09:25:31 --> Controller Class Initialized
DEBUG - 2011-04-12 09:25:31 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 09:25:31 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:25:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:25:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:25:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:25:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:25:31 --> Final output sent to browser
DEBUG - 2011-04-12 09:25:31 --> Total execution time: 0.2080
DEBUG - 2011-04-12 09:25:35 --> Config Class Initialized
DEBUG - 2011-04-12 09:25:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:25:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:25:35 --> URI Class Initialized
DEBUG - 2011-04-12 09:25:35 --> Router Class Initialized
ERROR - 2011-04-12 09:25:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 09:25:47 --> Config Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:25:47 --> URI Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Router Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Output Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Input Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:25:47 --> Language Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Loader Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Controller Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Model Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Model Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Model Class Initialized
DEBUG - 2011-04-12 09:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:25:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:25:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:25:48 --> Final output sent to browser
DEBUG - 2011-04-12 09:25:48 --> Total execution time: 1.1447
DEBUG - 2011-04-12 09:29:23 --> Config Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:29:23 --> URI Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Router Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Output Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Input Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:29:23 --> Language Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Loader Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Controller Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Model Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Model Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Model Class Initialized
DEBUG - 2011-04-12 09:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:29:23 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:29:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:29:25 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:29:25 --> Final output sent to browser
DEBUG - 2011-04-12 09:29:25 --> Total execution time: 1.7531
DEBUG - 2011-04-12 09:55:37 --> Config Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 09:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 09:55:37 --> URI Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Router Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Output Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Input Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 09:55:37 --> Language Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Loader Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Controller Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Model Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Model Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Model Class Initialized
DEBUG - 2011-04-12 09:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 09:55:37 --> Database Driver Class Initialized
DEBUG - 2011-04-12 09:55:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 09:55:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 09:55:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 09:55:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 09:55:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 09:55:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 09:55:38 --> Final output sent to browser
DEBUG - 2011-04-12 09:55:38 --> Total execution time: 1.4477
DEBUG - 2011-04-12 10:02:48 --> Config Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:02:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:02:48 --> URI Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Router Class Initialized
DEBUG - 2011-04-12 10:02:48 --> No URI present. Default controller set.
DEBUG - 2011-04-12 10:02:48 --> Output Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Input Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:02:48 --> Language Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Loader Class Initialized
DEBUG - 2011-04-12 10:02:48 --> Controller Class Initialized
DEBUG - 2011-04-12 10:02:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 10:02:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:02:48 --> Final output sent to browser
DEBUG - 2011-04-12 10:02:48 --> Total execution time: 0.1833
DEBUG - 2011-04-12 10:02:49 --> Config Class Initialized
DEBUG - 2011-04-12 10:02:49 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:02:49 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:02:49 --> URI Class Initialized
DEBUG - 2011-04-12 10:02:49 --> Router Class Initialized
ERROR - 2011-04-12 10:02:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:02:50 --> Config Class Initialized
DEBUG - 2011-04-12 10:02:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:02:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:02:50 --> URI Class Initialized
DEBUG - 2011-04-12 10:02:50 --> Router Class Initialized
ERROR - 2011-04-12 10:02:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:03:37 --> Config Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:03:37 --> URI Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Router Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Output Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Input Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:03:37 --> Language Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Loader Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Controller Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Model Class Initialized
DEBUG - 2011-04-12 10:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:03:37 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:03:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:03:37 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:03:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:03:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:03:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:03:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:03:37 --> Final output sent to browser
DEBUG - 2011-04-12 10:03:37 --> Total execution time: 0.3612
DEBUG - 2011-04-12 10:03:38 --> Config Class Initialized
DEBUG - 2011-04-12 10:03:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:03:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:03:38 --> URI Class Initialized
DEBUG - 2011-04-12 10:03:38 --> Router Class Initialized
ERROR - 2011-04-12 10:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:19:25 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:26 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:26 --> Router Class Initialized
DEBUG - 2011-04-12 10:19:26 --> No URI present. Default controller set.
DEBUG - 2011-04-12 10:19:26 --> Output Class Initialized
DEBUG - 2011-04-12 10:19:28 --> Input Class Initialized
DEBUG - 2011-04-12 10:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:19:28 --> Language Class Initialized
DEBUG - 2011-04-12 10:19:28 --> Loader Class Initialized
DEBUG - 2011-04-12 10:19:28 --> Controller Class Initialized
DEBUG - 2011-04-12 10:19:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 10:19:29 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:19:29 --> Final output sent to browser
DEBUG - 2011-04-12 10:19:29 --> Total execution time: 4.5630
DEBUG - 2011-04-12 10:19:31 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:31 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:31 --> Router Class Initialized
ERROR - 2011-04-12 10:19:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:19:36 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:36 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:36 --> Router Class Initialized
ERROR - 2011-04-12 10:19:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:19:50 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:50 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:50 --> Router Class Initialized
ERROR - 2011-04-12 10:19:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:19:52 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:52 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Router Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Output Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Input Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:19:52 --> Language Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Loader Class Initialized
DEBUG - 2011-04-12 10:19:52 --> Controller Class Initialized
DEBUG - 2011-04-12 10:19:53 --> Model Class Initialized
DEBUG - 2011-04-12 10:19:53 --> Model Class Initialized
DEBUG - 2011-04-12 10:19:53 --> Model Class Initialized
DEBUG - 2011-04-12 10:19:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:19:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:19:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:19:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:19:54 --> Final output sent to browser
DEBUG - 2011-04-12 10:19:54 --> Total execution time: 1.6863
DEBUG - 2011-04-12 10:19:55 --> Config Class Initialized
DEBUG - 2011-04-12 10:19:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:19:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:19:55 --> URI Class Initialized
DEBUG - 2011-04-12 10:19:55 --> Router Class Initialized
ERROR - 2011-04-12 10:19:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:04 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:04 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:04 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:04 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:06 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:06 --> Total execution time: 2.5059
DEBUG - 2011-04-12 10:20:07 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:08 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:08 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:08 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:08 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Router Class Initialized
ERROR - 2011-04-12 10:20:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:08 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:08 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:08 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:08 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:08 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:08 --> Total execution time: 0.4676
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:08 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:08 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:08 --> Total execution time: 0.3612
DEBUG - 2011-04-12 10:20:14 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:14 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:14 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:14 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:16 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:16 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:16 --> Total execution time: 2.1522
DEBUG - 2011-04-12 10:20:18 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:18 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:18 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:18 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:18 --> Router Class Initialized
ERROR - 2011-04-12 10:20:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:24 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:24 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:24 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:24 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:25 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:25 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:25 --> Total execution time: 1.0417
DEBUG - 2011-04-12 10:20:27 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:27 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Router Class Initialized
ERROR - 2011-04-12 10:20:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:27 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:27 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:27 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:27 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:27 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:27 --> Total execution time: 0.3541
DEBUG - 2011-04-12 10:20:34 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:34 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:34 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:35 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:35 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:35 --> Total execution time: 0.9102
DEBUG - 2011-04-12 10:20:36 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:36 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:36 --> Router Class Initialized
ERROR - 2011-04-12 10:20:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:40 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:40 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:40 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:40 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:41 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:41 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:41 --> Total execution time: 0.8441
DEBUG - 2011-04-12 10:20:42 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:42 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:42 --> Router Class Initialized
ERROR - 2011-04-12 10:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:46 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:46 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:46 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:47 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:47 --> Total execution time: 0.9644
DEBUG - 2011-04-12 10:20:48 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:48 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:48 --> Router Class Initialized
ERROR - 2011-04-12 10:20:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:55 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:55 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:55 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:55 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:55 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:55 --> Total execution time: 0.1503
DEBUG - 2011-04-12 10:20:55 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:55 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:55 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:56 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:56 --> Total execution time: 0.9202
DEBUG - 2011-04-12 10:20:57 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:57 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:57 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:57 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:57 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:57 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:57 --> Total execution time: 0.2410
DEBUG - 2011-04-12 10:20:57 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:57 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:57 --> Router Class Initialized
ERROR - 2011-04-12 10:20:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:20:58 --> Config Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:20:58 --> URI Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Router Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Output Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Input Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:20:58 --> Language Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Loader Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Controller Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:20:58 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:20:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:20:58 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:20:58 --> Final output sent to browser
DEBUG - 2011-04-12 10:20:58 --> Total execution time: 0.2457
DEBUG - 2011-04-12 10:21:04 --> Config Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:21:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:21:04 --> URI Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Router Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Output Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Input Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:21:04 --> Language Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Loader Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Controller Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:21:04 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:21:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:21:04 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:21:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:21:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:21:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:21:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:21:04 --> Final output sent to browser
DEBUG - 2011-04-12 10:21:04 --> Total execution time: 0.5416
DEBUG - 2011-04-12 10:21:05 --> Config Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:21:05 --> URI Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Router Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Output Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Input Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:21:05 --> Language Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Loader Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Controller Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:21:05 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Config Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:21:05 --> URI Class Initialized
DEBUG - 2011-04-12 10:21:05 --> Router Class Initialized
ERROR - 2011-04-12 10:21:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:21:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:21:05 --> Final output sent to browser
DEBUG - 2011-04-12 10:21:05 --> Total execution time: 0.3648
DEBUG - 2011-04-12 10:21:06 --> Config Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:21:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:21:06 --> URI Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Router Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Output Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Input Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:21:06 --> Language Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Loader Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Controller Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Model Class Initialized
DEBUG - 2011-04-12 10:21:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:21:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:21:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:21:06 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:21:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:21:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:21:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:21:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:21:06 --> Final output sent to browser
DEBUG - 2011-04-12 10:21:06 --> Total execution time: 0.2631
DEBUG - 2011-04-12 10:31:07 --> Config Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:31:07 --> URI Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Router Class Initialized
DEBUG - 2011-04-12 10:31:07 --> No URI present. Default controller set.
DEBUG - 2011-04-12 10:31:07 --> Output Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Input Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:31:07 --> Language Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Loader Class Initialized
DEBUG - 2011-04-12 10:31:07 --> Controller Class Initialized
DEBUG - 2011-04-12 10:31:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 10:31:08 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:31:08 --> Final output sent to browser
DEBUG - 2011-04-12 10:31:08 --> Total execution time: 0.1442
DEBUG - 2011-04-12 10:31:09 --> Config Class Initialized
DEBUG - 2011-04-12 10:31:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:31:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:31:09 --> URI Class Initialized
DEBUG - 2011-04-12 10:31:09 --> Router Class Initialized
ERROR - 2011-04-12 10:31:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:31:10 --> Config Class Initialized
DEBUG - 2011-04-12 10:31:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:31:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:31:10 --> URI Class Initialized
DEBUG - 2011-04-12 10:31:10 --> Router Class Initialized
ERROR - 2011-04-12 10:31:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:37:54 --> Config Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:37:54 --> URI Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Router Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Output Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Input Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:37:54 --> Language Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Loader Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Controller Class Initialized
ERROR - 2011-04-12 10:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 10:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:37:54 --> Model Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Model Class Initialized
DEBUG - 2011-04-12 10:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:37:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:37:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:37:54 --> Final output sent to browser
DEBUG - 2011-04-12 10:37:54 --> Total execution time: 0.1958
DEBUG - 2011-04-12 10:37:56 --> Config Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:37:56 --> URI Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Router Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Output Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Input Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:37:56 --> Language Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Loader Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Controller Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Model Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Model Class Initialized
DEBUG - 2011-04-12 10:37:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:37:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:37:57 --> Final output sent to browser
DEBUG - 2011-04-12 10:37:57 --> Total execution time: 0.8968
DEBUG - 2011-04-12 10:37:59 --> Config Class Initialized
DEBUG - 2011-04-12 10:37:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:37:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:37:59 --> URI Class Initialized
DEBUG - 2011-04-12 10:37:59 --> Router Class Initialized
ERROR - 2011-04-12 10:37:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 10:51:57 --> Config Class Initialized
DEBUG - 2011-04-12 10:51:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:51:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:51:57 --> URI Class Initialized
DEBUG - 2011-04-12 10:51:57 --> Router Class Initialized
ERROR - 2011-04-12 10:51:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 10:51:58 --> Config Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:51:58 --> URI Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Router Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Output Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Input Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:51:58 --> Language Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Loader Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Controller Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Model Class Initialized
DEBUG - 2011-04-12 10:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:51:58 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:51:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 10:51:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:51:59 --> Final output sent to browser
DEBUG - 2011-04-12 10:51:59 --> Total execution time: 1.0574
DEBUG - 2011-04-12 10:52:29 --> Config Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:52:29 --> URI Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Router Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Output Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Input Class Initialized
DEBUG - 2011-04-12 10:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:52:29 --> Language Class Initialized
DEBUG - 2011-04-12 10:52:30 --> Loader Class Initialized
DEBUG - 2011-04-12 10:52:30 --> Controller Class Initialized
ERROR - 2011-04-12 10:52:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 10:52:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 10:52:30 --> Model Class Initialized
DEBUG - 2011-04-12 10:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:52:30 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:52:30 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:52:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:52:30 --> Final output sent to browser
DEBUG - 2011-04-12 10:52:30 --> Total execution time: 0.1168
DEBUG - 2011-04-12 10:59:53 --> Config Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 10:59:53 --> URI Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Router Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Output Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Input Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 10:59:53 --> Language Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Loader Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Controller Class Initialized
ERROR - 2011-04-12 10:59:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 10:59:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:59:53 --> Model Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Model Class Initialized
DEBUG - 2011-04-12 10:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 10:59:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 10:59:53 --> Helper loaded: url_helper
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 10:59:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 10:59:53 --> Final output sent to browser
DEBUG - 2011-04-12 10:59:53 --> Total execution time: 0.1047
DEBUG - 2011-04-12 11:06:22 --> Config Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:06:22 --> URI Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Router Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Output Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Input Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:06:22 --> Language Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Loader Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Controller Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:06:22 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:06:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:06:22 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:06:22 --> Final output sent to browser
DEBUG - 2011-04-12 11:06:22 --> Total execution time: 0.1436
DEBUG - 2011-04-12 11:12:03 --> Config Class Initialized
DEBUG - 2011-04-12 11:12:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:12:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:12:03 --> URI Class Initialized
DEBUG - 2011-04-12 11:12:03 --> Router Class Initialized
ERROR - 2011-04-12 11:12:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:12:53 --> Config Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:12:53 --> URI Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Router Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Output Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Input Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:12:53 --> Language Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Loader Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Controller Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:12:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:12:53 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:12:53 --> Final output sent to browser
DEBUG - 2011-04-12 11:12:53 --> Total execution time: 0.2522
DEBUG - 2011-04-12 11:13:00 --> Config Class Initialized
DEBUG - 2011-04-12 11:13:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:13:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:13:00 --> URI Class Initialized
DEBUG - 2011-04-12 11:13:00 --> Router Class Initialized
DEBUG - 2011-04-12 11:13:00 --> No URI present. Default controller set.
DEBUG - 2011-04-12 11:13:00 --> Output Class Initialized
DEBUG - 2011-04-12 11:13:01 --> Input Class Initialized
DEBUG - 2011-04-12 11:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:13:01 --> Language Class Initialized
DEBUG - 2011-04-12 11:13:01 --> Loader Class Initialized
DEBUG - 2011-04-12 11:13:01 --> Controller Class Initialized
DEBUG - 2011-04-12 11:13:01 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 11:13:01 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:13:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:13:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:13:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:13:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:13:01 --> Final output sent to browser
DEBUG - 2011-04-12 11:13:01 --> Total execution time: 0.0671
DEBUG - 2011-04-12 11:17:39 --> Config Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:17:39 --> URI Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Router Class Initialized
DEBUG - 2011-04-12 11:17:39 --> No URI present. Default controller set.
DEBUG - 2011-04-12 11:17:39 --> Output Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Input Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:17:39 --> Language Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Loader Class Initialized
DEBUG - 2011-04-12 11:17:39 --> Controller Class Initialized
DEBUG - 2011-04-12 11:17:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 11:17:39 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:17:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:17:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:17:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:17:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:17:39 --> Final output sent to browser
DEBUG - 2011-04-12 11:17:39 --> Total execution time: 0.0415
DEBUG - 2011-04-12 11:17:40 --> Config Class Initialized
DEBUG - 2011-04-12 11:17:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:17:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:17:40 --> URI Class Initialized
DEBUG - 2011-04-12 11:17:40 --> Router Class Initialized
ERROR - 2011-04-12 11:17:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:18:02 --> Config Class Initialized
DEBUG - 2011-04-12 11:18:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:18:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:18:02 --> URI Class Initialized
DEBUG - 2011-04-12 11:18:02 --> Router Class Initialized
ERROR - 2011-04-12 11:18:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:19:46 --> Config Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:19:46 --> URI Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Router Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Output Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Input Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:19:46 --> Language Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Loader Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Controller Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Model Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Model Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Model Class Initialized
DEBUG - 2011-04-12 11:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:19:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:19:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:19:46 --> Final output sent to browser
DEBUG - 2011-04-12 11:19:46 --> Total execution time: 0.2688
DEBUG - 2011-04-12 11:19:51 --> Config Class Initialized
DEBUG - 2011-04-12 11:19:51 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:19:51 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:19:51 --> URI Class Initialized
DEBUG - 2011-04-12 11:19:51 --> Router Class Initialized
ERROR - 2011-04-12 11:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:19:52 --> Config Class Initialized
DEBUG - 2011-04-12 11:19:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:19:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:19:52 --> URI Class Initialized
DEBUG - 2011-04-12 11:19:52 --> Router Class Initialized
ERROR - 2011-04-12 11:19:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:19:53 --> Config Class Initialized
DEBUG - 2011-04-12 11:19:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:19:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:19:53 --> URI Class Initialized
DEBUG - 2011-04-12 11:19:53 --> Router Class Initialized
ERROR - 2011-04-12 11:19:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:20:06 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:06 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:06 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:06 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:07 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:07 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:07 --> Total execution time: 0.9795
DEBUG - 2011-04-12 11:20:13 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:13 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:13 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:13 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:13 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:13 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:13 --> Total execution time: 0.1243
DEBUG - 2011-04-12 11:20:18 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:18 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:18 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:18 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:19 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:19 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:19 --> Total execution time: 0.8654
DEBUG - 2011-04-12 11:20:21 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:21 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:21 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:21 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:21 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:21 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:21 --> Total execution time: 0.0661
DEBUG - 2011-04-12 11:20:26 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:26 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:26 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:26 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:27 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:27 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:27 --> Total execution time: 0.6018
DEBUG - 2011-04-12 11:20:35 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:35 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:35 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:35 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:35 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:35 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:35 --> Total execution time: 0.1387
DEBUG - 2011-04-12 11:20:36 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:36 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:36 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:36 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:37 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:37 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:37 --> Total execution time: 1.5947
DEBUG - 2011-04-12 11:20:44 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:44 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:44 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:44 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:45 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:45 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:45 --> Total execution time: 1.3734
DEBUG - 2011-04-12 11:20:49 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:49 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:49 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:49 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:49 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:49 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:49 --> Total execution time: 0.2198
DEBUG - 2011-04-12 11:20:53 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:53 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:53 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:53 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:53 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:53 --> Total execution time: 0.4142
DEBUG - 2011-04-12 11:20:55 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:55 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:55 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:55 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:55 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:55 --> Total execution time: 0.0565
DEBUG - 2011-04-12 11:20:56 --> Config Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:20:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:20:56 --> URI Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Router Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Output Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Input Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:20:56 --> Language Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Loader Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Controller Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:20:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:20:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:20:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:20:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:20:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:20:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:20:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:20:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:20:56 --> Final output sent to browser
DEBUG - 2011-04-12 11:20:56 --> Total execution time: 0.0637
DEBUG - 2011-04-12 11:21:03 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:03 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:03 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:03 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:03 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:03 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:03 --> Total execution time: 0.4403
DEBUG - 2011-04-12 11:21:05 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:05 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:05 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:05 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:05 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:05 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:05 --> Total execution time: 0.0633
DEBUG - 2011-04-12 11:21:13 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:13 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:13 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:13 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:13 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:13 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:13 --> Total execution time: 0.7842
DEBUG - 2011-04-12 11:21:15 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:15 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:15 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:15 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:15 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:15 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:15 --> Total execution time: 0.1406
DEBUG - 2011-04-12 11:21:22 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:22 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:22 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:22 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:22 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:22 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:22 --> Total execution time: 0.3102
DEBUG - 2011-04-12 11:21:24 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:24 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:24 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:24 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:24 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:24 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:24 --> Total execution time: 0.0693
DEBUG - 2011-04-12 11:21:32 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:32 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:32 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:32 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:32 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:32 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:32 --> Total execution time: 0.4577
DEBUG - 2011-04-12 11:21:35 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:35 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:35 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:35 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:35 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:35 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:35 --> Total execution time: 0.1068
DEBUG - 2011-04-12 11:21:39 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:39 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:39 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:39 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:40 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:40 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:40 --> Total execution time: 0.4748
DEBUG - 2011-04-12 11:21:47 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:47 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:47 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:47 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:47 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:47 --> Total execution time: 0.1315
DEBUG - 2011-04-12 11:21:48 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:48 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:48 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:48 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:48 --> Total execution time: 0.5476
DEBUG - 2011-04-12 11:21:50 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:50 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:50 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:50 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:50 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:50 --> Total execution time: 0.1016
DEBUG - 2011-04-12 11:21:50 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:50 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:50 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:50 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:50 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:50 --> Total execution time: 0.1152
DEBUG - 2011-04-12 11:21:53 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:53 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:54 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:54 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:54 --> Total execution time: 0.3011
DEBUG - 2011-04-12 11:21:56 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:56 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:56 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:56 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:56 --> Total execution time: 0.0426
DEBUG - 2011-04-12 11:21:59 --> Config Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:21:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:21:59 --> URI Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Router Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Output Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Input Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:21:59 --> Language Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Loader Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Controller Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Model Class Initialized
DEBUG - 2011-04-12 11:21:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:21:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:21:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:21:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:21:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:21:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:21:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:21:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:21:59 --> Final output sent to browser
DEBUG - 2011-04-12 11:21:59 --> Total execution time: 0.3117
DEBUG - 2011-04-12 11:22:20 --> Config Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:22:20 --> URI Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Router Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Output Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Input Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:22:20 --> Language Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Loader Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Controller Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:22:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:22:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:22:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:22:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:22:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:22:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:22:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:22:20 --> Final output sent to browser
DEBUG - 2011-04-12 11:22:20 --> Total execution time: 0.0466
DEBUG - 2011-04-12 11:22:25 --> Config Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:22:25 --> URI Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Router Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Output Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Input Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:22:25 --> Language Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Loader Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Controller Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:22:25 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:22:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:22:25 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:22:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:22:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:22:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:22:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:22:25 --> Final output sent to browser
DEBUG - 2011-04-12 11:22:25 --> Total execution time: 0.2684
DEBUG - 2011-04-12 11:22:42 --> Config Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:22:42 --> URI Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Router Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Output Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Input Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:22:42 --> Language Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Loader Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Controller Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Model Class Initialized
DEBUG - 2011-04-12 11:22:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:22:42 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:22:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 11:22:42 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:22:42 --> Final output sent to browser
DEBUG - 2011-04-12 11:22:42 --> Total execution time: 0.0787
DEBUG - 2011-04-12 11:31:34 --> Config Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:31:34 --> URI Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Router Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Output Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Input Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:31:34 --> Language Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Loader Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Controller Class Initialized
ERROR - 2011-04-12 11:31:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 11:31:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 11:31:34 --> Model Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Model Class Initialized
DEBUG - 2011-04-12 11:31:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:31:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 11:31:34 --> Helper loaded: url_helper
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 11:31:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 11:31:34 --> Final output sent to browser
DEBUG - 2011-04-12 11:31:34 --> Total execution time: 0.1670
DEBUG - 2011-04-12 11:31:35 --> Config Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:31:35 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:31:35 --> URI Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Router Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Output Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Input Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 11:31:35 --> Language Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Loader Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Controller Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Model Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 11:31:35 --> Database Driver Class Initialized
DEBUG - 2011-04-12 11:31:35 --> Final output sent to browser
DEBUG - 2011-04-12 11:31:35 --> Total execution time: 0.7680
DEBUG - 2011-04-12 11:31:36 --> Config Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:31:36 --> URI Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Router Class Initialized
ERROR - 2011-04-12 11:31:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 11:31:36 --> Config Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 11:31:36 --> URI Class Initialized
DEBUG - 2011-04-12 11:31:36 --> Router Class Initialized
ERROR - 2011-04-12 11:31:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:19:59 --> Config Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:19:59 --> URI Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Router Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Output Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Input Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:19:59 --> Language Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Loader Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Controller Class Initialized
ERROR - 2011-04-12 12:19:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 12:19:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:19:59 --> Model Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Model Class Initialized
DEBUG - 2011-04-12 12:19:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:19:59 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:19:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:19:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:19:59 --> Final output sent to browser
DEBUG - 2011-04-12 12:19:59 --> Total execution time: 0.3645
DEBUG - 2011-04-12 12:20:00 --> Config Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:20:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:20:00 --> URI Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Router Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Output Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Input Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:20:00 --> Language Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Loader Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Controller Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Model Class Initialized
DEBUG - 2011-04-12 12:20:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:20:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:20:01 --> Final output sent to browser
DEBUG - 2011-04-12 12:20:01 --> Total execution time: 0.9023
DEBUG - 2011-04-12 12:20:02 --> Config Class Initialized
DEBUG - 2011-04-12 12:20:02 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:20:02 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:20:02 --> URI Class Initialized
DEBUG - 2011-04-12 12:20:02 --> Router Class Initialized
ERROR - 2011-04-12 12:20:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:20:03 --> Config Class Initialized
DEBUG - 2011-04-12 12:20:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:20:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:20:03 --> URI Class Initialized
DEBUG - 2011-04-12 12:20:03 --> Router Class Initialized
ERROR - 2011-04-12 12:20:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:21:46 --> Config Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:21:46 --> URI Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Router Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Output Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Input Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:21:46 --> Language Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Loader Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Controller Class Initialized
ERROR - 2011-04-12 12:21:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 12:21:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:21:46 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:21:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:21:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:21:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:21:46 --> Final output sent to browser
DEBUG - 2011-04-12 12:21:46 --> Total execution time: 0.0736
DEBUG - 2011-04-12 12:21:47 --> Config Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:21:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:21:47 --> URI Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Router Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Output Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Input Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:21:47 --> Language Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Loader Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Controller Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:21:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:21:48 --> Final output sent to browser
DEBUG - 2011-04-12 12:21:48 --> Total execution time: 0.7330
DEBUG - 2011-04-12 12:21:51 --> Config Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:21:51 --> URI Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Router Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Output Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Input Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:21:51 --> Language Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Loader Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Controller Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Model Class Initialized
DEBUG - 2011-04-12 12:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:21:51 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:21:52 --> Final output sent to browser
DEBUG - 2011-04-12 12:21:52 --> Total execution time: 0.7876
DEBUG - 2011-04-12 12:22:08 --> Config Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:22:08 --> URI Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Router Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Output Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Input Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:22:08 --> Language Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Loader Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Controller Class Initialized
DEBUG - 2011-04-12 12:22:08 --> Model Class Initialized
DEBUG - 2011-04-12 12:22:09 --> Model Class Initialized
DEBUG - 2011-04-12 12:22:09 --> Model Class Initialized
DEBUG - 2011-04-12 12:22:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:22:09 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:22:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 12:22:10 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:22:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:22:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:22:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:22:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:22:10 --> Final output sent to browser
DEBUG - 2011-04-12 12:22:10 --> Total execution time: 2.0098
DEBUG - 2011-04-12 12:28:07 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:07 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Router Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Output Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Input Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:28:07 --> Language Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Loader Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Controller Class Initialized
ERROR - 2011-04-12 12:28:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 12:28:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 12:28:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:28:07 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:28:08 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:28:08 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:28:08 --> Final output sent to browser
DEBUG - 2011-04-12 12:28:08 --> Total execution time: 0.0311
DEBUG - 2011-04-12 12:28:08 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:08 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Router Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Output Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Input Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:28:08 --> Language Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Loader Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Controller Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:28:08 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:28:09 --> Final output sent to browser
DEBUG - 2011-04-12 12:28:09 --> Total execution time: 0.6481
DEBUG - 2011-04-12 12:28:09 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:09 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:09 --> Router Class Initialized
ERROR - 2011-04-12 12:28:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:28:10 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:10 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:10 --> Router Class Initialized
ERROR - 2011-04-12 12:28:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:28:11 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:11 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:11 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:11 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:11 --> Router Class Initialized
ERROR - 2011-04-12 12:28:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 12:28:14 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:14 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Router Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Output Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Input Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:28:14 --> Language Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Loader Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Controller Class Initialized
ERROR - 2011-04-12 12:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 12:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:28:14 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:28:14 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:28:14 --> Final output sent to browser
DEBUG - 2011-04-12 12:28:14 --> Total execution time: 0.0444
DEBUG - 2011-04-12 12:28:14 --> Config Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:28:14 --> URI Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Router Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Output Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Input Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:28:14 --> Language Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Loader Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Controller Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Model Class Initialized
DEBUG - 2011-04-12 12:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:28:14 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:28:15 --> Final output sent to browser
DEBUG - 2011-04-12 12:28:15 --> Total execution time: 0.6816
DEBUG - 2011-04-12 12:40:38 --> Config Class Initialized
DEBUG - 2011-04-12 12:40:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:40:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:40:38 --> URI Class Initialized
DEBUG - 2011-04-12 12:40:38 --> Router Class Initialized
ERROR - 2011-04-12 12:40:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 12:40:40 --> Config Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:40:40 --> URI Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Router Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Output Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Input Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:40:40 --> Language Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Loader Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Controller Class Initialized
ERROR - 2011-04-12 12:40:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 12:40:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:40:40 --> Model Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Model Class Initialized
DEBUG - 2011-04-12 12:40:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 12:40:40 --> Database Driver Class Initialized
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 12:40:40 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:40:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:40:40 --> Final output sent to browser
DEBUG - 2011-04-12 12:40:40 --> Total execution time: 0.3162
DEBUG - 2011-04-12 12:58:10 --> Config Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 12:58:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 12:58:10 --> URI Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Router Class Initialized
DEBUG - 2011-04-12 12:58:10 --> No URI present. Default controller set.
DEBUG - 2011-04-12 12:58:10 --> Output Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Input Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 12:58:10 --> Language Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Loader Class Initialized
DEBUG - 2011-04-12 12:58:10 --> Controller Class Initialized
DEBUG - 2011-04-12 12:58:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 12:58:10 --> Helper loaded: url_helper
DEBUG - 2011-04-12 12:58:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 12:58:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 12:58:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 12:58:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 12:58:10 --> Final output sent to browser
DEBUG - 2011-04-12 12:58:10 --> Total execution time: 0.1090
DEBUG - 2011-04-12 13:01:16 --> Config Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:01:16 --> URI Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Router Class Initialized
ERROR - 2011-04-12 13:01:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 13:01:16 --> Config Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:01:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:01:16 --> URI Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Router Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Output Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Input Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:01:16 --> Language Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Loader Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Controller Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Model Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Model Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Model Class Initialized
DEBUG - 2011-04-12 13:01:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:01:16 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:01:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 13:01:18 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:01:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:01:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:01:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:01:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:01:18 --> Final output sent to browser
DEBUG - 2011-04-12 13:01:18 --> Total execution time: 1.9181
DEBUG - 2011-04-12 13:11:47 --> Config Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:11:47 --> URI Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Router Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Output Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Input Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:11:47 --> Language Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Loader Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Controller Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Model Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Model Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Model Class Initialized
DEBUG - 2011-04-12 13:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:11:47 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:11:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 13:11:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:11:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:11:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:11:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:11:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:11:48 --> Final output sent to browser
DEBUG - 2011-04-12 13:11:48 --> Total execution time: 0.8338
DEBUG - 2011-04-12 13:52:55 --> Config Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:52:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:52:55 --> URI Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Router Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Output Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Input Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:52:55 --> Language Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Loader Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Controller Class Initialized
ERROR - 2011-04-12 13:52:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:52:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:52:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:52:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:52:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:52:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:52:56 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:52:56 --> Final output sent to browser
DEBUG - 2011-04-12 13:52:56 --> Total execution time: 0.6947
DEBUG - 2011-04-12 13:52:57 --> Config Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:52:57 --> URI Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Router Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Output Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Input Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:52:57 --> Language Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Loader Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Controller Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Model Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Model Class Initialized
DEBUG - 2011-04-12 13:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:52:57 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:52:58 --> Final output sent to browser
DEBUG - 2011-04-12 13:52:58 --> Total execution time: 0.8936
DEBUG - 2011-04-12 13:53:01 --> Config Class Initialized
DEBUG - 2011-04-12 13:53:01 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:53:01 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:53:01 --> URI Class Initialized
DEBUG - 2011-04-12 13:53:01 --> Router Class Initialized
ERROR - 2011-04-12 13:53:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 13:53:04 --> Config Class Initialized
DEBUG - 2011-04-12 13:53:04 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:53:04 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:53:04 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:53:04 --> URI Class Initialized
DEBUG - 2011-04-12 13:53:04 --> Router Class Initialized
ERROR - 2011-04-12 13:53:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 13:53:16 --> Config Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:53:16 --> URI Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Router Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Output Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Input Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:53:16 --> Language Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Loader Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Controller Class Initialized
ERROR - 2011-04-12 13:53:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:53:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:53:16 --> Model Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Model Class Initialized
DEBUG - 2011-04-12 13:53:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:53:16 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:53:16 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:53:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:53:16 --> Final output sent to browser
DEBUG - 2011-04-12 13:53:16 --> Total execution time: 0.0533
DEBUG - 2011-04-12 13:53:17 --> Config Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:53:17 --> URI Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Router Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Output Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Input Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:53:17 --> Language Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Loader Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Controller Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Model Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Model Class Initialized
DEBUG - 2011-04-12 13:53:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:53:17 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:53:18 --> Final output sent to browser
DEBUG - 2011-04-12 13:53:18 --> Total execution time: 0.6543
DEBUG - 2011-04-12 13:54:09 --> Config Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:54:09 --> URI Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Router Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Output Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Input Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:54:09 --> Language Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Loader Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Controller Class Initialized
ERROR - 2011-04-12 13:54:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:54:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:54:09 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:54:09 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:54:09 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:54:09 --> Final output sent to browser
DEBUG - 2011-04-12 13:54:09 --> Total execution time: 0.0299
DEBUG - 2011-04-12 13:54:10 --> Config Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:54:10 --> URI Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Router Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Output Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Input Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:54:10 --> Language Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Loader Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Controller Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:54:10 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:54:10 --> Final output sent to browser
DEBUG - 2011-04-12 13:54:10 --> Total execution time: 0.6193
DEBUG - 2011-04-12 13:54:30 --> Config Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:54:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:54:30 --> URI Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Router Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Output Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Input Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:54:30 --> Language Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Loader Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Controller Class Initialized
ERROR - 2011-04-12 13:54:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:54:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:54:30 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:54:30 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:54:30 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:54:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:54:30 --> Final output sent to browser
DEBUG - 2011-04-12 13:54:30 --> Total execution time: 0.0307
DEBUG - 2011-04-12 13:54:31 --> Config Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:54:31 --> URI Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Router Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Output Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Input Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:54:31 --> Language Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Loader Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Controller Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Model Class Initialized
DEBUG - 2011-04-12 13:54:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:54:31 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:54:32 --> Final output sent to browser
DEBUG - 2011-04-12 13:54:32 --> Total execution time: 0.6672
DEBUG - 2011-04-12 13:55:38 --> Config Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:55:38 --> URI Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Router Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Output Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Input Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:55:38 --> Language Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Loader Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Controller Class Initialized
ERROR - 2011-04-12 13:55:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:55:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:55:38 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:55:38 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:55:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:55:38 --> Final output sent to browser
DEBUG - 2011-04-12 13:55:38 --> Total execution time: 0.0286
DEBUG - 2011-04-12 13:55:38 --> Config Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:55:38 --> URI Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Router Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Output Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Input Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:55:38 --> Language Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Loader Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Controller Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:55:38 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:55:39 --> Final output sent to browser
DEBUG - 2011-04-12 13:55:39 --> Total execution time: 0.8181
DEBUG - 2011-04-12 13:55:55 --> Config Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:55:55 --> URI Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Router Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Output Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Input Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:55:55 --> Language Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Loader Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Controller Class Initialized
ERROR - 2011-04-12 13:55:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 13:55:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:55:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:55:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 13:55:55 --> Helper loaded: url_helper
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 13:55:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 13:55:55 --> Final output sent to browser
DEBUG - 2011-04-12 13:55:55 --> Total execution time: 0.0308
DEBUG - 2011-04-12 13:55:55 --> Config Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Hooks Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Utf8 Class Initialized
DEBUG - 2011-04-12 13:55:55 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 13:55:55 --> URI Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Router Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Output Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Input Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 13:55:55 --> Language Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Loader Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Controller Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Model Class Initialized
DEBUG - 2011-04-12 13:55:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 13:55:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 13:55:56 --> Final output sent to browser
DEBUG - 2011-04-12 13:55:56 --> Total execution time: 0.7155
DEBUG - 2011-04-12 14:19:48 --> Config Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:19:48 --> URI Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Router Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Output Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Input Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:19:48 --> Language Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Loader Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Controller Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Model Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Model Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Model Class Initialized
DEBUG - 2011-04-12 14:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:19:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:19:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 14:19:49 --> Helper loaded: url_helper
DEBUG - 2011-04-12 14:19:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 14:19:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 14:19:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 14:19:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 14:19:49 --> Final output sent to browser
DEBUG - 2011-04-12 14:19:49 --> Total execution time: 0.6282
DEBUG - 2011-04-12 14:20:20 --> Config Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:20:20 --> URI Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Router Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Output Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Input Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:20:20 --> Language Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Loader Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Controller Class Initialized
ERROR - 2011-04-12 14:20:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 14:20:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:20:20 --> Model Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Model Class Initialized
DEBUG - 2011-04-12 14:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:20:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:20:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 14:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 14:20:20 --> Final output sent to browser
DEBUG - 2011-04-12 14:20:20 --> Total execution time: 0.1239
DEBUG - 2011-04-12 14:20:21 --> Config Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:20:21 --> URI Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Router Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Output Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Input Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:20:21 --> Language Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Loader Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Controller Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 14:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:20:21 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:20:22 --> Final output sent to browser
DEBUG - 2011-04-12 14:20:22 --> Total execution time: 1.1274
DEBUG - 2011-04-12 14:25:46 --> Config Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:25:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:25:46 --> URI Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Router Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Output Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Input Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:25:46 --> Language Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Loader Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Controller Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Model Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Model Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Model Class Initialized
DEBUG - 2011-04-12 14:25:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:25:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:25:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 14:25:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 14:25:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 14:25:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 14:25:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 14:25:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 14:25:46 --> Final output sent to browser
DEBUG - 2011-04-12 14:25:46 --> Total execution time: 0.1412
DEBUG - 2011-04-12 14:25:47 --> Config Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:25:47 --> URI Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Router Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Output Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Input Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:25:47 --> Language Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Loader Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Controller Class Initialized
ERROR - 2011-04-12 14:25:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 14:25:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 14:25:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:25:47 --> Model Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Model Class Initialized
DEBUG - 2011-04-12 14:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:25:48 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:25:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:25:48 --> Helper loaded: url_helper
DEBUG - 2011-04-12 14:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 14:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 14:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 14:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 14:25:48 --> Final output sent to browser
DEBUG - 2011-04-12 14:25:48 --> Total execution time: 0.0870
DEBUG - 2011-04-12 14:50:58 --> Config Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Hooks Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Utf8 Class Initialized
DEBUG - 2011-04-12 14:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 14:50:58 --> URI Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Router Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Output Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Input Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 14:50:58 --> Language Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Loader Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Controller Class Initialized
ERROR - 2011-04-12 14:50:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 14:50:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:50:58 --> Model Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Model Class Initialized
DEBUG - 2011-04-12 14:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 14:50:58 --> Database Driver Class Initialized
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 14:50:58 --> Helper loaded: url_helper
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 14:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 14:50:58 --> Final output sent to browser
DEBUG - 2011-04-12 14:50:58 --> Total execution time: 0.3281
DEBUG - 2011-04-12 15:09:40 --> Config Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:09:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:09:40 --> URI Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Router Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Output Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Input Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:09:40 --> Language Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Loader Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Controller Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Model Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Model Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Model Class Initialized
DEBUG - 2011-04-12 15:09:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:09:40 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:09:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 15:09:41 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:09:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:09:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:09:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:09:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:09:41 --> Final output sent to browser
DEBUG - 2011-04-12 15:09:41 --> Total execution time: 0.4233
DEBUG - 2011-04-12 15:09:43 --> Config Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:09:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:09:43 --> URI Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Router Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Output Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Input Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:09:43 --> Language Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Loader Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Controller Class Initialized
ERROR - 2011-04-12 15:09:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:09:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:09:43 --> Model Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Model Class Initialized
DEBUG - 2011-04-12 15:09:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:09:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:09:43 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:09:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:09:43 --> Final output sent to browser
DEBUG - 2011-04-12 15:09:43 --> Total execution time: 0.0846
DEBUG - 2011-04-12 15:19:49 --> Config Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:19:49 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:19:49 --> URI Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Router Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Output Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Input Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:19:49 --> Language Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Loader Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Controller Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Model Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Model Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Model Class Initialized
DEBUG - 2011-04-12 15:19:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:19:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:19:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 15:19:50 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:19:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:19:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:19:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:19:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:19:50 --> Final output sent to browser
DEBUG - 2011-04-12 15:19:50 --> Total execution time: 0.2734
DEBUG - 2011-04-12 15:19:52 --> Config Class Initialized
DEBUG - 2011-04-12 15:19:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:19:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:19:52 --> URI Class Initialized
DEBUG - 2011-04-12 15:19:52 --> Router Class Initialized
ERROR - 2011-04-12 15:19:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 15:19:54 --> Config Class Initialized
DEBUG - 2011-04-12 15:19:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:19:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:19:54 --> URI Class Initialized
DEBUG - 2011-04-12 15:19:54 --> Router Class Initialized
ERROR - 2011-04-12 15:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 15:20:20 --> Config Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:20:20 --> URI Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Router Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Output Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Input Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:20:20 --> Language Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Loader Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Controller Class Initialized
ERROR - 2011-04-12 15:20:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:20:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:20:20 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:20:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:20:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:20:20 --> Final output sent to browser
DEBUG - 2011-04-12 15:20:20 --> Total execution time: 0.0773
DEBUG - 2011-04-12 15:20:21 --> Config Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:20:21 --> URI Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Router Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Output Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Input Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:20:21 --> Language Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Loader Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Controller Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:20:21 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:20:22 --> Final output sent to browser
DEBUG - 2011-04-12 15:20:22 --> Total execution time: 0.6637
DEBUG - 2011-04-12 15:20:50 --> Config Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:20:50 --> URI Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Router Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Output Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Input Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:20:50 --> Language Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Loader Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Controller Class Initialized
ERROR - 2011-04-12 15:20:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:20:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:20:50 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:20:50 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:20:50 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:20:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:20:50 --> Final output sent to browser
DEBUG - 2011-04-12 15:20:50 --> Total execution time: 0.0357
DEBUG - 2011-04-12 15:20:51 --> Config Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:20:51 --> URI Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Router Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Output Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Input Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:20:51 --> Language Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Loader Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Controller Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Model Class Initialized
DEBUG - 2011-04-12 15:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:20:51 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:20:52 --> Final output sent to browser
DEBUG - 2011-04-12 15:20:52 --> Total execution time: 1.1565
DEBUG - 2011-04-12 15:21:23 --> Config Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:21:23 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:21:23 --> URI Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Router Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Output Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Input Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:21:23 --> Language Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Loader Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Controller Class Initialized
ERROR - 2011-04-12 15:21:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:21:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:21:23 --> Model Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Model Class Initialized
DEBUG - 2011-04-12 15:21:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:21:23 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:21:23 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:21:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:21:23 --> Final output sent to browser
DEBUG - 2011-04-12 15:21:23 --> Total execution time: 0.0555
DEBUG - 2011-04-12 15:21:25 --> Config Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:21:25 --> URI Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Router Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Output Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Input Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:21:25 --> Language Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Loader Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Controller Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Model Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Model Class Initialized
DEBUG - 2011-04-12 15:21:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:21:25 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:21:26 --> Final output sent to browser
DEBUG - 2011-04-12 15:21:26 --> Total execution time: 1.0825
DEBUG - 2011-04-12 15:29:28 --> Config Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:29:28 --> URI Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Router Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Output Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Input Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:29:28 --> Language Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Loader Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Controller Class Initialized
ERROR - 2011-04-12 15:29:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:29:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:29:28 --> Model Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Model Class Initialized
DEBUG - 2011-04-12 15:29:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:29:28 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:29:28 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:29:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:29:28 --> Final output sent to browser
DEBUG - 2011-04-12 15:29:28 --> Total execution time: 0.1097
DEBUG - 2011-04-12 15:30:54 --> Config Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:30:54 --> URI Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Router Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Output Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Input Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:30:54 --> Language Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Loader Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Controller Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Model Class Initialized
DEBUG - 2011-04-12 15:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:30:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:30:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 15:30:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:30:54 --> Final output sent to browser
DEBUG - 2011-04-12 15:30:54 --> Total execution time: 0.1202
DEBUG - 2011-04-12 15:31:57 --> Config Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:31:57 --> URI Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Router Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Output Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Input Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:31:57 --> Language Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Loader Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Controller Class Initialized
ERROR - 2011-04-12 15:31:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 15:31:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:31:57 --> Model Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Model Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:31:57 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 15:31:57 --> Helper loaded: url_helper
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 15:31:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 15:31:57 --> Final output sent to browser
DEBUG - 2011-04-12 15:31:57 --> Total execution time: 0.0301
DEBUG - 2011-04-12 15:31:57 --> Config Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Hooks Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Utf8 Class Initialized
DEBUG - 2011-04-12 15:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 15:31:57 --> URI Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Router Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Output Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Input Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 15:31:57 --> Language Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Loader Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Controller Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Model Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Model Class Initialized
DEBUG - 2011-04-12 15:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 15:31:57 --> Database Driver Class Initialized
DEBUG - 2011-04-12 15:31:58 --> Final output sent to browser
DEBUG - 2011-04-12 15:31:58 --> Total execution time: 0.7672
DEBUG - 2011-04-12 16:56:27 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:27 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Router Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Output Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Input Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 16:56:27 --> Language Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Loader Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Controller Class Initialized
ERROR - 2011-04-12 16:56:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 16:56:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 16:56:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 16:56:27 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:27 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 16:56:28 --> Database Driver Class Initialized
DEBUG - 2011-04-12 16:56:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 16:56:28 --> Helper loaded: url_helper
DEBUG - 2011-04-12 16:56:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 16:56:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 16:56:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 16:56:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 16:56:28 --> Final output sent to browser
DEBUG - 2011-04-12 16:56:28 --> Total execution time: 1.2953
DEBUG - 2011-04-12 16:56:29 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:29 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Router Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Output Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Input Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 16:56:29 --> Language Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Loader Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Controller Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 16:56:29 --> Database Driver Class Initialized
DEBUG - 2011-04-12 16:56:30 --> Final output sent to browser
DEBUG - 2011-04-12 16:56:30 --> Total execution time: 0.6859
DEBUG - 2011-04-12 16:56:31 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:31 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:31 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:31 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:31 --> Router Class Initialized
ERROR - 2011-04-12 16:56:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 16:56:32 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:32 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Router Class Initialized
ERROR - 2011-04-12 16:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 16:56:32 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:32 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:32 --> Router Class Initialized
ERROR - 2011-04-12 16:56:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 16:56:52 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:52 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Router Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Output Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Input Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 16:56:52 --> Language Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Loader Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Controller Class Initialized
ERROR - 2011-04-12 16:56:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 16:56:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 16:56:52 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 16:56:52 --> Database Driver Class Initialized
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 16:56:52 --> Helper loaded: url_helper
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 16:56:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 16:56:52 --> Final output sent to browser
DEBUG - 2011-04-12 16:56:52 --> Total execution time: 0.0287
DEBUG - 2011-04-12 16:56:53 --> Config Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 16:56:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 16:56:53 --> URI Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Router Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Output Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Input Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 16:56:53 --> Language Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Loader Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Controller Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Model Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 16:56:53 --> Database Driver Class Initialized
DEBUG - 2011-04-12 16:56:53 --> Final output sent to browser
DEBUG - 2011-04-12 16:56:53 --> Total execution time: 0.5479
DEBUG - 2011-04-12 17:03:59 --> Config Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:03:59 --> URI Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Router Class Initialized
DEBUG - 2011-04-12 17:03:59 --> No URI present. Default controller set.
DEBUG - 2011-04-12 17:03:59 --> Output Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Input Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:03:59 --> Language Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Loader Class Initialized
DEBUG - 2011-04-12 17:03:59 --> Controller Class Initialized
DEBUG - 2011-04-12 17:03:59 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 17:03:59 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:03:59 --> Final output sent to browser
DEBUG - 2011-04-12 17:03:59 --> Total execution time: 0.0468
DEBUG - 2011-04-12 17:04:10 --> Config Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:04:10 --> URI Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Router Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Output Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Input Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:04:10 --> Language Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Loader Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Controller Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 17:04:10 --> Database Driver Class Initialized
DEBUG - 2011-04-12 17:04:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 17:04:11 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:04:11 --> Final output sent to browser
DEBUG - 2011-04-12 17:04:11 --> Total execution time: 0.4690
DEBUG - 2011-04-12 17:04:52 --> Config Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:04:52 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:04:52 --> URI Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Router Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Output Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Input Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:04:52 --> Language Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Loader Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Controller Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 17:04:52 --> Database Driver Class Initialized
DEBUG - 2011-04-12 17:04:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 17:04:52 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:04:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:04:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:04:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:04:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:04:52 --> Final output sent to browser
DEBUG - 2011-04-12 17:04:52 --> Total execution time: 0.3425
DEBUG - 2011-04-12 17:04:54 --> Config Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:04:54 --> URI Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Router Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Output Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Input Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:04:54 --> Language Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Loader Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Controller Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Model Class Initialized
DEBUG - 2011-04-12 17:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 17:04:54 --> Database Driver Class Initialized
DEBUG - 2011-04-12 17:04:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 17:04:54 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:04:54 --> Final output sent to browser
DEBUG - 2011-04-12 17:04:54 --> Total execution time: 0.0559
DEBUG - 2011-04-12 17:06:30 --> Config Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:06:30 --> URI Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Router Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Output Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Input Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:06:30 --> Language Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Loader Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Controller Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Model Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Model Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Model Class Initialized
DEBUG - 2011-04-12 17:06:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 17:06:30 --> Database Driver Class Initialized
DEBUG - 2011-04-12 17:06:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 17:06:30 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:06:30 --> Final output sent to browser
DEBUG - 2011-04-12 17:06:30 --> Total execution time: 0.0705
DEBUG - 2011-04-12 17:06:39 --> Config Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 17:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 17:06:39 --> URI Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Router Class Initialized
DEBUG - 2011-04-12 17:06:39 --> No URI present. Default controller set.
DEBUG - 2011-04-12 17:06:39 --> Output Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Input Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 17:06:39 --> Language Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Loader Class Initialized
DEBUG - 2011-04-12 17:06:39 --> Controller Class Initialized
DEBUG - 2011-04-12 17:06:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 17:06:39 --> Helper loaded: url_helper
DEBUG - 2011-04-12 17:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 17:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 17:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 17:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 17:06:39 --> Final output sent to browser
DEBUG - 2011-04-12 17:06:39 --> Total execution time: 0.0124
DEBUG - 2011-04-12 18:28:15 --> Config Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Hooks Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Utf8 Class Initialized
DEBUG - 2011-04-12 18:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 18:28:15 --> URI Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Router Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Output Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Input Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 18:28:15 --> Language Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Loader Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Controller Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Model Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Model Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Model Class Initialized
DEBUG - 2011-04-12 18:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 18:28:15 --> Database Driver Class Initialized
DEBUG - 2011-04-12 18:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 18:28:16 --> Helper loaded: url_helper
DEBUG - 2011-04-12 18:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 18:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 18:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 18:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 18:28:16 --> Final output sent to browser
DEBUG - 2011-04-12 18:28:16 --> Total execution time: 1.6931
DEBUG - 2011-04-12 18:28:19 --> Config Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Hooks Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Utf8 Class Initialized
DEBUG - 2011-04-12 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 18:28:19 --> URI Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Router Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Output Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Input Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 18:28:19 --> Language Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Loader Class Initialized
DEBUG - 2011-04-12 18:28:19 --> Controller Class Initialized
ERROR - 2011-04-12 18:28:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 18:28:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 18:28:20 --> Model Class Initialized
DEBUG - 2011-04-12 18:28:20 --> Model Class Initialized
DEBUG - 2011-04-12 18:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 18:28:20 --> Database Driver Class Initialized
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 18:28:20 --> Helper loaded: url_helper
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 18:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 18:28:20 --> Final output sent to browser
DEBUG - 2011-04-12 18:28:20 --> Total execution time: 0.0999
DEBUG - 2011-04-12 18:28:36 --> Config Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 18:28:36 --> URI Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Router Class Initialized
DEBUG - 2011-04-12 18:28:36 --> No URI present. Default controller set.
DEBUG - 2011-04-12 18:28:36 --> Output Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Input Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 18:28:36 --> Language Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Loader Class Initialized
DEBUG - 2011-04-12 18:28:36 --> Controller Class Initialized
DEBUG - 2011-04-12 18:28:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 18:28:36 --> Helper loaded: url_helper
DEBUG - 2011-04-12 18:28:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 18:28:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 18:28:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 18:28:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 18:28:36 --> Final output sent to browser
DEBUG - 2011-04-12 18:28:36 --> Total execution time: 0.0809
DEBUG - 2011-04-12 19:08:54 --> Config Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:08:54 --> URI Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Router Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Output Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Input Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:08:54 --> Language Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Loader Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Controller Class Initialized
ERROR - 2011-04-12 19:08:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 19:08:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 19:08:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:08:54 --> Model Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Model Class Initialized
DEBUG - 2011-04-12 19:08:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:08:55 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:08:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:08:55 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:08:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:08:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:08:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:08:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:08:55 --> Final output sent to browser
DEBUG - 2011-04-12 19:08:55 --> Total execution time: 0.2915
DEBUG - 2011-04-12 19:08:56 --> Config Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:08:56 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:08:56 --> URI Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Router Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Output Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Input Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:08:56 --> Language Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Loader Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Controller Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Model Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Model Class Initialized
DEBUG - 2011-04-12 19:08:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:08:56 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:08:57 --> Final output sent to browser
DEBUG - 2011-04-12 19:08:57 --> Total execution time: 0.8923
DEBUG - 2011-04-12 19:08:59 --> Config Class Initialized
DEBUG - 2011-04-12 19:08:59 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:08:59 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:08:59 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:08:59 --> URI Class Initialized
DEBUG - 2011-04-12 19:08:59 --> Router Class Initialized
ERROR - 2011-04-12 19:08:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 19:09:00 --> Config Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:09:00 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:09:00 --> URI Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Router Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Output Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Input Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:09:00 --> Language Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Loader Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Controller Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Model Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Model Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Model Class Initialized
DEBUG - 2011-04-12 19:09:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:09:00 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:09:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 19:09:00 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:09:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:09:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:09:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:09:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:09:00 --> Final output sent to browser
DEBUG - 2011-04-12 19:09:00 --> Total execution time: 0.2341
DEBUG - 2011-04-12 19:09:01 --> Config Class Initialized
DEBUG - 2011-04-12 19:09:01 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:09:01 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:09:01 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:09:01 --> URI Class Initialized
DEBUG - 2011-04-12 19:09:01 --> Router Class Initialized
ERROR - 2011-04-12 19:09:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 19:15:39 --> Config Class Initialized
DEBUG - 2011-04-12 19:15:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:15:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:15:39 --> URI Class Initialized
DEBUG - 2011-04-12 19:15:39 --> Router Class Initialized
ERROR - 2011-04-12 19:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 19:18:33 --> Config Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:18:33 --> URI Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Router Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Output Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Input Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:18:33 --> Language Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Loader Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Controller Class Initialized
ERROR - 2011-04-12 19:18:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 19:18:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:18:33 --> Model Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Model Class Initialized
DEBUG - 2011-04-12 19:18:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:18:33 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:18:33 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:18:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:18:33 --> Final output sent to browser
DEBUG - 2011-04-12 19:18:33 --> Total execution time: 0.0300
DEBUG - 2011-04-12 19:18:34 --> Config Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:18:34 --> URI Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Router Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Output Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Input Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:18:34 --> Language Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Loader Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Controller Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Model Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Model Class Initialized
DEBUG - 2011-04-12 19:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:18:34 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:18:35 --> Final output sent to browser
DEBUG - 2011-04-12 19:18:35 --> Total execution time: 0.5479
DEBUG - 2011-04-12 19:18:36 --> Config Class Initialized
DEBUG - 2011-04-12 19:18:36 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:18:36 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:18:36 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:18:36 --> URI Class Initialized
DEBUG - 2011-04-12 19:18:36 --> Router Class Initialized
ERROR - 2011-04-12 19:18:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 19:18:37 --> Config Class Initialized
DEBUG - 2011-04-12 19:18:37 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:18:37 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:18:37 --> URI Class Initialized
DEBUG - 2011-04-12 19:18:37 --> Router Class Initialized
ERROR - 2011-04-12 19:18:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 19:18:53 --> Config Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:18:53 --> URI Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Router Class Initialized
DEBUG - 2011-04-12 19:18:53 --> No URI present. Default controller set.
DEBUG - 2011-04-12 19:18:53 --> Output Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Input Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:18:53 --> Language Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Loader Class Initialized
DEBUG - 2011-04-12 19:18:53 --> Controller Class Initialized
DEBUG - 2011-04-12 19:18:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 19:18:53 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:18:53 --> Final output sent to browser
DEBUG - 2011-04-12 19:18:53 --> Total execution time: 0.0643
DEBUG - 2011-04-12 19:19:03 --> Config Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:19:03 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:19:03 --> URI Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Router Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Output Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Input Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:19:03 --> Language Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Loader Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Controller Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Model Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Model Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Model Class Initialized
DEBUG - 2011-04-12 19:19:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:19:03 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:19:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 19:19:03 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:19:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:19:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:19:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:19:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:19:03 --> Final output sent to browser
DEBUG - 2011-04-12 19:19:03 --> Total execution time: 0.0425
DEBUG - 2011-04-12 19:56:07 --> Config Class Initialized
DEBUG - 2011-04-12 19:56:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:56:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:56:07 --> URI Class Initialized
DEBUG - 2011-04-12 19:56:07 --> Router Class Initialized
ERROR - 2011-04-12 19:56:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 19:56:46 --> Config Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Hooks Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Utf8 Class Initialized
DEBUG - 2011-04-12 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 19:56:46 --> URI Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Router Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Output Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Input Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 19:56:46 --> Language Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Loader Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Controller Class Initialized
ERROR - 2011-04-12 19:56:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 19:56:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:56:46 --> Model Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Model Class Initialized
DEBUG - 2011-04-12 19:56:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 19:56:46 --> Database Driver Class Initialized
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 19:56:46 --> Helper loaded: url_helper
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 19:56:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 19:56:46 --> Final output sent to browser
DEBUG - 2011-04-12 19:56:46 --> Total execution time: 0.2441
DEBUG - 2011-04-12 21:24:39 --> Config Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Hooks Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Utf8 Class Initialized
DEBUG - 2011-04-12 21:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 21:24:39 --> URI Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Router Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Output Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Input Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 21:24:39 --> Language Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Loader Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Controller Class Initialized
ERROR - 2011-04-12 21:24:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 21:24:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 21:24:39 --> Model Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Model Class Initialized
DEBUG - 2011-04-12 21:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 21:24:39 --> Database Driver Class Initialized
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 21:24:39 --> Helper loaded: url_helper
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 21:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 21:24:39 --> Final output sent to browser
DEBUG - 2011-04-12 21:24:39 --> Total execution time: 0.3324
DEBUG - 2011-04-12 21:24:40 --> Config Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Hooks Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Utf8 Class Initialized
DEBUG - 2011-04-12 21:24:40 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 21:24:40 --> URI Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Router Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Output Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Input Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 21:24:40 --> Language Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Loader Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Controller Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Model Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Model Class Initialized
DEBUG - 2011-04-12 21:24:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 21:24:40 --> Database Driver Class Initialized
DEBUG - 2011-04-12 21:24:41 --> Final output sent to browser
DEBUG - 2011-04-12 21:24:41 --> Total execution time: 0.7242
DEBUG - 2011-04-12 21:24:44 --> Config Class Initialized
DEBUG - 2011-04-12 21:24:44 --> Hooks Class Initialized
DEBUG - 2011-04-12 21:24:44 --> Utf8 Class Initialized
DEBUG - 2011-04-12 21:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 21:24:44 --> URI Class Initialized
DEBUG - 2011-04-12 21:24:44 --> Router Class Initialized
ERROR - 2011-04-12 21:24:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 21:24:50 --> Config Class Initialized
DEBUG - 2011-04-12 21:24:50 --> Hooks Class Initialized
DEBUG - 2011-04-12 21:24:50 --> Utf8 Class Initialized
DEBUG - 2011-04-12 21:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 21:24:50 --> URI Class Initialized
DEBUG - 2011-04-12 21:24:50 --> Router Class Initialized
ERROR - 2011-04-12 21:24:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 22:26:28 --> Config Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 22:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 22:26:28 --> URI Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Router Class Initialized
DEBUG - 2011-04-12 22:26:28 --> No URI present. Default controller set.
DEBUG - 2011-04-12 22:26:28 --> Output Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Input Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 22:26:28 --> Language Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Loader Class Initialized
DEBUG - 2011-04-12 22:26:28 --> Controller Class Initialized
DEBUG - 2011-04-12 22:26:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-04-12 22:26:28 --> Helper loaded: url_helper
DEBUG - 2011-04-12 22:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 22:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 22:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 22:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 22:26:28 --> Final output sent to browser
DEBUG - 2011-04-12 22:26:28 --> Total execution time: 0.2750
DEBUG - 2011-04-12 23:32:42 --> Config Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:32:42 --> URI Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Router Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Output Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Input Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 23:32:42 --> Language Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Loader Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Controller Class Initialized
ERROR - 2011-04-12 23:32:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-04-12 23:32:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 23:32:42 --> Model Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Model Class Initialized
DEBUG - 2011-04-12 23:32:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 23:32:42 --> Database Driver Class Initialized
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-04-12 23:32:42 --> Helper loaded: url_helper
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 23:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 23:32:42 --> Final output sent to browser
DEBUG - 2011-04-12 23:32:42 --> Total execution time: 0.3058
DEBUG - 2011-04-12 23:32:45 --> Config Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:32:45 --> URI Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Router Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Output Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Input Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 23:32:45 --> Language Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Loader Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Controller Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Model Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Model Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 23:32:45 --> Database Driver Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Config Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:32:45 --> URI Class Initialized
DEBUG - 2011-04-12 23:32:45 --> Router Class Initialized
ERROR - 2011-04-12 23:32:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 23:32:45 --> Final output sent to browser
DEBUG - 2011-04-12 23:32:45 --> Total execution time: 0.6702
DEBUG - 2011-04-12 23:33:43 --> Config Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:33:43 --> URI Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Router Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Output Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Input Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 23:33:43 --> Language Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Loader Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Controller Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Model Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Model Class Initialized
DEBUG - 2011-04-12 23:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 23:33:43 --> Database Driver Class Initialized
DEBUG - 2011-04-12 23:33:44 --> Final output sent to browser
DEBUG - 2011-04-12 23:33:44 --> Total execution time: 0.4523
DEBUG - 2011-04-12 23:33:45 --> Config Class Initialized
DEBUG - 2011-04-12 23:33:45 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:33:45 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:33:45 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:33:45 --> URI Class Initialized
DEBUG - 2011-04-12 23:33:45 --> Router Class Initialized
ERROR - 2011-04-12 23:33:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 23:34:07 --> Config Class Initialized
DEBUG - 2011-04-12 23:34:07 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:34:07 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:34:07 --> URI Class Initialized
DEBUG - 2011-04-12 23:34:07 --> Router Class Initialized
ERROR - 2011-04-12 23:34:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-04-12 23:45:28 --> Config Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:45:28 --> URI Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Router Class Initialized
ERROR - 2011-04-12 23:45:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-04-12 23:45:28 --> Config Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Hooks Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Utf8 Class Initialized
DEBUG - 2011-04-12 23:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-04-12 23:45:28 --> URI Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Router Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Output Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Input Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-04-12 23:45:28 --> Language Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Loader Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Controller Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Model Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Model Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Model Class Initialized
DEBUG - 2011-04-12 23:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-04-12 23:45:28 --> Database Driver Class Initialized
DEBUG - 2011-04-12 23:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-04-12 23:45:28 --> Helper loaded: url_helper
DEBUG - 2011-04-12 23:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-04-12 23:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-04-12 23:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-04-12 23:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-04-12 23:45:28 --> Final output sent to browser
DEBUG - 2011-04-12 23:45:28 --> Total execution time: 0.3255

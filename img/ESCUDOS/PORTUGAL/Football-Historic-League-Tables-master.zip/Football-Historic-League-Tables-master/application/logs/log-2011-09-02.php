<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-02 00:16:35 --> Config Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:16:35 --> URI Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Router Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Output Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Input Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:16:35 --> Language Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Loader Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Controller Class Initialized
ERROR - 2011-09-02 00:16:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 00:16:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 00:16:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:16:35 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:16:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:16:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:16:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:16:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:16:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:16:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:16:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:16:36 --> Final output sent to browser
DEBUG - 2011-09-02 00:16:36 --> Total execution time: 0.3542
DEBUG - 2011-09-02 00:16:38 --> Config Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:16:38 --> URI Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Router Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Output Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Input Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:16:38 --> Language Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Loader Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Controller Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:16:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:16:38 --> Final output sent to browser
DEBUG - 2011-09-02 00:16:38 --> Total execution time: 0.5568
DEBUG - 2011-09-02 00:16:40 --> Config Class Initialized
DEBUG - 2011-09-02 00:16:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:16:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:16:40 --> URI Class Initialized
DEBUG - 2011-09-02 00:16:40 --> Router Class Initialized
ERROR - 2011-09-02 00:16:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 00:16:57 --> Config Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:16:57 --> URI Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Router Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Output Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Input Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:16:57 --> Language Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Loader Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Controller Class Initialized
ERROR - 2011-09-02 00:16:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 00:16:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:16:57 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:16:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:16:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:16:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:16:57 --> Final output sent to browser
DEBUG - 2011-09-02 00:16:57 --> Total execution time: 0.0300
DEBUG - 2011-09-02 00:16:57 --> Config Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:16:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:16:57 --> URI Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Router Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Output Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Input Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:16:57 --> Language Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Loader Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Controller Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Model Class Initialized
DEBUG - 2011-09-02 00:16:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:16:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:16:58 --> Final output sent to browser
DEBUG - 2011-09-02 00:16:58 --> Total execution time: 0.5142
DEBUG - 2011-09-02 00:17:07 --> Config Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:17:07 --> URI Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Router Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Output Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Input Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:17:07 --> Language Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Loader Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Controller Class Initialized
ERROR - 2011-09-02 00:17:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 00:17:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:17:07 --> Model Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Model Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:17:07 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 00:17:07 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:17:07 --> Final output sent to browser
DEBUG - 2011-09-02 00:17:07 --> Total execution time: 0.0280
DEBUG - 2011-09-02 00:17:07 --> Config Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:17:07 --> URI Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Router Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Output Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Input Class Initialized
DEBUG - 2011-09-02 00:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:17:07 --> Language Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Loader Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Controller Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Model Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Model Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:17:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:17:08 --> Final output sent to browser
DEBUG - 2011-09-02 00:17:08 --> Total execution time: 0.6264
DEBUG - 2011-09-02 00:22:27 --> Config Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:22:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:22:27 --> URI Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Router Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Output Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Input Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:22:27 --> Language Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Loader Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Controller Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:22:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:22:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:22:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:22:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:22:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:22:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:22:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:22:27 --> Final output sent to browser
DEBUG - 2011-09-02 00:22:27 --> Total execution time: 0.2740
DEBUG - 2011-09-02 00:22:49 --> Config Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:22:49 --> URI Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Router Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Output Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Input Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:22:49 --> Language Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Loader Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Controller Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Model Class Initialized
DEBUG - 2011-09-02 00:22:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:22:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:22:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:22:50 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:22:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:22:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:22:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:22:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:22:50 --> Final output sent to browser
DEBUG - 2011-09-02 00:22:50 --> Total execution time: 0.6481
DEBUG - 2011-09-02 00:23:16 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:16 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:16 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:16 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:16 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:16 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:16 --> Total execution time: 0.0800
DEBUG - 2011-09-02 00:23:18 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:18 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:18 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:19 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:19 --> Total execution time: 0.2065
DEBUG - 2011-09-02 00:23:20 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:20 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:20 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:20 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:20 --> Total execution time: 0.0461
DEBUG - 2011-09-02 00:23:32 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:32 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:32 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:32 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:32 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:32 --> Total execution time: 0.2379
DEBUG - 2011-09-02 00:23:33 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:33 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:33 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:33 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:33 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:33 --> Total execution time: 0.0427
DEBUG - 2011-09-02 00:23:38 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:38 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:38 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:39 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:39 --> Total execution time: 0.5287
DEBUG - 2011-09-02 00:23:40 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:40 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:40 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:40 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:40 --> Total execution time: 0.1203
DEBUG - 2011-09-02 00:23:44 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:44 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:44 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:45 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:45 --> Total execution time: 0.2708
DEBUG - 2011-09-02 00:23:46 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:46 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:46 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:46 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:46 --> Total execution time: 0.0652
DEBUG - 2011-09-02 00:23:51 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:51 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:51 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:51 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:51 --> Total execution time: 0.5379
DEBUG - 2011-09-02 00:23:52 --> Config Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 00:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 00:23:52 --> URI Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Router Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Output Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Input Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 00:23:52 --> Language Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Loader Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Controller Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Model Class Initialized
DEBUG - 2011-09-02 00:23:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 00:23:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 00:23:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 00:23:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 00:23:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 00:23:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 00:23:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 00:23:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 00:23:52 --> Final output sent to browser
DEBUG - 2011-09-02 00:23:52 --> Total execution time: 0.0715
DEBUG - 2011-09-02 01:44:36 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:36 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:36 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Controller Class Initialized
ERROR - 2011-09-02 01:44:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 01:44:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:36 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 01:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 01:44:36 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:36 --> Total execution time: 0.1936
DEBUG - 2011-09-02 01:44:37 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:37 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:37 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Controller Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:38 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:38 --> Total execution time: 1.3005
DEBUG - 2011-09-02 01:44:48 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:48 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:48 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Controller Class Initialized
ERROR - 2011-09-02 01:44:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 01:44:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:48 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 01:44:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 01:44:48 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:48 --> Total execution time: 0.0294
DEBUG - 2011-09-02 01:44:50 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:50 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:50 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Controller Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:50 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:50 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:50 --> Total execution time: 0.5999
DEBUG - 2011-09-02 01:44:52 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:52 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:52 --> Router Class Initialized
ERROR - 2011-09-02 01:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 01:44:57 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:57 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:57 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Controller Class Initialized
ERROR - 2011-09-02 01:44:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 01:44:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:57 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:44:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 01:44:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 01:44:57 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:57 --> Total execution time: 0.0542
DEBUG - 2011-09-02 01:44:58 --> Config Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:44:58 --> URI Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Router Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Output Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Input Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:44:58 --> Language Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Loader Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Controller Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Model Class Initialized
DEBUG - 2011-09-02 01:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:44:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:44:59 --> Final output sent to browser
DEBUG - 2011-09-02 01:44:59 --> Total execution time: 1.0053
DEBUG - 2011-09-02 01:45:00 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:00 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:00 --> Router Class Initialized
ERROR - 2011-09-02 01:45:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 01:45:09 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:09 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Router Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Output Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Input Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:45:09 --> Language Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Loader Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Controller Class Initialized
ERROR - 2011-09-02 01:45:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 01:45:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:45:09 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:45:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:45:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 01:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 01:45:09 --> Final output sent to browser
DEBUG - 2011-09-02 01:45:09 --> Total execution time: 0.0268
DEBUG - 2011-09-02 01:45:10 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:10 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Router Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Output Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Input Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:45:10 --> Language Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Loader Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Controller Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:45:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:45:11 --> Final output sent to browser
DEBUG - 2011-09-02 01:45:11 --> Total execution time: 0.9794
DEBUG - 2011-09-02 01:45:12 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:12 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:12 --> Router Class Initialized
ERROR - 2011-09-02 01:45:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 01:45:20 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:20 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:20 --> Router Class Initialized
DEBUG - 2011-09-02 01:45:20 --> Output Class Initialized
DEBUG - 2011-09-02 01:45:20 --> Input Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:45:21 --> Language Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Loader Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Controller Class Initialized
ERROR - 2011-09-02 01:45:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 01:45:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:45:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 01:45:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 01:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 01:45:21 --> Final output sent to browser
DEBUG - 2011-09-02 01:45:21 --> Total execution time: 0.0713
DEBUG - 2011-09-02 01:45:21 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:21 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Router Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Output Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Input Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 01:45:21 --> Language Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Loader Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Controller Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 01:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 01:45:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 01:45:22 --> Final output sent to browser
DEBUG - 2011-09-02 01:45:22 --> Total execution time: 0.9263
DEBUG - 2011-09-02 01:45:23 --> Config Class Initialized
DEBUG - 2011-09-02 01:45:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 01:45:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 01:45:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 01:45:23 --> URI Class Initialized
DEBUG - 2011-09-02 01:45:23 --> Router Class Initialized
ERROR - 2011-09-02 01:45:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 02:15:20 --> Config Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 02:15:20 --> URI Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Router Class Initialized
DEBUG - 2011-09-02 02:15:20 --> No URI present. Default controller set.
DEBUG - 2011-09-02 02:15:20 --> Output Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Input Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 02:15:20 --> Language Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Loader Class Initialized
DEBUG - 2011-09-02 02:15:20 --> Controller Class Initialized
DEBUG - 2011-09-02 02:15:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 02:15:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 02:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 02:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 02:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 02:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 02:15:20 --> Final output sent to browser
DEBUG - 2011-09-02 02:15:20 --> Total execution time: 0.1903
DEBUG - 2011-09-02 03:35:37 --> Config Class Initialized
DEBUG - 2011-09-02 03:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:35:37 --> URI Class Initialized
DEBUG - 2011-09-02 03:35:37 --> Router Class Initialized
ERROR - 2011-09-02 03:35:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 03:35:38 --> Config Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:35:38 --> URI Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Router Class Initialized
DEBUG - 2011-09-02 03:35:38 --> No URI present. Default controller set.
DEBUG - 2011-09-02 03:35:38 --> Output Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Input Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 03:35:38 --> Language Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Loader Class Initialized
DEBUG - 2011-09-02 03:35:38 --> Controller Class Initialized
DEBUG - 2011-09-02 03:35:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 03:35:38 --> Helper loaded: url_helper
DEBUG - 2011-09-02 03:35:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 03:35:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 03:35:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 03:35:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 03:35:38 --> Final output sent to browser
DEBUG - 2011-09-02 03:35:38 --> Total execution time: 0.2170
DEBUG - 2011-09-02 03:42:55 --> Config Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:42:55 --> URI Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Router Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Output Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Input Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 03:42:55 --> Language Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Loader Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Controller Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Model Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Model Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Model Class Initialized
DEBUG - 2011-09-02 03:42:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 03:42:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 03:42:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 03:42:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 03:42:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 03:42:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 03:42:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 03:42:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 03:42:56 --> Final output sent to browser
DEBUG - 2011-09-02 03:42:56 --> Total execution time: 1.0995
DEBUG - 2011-09-02 03:43:12 --> Config Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:43:12 --> URI Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Router Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Output Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Input Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 03:43:12 --> Language Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Loader Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Controller Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 03:43:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 03:43:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 03:43:12 --> Helper loaded: url_helper
DEBUG - 2011-09-02 03:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 03:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 03:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 03:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 03:43:12 --> Final output sent to browser
DEBUG - 2011-09-02 03:43:12 --> Total execution time: 0.1479
DEBUG - 2011-09-02 03:43:23 --> Config Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:43:23 --> URI Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Router Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Output Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Input Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 03:43:23 --> Language Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Loader Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Controller Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Model Class Initialized
DEBUG - 2011-09-02 03:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 03:43:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 03:43:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 03:43:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 03:43:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 03:43:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 03:43:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 03:43:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 03:43:23 --> Final output sent to browser
DEBUG - 2011-09-02 03:43:23 --> Total execution time: 0.1250
DEBUG - 2011-09-02 03:44:02 --> Config Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 03:44:02 --> URI Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Router Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Output Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Input Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 03:44:02 --> Language Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Loader Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Controller Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Model Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Model Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Model Class Initialized
DEBUG - 2011-09-02 03:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 03:44:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 03:44:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 03:44:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 03:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 03:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 03:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 03:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 03:44:02 --> Final output sent to browser
DEBUG - 2011-09-02 03:44:02 --> Total execution time: 0.0510
DEBUG - 2011-09-02 04:08:31 --> Config Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:08:31 --> URI Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Router Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Output Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Input Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:08:31 --> Language Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Loader Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Controller Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Model Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Model Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Model Class Initialized
DEBUG - 2011-09-02 04:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:08:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:08:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:08:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:08:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:08:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:08:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:08:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:08:34 --> Final output sent to browser
DEBUG - 2011-09-02 04:08:34 --> Total execution time: 3.4888
DEBUG - 2011-09-02 04:14:19 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:19 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Router Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Output Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Input Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:14:19 --> Language Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Loader Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Controller Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:14:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:14:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:14:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:14:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:14:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:14:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:14:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:14:19 --> Final output sent to browser
DEBUG - 2011-09-02 04:14:19 --> Total execution time: 0.1624
DEBUG - 2011-09-02 04:14:21 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:21 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:21 --> Router Class Initialized
ERROR - 2011-09-02 04:14:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:14:22 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:22 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Router Class Initialized
ERROR - 2011-09-02 04:14:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:14:22 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:22 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:22 --> Router Class Initialized
ERROR - 2011-09-02 04:14:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:14:57 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:57 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Router Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Output Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Input Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:14:57 --> Language Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Loader Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Controller Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:14:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Config Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:14:57 --> URI Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Router Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Output Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Input Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:14:57 --> Language Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Loader Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Controller Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:14:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:14:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:14:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:14:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:14:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:14:59 --> Final output sent to browser
DEBUG - 2011-09-02 04:14:59 --> Final output sent to browser
DEBUG - 2011-09-02 04:14:59 --> Total execution time: 1.4680
DEBUG - 2011-09-02 04:14:59 --> Total execution time: 1.9055
DEBUG - 2011-09-02 04:15:00 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:00 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:00 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:00 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:00 --> Total execution time: 0.1417
DEBUG - 2011-09-02 04:15:00 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:00 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:00 --> Router Class Initialized
ERROR - 2011-09-02 04:15:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:15:12 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:12 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:12 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:20 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:20 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:21 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:21 --> Total execution time: 1.2482
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:21 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:21 --> Total execution time: 9.0456
DEBUG - 2011-09-02 04:15:23 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:23 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Router Class Initialized
ERROR - 2011-09-02 04:15:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:15:23 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:23 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:23 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:23 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:23 --> Total execution time: 0.1508
DEBUG - 2011-09-02 04:15:36 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:36 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:36 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:37 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:37 --> Total execution time: 0.8315
DEBUG - 2011-09-02 04:15:38 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:38 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Router Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Output Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Input Class Initialized
DEBUG - 2011-09-02 04:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:15:38 --> Language Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Loader Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Controller Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Model Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:15:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Config Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:15:39 --> URI Class Initialized
DEBUG - 2011-09-02 04:15:39 --> Router Class Initialized
ERROR - 2011-09-02 04:15:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:15:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:15:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:15:39 --> Final output sent to browser
DEBUG - 2011-09-02 04:15:39 --> Total execution time: 0.2656
DEBUG - 2011-09-02 04:16:12 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:12 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Router Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Output Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Input Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:16:12 --> Language Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Loader Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Controller Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:16:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:16:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:16:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:16:13 --> Final output sent to browser
DEBUG - 2011-09-02 04:16:13 --> Total execution time: 1.0135
DEBUG - 2011-09-02 04:16:13 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:13 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Router Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Output Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Input Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:16:13 --> Language Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Loader Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Controller Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:16:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:16:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:16:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:16:14 --> Final output sent to browser
DEBUG - 2011-09-02 04:16:14 --> Total execution time: 0.1711
DEBUG - 2011-09-02 04:16:14 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:14 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:14 --> Router Class Initialized
ERROR - 2011-09-02 04:16:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:16:24 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:24 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Router Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Output Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Input Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:16:24 --> Language Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Loader Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Controller Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:16:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:16:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:16:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:16:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:16:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:16:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:16:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:16:26 --> Final output sent to browser
DEBUG - 2011-09-02 04:16:26 --> Total execution time: 2.0906
DEBUG - 2011-09-02 04:16:27 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:27 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:27 --> Router Class Initialized
ERROR - 2011-09-02 04:16:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:16:30 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:30 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Router Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Output Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Input Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:16:30 --> Language Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Loader Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Controller Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:16:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:16:30 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:16:30 --> Final output sent to browser
DEBUG - 2011-09-02 04:16:30 --> Total execution time: 0.0879
DEBUG - 2011-09-02 04:16:56 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:56 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Router Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Output Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Input Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:16:56 --> Language Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Loader Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Controller Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:16:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:16:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:16:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:16:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:16:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:16:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:16:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:16:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:16:56 --> Final output sent to browser
DEBUG - 2011-09-02 04:16:56 --> Total execution time: 0.8656
DEBUG - 2011-09-02 04:16:58 --> Config Class Initialized
DEBUG - 2011-09-02 04:16:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:16:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:16:58 --> URI Class Initialized
DEBUG - 2011-09-02 04:16:58 --> Router Class Initialized
ERROR - 2011-09-02 04:16:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:17:09 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:09 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:09 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:10 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:10 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:10 --> Total execution time: 0.8790
DEBUG - 2011-09-02 04:17:11 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:11 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:11 --> Router Class Initialized
ERROR - 2011-09-02 04:17:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:17:18 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:18 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:18 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:18 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:18 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:18 --> Total execution time: 0.5177
DEBUG - 2011-09-02 04:17:19 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:19 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:19 --> Router Class Initialized
ERROR - 2011-09-02 04:17:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:17:30 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:30 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:30 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:41 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:41 --> Total execution time: 10.8034
DEBUG - 2011-09-02 04:17:42 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:42 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:42 --> Router Class Initialized
ERROR - 2011-09-02 04:17:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:17:46 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:46 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:46 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:47 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:47 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:47 --> Total execution time: 0.1099
DEBUG - 2011-09-02 04:17:48 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:48 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:48 --> Router Class Initialized
ERROR - 2011-09-02 04:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:17:55 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:55 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:55 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:56 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:56 --> Total execution time: 1.2484
DEBUG - 2011-09-02 04:17:58 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:58 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Router Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Output Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Input Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:17:58 --> Language Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Loader Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Controller Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Model Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:17:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:17:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:17:58 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:17:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:17:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:17:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:17:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:17:58 --> Final output sent to browser
DEBUG - 2011-09-02 04:17:58 --> Total execution time: 0.1920
DEBUG - 2011-09-02 04:17:58 --> Config Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:17:58 --> URI Class Initialized
DEBUG - 2011-09-02 04:17:58 --> Router Class Initialized
ERROR - 2011-09-02 04:17:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:18:12 --> Config Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:18:12 --> URI Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Router Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Output Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Input Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:18:12 --> Language Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Loader Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Controller Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:18:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:18:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:18:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:18:14 --> Final output sent to browser
DEBUG - 2011-09-02 04:18:14 --> Total execution time: 1.1642
DEBUG - 2011-09-02 04:18:21 --> Config Class Initialized
DEBUG - 2011-09-02 04:18:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:18:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:18:21 --> URI Class Initialized
DEBUG - 2011-09-02 04:18:21 --> Router Class Initialized
ERROR - 2011-09-02 04:18:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:18:37 --> Config Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:18:37 --> URI Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Router Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Output Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Input Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:18:37 --> Language Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Loader Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Controller Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:18:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:18:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:18:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:18:41 --> Final output sent to browser
DEBUG - 2011-09-02 04:18:41 --> Total execution time: 3.7952
DEBUG - 2011-09-02 04:18:43 --> Config Class Initialized
DEBUG - 2011-09-02 04:18:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:18:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:18:43 --> URI Class Initialized
DEBUG - 2011-09-02 04:18:43 --> Router Class Initialized
ERROR - 2011-09-02 04:18:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:18:46 --> Config Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:18:46 --> URI Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Router Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Output Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Input Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:18:46 --> Language Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Loader Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Controller Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Model Class Initialized
DEBUG - 2011-09-02 04:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:18:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:18:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:18:46 --> Final output sent to browser
DEBUG - 2011-09-02 04:18:46 --> Total execution time: 0.0662
DEBUG - 2011-09-02 04:19:08 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:08 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Router Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Output Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Input Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:19:08 --> Language Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Loader Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Controller Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:19:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:19:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:19:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:19:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:19:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:19:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:19:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:19:09 --> Final output sent to browser
DEBUG - 2011-09-02 04:19:09 --> Total execution time: 1.7565
DEBUG - 2011-09-02 04:19:11 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:11 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:11 --> Router Class Initialized
ERROR - 2011-09-02 04:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:19:17 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:17 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Router Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Output Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Input Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:19:17 --> Language Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Loader Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Controller Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:19:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:19:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:19:18 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:19:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:19:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:19:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:19:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:19:18 --> Final output sent to browser
DEBUG - 2011-09-02 04:19:18 --> Total execution time: 0.1086
DEBUG - 2011-09-02 04:19:23 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:23 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Router Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Output Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Input Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:19:23 --> Language Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Loader Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Controller Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:19:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:19:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:19:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:19:26 --> Final output sent to browser
DEBUG - 2011-09-02 04:19:26 --> Total execution time: 2.9267
DEBUG - 2011-09-02 04:19:27 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:27 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:27 --> Router Class Initialized
ERROR - 2011-09-02 04:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:19:36 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:36 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Router Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Output Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Input Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:19:36 --> Language Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Loader Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Controller Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:19:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:19:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:19:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:19:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:19:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:19:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:19:39 --> Final output sent to browser
DEBUG - 2011-09-02 04:19:39 --> Total execution time: 2.6511
DEBUG - 2011-09-02 04:19:40 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:40 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:40 --> Router Class Initialized
ERROR - 2011-09-02 04:19:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:19:52 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:52 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Router Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Output Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Input Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:19:52 --> Language Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Loader Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Controller Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Model Class Initialized
DEBUG - 2011-09-02 04:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:19:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:19:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:19:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:19:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:19:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:19:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:19:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:19:57 --> Final output sent to browser
DEBUG - 2011-09-02 04:19:57 --> Total execution time: 4.8698
DEBUG - 2011-09-02 04:19:58 --> Config Class Initialized
DEBUG - 2011-09-02 04:19:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:19:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:19:58 --> URI Class Initialized
DEBUG - 2011-09-02 04:19:58 --> Router Class Initialized
ERROR - 2011-09-02 04:19:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:20:11 --> Config Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:20:11 --> URI Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Router Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Output Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Input Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:20:11 --> Language Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Loader Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Controller Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:20:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:20:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:20:12 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:20:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:20:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:20:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:20:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:20:12 --> Final output sent to browser
DEBUG - 2011-09-02 04:20:12 --> Total execution time: 0.6603
DEBUG - 2011-09-02 04:20:13 --> Config Class Initialized
DEBUG - 2011-09-02 04:20:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:20:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:20:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:20:13 --> URI Class Initialized
DEBUG - 2011-09-02 04:20:13 --> Router Class Initialized
ERROR - 2011-09-02 04:20:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:20:29 --> Config Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:20:29 --> URI Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Router Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Output Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Input Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:20:29 --> Language Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Loader Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Controller Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Model Class Initialized
DEBUG - 2011-09-02 04:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:20:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:20:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:20:29 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:20:29 --> Final output sent to browser
DEBUG - 2011-09-02 04:20:29 --> Total execution time: 0.1437
DEBUG - 2011-09-02 04:20:31 --> Config Class Initialized
DEBUG - 2011-09-02 04:20:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:20:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:20:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:20:31 --> URI Class Initialized
DEBUG - 2011-09-02 04:20:31 --> Router Class Initialized
ERROR - 2011-09-02 04:20:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:22:56 --> Config Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:22:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:22:56 --> URI Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Router Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Output Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Input Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:22:56 --> Language Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Loader Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Controller Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:22:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:22:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:22:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:22:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:22:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:22:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:22:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:22:56 --> Final output sent to browser
DEBUG - 2011-09-02 04:22:56 --> Total execution time: 0.0637
DEBUG - 2011-09-02 04:22:57 --> Config Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:22:57 --> URI Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Router Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Output Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Input Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:22:57 --> Language Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Loader Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Controller Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:22:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:22:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:22:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:22:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:22:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:22:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:22:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:22:57 --> Final output sent to browser
DEBUG - 2011-09-02 04:22:57 --> Total execution time: 0.0534
DEBUG - 2011-09-02 04:22:59 --> Config Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:22:59 --> URI Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Router Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Output Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Input Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:22:59 --> Language Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Loader Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Controller Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Model Class Initialized
DEBUG - 2011-09-02 04:22:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:22:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:22:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:22:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:22:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:22:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:22:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:22:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:22:59 --> Final output sent to browser
DEBUG - 2011-09-02 04:22:59 --> Total execution time: 0.0472
DEBUG - 2011-09-02 04:23:19 --> Config Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:23:19 --> URI Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Router Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Output Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Input Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:23:19 --> Language Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Loader Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Controller Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:23:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:23:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 04:23:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:23:20 --> Final output sent to browser
DEBUG - 2011-09-02 04:23:20 --> Total execution time: 0.1870
DEBUG - 2011-09-02 04:39:17 --> Config Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:39:17 --> URI Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Router Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Output Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Input Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:39:17 --> Language Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Loader Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Controller Class Initialized
ERROR - 2011-09-02 04:39:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 04:39:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 04:39:17 --> Model Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Model Class Initialized
DEBUG - 2011-09-02 04:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:39:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 04:39:17 --> Helper loaded: url_helper
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 04:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 04:39:17 --> Final output sent to browser
DEBUG - 2011-09-02 04:39:17 --> Total execution time: 0.4262
DEBUG - 2011-09-02 04:39:18 --> Config Class Initialized
DEBUG - 2011-09-02 04:39:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:39:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:39:19 --> URI Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Router Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Output Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Input Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 04:39:19 --> Language Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Loader Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Controller Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Model Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 04:39:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 04:39:19 --> Final output sent to browser
DEBUG - 2011-09-02 04:39:19 --> Total execution time: 1.0125
DEBUG - 2011-09-02 04:39:21 --> Config Class Initialized
DEBUG - 2011-09-02 04:39:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:39:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:39:21 --> URI Class Initialized
DEBUG - 2011-09-02 04:39:21 --> Router Class Initialized
ERROR - 2011-09-02 04:39:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 04:39:22 --> Config Class Initialized
DEBUG - 2011-09-02 04:39:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 04:39:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 04:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 04:39:22 --> URI Class Initialized
DEBUG - 2011-09-02 04:39:22 --> Router Class Initialized
ERROR - 2011-09-02 04:39:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 05:04:16 --> Config Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:04:16 --> URI Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Router Class Initialized
DEBUG - 2011-09-02 05:04:16 --> No URI present. Default controller set.
DEBUG - 2011-09-02 05:04:16 --> Output Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Input Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:04:16 --> Language Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Loader Class Initialized
DEBUG - 2011-09-02 05:04:16 --> Controller Class Initialized
DEBUG - 2011-09-02 05:04:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 05:04:16 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:04:16 --> Final output sent to browser
DEBUG - 2011-09-02 05:04:16 --> Total execution time: 0.2076
DEBUG - 2011-09-02 05:14:45 --> Config Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:14:45 --> URI Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Router Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Output Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Input Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:14:45 --> Language Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Loader Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Controller Class Initialized
ERROR - 2011-09-02 05:14:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 05:14:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 05:14:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:14:45 --> Model Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Model Class Initialized
DEBUG - 2011-09-02 05:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:14:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:14:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:14:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:14:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:14:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:14:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:14:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:14:46 --> Final output sent to browser
DEBUG - 2011-09-02 05:14:46 --> Total execution time: 1.1330
DEBUG - 2011-09-02 05:14:48 --> Config Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:14:48 --> URI Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Router Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Output Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Input Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:14:48 --> Language Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Loader Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Controller Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Model Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Model Class Initialized
DEBUG - 2011-09-02 05:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:14:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:14:49 --> Final output sent to browser
DEBUG - 2011-09-02 05:14:49 --> Total execution time: 1.2725
DEBUG - 2011-09-02 05:14:50 --> Config Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:14:50 --> URI Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Router Class Initialized
ERROR - 2011-09-02 05:14:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 05:14:50 --> Config Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:14:50 --> URI Class Initialized
DEBUG - 2011-09-02 05:14:50 --> Router Class Initialized
ERROR - 2011-09-02 05:14:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 05:14:51 --> Config Class Initialized
DEBUG - 2011-09-02 05:14:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:14:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:14:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:14:51 --> URI Class Initialized
DEBUG - 2011-09-02 05:14:51 --> Router Class Initialized
ERROR - 2011-09-02 05:14:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 05:15:05 --> Config Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:15:05 --> URI Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Router Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Output Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Input Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:15:05 --> Language Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Loader Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Controller Class Initialized
ERROR - 2011-09-02 05:15:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 05:15:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:05 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:15:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:15:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:15:05 --> Final output sent to browser
DEBUG - 2011-09-02 05:15:05 --> Total execution time: 0.1487
DEBUG - 2011-09-02 05:15:06 --> Config Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:15:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:15:06 --> URI Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Router Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Output Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Input Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:15:06 --> Language Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Loader Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Controller Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:15:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:15:08 --> Final output sent to browser
DEBUG - 2011-09-02 05:15:08 --> Total execution time: 1.9875
DEBUG - 2011-09-02 05:15:23 --> Config Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:15:23 --> URI Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Router Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Output Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Input Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:15:23 --> Language Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Loader Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Controller Class Initialized
ERROR - 2011-09-02 05:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 05:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:23 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:15:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:15:23 --> Final output sent to browser
DEBUG - 2011-09-02 05:15:23 --> Total execution time: 0.1553
DEBUG - 2011-09-02 05:15:24 --> Config Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:15:24 --> URI Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Router Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Output Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Input Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:15:24 --> Language Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Loader Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Controller Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:15:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:15:24 --> Final output sent to browser
DEBUG - 2011-09-02 05:15:24 --> Total execution time: 0.5304
DEBUG - 2011-09-02 05:15:25 --> Config Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:15:25 --> URI Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Router Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Output Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Input Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:15:25 --> Language Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Loader Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Controller Class Initialized
ERROR - 2011-09-02 05:15:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 05:15:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:25 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Model Class Initialized
DEBUG - 2011-09-02 05:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:15:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:15:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:15:25 --> Final output sent to browser
DEBUG - 2011-09-02 05:15:25 --> Total execution time: 0.0361
DEBUG - 2011-09-02 05:27:58 --> Config Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 05:27:58 --> URI Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Router Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Output Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Input Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 05:27:58 --> Language Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Loader Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Controller Class Initialized
ERROR - 2011-09-02 05:27:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 05:27:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:27:58 --> Model Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Model Class Initialized
DEBUG - 2011-09-02 05:27:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 05:27:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 05:27:58 --> Helper loaded: url_helper
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 05:27:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 05:27:58 --> Final output sent to browser
DEBUG - 2011-09-02 05:27:58 --> Total execution time: 0.2711
DEBUG - 2011-09-02 06:16:09 --> Config Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 06:16:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 06:16:09 --> URI Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Router Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Output Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Input Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 06:16:09 --> Language Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Loader Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Controller Class Initialized
ERROR - 2011-09-02 06:16:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 06:16:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 06:16:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 06:16:09 --> Model Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Model Class Initialized
DEBUG - 2011-09-02 06:16:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 06:16:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 06:16:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 06:16:10 --> Helper loaded: url_helper
DEBUG - 2011-09-02 06:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 06:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 06:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 06:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 06:16:10 --> Final output sent to browser
DEBUG - 2011-09-02 06:16:10 --> Total execution time: 0.2927
DEBUG - 2011-09-02 06:16:11 --> Config Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 06:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 06:16:11 --> URI Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Router Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Output Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Input Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 06:16:11 --> Language Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Loader Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Controller Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Model Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Model Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 06:16:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 06:16:11 --> Final output sent to browser
DEBUG - 2011-09-02 06:16:11 --> Total execution time: 0.6053
DEBUG - 2011-09-02 06:16:12 --> Config Class Initialized
DEBUG - 2011-09-02 06:16:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 06:16:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 06:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 06:16:12 --> URI Class Initialized
DEBUG - 2011-09-02 06:16:12 --> Router Class Initialized
ERROR - 2011-09-02 06:16:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 06:38:24 --> Config Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 06:38:24 --> URI Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Router Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Output Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Input Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 06:38:24 --> Language Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Loader Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Controller Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Model Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Model Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Model Class Initialized
DEBUG - 2011-09-02 06:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 06:38:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 06:38:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 06:38:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 06:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 06:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 06:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 06:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 06:38:25 --> Final output sent to browser
DEBUG - 2011-09-02 06:38:25 --> Total execution time: 0.6415
DEBUG - 2011-09-02 07:30:21 --> Config Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:30:21 --> URI Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Router Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Output Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Input Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:30:21 --> Language Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Loader Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Controller Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Model Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Model Class Initialized
DEBUG - 2011-09-02 07:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:30:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:30:22 --> Final output sent to browser
DEBUG - 2011-09-02 07:30:22 --> Total execution time: 0.8123
DEBUG - 2011-09-02 07:34:39 --> Config Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:34:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:34:39 --> URI Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Router Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Output Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Input Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:34:39 --> Language Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Loader Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Controller Class Initialized
ERROR - 2011-09-02 07:34:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:34:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:34:39 --> Model Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Model Class Initialized
DEBUG - 2011-09-02 07:34:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:34:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:34:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:34:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:34:39 --> Final output sent to browser
DEBUG - 2011-09-02 07:34:39 --> Total execution time: 0.1124
DEBUG - 2011-09-02 07:34:41 --> Config Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:34:41 --> URI Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Router Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Output Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Input Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:34:41 --> Language Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Loader Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Controller Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Model Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Model Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:34:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:34:41 --> Final output sent to browser
DEBUG - 2011-09-02 07:34:41 --> Total execution time: 0.5095
DEBUG - 2011-09-02 07:34:43 --> Config Class Initialized
DEBUG - 2011-09-02 07:34:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:34:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:34:43 --> URI Class Initialized
DEBUG - 2011-09-02 07:34:43 --> Router Class Initialized
ERROR - 2011-09-02 07:34:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:36:00 --> Config Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:36:00 --> URI Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Router Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Output Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Input Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:36:00 --> Language Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Loader Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Controller Class Initialized
ERROR - 2011-09-02 07:36:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:36:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:36:00 --> Model Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Model Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:36:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:36:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:36:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:36:00 --> Final output sent to browser
DEBUG - 2011-09-02 07:36:00 --> Total execution time: 0.0482
DEBUG - 2011-09-02 07:36:00 --> Config Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:36:00 --> URI Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Router Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Output Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Input Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:36:00 --> Language Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Loader Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Controller Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Model Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Model Class Initialized
DEBUG - 2011-09-02 07:36:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:36:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:36:01 --> Final output sent to browser
DEBUG - 2011-09-02 07:36:01 --> Total execution time: 0.4403
DEBUG - 2011-09-02 07:36:02 --> Config Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:36:02 --> URI Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Router Class Initialized
ERROR - 2011-09-02 07:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:36:02 --> Config Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:36:02 --> URI Class Initialized
DEBUG - 2011-09-02 07:36:02 --> Router Class Initialized
ERROR - 2011-09-02 07:36:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:37:31 --> Config Class Initialized
DEBUG - 2011-09-02 07:37:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:37:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:37:31 --> URI Class Initialized
DEBUG - 2011-09-02 07:37:31 --> Router Class Initialized
ERROR - 2011-09-02 07:37:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:42:31 --> Config Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:42:31 --> URI Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Router Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Output Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Input Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:42:31 --> Language Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Loader Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Controller Class Initialized
ERROR - 2011-09-02 07:42:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:42:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:42:31 --> Model Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Model Class Initialized
DEBUG - 2011-09-02 07:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:42:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:42:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:42:31 --> Final output sent to browser
DEBUG - 2011-09-02 07:42:31 --> Total execution time: 0.0303
DEBUG - 2011-09-02 07:42:32 --> Config Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:42:32 --> URI Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Router Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Output Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Input Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:42:32 --> Language Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Loader Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Controller Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Model Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Model Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:42:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:42:32 --> Final output sent to browser
DEBUG - 2011-09-02 07:42:32 --> Total execution time: 0.4756
DEBUG - 2011-09-02 07:42:34 --> Config Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:42:34 --> URI Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Router Class Initialized
ERROR - 2011-09-02 07:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:42:34 --> Config Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:42:34 --> URI Class Initialized
DEBUG - 2011-09-02 07:42:34 --> Router Class Initialized
ERROR - 2011-09-02 07:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:43:22 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:22 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Router Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Output Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Input Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:43:22 --> Language Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Loader Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Controller Class Initialized
ERROR - 2011-09-02 07:43:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:43:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:43:22 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:43:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:43:22 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:43:22 --> Final output sent to browser
DEBUG - 2011-09-02 07:43:22 --> Total execution time: 0.0312
DEBUG - 2011-09-02 07:43:23 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:23 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Router Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Output Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Input Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:43:23 --> Language Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Loader Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Controller Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:43:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:43:24 --> Final output sent to browser
DEBUG - 2011-09-02 07:43:24 --> Total execution time: 0.4835
DEBUG - 2011-09-02 07:43:24 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:24 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:24 --> Router Class Initialized
ERROR - 2011-09-02 07:43:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:43:34 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:34 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:34 --> Router Class Initialized
ERROR - 2011-09-02 07:43:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:43:37 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:37 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Router Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Output Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Input Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:43:37 --> Language Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Loader Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Controller Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:43:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 07:43:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:43:37 --> Final output sent to browser
DEBUG - 2011-09-02 07:43:37 --> Total execution time: 0.3592
DEBUG - 2011-09-02 07:43:38 --> Config Class Initialized
DEBUG - 2011-09-02 07:43:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:43:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:43:38 --> URI Class Initialized
DEBUG - 2011-09-02 07:43:38 --> Router Class Initialized
ERROR - 2011-09-02 07:43:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:45:01 --> Config Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:45:01 --> URI Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Router Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Output Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Input Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:45:01 --> Language Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Loader Class Initialized
DEBUG - 2011-09-02 07:45:01 --> Controller Class Initialized
ERROR - 2011-09-02 07:45:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:45:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:45:02 --> Model Class Initialized
DEBUG - 2011-09-02 07:45:02 --> Model Class Initialized
DEBUG - 2011-09-02 07:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:45:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:45:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:45:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:45:02 --> Final output sent to browser
DEBUG - 2011-09-02 07:45:02 --> Total execution time: 0.2277
DEBUG - 2011-09-02 07:45:04 --> Config Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:45:04 --> URI Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Router Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Output Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Input Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:45:04 --> Language Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Loader Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Controller Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Model Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Model Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:45:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:45:04 --> Final output sent to browser
DEBUG - 2011-09-02 07:45:04 --> Total execution time: 0.5607
DEBUG - 2011-09-02 07:54:14 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:14 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Router Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Output Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Input Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:54:14 --> Language Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Loader Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Controller Class Initialized
ERROR - 2011-09-02 07:54:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:54:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:54:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:54:14 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:54:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:54:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:54:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:54:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:54:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:54:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:54:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:54:15 --> Final output sent to browser
DEBUG - 2011-09-02 07:54:15 --> Total execution time: 0.0321
DEBUG - 2011-09-02 07:54:16 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:16 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Router Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Output Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Input Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:54:16 --> Language Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Loader Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Controller Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:54:16 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:54:17 --> Final output sent to browser
DEBUG - 2011-09-02 07:54:17 --> Total execution time: 0.9891
DEBUG - 2011-09-02 07:54:19 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:19 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:19 --> Router Class Initialized
ERROR - 2011-09-02 07:54:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:54:40 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:40 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Router Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Output Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Input Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:54:40 --> Language Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Loader Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Controller Class Initialized
ERROR - 2011-09-02 07:54:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 07:54:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:54:40 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:54:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 07:54:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:54:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:54:40 --> Final output sent to browser
DEBUG - 2011-09-02 07:54:40 --> Total execution time: 0.0592
DEBUG - 2011-09-02 07:54:41 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:41 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Router Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Output Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Input Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:54:41 --> Language Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Loader Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Controller Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Model Class Initialized
DEBUG - 2011-09-02 07:54:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:54:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:54:42 --> Final output sent to browser
DEBUG - 2011-09-02 07:54:42 --> Total execution time: 0.4946
DEBUG - 2011-09-02 07:54:43 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:43 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:43 --> Router Class Initialized
ERROR - 2011-09-02 07:54:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:54:44 --> Config Class Initialized
DEBUG - 2011-09-02 07:54:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:54:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:54:44 --> URI Class Initialized
DEBUG - 2011-09-02 07:54:44 --> Router Class Initialized
ERROR - 2011-09-02 07:54:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:55:15 --> Config Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:55:15 --> URI Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Router Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Output Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Input Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:55:15 --> Language Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Loader Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Controller Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:55:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:55:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 07:55:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:55:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:55:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:55:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:55:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:55:15 --> Final output sent to browser
DEBUG - 2011-09-02 07:55:15 --> Total execution time: 0.0706
DEBUG - 2011-09-02 07:55:17 --> Config Class Initialized
DEBUG - 2011-09-02 07:55:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:55:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:55:17 --> URI Class Initialized
DEBUG - 2011-09-02 07:55:17 --> Router Class Initialized
ERROR - 2011-09-02 07:55:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:55:35 --> Config Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:55:35 --> URI Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Router Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Output Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Input Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:55:35 --> Language Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Loader Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Controller Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:55:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:55:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 07:55:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:55:35 --> Final output sent to browser
DEBUG - 2011-09-02 07:55:35 --> Total execution time: 0.7039
DEBUG - 2011-09-02 07:55:37 --> Config Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:55:37 --> URI Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Router Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Output Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Input Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 07:55:37 --> Language Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Loader Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Controller Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Model Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 07:55:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Config Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 07:55:37 --> URI Class Initialized
DEBUG - 2011-09-02 07:55:37 --> Router Class Initialized
ERROR - 2011-09-02 07:55:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 07:55:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 07:55:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 07:55:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 07:55:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 07:55:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 07:55:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 07:55:37 --> Final output sent to browser
DEBUG - 2011-09-02 07:55:37 --> Total execution time: 0.0656
DEBUG - 2011-09-02 08:05:17 --> Config Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 08:05:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 08:05:17 --> URI Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Router Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Output Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Input Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 08:05:17 --> Language Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Loader Class Initialized
DEBUG - 2011-09-02 08:05:17 --> Controller Class Initialized
DEBUG - 2011-09-02 08:05:18 --> Model Class Initialized
DEBUG - 2011-09-02 08:05:18 --> Model Class Initialized
DEBUG - 2011-09-02 08:05:18 --> Model Class Initialized
DEBUG - 2011-09-02 08:05:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 08:05:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 08:05:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 08:05:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 08:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 08:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 08:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 08:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 08:05:20 --> Final output sent to browser
DEBUG - 2011-09-02 08:05:20 --> Total execution time: 3.0864
DEBUG - 2011-09-02 09:00:59 --> Config Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:00:59 --> URI Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Router Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Output Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Input Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:00:59 --> Language Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Loader Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Controller Class Initialized
ERROR - 2011-09-02 09:00:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:00:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:00:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:00:59 --> Model Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Model Class Initialized
DEBUG - 2011-09-02 09:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:00:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:01:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:01:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:01:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:01:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:01:00 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:00 --> Total execution time: 0.3228
DEBUG - 2011-09-02 09:01:00 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:00 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:00 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Controller Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:01 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:01 --> Total execution time: 0.6556
DEBUG - 2011-09-02 09:01:02 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:02 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Router Class Initialized
ERROR - 2011-09-02 09:01:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:01:02 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:02 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:02 --> Router Class Initialized
ERROR - 2011-09-02 09:01:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:01:37 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:37 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:37 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Controller Class Initialized
ERROR - 2011-09-02 09:01:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:01:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:37 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:01:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:01:37 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:37 --> Total execution time: 0.0284
DEBUG - 2011-09-02 09:01:38 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:38 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:38 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Controller Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:38 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:38 --> Total execution time: 0.5213
DEBUG - 2011-09-02 09:01:39 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:39 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:39 --> Router Class Initialized
ERROR - 2011-09-02 09:01:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:01:48 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:48 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:49 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Controller Class Initialized
ERROR - 2011-09-02 09:01:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:01:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:49 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:01:49 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:49 --> Total execution time: 0.0326
DEBUG - 2011-09-02 09:01:49 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:49 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:49 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Controller Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:50 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:50 --> Total execution time: 0.6011
DEBUG - 2011-09-02 09:01:50 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:50 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:50 --> Router Class Initialized
ERROR - 2011-09-02 09:01:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:01:58 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:58 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:58 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Controller Class Initialized
ERROR - 2011-09-02 09:01:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:01:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:58 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:01:58 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:01:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:01:58 --> Final output sent to browser
DEBUG - 2011-09-02 09:01:58 --> Total execution time: 0.0304
DEBUG - 2011-09-02 09:01:59 --> Config Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:01:59 --> URI Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Router Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Output Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Input Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:01:59 --> Language Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Loader Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Controller Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Model Class Initialized
DEBUG - 2011-09-02 09:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:01:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:00 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:00 --> Total execution time: 0.5947
DEBUG - 2011-09-02 09:02:00 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:00 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:00 --> Router Class Initialized
ERROR - 2011-09-02 09:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:02:07 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:07 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:07 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Controller Class Initialized
ERROR - 2011-09-02 09:02:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:02:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:07 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:07 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:07 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:02:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:02:07 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:07 --> Total execution time: 0.0418
DEBUG - 2011-09-02 09:02:08 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:08 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:08 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Controller Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:08 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:08 --> Total execution time: 0.7470
DEBUG - 2011-09-02 09:02:09 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:09 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:09 --> Router Class Initialized
ERROR - 2011-09-02 09:02:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:02:14 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:14 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:14 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Controller Class Initialized
ERROR - 2011-09-02 09:02:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:02:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:02:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:02:14 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:14 --> Total execution time: 0.0419
DEBUG - 2011-09-02 09:02:14 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:14 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:14 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Controller Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:15 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:15 --> Total execution time: 0.5624
DEBUG - 2011-09-02 09:02:15 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:15 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:15 --> Router Class Initialized
ERROR - 2011-09-02 09:02:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:02:22 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:22 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:22 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Controller Class Initialized
ERROR - 2011-09-02 09:02:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:02:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:22 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:02:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:02:22 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:22 --> Total execution time: 0.0271
DEBUG - 2011-09-02 09:02:22 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:22 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:22 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Controller Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:23 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:23 --> Total execution time: 0.6093
DEBUG - 2011-09-02 09:02:23 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:23 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:23 --> Router Class Initialized
ERROR - 2011-09-02 09:02:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:02:35 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:35 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:35 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Controller Class Initialized
ERROR - 2011-09-02 09:02:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:02:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:35 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:02:35 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:35 --> Total execution time: 0.0338
DEBUG - 2011-09-02 09:02:35 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:35 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:35 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Controller Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:36 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:36 --> Total execution time: 0.6679
DEBUG - 2011-09-02 09:02:37 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:37 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:37 --> Router Class Initialized
ERROR - 2011-09-02 09:02:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:02:45 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:45 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:45 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Controller Class Initialized
ERROR - 2011-09-02 09:02:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:02:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:45 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:02:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:02:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:02:45 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:45 --> Total execution time: 0.0287
DEBUG - 2011-09-02 09:02:45 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:45 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Router Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Output Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Input Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:02:45 --> Language Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Loader Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Controller Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Model Class Initialized
DEBUG - 2011-09-02 09:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:02:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:02:46 --> Final output sent to browser
DEBUG - 2011-09-02 09:02:46 --> Total execution time: 0.5621
DEBUG - 2011-09-02 09:02:46 --> Config Class Initialized
DEBUG - 2011-09-02 09:02:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:02:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:02:46 --> URI Class Initialized
DEBUG - 2011-09-02 09:02:46 --> Router Class Initialized
ERROR - 2011-09-02 09:02:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:08 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:08 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:08 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:08 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:08 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:08 --> Total execution time: 0.0303
DEBUG - 2011-09-02 09:03:08 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:08 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:08 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:09 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:09 --> Total execution time: 0.4994
DEBUG - 2011-09-02 09:03:09 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:09 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:09 --> Router Class Initialized
ERROR - 2011-09-02 09:03:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:14 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:14 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:14 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:14 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:14 --> Total execution time: 0.2312
DEBUG - 2011-09-02 09:03:15 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:15 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:15 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:15 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:15 --> Total execution time: 0.5129
DEBUG - 2011-09-02 09:03:16 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:16 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:16 --> Router Class Initialized
ERROR - 2011-09-02 09:03:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:27 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:27 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:27 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:27 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:27 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:27 --> Total execution time: 0.0735
DEBUG - 2011-09-02 09:03:28 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:28 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:28 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:29 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:29 --> Total execution time: 0.7995
DEBUG - 2011-09-02 09:03:29 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:29 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:29 --> Router Class Initialized
ERROR - 2011-09-02 09:03:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:36 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:36 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:36 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:36 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:36 --> Total execution time: 0.0275
DEBUG - 2011-09-02 09:03:37 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:37 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:37 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:37 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:37 --> Total execution time: 0.5829
DEBUG - 2011-09-02 09:03:38 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:38 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:38 --> Router Class Initialized
ERROR - 2011-09-02 09:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:46 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:46 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:46 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:46 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:46 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:46 --> Total execution time: 0.1004
DEBUG - 2011-09-02 09:03:47 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:47 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:47 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:47 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:47 --> Total execution time: 0.6435
DEBUG - 2011-09-02 09:03:48 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:48 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:48 --> Router Class Initialized
ERROR - 2011-09-02 09:03:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:03:56 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:56 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:56 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Controller Class Initialized
ERROR - 2011-09-02 09:03:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:03:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:03:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:03:56 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:56 --> Total execution time: 0.0433
DEBUG - 2011-09-02 09:03:57 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:57 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Router Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Output Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Input Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:03:57 --> Language Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Loader Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Controller Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Model Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:03:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:03:57 --> Final output sent to browser
DEBUG - 2011-09-02 09:03:57 --> Total execution time: 0.6006
DEBUG - 2011-09-02 09:03:58 --> Config Class Initialized
DEBUG - 2011-09-02 09:03:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:03:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:03:58 --> URI Class Initialized
DEBUG - 2011-09-02 09:03:58 --> Router Class Initialized
ERROR - 2011-09-02 09:03:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:04:02 --> Config Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:04:02 --> URI Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Router Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Output Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Input Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:04:02 --> Language Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Loader Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Controller Class Initialized
ERROR - 2011-09-02 09:04:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:04:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:04:02 --> Model Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Model Class Initialized
DEBUG - 2011-09-02 09:04:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:04:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:04:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:04:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:04:02 --> Final output sent to browser
DEBUG - 2011-09-02 09:04:02 --> Total execution time: 0.0282
DEBUG - 2011-09-02 09:04:03 --> Config Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:04:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:04:03 --> URI Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Router Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Output Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Input Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:04:03 --> Language Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Loader Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Controller Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Model Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Model Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:04:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:04:03 --> Final output sent to browser
DEBUG - 2011-09-02 09:04:03 --> Total execution time: 0.5766
DEBUG - 2011-09-02 09:04:04 --> Config Class Initialized
DEBUG - 2011-09-02 09:04:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:04:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:04:04 --> URI Class Initialized
DEBUG - 2011-09-02 09:04:04 --> Router Class Initialized
ERROR - 2011-09-02 09:04:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:06:12 --> Config Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:06:12 --> URI Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Router Class Initialized
DEBUG - 2011-09-02 09:06:12 --> No URI present. Default controller set.
DEBUG - 2011-09-02 09:06:12 --> Output Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Input Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:06:12 --> Language Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Loader Class Initialized
DEBUG - 2011-09-02 09:06:12 --> Controller Class Initialized
DEBUG - 2011-09-02 09:06:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 09:06:12 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:06:12 --> Final output sent to browser
DEBUG - 2011-09-02 09:06:12 --> Total execution time: 0.0519
DEBUG - 2011-09-02 09:42:09 --> Config Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:42:09 --> URI Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Router Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Output Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Input Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:42:09 --> Language Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Loader Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Controller Class Initialized
ERROR - 2011-09-02 09:42:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:42:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:42:09 --> Model Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Model Class Initialized
DEBUG - 2011-09-02 09:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:42:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:42:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:42:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:42:09 --> Final output sent to browser
DEBUG - 2011-09-02 09:42:09 --> Total execution time: 0.2836
DEBUG - 2011-09-02 09:42:10 --> Config Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:42:10 --> URI Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Router Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Output Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Input Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:42:10 --> Language Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Loader Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Controller Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Model Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Model Class Initialized
DEBUG - 2011-09-02 09:42:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:42:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:42:11 --> Final output sent to browser
DEBUG - 2011-09-02 09:42:11 --> Total execution time: 0.5182
DEBUG - 2011-09-02 09:42:30 --> Config Class Initialized
DEBUG - 2011-09-02 09:42:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:42:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:42:30 --> URI Class Initialized
DEBUG - 2011-09-02 09:42:30 --> Router Class Initialized
ERROR - 2011-09-02 09:42:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:42:34 --> Config Class Initialized
DEBUG - 2011-09-02 09:42:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:42:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:42:34 --> URI Class Initialized
DEBUG - 2011-09-02 09:42:34 --> Router Class Initialized
ERROR - 2011-09-02 09:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 09:59:06 --> Config Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 09:59:06 --> URI Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Router Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Output Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Input Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 09:59:06 --> Language Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Loader Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Controller Class Initialized
ERROR - 2011-09-02 09:59:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 09:59:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:59:06 --> Model Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Model Class Initialized
DEBUG - 2011-09-02 09:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 09:59:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 09:59:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 09:59:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 09:59:06 --> Final output sent to browser
DEBUG - 2011-09-02 09:59:06 --> Total execution time: 0.1193
DEBUG - 2011-09-02 10:36:05 --> Config Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:36:05 --> URI Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Router Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Output Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Input Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 10:36:05 --> Language Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Loader Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Controller Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Model Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Model Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Model Class Initialized
DEBUG - 2011-09-02 10:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 10:36:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 10:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 10:36:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 10:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 10:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 10:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 10:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 10:36:05 --> Final output sent to browser
DEBUG - 2011-09-02 10:36:05 --> Total execution time: 0.8836
DEBUG - 2011-09-02 10:36:08 --> Config Class Initialized
DEBUG - 2011-09-02 10:36:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:36:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:36:08 --> URI Class Initialized
DEBUG - 2011-09-02 10:36:08 --> Router Class Initialized
ERROR - 2011-09-02 10:36:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 10:54:48 --> Config Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:54:48 --> URI Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Router Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Output Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Input Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 10:54:48 --> Language Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Loader Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Controller Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Model Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Model Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Model Class Initialized
DEBUG - 2011-09-02 10:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 10:54:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 10:54:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 10:54:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 10:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 10:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 10:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 10:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 10:54:48 --> Final output sent to browser
DEBUG - 2011-09-02 10:54:48 --> Total execution time: 0.1661
DEBUG - 2011-09-02 10:54:55 --> Config Class Initialized
DEBUG - 2011-09-02 10:54:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:54:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:54:55 --> URI Class Initialized
DEBUG - 2011-09-02 10:54:55 --> Router Class Initialized
ERROR - 2011-09-02 10:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 10:55:19 --> Config Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:55:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:55:19 --> URI Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Router Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Output Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Input Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 10:55:19 --> Language Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Loader Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Controller Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 10:55:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 10:55:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 10:55:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 10:55:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 10:55:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 10:55:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 10:55:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 10:55:20 --> Final output sent to browser
DEBUG - 2011-09-02 10:55:20 --> Total execution time: 0.6678
DEBUG - 2011-09-02 10:55:24 --> Config Class Initialized
DEBUG - 2011-09-02 10:55:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:55:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:55:24 --> URI Class Initialized
DEBUG - 2011-09-02 10:55:24 --> Router Class Initialized
ERROR - 2011-09-02 10:55:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 10:55:25 --> Config Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 10:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 10:55:25 --> URI Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Router Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Output Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Input Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 10:55:25 --> Language Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Loader Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Controller Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Model Class Initialized
DEBUG - 2011-09-02 10:55:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 10:55:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 10:55:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 10:55:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 10:55:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 10:55:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 10:55:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 10:55:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 10:55:25 --> Final output sent to browser
DEBUG - 2011-09-02 10:55:25 --> Total execution time: 0.0694
DEBUG - 2011-09-02 11:46:28 --> Config Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:46:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:46:28 --> URI Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Router Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Output Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Input Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:46:28 --> Language Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Loader Class Initialized
DEBUG - 2011-09-02 11:46:28 --> Controller Class Initialized
ERROR - 2011-09-02 11:46:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:46:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:46:29 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:29 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:46:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:46:29 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:46:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:46:29 --> Final output sent to browser
DEBUG - 2011-09-02 11:46:29 --> Total execution time: 0.0920
DEBUG - 2011-09-02 11:46:30 --> Config Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:46:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:46:30 --> URI Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Router Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Output Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Input Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:46:30 --> Language Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Loader Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Controller Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:46:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:46:31 --> Final output sent to browser
DEBUG - 2011-09-02 11:46:31 --> Total execution time: 0.6699
DEBUG - 2011-09-02 11:46:32 --> Config Class Initialized
DEBUG - 2011-09-02 11:46:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:46:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:46:32 --> URI Class Initialized
DEBUG - 2011-09-02 11:46:32 --> Router Class Initialized
ERROR - 2011-09-02 11:46:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 11:46:43 --> Config Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:46:43 --> URI Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Router Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Output Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Input Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:46:43 --> Language Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Loader Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Controller Class Initialized
ERROR - 2011-09-02 11:46:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:46:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:46:43 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:46:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:46:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:46:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:46:43 --> Final output sent to browser
DEBUG - 2011-09-02 11:46:43 --> Total execution time: 0.0283
DEBUG - 2011-09-02 11:46:44 --> Config Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:46:44 --> URI Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Router Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Output Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Input Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:46:44 --> Language Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Loader Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Controller Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Model Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:46:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:46:44 --> Final output sent to browser
DEBUG - 2011-09-02 11:46:44 --> Total execution time: 0.6235
DEBUG - 2011-09-02 11:47:04 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:04 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:04 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Controller Class Initialized
ERROR - 2011-09-02 11:47:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:47:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:04 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:04 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:47:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:47:04 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:04 --> Total execution time: 0.0269
DEBUG - 2011-09-02 11:47:04 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:04 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:04 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Controller Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:05 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:05 --> Total execution time: 0.5332
DEBUG - 2011-09-02 11:47:11 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:11 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:11 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Controller Class Initialized
ERROR - 2011-09-02 11:47:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:47:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:11 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:11 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:47:11 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:11 --> Total execution time: 0.0285
DEBUG - 2011-09-02 11:47:12 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:12 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:12 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Controller Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:12 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:12 --> Total execution time: 0.6344
DEBUG - 2011-09-02 11:47:18 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:18 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:18 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Controller Class Initialized
ERROR - 2011-09-02 11:47:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:47:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:18 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:18 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:47:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:47:18 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:18 --> Total execution time: 0.0276
DEBUG - 2011-09-02 11:47:19 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:19 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:19 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Controller Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:20 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:20 --> Total execution time: 0.5524
DEBUG - 2011-09-02 11:47:27 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:27 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:27 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Controller Class Initialized
ERROR - 2011-09-02 11:47:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 11:47:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:27 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 11:47:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 11:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 11:47:27 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:27 --> Total execution time: 0.0358
DEBUG - 2011-09-02 11:47:28 --> Config Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 11:47:28 --> URI Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Router Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Output Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Input Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 11:47:28 --> Language Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Loader Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Controller Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Model Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 11:47:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 11:47:28 --> Final output sent to browser
DEBUG - 2011-09-02 11:47:28 --> Total execution time: 0.5578
DEBUG - 2011-09-02 12:17:02 --> Config Class Initialized
DEBUG - 2011-09-02 12:17:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 12:17:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 12:17:02 --> URI Class Initialized
DEBUG - 2011-09-02 12:17:02 --> Router Class Initialized
ERROR - 2011-09-02 12:17:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 13:12:52 --> Config Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:12:52 --> URI Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Router Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Output Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Input Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:12:52 --> Language Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Loader Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Controller Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Model Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Model Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Model Class Initialized
DEBUG - 2011-09-02 13:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:12:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:12:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:12:53 --> Final output sent to browser
DEBUG - 2011-09-02 13:12:53 --> Total execution time: 0.6453
DEBUG - 2011-09-02 13:13:08 --> Config Class Initialized
DEBUG - 2011-09-02 13:13:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:13:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:13:08 --> URI Class Initialized
DEBUG - 2011-09-02 13:13:08 --> Router Class Initialized
ERROR - 2011-09-02 13:13:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:13:11 --> Config Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:13:11 --> URI Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Router Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Output Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Input Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:13:11 --> Language Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Loader Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Controller Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:13:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:13:12 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:13:12 --> Final output sent to browser
DEBUG - 2011-09-02 13:13:12 --> Total execution time: 0.9239
DEBUG - 2011-09-02 13:13:26 --> Config Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:13:26 --> URI Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Router Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Output Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Input Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:13:26 --> Language Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Loader Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Controller Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:13:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:13:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:13:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:13:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:13:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:13:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:13:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:13:27 --> Final output sent to browser
DEBUG - 2011-09-02 13:13:27 --> Total execution time: 0.2694
DEBUG - 2011-09-02 13:13:39 --> Config Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:13:39 --> URI Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Router Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Output Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Input Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:13:39 --> Language Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Loader Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Controller Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:13:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:13:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:13:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:13:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:13:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:13:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:13:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:13:40 --> Final output sent to browser
DEBUG - 2011-09-02 13:13:40 --> Total execution time: 0.3545
DEBUG - 2011-09-02 13:13:53 --> Config Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:13:53 --> URI Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Router Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Output Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Input Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:13:53 --> Language Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Loader Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Controller Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Model Class Initialized
DEBUG - 2011-09-02 13:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:13:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:13:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:13:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:13:53 --> Final output sent to browser
DEBUG - 2011-09-02 13:13:53 --> Total execution time: 0.4660
DEBUG - 2011-09-02 13:14:04 --> Config Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:14:04 --> URI Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Router Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Output Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Input Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:14:04 --> Language Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Loader Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Controller Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:14:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:14:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:14:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:14:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:14:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:14:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:14:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:14:05 --> Final output sent to browser
DEBUG - 2011-09-02 13:14:05 --> Total execution time: 0.6951
DEBUG - 2011-09-02 13:14:13 --> Config Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:14:13 --> URI Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Router Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Output Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Input Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:14:13 --> Language Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Loader Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Controller Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:14:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:14:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:14:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:14:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:14:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:14:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:14:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:14:13 --> Final output sent to browser
DEBUG - 2011-09-02 13:14:13 --> Total execution time: 0.0524
DEBUG - 2011-09-02 13:14:27 --> Config Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:14:27 --> URI Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Router Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Output Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Input Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:14:27 --> Language Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Loader Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Controller Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:14:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:14:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:14:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:14:27 --> Final output sent to browser
DEBUG - 2011-09-02 13:14:27 --> Total execution time: 0.8664
DEBUG - 2011-09-02 13:14:36 --> Config Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:14:36 --> URI Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Router Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Output Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Input Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:14:36 --> Language Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Loader Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Controller Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:14:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:14:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:14:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:14:36 --> Final output sent to browser
DEBUG - 2011-09-02 13:14:36 --> Total execution time: 0.0632
DEBUG - 2011-09-02 13:18:26 --> Config Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:18:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:18:26 --> URI Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Router Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Output Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Input Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:18:26 --> Language Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Loader Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Controller Class Initialized
ERROR - 2011-09-02 13:18:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:18:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:18:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:18:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:18:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:18:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:18:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:18:26 --> Final output sent to browser
DEBUG - 2011-09-02 13:18:26 --> Total execution time: 0.1121
DEBUG - 2011-09-02 13:18:28 --> Config Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:18:28 --> URI Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Router Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Output Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Input Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:18:28 --> Language Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Loader Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Controller Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Model Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Model Class Initialized
DEBUG - 2011-09-02 13:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:18:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:18:29 --> Final output sent to browser
DEBUG - 2011-09-02 13:18:29 --> Total execution time: 1.4569
DEBUG - 2011-09-02 13:18:31 --> Config Class Initialized
DEBUG - 2011-09-02 13:18:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:18:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:18:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:18:31 --> URI Class Initialized
DEBUG - 2011-09-02 13:18:31 --> Router Class Initialized
ERROR - 2011-09-02 13:18:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:19:21 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:21 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Router Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Output Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Input Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:19:21 --> Language Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Loader Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Controller Class Initialized
ERROR - 2011-09-02 13:19:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:19:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:19:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:19:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:19:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:19:21 --> Final output sent to browser
DEBUG - 2011-09-02 13:19:21 --> Total execution time: 0.0408
DEBUG - 2011-09-02 13:19:23 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:23 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Router Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Output Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Input Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:19:23 --> Language Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Loader Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Controller Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:19:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:19:23 --> Final output sent to browser
DEBUG - 2011-09-02 13:19:23 --> Total execution time: 0.7575
DEBUG - 2011-09-02 13:19:25 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:25 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:25 --> Router Class Initialized
ERROR - 2011-09-02 13:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:19:47 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:47 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Router Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Output Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Input Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:19:47 --> Language Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Loader Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Controller Class Initialized
ERROR - 2011-09-02 13:19:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:19:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:19:47 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:19:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:19:47 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:19:47 --> Final output sent to browser
DEBUG - 2011-09-02 13:19:47 --> Total execution time: 0.0764
DEBUG - 2011-09-02 13:19:48 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:48 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Router Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Output Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Input Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:19:48 --> Language Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Loader Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Controller Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Model Class Initialized
DEBUG - 2011-09-02 13:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:19:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:19:49 --> Final output sent to browser
DEBUG - 2011-09-02 13:19:49 --> Total execution time: 0.7188
DEBUG - 2011-09-02 13:19:51 --> Config Class Initialized
DEBUG - 2011-09-02 13:19:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:19:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:19:51 --> URI Class Initialized
DEBUG - 2011-09-02 13:19:51 --> Router Class Initialized
ERROR - 2011-09-02 13:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:20:06 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:06 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:06 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Controller Class Initialized
ERROR - 2011-09-02 13:20:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:20:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:06 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:20:06 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:06 --> Total execution time: 0.1286
DEBUG - 2011-09-02 13:20:07 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:07 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:07 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:07 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:08 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Controller Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:09 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:09 --> Total execution time: 1.0623
DEBUG - 2011-09-02 13:20:11 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:11 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:11 --> Router Class Initialized
ERROR - 2011-09-02 13:20:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:20:25 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:25 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:25 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:26 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:26 --> Controller Class Initialized
ERROR - 2011-09-02 13:20:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:20:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:26 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:20:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:20:26 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:26 --> Total execution time: 0.0468
DEBUG - 2011-09-02 13:20:27 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:27 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:27 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Controller Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:27 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:27 --> Total execution time: 0.6263
DEBUG - 2011-09-02 13:20:29 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:29 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:29 --> Router Class Initialized
ERROR - 2011-09-02 13:20:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:20:34 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:34 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:34 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Controller Class Initialized
ERROR - 2011-09-02 13:20:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:20:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:34 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:20:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:20:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:20:34 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:34 --> Total execution time: 0.0315
DEBUG - 2011-09-02 13:20:35 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:35 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Router Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Output Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Input Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:20:35 --> Language Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Loader Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Controller Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Model Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:20:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:20:35 --> Final output sent to browser
DEBUG - 2011-09-02 13:20:35 --> Total execution time: 0.5524
DEBUG - 2011-09-02 13:20:37 --> Config Class Initialized
DEBUG - 2011-09-02 13:20:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:20:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:20:37 --> URI Class Initialized
DEBUG - 2011-09-02 13:20:37 --> Router Class Initialized
ERROR - 2011-09-02 13:20:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:24:44 --> Config Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:24:44 --> URI Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Router Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Output Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Input Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:24:44 --> Language Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Loader Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Controller Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Model Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Model Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Model Class Initialized
DEBUG - 2011-09-02 13:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:24:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:24:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:24:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:24:44 --> Final output sent to browser
DEBUG - 2011-09-02 13:24:44 --> Total execution time: 0.0420
DEBUG - 2011-09-02 13:24:45 --> Config Class Initialized
DEBUG - 2011-09-02 13:24:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:24:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:24:45 --> URI Class Initialized
DEBUG - 2011-09-02 13:24:45 --> Router Class Initialized
ERROR - 2011-09-02 13:24:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:25:14 --> Config Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:25:14 --> URI Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Router Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Output Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Input Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:25:14 --> Language Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Loader Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Controller Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:25:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:25:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:25:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:25:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:25:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:25:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:25:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:25:14 --> Final output sent to browser
DEBUG - 2011-09-02 13:25:14 --> Total execution time: 0.0472
DEBUG - 2011-09-02 13:25:15 --> Config Class Initialized
DEBUG - 2011-09-02 13:25:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:25:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:25:15 --> URI Class Initialized
DEBUG - 2011-09-02 13:25:15 --> Router Class Initialized
ERROR - 2011-09-02 13:25:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:25:33 --> Config Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:25:33 --> URI Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Router Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Output Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Input Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:25:33 --> Language Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Loader Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Controller Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:25:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:25:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:25:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:25:34 --> Final output sent to browser
DEBUG - 2011-09-02 13:25:34 --> Total execution time: 0.3954
DEBUG - 2011-09-02 13:25:35 --> Config Class Initialized
DEBUG - 2011-09-02 13:25:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:25:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:25:35 --> URI Class Initialized
DEBUG - 2011-09-02 13:25:35 --> Router Class Initialized
ERROR - 2011-09-02 13:25:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:25:59 --> Config Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:25:59 --> URI Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Router Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Output Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Input Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:25:59 --> Language Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Loader Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Controller Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Model Class Initialized
DEBUG - 2011-09-02 13:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:25:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:25:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:25:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:25:59 --> Final output sent to browser
DEBUG - 2011-09-02 13:25:59 --> Total execution time: 0.0458
DEBUG - 2011-09-02 13:26:00 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:00 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:00 --> Router Class Initialized
ERROR - 2011-09-02 13:26:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:26:21 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:21 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Router Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Output Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Input Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:26:21 --> Language Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Loader Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Controller Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:26:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:26:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:26:21 --> Final output sent to browser
DEBUG - 2011-09-02 13:26:21 --> Total execution time: 0.0501
DEBUG - 2011-09-02 13:26:22 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:22 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:22 --> Router Class Initialized
ERROR - 2011-09-02 13:26:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:26:23 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:23 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Router Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Output Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Input Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:26:23 --> Language Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Loader Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Controller Class Initialized
ERROR - 2011-09-02 13:26:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:26:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:26:23 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:26:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:26:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:26:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:26:23 --> Final output sent to browser
DEBUG - 2011-09-02 13:26:23 --> Total execution time: 0.0277
DEBUG - 2011-09-02 13:26:23 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:23 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Router Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Output Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Input Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:26:23 --> Language Class Initialized
DEBUG - 2011-09-02 13:26:23 --> Loader Class Initialized
DEBUG - 2011-09-02 13:26:24 --> Controller Class Initialized
DEBUG - 2011-09-02 13:26:24 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:24 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:26:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:26:24 --> Final output sent to browser
DEBUG - 2011-09-02 13:26:24 --> Total execution time: 0.5474
DEBUG - 2011-09-02 13:26:25 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:25 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Router Class Initialized
ERROR - 2011-09-02 13:26:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:26:25 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:25 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:25 --> Router Class Initialized
ERROR - 2011-09-02 13:26:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:26:33 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:33 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Router Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Output Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Input Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:26:33 --> Language Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Loader Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Controller Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:26:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:26:33 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:26:33 --> Final output sent to browser
DEBUG - 2011-09-02 13:26:33 --> Total execution time: 0.0578
DEBUG - 2011-09-02 13:26:34 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:34 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:34 --> Router Class Initialized
ERROR - 2011-09-02 13:26:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:26:50 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:50 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Router Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Output Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Input Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:26:50 --> Language Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Loader Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Controller Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Model Class Initialized
DEBUG - 2011-09-02 13:26:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:26:50 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:26:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:26:50 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:26:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:26:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:26:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:26:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:26:50 --> Final output sent to browser
DEBUG - 2011-09-02 13:26:50 --> Total execution time: 0.0639
DEBUG - 2011-09-02 13:26:51 --> Config Class Initialized
DEBUG - 2011-09-02 13:26:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:26:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:26:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:26:51 --> URI Class Initialized
DEBUG - 2011-09-02 13:26:51 --> Router Class Initialized
ERROR - 2011-09-02 13:26:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:48:10 --> Config Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:48:10 --> URI Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Router Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Output Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Input Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:48:10 --> Language Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Loader Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Controller Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Model Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Model Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Model Class Initialized
DEBUG - 2011-09-02 13:48:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:48:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:48:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:48:10 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:48:10 --> Final output sent to browser
DEBUG - 2011-09-02 13:48:10 --> Total execution time: 0.3006
DEBUG - 2011-09-02 13:57:00 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:00 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Router Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Output Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Input Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:57:00 --> Language Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Loader Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Controller Class Initialized
ERROR - 2011-09-02 13:57:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 13:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:57:00 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:57:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 13:57:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:57:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:57:00 --> Final output sent to browser
DEBUG - 2011-09-02 13:57:00 --> Total execution time: 0.0573
DEBUG - 2011-09-02 13:57:02 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:02 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Router Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Output Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Input Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:57:02 --> Language Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Loader Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Controller Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:57:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:57:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:57:02 --> Final output sent to browser
DEBUG - 2011-09-02 13:57:02 --> Total execution time: 0.0579
DEBUG - 2011-09-02 13:57:03 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:03 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:03 --> Router Class Initialized
ERROR - 2011-09-02 13:57:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:57:11 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:11 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Router Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Output Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Input Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:57:11 --> Language Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Loader Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Controller Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:57:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:12 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Router Class Initialized
ERROR - 2011-09-02 13:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:57:12 --> Final output sent to browser
DEBUG - 2011-09-02 13:57:12 --> Total execution time: 0.5482
DEBUG - 2011-09-02 13:57:12 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:12 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:12 --> Router Class Initialized
ERROR - 2011-09-02 13:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:57:36 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:36 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Router Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Output Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Input Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 13:57:36 --> Language Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Loader Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Controller Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Model Class Initialized
DEBUG - 2011-09-02 13:57:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 13:57:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 13:57:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 13:57:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 13:57:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 13:57:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 13:57:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 13:57:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 13:57:36 --> Final output sent to browser
DEBUG - 2011-09-02 13:57:36 --> Total execution time: 0.2251
DEBUG - 2011-09-02 13:57:37 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:37 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:37 --> Router Class Initialized
ERROR - 2011-09-02 13:57:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 13:57:43 --> Config Class Initialized
DEBUG - 2011-09-02 13:57:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 13:57:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 13:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 13:57:43 --> URI Class Initialized
DEBUG - 2011-09-02 13:57:43 --> Router Class Initialized
ERROR - 2011-09-02 13:57:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 14:15:08 --> Config Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:15:08 --> URI Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Router Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Output Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Input Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:15:08 --> Language Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Loader Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Controller Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Model Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Model Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Model Class Initialized
DEBUG - 2011-09-02 14:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:15:08 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:15:08 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:15:08 --> Final output sent to browser
DEBUG - 2011-09-02 14:15:08 --> Total execution time: 0.0445
DEBUG - 2011-09-02 14:51:32 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:32 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Router Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Output Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Input Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:51:32 --> Language Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Loader Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Controller Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:51:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:51:32 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:51:32 --> Final output sent to browser
DEBUG - 2011-09-02 14:51:32 --> Total execution time: 0.2081
DEBUG - 2011-09-02 14:51:35 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:35 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Router Class Initialized
ERROR - 2011-09-02 14:51:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 14:51:35 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:35 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Router Class Initialized
ERROR - 2011-09-02 14:51:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 14:51:35 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:35 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:35 --> Router Class Initialized
ERROR - 2011-09-02 14:51:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 14:51:52 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:52 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Router Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Output Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Input Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:51:52 --> Language Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Loader Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Controller Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:51:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:51:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:51:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:51:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:51:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:51:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:51:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:51:52 --> Final output sent to browser
DEBUG - 2011-09-02 14:51:52 --> Total execution time: 0.2259
DEBUG - 2011-09-02 14:51:56 --> Config Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:51:56 --> URI Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Router Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Output Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Input Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:51:56 --> Language Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Loader Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Controller Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Model Class Initialized
DEBUG - 2011-09-02 14:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:51:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:51:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:51:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:51:56 --> Final output sent to browser
DEBUG - 2011-09-02 14:51:56 --> Total execution time: 0.0482
DEBUG - 2011-09-02 14:52:04 --> Config Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:52:04 --> URI Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Router Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Output Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Input Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:52:04 --> Language Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Loader Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Controller Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:52:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:52:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:52:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:52:05 --> Final output sent to browser
DEBUG - 2011-09-02 14:52:05 --> Total execution time: 0.2438
DEBUG - 2011-09-02 14:52:06 --> Config Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:52:06 --> URI Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Router Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Output Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Input Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:52:06 --> Language Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Loader Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Controller Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:52:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:52:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:52:06 --> Final output sent to browser
DEBUG - 2011-09-02 14:52:06 --> Total execution time: 0.0592
DEBUG - 2011-09-02 14:52:06 --> Config Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:52:06 --> URI Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Router Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Output Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Input Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:52:06 --> Language Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Loader Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Controller Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Model Class Initialized
DEBUG - 2011-09-02 14:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:52:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:52:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:52:06 --> Final output sent to browser
DEBUG - 2011-09-02 14:52:06 --> Total execution time: 0.0727
DEBUG - 2011-09-02 14:54:17 --> Config Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:54:17 --> URI Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Router Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Output Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Input Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 14:54:17 --> Language Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Loader Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Controller Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Model Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Model Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Model Class Initialized
DEBUG - 2011-09-02 14:54:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 14:54:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 14:54:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 14:54:18 --> Helper loaded: url_helper
DEBUG - 2011-09-02 14:54:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 14:54:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 14:54:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 14:54:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 14:54:18 --> Final output sent to browser
DEBUG - 2011-09-02 14:54:18 --> Total execution time: 0.0792
DEBUG - 2011-09-02 14:54:21 --> Config Class Initialized
DEBUG - 2011-09-02 14:54:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 14:54:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 14:54:21 --> URI Class Initialized
DEBUG - 2011-09-02 14:54:21 --> Router Class Initialized
ERROR - 2011-09-02 14:54:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 15:22:44 --> Config Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:22:44 --> URI Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Router Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Output Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Input Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:22:44 --> Language Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Loader Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Controller Class Initialized
ERROR - 2011-09-02 15:22:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 15:22:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 15:22:44 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:22:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 15:22:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 15:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 15:22:44 --> Final output sent to browser
DEBUG - 2011-09-02 15:22:44 --> Total execution time: 0.1037
DEBUG - 2011-09-02 15:22:48 --> Config Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:22:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:22:48 --> URI Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Router Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Output Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Input Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:22:48 --> Language Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Loader Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Controller Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:22:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:22:49 --> Final output sent to browser
DEBUG - 2011-09-02 15:22:49 --> Total execution time: 0.7913
DEBUG - 2011-09-02 15:22:51 --> Config Class Initialized
DEBUG - 2011-09-02 15:22:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:22:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:22:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:22:51 --> URI Class Initialized
DEBUG - 2011-09-02 15:22:51 --> Router Class Initialized
ERROR - 2011-09-02 15:22:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 15:22:54 --> Config Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:22:54 --> URI Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Router Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Output Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Input Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:22:54 --> Language Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Loader Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Controller Class Initialized
ERROR - 2011-09-02 15:22:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 15:22:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 15:22:54 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:22:54 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 15:22:54 --> Helper loaded: url_helper
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 15:22:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 15:22:54 --> Final output sent to browser
DEBUG - 2011-09-02 15:22:54 --> Total execution time: 0.0293
DEBUG - 2011-09-02 15:22:55 --> Config Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:22:55 --> URI Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Router Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Output Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Input Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:22:55 --> Language Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Loader Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Controller Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Model Class Initialized
DEBUG - 2011-09-02 15:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:22:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:22:56 --> Final output sent to browser
DEBUG - 2011-09-02 15:22:56 --> Total execution time: 0.5692
DEBUG - 2011-09-02 15:23:01 --> Config Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:23:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:23:01 --> URI Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Router Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Output Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Input Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:23:01 --> Language Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Loader Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Controller Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:23:01 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:23:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 15:23:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 15:23:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 15:23:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 15:23:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 15:23:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 15:23:02 --> Final output sent to browser
DEBUG - 2011-09-02 15:23:02 --> Total execution time: 0.3574
DEBUG - 2011-09-02 15:23:22 --> Config Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:23:22 --> URI Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Router Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Output Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Input Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:23:22 --> Language Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Loader Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Controller Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:23:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:23:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 15:23:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 15:23:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 15:23:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 15:23:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 15:23:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 15:23:23 --> Final output sent to browser
DEBUG - 2011-09-02 15:23:23 --> Total execution time: 0.5759
DEBUG - 2011-09-02 15:23:47 --> Config Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 15:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 15:23:47 --> URI Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Router Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Output Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Input Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 15:23:47 --> Language Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Loader Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Controller Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Model Class Initialized
DEBUG - 2011-09-02 15:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 15:23:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 15:23:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 15:23:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 15:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 15:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 15:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 15:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 15:23:48 --> Final output sent to browser
DEBUG - 2011-09-02 15:23:48 --> Total execution time: 0.3061
DEBUG - 2011-09-02 16:00:46 --> Config Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:00:46 --> URI Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Router Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Output Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Input Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:00:46 --> Language Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Loader Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Controller Class Initialized
ERROR - 2011-09-02 16:00:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 16:00:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:00:46 --> Model Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Model Class Initialized
DEBUG - 2011-09-02 16:00:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:00:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:00:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:00:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:00:46 --> Final output sent to browser
DEBUG - 2011-09-02 16:00:46 --> Total execution time: 0.0681
DEBUG - 2011-09-02 16:00:48 --> Config Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:00:48 --> URI Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Router Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Output Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Input Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:00:48 --> Language Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Loader Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Controller Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Model Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Model Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:00:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:00:48 --> Final output sent to browser
DEBUG - 2011-09-02 16:00:48 --> Total execution time: 0.6285
DEBUG - 2011-09-02 16:00:50 --> Config Class Initialized
DEBUG - 2011-09-02 16:00:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:00:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:00:50 --> URI Class Initialized
DEBUG - 2011-09-02 16:00:50 --> Router Class Initialized
ERROR - 2011-09-02 16:00:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 16:01:15 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:15 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Router Class Initialized
DEBUG - 2011-09-02 16:01:15 --> No URI present. Default controller set.
DEBUG - 2011-09-02 16:01:15 --> Output Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Input Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:01:15 --> Language Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Loader Class Initialized
DEBUG - 2011-09-02 16:01:15 --> Controller Class Initialized
DEBUG - 2011-09-02 16:01:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 16:01:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:01:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:01:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:01:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:01:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:01:15 --> Final output sent to browser
DEBUG - 2011-09-02 16:01:15 --> Total execution time: 0.0732
DEBUG - 2011-09-02 16:01:34 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:34 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Router Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Output Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Input Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:01:34 --> Language Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Loader Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Controller Class Initialized
ERROR - 2011-09-02 16:01:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 16:01:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:34 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:01:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:01:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:01:34 --> Final output sent to browser
DEBUG - 2011-09-02 16:01:34 --> Total execution time: 0.0419
DEBUG - 2011-09-02 16:01:35 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:35 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Router Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Output Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Input Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:01:35 --> Language Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Loader Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Controller Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:01:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:01:35 --> Final output sent to browser
DEBUG - 2011-09-02 16:01:35 --> Total execution time: 0.5283
DEBUG - 2011-09-02 16:01:36 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:36 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Router Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Output Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Input Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:01:36 --> Language Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Loader Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Controller Class Initialized
ERROR - 2011-09-02 16:01:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 16:01:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:36 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:01:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:01:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:01:36 --> Final output sent to browser
DEBUG - 2011-09-02 16:01:36 --> Total execution time: 0.0318
DEBUG - 2011-09-02 16:01:37 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:37 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:37 --> Router Class Initialized
ERROR - 2011-09-02 16:01:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 16:01:59 --> Config Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:01:59 --> URI Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Router Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Output Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Input Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:01:59 --> Language Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Loader Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Controller Class Initialized
ERROR - 2011-09-02 16:01:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 16:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:59 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Model Class Initialized
DEBUG - 2011-09-02 16:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:01:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:01:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:01:59 --> Final output sent to browser
DEBUG - 2011-09-02 16:01:59 --> Total execution time: 0.0305
DEBUG - 2011-09-02 16:02:02 --> Config Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:02:02 --> URI Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Router Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Output Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Input Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:02:02 --> Language Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Loader Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Controller Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:02:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:02:03 --> Final output sent to browser
DEBUG - 2011-09-02 16:02:03 --> Total execution time: 0.5642
DEBUG - 2011-09-02 16:02:05 --> Config Class Initialized
DEBUG - 2011-09-02 16:02:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:02:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:02:05 --> URI Class Initialized
DEBUG - 2011-09-02 16:02:05 --> Router Class Initialized
ERROR - 2011-09-02 16:02:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 16:02:21 --> Config Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:02:21 --> URI Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Router Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Output Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Input Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:02:21 --> Language Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Loader Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Controller Class Initialized
ERROR - 2011-09-02 16:02:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 16:02:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:02:21 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:02:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 16:02:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 16:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 16:02:21 --> Final output sent to browser
DEBUG - 2011-09-02 16:02:21 --> Total execution time: 0.0320
DEBUG - 2011-09-02 16:02:22 --> Config Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:02:22 --> URI Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Router Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Output Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Input Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 16:02:22 --> Language Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Loader Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Controller Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Model Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 16:02:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 16:02:22 --> Final output sent to browser
DEBUG - 2011-09-02 16:02:22 --> Total execution time: 0.5482
DEBUG - 2011-09-02 16:02:24 --> Config Class Initialized
DEBUG - 2011-09-02 16:02:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 16:02:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 16:02:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 16:02:24 --> URI Class Initialized
DEBUG - 2011-09-02 16:02:24 --> Router Class Initialized
ERROR - 2011-09-02 16:02:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:13:25 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:25 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Router Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Output Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Input Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:13:25 --> Language Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Loader Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Controller Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:13:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:13:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 17:13:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:13:25 --> Final output sent to browser
DEBUG - 2011-09-02 17:13:25 --> Total execution time: 0.6669
DEBUG - 2011-09-02 17:13:26 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:26 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Router Class Initialized
ERROR - 2011-09-02 17:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:13:26 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:26 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Router Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Output Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Input Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:13:26 --> Language Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Loader Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Controller Class Initialized
ERROR - 2011-09-02 17:13:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:13:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:13:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:13:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:13:26 --> Final output sent to browser
DEBUG - 2011-09-02 17:13:26 --> Total execution time: 0.0766
DEBUG - 2011-09-02 17:13:27 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:27 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Router Class Initialized
ERROR - 2011-09-02 17:13:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:13:27 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:27 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Router Class Initialized
ERROR - 2011-09-02 17:13:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:13:27 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:27 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Router Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Output Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Input Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:13:27 --> Language Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Loader Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Controller Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:13:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:13:28 --> Final output sent to browser
DEBUG - 2011-09-02 17:13:28 --> Total execution time: 0.6016
DEBUG - 2011-09-02 17:13:39 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:39 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Router Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Output Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Input Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:13:39 --> Language Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Loader Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Controller Class Initialized
ERROR - 2011-09-02 17:13:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:13:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:13:39 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:13:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:13:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:13:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:13:39 --> Final output sent to browser
DEBUG - 2011-09-02 17:13:39 --> Total execution time: 0.0298
DEBUG - 2011-09-02 17:13:40 --> Config Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:13:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:13:40 --> URI Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Router Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Output Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Input Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:13:40 --> Language Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Loader Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Controller Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Model Class Initialized
DEBUG - 2011-09-02 17:13:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:13:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:13:41 --> Final output sent to browser
DEBUG - 2011-09-02 17:13:41 --> Total execution time: 0.5895
DEBUG - 2011-09-02 17:14:04 --> Config Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:14:04 --> URI Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Router Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Output Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Input Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:14:04 --> Language Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Loader Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Controller Class Initialized
ERROR - 2011-09-02 17:14:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:14:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:04 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:14:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:04 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:14:04 --> Final output sent to browser
DEBUG - 2011-09-02 17:14:04 --> Total execution time: 0.0313
DEBUG - 2011-09-02 17:14:05 --> Config Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:14:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:14:05 --> URI Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Router Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Output Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Input Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:14:05 --> Language Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Loader Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Controller Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:14:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:14:06 --> Final output sent to browser
DEBUG - 2011-09-02 17:14:06 --> Total execution time: 0.5928
DEBUG - 2011-09-02 17:14:24 --> Config Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:14:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:14:24 --> URI Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Router Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Output Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Input Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:14:24 --> Language Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Loader Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Controller Class Initialized
ERROR - 2011-09-02 17:14:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:14:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:24 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:14:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:14:24 --> Final output sent to browser
DEBUG - 2011-09-02 17:14:24 --> Total execution time: 0.0296
DEBUG - 2011-09-02 17:14:25 --> Config Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:14:25 --> URI Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Router Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Output Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Input Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:14:25 --> Language Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Loader Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Controller Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:14:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:14:25 --> Final output sent to browser
DEBUG - 2011-09-02 17:14:25 --> Total execution time: 0.5577
DEBUG - 2011-09-02 17:14:26 --> Config Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:14:26 --> URI Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Router Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Output Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Input Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:14:26 --> Language Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Loader Class Initialized
DEBUG - 2011-09-02 17:14:26 --> Controller Class Initialized
ERROR - 2011-09-02 17:14:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:14:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:14:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:26 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:27 --> Model Class Initialized
DEBUG - 2011-09-02 17:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:14:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:14:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:14:27 --> Final output sent to browser
DEBUG - 2011-09-02 17:14:27 --> Total execution time: 0.0297
DEBUG - 2011-09-02 17:26:43 --> Config Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:26:43 --> URI Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Router Class Initialized
DEBUG - 2011-09-02 17:26:43 --> No URI present. Default controller set.
DEBUG - 2011-09-02 17:26:43 --> Output Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Input Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:26:43 --> Language Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Loader Class Initialized
DEBUG - 2011-09-02 17:26:43 --> Controller Class Initialized
DEBUG - 2011-09-02 17:26:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 17:26:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:26:43 --> Final output sent to browser
DEBUG - 2011-09-02 17:26:43 --> Total execution time: 0.0647
DEBUG - 2011-09-02 17:32:00 --> Config Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:32:00 --> URI Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Router Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Output Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Input Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:32:00 --> Language Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Loader Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Controller Class Initialized
ERROR - 2011-09-02 17:32:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:32:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:32:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:32:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:32:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:32:00 --> Final output sent to browser
DEBUG - 2011-09-02 17:32:00 --> Total execution time: 0.0318
DEBUG - 2011-09-02 17:32:00 --> Config Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:32:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:32:00 --> URI Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Router Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Output Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Input Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:32:00 --> Language Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Loader Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Controller Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Model Class Initialized
DEBUG - 2011-09-02 17:32:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:32:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:32:01 --> Final output sent to browser
DEBUG - 2011-09-02 17:32:01 --> Total execution time: 0.5646
DEBUG - 2011-09-02 17:32:04 --> Config Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:32:04 --> URI Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Router Class Initialized
ERROR - 2011-09-02 17:32:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:32:04 --> Config Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:32:04 --> URI Class Initialized
DEBUG - 2011-09-02 17:32:04 --> Router Class Initialized
ERROR - 2011-09-02 17:32:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:33:02 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:02 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:02 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Controller Class Initialized
ERROR - 2011-09-02 17:33:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:33:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:02 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:33:02 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:02 --> Total execution time: 0.0457
DEBUG - 2011-09-02 17:33:03 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:03 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:03 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Controller Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:04 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:04 --> Total execution time: 0.4992
DEBUG - 2011-09-02 17:33:17 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:17 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:17 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Controller Class Initialized
ERROR - 2011-09-02 17:33:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:33:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:17 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:17 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:33:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:33:17 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:17 --> Total execution time: 0.0285
DEBUG - 2011-09-02 17:33:18 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:18 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:18 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Controller Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:18 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:18 --> Total execution time: 0.4801
DEBUG - 2011-09-02 17:33:35 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:35 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:35 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Controller Class Initialized
ERROR - 2011-09-02 17:33:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:33:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:35 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:33:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:33:35 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:35 --> Total execution time: 0.0322
DEBUG - 2011-09-02 17:33:36 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:36 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:36 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Controller Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:37 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:37 --> Total execution time: 0.6131
DEBUG - 2011-09-02 17:33:51 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:51 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:51 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Controller Class Initialized
ERROR - 2011-09-02 17:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:51 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:33:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:33:51 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:51 --> Total execution time: 0.0583
DEBUG - 2011-09-02 17:33:51 --> Config Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:33:51 --> URI Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Router Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Output Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Input Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:33:51 --> Language Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Loader Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Controller Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Model Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:33:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:33:51 --> Final output sent to browser
DEBUG - 2011-09-02 17:33:51 --> Total execution time: 0.4533
DEBUG - 2011-09-02 17:34:05 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:05 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:05 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:05 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:05 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:05 --> Total execution time: 0.0281
DEBUG - 2011-09-02 17:34:06 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:06 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:06 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Controller Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:06 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:06 --> Total execution time: 0.6211
DEBUG - 2011-09-02 17:34:07 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:07 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:07 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:07 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:07 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:07 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:07 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:07 --> Total execution time: 0.0278
DEBUG - 2011-09-02 17:34:11 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:11 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:11 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:11 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:11 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:11 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:11 --> Total execution time: 0.0276
DEBUG - 2011-09-02 17:34:12 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:12 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:12 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Controller Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:12 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:12 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:12 --> Total execution time: 0.5792
DEBUG - 2011-09-02 17:34:16 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:16 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:16 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:16 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:16 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:16 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:16 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:16 --> Total execution time: 0.0282
DEBUG - 2011-09-02 17:34:16 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:16 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:16 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Controller Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:17 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:17 --> Total execution time: 0.5278
DEBUG - 2011-09-02 17:34:49 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:49 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:49 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:49 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:49 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:49 --> Total execution time: 0.0306
DEBUG - 2011-09-02 17:34:50 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:50 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:50 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Controller Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:50 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Config Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:34:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:34:50 --> URI Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Router Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Output Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Input Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:34:50 --> Language Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Loader Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Controller Class Initialized
ERROR - 2011-09-02 17:34:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:34:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:50 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Model Class Initialized
DEBUG - 2011-09-02 17:34:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:34:50 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:34:50 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:34:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:34:50 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:50 --> Total execution time: 0.0296
DEBUG - 2011-09-02 17:34:50 --> Final output sent to browser
DEBUG - 2011-09-02 17:34:50 --> Total execution time: 0.5754
DEBUG - 2011-09-02 17:35:39 --> Config Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:35:39 --> URI Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Router Class Initialized
DEBUG - 2011-09-02 17:35:39 --> No URI present. Default controller set.
DEBUG - 2011-09-02 17:35:39 --> Output Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Input Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:35:39 --> Language Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Loader Class Initialized
DEBUG - 2011-09-02 17:35:39 --> Controller Class Initialized
DEBUG - 2011-09-02 17:35:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 17:35:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:35:39 --> Final output sent to browser
DEBUG - 2011-09-02 17:35:39 --> Total execution time: 0.0146
DEBUG - 2011-09-02 17:42:36 --> Config Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:42:36 --> URI Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Router Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Output Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Input Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:42:36 --> Language Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Loader Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Controller Class Initialized
ERROR - 2011-09-02 17:42:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:42:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:42:36 --> Model Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Model Class Initialized
DEBUG - 2011-09-02 17:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:42:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:42:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:42:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:42:36 --> Final output sent to browser
DEBUG - 2011-09-02 17:42:36 --> Total execution time: 0.0312
DEBUG - 2011-09-02 17:42:37 --> Config Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:42:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:42:37 --> URI Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Router Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Output Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Input Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:42:37 --> Language Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Loader Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Controller Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Model Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Model Class Initialized
DEBUG - 2011-09-02 17:42:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:42:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:42:38 --> Final output sent to browser
DEBUG - 2011-09-02 17:42:38 --> Total execution time: 0.5189
DEBUG - 2011-09-02 17:42:39 --> Config Class Initialized
DEBUG - 2011-09-02 17:42:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:42:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:42:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:42:39 --> URI Class Initialized
DEBUG - 2011-09-02 17:42:39 --> Router Class Initialized
ERROR - 2011-09-02 17:42:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 17:45:58 --> Config Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:45:58 --> URI Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Router Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Output Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Input Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:45:58 --> Language Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Loader Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Controller Class Initialized
ERROR - 2011-09-02 17:45:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 17:45:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:45:58 --> Model Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Model Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:45:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 17:45:58 --> Helper loaded: url_helper
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 17:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 17:45:58 --> Final output sent to browser
DEBUG - 2011-09-02 17:45:58 --> Total execution time: 0.0286
DEBUG - 2011-09-02 17:45:58 --> Config Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 17:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 17:45:58 --> URI Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Router Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Output Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Input Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 17:45:58 --> Language Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Loader Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Controller Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Model Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Model Class Initialized
DEBUG - 2011-09-02 17:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 17:45:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 17:45:59 --> Final output sent to browser
DEBUG - 2011-09-02 17:45:59 --> Total execution time: 0.4688
DEBUG - 2011-09-02 18:01:19 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:19 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:19 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Controller Class Initialized
ERROR - 2011-09-02 18:01:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:01:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:01:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:01:19 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:19 --> Total execution time: 0.0367
DEBUG - 2011-09-02 18:01:19 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:19 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:19 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Controller Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:20 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:20 --> Total execution time: 0.5324
DEBUG - 2011-09-02 18:01:44 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:44 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:44 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Controller Class Initialized
ERROR - 2011-09-02 18:01:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:01:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:44 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:01:44 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:44 --> Total execution time: 0.0281
DEBUG - 2011-09-02 18:01:44 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:44 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:44 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Controller Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:45 --> Total execution time: 0.3976
DEBUG - 2011-09-02 18:01:45 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:45 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:45 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Controller Class Initialized
ERROR - 2011-09-02 18:01:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:01:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:45 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:01:45 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:45 --> Total execution time: 0.0278
DEBUG - 2011-09-02 18:01:56 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:56 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:56 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Controller Class Initialized
ERROR - 2011-09-02 18:01:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:01:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:01:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:01:56 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:56 --> Total execution time: 0.0630
DEBUG - 2011-09-02 18:01:56 --> Config Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:01:56 --> URI Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Router Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Output Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Input Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:01:56 --> Language Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Loader Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Controller Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:01:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:01:56 --> Final output sent to browser
DEBUG - 2011-09-02 18:01:56 --> Total execution time: 0.5018
DEBUG - 2011-09-02 18:02:26 --> Config Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:02:26 --> URI Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Router Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Output Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Input Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:02:26 --> Language Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Loader Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Controller Class Initialized
ERROR - 2011-09-02 18:02:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:02:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:02:26 --> Model Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Model Class Initialized
DEBUG - 2011-09-02 18:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:02:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:02:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:02:26 --> Final output sent to browser
DEBUG - 2011-09-02 18:02:26 --> Total execution time: 0.0273
DEBUG - 2011-09-02 18:02:27 --> Config Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:02:27 --> URI Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Router Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Output Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Input Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:02:27 --> Language Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Loader Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Controller Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Model Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Model Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:02:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:02:27 --> Final output sent to browser
DEBUG - 2011-09-02 18:02:27 --> Total execution time: 0.6584
DEBUG - 2011-09-02 18:03:00 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:00 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:00 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Controller Class Initialized
ERROR - 2011-09-02 18:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:00 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:03:00 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:00 --> Total execution time: 0.0290
DEBUG - 2011-09-02 18:03:01 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:01 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:01 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Controller Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:01 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:01 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:01 --> Total execution time: 0.5333
DEBUG - 2011-09-02 18:03:19 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:19 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:19 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Controller Class Initialized
ERROR - 2011-09-02 18:03:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:03:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:03:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:03:19 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:19 --> Total execution time: 0.0535
DEBUG - 2011-09-02 18:03:19 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:19 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:19 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Controller Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:20 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:20 --> Total execution time: 0.5141
DEBUG - 2011-09-02 18:03:41 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:41 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:41 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Controller Class Initialized
ERROR - 2011-09-02 18:03:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:03:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:03:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:03:41 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:41 --> Total execution time: 0.0278
DEBUG - 2011-09-02 18:03:41 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:41 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:41 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Controller Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:42 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:42 --> Total execution time: 0.5503
DEBUG - 2011-09-02 18:03:56 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:56 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:56 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Controller Class Initialized
ERROR - 2011-09-02 18:03:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:03:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:03:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:03:56 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:56 --> Total execution time: 0.0283
DEBUG - 2011-09-02 18:03:56 --> Config Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:03:56 --> URI Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Router Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Output Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Input Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:03:56 --> Language Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Loader Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Controller Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Model Class Initialized
DEBUG - 2011-09-02 18:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:03:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:03:57 --> Final output sent to browser
DEBUG - 2011-09-02 18:03:57 --> Total execution time: 0.5858
DEBUG - 2011-09-02 18:04:39 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:39 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:39 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Controller Class Initialized
ERROR - 2011-09-02 18:04:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:04:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:39 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:04:39 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:39 --> Total execution time: 0.0301
DEBUG - 2011-09-02 18:04:39 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:39 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:39 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Controller Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:40 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:40 --> Total execution time: 0.7138
DEBUG - 2011-09-02 18:04:45 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:45 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:45 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Controller Class Initialized
ERROR - 2011-09-02 18:04:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:04:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:45 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:04:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:04:45 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:45 --> Total execution time: 0.0475
DEBUG - 2011-09-02 18:04:46 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:46 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:46 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Controller Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:46 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:46 --> Total execution time: 0.4699
DEBUG - 2011-09-02 18:04:51 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:51 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:51 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Controller Class Initialized
ERROR - 2011-09-02 18:04:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:04:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:51 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:04:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:04:51 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:51 --> Total execution time: 0.0277
DEBUG - 2011-09-02 18:04:57 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:57 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:57 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Controller Class Initialized
ERROR - 2011-09-02 18:04:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:04:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:57 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:04:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:04:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:04:57 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:57 --> Total execution time: 0.0275
DEBUG - 2011-09-02 18:04:57 --> Config Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:04:57 --> URI Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Router Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Output Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Input Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:04:57 --> Language Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Loader Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Controller Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Model Class Initialized
DEBUG - 2011-09-02 18:04:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:04:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:04:58 --> Final output sent to browser
DEBUG - 2011-09-02 18:04:58 --> Total execution time: 0.5530
DEBUG - 2011-09-02 18:07:15 --> Config Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:07:15 --> URI Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Router Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Output Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Input Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:07:15 --> Language Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Loader Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Controller Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Model Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Model Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Model Class Initialized
DEBUG - 2011-09-02 18:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:07:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:07:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:07:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:07:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:07:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:07:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:07:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:07:15 --> Final output sent to browser
DEBUG - 2011-09-02 18:07:15 --> Total execution time: 0.2035
DEBUG - 2011-09-02 18:09:20 --> Config Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:09:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:09:20 --> URI Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Router Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Output Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Input Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:09:20 --> Language Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Loader Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Controller Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:09:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:09:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:09:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:09:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:09:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:09:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:09:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:09:20 --> Final output sent to browser
DEBUG - 2011-09-02 18:09:20 --> Total execution time: 0.0540
DEBUG - 2011-09-02 18:09:24 --> Config Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:09:24 --> URI Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Router Class Initialized
ERROR - 2011-09-02 18:09:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:09:24 --> Config Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:09:24 --> URI Class Initialized
DEBUG - 2011-09-02 18:09:24 --> Router Class Initialized
ERROR - 2011-09-02 18:09:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:09:34 --> Config Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:09:34 --> URI Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Router Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Output Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Input Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:09:34 --> Language Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Loader Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Controller Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Model Class Initialized
DEBUG - 2011-09-02 18:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:09:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:09:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:09:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:09:34 --> Final output sent to browser
DEBUG - 2011-09-02 18:09:34 --> Total execution time: 0.0924
DEBUG - 2011-09-02 18:19:21 --> Config Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:19:21 --> URI Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Router Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Output Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Input Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:19:21 --> Language Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Loader Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Controller Class Initialized
ERROR - 2011-09-02 18:19:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:19:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:19:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:19:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:19:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:19:21 --> Final output sent to browser
DEBUG - 2011-09-02 18:19:21 --> Total execution time: 0.0353
DEBUG - 2011-09-02 18:19:21 --> Config Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:19:21 --> URI Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Router Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Output Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Input Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:19:21 --> Language Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Loader Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Controller Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:19:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:19:22 --> Final output sent to browser
DEBUG - 2011-09-02 18:19:22 --> Total execution time: 0.6981
DEBUG - 2011-09-02 18:19:23 --> Config Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:19:23 --> URI Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Router Class Initialized
ERROR - 2011-09-02 18:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:19:23 --> Config Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:19:23 --> URI Class Initialized
DEBUG - 2011-09-02 18:19:23 --> Router Class Initialized
ERROR - 2011-09-02 18:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:20:46 --> Config Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:20:46 --> URI Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Router Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Output Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Input Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:20:46 --> Language Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Loader Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Controller Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:20:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:20:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:20:46 --> Final output sent to browser
DEBUG - 2011-09-02 18:20:46 --> Total execution time: 0.0454
DEBUG - 2011-09-02 18:20:49 --> Config Class Initialized
DEBUG - 2011-09-02 18:20:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:20:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:20:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:20:49 --> URI Class Initialized
DEBUG - 2011-09-02 18:20:49 --> Router Class Initialized
ERROR - 2011-09-02 18:20:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:20:58 --> Config Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:20:58 --> URI Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Router Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Output Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Input Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:20:58 --> Language Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Loader Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Controller Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:20:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:20:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:20:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:20:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:20:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:20:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:20:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:20:59 --> Final output sent to browser
DEBUG - 2011-09-02 18:20:59 --> Total execution time: 0.3165
DEBUG - 2011-09-02 18:21:00 --> Config Class Initialized
DEBUG - 2011-09-02 18:21:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:21:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:21:00 --> URI Class Initialized
DEBUG - 2011-09-02 18:21:00 --> Router Class Initialized
ERROR - 2011-09-02 18:21:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:21:11 --> Config Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:21:11 --> URI Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Router Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Output Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Input Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:21:11 --> Language Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Loader Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Controller Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:21:11 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:21:11 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:21:11 --> Final output sent to browser
DEBUG - 2011-09-02 18:21:11 --> Total execution time: 0.2404
DEBUG - 2011-09-02 18:21:13 --> Config Class Initialized
DEBUG - 2011-09-02 18:21:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:21:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:21:13 --> URI Class Initialized
DEBUG - 2011-09-02 18:21:13 --> Router Class Initialized
ERROR - 2011-09-02 18:21:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:21:32 --> Config Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:21:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:21:32 --> URI Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Router Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Output Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Input Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:21:32 --> Language Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Loader Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Controller Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Model Class Initialized
DEBUG - 2011-09-02 18:21:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:21:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:21:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:21:32 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:21:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:21:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:21:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:21:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:21:32 --> Final output sent to browser
DEBUG - 2011-09-02 18:21:32 --> Total execution time: 0.2678
DEBUG - 2011-09-02 18:21:34 --> Config Class Initialized
DEBUG - 2011-09-02 18:21:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:21:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:21:34 --> URI Class Initialized
DEBUG - 2011-09-02 18:21:34 --> Router Class Initialized
ERROR - 2011-09-02 18:21:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:37:04 --> Config Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:37:04 --> URI Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Router Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Output Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Input Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:37:04 --> Language Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Loader Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Controller Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Model Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Model Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Model Class Initialized
DEBUG - 2011-09-02 18:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:37:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:37:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:37:04 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:37:04 --> Final output sent to browser
DEBUG - 2011-09-02 18:37:04 --> Total execution time: 0.1089
DEBUG - 2011-09-02 18:37:22 --> Config Class Initialized
DEBUG - 2011-09-02 18:37:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:37:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:37:22 --> URI Class Initialized
DEBUG - 2011-09-02 18:37:22 --> Router Class Initialized
ERROR - 2011-09-02 18:37:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:37:27 --> Config Class Initialized
DEBUG - 2011-09-02 18:37:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:37:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:37:27 --> URI Class Initialized
DEBUG - 2011-09-02 18:37:27 --> Router Class Initialized
ERROR - 2011-09-02 18:37:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 18:38:20 --> Config Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:38:20 --> URI Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Router Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Output Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Input Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:38:20 --> Language Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Loader Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Controller Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:38:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:38:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:38:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:38:20 --> Final output sent to browser
DEBUG - 2011-09-02 18:38:20 --> Total execution time: 0.0700
DEBUG - 2011-09-02 18:38:35 --> Config Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:38:35 --> URI Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Router Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Output Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Input Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:38:35 --> Language Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Loader Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Controller Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:38:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:38:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:38:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:38:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:38:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:38:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:38:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:38:35 --> Final output sent to browser
DEBUG - 2011-09-02 18:38:35 --> Total execution time: 0.0610
DEBUG - 2011-09-02 18:38:58 --> Config Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:38:58 --> URI Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Router Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Output Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Input Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:38:58 --> Language Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Loader Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Controller Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Model Class Initialized
DEBUG - 2011-09-02 18:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:38:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:38:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:38:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:38:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:38:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:38:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:38:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:38:59 --> Final output sent to browser
DEBUG - 2011-09-02 18:38:59 --> Total execution time: 0.5464
DEBUG - 2011-09-02 18:39:02 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:02 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:02 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:02 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:02 --> Total execution time: 0.1500
DEBUG - 2011-09-02 18:39:06 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:06 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:06 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:06 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:06 --> Total execution time: 0.0506
DEBUG - 2011-09-02 18:39:09 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:09 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:09 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Controller Class Initialized
ERROR - 2011-09-02 18:39:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:39:09 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:39:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:09 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:09 --> Total execution time: 0.0505
DEBUG - 2011-09-02 18:39:10 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:10 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:10 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:11 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:11 --> Total execution time: 0.4676
DEBUG - 2011-09-02 18:39:18 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:18 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:18 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:18 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:18 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:18 --> Total execution time: 0.2110
DEBUG - 2011-09-02 18:39:31 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:31 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:31 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:32 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:32 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:32 --> Total execution time: 0.1325
DEBUG - 2011-09-02 18:39:40 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:40 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:40 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:40 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:40 --> Total execution time: 0.1852
DEBUG - 2011-09-02 18:39:41 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:41 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:41 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:41 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:41 --> Total execution time: 0.2068
DEBUG - 2011-09-02 18:39:42 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:42 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:42 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:42 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:42 --> Total execution time: 0.0410
DEBUG - 2011-09-02 18:39:49 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:49 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:49 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:49 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:49 --> Total execution time: 0.2309
DEBUG - 2011-09-02 18:39:50 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:50 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:50 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:50 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:50 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:50 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:50 --> Total execution time: 0.0418
DEBUG - 2011-09-02 18:39:55 --> Config Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:39:55 --> URI Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Router Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Output Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Input Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:39:55 --> Language Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Loader Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Controller Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Model Class Initialized
DEBUG - 2011-09-02 18:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:39:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:39:55 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:39:55 --> Final output sent to browser
DEBUG - 2011-09-02 18:39:55 --> Total execution time: 0.0469
DEBUG - 2011-09-02 18:40:03 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:03 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:03 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:04 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:04 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:04 --> Total execution time: 1.1390
DEBUG - 2011-09-02 18:40:05 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:05 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:05 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:06 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:06 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:06 --> Total execution time: 0.0667
DEBUG - 2011-09-02 18:40:21 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:21 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:21 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:21 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:21 --> Total execution time: 0.2551
DEBUG - 2011-09-02 18:40:25 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:25 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:25 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:26 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:26 --> Total execution time: 0.3409
DEBUG - 2011-09-02 18:40:35 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:35 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:35 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:35 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:35 --> Total execution time: 0.2822
DEBUG - 2011-09-02 18:40:42 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:42 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:42 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:42 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:42 --> Total execution time: 0.0473
DEBUG - 2011-09-02 18:40:54 --> Config Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:40:54 --> URI Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Router Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Output Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Input Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:40:54 --> Language Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Loader Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Controller Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Model Class Initialized
DEBUG - 2011-09-02 18:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:40:54 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:40:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:40:54 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:40:54 --> Final output sent to browser
DEBUG - 2011-09-02 18:40:54 --> Total execution time: 0.2279
DEBUG - 2011-09-02 18:41:05 --> Config Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:41:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:41:05 --> URI Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Router Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Output Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Input Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:41:05 --> Language Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Loader Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Controller Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:41:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:41:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:41:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:41:06 --> Final output sent to browser
DEBUG - 2011-09-02 18:41:06 --> Total execution time: 0.5538
DEBUG - 2011-09-02 18:41:13 --> Config Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:41:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:41:13 --> URI Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Router Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Output Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Input Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:41:13 --> Language Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Loader Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Controller Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:41:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:41:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:41:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:41:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:41:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:41:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:41:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:41:13 --> Final output sent to browser
DEBUG - 2011-09-02 18:41:13 --> Total execution time: 0.2308
DEBUG - 2011-09-02 18:41:20 --> Config Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:41:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:41:20 --> URI Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Router Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Output Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Input Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:41:20 --> Language Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Loader Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Controller Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:41:20 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:41:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:41:20 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:41:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:41:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:41:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:41:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:41:20 --> Final output sent to browser
DEBUG - 2011-09-02 18:41:20 --> Total execution time: 0.2285
DEBUG - 2011-09-02 18:41:24 --> Config Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:41:24 --> URI Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Router Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Output Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Input Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:41:24 --> Language Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Loader Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Controller Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:41:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:41:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:41:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:41:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:41:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:41:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:41:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:41:24 --> Final output sent to browser
DEBUG - 2011-09-02 18:41:24 --> Total execution time: 0.0743
DEBUG - 2011-09-02 18:41:37 --> Config Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:41:37 --> URI Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Router Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Output Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Input Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:41:37 --> Language Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Loader Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Controller Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Model Class Initialized
DEBUG - 2011-09-02 18:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:41:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:41:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 18:41:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:41:37 --> Final output sent to browser
DEBUG - 2011-09-02 18:41:37 --> Total execution time: 0.0521
DEBUG - 2011-09-02 18:42:23 --> Config Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:42:23 --> URI Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Router Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Output Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Input Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:42:23 --> Language Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Loader Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Controller Class Initialized
ERROR - 2011-09-02 18:42:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 18:42:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:42:23 --> Model Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Model Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:42:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 18:42:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:42:23 --> Final output sent to browser
DEBUG - 2011-09-02 18:42:23 --> Total execution time: 0.0281
DEBUG - 2011-09-02 18:42:23 --> Config Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:42:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:42:23 --> URI Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Router Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Output Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Input Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:42:23 --> Language Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Loader Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Controller Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Model Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Model Class Initialized
DEBUG - 2011-09-02 18:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 18:42:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 18:42:24 --> Final output sent to browser
DEBUG - 2011-09-02 18:42:24 --> Total execution time: 0.6482
DEBUG - 2011-09-02 18:52:38 --> Config Class Initialized
DEBUG - 2011-09-02 18:52:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:52:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:52:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:52:38 --> URI Class Initialized
DEBUG - 2011-09-02 18:52:38 --> Router Class Initialized
ERROR - 2011-09-02 18:52:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 18:52:39 --> Config Class Initialized
DEBUG - 2011-09-02 18:52:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:52:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:52:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:52:39 --> URI Class Initialized
DEBUG - 2011-09-02 18:52:39 --> Router Class Initialized
ERROR - 2011-09-02 18:52:39 --> 404 Page Not Found --> sitemap.xml
DEBUG - 2011-09-02 18:52:40 --> Config Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 18:52:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 18:52:40 --> URI Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Router Class Initialized
DEBUG - 2011-09-02 18:52:40 --> No URI present. Default controller set.
DEBUG - 2011-09-02 18:52:40 --> Output Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Input Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 18:52:40 --> Language Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Loader Class Initialized
DEBUG - 2011-09-02 18:52:40 --> Controller Class Initialized
DEBUG - 2011-09-02 18:52:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 18:52:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 18:52:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 18:52:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 18:52:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 18:52:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 18:52:40 --> Final output sent to browser
DEBUG - 2011-09-02 18:52:40 --> Total execution time: 0.0122
DEBUG - 2011-09-02 19:00:42 --> Config Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:00:42 --> URI Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Router Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Output Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Input Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:00:42 --> Language Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Loader Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Controller Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:00:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:00:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:00:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:00:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:00:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:00:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:00:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:00:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:00:42 --> Final output sent to browser
DEBUG - 2011-09-02 19:00:42 --> Total execution time: 0.0776
DEBUG - 2011-09-02 19:00:44 --> Config Class Initialized
DEBUG - 2011-09-02 19:00:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:00:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:00:44 --> URI Class Initialized
DEBUG - 2011-09-02 19:00:44 --> Router Class Initialized
ERROR - 2011-09-02 19:00:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:00:59 --> Config Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:00:59 --> URI Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Router Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Output Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Input Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:00:59 --> Language Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Loader Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Controller Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Model Class Initialized
DEBUG - 2011-09-02 19:00:59 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:00 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:01:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:01:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:01:01 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:01:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:01:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:01:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:01:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:01:01 --> Final output sent to browser
DEBUG - 2011-09-02 19:01:01 --> Total execution time: 1.0774
DEBUG - 2011-09-02 19:01:02 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:02 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:02 --> Router Class Initialized
ERROR - 2011-09-02 19:01:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:01:31 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:31 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Router Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Output Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Input Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:01:31 --> Language Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Loader Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Controller Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:01:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:01:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:01:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:01:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:01:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:01:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:01:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:01:31 --> Final output sent to browser
DEBUG - 2011-09-02 19:01:31 --> Total execution time: 0.1473
DEBUG - 2011-09-02 19:01:32 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:32 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Router Class Initialized
ERROR - 2011-09-02 19:01:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:01:32 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:32 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Router Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Output Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Input Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:01:32 --> Language Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Loader Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Controller Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:01:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:01:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:01:32 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:01:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:01:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:01:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:01:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:01:32 --> Final output sent to browser
DEBUG - 2011-09-02 19:01:32 --> Total execution time: 0.0431
DEBUG - 2011-09-02 19:01:40 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:40 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Router Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Output Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Input Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:01:40 --> Language Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Loader Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Controller Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Model Class Initialized
DEBUG - 2011-09-02 19:01:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:01:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:01:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:01:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:01:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:01:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:01:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:01:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:01:41 --> Final output sent to browser
DEBUG - 2011-09-02 19:01:41 --> Total execution time: 0.2749
DEBUG - 2011-09-02 19:01:42 --> Config Class Initialized
DEBUG - 2011-09-02 19:01:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:01:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:01:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:01:42 --> URI Class Initialized
DEBUG - 2011-09-02 19:01:42 --> Router Class Initialized
ERROR - 2011-09-02 19:01:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:02:05 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:05 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Router Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Output Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Input Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:02:05 --> Language Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Loader Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Controller Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:02:05 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:02:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:02:05 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:02:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:02:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:02:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:02:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:02:05 --> Final output sent to browser
DEBUG - 2011-09-02 19:02:05 --> Total execution time: 0.4560
DEBUG - 2011-09-02 19:02:07 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:07 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:07 --> Router Class Initialized
ERROR - 2011-09-02 19:02:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:02:27 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:27 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Router Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Output Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Input Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:02:27 --> Language Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Loader Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Controller Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:02:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:02:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:02:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:02:27 --> Final output sent to browser
DEBUG - 2011-09-02 19:02:27 --> Total execution time: 0.0558
DEBUG - 2011-09-02 19:02:29 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:29 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:29 --> Router Class Initialized
ERROR - 2011-09-02 19:02:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:02:47 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:47 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Router Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Output Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Input Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:02:47 --> Language Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Loader Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Controller Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Model Class Initialized
DEBUG - 2011-09-02 19:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:02:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:02:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:02:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:02:48 --> Final output sent to browser
DEBUG - 2011-09-02 19:02:48 --> Total execution time: 0.3456
DEBUG - 2011-09-02 19:02:49 --> Config Class Initialized
DEBUG - 2011-09-02 19:02:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:02:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:02:49 --> URI Class Initialized
DEBUG - 2011-09-02 19:02:49 --> Router Class Initialized
ERROR - 2011-09-02 19:02:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:03:39 --> Config Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:03:39 --> URI Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Router Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Output Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Input Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:03:39 --> Language Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Loader Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Controller Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Model Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Model Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Model Class Initialized
DEBUG - 2011-09-02 19:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:03:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:03:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:03:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:03:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:03:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:03:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:03:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:03:42 --> Final output sent to browser
DEBUG - 2011-09-02 19:03:42 --> Total execution time: 3.0742
DEBUG - 2011-09-02 19:03:44 --> Config Class Initialized
DEBUG - 2011-09-02 19:03:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:03:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:03:44 --> URI Class Initialized
DEBUG - 2011-09-02 19:03:44 --> Router Class Initialized
ERROR - 2011-09-02 19:03:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:04:21 --> Config Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:04:21 --> URI Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Router Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Output Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Input Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:04:21 --> Language Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Loader Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Controller Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:04:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:04:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:04:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:04:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:04:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:04:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:04:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:04:21 --> Final output sent to browser
DEBUG - 2011-09-02 19:04:21 --> Total execution time: 0.3929
DEBUG - 2011-09-02 19:04:22 --> Config Class Initialized
DEBUG - 2011-09-02 19:04:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:04:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:04:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:04:22 --> URI Class Initialized
DEBUG - 2011-09-02 19:04:22 --> Router Class Initialized
ERROR - 2011-09-02 19:04:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:04:42 --> Config Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:04:42 --> URI Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Router Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Output Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Input Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:04:42 --> Language Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Loader Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Controller Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:04:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:04:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:04:42 --> Final output sent to browser
DEBUG - 2011-09-02 19:04:42 --> Total execution time: 0.2152
DEBUG - 2011-09-02 19:04:44 --> Config Class Initialized
DEBUG - 2011-09-02 19:04:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:04:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:04:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:04:44 --> URI Class Initialized
DEBUG - 2011-09-02 19:04:44 --> Router Class Initialized
ERROR - 2011-09-02 19:04:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:05:03 --> Config Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:05:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:05:03 --> URI Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Router Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Output Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Input Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:05:03 --> Language Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Loader Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Controller Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:05:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:05:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:05:04 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:05:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:05:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:05:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:05:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:05:04 --> Final output sent to browser
DEBUG - 2011-09-02 19:05:04 --> Total execution time: 0.2804
DEBUG - 2011-09-02 19:05:05 --> Config Class Initialized
DEBUG - 2011-09-02 19:05:05 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:05:05 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:05:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:05:05 --> URI Class Initialized
DEBUG - 2011-09-02 19:05:05 --> Router Class Initialized
ERROR - 2011-09-02 19:05:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:05:23 --> Config Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:05:23 --> URI Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Router Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Output Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Input Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:05:23 --> Language Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Loader Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Controller Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:05:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:05:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:05:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:05:24 --> Final output sent to browser
DEBUG - 2011-09-02 19:05:24 --> Total execution time: 0.3814
DEBUG - 2011-09-02 19:05:25 --> Config Class Initialized
DEBUG - 2011-09-02 19:05:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:05:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:05:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:05:25 --> URI Class Initialized
DEBUG - 2011-09-02 19:05:25 --> Router Class Initialized
ERROR - 2011-09-02 19:05:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:05:50 --> Config Class Initialized
DEBUG - 2011-09-02 19:05:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:05:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:05:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:05:50 --> URI Class Initialized
DEBUG - 2011-09-02 19:05:50 --> Router Class Initialized
ERROR - 2011-09-02 19:05:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:06:02 --> Config Class Initialized
DEBUG - 2011-09-02 19:06:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:06:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:06:02 --> URI Class Initialized
DEBUG - 2011-09-02 19:06:02 --> Router Class Initialized
ERROR - 2011-09-02 19:06:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:08:10 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:10 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:10 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Controller Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:08:11 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:08:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:08:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:08:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:08:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:08:11 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:11 --> Total execution time: 0.1663
DEBUG - 2011-09-02 19:08:25 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:25 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Router Class Initialized
ERROR - 2011-09-02 19:08:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:08:25 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:25 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:25 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Controller Class Initialized
ERROR - 2011-09-02 19:08:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:08:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:08:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:08:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:08:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:08:25 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:25 --> Total execution time: 0.0286
DEBUG - 2011-09-02 19:08:26 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:26 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Router Class Initialized
ERROR - 2011-09-02 19:08:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:08:26 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:26 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:26 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Controller Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:26 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:26 --> Total execution time: 0.6117
DEBUG - 2011-09-02 19:08:41 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:41 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:41 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Controller Class Initialized
ERROR - 2011-09-02 19:08:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:08:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:08:41 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:08:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:08:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:08:41 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:41 --> Total execution time: 0.0612
DEBUG - 2011-09-02 19:08:42 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:42 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:42 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Controller Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:43 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:43 --> Total execution time: 0.6785
DEBUG - 2011-09-02 19:08:53 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:53 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Router Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Output Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Input Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:08:53 --> Language Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Loader Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Controller Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:08:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:08:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:08:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:08:54 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:08:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:08:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:08:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:08:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:08:54 --> Final output sent to browser
DEBUG - 2011-09-02 19:08:54 --> Total execution time: 0.2187
DEBUG - 2011-09-02 19:08:54 --> Config Class Initialized
DEBUG - 2011-09-02 19:08:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:08:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:08:54 --> URI Class Initialized
DEBUG - 2011-09-02 19:08:54 --> Router Class Initialized
ERROR - 2011-09-02 19:08:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:09:06 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:06 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Router Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Output Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Input Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:09:06 --> Language Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Loader Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Controller Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:09:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:09:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:09:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:09:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:09:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:09:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:09:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:09:06 --> Final output sent to browser
DEBUG - 2011-09-02 19:09:06 --> Total execution time: 0.2585
DEBUG - 2011-09-02 19:09:07 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:07 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:07 --> Router Class Initialized
ERROR - 2011-09-02 19:09:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:09:31 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:31 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Router Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Output Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Input Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:09:31 --> Language Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Loader Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Controller Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:09:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:09:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:09:31 --> Final output sent to browser
DEBUG - 2011-09-02 19:09:31 --> Total execution time: 0.2288
DEBUG - 2011-09-02 19:09:32 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:32 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:32 --> Router Class Initialized
ERROR - 2011-09-02 19:09:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:09:52 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:52 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Router Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Output Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Input Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:09:52 --> Language Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Loader Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Controller Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:09:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:09:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:09:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:09:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:09:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:09:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:09:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:09:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:09:52 --> Final output sent to browser
DEBUG - 2011-09-02 19:09:52 --> Total execution time: 0.1964
DEBUG - 2011-09-02 19:09:54 --> Config Class Initialized
DEBUG - 2011-09-02 19:09:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:09:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:09:54 --> URI Class Initialized
DEBUG - 2011-09-02 19:09:54 --> Router Class Initialized
ERROR - 2011-09-02 19:09:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:10:24 --> Config Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:10:24 --> URI Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Router Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Output Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Input Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:10:24 --> Language Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Loader Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Controller Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:10:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:10:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:10:24 --> Final output sent to browser
DEBUG - 2011-09-02 19:10:24 --> Total execution time: 0.2148
DEBUG - 2011-09-02 19:10:26 --> Config Class Initialized
DEBUG - 2011-09-02 19:10:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:10:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:10:26 --> URI Class Initialized
DEBUG - 2011-09-02 19:10:26 --> Router Class Initialized
ERROR - 2011-09-02 19:10:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:10:51 --> Config Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:10:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:10:51 --> URI Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Router Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Output Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Input Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:10:51 --> Language Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Loader Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Controller Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Model Class Initialized
DEBUG - 2011-09-02 19:10:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:10:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:10:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:10:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:10:52 --> Final output sent to browser
DEBUG - 2011-09-02 19:10:52 --> Total execution time: 0.2383
DEBUG - 2011-09-02 19:10:53 --> Config Class Initialized
DEBUG - 2011-09-02 19:10:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:10:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:10:53 --> URI Class Initialized
DEBUG - 2011-09-02 19:10:53 --> Router Class Initialized
ERROR - 2011-09-02 19:10:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:11:14 --> Config Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:11:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:11:14 --> URI Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Router Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Output Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Input Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:11:14 --> Language Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Loader Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Controller Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Model Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Model Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Model Class Initialized
DEBUG - 2011-09-02 19:11:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:11:14 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:11:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:11:14 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:11:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:11:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:11:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:11:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:11:14 --> Final output sent to browser
DEBUG - 2011-09-02 19:11:14 --> Total execution time: 0.0465
DEBUG - 2011-09-02 19:11:15 --> Config Class Initialized
DEBUG - 2011-09-02 19:11:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:11:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:11:15 --> URI Class Initialized
DEBUG - 2011-09-02 19:11:15 --> Router Class Initialized
ERROR - 2011-09-02 19:11:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:12:31 --> Config Class Initialized
DEBUG - 2011-09-02 19:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:12:31 --> URI Class Initialized
DEBUG - 2011-09-02 19:12:31 --> Router Class Initialized
ERROR - 2011-09-02 19:12:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:12:34 --> Config Class Initialized
DEBUG - 2011-09-02 19:12:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:12:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:12:34 --> URI Class Initialized
DEBUG - 2011-09-02 19:12:34 --> Router Class Initialized
ERROR - 2011-09-02 19:12:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:12:38 --> Config Class Initialized
DEBUG - 2011-09-02 19:12:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:12:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:12:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:12:38 --> URI Class Initialized
DEBUG - 2011-09-02 19:12:38 --> Router Class Initialized
ERROR - 2011-09-02 19:12:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:12:41 --> Config Class Initialized
DEBUG - 2011-09-02 19:12:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:12:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:12:41 --> URI Class Initialized
DEBUG - 2011-09-02 19:12:41 --> Router Class Initialized
ERROR - 2011-09-02 19:12:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:12:59 --> Config Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:12:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:12:59 --> URI Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Router Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Output Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Input Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:12:59 --> Language Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Loader Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Controller Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Model Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Model Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Model Class Initialized
DEBUG - 2011-09-02 19:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:12:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:12:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:12:59 --> Final output sent to browser
DEBUG - 2011-09-02 19:12:59 --> Total execution time: 0.0850
DEBUG - 2011-09-02 19:13:20 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:20 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Router Class Initialized
ERROR - 2011-09-02 19:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:20 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:20 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Router Class Initialized
ERROR - 2011-09-02 19:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:20 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:20 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:20 --> Router Class Initialized
ERROR - 2011-09-02 19:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:21 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:21 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Router Class Initialized
ERROR - 2011-09-02 19:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:21 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:21 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Router Class Initialized
ERROR - 2011-09-02 19:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:21 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:21 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:21 --> Router Class Initialized
ERROR - 2011-09-02 19:13:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:25 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:25 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Router Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Output Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Input Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:13:25 --> Language Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Loader Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Controller Class Initialized
ERROR - 2011-09-02 19:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:13:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:13:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:13:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:13:25 --> Final output sent to browser
DEBUG - 2011-09-02 19:13:25 --> Total execution time: 0.0338
DEBUG - 2011-09-02 19:13:26 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:26 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Router Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Output Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Input Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:13:26 --> Language Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Loader Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Controller Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:13:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:13:26 --> Final output sent to browser
DEBUG - 2011-09-02 19:13:26 --> Total execution time: 0.4949
DEBUG - 2011-09-02 19:13:27 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:27 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:27 --> Router Class Initialized
ERROR - 2011-09-02 19:13:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:13:37 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:37 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Router Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Output Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Input Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:13:37 --> Language Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Loader Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Controller Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:13:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:13:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:13:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:13:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:13:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:13:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:13:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:13:37 --> Final output sent to browser
DEBUG - 2011-09-02 19:13:37 --> Total execution time: 0.0511
DEBUG - 2011-09-02 19:13:43 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:43 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Router Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Output Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Input Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:13:43 --> Language Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Loader Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Controller Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:13:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:13:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:13:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:13:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:13:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:13:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:13:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:13:43 --> Final output sent to browser
DEBUG - 2011-09-02 19:13:43 --> Total execution time: 0.0474
DEBUG - 2011-09-02 19:13:56 --> Config Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:13:56 --> URI Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Router Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Output Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Input Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:13:56 --> Language Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Loader Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Controller Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Model Class Initialized
DEBUG - 2011-09-02 19:13:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:13:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:13:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:13:57 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:13:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:13:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:13:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:13:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:13:57 --> Final output sent to browser
DEBUG - 2011-09-02 19:13:57 --> Total execution time: 0.3020
DEBUG - 2011-09-02 19:14:13 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:13 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:13 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Controller Class Initialized
ERROR - 2011-09-02 19:14:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:14:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:14:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:13 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:13 --> Total execution time: 0.0302
DEBUG - 2011-09-02 19:14:13 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:13 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:13 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:13 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:13 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:13 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:13 --> Total execution time: 0.2355
DEBUG - 2011-09-02 19:14:14 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:14 --> Total execution time: 0.5143
DEBUG - 2011-09-02 19:14:15 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:15 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:15 --> Router Class Initialized
ERROR - 2011-09-02 19:14:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:14:22 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:22 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:22 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:22 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:22 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:22 --> Total execution time: 0.0459
DEBUG - 2011-09-02 19:14:23 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:23 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:23 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:23 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:23 --> Total execution time: 0.0439
DEBUG - 2011-09-02 19:14:33 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:33 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:33 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:33 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:33 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:33 --> Total execution time: 0.2629
DEBUG - 2011-09-02 19:14:34 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:34 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:34 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:34 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:34 --> Total execution time: 0.0461
DEBUG - 2011-09-02 19:14:52 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:52 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:52 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:52 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:52 --> Total execution time: 0.2031
DEBUG - 2011-09-02 19:14:53 --> Config Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:14:53 --> URI Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Router Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Output Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Input Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:14:53 --> Language Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Loader Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Controller Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:14:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:14:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:14:53 --> Final output sent to browser
DEBUG - 2011-09-02 19:14:53 --> Total execution time: 0.0506
DEBUG - 2011-09-02 19:15:07 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:07 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:07 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:07 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:15:08 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:08 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:08 --> Total execution time: 1.3670
DEBUG - 2011-09-02 19:15:09 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:09 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:09 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:15:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:09 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:09 --> Total execution time: 0.1111
DEBUG - 2011-09-02 19:15:09 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:09 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:09 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:15:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:09 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:09 --> Total execution time: 0.0565
DEBUG - 2011-09-02 19:15:24 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:24 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:24 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Controller Class Initialized
ERROR - 2011-09-02 19:15:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:15:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:24 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:24 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:24 --> Total execution time: 0.0292
DEBUG - 2011-09-02 19:15:25 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:25 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:25 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:26 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:26 --> Total execution time: 0.6275
DEBUG - 2011-09-02 19:15:27 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:27 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:27 --> Router Class Initialized
ERROR - 2011-09-02 19:15:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:15:35 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:35 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:35 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:15:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:35 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:35 --> Total execution time: 0.0550
DEBUG - 2011-09-02 19:15:42 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:42 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:42 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Controller Class Initialized
ERROR - 2011-09-02 19:15:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:15:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:42 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:42 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:42 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:42 --> Total execution time: 0.0325
DEBUG - 2011-09-02 19:15:43 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:43 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:43 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:43 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:43 --> Total execution time: 0.5008
DEBUG - 2011-09-02 19:15:53 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:53 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:53 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Controller Class Initialized
ERROR - 2011-09-02 19:15:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:15:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:53 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:53 --> Total execution time: 0.0344
DEBUG - 2011-09-02 19:15:53 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:53 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:53 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Controller Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:54 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:54 --> Total execution time: 0.6402
DEBUG - 2011-09-02 19:15:55 --> Config Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:15:55 --> URI Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Router Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Output Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Input Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:15:55 --> Language Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Loader Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Controller Class Initialized
ERROR - 2011-09-02 19:15:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:55 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Model Class Initialized
DEBUG - 2011-09-02 19:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:15:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:15:55 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:15:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:15:55 --> Final output sent to browser
DEBUG - 2011-09-02 19:15:55 --> Total execution time: 0.0275
DEBUG - 2011-09-02 19:16:28 --> Config Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:16:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:16:28 --> URI Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Router Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Output Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Input Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:16:28 --> Language Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Loader Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Controller Class Initialized
ERROR - 2011-09-02 19:16:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:16:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:16:28 --> Model Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Model Class Initialized
DEBUG - 2011-09-02 19:16:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:16:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:16:28 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:16:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:16:28 --> Final output sent to browser
DEBUG - 2011-09-02 19:16:28 --> Total execution time: 0.0266
DEBUG - 2011-09-02 19:16:29 --> Config Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:16:29 --> URI Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Router Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Output Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Input Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:16:29 --> Language Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Loader Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Controller Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Model Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Model Class Initialized
DEBUG - 2011-09-02 19:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:16:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:16:30 --> Final output sent to browser
DEBUG - 2011-09-02 19:16:30 --> Total execution time: 0.5011
DEBUG - 2011-09-02 19:16:31 --> Config Class Initialized
DEBUG - 2011-09-02 19:16:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:16:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:16:31 --> URI Class Initialized
DEBUG - 2011-09-02 19:16:31 --> Router Class Initialized
ERROR - 2011-09-02 19:16:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:17:28 --> Config Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:17:28 --> URI Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Router Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Output Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Input Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:17:28 --> Language Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Loader Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Controller Class Initialized
ERROR - 2011-09-02 19:17:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 19:17:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:17:28 --> Model Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Model Class Initialized
DEBUG - 2011-09-02 19:17:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:17:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 19:17:28 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:17:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:17:28 --> Final output sent to browser
DEBUG - 2011-09-02 19:17:28 --> Total execution time: 0.0325
DEBUG - 2011-09-02 19:17:29 --> Config Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:17:29 --> URI Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Router Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Output Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Input Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:17:29 --> Language Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Loader Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Controller Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Model Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Model Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:17:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:17:29 --> Final output sent to browser
DEBUG - 2011-09-02 19:17:29 --> Total execution time: 0.5033
DEBUG - 2011-09-02 19:17:30 --> Config Class Initialized
DEBUG - 2011-09-02 19:17:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:17:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:17:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:17:30 --> URI Class Initialized
DEBUG - 2011-09-02 19:17:30 --> Router Class Initialized
ERROR - 2011-09-02 19:17:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:19:48 --> Config Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:19:48 --> URI Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Router Class Initialized
DEBUG - 2011-09-02 19:19:48 --> No URI present. Default controller set.
DEBUG - 2011-09-02 19:19:48 --> Output Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Input Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:19:48 --> Language Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Loader Class Initialized
DEBUG - 2011-09-02 19:19:48 --> Controller Class Initialized
DEBUG - 2011-09-02 19:19:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 19:19:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:19:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:19:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:19:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:19:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:19:48 --> Final output sent to browser
DEBUG - 2011-09-02 19:19:48 --> Total execution time: 0.0136
DEBUG - 2011-09-02 19:22:15 --> Config Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:22:15 --> URI Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Router Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Output Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Input Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 19:22:15 --> Language Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Loader Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Controller Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Model Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Model Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Model Class Initialized
DEBUG - 2011-09-02 19:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 19:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 19:22:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 19:22:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 19:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 19:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 19:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 19:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 19:22:15 --> Final output sent to browser
DEBUG - 2011-09-02 19:22:15 --> Total execution time: 0.0485
DEBUG - 2011-09-02 19:22:18 --> Config Class Initialized
DEBUG - 2011-09-02 19:22:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:22:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:22:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:22:18 --> URI Class Initialized
DEBUG - 2011-09-02 19:22:18 --> Router Class Initialized
ERROR - 2011-09-02 19:22:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 19:22:19 --> Config Class Initialized
DEBUG - 2011-09-02 19:22:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 19:22:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 19:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 19:22:19 --> URI Class Initialized
DEBUG - 2011-09-02 19:22:19 --> Router Class Initialized
ERROR - 2011-09-02 19:22:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:12:55 --> Config Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:12:55 --> URI Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Router Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Output Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Input Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:12:55 --> Language Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Loader Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Controller Class Initialized
ERROR - 2011-09-02 20:12:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 20:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:12:55 --> Model Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Model Class Initialized
DEBUG - 2011-09-02 20:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:12:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:12:55 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:12:55 --> Final output sent to browser
DEBUG - 2011-09-02 20:12:55 --> Total execution time: 0.1194
DEBUG - 2011-09-02 20:22:12 --> Config Class Initialized
DEBUG - 2011-09-02 20:22:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:22:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:22:12 --> URI Class Initialized
DEBUG - 2011-09-02 20:22:12 --> Router Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Output Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Input Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:22:13 --> Language Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Loader Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Controller Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:22:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:22:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:22:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:22:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:22:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:22:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:22:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:22:13 --> Final output sent to browser
DEBUG - 2011-09-02 20:22:13 --> Total execution time: 0.2659
DEBUG - 2011-09-02 20:22:14 --> Config Class Initialized
DEBUG - 2011-09-02 20:22:14 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:22:14 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:22:14 --> URI Class Initialized
DEBUG - 2011-09-02 20:22:14 --> Router Class Initialized
ERROR - 2011-09-02 20:22:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:22:41 --> Config Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:22:41 --> URI Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Router Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Output Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Input Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:22:41 --> Language Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Loader Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Controller Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:22:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:22:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:22:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:22:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:22:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:22:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:22:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:22:41 --> Final output sent to browser
DEBUG - 2011-09-02 20:22:41 --> Total execution time: 0.2894
DEBUG - 2011-09-02 20:22:54 --> Config Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:22:54 --> URI Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Router Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Output Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Input Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:22:54 --> Language Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Loader Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Controller Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:22:54 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:22:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:22:55 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:22:55 --> Final output sent to browser
DEBUG - 2011-09-02 20:22:55 --> Total execution time: 0.4305
DEBUG - 2011-09-02 20:23:18 --> Config Class Initialized
DEBUG - 2011-09-02 20:23:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:23:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:23:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:23:18 --> URI Class Initialized
DEBUG - 2011-09-02 20:23:18 --> Router Class Initialized
DEBUG - 2011-09-02 20:23:18 --> Output Class Initialized
DEBUG - 2011-09-02 20:23:18 --> Input Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:23:19 --> Language Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Loader Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Controller Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:23:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:23:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:23:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:23:19 --> Final output sent to browser
DEBUG - 2011-09-02 20:23:19 --> Total execution time: 0.2725
DEBUG - 2011-09-02 20:23:55 --> Config Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:23:55 --> URI Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Router Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Output Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Input Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:23:55 --> Language Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Loader Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Controller Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Model Class Initialized
DEBUG - 2011-09-02 20:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:23:55 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:23:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:23:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:23:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:23:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:23:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:23:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:23:56 --> Final output sent to browser
DEBUG - 2011-09-02 20:23:56 --> Total execution time: 0.3837
DEBUG - 2011-09-02 20:24:26 --> Config Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:24:26 --> URI Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Router Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Output Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Input Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:24:26 --> Language Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Loader Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Controller Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:24:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:24:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:24:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:24:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:24:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:24:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:24:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:24:26 --> Final output sent to browser
DEBUG - 2011-09-02 20:24:26 --> Total execution time: 0.2219
DEBUG - 2011-09-02 20:24:47 --> Config Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:24:47 --> URI Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Router Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Output Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Input Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:24:47 --> Language Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Loader Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Controller Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:24:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:24:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:24:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:24:48 --> Final output sent to browser
DEBUG - 2011-09-02 20:24:48 --> Total execution time: 0.3476
DEBUG - 2011-09-02 20:25:00 --> Config Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:25:00 --> URI Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Router Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Output Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Input Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:25:00 --> Language Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Loader Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Controller Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:25:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:25:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:25:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:25:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:25:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:25:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:25:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:25:00 --> Final output sent to browser
DEBUG - 2011-09-02 20:25:00 --> Total execution time: 0.5103
DEBUG - 2011-09-02 20:25:28 --> Config Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:25:28 --> URI Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Router Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Output Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Input Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:25:28 --> Language Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Loader Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Controller Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Model Class Initialized
DEBUG - 2011-09-02 20:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:25:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:25:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:25:28 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:25:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:25:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:25:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:25:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:25:28 --> Final output sent to browser
DEBUG - 2011-09-02 20:25:28 --> Total execution time: 0.3029
DEBUG - 2011-09-02 20:26:03 --> Config Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:26:03 --> URI Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Router Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Output Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Input Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:26:03 --> Language Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Loader Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Controller Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:26:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:26:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:26:03 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:26:03 --> Final output sent to browser
DEBUG - 2011-09-02 20:26:03 --> Total execution time: 0.2741
DEBUG - 2011-09-02 20:26:30 --> Config Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:26:30 --> URI Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Router Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Output Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Input Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:26:30 --> Language Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Loader Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Controller Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:26:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:26:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:26:30 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:26:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:26:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:26:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:26:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:26:30 --> Final output sent to browser
DEBUG - 2011-09-02 20:26:30 --> Total execution time: 0.1987
DEBUG - 2011-09-02 20:26:48 --> Config Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:26:48 --> URI Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Router Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Output Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Input Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:26:48 --> Language Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Loader Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Controller Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:26:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:26:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:26:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:26:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:26:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:26:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:26:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:26:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:26:48 --> Final output sent to browser
DEBUG - 2011-09-02 20:26:48 --> Total execution time: 0.2924
DEBUG - 2011-09-02 20:27:12 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:12 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:12 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:13 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:13 --> Total execution time: 0.3802
DEBUG - 2011-09-02 20:27:24 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:24 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:24 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:25 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:25 --> Total execution time: 0.2675
DEBUG - 2011-09-02 20:27:36 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:36 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:36 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:36 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:36 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:36 --> Total execution time: 0.3127
DEBUG - 2011-09-02 20:27:43 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:43 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:43 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:43 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:43 --> Total execution time: 0.2279
DEBUG - 2011-09-02 20:27:52 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:52 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:52 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:53 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:53 --> Total execution time: 0.2987
DEBUG - 2011-09-02 20:27:59 --> Config Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:27:59 --> URI Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Router Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Output Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Input Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:27:59 --> Language Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Loader Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Controller Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:27:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:27:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:27:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:27:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:27:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:27:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:27:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:27:59 --> Final output sent to browser
DEBUG - 2011-09-02 20:27:59 --> Total execution time: 0.2765
DEBUG - 2011-09-02 20:37:31 --> Config Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:37:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:37:31 --> URI Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Router Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Output Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Input Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:37:31 --> Language Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Loader Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Controller Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Model Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Model Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Model Class Initialized
DEBUG - 2011-09-02 20:37:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:37:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:37:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:37:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:37:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:37:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:37:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:37:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:37:31 --> Final output sent to browser
DEBUG - 2011-09-02 20:37:31 --> Total execution time: 0.0479
DEBUG - 2011-09-02 20:39:50 --> Config Class Initialized
DEBUG - 2011-09-02 20:39:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:39:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:39:50 --> URI Class Initialized
DEBUG - 2011-09-02 20:39:50 --> Router Class Initialized
ERROR - 2011-09-02 20:39:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:41:09 --> Config Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:41:09 --> URI Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Router Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Output Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Input Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:41:09 --> Language Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Loader Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Controller Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:41:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:41:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:41:09 --> Final output sent to browser
DEBUG - 2011-09-02 20:41:09 --> Total execution time: 0.0489
DEBUG - 2011-09-02 20:41:26 --> Config Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:41:26 --> URI Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Router Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Output Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Input Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:41:26 --> Language Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Loader Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Controller Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:41:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:41:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:41:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:41:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:41:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:41:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:41:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:41:26 --> Final output sent to browser
DEBUG - 2011-09-02 20:41:26 --> Total execution time: 0.1759
DEBUG - 2011-09-02 20:41:43 --> Config Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:41:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:41:43 --> URI Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Router Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Output Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Input Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:41:43 --> Language Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Loader Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Controller Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Model Class Initialized
DEBUG - 2011-09-02 20:41:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:41:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:41:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:41:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:41:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:41:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:41:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:41:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:41:43 --> Final output sent to browser
DEBUG - 2011-09-02 20:41:43 --> Total execution time: 0.0977
DEBUG - 2011-09-02 20:42:41 --> Config Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:42:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:42:41 --> URI Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Router Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Output Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Input Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:42:41 --> Language Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Loader Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Controller Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:42:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:42:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:42:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:42:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:42:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:42:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:42:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:42:41 --> Final output sent to browser
DEBUG - 2011-09-02 20:42:41 --> Total execution time: 0.1053
DEBUG - 2011-09-02 20:42:53 --> Config Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:42:53 --> URI Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Router Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Output Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Input Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:42:53 --> Language Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Loader Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Controller Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Model Class Initialized
DEBUG - 2011-09-02 20:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:42:53 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:42:53 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:42:53 --> Final output sent to browser
DEBUG - 2011-09-02 20:42:53 --> Total execution time: 0.0524
DEBUG - 2011-09-02 20:43:13 --> Config Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:43:13 --> URI Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Router Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Output Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Input Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:43:13 --> Language Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Loader Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Controller Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:43:13 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:43:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:43:13 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:43:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:43:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:43:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:43:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:43:13 --> Final output sent to browser
DEBUG - 2011-09-02 20:43:13 --> Total execution time: 0.0980
DEBUG - 2011-09-02 20:43:25 --> Config Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:43:25 --> URI Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Router Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Output Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Input Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:43:25 --> Language Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Loader Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Controller Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:43:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:43:25 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:43:25 --> Final output sent to browser
DEBUG - 2011-09-02 20:43:25 --> Total execution time: 0.0490
DEBUG - 2011-09-02 20:43:37 --> Config Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:43:37 --> URI Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Router Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Output Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Input Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:43:37 --> Language Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Loader Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Controller Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:43:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:43:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:43:37 --> Final output sent to browser
DEBUG - 2011-09-02 20:43:37 --> Total execution time: 0.1700
DEBUG - 2011-09-02 20:43:48 --> Config Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:43:48 --> URI Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Router Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Output Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Input Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:43:48 --> Language Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Loader Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Controller Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:43:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:43:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:43:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:43:48 --> Final output sent to browser
DEBUG - 2011-09-02 20:43:48 --> Total execution time: 0.0469
DEBUG - 2011-09-02 20:43:59 --> Config Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:43:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:43:59 --> URI Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Router Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Output Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Input Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:43:59 --> Language Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Loader Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Controller Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:43:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:43:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:43:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:43:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:43:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:43:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:43:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:43:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:43:59 --> Final output sent to browser
DEBUG - 2011-09-02 20:43:59 --> Total execution time: 0.0682
DEBUG - 2011-09-02 20:44:09 --> Config Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:44:09 --> URI Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Router Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Output Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Input Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:44:09 --> Language Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Loader Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Controller Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:44:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:44:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:44:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:44:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:44:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:44:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:44:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:44:09 --> Final output sent to browser
DEBUG - 2011-09-02 20:44:09 --> Total execution time: 0.0482
DEBUG - 2011-09-02 20:44:27 --> Config Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:44:27 --> URI Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Router Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Output Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Input Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:44:27 --> Language Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Loader Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Controller Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:44:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:44:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:44:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:44:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:44:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:44:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:44:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:44:27 --> Final output sent to browser
DEBUG - 2011-09-02 20:44:27 --> Total execution time: 0.0462
DEBUG - 2011-09-02 20:44:39 --> Config Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:44:39 --> URI Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Router Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Output Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Input Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:44:39 --> Language Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Loader Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Controller Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:44:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:44:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:44:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:44:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:44:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:44:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:44:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:44:39 --> Final output sent to browser
DEBUG - 2011-09-02 20:44:39 --> Total execution time: 0.0906
DEBUG - 2011-09-02 20:44:49 --> Config Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:44:49 --> URI Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Router Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Output Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Input Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:44:49 --> Language Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Loader Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Controller Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:44:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:44:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:44:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:44:49 --> Final output sent to browser
DEBUG - 2011-09-02 20:44:49 --> Total execution time: 0.0425
DEBUG - 2011-09-02 20:45:06 --> Config Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:45:06 --> URI Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Router Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Output Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Input Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:45:06 --> Language Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Loader Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Controller Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:45:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:45:06 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:45:06 --> Final output sent to browser
DEBUG - 2011-09-02 20:45:06 --> Total execution time: 0.1453
DEBUG - 2011-09-02 20:45:21 --> Config Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:45:21 --> URI Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Router Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Output Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Input Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:45:21 --> Language Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Loader Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Controller Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Model Class Initialized
DEBUG - 2011-09-02 20:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:45:21 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:45:21 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:45:21 --> Final output sent to browser
DEBUG - 2011-09-02 20:45:21 --> Total execution time: 0.0624
DEBUG - 2011-09-02 20:46:15 --> Config Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:46:15 --> URI Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Router Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Output Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Input Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:46:15 --> Language Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Loader Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Controller Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:46:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:46:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:46:15 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:46:15 --> Final output sent to browser
DEBUG - 2011-09-02 20:46:15 --> Total execution time: 0.0417
DEBUG - 2011-09-02 20:46:40 --> Config Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:46:40 --> URI Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Router Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Output Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Input Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:46:40 --> Language Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Loader Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Controller Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:46:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:46:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:46:40 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:46:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:46:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:46:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:46:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:46:40 --> Final output sent to browser
DEBUG - 2011-09-02 20:46:40 --> Total execution time: 0.0676
DEBUG - 2011-09-02 20:46:49 --> Config Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:46:49 --> URI Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Router Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Output Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Input Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:46:49 --> Language Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Loader Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Controller Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Model Class Initialized
DEBUG - 2011-09-02 20:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:46:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:46:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:46:49 --> Final output sent to browser
DEBUG - 2011-09-02 20:46:49 --> Total execution time: 0.1124
DEBUG - 2011-09-02 20:47:23 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:23 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:23 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:23 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:23 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:23 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:23 --> Total execution time: 0.2955
DEBUG - 2011-09-02 20:47:27 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:27 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:27 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:27 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:27 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:27 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:27 --> Total execution time: 0.0445
DEBUG - 2011-09-02 20:47:36 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:36 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:36 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:36 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:37 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:37 --> Total execution time: 0.3066
DEBUG - 2011-09-02 20:47:39 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:39 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:39 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:39 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:39 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:39 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:39 --> Total execution time: 0.0496
DEBUG - 2011-09-02 20:47:51 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:51 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:51 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:51 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:51 --> Total execution time: 0.3496
DEBUG - 2011-09-02 20:47:54 --> Config Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:47:54 --> URI Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Router Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Output Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Input Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:47:54 --> Language Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Loader Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Controller Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 20:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:47:54 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:47:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:47:55 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:47:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:47:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:47:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:47:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:47:55 --> Final output sent to browser
DEBUG - 2011-09-02 20:47:55 --> Total execution time: 0.0524
DEBUG - 2011-09-02 20:48:25 --> Config Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:48:25 --> URI Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Router Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Output Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Input Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:48:25 --> Language Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Loader Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Controller Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:48:25 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:48:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:48:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:48:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:48:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:48:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:48:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:48:26 --> Final output sent to browser
DEBUG - 2011-09-02 20:48:26 --> Total execution time: 0.3541
DEBUG - 2011-09-02 20:48:29 --> Config Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:48:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:48:29 --> URI Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Router Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Output Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Input Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:48:29 --> Language Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Loader Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Controller Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:48:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:48:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:48:29 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:48:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:48:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:48:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:48:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:48:29 --> Final output sent to browser
DEBUG - 2011-09-02 20:48:29 --> Total execution time: 0.0466
DEBUG - 2011-09-02 20:48:44 --> Config Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:48:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:48:44 --> URI Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Router Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Output Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Input Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:48:44 --> Language Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Loader Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Controller Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:48:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:48:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:48:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:48:44 --> Final output sent to browser
DEBUG - 2011-09-02 20:48:44 --> Total execution time: 0.1575
DEBUG - 2011-09-02 20:48:47 --> Config Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:48:47 --> URI Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Router Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Output Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Input Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:48:47 --> Language Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Loader Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Controller Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Model Class Initialized
DEBUG - 2011-09-02 20:48:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:48:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:48:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:48:47 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:48:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:48:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:48:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:48:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:48:47 --> Final output sent to browser
DEBUG - 2011-09-02 20:48:47 --> Total execution time: 0.0417
DEBUG - 2011-09-02 20:49:00 --> Config Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:49:00 --> URI Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Router Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Output Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Input Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:49:00 --> Language Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Loader Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Controller Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:49:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:49:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:49:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:49:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:49:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:49:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:49:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:49:00 --> Final output sent to browser
DEBUG - 2011-09-02 20:49:00 --> Total execution time: 0.2057
DEBUG - 2011-09-02 20:49:03 --> Config Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:49:03 --> URI Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Router Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Output Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Input Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:49:03 --> Language Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Loader Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Controller Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:49:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:49:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:49:03 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:49:03 --> Final output sent to browser
DEBUG - 2011-09-02 20:49:03 --> Total execution time: 0.0421
DEBUG - 2011-09-02 20:49:22 --> Config Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:49:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:49:22 --> URI Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Router Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Output Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Input Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:49:22 --> Language Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Loader Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Controller Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:49:22 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:49:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:49:22 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:49:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:49:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:49:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:49:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:49:22 --> Final output sent to browser
DEBUG - 2011-09-02 20:49:22 --> Total execution time: 0.0489
DEBUG - 2011-09-02 20:49:34 --> Config Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:49:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:49:34 --> URI Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Router Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Output Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Input Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:49:34 --> Language Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Loader Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Controller Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Model Class Initialized
DEBUG - 2011-09-02 20:49:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:49:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:49:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:49:34 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:49:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:49:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:49:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:49:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:49:34 --> Final output sent to browser
DEBUG - 2011-09-02 20:49:34 --> Total execution time: 0.0450
DEBUG - 2011-09-02 20:50:06 --> Config Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:50:06 --> URI Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Router Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Output Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Input Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:50:06 --> Language Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Loader Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Controller Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:50:06 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:50:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:50:07 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:50:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:50:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:50:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:50:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:50:07 --> Final output sent to browser
DEBUG - 2011-09-02 20:50:07 --> Total execution time: 0.3598
DEBUG - 2011-09-02 20:50:09 --> Config Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:50:09 --> URI Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Router Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Output Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Input Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:50:09 --> Language Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Loader Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Controller Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:50:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:50:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:50:09 --> Final output sent to browser
DEBUG - 2011-09-02 20:50:09 --> Total execution time: 0.0680
DEBUG - 2011-09-02 20:50:09 --> Config Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:50:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:50:09 --> URI Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Router Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Output Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Input Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:50:09 --> Language Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Loader Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Controller Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Model Class Initialized
DEBUG - 2011-09-02 20:50:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:50:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 20:50:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:50:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:50:09 --> Final output sent to browser
DEBUG - 2011-09-02 20:50:09 --> Total execution time: 0.0760
DEBUG - 2011-09-02 20:57:44 --> Config Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:57:44 --> URI Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Router Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Output Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Input Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:57:44 --> Language Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Loader Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Controller Class Initialized
ERROR - 2011-09-02 20:57:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 20:57:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:57:44 --> Model Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Model Class Initialized
DEBUG - 2011-09-02 20:57:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:57:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:57:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:57:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:57:44 --> Final output sent to browser
DEBUG - 2011-09-02 20:57:44 --> Total execution time: 0.1148
DEBUG - 2011-09-02 20:57:46 --> Config Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:57:46 --> URI Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Router Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Output Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Input Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:57:46 --> Language Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Loader Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Controller Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Model Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Model Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:57:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:57:46 --> Final output sent to browser
DEBUG - 2011-09-02 20:57:46 --> Total execution time: 0.6544
DEBUG - 2011-09-02 20:57:51 --> Config Class Initialized
DEBUG - 2011-09-02 20:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:57:51 --> URI Class Initialized
DEBUG - 2011-09-02 20:57:51 --> Router Class Initialized
ERROR - 2011-09-02 20:57:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:57:52 --> Config Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:57:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:57:52 --> URI Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Router Class Initialized
ERROR - 2011-09-02 20:57:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:57:52 --> Config Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:57:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:57:52 --> URI Class Initialized
DEBUG - 2011-09-02 20:57:52 --> Router Class Initialized
ERROR - 2011-09-02 20:57:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 20:58:33 --> Config Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:58:33 --> URI Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Router Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Output Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Input Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:58:33 --> Language Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Loader Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Controller Class Initialized
ERROR - 2011-09-02 20:58:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 20:58:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:58:33 --> Model Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Model Class Initialized
DEBUG - 2011-09-02 20:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:58:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:58:33 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:58:33 --> Final output sent to browser
DEBUG - 2011-09-02 20:58:33 --> Total execution time: 0.0326
DEBUG - 2011-09-02 20:58:34 --> Config Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:58:34 --> URI Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Router Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Output Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Input Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:58:34 --> Language Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Loader Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Controller Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Model Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Model Class Initialized
DEBUG - 2011-09-02 20:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:58:34 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:58:35 --> Final output sent to browser
DEBUG - 2011-09-02 20:58:35 --> Total execution time: 0.6287
DEBUG - 2011-09-02 20:59:38 --> Config Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:59:38 --> URI Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Router Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Output Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Input Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:59:38 --> Language Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Loader Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Controller Class Initialized
ERROR - 2011-09-02 20:59:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 20:59:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:59:38 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:59:38 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:59:38 --> Final output sent to browser
DEBUG - 2011-09-02 20:59:38 --> Total execution time: 0.0330
DEBUG - 2011-09-02 20:59:38 --> Config Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:59:38 --> URI Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Router Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Output Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Input Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:59:38 --> Language Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Loader Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Controller Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:59:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:59:39 --> Final output sent to browser
DEBUG - 2011-09-02 20:59:39 --> Total execution time: 1.0688
DEBUG - 2011-09-02 20:59:58 --> Config Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:59:58 --> URI Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Router Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Output Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Input Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:59:58 --> Language Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Loader Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Controller Class Initialized
ERROR - 2011-09-02 20:59:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 20:59:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:59:58 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:59:58 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 20:59:58 --> Helper loaded: url_helper
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 20:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 20:59:58 --> Final output sent to browser
DEBUG - 2011-09-02 20:59:58 --> Total execution time: 0.0311
DEBUG - 2011-09-02 20:59:59 --> Config Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 20:59:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 20:59:59 --> URI Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Router Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Output Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Input Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 20:59:59 --> Language Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Loader Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Controller Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Model Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 20:59:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 20:59:59 --> Final output sent to browser
DEBUG - 2011-09-02 20:59:59 --> Total execution time: 0.5970
DEBUG - 2011-09-02 21:01:03 --> Config Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:01:03 --> URI Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Router Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Output Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Input Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:01:03 --> Language Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Loader Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Controller Class Initialized
ERROR - 2011-09-02 21:01:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:01:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:01:03 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:01:03 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:01:03 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:01:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:01:03 --> Final output sent to browser
DEBUG - 2011-09-02 21:01:03 --> Total execution time: 0.0329
DEBUG - 2011-09-02 21:01:04 --> Config Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:01:04 --> URI Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Router Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Output Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Input Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:01:04 --> Language Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Loader Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Controller Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:01:04 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:01:05 --> Final output sent to browser
DEBUG - 2011-09-02 21:01:05 --> Total execution time: 0.5961
DEBUG - 2011-09-02 21:01:45 --> Config Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:01:45 --> URI Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Router Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Output Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Input Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:01:45 --> Language Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Loader Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Controller Class Initialized
ERROR - 2011-09-02 21:01:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:01:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:01:45 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:01:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:01:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:01:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:01:45 --> Final output sent to browser
DEBUG - 2011-09-02 21:01:45 --> Total execution time: 0.0271
DEBUG - 2011-09-02 21:01:46 --> Config Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:01:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:01:46 --> URI Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Router Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Output Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Input Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:01:46 --> Language Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Loader Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Controller Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Model Class Initialized
DEBUG - 2011-09-02 21:01:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:01:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:01:47 --> Final output sent to browser
DEBUG - 2011-09-02 21:01:47 --> Total execution time: 0.5412
DEBUG - 2011-09-02 21:02:00 --> Config Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:02:00 --> URI Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Router Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Output Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Input Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:02:00 --> Language Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Loader Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Controller Class Initialized
ERROR - 2011-09-02 21:02:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:02:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:02:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:00 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:02:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:02:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:01 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:02:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:02:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:02:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:02:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:02:01 --> Final output sent to browser
DEBUG - 2011-09-02 21:02:01 --> Total execution time: 0.0319
DEBUG - 2011-09-02 21:02:01 --> Config Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:02:01 --> URI Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Router Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Output Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Input Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:02:01 --> Language Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Loader Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Controller Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:02:01 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:02:02 --> Final output sent to browser
DEBUG - 2011-09-02 21:02:02 --> Total execution time: 0.5689
DEBUG - 2011-09-02 21:02:28 --> Config Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:02:28 --> URI Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Router Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Output Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Input Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:02:28 --> Language Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Loader Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Controller Class Initialized
ERROR - 2011-09-02 21:02:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:02:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:28 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:02:28 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:28 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:02:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:02:28 --> Final output sent to browser
DEBUG - 2011-09-02 21:02:28 --> Total execution time: 0.0272
DEBUG - 2011-09-02 21:02:29 --> Config Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:02:29 --> URI Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Router Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Output Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Input Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:02:29 --> Language Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Loader Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Controller Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:02:29 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:02:30 --> Final output sent to browser
DEBUG - 2011-09-02 21:02:30 --> Total execution time: 0.6364
DEBUG - 2011-09-02 21:02:33 --> Config Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:02:33 --> URI Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Router Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Output Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Input Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:02:33 --> Language Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Loader Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Controller Class Initialized
ERROR - 2011-09-02 21:02:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:02:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:33 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Model Class Initialized
DEBUG - 2011-09-02 21:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:02:33 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:02:33 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:02:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:02:33 --> Final output sent to browser
DEBUG - 2011-09-02 21:02:33 --> Total execution time: 0.0350
DEBUG - 2011-09-02 21:03:26 --> Config Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:03:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:03:26 --> URI Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Router Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Output Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Input Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:03:26 --> Language Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Loader Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Controller Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Model Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Model Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Model Class Initialized
DEBUG - 2011-09-02 21:03:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:03:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:03:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 21:03:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:03:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:03:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:03:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:03:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:03:26 --> Final output sent to browser
DEBUG - 2011-09-02 21:03:26 --> Total execution time: 0.0480
DEBUG - 2011-09-02 21:04:01 --> Config Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:04:01 --> URI Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Router Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Output Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Input Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:04:01 --> Language Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Loader Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Controller Class Initialized
ERROR - 2011-09-02 21:04:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:04:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:04:01 --> Model Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Model Class Initialized
DEBUG - 2011-09-02 21:04:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:04:01 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:04:01 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:04:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:04:01 --> Final output sent to browser
DEBUG - 2011-09-02 21:04:01 --> Total execution time: 0.0483
DEBUG - 2011-09-02 21:04:02 --> Config Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:04:02 --> URI Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Router Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Output Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Input Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:04:02 --> Language Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Loader Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Controller Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Model Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Model Class Initialized
DEBUG - 2011-09-02 21:04:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:04:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:04:03 --> Final output sent to browser
DEBUG - 2011-09-02 21:04:03 --> Total execution time: 0.6751
DEBUG - 2011-09-02 21:05:37 --> Config Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:05:37 --> URI Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Router Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Output Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Input Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:05:37 --> Language Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Loader Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Controller Class Initialized
ERROR - 2011-09-02 21:05:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:05:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:05:37 --> Model Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Model Class Initialized
DEBUG - 2011-09-02 21:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:05:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:05:37 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:05:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:05:37 --> Final output sent to browser
DEBUG - 2011-09-02 21:05:37 --> Total execution time: 0.0286
DEBUG - 2011-09-02 21:05:38 --> Config Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:05:38 --> URI Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Router Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Output Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Input Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:05:38 --> Language Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Loader Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Controller Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Model Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Model Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:05:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:05:38 --> Final output sent to browser
DEBUG - 2011-09-02 21:05:38 --> Total execution time: 0.5989
DEBUG - 2011-09-02 21:07:30 --> Config Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:07:30 --> URI Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Router Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Output Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Input Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:07:30 --> Language Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Loader Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Controller Class Initialized
ERROR - 2011-09-02 21:07:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:07:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:30 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:07:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:30 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:07:30 --> Final output sent to browser
DEBUG - 2011-09-02 21:07:30 --> Total execution time: 0.0300
DEBUG - 2011-09-02 21:07:31 --> Config Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:07:31 --> URI Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Router Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Output Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Input Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:07:31 --> Language Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Loader Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Controller Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:07:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:07:31 --> Final output sent to browser
DEBUG - 2011-09-02 21:07:31 --> Total execution time: 0.5129
DEBUG - 2011-09-02 21:07:43 --> Config Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:07:43 --> URI Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Router Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Output Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Input Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:07:43 --> Language Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Loader Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Controller Class Initialized
ERROR - 2011-09-02 21:07:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:07:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:43 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:07:43 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:43 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:07:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:07:43 --> Final output sent to browser
DEBUG - 2011-09-02 21:07:43 --> Total execution time: 0.0544
DEBUG - 2011-09-02 21:07:44 --> Config Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:07:44 --> URI Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Router Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Output Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Input Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:07:44 --> Language Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Loader Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Controller Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:07:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:07:45 --> Final output sent to browser
DEBUG - 2011-09-02 21:07:45 --> Total execution time: 0.5390
DEBUG - 2011-09-02 21:07:46 --> Config Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:07:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:07:46 --> URI Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Router Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Output Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Input Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 21:07:46 --> Language Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Loader Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Controller Class Initialized
ERROR - 2011-09-02 21:07:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 21:07:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:46 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Model Class Initialized
DEBUG - 2011-09-02 21:07:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 21:07:46 --> Database Driver Class Initialized
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 21:07:46 --> Helper loaded: url_helper
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 21:07:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 21:07:46 --> Final output sent to browser
DEBUG - 2011-09-02 21:07:46 --> Total execution time: 0.0498
DEBUG - 2011-09-02 21:13:51 --> Config Class Initialized
DEBUG - 2011-09-02 21:13:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 21:13:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 21:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 21:13:51 --> URI Class Initialized
DEBUG - 2011-09-02 21:13:51 --> Router Class Initialized
ERROR - 2011-09-02 21:13:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 22:05:26 --> Config Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:05:26 --> URI Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Router Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Output Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Input Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:05:26 --> Language Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Loader Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Controller Class Initialized
ERROR - 2011-09-02 22:05:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:05:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:05:26 --> Model Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Model Class Initialized
DEBUG - 2011-09-02 22:05:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:05:26 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:05:26 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:05:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:05:26 --> Final output sent to browser
DEBUG - 2011-09-02 22:05:26 --> Total execution time: 0.1019
DEBUG - 2011-09-02 22:06:16 --> Config Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:06:16 --> URI Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Router Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Output Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Input Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:06:16 --> Language Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Loader Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Controller Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Model Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Model Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Model Class Initialized
DEBUG - 2011-09-02 22:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:06:16 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:06:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 22:06:16 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:06:16 --> Final output sent to browser
DEBUG - 2011-09-02 22:06:16 --> Total execution time: 0.7013
DEBUG - 2011-09-02 22:07:51 --> Config Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:07:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:07:51 --> URI Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Router Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Output Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Input Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:07:51 --> Language Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Loader Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Controller Class Initialized
ERROR - 2011-09-02 22:07:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:07:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:07:51 --> Model Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Model Class Initialized
DEBUG - 2011-09-02 22:07:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:07:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:07:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:07:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:07:51 --> Final output sent to browser
DEBUG - 2011-09-02 22:07:51 --> Total execution time: 0.0274
DEBUG - 2011-09-02 22:07:52 --> Config Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:07:52 --> URI Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Router Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Output Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Input Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:07:52 --> Language Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Loader Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Controller Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Model Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Model Class Initialized
DEBUG - 2011-09-02 22:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:07:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:07:53 --> Final output sent to browser
DEBUG - 2011-09-02 22:07:53 --> Total execution time: 0.7535
DEBUG - 2011-09-02 22:08:10 --> Config Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:08:10 --> URI Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Router Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Output Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Input Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:08:10 --> Language Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Loader Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Controller Class Initialized
ERROR - 2011-09-02 22:08:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:08:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:08:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:08:10 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:08:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:08:10 --> Final output sent to browser
DEBUG - 2011-09-02 22:08:10 --> Total execution time: 0.0279
DEBUG - 2011-09-02 22:08:10 --> Config Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:08:10 --> URI Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Router Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Output Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Input Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:08:10 --> Language Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Loader Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Controller Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:08:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:08:11 --> Final output sent to browser
DEBUG - 2011-09-02 22:08:11 --> Total execution time: 0.7727
DEBUG - 2011-09-02 22:08:31 --> Config Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:08:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:08:31 --> URI Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Router Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Output Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Input Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:08:31 --> Language Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Loader Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Controller Class Initialized
ERROR - 2011-09-02 22:08:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:08:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:08:31 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:08:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:08:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:08:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:08:31 --> Final output sent to browser
DEBUG - 2011-09-02 22:08:31 --> Total execution time: 0.0300
DEBUG - 2011-09-02 22:08:32 --> Config Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:08:32 --> URI Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Router Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Output Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Input Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:08:32 --> Language Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Loader Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Controller Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Model Class Initialized
DEBUG - 2011-09-02 22:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:08:32 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:08:33 --> Final output sent to browser
DEBUG - 2011-09-02 22:08:33 --> Total execution time: 0.7312
DEBUG - 2011-09-02 22:36:40 --> Config Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:36:40 --> URI Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Router Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Output Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Input Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:36:40 --> Language Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Loader Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Controller Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:36:40 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:36:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 22:36:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:36:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:36:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:36:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:36:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:36:41 --> Final output sent to browser
DEBUG - 2011-09-02 22:36:41 --> Total execution time: 0.2629
DEBUG - 2011-09-02 22:36:42 --> Config Class Initialized
DEBUG - 2011-09-02 22:36:42 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:36:42 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:36:42 --> URI Class Initialized
DEBUG - 2011-09-02 22:36:42 --> Router Class Initialized
ERROR - 2011-09-02 22:36:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 22:36:56 --> Config Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:36:56 --> URI Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Router Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Output Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Input Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:36:56 --> Language Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Loader Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Controller Class Initialized
ERROR - 2011-09-02 22:36:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:36:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:36:56 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:36:56 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:36:56 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:36:56 --> Final output sent to browser
DEBUG - 2011-09-02 22:36:56 --> Total execution time: 0.0324
DEBUG - 2011-09-02 22:36:57 --> Config Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:36:57 --> URI Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Router Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Output Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Input Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:36:57 --> Language Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Loader Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Controller Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Model Class Initialized
DEBUG - 2011-09-02 22:36:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:36:57 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:36:58 --> Final output sent to browser
DEBUG - 2011-09-02 22:36:58 --> Total execution time: 0.8431
DEBUG - 2011-09-02 22:36:59 --> Config Class Initialized
DEBUG - 2011-09-02 22:36:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:36:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:36:59 --> URI Class Initialized
DEBUG - 2011-09-02 22:36:59 --> Router Class Initialized
ERROR - 2011-09-02 22:36:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 22:39:09 --> Config Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:39:09 --> URI Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Router Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Output Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Input Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:39:09 --> Language Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Loader Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Controller Class Initialized
ERROR - 2011-09-02 22:39:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:39:09 --> Model Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Model Class Initialized
DEBUG - 2011-09-02 22:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:39:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:39:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:39:09 --> Final output sent to browser
DEBUG - 2011-09-02 22:39:09 --> Total execution time: 0.0292
DEBUG - 2011-09-02 22:39:10 --> Config Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:39:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:39:10 --> URI Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Router Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Output Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Input Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:39:10 --> Language Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Loader Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Controller Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:39:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:39:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:39:11 --> Final output sent to browser
DEBUG - 2011-09-02 22:39:11 --> Total execution time: 0.5335
DEBUG - 2011-09-02 22:39:12 --> Config Class Initialized
DEBUG - 2011-09-02 22:39:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:39:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:39:12 --> URI Class Initialized
DEBUG - 2011-09-02 22:39:12 --> Router Class Initialized
ERROR - 2011-09-02 22:39:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 22:40:09 --> Config Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:40:09 --> URI Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Router Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Output Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Input Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:40:09 --> Language Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Loader Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Controller Class Initialized
ERROR - 2011-09-02 22:40:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:40:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:40:09 --> Model Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Model Class Initialized
DEBUG - 2011-09-02 22:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:40:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:40:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:40:09 --> Final output sent to browser
DEBUG - 2011-09-02 22:40:09 --> Total execution time: 0.0344
DEBUG - 2011-09-02 22:40:10 --> Config Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:40:10 --> URI Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Router Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Output Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Input Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:40:10 --> Language Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Loader Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Controller Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Model Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:40:10 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:40:10 --> Final output sent to browser
DEBUG - 2011-09-02 22:40:10 --> Total execution time: 0.8078
DEBUG - 2011-09-02 22:41:02 --> Config Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:41:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:41:02 --> URI Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Router Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Output Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Input Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:41:02 --> Language Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Loader Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Controller Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Model Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Model Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Model Class Initialized
DEBUG - 2011-09-02 22:41:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:41:02 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:41:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 22:41:02 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:41:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:41:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:41:02 --> Final output sent to browser
DEBUG - 2011-09-02 22:41:02 --> Total execution time: 0.0888
DEBUG - 2011-09-02 22:44:17 --> Config Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:44:17 --> URI Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Router Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Output Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Input Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:44:17 --> Language Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Loader Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Controller Class Initialized
ERROR - 2011-09-02 22:44:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 22:44:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:44:17 --> Model Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Model Class Initialized
DEBUG - 2011-09-02 22:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:44:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 22:44:17 --> Helper loaded: url_helper
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 22:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 22:44:17 --> Final output sent to browser
DEBUG - 2011-09-02 22:44:17 --> Total execution time: 0.0293
DEBUG - 2011-09-02 22:44:18 --> Config Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:44:18 --> URI Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Router Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Output Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Input Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 22:44:18 --> Language Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Loader Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Controller Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Model Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Model Class Initialized
DEBUG - 2011-09-02 22:44:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 22:44:18 --> Database Driver Class Initialized
DEBUG - 2011-09-02 22:44:19 --> Final output sent to browser
DEBUG - 2011-09-02 22:44:19 --> Total execution time: 0.4490
DEBUG - 2011-09-02 22:44:20 --> Config Class Initialized
DEBUG - 2011-09-02 22:44:20 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:44:20 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:44:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:44:20 --> URI Class Initialized
DEBUG - 2011-09-02 22:44:20 --> Router Class Initialized
ERROR - 2011-09-02 22:44:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 22:59:10 --> Config Class Initialized
DEBUG - 2011-09-02 22:59:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 22:59:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 22:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 22:59:10 --> URI Class Initialized
DEBUG - 2011-09-02 22:59:10 --> Router Class Initialized
ERROR - 2011-09-02 22:59:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 23:00:12 --> Config Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:00:12 --> URI Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Router Class Initialized
DEBUG - 2011-09-02 23:00:12 --> No URI present. Default controller set.
DEBUG - 2011-09-02 23:00:12 --> Output Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Input Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:00:12 --> Language Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Loader Class Initialized
DEBUG - 2011-09-02 23:00:12 --> Controller Class Initialized
DEBUG - 2011-09-02 23:00:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 23:00:12 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:00:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:00:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:00:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:00:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:00:12 --> Final output sent to browser
DEBUG - 2011-09-02 23:00:12 --> Total execution time: 0.1347
DEBUG - 2011-09-02 23:02:49 --> Config Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:02:49 --> URI Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Router Class Initialized
DEBUG - 2011-09-02 23:02:49 --> No URI present. Default controller set.
DEBUG - 2011-09-02 23:02:49 --> Output Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Input Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:02:49 --> Language Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Loader Class Initialized
DEBUG - 2011-09-02 23:02:49 --> Controller Class Initialized
DEBUG - 2011-09-02 23:02:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-02 23:02:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:02:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:02:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:02:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:02:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:02:49 --> Final output sent to browser
DEBUG - 2011-09-02 23:02:49 --> Total execution time: 0.0128
DEBUG - 2011-09-02 23:35:45 --> Config Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:35:45 --> URI Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Router Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Output Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Input Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:35:45 --> Language Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Loader Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Controller Class Initialized
ERROR - 2011-09-02 23:35:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-02 23:35:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 23:35:45 --> Model Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Model Class Initialized
DEBUG - 2011-09-02 23:35:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:35:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-02 23:35:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:35:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:35:45 --> Final output sent to browser
DEBUG - 2011-09-02 23:35:45 --> Total execution time: 0.0523
DEBUG - 2011-09-02 23:35:48 --> Config Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:35:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:35:48 --> URI Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Router Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Output Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Input Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:35:48 --> Language Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Loader Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Controller Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Model Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Model Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:35:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:35:48 --> Final output sent to browser
DEBUG - 2011-09-02 23:35:48 --> Total execution time: 0.6060
DEBUG - 2011-09-02 23:35:51 --> Config Class Initialized
DEBUG - 2011-09-02 23:35:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:35:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:35:51 --> URI Class Initialized
DEBUG - 2011-09-02 23:35:51 --> Router Class Initialized
ERROR - 2011-09-02 23:35:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:44:30 --> Config Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:44:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:44:30 --> URI Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Router Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Output Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Input Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:44:30 --> Language Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Loader Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Controller Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:44:30 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:44:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:44:30 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:44:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:44:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:44:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:44:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:44:30 --> Final output sent to browser
DEBUG - 2011-09-02 23:44:30 --> Total execution time: 0.2359
DEBUG - 2011-09-02 23:44:35 --> Config Class Initialized
DEBUG - 2011-09-02 23:44:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:44:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:44:35 --> URI Class Initialized
DEBUG - 2011-09-02 23:44:35 --> Router Class Initialized
ERROR - 2011-09-02 23:44:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:44:49 --> Config Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:44:49 --> URI Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Router Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Output Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Input Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:44:49 --> Language Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Loader Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Controller Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Model Class Initialized
DEBUG - 2011-09-02 23:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:44:49 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:44:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:44:49 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:44:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:44:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:44:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:44:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:44:49 --> Final output sent to browser
DEBUG - 2011-09-02 23:44:49 --> Total execution time: 0.2802
DEBUG - 2011-09-02 23:44:52 --> Config Class Initialized
DEBUG - 2011-09-02 23:44:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:44:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:44:52 --> URI Class Initialized
DEBUG - 2011-09-02 23:44:52 --> Router Class Initialized
ERROR - 2011-09-02 23:44:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:45:09 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:09 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Router Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Output Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Input Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:45:09 --> Language Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Loader Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Controller Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:45:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:45:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:45:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:45:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:45:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:45:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:45:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:45:09 --> Final output sent to browser
DEBUG - 2011-09-02 23:45:09 --> Total execution time: 0.3291
DEBUG - 2011-09-02 23:45:11 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:11 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:11 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:11 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:11 --> Router Class Initialized
ERROR - 2011-09-02 23:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:45:19 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:19 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Router Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Output Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Input Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:45:19 --> Language Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Loader Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Controller Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:45:19 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:45:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:45:19 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:45:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:45:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:45:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:45:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:45:19 --> Final output sent to browser
DEBUG - 2011-09-02 23:45:19 --> Total execution time: 0.2701
DEBUG - 2011-09-02 23:45:22 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:22 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:22 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:22 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:22 --> Router Class Initialized
ERROR - 2011-09-02 23:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:45:35 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:35 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Router Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Output Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Input Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:45:35 --> Language Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Loader Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Controller Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:45:35 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:45:35 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:45:35 --> Final output sent to browser
DEBUG - 2011-09-02 23:45:35 --> Total execution time: 0.0457
DEBUG - 2011-09-02 23:45:37 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:37 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:37 --> Router Class Initialized
ERROR - 2011-09-02 23:45:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:45:44 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:44 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Router Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Output Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Input Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:45:44 --> Language Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Loader Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Controller Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:45:44 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:45:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:45:44 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:45:44 --> Final output sent to browser
DEBUG - 2011-09-02 23:45:44 --> Total execution time: 0.2162
DEBUG - 2011-09-02 23:45:47 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:47 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:47 --> Router Class Initialized
ERROR - 2011-09-02 23:45:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:45:51 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:51 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Router Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Output Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Input Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:45:51 --> Language Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Loader Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Controller Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Model Class Initialized
DEBUG - 2011-09-02 23:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:45:51 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:45:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:45:51 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:45:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:45:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:45:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:45:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:45:51 --> Final output sent to browser
DEBUG - 2011-09-02 23:45:51 --> Total execution time: 0.2378
DEBUG - 2011-09-02 23:45:54 --> Config Class Initialized
DEBUG - 2011-09-02 23:45:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:45:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:45:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:45:54 --> URI Class Initialized
DEBUG - 2011-09-02 23:45:54 --> Router Class Initialized
ERROR - 2011-09-02 23:45:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:09 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:09 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:09 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:09 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:09 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:09 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:09 --> Total execution time: 0.1917
DEBUG - 2011-09-02 23:46:10 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:10 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:10 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:10 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:10 --> Router Class Initialized
ERROR - 2011-09-02 23:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:16 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:16 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:16 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:16 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:17 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:17 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:17 --> Total execution time: 0.2811
DEBUG - 2011-09-02 23:46:18 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:18 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:18 --> Router Class Initialized
ERROR - 2011-09-02 23:46:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:37 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:37 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:37 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:37 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:38 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:38 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:38 --> Total execution time: 0.2361
DEBUG - 2011-09-02 23:46:39 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:39 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:39 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:39 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:39 --> Router Class Initialized
ERROR - 2011-09-02 23:46:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:45 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:45 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:45 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:45 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:45 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:45 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:45 --> Total execution time: 0.1467
DEBUG - 2011-09-02 23:46:47 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:47 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Router Class Initialized
ERROR - 2011-09-02 23:46:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 23:46:47 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:47 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:47 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:47 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:47 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:47 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:47 --> Total execution time: 0.0792
DEBUG - 2011-09-02 23:46:47 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:47 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:47 --> Router Class Initialized
ERROR - 2011-09-02 23:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:52 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:52 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:52 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:52 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:52 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:52 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:52 --> Total execution time: 0.2510
DEBUG - 2011-09-02 23:46:54 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:54 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:54 --> Router Class Initialized
ERROR - 2011-09-02 23:46:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:46:59 --> Config Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:46:59 --> URI Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Router Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Output Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Input Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:46:59 --> Language Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Loader Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Controller Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Model Class Initialized
DEBUG - 2011-09-02 23:46:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:46:59 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:46:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:46:59 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:46:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:46:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:46:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:46:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:46:59 --> Final output sent to browser
DEBUG - 2011-09-02 23:46:59 --> Total execution time: 0.2636
DEBUG - 2011-09-02 23:47:02 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:02 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:02 --> Router Class Initialized
ERROR - 2011-09-02 23:47:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:47:17 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:17 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Router Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Output Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Input Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:47:17 --> Language Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Loader Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Controller Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:47:17 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:47:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:47:17 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:47:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:47:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:47:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:47:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:47:17 --> Final output sent to browser
DEBUG - 2011-09-02 23:47:17 --> Total execution time: 0.2009
DEBUG - 2011-09-02 23:47:18 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:18 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:18 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:18 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:18 --> Router Class Initialized
ERROR - 2011-09-02 23:47:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:47:37 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:37 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Router Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Output Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Input Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:47:37 --> Language Class Initialized
DEBUG - 2011-09-02 23:47:37 --> Loader Class Initialized
DEBUG - 2011-09-02 23:47:38 --> Controller Class Initialized
DEBUG - 2011-09-02 23:47:38 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:38 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:38 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:47:38 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:47:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:47:38 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:47:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:47:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:47:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:47:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:47:38 --> Final output sent to browser
DEBUG - 2011-09-02 23:47:38 --> Total execution time: 0.4205
DEBUG - 2011-09-02 23:47:43 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:43 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:43 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:43 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:43 --> Router Class Initialized
ERROR - 2011-09-02 23:47:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:47:48 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:48 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Router Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Output Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Input Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:47:48 --> Language Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Loader Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Controller Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:47:48 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:47:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:47:48 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:47:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:47:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:47:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:47:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:47:48 --> Final output sent to browser
DEBUG - 2011-09-02 23:47:48 --> Total execution time: 0.2318
DEBUG - 2011-09-02 23:47:50 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:50 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:50 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:50 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:50 --> Router Class Initialized
ERROR - 2011-09-02 23:47:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:47:54 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:54 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Router Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Output Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Input Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:47:54 --> Language Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Loader Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Controller Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Model Class Initialized
DEBUG - 2011-09-02 23:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:47:54 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:47:54 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:47:54 --> Final output sent to browser
DEBUG - 2011-09-02 23:47:54 --> Total execution time: 0.1979
DEBUG - 2011-09-02 23:47:57 --> Config Class Initialized
DEBUG - 2011-09-02 23:47:57 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:47:57 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:47:57 --> URI Class Initialized
DEBUG - 2011-09-02 23:47:57 --> Router Class Initialized
ERROR - 2011-09-02 23:47:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:48:00 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:00 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Router Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Output Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Input Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:48:00 --> Language Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Loader Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Controller Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:48:00 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:48:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:48:00 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:48:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:48:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:48:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:48:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:48:00 --> Final output sent to browser
DEBUG - 2011-09-02 23:48:00 --> Total execution time: 0.2159
DEBUG - 2011-09-02 23:48:02 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:02 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:02 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:02 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:02 --> Router Class Initialized
ERROR - 2011-09-02 23:48:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:48:07 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:07 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Router Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Output Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Input Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:48:07 --> Language Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Loader Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Controller Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:48:07 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:48:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:48:08 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:48:08 --> Final output sent to browser
DEBUG - 2011-09-02 23:48:08 --> Total execution time: 0.4483
DEBUG - 2011-09-02 23:48:09 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:09 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:09 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:09 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:09 --> Router Class Initialized
ERROR - 2011-09-02 23:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:48:15 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:15 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Router Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Output Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Input Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:48:15 --> Language Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Loader Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Controller Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:48:15 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:48:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:48:16 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:48:16 --> Final output sent to browser
DEBUG - 2011-09-02 23:48:16 --> Total execution time: 0.4243
DEBUG - 2011-09-02 23:48:19 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:19 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:19 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:19 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:19 --> Router Class Initialized
ERROR - 2011-09-02 23:48:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:48:24 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:24 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Router Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Output Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Input Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:48:24 --> Language Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Loader Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Controller Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:48:24 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:48:24 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:48:24 --> Final output sent to browser
DEBUG - 2011-09-02 23:48:24 --> Total execution time: 0.0441
DEBUG - 2011-09-02 23:48:25 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:25 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:25 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:25 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:25 --> Router Class Initialized
ERROR - 2011-09-02 23:48:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:48:31 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:31 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Router Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Output Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Input Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:48:31 --> Language Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Loader Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Controller Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Model Class Initialized
DEBUG - 2011-09-02 23:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:48:31 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:48:31 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:48:31 --> Final output sent to browser
DEBUG - 2011-09-02 23:48:31 --> Total execution time: 0.0825
DEBUG - 2011-09-02 23:48:36 --> Config Class Initialized
DEBUG - 2011-09-02 23:48:36 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:48:36 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:48:36 --> URI Class Initialized
DEBUG - 2011-09-02 23:48:36 --> Router Class Initialized
ERROR - 2011-09-02 23:48:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-02 23:51:08 --> Config Class Initialized
DEBUG - 2011-09-02 23:51:08 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:51:08 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:51:08 --> URI Class Initialized
DEBUG - 2011-09-02 23:51:08 --> Router Class Initialized
ERROR - 2011-09-02 23:51:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-02 23:51:41 --> Config Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Hooks Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Utf8 Class Initialized
DEBUG - 2011-09-02 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-02 23:51:41 --> URI Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Router Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Output Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Input Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-02 23:51:41 --> Language Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Loader Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Controller Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Model Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Model Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Model Class Initialized
DEBUG - 2011-09-02 23:51:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-02 23:51:41 --> Database Driver Class Initialized
DEBUG - 2011-09-02 23:51:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-02 23:51:41 --> Helper loaded: url_helper
DEBUG - 2011-09-02 23:51:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-02 23:51:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-02 23:51:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-02 23:51:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-02 23:51:41 --> Final output sent to browser
DEBUG - 2011-09-02 23:51:41 --> Total execution time: 0.0642

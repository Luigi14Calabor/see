<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-01 00:02:51 --> Config Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 00:02:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 00:02:51 --> URI Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Router Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Output Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Input Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 00:02:51 --> Language Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Loader Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Controller Class Initialized
ERROR - 2011-09-01 00:02:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 00:02:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 00:02:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 00:02:51 --> Model Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Model Class Initialized
DEBUG - 2011-09-01 00:02:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 00:02:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 00:02:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 00:02:52 --> Helper loaded: url_helper
DEBUG - 2011-09-01 00:02:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 00:02:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 00:02:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 00:02:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 00:02:52 --> Final output sent to browser
DEBUG - 2011-09-01 00:02:52 --> Total execution time: 0.8152
DEBUG - 2011-09-01 02:06:34 --> Config Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:06:34 --> URI Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Router Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Output Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Input Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 02:06:34 --> Language Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Loader Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Controller Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Model Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Model Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Model Class Initialized
DEBUG - 2011-09-01 02:06:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 02:06:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 02:06:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 02:06:36 --> Helper loaded: url_helper
DEBUG - 2011-09-01 02:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 02:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 02:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 02:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 02:06:36 --> Final output sent to browser
DEBUG - 2011-09-01 02:06:36 --> Total execution time: 2.5506
DEBUG - 2011-09-01 02:06:39 --> Config Class Initialized
DEBUG - 2011-09-01 02:06:39 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:06:39 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:06:39 --> URI Class Initialized
DEBUG - 2011-09-01 02:06:39 --> Router Class Initialized
ERROR - 2011-09-01 02:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 02:06:40 --> Config Class Initialized
DEBUG - 2011-09-01 02:06:40 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:06:40 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:06:40 --> URI Class Initialized
DEBUG - 2011-09-01 02:06:40 --> Router Class Initialized
ERROR - 2011-09-01 02:06:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 02:08:18 --> Config Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:08:18 --> URI Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Router Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Output Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Input Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 02:08:18 --> Language Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Loader Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Controller Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 02:08:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 02:08:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 02:08:19 --> Helper loaded: url_helper
DEBUG - 2011-09-01 02:08:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 02:08:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 02:08:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 02:08:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 02:08:19 --> Final output sent to browser
DEBUG - 2011-09-01 02:08:19 --> Total execution time: 1.0173
DEBUG - 2011-09-01 02:08:20 --> Config Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:08:20 --> URI Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Router Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Output Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Input Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 02:08:20 --> Language Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Loader Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Controller Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Model Class Initialized
DEBUG - 2011-09-01 02:08:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 02:08:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 02:08:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 02:08:20 --> Helper loaded: url_helper
DEBUG - 2011-09-01 02:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 02:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 02:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 02:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 02:08:20 --> Final output sent to browser
DEBUG - 2011-09-01 02:08:20 --> Total execution time: 0.0612
DEBUG - 2011-09-01 02:08:21 --> Config Class Initialized
DEBUG - 2011-09-01 02:08:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 02:08:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 02:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 02:08:21 --> URI Class Initialized
DEBUG - 2011-09-01 02:08:21 --> Router Class Initialized
ERROR - 2011-09-01 02:08:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:28:04 --> Config Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:28:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:28:04 --> URI Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Router Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Output Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Input Class Initialized
DEBUG - 2011-09-01 03:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:28:05 --> Language Class Initialized
DEBUG - 2011-09-01 03:28:05 --> Loader Class Initialized
DEBUG - 2011-09-01 03:28:05 --> Controller Class Initialized
ERROR - 2011-09-01 03:28:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:28:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:28:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:28:05 --> Model Class Initialized
DEBUG - 2011-09-01 03:28:05 --> Model Class Initialized
DEBUG - 2011-09-01 03:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:28:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:28:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:28:10 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:28:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:28:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:28:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:28:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:28:10 --> Final output sent to browser
DEBUG - 2011-09-01 03:28:10 --> Total execution time: 6.8710
DEBUG - 2011-09-01 03:28:14 --> Config Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:28:14 --> URI Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Router Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Output Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Input Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:28:14 --> Language Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Loader Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Controller Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:28:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:28:15 --> Final output sent to browser
DEBUG - 2011-09-01 03:28:15 --> Total execution time: 1.1760
DEBUG - 2011-09-01 03:28:22 --> Config Class Initialized
DEBUG - 2011-09-01 03:28:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:28:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:28:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:28:22 --> URI Class Initialized
DEBUG - 2011-09-01 03:28:22 --> Router Class Initialized
ERROR - 2011-09-01 03:28:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:28:23 --> Config Class Initialized
DEBUG - 2011-09-01 03:28:23 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:28:23 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:28:23 --> URI Class Initialized
DEBUG - 2011-09-01 03:28:23 --> Router Class Initialized
ERROR - 2011-09-01 03:28:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:29:26 --> Config Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:29:26 --> URI Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Router Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Output Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Input Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:29:26 --> Language Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Loader Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Controller Class Initialized
ERROR - 2011-09-01 03:29:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:29:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:29:26 --> Model Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Model Class Initialized
DEBUG - 2011-09-01 03:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:29:26 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:29:26 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:29:26 --> Final output sent to browser
DEBUG - 2011-09-01 03:29:26 --> Total execution time: 0.0328
DEBUG - 2011-09-01 03:29:27 --> Config Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:29:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:29:27 --> URI Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Router Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Output Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Input Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:29:27 --> Language Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Loader Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Controller Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Model Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Model Class Initialized
DEBUG - 2011-09-01 03:29:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:29:27 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:29:28 --> Final output sent to browser
DEBUG - 2011-09-01 03:29:28 --> Total execution time: 0.5158
DEBUG - 2011-09-01 03:29:30 --> Config Class Initialized
DEBUG - 2011-09-01 03:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:29:30 --> URI Class Initialized
DEBUG - 2011-09-01 03:29:30 --> Router Class Initialized
ERROR - 2011-09-01 03:29:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:30:26 --> Config Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:30:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:30:26 --> URI Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Router Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Output Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Input Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:30:26 --> Language Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Loader Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Controller Class Initialized
ERROR - 2011-09-01 03:30:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:30:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:30:26 --> Model Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Model Class Initialized
DEBUG - 2011-09-01 03:30:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:30:26 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:30:26 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:30:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:30:26 --> Final output sent to browser
DEBUG - 2011-09-01 03:30:26 --> Total execution time: 0.0282
DEBUG - 2011-09-01 03:30:28 --> Config Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:30:28 --> URI Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Router Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Output Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Input Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:30:28 --> Language Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Loader Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Controller Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Model Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Model Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:30:28 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:30:28 --> Final output sent to browser
DEBUG - 2011-09-01 03:30:28 --> Total execution time: 0.5458
DEBUG - 2011-09-01 03:30:30 --> Config Class Initialized
DEBUG - 2011-09-01 03:30:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:30:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:30:30 --> URI Class Initialized
DEBUG - 2011-09-01 03:30:30 --> Router Class Initialized
ERROR - 2011-09-01 03:30:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:30:31 --> Config Class Initialized
DEBUG - 2011-09-01 03:30:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:30:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:30:31 --> URI Class Initialized
DEBUG - 2011-09-01 03:30:31 --> Router Class Initialized
ERROR - 2011-09-01 03:30:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:32:58 --> Config Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:32:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:32:58 --> URI Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Router Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Output Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Input Class Initialized
DEBUG - 2011-09-01 03:32:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:32:58 --> Language Class Initialized
DEBUG - 2011-09-01 03:32:59 --> Loader Class Initialized
DEBUG - 2011-09-01 03:32:59 --> Controller Class Initialized
DEBUG - 2011-09-01 03:32:59 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:02 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:02 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Controller Class Initialized
ERROR - 2011-09-01 03:33:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:33:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:02 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:02 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:02 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:33:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:33:02 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:02 --> Total execution time: 0.1185
DEBUG - 2011-09-01 03:33:03 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:03 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:03 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Controller Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:03 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:09 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:09 --> Total execution time: 6.3729
DEBUG - 2011-09-01 03:33:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 03:33:11 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:33:11 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:11 --> Total execution time: 12.9404
DEBUG - 2011-09-01 03:33:12 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:12 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:12 --> Router Class Initialized
ERROR - 2011-09-01 03:33:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:33:19 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:19 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:19 --> Router Class Initialized
ERROR - 2011-09-01 03:33:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:33:20 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:20 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:20 --> Router Class Initialized
ERROR - 2011-09-01 03:33:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:33:28 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:28 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:28 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Controller Class Initialized
ERROR - 2011-09-01 03:33:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:33:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:28 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:28 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:28 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:33:28 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:28 --> Total execution time: 0.0298
DEBUG - 2011-09-01 03:33:30 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:30 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:30 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Controller Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:30 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:30 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:30 --> Total execution time: 0.6914
DEBUG - 2011-09-01 03:33:32 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:32 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:32 --> Router Class Initialized
ERROR - 2011-09-01 03:33:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:33:56 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:56 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:56 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Controller Class Initialized
ERROR - 2011-09-01 03:33:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:33:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:56 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:56 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:56 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:33:56 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:56 --> Total execution time: 0.1357
DEBUG - 2011-09-01 03:33:58 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:58 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:58 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Controller Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:58 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:59 --> Total execution time: 0.6419
DEBUG - 2011-09-01 03:33:59 --> Config Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:33:59 --> URI Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Router Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Output Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Input Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:33:59 --> Language Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Loader Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Controller Class Initialized
ERROR - 2011-09-01 03:33:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:59 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Model Class Initialized
DEBUG - 2011-09-01 03:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:33:59 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:33:59 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:33:59 --> Final output sent to browser
DEBUG - 2011-09-01 03:33:59 --> Total execution time: 0.0300
DEBUG - 2011-09-01 03:34:00 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:00 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:00 --> Router Class Initialized
ERROR - 2011-09-01 03:34:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:34:11 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:11 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:11 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Controller Class Initialized
ERROR - 2011-09-01 03:34:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:34:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:11 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:11 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:11 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:34:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:34:11 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:11 --> Total execution time: 0.0908
DEBUG - 2011-09-01 03:34:13 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:13 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:13 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Controller Class Initialized
ERROR - 2011-09-01 03:34:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:34:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:13 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:13 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:34:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:34:13 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:13 --> Total execution time: 0.0283
DEBUG - 2011-09-01 03:34:15 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:15 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:15 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Controller Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:15 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:15 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:15 --> Total execution time: 0.5700
DEBUG - 2011-09-01 03:34:18 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:18 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:18 --> Router Class Initialized
ERROR - 2011-09-01 03:34:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:34:43 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:43 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:43 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Controller Class Initialized
ERROR - 2011-09-01 03:34:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:34:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:43 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:43 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:43 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:34:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:34:43 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:43 --> Total execution time: 0.0432
DEBUG - 2011-09-01 03:34:45 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:45 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:45 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Controller Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:46 --> Total execution time: 0.6303
DEBUG - 2011-09-01 03:34:46 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:46 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:46 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Controller Class Initialized
ERROR - 2011-09-01 03:34:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:34:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:46 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:46 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:34:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:34:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:34:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:34:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:34:47 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:47 --> Total execution time: 0.0742
DEBUG - 2011-09-01 03:34:48 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:48 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:48 --> Router Class Initialized
ERROR - 2011-09-01 03:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:34:59 --> Config Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:34:59 --> URI Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Router Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Output Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Input Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:34:59 --> Language Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Loader Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Controller Class Initialized
ERROR - 2011-09-01 03:34:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:34:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:59 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Model Class Initialized
DEBUG - 2011-09-01 03:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:34:59 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:34:59 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:34:59 --> Final output sent to browser
DEBUG - 2011-09-01 03:34:59 --> Total execution time: 0.0325
DEBUG - 2011-09-01 03:35:00 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:00 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:00 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:00 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:00 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:00 --> Total execution time: 0.0582
DEBUG - 2011-09-01 03:35:00 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:00 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:00 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Controller Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:01 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:01 --> Total execution time: 0.5163
DEBUG - 2011-09-01 03:35:03 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:03 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:03 --> Router Class Initialized
ERROR - 2011-09-01 03:35:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:35:07 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:07 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:07 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:07 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:07 --> Total execution time: 0.0406
DEBUG - 2011-09-01 03:35:07 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:07 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:07 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Controller Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:08 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:08 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:08 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:08 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:08 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:08 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:08 --> Total execution time: 0.0495
DEBUG - 2011-09-01 03:35:08 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:08 --> Total execution time: 0.5473
DEBUG - 2011-09-01 03:35:11 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:11 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:11 --> Router Class Initialized
ERROR - 2011-09-01 03:35:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:35:14 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:14 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:14 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:14 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:14 --> Total execution time: 0.0299
DEBUG - 2011-09-01 03:35:15 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:15 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:15 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Controller Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:15 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:15 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:15 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:15 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:15 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:15 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:15 --> Total execution time: 0.0827
DEBUG - 2011-09-01 03:35:15 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:15 --> Total execution time: 0.4693
DEBUG - 2011-09-01 03:35:17 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:17 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:17 --> Router Class Initialized
ERROR - 2011-09-01 03:35:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:35:37 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:37 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:37 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:37 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:37 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:37 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:37 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:37 --> Total execution time: 0.0673
DEBUG - 2011-09-01 03:35:38 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:38 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:38 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Controller Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:38 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:41 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:41 --> Total execution time: 2.8330
DEBUG - 2011-09-01 03:35:42 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:42 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Router Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Output Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Input Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:35:42 --> Language Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Loader Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Controller Class Initialized
ERROR - 2011-09-01 03:35:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:35:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:42 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Model Class Initialized
DEBUG - 2011-09-01 03:35:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:35:42 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:35:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:35:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:35:42 --> Final output sent to browser
DEBUG - 2011-09-01 03:35:42 --> Total execution time: 0.0492
DEBUG - 2011-09-01 03:35:44 --> Config Class Initialized
DEBUG - 2011-09-01 03:35:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:35:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:35:44 --> URI Class Initialized
DEBUG - 2011-09-01 03:35:44 --> Router Class Initialized
ERROR - 2011-09-01 03:35:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:36:12 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:12 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Router Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Output Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Input Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:36:12 --> Language Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Loader Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Controller Class Initialized
ERROR - 2011-09-01 03:36:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:36:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:12 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:36:12 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:12 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:36:12 --> Final output sent to browser
DEBUG - 2011-09-01 03:36:12 --> Total execution time: 0.0420
DEBUG - 2011-09-01 03:36:13 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:13 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Router Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Output Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Input Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:36:13 --> Language Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Loader Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Controller Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:36:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Final output sent to browser
DEBUG - 2011-09-01 03:36:14 --> Total execution time: 0.8003
DEBUG - 2011-09-01 03:36:14 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:14 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Router Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Output Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Input Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:36:14 --> Language Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Loader Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Controller Class Initialized
ERROR - 2011-09-01 03:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:36:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:36:14 --> Final output sent to browser
DEBUG - 2011-09-01 03:36:14 --> Total execution time: 0.0568
DEBUG - 2011-09-01 03:36:16 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:16 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:16 --> Router Class Initialized
ERROR - 2011-09-01 03:36:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 03:36:30 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:30 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Router Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Output Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Input Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:36:30 --> Language Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Loader Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Controller Class Initialized
ERROR - 2011-09-01 03:36:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 03:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:30 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:36:30 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 03:36:30 --> Helper loaded: url_helper
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 03:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 03:36:30 --> Final output sent to browser
DEBUG - 2011-09-01 03:36:30 --> Total execution time: 0.0743
DEBUG - 2011-09-01 03:36:31 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:31 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Router Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Output Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Input Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 03:36:31 --> Language Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Loader Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Controller Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Model Class Initialized
DEBUG - 2011-09-01 03:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 03:36:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 03:36:32 --> Final output sent to browser
DEBUG - 2011-09-01 03:36:32 --> Total execution time: 0.7949
DEBUG - 2011-09-01 03:36:34 --> Config Class Initialized
DEBUG - 2011-09-01 03:36:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 03:36:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 03:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 03:36:34 --> URI Class Initialized
DEBUG - 2011-09-01 03:36:34 --> Router Class Initialized
ERROR - 2011-09-01 03:36:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 04:02:49 --> Config Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:02:49 --> URI Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Router Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Output Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Input Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:02:49 --> Language Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Loader Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Controller Class Initialized
ERROR - 2011-09-01 04:02:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 04:02:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 04:02:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 04:02:49 --> Model Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Model Class Initialized
DEBUG - 2011-09-01 04:02:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:02:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:02:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 04:02:50 --> Helper loaded: url_helper
DEBUG - 2011-09-01 04:02:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 04:02:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 04:02:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 04:02:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 04:02:50 --> Final output sent to browser
DEBUG - 2011-09-01 04:02:50 --> Total execution time: 1.0109
DEBUG - 2011-09-01 04:02:52 --> Config Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:02:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:02:52 --> URI Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Router Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Output Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Input Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:02:52 --> Language Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Loader Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Controller Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Model Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Model Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:02:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:02:52 --> Final output sent to browser
DEBUG - 2011-09-01 04:02:52 --> Total execution time: 0.8395
DEBUG - 2011-09-01 04:02:54 --> Config Class Initialized
DEBUG - 2011-09-01 04:02:54 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:02:54 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:02:54 --> URI Class Initialized
DEBUG - 2011-09-01 04:02:54 --> Router Class Initialized
ERROR - 2011-09-01 04:02:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 04:08:18 --> Config Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:08:18 --> URI Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Router Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Output Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Input Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:08:18 --> Language Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Loader Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Controller Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Model Class Initialized
DEBUG - 2011-09-01 04:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:08:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:08:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 04:08:18 --> Helper loaded: url_helper
DEBUG - 2011-09-01 04:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 04:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 04:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 04:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 04:08:18 --> Final output sent to browser
DEBUG - 2011-09-01 04:08:18 --> Total execution time: 0.7337
DEBUG - 2011-09-01 04:08:20 --> Config Class Initialized
DEBUG - 2011-09-01 04:08:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:08:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:08:20 --> URI Class Initialized
DEBUG - 2011-09-01 04:08:20 --> Router Class Initialized
ERROR - 2011-09-01 04:08:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 04:08:21 --> Config Class Initialized
DEBUG - 2011-09-01 04:08:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:08:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:08:21 --> URI Class Initialized
DEBUG - 2011-09-01 04:08:21 --> Router Class Initialized
ERROR - 2011-09-01 04:08:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 04:16:14 --> Config Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:16:14 --> URI Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Router Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Output Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Input Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:16:14 --> Language Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Loader Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Controller Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Model Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Model Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Model Class Initialized
DEBUG - 2011-09-01 04:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:16:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:16:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 04:16:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 04:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 04:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 04:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 04:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 04:16:14 --> Final output sent to browser
DEBUG - 2011-09-01 04:16:14 --> Total execution time: 0.0482
DEBUG - 2011-09-01 04:43:49 --> Config Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:43:49 --> URI Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Router Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Output Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Input Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:43:49 --> Language Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Loader Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Controller Class Initialized
ERROR - 2011-09-01 04:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 04:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 04:43:49 --> Model Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Model Class Initialized
DEBUG - 2011-09-01 04:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:43:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 04:43:49 --> Helper loaded: url_helper
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 04:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 04:43:49 --> Final output sent to browser
DEBUG - 2011-09-01 04:43:49 --> Total execution time: 0.6254
DEBUG - 2011-09-01 04:43:51 --> Config Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:43:51 --> URI Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Router Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Output Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Input Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 04:43:51 --> Language Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Loader Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Controller Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Model Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Model Class Initialized
DEBUG - 2011-09-01 04:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 04:43:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 04:43:52 --> Final output sent to browser
DEBUG - 2011-09-01 04:43:52 --> Total execution time: 0.6058
DEBUG - 2011-09-01 04:43:53 --> Config Class Initialized
DEBUG - 2011-09-01 04:43:53 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:43:53 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:43:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:43:53 --> URI Class Initialized
DEBUG - 2011-09-01 04:43:53 --> Router Class Initialized
ERROR - 2011-09-01 04:43:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 04:43:54 --> Config Class Initialized
DEBUG - 2011-09-01 04:43:54 --> Hooks Class Initialized
DEBUG - 2011-09-01 04:43:54 --> Utf8 Class Initialized
DEBUG - 2011-09-01 04:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 04:43:54 --> URI Class Initialized
DEBUG - 2011-09-01 04:43:54 --> Router Class Initialized
ERROR - 2011-09-01 04:43:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 05:29:21 --> Config Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 05:29:21 --> URI Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Router Class Initialized
DEBUG - 2011-09-01 05:29:21 --> No URI present. Default controller set.
DEBUG - 2011-09-01 05:29:21 --> Output Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Input Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 05:29:21 --> Language Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Loader Class Initialized
DEBUG - 2011-09-01 05:29:21 --> Controller Class Initialized
DEBUG - 2011-09-01 05:29:21 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 05:29:21 --> Helper loaded: url_helper
DEBUG - 2011-09-01 05:29:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 05:29:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 05:29:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 05:29:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 05:29:21 --> Final output sent to browser
DEBUG - 2011-09-01 05:29:21 --> Total execution time: 0.2094
DEBUG - 2011-09-01 05:30:38 --> Config Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 05:30:38 --> URI Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Router Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Output Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Input Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 05:30:38 --> Language Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Loader Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Controller Class Initialized
ERROR - 2011-09-01 05:30:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 05:30:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 05:30:38 --> Model Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Model Class Initialized
DEBUG - 2011-09-01 05:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 05:30:38 --> Database Driver Class Initialized
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 05:30:38 --> Helper loaded: url_helper
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 05:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 05:30:38 --> Final output sent to browser
DEBUG - 2011-09-01 05:30:38 --> Total execution time: 0.1647
DEBUG - 2011-09-01 05:30:39 --> Config Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Hooks Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Utf8 Class Initialized
DEBUG - 2011-09-01 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 05:30:39 --> URI Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Router Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Output Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Input Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 05:30:39 --> Language Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Loader Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Controller Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Model Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Model Class Initialized
DEBUG - 2011-09-01 05:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 05:30:39 --> Database Driver Class Initialized
DEBUG - 2011-09-01 05:30:40 --> Final output sent to browser
DEBUG - 2011-09-01 05:30:40 --> Total execution time: 0.6378
DEBUG - 2011-09-01 05:30:41 --> Config Class Initialized
DEBUG - 2011-09-01 05:30:41 --> Hooks Class Initialized
DEBUG - 2011-09-01 05:30:41 --> Utf8 Class Initialized
DEBUG - 2011-09-01 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 05:30:41 --> URI Class Initialized
DEBUG - 2011-09-01 05:30:41 --> Router Class Initialized
ERROR - 2011-09-01 05:30:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:09:30 --> Config Class Initialized
DEBUG - 2011-09-01 08:09:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:09:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:09:30 --> URI Class Initialized
DEBUG - 2011-09-01 08:09:30 --> Router Class Initialized
ERROR - 2011-09-01 08:09:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 08:09:31 --> Config Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:09:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:09:31 --> URI Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Router Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Output Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Input Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:09:31 --> Language Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Loader Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Controller Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Model Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Model Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Model Class Initialized
DEBUG - 2011-09-01 08:09:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:09:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:09:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 08:09:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:09:31 --> Final output sent to browser
DEBUG - 2011-09-01 08:09:31 --> Total execution time: 0.7692
DEBUG - 2011-09-01 08:10:22 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:22 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Router Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Output Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Input Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:10:22 --> Language Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Loader Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Controller Class Initialized
ERROR - 2011-09-01 08:10:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:10:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:22 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:10:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:10:22 --> Final output sent to browser
DEBUG - 2011-09-01 08:10:22 --> Total execution time: 0.0813
DEBUG - 2011-09-01 08:10:24 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:24 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Router Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Output Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Input Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:10:24 --> Language Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Loader Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Controller Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:10:24 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:10:24 --> Final output sent to browser
DEBUG - 2011-09-01 08:10:24 --> Total execution time: 0.7059
DEBUG - 2011-09-01 08:10:30 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:30 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:30 --> Router Class Initialized
ERROR - 2011-09-01 08:10:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:10:52 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:52 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Router Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Output Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Input Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:10:52 --> Language Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Loader Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Controller Class Initialized
ERROR - 2011-09-01 08:10:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:10:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:10:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:52 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:10:52 --> Final output sent to browser
DEBUG - 2011-09-01 08:10:52 --> Total execution time: 0.0401
DEBUG - 2011-09-01 08:10:54 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:54 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Router Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Output Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Input Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:10:54 --> Language Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Loader Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Controller Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:10:54 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:54 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Router Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Output Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Input Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:10:54 --> Language Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Loader Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Controller Class Initialized
ERROR - 2011-09-01 08:10:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:10:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:54 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Model Class Initialized
DEBUG - 2011-09-01 08:10:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:10:54 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:10:54 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:10:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:10:54 --> Final output sent to browser
DEBUG - 2011-09-01 08:10:54 --> Total execution time: 0.0334
DEBUG - 2011-09-01 08:10:54 --> Final output sent to browser
DEBUG - 2011-09-01 08:10:54 --> Total execution time: 0.5140
DEBUG - 2011-09-01 08:10:57 --> Config Class Initialized
DEBUG - 2011-09-01 08:10:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:10:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:10:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:10:57 --> URI Class Initialized
DEBUG - 2011-09-01 08:10:57 --> Router Class Initialized
ERROR - 2011-09-01 08:10:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:11:00 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:00 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:00 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Controller Class Initialized
ERROR - 2011-09-01 08:11:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:11:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:00 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:00 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:11:00 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:00 --> Total execution time: 0.0313
DEBUG - 2011-09-01 08:11:01 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:01 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:01 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Controller Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:02 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:02 --> Total execution time: 0.7898
DEBUG - 2011-09-01 08:11:22 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:22 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:22 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Controller Class Initialized
ERROR - 2011-09-01 08:11:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:11:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:22 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:11:22 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:22 --> Total execution time: 0.0283
DEBUG - 2011-09-01 08:11:23 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:23 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:23 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Controller Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:23 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:23 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:23 --> Total execution time: 0.5576
DEBUG - 2011-09-01 08:11:33 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:33 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:33 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Controller Class Initialized
ERROR - 2011-09-01 08:11:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:11:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:33 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:11:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:11:33 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:33 --> Total execution time: 0.0280
DEBUG - 2011-09-01 08:11:34 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:34 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:34 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Controller Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:35 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:35 --> Total execution time: 0.5053
DEBUG - 2011-09-01 08:11:44 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:44 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:44 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Controller Class Initialized
ERROR - 2011-09-01 08:11:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:11:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:44 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:44 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:44 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:11:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:11:44 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:44 --> Total execution time: 0.0514
DEBUG - 2011-09-01 08:11:45 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:45 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:45 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Controller Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:45 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:45 --> Total execution time: 0.7148
DEBUG - 2011-09-01 08:11:56 --> Config Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:11:56 --> URI Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Router Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Output Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Input Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:11:56 --> Language Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Loader Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Controller Class Initialized
ERROR - 2011-09-01 08:11:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:11:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:56 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Model Class Initialized
DEBUG - 2011-09-01 08:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:11:56 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:11:56 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:11:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:11:56 --> Final output sent to browser
DEBUG - 2011-09-01 08:11:56 --> Total execution time: 0.0550
DEBUG - 2011-09-01 08:12:01 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:01 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:01 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Controller Class Initialized
ERROR - 2011-09-01 08:12:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:12:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:01 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:12:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:12:01 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:01 --> Total execution time: 0.0540
DEBUG - 2011-09-01 08:12:02 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:02 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:02 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Controller Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:02 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:02 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:02 --> Total execution time: 0.5835
DEBUG - 2011-09-01 08:12:16 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:16 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:16 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Controller Class Initialized
ERROR - 2011-09-01 08:12:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:12:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:16 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:16 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:16 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:12:16 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:16 --> Total execution time: 0.2323
DEBUG - 2011-09-01 08:12:17 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:17 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:17 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Controller Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:17 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:18 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:18 --> Total execution time: 0.6854
DEBUG - 2011-09-01 08:12:31 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:31 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:31 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Controller Class Initialized
ERROR - 2011-09-01 08:12:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:12:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:31 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:12:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:12:31 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:31 --> Total execution time: 0.0308
DEBUG - 2011-09-01 08:12:32 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:32 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:32 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Controller Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:33 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:33 --> Total execution time: 0.5218
DEBUG - 2011-09-01 08:12:47 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:47 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:47 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Controller Class Initialized
ERROR - 2011-09-01 08:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:47 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:12:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:12:47 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:47 --> Total execution time: 0.0281
DEBUG - 2011-09-01 08:12:49 --> Config Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:12:49 --> URI Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Router Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Output Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Input Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:12:49 --> Language Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Loader Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Controller Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Model Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:12:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:12:49 --> Final output sent to browser
DEBUG - 2011-09-01 08:12:49 --> Total execution time: 0.5360
DEBUG - 2011-09-01 08:13:04 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:04 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:04 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:04 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:04 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:04 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:04 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:04 --> Total execution time: 0.0385
DEBUG - 2011-09-01 08:13:05 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:05 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:05 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:06 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:06 --> Total execution time: 0.5040
DEBUG - 2011-09-01 08:13:13 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:13 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:13 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:13 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:13 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:13 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:13 --> Total execution time: 0.0514
DEBUG - 2011-09-01 08:13:14 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:14 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:14 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:15 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:15 --> Total execution time: 0.6571
DEBUG - 2011-09-01 08:13:24 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:24 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:24 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:24 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:24 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:24 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:24 --> Total execution time: 0.0271
DEBUG - 2011-09-01 08:13:24 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:24 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:24 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:24 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:25 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:25 --> Total execution time: 0.5161
DEBUG - 2011-09-01 08:13:33 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:33 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:33 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:33 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:33 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:33 --> Total execution time: 0.0330
DEBUG - 2011-09-01 08:13:34 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:34 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:34 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:35 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:35 --> Total execution time: 0.5085
DEBUG - 2011-09-01 08:13:42 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:42 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:42 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:42 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:42 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:42 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:42 --> Total execution time: 0.0267
DEBUG - 2011-09-01 08:13:43 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:43 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:43 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:43 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:43 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:43 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:43 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:43 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:43 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:43 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:43 --> Total execution time: 0.0279
DEBUG - 2011-09-01 08:13:43 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:43 --> Total execution time: 0.5026
DEBUG - 2011-09-01 08:13:51 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:51 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:51 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:51 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:51 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:51 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:51 --> Total execution time: 0.0330
DEBUG - 2011-09-01 08:13:52 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:52 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:52 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Controller Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:53 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:53 --> Language Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Loader Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Controller Class Initialized
ERROR - 2011-09-01 08:13:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:13:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:53 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Model Class Initialized
DEBUG - 2011-09-01 08:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:13:53 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:13:53 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:13:53 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:53 --> Total execution time: 0.0511
DEBUG - 2011-09-01 08:13:53 --> Final output sent to browser
DEBUG - 2011-09-01 08:13:53 --> Total execution time: 0.5582
DEBUG - 2011-09-01 08:13:59 --> Config Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:13:59 --> URI Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Router Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Output Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Input Class Initialized
DEBUG - 2011-09-01 08:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:13:59 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:00 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:00 --> Controller Class Initialized
ERROR - 2011-09-01 08:14:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:14:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:00 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:00 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:00 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:14:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:14:00 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:00 --> Total execution time: 0.0283
DEBUG - 2011-09-01 08:14:01 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:01 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Router Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Output Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Input Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:14:01 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Controller Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:02 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:02 --> Total execution time: 0.5216
DEBUG - 2011-09-01 08:14:09 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:09 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Router Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Output Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Input Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:14:09 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Controller Class Initialized
ERROR - 2011-09-01 08:14:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:14:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:09 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:09 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:09 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:14:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:14:09 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:09 --> Total execution time: 0.0279
DEBUG - 2011-09-01 08:14:10 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:10 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Router Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Output Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Input Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:14:10 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Controller Class Initialized
ERROR - 2011-09-01 08:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:10 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:10 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:14:10 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:14:10 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:10 --> Total execution time: 0.1254
DEBUG - 2011-09-01 08:14:10 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:10 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Router Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Output Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Input Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:14:10 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Controller Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:10 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:11 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:11 --> Total execution time: 0.7677
DEBUG - 2011-09-01 08:14:36 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:36 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Router Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Output Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Input Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:14:36 --> Language Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Loader Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Controller Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Model Class Initialized
DEBUG - 2011-09-01 08:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:14:36 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:14:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 08:14:36 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:14:36 --> Final output sent to browser
DEBUG - 2011-09-01 08:14:36 --> Total execution time: 0.1327
DEBUG - 2011-09-01 08:14:38 --> Config Class Initialized
DEBUG - 2011-09-01 08:14:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:14:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:14:38 --> URI Class Initialized
DEBUG - 2011-09-01 08:14:38 --> Router Class Initialized
ERROR - 2011-09-01 08:14:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:15:09 --> Config Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:15:09 --> URI Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Router Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Output Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Input Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:15:09 --> Language Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Loader Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Controller Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:15:09 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:15:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 08:15:10 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:15:10 --> Final output sent to browser
DEBUG - 2011-09-01 08:15:10 --> Total execution time: 1.2374
DEBUG - 2011-09-01 08:15:12 --> Config Class Initialized
DEBUG - 2011-09-01 08:15:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:15:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:15:12 --> URI Class Initialized
DEBUG - 2011-09-01 08:15:12 --> Router Class Initialized
ERROR - 2011-09-01 08:15:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:15:42 --> Config Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:15:42 --> URI Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Router Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Output Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Input Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:15:42 --> Language Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Loader Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Controller Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Model Class Initialized
DEBUG - 2011-09-01 08:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:15:42 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 08:15:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:15:42 --> Final output sent to browser
DEBUG - 2011-09-01 08:15:42 --> Total execution time: 0.0481
DEBUG - 2011-09-01 08:46:50 --> Config Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:46:50 --> URI Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Router Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Output Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Input Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:46:50 --> Language Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Loader Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Controller Class Initialized
ERROR - 2011-09-01 08:46:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 08:46:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:46:50 --> Model Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Model Class Initialized
DEBUG - 2011-09-01 08:46:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:46:50 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 08:46:50 --> Helper loaded: url_helper
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 08:46:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 08:46:50 --> Final output sent to browser
DEBUG - 2011-09-01 08:46:50 --> Total execution time: 0.2745
DEBUG - 2011-09-01 08:46:52 --> Config Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:46:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:46:52 --> URI Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Router Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Output Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Input Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 08:46:52 --> Language Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Loader Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Controller Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Model Class Initialized
DEBUG - 2011-09-01 08:46:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 08:46:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 08:46:53 --> Final output sent to browser
DEBUG - 2011-09-01 08:46:53 --> Total execution time: 0.5918
DEBUG - 2011-09-01 08:46:56 --> Config Class Initialized
DEBUG - 2011-09-01 08:46:56 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:46:56 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:46:56 --> URI Class Initialized
DEBUG - 2011-09-01 08:46:56 --> Router Class Initialized
ERROR - 2011-09-01 08:46:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 08:46:58 --> Config Class Initialized
DEBUG - 2011-09-01 08:46:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 08:46:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 08:46:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 08:46:58 --> URI Class Initialized
DEBUG - 2011-09-01 08:46:58 --> Router Class Initialized
ERROR - 2011-09-01 08:46:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 09:25:06 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:06 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:06 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:07 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:07 --> Total execution time: 1.3461
DEBUG - 2011-09-01 09:25:10 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:10 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Router Class Initialized
ERROR - 2011-09-01 09:25:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 09:25:10 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:10 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:10 --> Router Class Initialized
ERROR - 2011-09-01 09:25:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 09:25:32 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:32 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:32 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:32 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:32 --> Total execution time: 0.3744
DEBUG - 2011-09-01 09:25:33 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:33 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:33 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:33 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:33 --> Total execution time: 0.0516
DEBUG - 2011-09-01 09:25:34 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:34 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:34 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:34 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:34 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:34 --> Total execution time: 0.0523
DEBUG - 2011-09-01 09:25:47 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:47 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:47 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:47 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:47 --> Total execution time: 0.6267
DEBUG - 2011-09-01 09:25:48 --> Config Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:25:48 --> URI Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Router Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Output Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Input Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:25:48 --> Language Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Loader Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Controller Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:25:48 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:25:48 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:25:48 --> Final output sent to browser
DEBUG - 2011-09-01 09:25:48 --> Total execution time: 0.0690
DEBUG - 2011-09-01 09:26:04 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:04 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:04 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:04 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:04 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:04 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:04 --> Total execution time: 0.3295
DEBUG - 2011-09-01 09:26:05 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:05 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:05 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:05 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:05 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:05 --> Total execution time: 0.0550
DEBUG - 2011-09-01 09:26:22 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:22 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:22 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:22 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:22 --> Total execution time: 0.4884
DEBUG - 2011-09-01 09:26:24 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:24 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:24 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:24 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:24 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:24 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:24 --> Total execution time: 0.0448
DEBUG - 2011-09-01 09:26:32 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:32 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:32 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:32 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:32 --> Total execution time: 0.4313
DEBUG - 2011-09-01 09:26:34 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:34 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:34 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:34 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:34 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:34 --> Total execution time: 0.2083
DEBUG - 2011-09-01 09:26:45 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:45 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:45 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:46 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:46 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:46 --> Total execution time: 1.1529
DEBUG - 2011-09-01 09:26:47 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:47 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:47 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:47 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:47 --> Total execution time: 0.0543
DEBUG - 2011-09-01 09:26:57 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:57 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:57 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:57 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:57 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:57 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:57 --> Total execution time: 0.2980
DEBUG - 2011-09-01 09:26:58 --> Config Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:26:58 --> URI Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Router Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Output Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Input Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:26:58 --> Language Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Loader Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Controller Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Model Class Initialized
DEBUG - 2011-09-01 09:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:26:58 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:26:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:26:58 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:26:58 --> Final output sent to browser
DEBUG - 2011-09-01 09:26:58 --> Total execution time: 0.0747
DEBUG - 2011-09-01 09:27:06 --> Config Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:27:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:27:06 --> URI Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Router Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Output Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Input Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:27:06 --> Language Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Loader Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Controller Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:27:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:27:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:27:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:27:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:27:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:27:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:27:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:27:07 --> Final output sent to browser
DEBUG - 2011-09-01 09:27:07 --> Total execution time: 0.2118
DEBUG - 2011-09-01 09:27:08 --> Config Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:27:08 --> URI Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Router Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Output Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Input Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:27:08 --> Language Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Loader Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Controller Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:27:08 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:27:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:27:08 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:27:08 --> Final output sent to browser
DEBUG - 2011-09-01 09:27:08 --> Total execution time: 0.0517
DEBUG - 2011-09-01 09:27:21 --> Config Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:27:21 --> URI Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Router Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Output Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Input Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:27:21 --> Language Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Loader Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Controller Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:27:21 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:27:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:27:21 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:27:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:27:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:27:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:27:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:27:21 --> Final output sent to browser
DEBUG - 2011-09-01 09:27:21 --> Total execution time: 0.2213
DEBUG - 2011-09-01 09:27:28 --> Config Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:27:28 --> URI Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Router Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Output Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Input Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:27:28 --> Language Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Loader Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Controller Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:27:28 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:27:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:27:28 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:27:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:27:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:27:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:27:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:27:28 --> Final output sent to browser
DEBUG - 2011-09-01 09:27:28 --> Total execution time: 0.2894
DEBUG - 2011-09-01 09:27:29 --> Config Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:27:29 --> URI Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Router Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Output Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Input Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:27:29 --> Language Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Loader Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Controller Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:27:29 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:27:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:27:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:27:29 --> Final output sent to browser
DEBUG - 2011-09-01 09:27:29 --> Total execution time: 0.0690
DEBUG - 2011-09-01 09:37:48 --> Config Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:37:48 --> URI Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Router Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Output Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Input Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:37:48 --> Language Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Loader Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Controller Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:37:48 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:37:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:37:48 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:37:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:37:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:37:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:37:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:37:48 --> Final output sent to browser
DEBUG - 2011-09-01 09:37:48 --> Total execution time: 0.1237
DEBUG - 2011-09-01 09:37:55 --> Config Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:37:55 --> URI Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Router Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Output Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Input Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:37:55 --> Language Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Loader Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Controller Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Model Class Initialized
DEBUG - 2011-09-01 09:37:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:37:55 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:37:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:37:55 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:37:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:37:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:37:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:37:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:37:55 --> Final output sent to browser
DEBUG - 2011-09-01 09:37:55 --> Total execution time: 0.0862
DEBUG - 2011-09-01 09:38:05 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:05 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:05 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:06 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:06 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:06 --> Total execution time: 0.2523
DEBUG - 2011-09-01 09:38:07 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:07 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:07 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:07 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:07 --> Total execution time: 0.0451
DEBUG - 2011-09-01 09:38:20 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:20 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:20 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:20 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:21 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:21 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:21 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:21 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:21 --> Total execution time: 0.8226
DEBUG - 2011-09-01 09:38:22 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:22 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:22 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:22 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:22 --> Total execution time: 0.0510
DEBUG - 2011-09-01 09:38:35 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:35 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:35 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:35 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:36 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:36 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:36 --> Total execution time: 0.2914
DEBUG - 2011-09-01 09:38:37 --> Config Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:38:37 --> URI Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Router Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Output Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Input Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:38:37 --> Language Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Loader Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Controller Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Model Class Initialized
DEBUG - 2011-09-01 09:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:38:37 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:38:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:38:37 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:38:37 --> Final output sent to browser
DEBUG - 2011-09-01 09:38:37 --> Total execution time: 0.0576
DEBUG - 2011-09-01 09:39:01 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:01 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:01 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:01 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:01 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:01 --> Total execution time: 0.0476
DEBUG - 2011-09-01 09:39:11 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:11 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:11 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:11 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:12 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:12 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:12 --> Total execution time: 0.4301
DEBUG - 2011-09-01 09:39:13 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:13 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:13 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:13 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:13 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:13 --> Total execution time: 0.0438
DEBUG - 2011-09-01 09:39:29 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:29 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:29 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:29 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:29 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:29 --> Total execution time: 0.2184
DEBUG - 2011-09-01 09:39:31 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:31 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:31 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:31 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:31 --> Total execution time: 0.1084
DEBUG - 2011-09-01 09:39:47 --> Config Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:39:47 --> URI Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Router Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Output Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Input Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:39:47 --> Language Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Loader Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Controller Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Model Class Initialized
DEBUG - 2011-09-01 09:39:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:39:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:39:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:39:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:39:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:39:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:39:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:39:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:39:47 --> Final output sent to browser
DEBUG - 2011-09-01 09:39:47 --> Total execution time: 0.3327
DEBUG - 2011-09-01 09:40:01 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:01 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:01 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:03 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:03 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:03 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:03 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:03 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:03 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:03 --> Total execution time: 2.1263
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:03 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:03 --> Total execution time: 0.3836
DEBUG - 2011-09-01 09:40:16 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:16 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:16 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:16 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:17 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:17 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:17 --> Total execution time: 0.7604
DEBUG - 2011-09-01 09:40:20 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:20 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:20 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:20 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:20 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:20 --> Total execution time: 0.0737
DEBUG - 2011-09-01 09:40:26 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:26 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:26 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:26 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:26 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:26 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:26 --> Total execution time: 0.0466
DEBUG - 2011-09-01 09:40:29 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:29 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:29 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:29 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:29 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:29 --> Total execution time: 0.2615
DEBUG - 2011-09-01 09:40:32 --> Config Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 09:40:32 --> URI Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Router Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Output Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Input Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 09:40:32 --> Language Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Loader Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Controller Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Model Class Initialized
DEBUG - 2011-09-01 09:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 09:40:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 09:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 09:40:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 09:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 09:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 09:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 09:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 09:40:32 --> Final output sent to browser
DEBUG - 2011-09-01 09:40:32 --> Total execution time: 0.0436
DEBUG - 2011-09-01 11:05:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:05:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Router Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Output Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Input Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:05:32 --> Language Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Loader Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Controller Class Initialized
ERROR - 2011-09-01 11:05:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:05:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:05:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:05:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:05:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:05:32 --> Final output sent to browser
DEBUG - 2011-09-01 11:05:32 --> Total execution time: 0.1278
DEBUG - 2011-09-01 11:05:34 --> Config Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:05:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:05:34 --> URI Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Router Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Output Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Input Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:05:34 --> Language Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Loader Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Controller Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Model Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Model Class Initialized
DEBUG - 2011-09-01 11:05:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:05:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:05:35 --> Final output sent to browser
DEBUG - 2011-09-01 11:05:35 --> Total execution time: 0.9519
DEBUG - 2011-09-01 11:05:36 --> Config Class Initialized
DEBUG - 2011-09-01 11:05:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:05:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:05:36 --> URI Class Initialized
DEBUG - 2011-09-01 11:05:36 --> Router Class Initialized
ERROR - 2011-09-01 11:05:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:05:37 --> Config Class Initialized
DEBUG - 2011-09-01 11:05:37 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:05:37 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:05:37 --> URI Class Initialized
DEBUG - 2011-09-01 11:05:37 --> Router Class Initialized
ERROR - 2011-09-01 11:05:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:36:50 --> Config Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:36:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:36:50 --> URI Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Router Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Output Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Input Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:36:50 --> Language Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Loader Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Controller Class Initialized
ERROR - 2011-09-01 11:36:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:36:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:36:50 --> Model Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Model Class Initialized
DEBUG - 2011-09-01 11:36:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:36:50 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:36:50 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:36:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:36:50 --> Final output sent to browser
DEBUG - 2011-09-01 11:36:50 --> Total execution time: 0.0387
DEBUG - 2011-09-01 11:36:51 --> Config Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:36:51 --> URI Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Router Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Output Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Input Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:36:51 --> Language Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Loader Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Controller Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Model Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Model Class Initialized
DEBUG - 2011-09-01 11:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:36:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:36:52 --> Final output sent to browser
DEBUG - 2011-09-01 11:36:52 --> Total execution time: 1.0104
DEBUG - 2011-09-01 11:42:30 --> Config Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:42:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:42:30 --> URI Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Router Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Output Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Input Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:42:30 --> Language Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Loader Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Controller Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:42:30 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:42:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:42:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:42:31 --> Final output sent to browser
DEBUG - 2011-09-01 11:42:31 --> Total execution time: 0.3578
DEBUG - 2011-09-01 11:42:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:42:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:42:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:42:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:42:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:42:32 --> Router Class Initialized
ERROR - 2011-09-01 11:42:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:42:33 --> Config Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:42:33 --> URI Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Router Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Output Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Input Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:42:33 --> Language Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Loader Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Controller Class Initialized
ERROR - 2011-09-01 11:42:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:42:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:42:33 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:42:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:42:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:42:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:42:33 --> Final output sent to browser
DEBUG - 2011-09-01 11:42:33 --> Total execution time: 0.0663
DEBUG - 2011-09-01 11:42:33 --> Config Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:42:33 --> URI Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Router Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Output Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Input Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:42:33 --> Language Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Loader Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Controller Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Model Class Initialized
DEBUG - 2011-09-01 11:42:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:42:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:42:34 --> Final output sent to browser
DEBUG - 2011-09-01 11:42:34 --> Total execution time: 0.5786
DEBUG - 2011-09-01 11:42:38 --> Config Class Initialized
DEBUG - 2011-09-01 11:42:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:42:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:42:38 --> URI Class Initialized
DEBUG - 2011-09-01 11:42:38 --> Router Class Initialized
ERROR - 2011-09-01 11:42:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:43:12 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:12 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:12 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Controller Class Initialized
ERROR - 2011-09-01 11:43:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:43:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:12 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:12 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:12 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:43:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:43:12 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:12 --> Total execution time: 0.0341
DEBUG - 2011-09-01 11:43:13 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:13 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:13 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Controller Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:13 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:13 --> Total execution time: 0.5694
DEBUG - 2011-09-01 11:43:14 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:14 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:14 --> Router Class Initialized
ERROR - 2011-09-01 11:43:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:43:25 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:25 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:25 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Controller Class Initialized
ERROR - 2011-09-01 11:43:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:43:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:25 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:25 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:43:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:43:25 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:25 --> Total execution time: 0.0274
DEBUG - 2011-09-01 11:43:26 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:26 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:26 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Controller Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:26 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:27 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:27 --> Total execution time: 0.6235
DEBUG - 2011-09-01 11:43:27 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:27 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:27 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:27 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:27 --> Router Class Initialized
ERROR - 2011-09-01 11:43:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:43:31 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:31 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:31 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Controller Class Initialized
ERROR - 2011-09-01 11:43:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:43:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:31 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:43:31 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:31 --> Total execution time: 0.0303
DEBUG - 2011-09-01 11:43:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:32 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Controller Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:32 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:32 --> Total execution time: 0.6298
DEBUG - 2011-09-01 11:43:33 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:33 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:33 --> Router Class Initialized
ERROR - 2011-09-01 11:43:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:43:46 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:46 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:46 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Controller Class Initialized
ERROR - 2011-09-01 11:43:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:43:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:46 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:46 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:43:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:43:46 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:46 --> Total execution time: 0.0288
DEBUG - 2011-09-01 11:43:47 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:47 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:47 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Controller Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:47 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:47 --> Total execution time: 0.6063
DEBUG - 2011-09-01 11:43:48 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:48 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:48 --> Router Class Initialized
ERROR - 2011-09-01 11:43:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:43:55 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:55 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:55 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Controller Class Initialized
ERROR - 2011-09-01 11:43:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:43:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:55 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:55 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:43:55 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:43:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:43:55 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:55 --> Total execution time: 0.0284
DEBUG - 2011-09-01 11:43:55 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:55 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Router Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Output Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Input Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:43:55 --> Language Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Loader Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Controller Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Model Class Initialized
DEBUG - 2011-09-01 11:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:43:55 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:43:56 --> Final output sent to browser
DEBUG - 2011-09-01 11:43:56 --> Total execution time: 1.1670
DEBUG - 2011-09-01 11:43:57 --> Config Class Initialized
DEBUG - 2011-09-01 11:43:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:43:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:43:57 --> URI Class Initialized
DEBUG - 2011-09-01 11:43:57 --> Router Class Initialized
ERROR - 2011-09-01 11:43:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:06 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:06 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:06 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:06 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:06 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:06 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:06 --> Total execution time: 0.0299
DEBUG - 2011-09-01 11:44:06 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:06 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:06 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:07 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:07 --> Total execution time: 0.5126
DEBUG - 2011-09-01 11:44:08 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:08 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:08 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:08 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:08 --> Router Class Initialized
ERROR - 2011-09-01 11:44:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:17 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:17 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:17 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:17 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:17 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:17 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:17 --> Total execution time: 0.0480
DEBUG - 2011-09-01 11:44:17 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:17 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:17 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:17 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:18 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:18 --> Total execution time: 0.5821
DEBUG - 2011-09-01 11:44:18 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:18 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:18 --> Router Class Initialized
ERROR - 2011-09-01 11:44:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:32 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:32 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:32 --> Total execution time: 0.0288
DEBUG - 2011-09-01 11:44:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:32 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:32 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:32 --> Total execution time: 0.4959
DEBUG - 2011-09-01 11:44:33 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:33 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:33 --> Router Class Initialized
ERROR - 2011-09-01 11:44:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:41 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:41 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:41 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:41 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:41 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:41 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:41 --> Total execution time: 0.0299
DEBUG - 2011-09-01 11:44:41 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:41 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:41 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:41 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:42 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:42 --> Total execution time: 0.4940
DEBUG - 2011-09-01 11:44:42 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:42 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:42 --> Router Class Initialized
ERROR - 2011-09-01 11:44:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:45 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:45 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:45 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:44:45 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:45 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:45 --> Total execution time: 0.0419
DEBUG - 2011-09-01 11:44:46 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:46 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:46 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:46 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:46 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:46 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:46 --> Total execution time: 0.0300
DEBUG - 2011-09-01 11:44:46 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:46 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:46 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:46 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:47 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:47 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:47 --> Router Class Initialized
ERROR - 2011-09-01 11:44:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:47 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:47 --> Total execution time: 0.4785
DEBUG - 2011-09-01 11:44:48 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:48 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:48 --> Router Class Initialized
ERROR - 2011-09-01 11:44:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:52 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:52 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:52 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:52 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:52 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:52 --> Total execution time: 0.0289
DEBUG - 2011-09-01 11:44:52 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:52 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:52 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:53 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:53 --> Total execution time: 0.5853
DEBUG - 2011-09-01 11:44:53 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:53 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:53 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:53 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:53 --> Router Class Initialized
ERROR - 2011-09-01 11:44:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:44:58 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:58 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:58 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Controller Class Initialized
ERROR - 2011-09-01 11:44:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:44:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:58 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:44:58 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:44:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:44:58 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:58 --> Total execution time: 0.0292
DEBUG - 2011-09-01 11:44:58 --> Config Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:44:58 --> URI Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Router Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Output Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Input Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:44:58 --> Language Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Loader Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Controller Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Model Class Initialized
DEBUG - 2011-09-01 11:44:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:44:58 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:44:59 --> Final output sent to browser
DEBUG - 2011-09-01 11:44:59 --> Total execution time: 0.7239
DEBUG - 2011-09-01 11:45:00 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:00 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Router Class Initialized
ERROR - 2011-09-01 11:45:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:00 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:00 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:00 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:01 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:01 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:01 --> Total execution time: 0.5668
DEBUG - 2011-09-01 11:45:02 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:02 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:02 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:02 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:02 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:02 --> Router Class Initialized
ERROR - 2011-09-01 11:45:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:03 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:03 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:03 --> Total execution time: 0.2632
DEBUG - 2011-09-01 11:45:04 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:04 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:04 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Controller Class Initialized
ERROR - 2011-09-01 11:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:04 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:04 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:04 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:04 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:04 --> Total execution time: 0.1386
DEBUG - 2011-09-01 11:45:04 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:04 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:04 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:04 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:05 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:05 --> Total execution time: 1.0109
DEBUG - 2011-09-01 11:45:06 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:06 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:06 --> Router Class Initialized
ERROR - 2011-09-01 11:45:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:07 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:07 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:07 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:07 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:07 --> Total execution time: 0.3149
DEBUG - 2011-09-01 11:45:10 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:10 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:10 --> Router Class Initialized
ERROR - 2011-09-01 11:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:12 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:12 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:12 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Controller Class Initialized
ERROR - 2011-09-01 11:45:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:45:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:12 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:12 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:12 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:12 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:12 --> Total execution time: 0.0302
DEBUG - 2011-09-01 11:45:13 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:13 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:13 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:13 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:13 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:13 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:13 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:13 --> Total execution time: 0.2783
DEBUG - 2011-09-01 11:45:13 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:13 --> Total execution time: 0.5576
DEBUG - 2011-09-01 11:45:14 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:14 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Router Class Initialized
ERROR - 2011-09-01 11:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:14 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:14 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:14 --> Router Class Initialized
ERROR - 2011-09-01 11:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:17 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:17 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:17 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:17 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:17 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:17 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:17 --> Total execution time: 0.2506
DEBUG - 2011-09-01 11:45:18 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:18 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:18 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:18 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:18 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:18 --> Total execution time: 0.0440
DEBUG - 2011-09-01 11:45:18 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:18 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:18 --> Router Class Initialized
ERROR - 2011-09-01 11:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:19 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:19 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:19 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Controller Class Initialized
ERROR - 2011-09-01 11:45:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 11:45:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 11:45:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:19 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 11:45:20 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:20 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:20 --> Total execution time: 0.0280
DEBUG - 2011-09-01 11:45:20 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:20 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:20 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:20 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:20 --> Total execution time: 0.5534
DEBUG - 2011-09-01 11:45:21 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:21 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:21 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:21 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:21 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:21 --> Router Class Initialized
ERROR - 2011-09-01 11:45:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:21 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:21 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:21 --> Total execution time: 0.1956
DEBUG - 2011-09-01 11:45:22 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:22 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:22 --> Router Class Initialized
ERROR - 2011-09-01 11:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:25 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:25 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:25 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:25 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:25 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:25 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:25 --> Total execution time: 0.3476
DEBUG - 2011-09-01 11:45:28 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:28 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Router Class Initialized
ERROR - 2011-09-01 11:45:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:28 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:28 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:28 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:28 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:28 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:28 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:28 --> Total execution time: 0.2933
DEBUG - 2011-09-01 11:45:30 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:30 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:30 --> Router Class Initialized
ERROR - 2011-09-01 11:45:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:32 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:32 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:32 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:32 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:32 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:32 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:32 --> Total execution time: 0.1882
DEBUG - 2011-09-01 11:45:33 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:33 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:33 --> Router Class Initialized
ERROR - 2011-09-01 11:45:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:35 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:35 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:35 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:35 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:35 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:35 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:35 --> Total execution time: 0.2062
DEBUG - 2011-09-01 11:45:36 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:36 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:36 --> Router Class Initialized
ERROR - 2011-09-01 11:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:38 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:38 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:38 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:38 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:38 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:38 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:38 --> Total execution time: 0.2418
DEBUG - 2011-09-01 11:45:39 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:39 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Router Class Initialized
ERROR - 2011-09-01 11:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:39 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:39 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:39 --> Router Class Initialized
ERROR - 2011-09-01 11:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:41 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:41 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:41 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:41 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:42 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:42 --> Total execution time: 0.2174
DEBUG - 2011-09-01 11:45:42 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:42 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:42 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:42 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:42 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:42 --> Total execution time: 0.0434
DEBUG - 2011-09-01 11:45:43 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:43 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:43 --> Router Class Initialized
ERROR - 2011-09-01 11:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:44 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:44 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:44 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:44 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:45 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:45 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:45 --> Total execution time: 0.2141
DEBUG - 2011-09-01 11:45:45 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:45 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:45 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:45 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:45 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:45 --> Total execution time: 0.0633
DEBUG - 2011-09-01 11:45:46 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:46 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:46 --> Router Class Initialized
ERROR - 2011-09-01 11:45:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:47 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:47 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:47 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:48 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:48 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:48 --> Total execution time: 0.7584
DEBUG - 2011-09-01 11:45:49 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:49 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:49 --> Router Class Initialized
ERROR - 2011-09-01 11:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 11:45:51 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:51 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:51 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:51 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:51 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:51 --> Total execution time: 0.0707
DEBUG - 2011-09-01 11:45:52 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:52 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Router Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Output Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Input Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 11:45:52 --> Language Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Loader Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Controller Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Model Class Initialized
DEBUG - 2011-09-01 11:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 11:45:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 11:45:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 11:45:52 --> Helper loaded: url_helper
DEBUG - 2011-09-01 11:45:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 11:45:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 11:45:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 11:45:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 11:45:52 --> Final output sent to browser
DEBUG - 2011-09-01 11:45:52 --> Total execution time: 0.0546
DEBUG - 2011-09-01 11:45:53 --> Config Class Initialized
DEBUG - 2011-09-01 11:45:53 --> Hooks Class Initialized
DEBUG - 2011-09-01 11:45:53 --> Utf8 Class Initialized
DEBUG - 2011-09-01 11:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 11:45:53 --> URI Class Initialized
DEBUG - 2011-09-01 11:45:53 --> Router Class Initialized
ERROR - 2011-09-01 11:45:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:27:43 --> Config Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:27:43 --> URI Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Router Class Initialized
DEBUG - 2011-09-01 12:27:43 --> No URI present. Default controller set.
DEBUG - 2011-09-01 12:27:43 --> Output Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Input Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:27:43 --> Language Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Loader Class Initialized
DEBUG - 2011-09-01 12:27:43 --> Controller Class Initialized
DEBUG - 2011-09-01 12:27:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 12:27:43 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:27:43 --> Final output sent to browser
DEBUG - 2011-09-01 12:27:43 --> Total execution time: 0.1139
DEBUG - 2011-09-01 12:43:06 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:06 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Router Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Output Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Input Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:43:06 --> Language Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Loader Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Controller Class Initialized
ERROR - 2011-09-01 12:43:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:43:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:43:06 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:43:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:43:06 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:43:06 --> Final output sent to browser
DEBUG - 2011-09-01 12:43:06 --> Total execution time: 0.0302
DEBUG - 2011-09-01 12:43:07 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:07 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Router Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Output Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Input Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:43:07 --> Language Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Loader Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Controller Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:43:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:43:08 --> Final output sent to browser
DEBUG - 2011-09-01 12:43:08 --> Total execution time: 0.6413
DEBUG - 2011-09-01 12:43:09 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:09 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:09 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:09 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:09 --> Router Class Initialized
ERROR - 2011-09-01 12:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:43:11 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:11 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:11 --> Router Class Initialized
ERROR - 2011-09-01 12:43:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:43:26 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:26 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Router Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Output Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Input Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:43:26 --> Language Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Loader Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Controller Class Initialized
ERROR - 2011-09-01 12:43:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:43:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:43:26 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:43:26 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:43:26 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:43:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:43:26 --> Final output sent to browser
DEBUG - 2011-09-01 12:43:26 --> Total execution time: 0.0290
DEBUG - 2011-09-01 12:43:27 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:27 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Router Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Output Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Input Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:43:27 --> Language Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Loader Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Controller Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Model Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:43:27 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:43:27 --> Final output sent to browser
DEBUG - 2011-09-01 12:43:27 --> Total execution time: 0.7083
DEBUG - 2011-09-01 12:43:29 --> Config Class Initialized
DEBUG - 2011-09-01 12:43:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:43:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:43:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:43:29 --> URI Class Initialized
DEBUG - 2011-09-01 12:43:29 --> Router Class Initialized
ERROR - 2011-09-01 12:43:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:44:39 --> Config Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:44:39 --> URI Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Router Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Output Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Input Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:44:39 --> Language Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Loader Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Controller Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Model Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Model Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Model Class Initialized
DEBUG - 2011-09-01 12:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:44:39 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:44:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 12:44:40 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:44:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:44:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:44:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:44:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:44:40 --> Final output sent to browser
DEBUG - 2011-09-01 12:44:40 --> Total execution time: 0.2928
DEBUG - 2011-09-01 12:44:42 --> Config Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:44:42 --> URI Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Router Class Initialized
ERROR - 2011-09-01 12:44:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:44:42 --> Config Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:44:42 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:44:42 --> URI Class Initialized
DEBUG - 2011-09-01 12:44:42 --> Router Class Initialized
ERROR - 2011-09-01 12:44:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:55:48 --> Config Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:55:48 --> URI Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Router Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Output Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Input Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:55:48 --> Language Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Loader Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Controller Class Initialized
ERROR - 2011-09-01 12:55:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:55:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:55:48 --> Model Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Model Class Initialized
DEBUG - 2011-09-01 12:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:55:48 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:55:48 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:55:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:55:48 --> Final output sent to browser
DEBUG - 2011-09-01 12:55:48 --> Total execution time: 0.0322
DEBUG - 2011-09-01 12:55:49 --> Config Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:55:49 --> URI Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Router Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Output Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Input Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:55:49 --> Language Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Loader Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Controller Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:55:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:55:49 --> Final output sent to browser
DEBUG - 2011-09-01 12:55:49 --> Total execution time: 0.6506
DEBUG - 2011-09-01 12:55:50 --> Config Class Initialized
DEBUG - 2011-09-01 12:55:50 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:55:50 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:55:50 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:55:50 --> URI Class Initialized
DEBUG - 2011-09-01 12:55:50 --> Router Class Initialized
ERROR - 2011-09-01 12:55:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:56:09 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:09 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:09 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Controller Class Initialized
ERROR - 2011-09-01 12:56:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:56:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:09 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:09 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:09 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:56:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:56:09 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:09 --> Total execution time: 0.0283
DEBUG - 2011-09-01 12:56:09 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:09 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:09 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Controller Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:09 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:10 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:10 --> Total execution time: 0.5622
DEBUG - 2011-09-01 12:56:11 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:11 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:11 --> Router Class Initialized
ERROR - 2011-09-01 12:56:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:56:22 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:22 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:22 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Controller Class Initialized
ERROR - 2011-09-01 12:56:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:56:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:56:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:56:22 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:22 --> Total execution time: 0.0332
DEBUG - 2011-09-01 12:56:23 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:23 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:23 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Controller Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:23 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:23 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:23 --> Total execution time: 0.7626
DEBUG - 2011-09-01 12:56:24 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:24 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:24 --> Router Class Initialized
ERROR - 2011-09-01 12:56:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:56:34 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:34 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:34 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Controller Class Initialized
ERROR - 2011-09-01 12:56:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:56:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:34 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:56:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:56:34 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:34 --> Total execution time: 0.0286
DEBUG - 2011-09-01 12:56:34 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:34 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:34 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Controller Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:35 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:35 --> Total execution time: 0.6274
DEBUG - 2011-09-01 12:56:36 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:36 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:36 --> Router Class Initialized
ERROR - 2011-09-01 12:56:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:56:44 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:44 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:44 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Controller Class Initialized
ERROR - 2011-09-01 12:56:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:56:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:44 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:44 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:56:44 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:56:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:56:44 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:44 --> Total execution time: 0.0274
DEBUG - 2011-09-01 12:56:45 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:45 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Router Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Output Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Input Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:56:45 --> Language Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Loader Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Controller Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Model Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:56:45 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:56:45 --> Final output sent to browser
DEBUG - 2011-09-01 12:56:45 --> Total execution time: 0.9614
DEBUG - 2011-09-01 12:56:46 --> Config Class Initialized
DEBUG - 2011-09-01 12:56:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:56:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:56:46 --> URI Class Initialized
DEBUG - 2011-09-01 12:56:46 --> Router Class Initialized
ERROR - 2011-09-01 12:56:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:57:01 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:01 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:01 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Controller Class Initialized
ERROR - 2011-09-01 12:57:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:57:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:01 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:01 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:01 --> Total execution time: 0.0297
DEBUG - 2011-09-01 12:57:01 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:01 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:01 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:02 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:02 --> Total execution time: 0.5113
DEBUG - 2011-09-01 12:57:03 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:03 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:03 --> Router Class Initialized
ERROR - 2011-09-01 12:57:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:57:11 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:11 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:11 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Controller Class Initialized
ERROR - 2011-09-01 12:57:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:57:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:11 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:11 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:11 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:11 --> Total execution time: 0.0266
DEBUG - 2011-09-01 12:57:11 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:11 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:11 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:11 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:12 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:12 --> Total execution time: 0.5010
DEBUG - 2011-09-01 12:57:13 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:13 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:13 --> Router Class Initialized
ERROR - 2011-09-01 12:57:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:57:19 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:19 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:19 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Controller Class Initialized
ERROR - 2011-09-01 12:57:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:57:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:19 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:19 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:19 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:19 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:19 --> Total execution time: 0.0275
DEBUG - 2011-09-01 12:57:20 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:20 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:20 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:20 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:20 --> Total execution time: 0.5713
DEBUG - 2011-09-01 12:57:22 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:22 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:22 --> Router Class Initialized
ERROR - 2011-09-01 12:57:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:57:48 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:48 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:48 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:48 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 12:57:49 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:49 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:49 --> Total execution time: 0.0709
DEBUG - 2011-09-01 12:57:51 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:51 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:51 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Controller Class Initialized
ERROR - 2011-09-01 12:57:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:57:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:51 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:51 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:51 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:51 --> Total execution time: 0.0403
DEBUG - 2011-09-01 12:57:51 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:51 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:51 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:52 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:52 --> Total execution time: 0.5055
DEBUG - 2011-09-01 12:57:53 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:53 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:53 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:53 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:53 --> Router Class Initialized
ERROR - 2011-09-01 12:57:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:57:57 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:57 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Router Class Initialized
ERROR - 2011-09-01 12:57:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 12:57:57 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:57 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:57 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Controller Class Initialized
ERROR - 2011-09-01 12:57:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:57:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:57 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:57 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:57:57 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:57:57 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:57 --> Total execution time: 0.0295
DEBUG - 2011-09-01 12:57:57 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:57 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Router Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Output Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Input Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:57:57 --> Language Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Loader Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Controller Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Model Class Initialized
DEBUG - 2011-09-01 12:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:57:57 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:57:58 --> Final output sent to browser
DEBUG - 2011-09-01 12:57:58 --> Total execution time: 0.5188
DEBUG - 2011-09-01 12:57:59 --> Config Class Initialized
DEBUG - 2011-09-01 12:57:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:57:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:57:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:57:59 --> URI Class Initialized
DEBUG - 2011-09-01 12:57:59 --> Router Class Initialized
ERROR - 2011-09-01 12:57:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:05 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:05 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:05 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:05 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:05 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:05 --> Total execution time: 0.0630
DEBUG - 2011-09-01 12:58:05 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:05 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:05 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:06 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:06 --> Total execution time: 0.5049
DEBUG - 2011-09-01 12:58:07 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:07 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:07 --> Router Class Initialized
ERROR - 2011-09-01 12:58:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:13 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:13 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:13 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:13 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:13 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:13 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:13 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:13 --> Total execution time: 0.0293
DEBUG - 2011-09-01 12:58:14 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:14 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:14 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:14 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:14 --> Total execution time: 0.5883
DEBUG - 2011-09-01 12:58:15 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:15 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:15 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:15 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:15 --> Router Class Initialized
ERROR - 2011-09-01 12:58:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:22 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:22 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:22 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:22 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:22 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:22 --> Total execution time: 0.0283
DEBUG - 2011-09-01 12:58:22 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:22 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:22 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:22 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:23 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:23 --> Total execution time: 0.5063
DEBUG - 2011-09-01 12:58:24 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:24 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:24 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:24 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:24 --> Router Class Initialized
ERROR - 2011-09-01 12:58:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:33 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:33 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:33 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:33 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:33 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:33 --> Total execution time: 0.0459
DEBUG - 2011-09-01 12:58:34 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:34 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:34 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:34 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:35 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:35 --> Total execution time: 0.8243
DEBUG - 2011-09-01 12:58:35 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:35 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:36 --> Router Class Initialized
ERROR - 2011-09-01 12:58:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:49 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:49 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:49 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:49 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:49 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:49 --> Total execution time: 0.0325
DEBUG - 2011-09-01 12:58:49 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:49 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:49 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:49 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:50 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:50 --> Total execution time: 0.5564
DEBUG - 2011-09-01 12:58:51 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:51 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:51 --> Router Class Initialized
ERROR - 2011-09-01 12:58:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:55 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:55 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:55 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:55 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:55 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:55 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:55 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:55 --> Total execution time: 0.0326
DEBUG - 2011-09-01 12:58:55 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:55 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:55 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Controller Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:55 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:56 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:56 --> Total execution time: 0.6591
DEBUG - 2011-09-01 12:58:57 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:57 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:57 --> Router Class Initialized
ERROR - 2011-09-01 12:58:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:58:59 --> Config Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:58:59 --> URI Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Router Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Output Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Input Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:58:59 --> Language Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Loader Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Controller Class Initialized
ERROR - 2011-09-01 12:58:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:58:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:59 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Model Class Initialized
DEBUG - 2011-09-01 12:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:58:59 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:58:59 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:58:59 --> Final output sent to browser
DEBUG - 2011-09-01 12:58:59 --> Total execution time: 0.0331
DEBUG - 2011-09-01 12:59:00 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:00 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:00 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Controller Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:00 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:00 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:00 --> Total execution time: 0.5764
DEBUG - 2011-09-01 12:59:01 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:01 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:01 --> Router Class Initialized
ERROR - 2011-09-01 12:59:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:59:02 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:02 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:02 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Controller Class Initialized
ERROR - 2011-09-01 12:59:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:59:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:02 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:02 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:02 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:59:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:59:02 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:02 --> Total execution time: 0.0555
DEBUG - 2011-09-01 12:59:05 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:05 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:05 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Controller Class Initialized
ERROR - 2011-09-01 12:59:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:05 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:05 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:59:05 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:05 --> Total execution time: 0.0511
DEBUG - 2011-09-01 12:59:06 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:06 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:06 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Controller Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:07 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:07 --> Total execution time: 0.5943
DEBUG - 2011-09-01 12:59:07 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:07 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:07 --> Router Class Initialized
ERROR - 2011-09-01 12:59:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:59:43 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:43 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:43 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Controller Class Initialized
ERROR - 2011-09-01 12:59:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 12:59:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:43 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:43 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 12:59:43 --> Helper loaded: url_helper
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 12:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 12:59:43 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:43 --> Total execution time: 0.0302
DEBUG - 2011-09-01 12:59:44 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:44 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Router Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Output Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Input Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 12:59:44 --> Language Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Loader Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Controller Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Model Class Initialized
DEBUG - 2011-09-01 12:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 12:59:44 --> Database Driver Class Initialized
DEBUG - 2011-09-01 12:59:45 --> Final output sent to browser
DEBUG - 2011-09-01 12:59:45 --> Total execution time: 0.5483
DEBUG - 2011-09-01 12:59:45 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:45 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:45 --> Router Class Initialized
ERROR - 2011-09-01 12:59:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 12:59:46 --> Config Class Initialized
DEBUG - 2011-09-01 12:59:46 --> Hooks Class Initialized
DEBUG - 2011-09-01 12:59:46 --> Utf8 Class Initialized
DEBUG - 2011-09-01 12:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 12:59:46 --> URI Class Initialized
DEBUG - 2011-09-01 12:59:46 --> Router Class Initialized
ERROR - 2011-09-01 12:59:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:21:08 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:08 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Router Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Output Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Input Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:21:08 --> Language Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Loader Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Controller Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:21:08 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:21:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:21:08 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:21:08 --> Final output sent to browser
DEBUG - 2011-09-01 13:21:08 --> Total execution time: 0.3529
DEBUG - 2011-09-01 13:21:11 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:11 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:11 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:11 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:11 --> Router Class Initialized
ERROR - 2011-09-01 13:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:21:13 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:13 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:13 --> Router Class Initialized
ERROR - 2011-09-01 13:21:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:21:14 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:14 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:14 --> Router Class Initialized
ERROR - 2011-09-01 13:21:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:21:35 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:35 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Router Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Output Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Input Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:21:35 --> Language Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Loader Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Controller Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:21:35 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:21:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:21:35 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:21:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:21:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:21:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:21:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:21:35 --> Final output sent to browser
DEBUG - 2011-09-01 13:21:35 --> Total execution time: 0.3512
DEBUG - 2011-09-01 13:21:48 --> Config Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:21:48 --> URI Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Router Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Output Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Input Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:21:48 --> Language Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Loader Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Controller Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Model Class Initialized
DEBUG - 2011-09-01 13:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:21:48 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:21:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:21:49 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:21:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:21:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:21:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:21:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:21:49 --> Final output sent to browser
DEBUG - 2011-09-01 13:21:49 --> Total execution time: 0.2761
DEBUG - 2011-09-01 13:22:03 --> Config Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:22:03 --> URI Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Router Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Output Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Input Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:22:03 --> Language Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Loader Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Controller Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:22:03 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:22:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:22:04 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:22:04 --> Final output sent to browser
DEBUG - 2011-09-01 13:22:04 --> Total execution time: 1.0250
DEBUG - 2011-09-01 13:22:06 --> Config Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:22:06 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:22:06 --> URI Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Router Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Output Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Input Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:22:06 --> Language Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Loader Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Controller Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:22:06 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:22:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:22:06 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:22:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:22:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:22:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:22:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:22:06 --> Final output sent to browser
DEBUG - 2011-09-01 13:22:06 --> Total execution time: 0.1601
DEBUG - 2011-09-01 13:22:15 --> Config Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:22:15 --> URI Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Router Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Output Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Input Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:22:15 --> Language Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Loader Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Controller Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:22:15 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:22:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:22:15 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:22:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:22:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:22:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:22:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:22:15 --> Final output sent to browser
DEBUG - 2011-09-01 13:22:15 --> Total execution time: 0.2742
DEBUG - 2011-09-01 13:22:29 --> Config Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:22:29 --> URI Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Router Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Output Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Input Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:22:29 --> Language Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Loader Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Controller Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:22:29 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:22:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:22:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:22:29 --> Final output sent to browser
DEBUG - 2011-09-01 13:22:29 --> Total execution time: 0.4641
DEBUG - 2011-09-01 13:22:41 --> Config Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:22:41 --> URI Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Router Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Output Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Input Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:22:41 --> Language Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Loader Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Controller Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Model Class Initialized
DEBUG - 2011-09-01 13:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:22:41 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:22:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:22:42 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:22:42 --> Final output sent to browser
DEBUG - 2011-09-01 13:22:42 --> Total execution time: 0.5710
DEBUG - 2011-09-01 13:24:12 --> Config Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:24:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:24:12 --> URI Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Router Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Output Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Input Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:24:12 --> Language Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Loader Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Controller Class Initialized
ERROR - 2011-09-01 13:24:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 13:24:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:24:12 --> Model Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Model Class Initialized
DEBUG - 2011-09-01 13:24:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:24:12 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:24:12 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:24:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:24:12 --> Final output sent to browser
DEBUG - 2011-09-01 13:24:12 --> Total execution time: 0.0271
DEBUG - 2011-09-01 13:24:14 --> Config Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:24:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:24:14 --> URI Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Router Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Output Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Input Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:24:14 --> Language Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Loader Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Controller Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Model Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Model Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:24:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:24:14 --> Final output sent to browser
DEBUG - 2011-09-01 13:24:14 --> Total execution time: 0.5724
DEBUG - 2011-09-01 13:25:03 --> Config Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:25:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:25:03 --> URI Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Router Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Output Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Input Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:25:03 --> Language Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Loader Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Controller Class Initialized
ERROR - 2011-09-01 13:25:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 13:25:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:25:03 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:25:03 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:25:03 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:25:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:25:03 --> Final output sent to browser
DEBUG - 2011-09-01 13:25:03 --> Total execution time: 0.0652
DEBUG - 2011-09-01 13:25:04 --> Config Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:25:04 --> URI Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Router Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Output Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Input Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:25:04 --> Language Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Loader Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Controller Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:25:04 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:25:05 --> Final output sent to browser
DEBUG - 2011-09-01 13:25:05 --> Total execution time: 0.5149
DEBUG - 2011-09-01 13:25:14 --> Config Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:25:14 --> URI Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Router Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Output Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Input Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:25:14 --> Language Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Loader Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Controller Class Initialized
ERROR - 2011-09-01 13:25:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 13:25:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:25:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 13:25:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:25:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:25:14 --> Final output sent to browser
DEBUG - 2011-09-01 13:25:14 --> Total execution time: 0.0949
DEBUG - 2011-09-01 13:25:16 --> Config Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:25:16 --> URI Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Router Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Output Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Input Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:25:16 --> Language Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Loader Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Controller Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Model Class Initialized
DEBUG - 2011-09-01 13:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:25:16 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:25:17 --> Final output sent to browser
DEBUG - 2011-09-01 13:25:17 --> Total execution time: 0.4939
DEBUG - 2011-09-01 13:26:36 --> Config Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:26:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:26:36 --> URI Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Router Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Output Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Input Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:26:36 --> Language Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Loader Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Controller Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Model Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Model Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Model Class Initialized
DEBUG - 2011-09-01 13:26:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:26:36 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:26:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:26:36 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:26:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:26:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:26:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:26:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:26:36 --> Final output sent to browser
DEBUG - 2011-09-01 13:26:36 --> Total execution time: 0.1797
DEBUG - 2011-09-01 13:26:48 --> Config Class Initialized
DEBUG - 2011-09-01 13:26:48 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:26:48 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:26:48 --> URI Class Initialized
DEBUG - 2011-09-01 13:26:48 --> Router Class Initialized
ERROR - 2011-09-01 13:26:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:27:20 --> Config Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:27:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:27:20 --> URI Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Router Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Output Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Input Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:27:20 --> Language Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Loader Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Controller Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:27:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:27:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:27:20 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:27:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:27:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:27:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:27:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:27:20 --> Final output sent to browser
DEBUG - 2011-09-01 13:27:20 --> Total execution time: 0.2381
DEBUG - 2011-09-01 13:27:28 --> Config Class Initialized
DEBUG - 2011-09-01 13:27:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:27:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:27:28 --> URI Class Initialized
DEBUG - 2011-09-01 13:27:28 --> Router Class Initialized
ERROR - 2011-09-01 13:27:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:27:47 --> Config Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:27:47 --> URI Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Router Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Output Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Input Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:27:47 --> Language Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Loader Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Controller Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:27:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:27:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:27:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:27:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:27:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:27:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:27:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:27:47 --> Final output sent to browser
DEBUG - 2011-09-01 13:27:47 --> Total execution time: 0.2001
DEBUG - 2011-09-01 13:27:52 --> Config Class Initialized
DEBUG - 2011-09-01 13:27:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:27:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:27:52 --> URI Class Initialized
DEBUG - 2011-09-01 13:27:52 --> Router Class Initialized
ERROR - 2011-09-01 13:27:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:28:23 --> Config Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:28:23 --> URI Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Router Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Output Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Input Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:28:23 --> Language Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Loader Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Controller Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:28:23 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:28:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:28:23 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:28:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:28:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:28:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:28:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:28:23 --> Final output sent to browser
DEBUG - 2011-09-01 13:28:23 --> Total execution time: 0.0656
DEBUG - 2011-09-01 13:28:27 --> Config Class Initialized
DEBUG - 2011-09-01 13:28:27 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:28:27 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:28:27 --> URI Class Initialized
DEBUG - 2011-09-01 13:28:27 --> Router Class Initialized
ERROR - 2011-09-01 13:28:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:28:47 --> Config Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:28:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:28:47 --> URI Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Router Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Output Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Input Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:28:47 --> Language Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Loader Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Controller Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Model Class Initialized
DEBUG - 2011-09-01 13:28:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:28:47 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:28:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:28:47 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:28:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:28:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:28:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:28:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:28:47 --> Final output sent to browser
DEBUG - 2011-09-01 13:28:47 --> Total execution time: 0.0445
DEBUG - 2011-09-01 13:28:58 --> Config Class Initialized
DEBUG - 2011-09-01 13:28:58 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:28:58 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:28:58 --> URI Class Initialized
DEBUG - 2011-09-01 13:28:58 --> Router Class Initialized
ERROR - 2011-09-01 13:28:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:29:25 --> Config Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:29:25 --> URI Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Router Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Output Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Input Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:29:25 --> Language Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Loader Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Controller Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:29:25 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:29:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:29:25 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:29:25 --> Final output sent to browser
DEBUG - 2011-09-01 13:29:25 --> Total execution time: 0.2943
DEBUG - 2011-09-01 13:29:30 --> Config Class Initialized
DEBUG - 2011-09-01 13:29:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:29:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:29:30 --> URI Class Initialized
DEBUG - 2011-09-01 13:29:30 --> Router Class Initialized
ERROR - 2011-09-01 13:29:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:30:18 --> Config Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:30:18 --> URI Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Router Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Output Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Input Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:30:18 --> Language Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Loader Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Controller Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Model Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Model Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Model Class Initialized
DEBUG - 2011-09-01 13:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:30:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:30:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:30:18 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:30:18 --> Final output sent to browser
DEBUG - 2011-09-01 13:30:18 --> Total execution time: 0.3596
DEBUG - 2011-09-01 13:30:57 --> Config Class Initialized
DEBUG - 2011-09-01 13:30:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:30:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:30:57 --> URI Class Initialized
DEBUG - 2011-09-01 13:30:57 --> Router Class Initialized
ERROR - 2011-09-01 13:30:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:31:25 --> Config Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:31:25 --> URI Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Router Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Output Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Input Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:31:25 --> Language Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Loader Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Controller Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:31:25 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:31:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:31:25 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:31:25 --> Final output sent to browser
DEBUG - 2011-09-01 13:31:25 --> Total execution time: 0.2693
DEBUG - 2011-09-01 13:31:31 --> Config Class Initialized
DEBUG - 2011-09-01 13:31:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:31:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:31:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:31:31 --> URI Class Initialized
DEBUG - 2011-09-01 13:31:31 --> Router Class Initialized
ERROR - 2011-09-01 13:31:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:31:54 --> Config Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:31:54 --> URI Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Router Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Output Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Input Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:31:54 --> Language Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Loader Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Controller Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Model Class Initialized
DEBUG - 2011-09-01 13:31:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:31:54 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:31:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:31:55 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:31:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:31:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:31:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:31:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:31:55 --> Final output sent to browser
DEBUG - 2011-09-01 13:31:55 --> Total execution time: 0.4795
DEBUG - 2011-09-01 13:32:12 --> Config Class Initialized
DEBUG - 2011-09-01 13:32:12 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:32:12 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:32:12 --> URI Class Initialized
DEBUG - 2011-09-01 13:32:12 --> Router Class Initialized
ERROR - 2011-09-01 13:32:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:32:20 --> Config Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:32:20 --> URI Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Router Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Output Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Input Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:32:20 --> Language Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Loader Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Controller Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:32:20 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:32:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:32:20 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:32:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:32:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:32:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:32:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:32:20 --> Final output sent to browser
DEBUG - 2011-09-01 13:32:20 --> Total execution time: 0.6291
DEBUG - 2011-09-01 13:32:31 --> Config Class Initialized
DEBUG - 2011-09-01 13:32:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:32:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:32:31 --> URI Class Initialized
DEBUG - 2011-09-01 13:32:31 --> Router Class Initialized
ERROR - 2011-09-01 13:32:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:32:52 --> Config Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:32:52 --> URI Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Router Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Output Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Input Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:32:52 --> Language Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Loader Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Controller Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Model Class Initialized
DEBUG - 2011-09-01 13:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:32:52 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:32:52 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:32:52 --> Final output sent to browser
DEBUG - 2011-09-01 13:32:52 --> Total execution time: 0.5525
DEBUG - 2011-09-01 13:33:02 --> Config Class Initialized
DEBUG - 2011-09-01 13:33:02 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:33:02 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:33:02 --> URI Class Initialized
DEBUG - 2011-09-01 13:33:02 --> Router Class Initialized
ERROR - 2011-09-01 13:33:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:33:44 --> Config Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:33:44 --> URI Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Router Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Output Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Input Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:33:44 --> Language Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Loader Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Controller Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Model Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Model Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Model Class Initialized
DEBUG - 2011-09-01 13:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:33:44 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:33:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:33:44 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:33:44 --> Final output sent to browser
DEBUG - 2011-09-01 13:33:44 --> Total execution time: 0.2413
DEBUG - 2011-09-01 13:33:51 --> Config Class Initialized
DEBUG - 2011-09-01 13:33:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:33:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:33:51 --> URI Class Initialized
DEBUG - 2011-09-01 13:33:51 --> Router Class Initialized
ERROR - 2011-09-01 13:33:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:34:07 --> Config Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:34:07 --> URI Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Router Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Output Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Input Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:34:07 --> Language Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Loader Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Controller Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:34:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:34:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:34:07 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:34:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:34:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:34:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:34:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:34:07 --> Final output sent to browser
DEBUG - 2011-09-01 13:34:07 --> Total execution time: 0.3158
DEBUG - 2011-09-01 13:34:13 --> Config Class Initialized
DEBUG - 2011-09-01 13:34:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:34:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:34:13 --> URI Class Initialized
DEBUG - 2011-09-01 13:34:13 --> Router Class Initialized
ERROR - 2011-09-01 13:34:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:34:28 --> Config Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:34:28 --> URI Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Router Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Output Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Input Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:34:28 --> Language Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Loader Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Controller Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:34:28 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:34:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:34:28 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:34:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:34:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:34:28 --> Final output sent to browser
DEBUG - 2011-09-01 13:34:28 --> Total execution time: 0.1152
DEBUG - 2011-09-01 13:34:36 --> Config Class Initialized
DEBUG - 2011-09-01 13:34:36 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:34:36 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:34:36 --> URI Class Initialized
DEBUG - 2011-09-01 13:34:36 --> Router Class Initialized
ERROR - 2011-09-01 13:34:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 13:34:51 --> Config Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:34:51 --> URI Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Router Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Output Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Input Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 13:34:51 --> Language Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Loader Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Controller Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Model Class Initialized
DEBUG - 2011-09-01 13:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 13:34:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 13:34:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 13:34:51 --> Helper loaded: url_helper
DEBUG - 2011-09-01 13:34:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 13:34:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 13:34:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 13:34:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 13:34:51 --> Final output sent to browser
DEBUG - 2011-09-01 13:34:51 --> Total execution time: 0.0451
DEBUG - 2011-09-01 13:35:08 --> Config Class Initialized
DEBUG - 2011-09-01 13:35:08 --> Hooks Class Initialized
DEBUG - 2011-09-01 13:35:08 --> Utf8 Class Initialized
DEBUG - 2011-09-01 13:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 13:35:08 --> URI Class Initialized
DEBUG - 2011-09-01 13:35:08 --> Router Class Initialized
ERROR - 2011-09-01 13:35:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:06:10 --> Config Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:06:10 --> URI Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Router Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Output Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Input Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:06:10 --> Language Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Loader Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Controller Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:06:10 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:06:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 14:06:11 --> Helper loaded: url_helper
DEBUG - 2011-09-01 14:06:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 14:06:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 14:06:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 14:06:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 14:06:11 --> Final output sent to browser
DEBUG - 2011-09-01 14:06:11 --> Total execution time: 0.6312
DEBUG - 2011-09-01 14:06:16 --> Config Class Initialized
DEBUG - 2011-09-01 14:06:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:06:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:06:16 --> URI Class Initialized
DEBUG - 2011-09-01 14:06:16 --> Router Class Initialized
ERROR - 2011-09-01 14:06:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:06:17 --> Config Class Initialized
DEBUG - 2011-09-01 14:06:17 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:06:17 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:06:17 --> URI Class Initialized
DEBUG - 2011-09-01 14:06:17 --> Router Class Initialized
ERROR - 2011-09-01 14:06:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:06:51 --> Config Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:06:51 --> URI Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Router Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Output Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Input Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:06:51 --> Language Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Loader Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Controller Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Model Class Initialized
DEBUG - 2011-09-01 14:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:06:51 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:06:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 14:06:51 --> Helper loaded: url_helper
DEBUG - 2011-09-01 14:06:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 14:06:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 14:06:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 14:06:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 14:06:51 --> Final output sent to browser
DEBUG - 2011-09-01 14:06:51 --> Total execution time: 0.0565
DEBUG - 2011-09-01 14:06:52 --> Config Class Initialized
DEBUG - 2011-09-01 14:06:52 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:06:52 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:06:52 --> URI Class Initialized
DEBUG - 2011-09-01 14:06:52 --> Router Class Initialized
ERROR - 2011-09-01 14:06:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:33:18 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:18 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Router Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Output Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Input Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:33:18 --> Language Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Loader Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Controller Class Initialized
ERROR - 2011-09-01 14:33:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 14:33:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 14:33:18 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 14:33:18 --> Helper loaded: url_helper
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 14:33:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 14:33:18 --> Final output sent to browser
DEBUG - 2011-09-01 14:33:18 --> Total execution time: 0.0291
DEBUG - 2011-09-01 14:33:18 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:18 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Router Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Output Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Input Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:33:18 --> Language Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Loader Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Controller Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:33:18 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Final output sent to browser
DEBUG - 2011-09-01 14:33:19 --> Total execution time: 0.7121
DEBUG - 2011-09-01 14:33:19 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:19 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Router Class Initialized
ERROR - 2011-09-01 14:33:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:33:19 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:19 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Router Class Initialized
ERROR - 2011-09-01 14:33:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:33:19 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:19 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:19 --> Router Class Initialized
ERROR - 2011-09-01 14:33:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 14:33:37 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:37 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Router Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Output Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Input Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:33:37 --> Language Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Loader Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Controller Class Initialized
ERROR - 2011-09-01 14:33:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 14:33:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 14:33:37 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:33:37 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 14:33:37 --> Helper loaded: url_helper
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 14:33:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 14:33:37 --> Final output sent to browser
DEBUG - 2011-09-01 14:33:37 --> Total execution time: 0.0277
DEBUG - 2011-09-01 14:33:37 --> Config Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:33:37 --> URI Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Router Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Output Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Input Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:33:37 --> Language Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Loader Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Controller Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Model Class Initialized
DEBUG - 2011-09-01 14:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:33:37 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:33:38 --> Final output sent to browser
DEBUG - 2011-09-01 14:33:38 --> Total execution time: 0.7338
DEBUG - 2011-09-01 14:45:07 --> Config Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:45:07 --> URI Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Router Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Output Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Input Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 14:45:07 --> Language Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Loader Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Controller Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Model Class Initialized
DEBUG - 2011-09-01 14:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 14:45:07 --> Database Driver Class Initialized
DEBUG - 2011-09-01 14:45:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 14:45:08 --> Helper loaded: url_helper
DEBUG - 2011-09-01 14:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 14:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 14:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 14:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 14:45:08 --> Final output sent to browser
DEBUG - 2011-09-01 14:45:08 --> Total execution time: 0.8092
DEBUG - 2011-09-01 14:45:10 --> Config Class Initialized
DEBUG - 2011-09-01 14:45:10 --> Hooks Class Initialized
DEBUG - 2011-09-01 14:45:10 --> Utf8 Class Initialized
DEBUG - 2011-09-01 14:45:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 14:45:10 --> URI Class Initialized
DEBUG - 2011-09-01 14:45:10 --> Router Class Initialized
ERROR - 2011-09-01 14:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 15:18:16 --> Config Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:18:16 --> URI Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Router Class Initialized
DEBUG - 2011-09-01 15:18:16 --> No URI present. Default controller set.
DEBUG - 2011-09-01 15:18:16 --> Output Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Input Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 15:18:16 --> Language Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Loader Class Initialized
DEBUG - 2011-09-01 15:18:16 --> Controller Class Initialized
DEBUG - 2011-09-01 15:18:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 15:18:16 --> Helper loaded: url_helper
DEBUG - 2011-09-01 15:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 15:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 15:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 15:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 15:18:16 --> Final output sent to browser
DEBUG - 2011-09-01 15:18:16 --> Total execution time: 0.0804
DEBUG - 2011-09-01 15:25:57 --> Config Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:25:57 --> URI Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Router Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Output Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Input Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 15:25:57 --> Language Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Loader Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Controller Class Initialized
ERROR - 2011-09-01 15:25:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 15:25:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 15:25:57 --> Model Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Model Class Initialized
DEBUG - 2011-09-01 15:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 15:25:57 --> Database Driver Class Initialized
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 15:25:57 --> Helper loaded: url_helper
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 15:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 15:25:57 --> Final output sent to browser
DEBUG - 2011-09-01 15:25:57 --> Total execution time: 0.0455
DEBUG - 2011-09-01 15:25:59 --> Config Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:25:59 --> URI Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Router Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Output Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Input Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 15:25:59 --> Language Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Loader Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Controller Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Model Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Model Class Initialized
DEBUG - 2011-09-01 15:25:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 15:25:59 --> Database Driver Class Initialized
DEBUG - 2011-09-01 15:26:00 --> Final output sent to browser
DEBUG - 2011-09-01 15:26:00 --> Total execution time: 0.7864
DEBUG - 2011-09-01 15:26:01 --> Config Class Initialized
DEBUG - 2011-09-01 15:26:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:26:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:26:01 --> URI Class Initialized
DEBUG - 2011-09-01 15:26:01 --> Router Class Initialized
ERROR - 2011-09-01 15:26:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 15:26:29 --> Config Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:26:29 --> URI Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Router Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Output Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Input Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 15:26:29 --> Language Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Loader Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Controller Class Initialized
ERROR - 2011-09-01 15:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 15:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 15:26:29 --> Model Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Model Class Initialized
DEBUG - 2011-09-01 15:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 15:26:29 --> Database Driver Class Initialized
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 15:26:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 15:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 15:26:29 --> Final output sent to browser
DEBUG - 2011-09-01 15:26:29 --> Total execution time: 0.0309
DEBUG - 2011-09-01 15:26:30 --> Config Class Initialized
DEBUG - 2011-09-01 15:26:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:26:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:26:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:26:30 --> URI Class Initialized
DEBUG - 2011-09-01 15:26:30 --> Router Class Initialized
ERROR - 2011-09-01 15:26:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 15:26:31 --> Config Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 15:26:31 --> URI Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Router Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Output Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Input Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 15:26:31 --> Language Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Loader Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Controller Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Model Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Model Class Initialized
DEBUG - 2011-09-01 15:26:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 15:26:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 15:26:32 --> Final output sent to browser
DEBUG - 2011-09-01 15:26:32 --> Total execution time: 0.5748
DEBUG - 2011-09-01 16:32:14 --> Config Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Hooks Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Utf8 Class Initialized
DEBUG - 2011-09-01 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 16:32:14 --> URI Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Router Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Output Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Input Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 16:32:14 --> Language Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Loader Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Controller Class Initialized
ERROR - 2011-09-01 16:32:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 16:32:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 16:32:14 --> Model Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Model Class Initialized
DEBUG - 2011-09-01 16:32:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 16:32:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 16:32:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 16:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 16:32:14 --> Final output sent to browser
DEBUG - 2011-09-01 16:32:14 --> Total execution time: 0.0349
DEBUG - 2011-09-01 16:44:33 --> Config Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 16:44:33 --> URI Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Router Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Output Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Input Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 16:44:33 --> Language Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Loader Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Controller Class Initialized
ERROR - 2011-09-01 16:44:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 16:44:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 16:44:33 --> Model Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Model Class Initialized
DEBUG - 2011-09-01 16:44:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 16:44:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 16:44:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 16:44:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 16:44:33 --> Final output sent to browser
DEBUG - 2011-09-01 16:44:33 --> Total execution time: 0.0330
DEBUG - 2011-09-01 16:44:35 --> Config Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 16:44:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 16:44:35 --> URI Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Router Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Output Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Input Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 16:44:35 --> Language Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Loader Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Controller Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Model Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Model Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 16:44:35 --> Database Driver Class Initialized
DEBUG - 2011-09-01 16:44:35 --> Final output sent to browser
DEBUG - 2011-09-01 16:44:35 --> Total execution time: 0.7446
DEBUG - 2011-09-01 17:00:33 --> Config Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Hooks Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Utf8 Class Initialized
DEBUG - 2011-09-01 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 17:00:33 --> URI Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Router Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Output Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Input Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 17:00:33 --> Language Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Loader Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Controller Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Model Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Model Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Model Class Initialized
DEBUG - 2011-09-01 17:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 17:00:33 --> Database Driver Class Initialized
DEBUG - 2011-09-01 17:00:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 17:00:33 --> Helper loaded: url_helper
DEBUG - 2011-09-01 17:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 17:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 17:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 17:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 17:00:33 --> Final output sent to browser
DEBUG - 2011-09-01 17:00:33 --> Total execution time: 0.2263
DEBUG - 2011-09-01 17:00:35 --> Config Class Initialized
DEBUG - 2011-09-01 17:00:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 17:00:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 17:00:35 --> URI Class Initialized
DEBUG - 2011-09-01 17:00:35 --> Router Class Initialized
ERROR - 2011-09-01 17:00:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 17:26:23 --> Config Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Hooks Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Utf8 Class Initialized
DEBUG - 2011-09-01 17:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 17:26:23 --> URI Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Router Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Output Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Input Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 17:26:23 --> Language Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Loader Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Controller Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Model Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Model Class Initialized
DEBUG - 2011-09-01 17:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 17:26:23 --> Database Driver Class Initialized
DEBUG - 2011-09-01 17:26:24 --> Final output sent to browser
DEBUG - 2011-09-01 17:26:24 --> Total execution time: 0.5664
DEBUG - 2011-09-01 18:38:43 --> Config Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 18:38:43 --> URI Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Router Class Initialized
ERROR - 2011-09-01 18:38:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 18:38:43 --> Config Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Hooks Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Utf8 Class Initialized
DEBUG - 2011-09-01 18:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 18:38:43 --> URI Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Router Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Output Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Input Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 18:38:43 --> Language Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Loader Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Controller Class Initialized
ERROR - 2011-09-01 18:38:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 18:38:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 18:38:43 --> Model Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Model Class Initialized
DEBUG - 2011-09-01 18:38:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 18:38:43 --> Database Driver Class Initialized
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 18:38:43 --> Helper loaded: url_helper
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 18:38:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 18:38:43 --> Final output sent to browser
DEBUG - 2011-09-01 18:38:43 --> Total execution time: 0.0681
DEBUG - 2011-09-01 18:43:25 --> Config Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Hooks Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Utf8 Class Initialized
DEBUG - 2011-09-01 18:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 18:43:25 --> URI Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Router Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Output Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Input Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 18:43:25 --> Language Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Loader Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Controller Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Model Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Model Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 18:43:25 --> Database Driver Class Initialized
DEBUG - 2011-09-01 18:43:25 --> Final output sent to browser
DEBUG - 2011-09-01 18:43:25 --> Total execution time: 0.5477
DEBUG - 2011-09-01 19:17:29 --> Config Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 19:17:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 19:17:29 --> URI Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Router Class Initialized
DEBUG - 2011-09-01 19:17:29 --> No URI present. Default controller set.
DEBUG - 2011-09-01 19:17:29 --> Output Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Input Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 19:17:29 --> Language Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Loader Class Initialized
DEBUG - 2011-09-01 19:17:29 --> Controller Class Initialized
DEBUG - 2011-09-01 19:17:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 19:17:30 --> Helper loaded: url_helper
DEBUG - 2011-09-01 19:17:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 19:17:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 19:17:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 19:17:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 19:17:30 --> Final output sent to browser
DEBUG - 2011-09-01 19:17:30 --> Total execution time: 0.6085
DEBUG - 2011-09-01 20:01:38 --> Config Class Initialized
DEBUG - 2011-09-01 20:01:38 --> Hooks Class Initialized
DEBUG - 2011-09-01 20:01:38 --> Utf8 Class Initialized
DEBUG - 2011-09-01 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 20:01:38 --> URI Class Initialized
DEBUG - 2011-09-01 20:01:38 --> Router Class Initialized
ERROR - 2011-09-01 20:01:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 21:07:01 --> Config Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:07:01 --> URI Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Router Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Output Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Input Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 21:07:01 --> Language Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Loader Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Controller Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Model Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Model Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Model Class Initialized
DEBUG - 2011-09-01 21:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 21:07:01 --> Database Driver Class Initialized
DEBUG - 2011-09-01 21:07:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-09-01 21:07:02 --> Helper loaded: url_helper
DEBUG - 2011-09-01 21:07:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 21:07:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 21:07:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 21:07:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 21:07:02 --> Final output sent to browser
DEBUG - 2011-09-01 21:07:02 --> Total execution time: 0.8245
DEBUG - 2011-09-01 21:07:04 --> Config Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:07:04 --> URI Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Router Class Initialized
ERROR - 2011-09-01 21:07:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 21:07:04 --> Config Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:07:04 --> URI Class Initialized
DEBUG - 2011-09-01 21:07:04 --> Router Class Initialized
ERROR - 2011-09-01 21:07:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 21:07:05 --> Config Class Initialized
DEBUG - 2011-09-01 21:07:05 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:07:05 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:07:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:07:05 --> URI Class Initialized
DEBUG - 2011-09-01 21:07:05 --> Router Class Initialized
ERROR - 2011-09-01 21:07:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-09-01 21:17:45 --> Config Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:17:45 --> URI Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Router Class Initialized
ERROR - 2011-09-01 21:17:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-09-01 21:17:45 --> Config Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Hooks Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Utf8 Class Initialized
DEBUG - 2011-09-01 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 21:17:45 --> URI Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Router Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Output Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Input Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 21:17:45 --> Language Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Loader Class Initialized
DEBUG - 2011-09-01 21:17:45 --> Controller Class Initialized
ERROR - 2011-09-01 21:17:45 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-09-01 22:13:34 --> Config Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:13:34 --> URI Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Router Class Initialized
DEBUG - 2011-09-01 22:13:34 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:13:34 --> Output Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Input Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:13:34 --> Language Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Loader Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Controller Class Initialized
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:13:34 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:13:34 --> Config Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:13:34 --> URI Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Router Class Initialized
DEBUG - 2011-09-01 22:13:34 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:13:34 --> Output Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Input Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:13:34 --> Language Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Loader Class Initialized
DEBUG - 2011-09-01 22:13:34 --> Controller Class Initialized
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:13:34 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:13:34 --> Final output sent to browser
DEBUG - 2011-09-01 22:13:34 --> Total execution time: 0.0132
DEBUG - 2011-09-01 22:13:35 --> Config Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:13:35 --> URI Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Router Class Initialized
DEBUG - 2011-09-01 22:13:35 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:13:35 --> Output Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Input Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:13:35 --> Language Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Loader Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Controller Class Initialized
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:13:35 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:13:35 --> Final output sent to browser
DEBUG - 2011-09-01 22:13:35 --> Total execution time: 0.0204
DEBUG - 2011-09-01 22:13:35 --> Config Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:13:35 --> URI Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Router Class Initialized
DEBUG - 2011-09-01 22:13:35 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:13:35 --> Output Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Input Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:13:35 --> Language Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Loader Class Initialized
DEBUG - 2011-09-01 22:13:35 --> Controller Class Initialized
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:13:35 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:13:35 --> Final output sent to browser
DEBUG - 2011-09-01 22:13:35 --> Total execution time: 0.0337
DEBUG - 2011-09-01 22:15:13 --> Config Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:15:13 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:15:13 --> URI Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Router Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Output Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Input Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:15:13 --> Language Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Loader Class Initialized
DEBUG - 2011-09-01 22:15:13 --> Controller Class Initialized
ERROR - 2011-09-01 22:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 22:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 22:15:14 --> Model Class Initialized
DEBUG - 2011-09-01 22:15:14 --> Model Class Initialized
DEBUG - 2011-09-01 22:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 22:15:14 --> Database Driver Class Initialized
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 22:15:14 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:15:14 --> Final output sent to browser
DEBUG - 2011-09-01 22:15:14 --> Total execution time: 0.8529
DEBUG - 2011-09-01 22:15:16 --> Config Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:15:16 --> URI Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Router Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Output Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Input Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:15:16 --> Language Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Loader Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Controller Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Model Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Model Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 22:15:16 --> Database Driver Class Initialized
DEBUG - 2011-09-01 22:15:16 --> Final output sent to browser
DEBUG - 2011-09-01 22:15:16 --> Total execution time: 0.5502
DEBUG - 2011-09-01 22:20:29 --> Config Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:20:29 --> URI Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Router Class Initialized
DEBUG - 2011-09-01 22:20:29 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:20:29 --> Output Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Input Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:20:29 --> Language Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Loader Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Controller Class Initialized
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:20:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:20:29 --> Config Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:20:29 --> URI Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Router Class Initialized
DEBUG - 2011-09-01 22:20:29 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:20:29 --> Output Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Input Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:20:29 --> Language Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Loader Class Initialized
DEBUG - 2011-09-01 22:20:29 --> Controller Class Initialized
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:20:29 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:20:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:20:29 --> Final output sent to browser
DEBUG - 2011-09-01 22:20:29 --> Total execution time: 0.0132
DEBUG - 2011-09-01 22:20:30 --> Config Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:20:30 --> URI Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Router Class Initialized
DEBUG - 2011-09-01 22:20:30 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:20:30 --> Output Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Input Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:20:30 --> Language Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Loader Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Controller Class Initialized
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:20:30 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:20:30 --> Final output sent to browser
DEBUG - 2011-09-01 22:20:30 --> Total execution time: 0.0195
DEBUG - 2011-09-01 22:20:30 --> Config Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:20:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:20:30 --> URI Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Router Class Initialized
DEBUG - 2011-09-01 22:20:30 --> No URI present. Default controller set.
DEBUG - 2011-09-01 22:20:30 --> Output Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Input Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:20:30 --> Language Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Loader Class Initialized
DEBUG - 2011-09-01 22:20:30 --> Controller Class Initialized
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-09-01 22:20:30 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:20:30 --> Final output sent to browser
DEBUG - 2011-09-01 22:20:30 --> Total execution time: 0.0203
DEBUG - 2011-09-01 22:36:31 --> Config Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Hooks Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Utf8 Class Initialized
DEBUG - 2011-09-01 22:36:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-01 22:36:31 --> URI Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Router Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Output Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Input Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-01 22:36:31 --> Language Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Loader Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Controller Class Initialized
ERROR - 2011-09-01 22:36:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-09-01 22:36:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 22:36:31 --> Model Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Model Class Initialized
DEBUG - 2011-09-01 22:36:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-09-01 22:36:31 --> Database Driver Class Initialized
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-09-01 22:36:31 --> Helper loaded: url_helper
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-09-01 22:36:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-09-01 22:36:31 --> Final output sent to browser
DEBUG - 2011-09-01 22:36:31 --> Total execution time: 0.0435

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-27 01:15:53 --> Config Class Initialized
DEBUG - 2011-06-27 01:15:53 --> Hooks Class Initialized
DEBUG - 2011-06-27 01:15:53 --> Utf8 Class Initialized
DEBUG - 2011-06-27 01:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 01:15:53 --> URI Class Initialized
DEBUG - 2011-06-27 01:15:53 --> Router Class Initialized
DEBUG - 2011-06-27 01:15:54 --> Output Class Initialized
DEBUG - 2011-06-27 01:15:54 --> Input Class Initialized
DEBUG - 2011-06-27 01:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 01:15:55 --> Language Class Initialized
DEBUG - 2011-06-27 01:15:55 --> Loader Class Initialized
DEBUG - 2011-06-27 01:15:55 --> Controller Class Initialized
DEBUG - 2011-06-27 01:15:56 --> Model Class Initialized
DEBUG - 2011-06-27 01:15:56 --> Model Class Initialized
DEBUG - 2011-06-27 01:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 01:15:57 --> Database Driver Class Initialized
DEBUG - 2011-06-27 01:15:58 --> Final output sent to browser
DEBUG - 2011-06-27 01:15:58 --> Total execution time: 5.6155
DEBUG - 2011-06-27 02:02:02 --> Config Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Utf8 Class Initialized
DEBUG - 2011-06-27 02:02:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 02:02:02 --> URI Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Router Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Output Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Input Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 02:02:02 --> Language Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Loader Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Controller Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Model Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Model Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Model Class Initialized
DEBUG - 2011-06-27 02:02:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 02:02:02 --> Database Driver Class Initialized
DEBUG - 2011-06-27 02:02:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 02:02:06 --> Helper loaded: url_helper
DEBUG - 2011-06-27 02:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 02:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 02:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 02:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 02:02:06 --> Final output sent to browser
DEBUG - 2011-06-27 02:02:06 --> Total execution time: 4.5094
DEBUG - 2011-06-27 02:02:08 --> Config Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Hooks Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Utf8 Class Initialized
DEBUG - 2011-06-27 02:02:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 02:02:08 --> URI Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Router Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Output Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Input Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 02:02:08 --> Language Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Loader Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Controller Class Initialized
ERROR - 2011-06-27 02:02:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 02:02:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 02:02:08 --> Model Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Model Class Initialized
DEBUG - 2011-06-27 02:02:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 02:02:08 --> Database Driver Class Initialized
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 02:02:08 --> Helper loaded: url_helper
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 02:02:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 02:02:08 --> Final output sent to browser
DEBUG - 2011-06-27 02:02:08 --> Total execution time: 0.1082
DEBUG - 2011-06-27 02:26:54 --> Config Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Hooks Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Utf8 Class Initialized
DEBUG - 2011-06-27 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 02:26:54 --> URI Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Router Class Initialized
ERROR - 2011-06-27 02:26:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 02:26:54 --> Config Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Hooks Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Utf8 Class Initialized
DEBUG - 2011-06-27 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 02:26:54 --> URI Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Router Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Output Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Input Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 02:26:54 --> Language Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Loader Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Controller Class Initialized
ERROR - 2011-06-27 02:26:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 02:26:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 02:26:54 --> Model Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Model Class Initialized
DEBUG - 2011-06-27 02:26:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 02:26:54 --> Database Driver Class Initialized
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 02:26:54 --> Helper loaded: url_helper
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 02:26:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 02:26:54 --> Final output sent to browser
DEBUG - 2011-06-27 02:26:54 --> Total execution time: 0.2761
DEBUG - 2011-06-27 03:13:02 --> Config Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:13:02 --> URI Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Router Class Initialized
ERROR - 2011-06-27 03:13:02 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 03:13:02 --> Config Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:13:02 --> URI Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Router Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Output Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Input Class Initialized
DEBUG - 2011-06-27 03:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 03:13:02 --> Language Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Loader Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Controller Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Model Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Model Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Model Class Initialized
DEBUG - 2011-06-27 03:13:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 03:13:03 --> Database Driver Class Initialized
DEBUG - 2011-06-27 03:13:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 03:13:03 --> Helper loaded: url_helper
DEBUG - 2011-06-27 03:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 03:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 03:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 03:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 03:13:04 --> Final output sent to browser
DEBUG - 2011-06-27 03:13:04 --> Total execution time: 1.1024
DEBUG - 2011-06-27 03:24:45 --> Config Class Initialized
DEBUG - 2011-06-27 03:24:45 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:24:45 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:24:45 --> URI Class Initialized
DEBUG - 2011-06-27 03:24:45 --> Router Class Initialized
ERROR - 2011-06-27 03:24:46 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 03:24:46 --> Config Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:24:46 --> URI Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Router Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Output Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Input Class Initialized
DEBUG - 2011-06-27 03:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 03:24:46 --> Language Class Initialized
DEBUG - 2011-06-27 03:24:47 --> Loader Class Initialized
DEBUG - 2011-06-27 03:24:47 --> Controller Class Initialized
ERROR - 2011-06-27 03:24:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 03:24:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 03:24:48 --> Model Class Initialized
DEBUG - 2011-06-27 03:24:48 --> Model Class Initialized
DEBUG - 2011-06-27 03:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 03:24:48 --> Database Driver Class Initialized
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 03:24:48 --> Helper loaded: url_helper
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 03:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 03:24:48 --> Final output sent to browser
DEBUG - 2011-06-27 03:24:48 --> Total execution time: 2.3621
DEBUG - 2011-06-27 03:38:43 --> Config Class Initialized
DEBUG - 2011-06-27 03:38:43 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:38:43 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:38:43 --> URI Class Initialized
DEBUG - 2011-06-27 03:38:43 --> Router Class Initialized
ERROR - 2011-06-27 03:38:43 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 03:38:44 --> Config Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Hooks Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Utf8 Class Initialized
DEBUG - 2011-06-27 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 03:38:44 --> URI Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Router Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Output Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Input Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 03:38:44 --> Language Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Loader Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Controller Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Model Class Initialized
DEBUG - 2011-06-27 03:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 03:38:44 --> Database Driver Class Initialized
DEBUG - 2011-06-27 03:39:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 03:39:00 --> Helper loaded: url_helper
DEBUG - 2011-06-27 03:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 03:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 03:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 03:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 03:39:00 --> Final output sent to browser
DEBUG - 2011-06-27 03:39:00 --> Total execution time: 16.5040
DEBUG - 2011-06-27 07:48:54 --> Config Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:48:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:48:54 --> URI Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Router Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Output Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Input Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:48:54 --> Language Class Initialized
DEBUG - 2011-06-27 07:48:54 --> Loader Class Initialized
DEBUG - 2011-06-27 07:48:55 --> Controller Class Initialized
ERROR - 2011-06-27 07:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:48:55 --> Model Class Initialized
DEBUG - 2011-06-27 07:48:55 --> Model Class Initialized
DEBUG - 2011-06-27 07:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:48:55 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:48:55 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:48:55 --> Final output sent to browser
DEBUG - 2011-06-27 07:48:55 --> Total execution time: 0.9897
DEBUG - 2011-06-27 07:48:56 --> Config Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:48:56 --> URI Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Router Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Output Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Input Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:48:56 --> Language Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Loader Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Controller Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Model Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Model Class Initialized
DEBUG - 2011-06-27 07:48:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:48:56 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:48:57 --> Final output sent to browser
DEBUG - 2011-06-27 07:48:57 --> Total execution time: 0.6773
DEBUG - 2011-06-27 07:48:58 --> Config Class Initialized
DEBUG - 2011-06-27 07:48:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:48:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:48:58 --> URI Class Initialized
DEBUG - 2011-06-27 07:48:58 --> Router Class Initialized
ERROR - 2011-06-27 07:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:49:47 --> Config Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:49:47 --> URI Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Router Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Output Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Input Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:49:47 --> Language Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Loader Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Controller Class Initialized
ERROR - 2011-06-27 07:49:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:49:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:49:47 --> Model Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Model Class Initialized
DEBUG - 2011-06-27 07:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:49:47 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:49:47 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:49:47 --> Final output sent to browser
DEBUG - 2011-06-27 07:49:47 --> Total execution time: 0.0309
DEBUG - 2011-06-27 07:49:48 --> Config Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:49:48 --> URI Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Router Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Output Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Input Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:49:48 --> Language Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Loader Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Controller Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Model Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Model Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:49:48 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:49:48 --> Final output sent to browser
DEBUG - 2011-06-27 07:49:48 --> Total execution time: 0.6739
DEBUG - 2011-06-27 07:49:49 --> Config Class Initialized
DEBUG - 2011-06-27 07:49:49 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:49:49 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:49:49 --> URI Class Initialized
DEBUG - 2011-06-27 07:49:49 --> Router Class Initialized
ERROR - 2011-06-27 07:49:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:50:39 --> Config Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:50:39 --> URI Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Router Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Output Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Input Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:50:39 --> Language Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Loader Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Controller Class Initialized
ERROR - 2011-06-27 07:50:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:50:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:50:39 --> Model Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Model Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:50:39 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:50:39 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:50:39 --> Final output sent to browser
DEBUG - 2011-06-27 07:50:39 --> Total execution time: 0.0345
DEBUG - 2011-06-27 07:50:39 --> Config Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:50:39 --> URI Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Router Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Output Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Input Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:50:39 --> Language Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Loader Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Controller Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Model Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Model Class Initialized
DEBUG - 2011-06-27 07:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:50:39 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:50:40 --> Final output sent to browser
DEBUG - 2011-06-27 07:50:40 --> Total execution time: 0.5046
DEBUG - 2011-06-27 07:50:41 --> Config Class Initialized
DEBUG - 2011-06-27 07:50:41 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:50:41 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:50:41 --> URI Class Initialized
DEBUG - 2011-06-27 07:50:41 --> Router Class Initialized
ERROR - 2011-06-27 07:50:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:51:01 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:01 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:01 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:01 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:01 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:01 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:01 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:01 --> Total execution time: 0.0403
DEBUG - 2011-06-27 07:51:02 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:02 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:02 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Controller Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:02 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:03 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:03 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:03 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:03 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:03 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:03 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:03 --> Total execution time: 0.0378
DEBUG - 2011-06-27 07:51:03 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:03 --> Total execution time: 0.6344
DEBUG - 2011-06-27 07:51:04 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:04 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:04 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:04 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:04 --> Router Class Initialized
ERROR - 2011-06-27 07:51:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:51:16 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:16 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:16 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:16 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:16 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:16 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:16 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:16 --> Total execution time: 0.0295
DEBUG - 2011-06-27 07:51:17 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:17 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:17 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Controller Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:17 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:17 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:17 --> Total execution time: 0.5103
DEBUG - 2011-06-27 07:51:18 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:18 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:18 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:18 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:18 --> Router Class Initialized
ERROR - 2011-06-27 07:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:51:34 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:34 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:34 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:34 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:34 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:34 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:34 --> Total execution time: 0.0681
DEBUG - 2011-06-27 07:51:34 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:34 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:34 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Controller Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:34 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:35 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:35 --> Total execution time: 0.6607
DEBUG - 2011-06-27 07:51:36 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:36 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:36 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:36 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:36 --> Router Class Initialized
ERROR - 2011-06-27 07:51:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:51:47 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:47 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:47 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:47 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:47 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:47 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:47 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:47 --> Total execution time: 0.0315
DEBUG - 2011-06-27 07:51:48 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:48 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:48 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Controller Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:48 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:48 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:48 --> Total execution time: 0.5296
DEBUG - 2011-06-27 07:51:49 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:49 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:49 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:49 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:49 --> Router Class Initialized
ERROR - 2011-06-27 07:51:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:51:58 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:58 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:58 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Controller Class Initialized
ERROR - 2011-06-27 07:51:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:51:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:58 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:58 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:51:58 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:51:58 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:58 --> Total execution time: 0.0308
DEBUG - 2011-06-27 07:51:59 --> Config Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:51:59 --> URI Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Router Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Output Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Input Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:51:59 --> Language Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Loader Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Controller Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Model Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:51:59 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:51:59 --> Final output sent to browser
DEBUG - 2011-06-27 07:51:59 --> Total execution time: 0.5439
DEBUG - 2011-06-27 07:52:01 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:01 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:01 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:01 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:01 --> Router Class Initialized
ERROR - 2011-06-27 07:52:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:52:02 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:02 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:02 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Controller Class Initialized
ERROR - 2011-06-27 07:52:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:52:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:02 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:02 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:02 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:52:02 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:02 --> Total execution time: 0.0336
DEBUG - 2011-06-27 07:52:06 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:06 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:06 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Controller Class Initialized
ERROR - 2011-06-27 07:52:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:52:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:06 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:06 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:06 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:52:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:52:06 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:06 --> Total execution time: 0.0290
DEBUG - 2011-06-27 07:52:06 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:06 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:06 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Controller Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:06 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:07 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:07 --> Total execution time: 0.5015
DEBUG - 2011-06-27 07:52:08 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:08 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:08 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:08 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:08 --> Router Class Initialized
ERROR - 2011-06-27 07:52:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:52:22 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:22 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:22 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Controller Class Initialized
ERROR - 2011-06-27 07:52:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:52:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:22 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:22 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:22 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:52:22 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:22 --> Total execution time: 0.0695
DEBUG - 2011-06-27 07:52:23 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:23 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:23 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Controller Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:23 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:24 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:24 --> Total execution time: 0.5497
DEBUG - 2011-06-27 07:52:25 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:25 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:25 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:25 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:25 --> Router Class Initialized
ERROR - 2011-06-27 07:52:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:52:29 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:29 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:29 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Controller Class Initialized
ERROR - 2011-06-27 07:52:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:52:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:29 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:29 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:52:29 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:52:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:52:29 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:29 --> Total execution time: 0.0279
DEBUG - 2011-06-27 07:52:30 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:30 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Router Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Output Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Input Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:52:30 --> Language Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Loader Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Controller Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Model Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:52:30 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:52:30 --> Final output sent to browser
DEBUG - 2011-06-27 07:52:30 --> Total execution time: 0.4917
DEBUG - 2011-06-27 07:52:31 --> Config Class Initialized
DEBUG - 2011-06-27 07:52:31 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:52:31 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:52:31 --> URI Class Initialized
DEBUG - 2011-06-27 07:52:31 --> Router Class Initialized
ERROR - 2011-06-27 07:52:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 07:54:03 --> Config Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:54:03 --> URI Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Router Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Output Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Input Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:54:03 --> Language Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Loader Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Controller Class Initialized
ERROR - 2011-06-27 07:54:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:54:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:03 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:54:03 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:03 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:54:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:54:03 --> Final output sent to browser
DEBUG - 2011-06-27 07:54:03 --> Total execution time: 0.0276
DEBUG - 2011-06-27 07:54:05 --> Config Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:54:05 --> URI Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Router Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Output Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Input Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:54:05 --> Language Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Loader Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Controller Class Initialized
ERROR - 2011-06-27 07:54:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:05 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:54:05 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:05 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:54:05 --> Final output sent to browser
DEBUG - 2011-06-27 07:54:05 --> Total execution time: 0.0274
DEBUG - 2011-06-27 07:54:08 --> Config Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:54:08 --> URI Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Router Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Output Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Input Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:54:08 --> Language Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Loader Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Controller Class Initialized
ERROR - 2011-06-27 07:54:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:54:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:08 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:54:08 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:08 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:54:08 --> Final output sent to browser
DEBUG - 2011-06-27 07:54:08 --> Total execution time: 0.0632
DEBUG - 2011-06-27 07:54:10 --> Config Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:54:10 --> URI Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Router Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Output Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Input Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:54:10 --> Language Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Loader Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Controller Class Initialized
ERROR - 2011-06-27 07:54:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:54:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:10 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:54:10 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:10 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:54:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:54:10 --> Final output sent to browser
DEBUG - 2011-06-27 07:54:10 --> Total execution time: 0.0276
DEBUG - 2011-06-27 07:54:12 --> Config Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Hooks Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Utf8 Class Initialized
DEBUG - 2011-06-27 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 07:54:12 --> URI Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Router Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Output Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Input Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 07:54:12 --> Language Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Loader Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Controller Class Initialized
ERROR - 2011-06-27 07:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 07:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:12 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Model Class Initialized
DEBUG - 2011-06-27 07:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 07:54:12 --> Database Driver Class Initialized
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 07:54:12 --> Helper loaded: url_helper
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 07:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 07:54:12 --> Final output sent to browser
DEBUG - 2011-06-27 07:54:12 --> Total execution time: 0.0293
DEBUG - 2011-06-27 08:11:22 --> Config Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Hooks Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Utf8 Class Initialized
DEBUG - 2011-06-27 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 08:11:22 --> URI Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Router Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Output Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Input Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 08:11:22 --> Language Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Loader Class Initialized
DEBUG - 2011-06-27 08:11:22 --> Controller Class Initialized
ERROR - 2011-06-27 08:11:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 08:11:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 08:11:23 --> Model Class Initialized
DEBUG - 2011-06-27 08:11:23 --> Model Class Initialized
DEBUG - 2011-06-27 08:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 08:11:23 --> Database Driver Class Initialized
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 08:11:23 --> Helper loaded: url_helper
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 08:11:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 08:11:23 --> Final output sent to browser
DEBUG - 2011-06-27 08:11:23 --> Total execution time: 0.5815
DEBUG - 2011-06-27 08:11:24 --> Config Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Hooks Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Utf8 Class Initialized
DEBUG - 2011-06-27 08:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 08:11:24 --> URI Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Router Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Output Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Input Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 08:11:24 --> Language Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Loader Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Controller Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Model Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Model Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 08:11:24 --> Database Driver Class Initialized
DEBUG - 2011-06-27 08:11:24 --> Final output sent to browser
DEBUG - 2011-06-27 08:11:24 --> Total execution time: 0.5575
DEBUG - 2011-06-27 08:11:29 --> Config Class Initialized
DEBUG - 2011-06-27 08:11:29 --> Hooks Class Initialized
DEBUG - 2011-06-27 08:11:29 --> Utf8 Class Initialized
DEBUG - 2011-06-27 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 08:11:29 --> URI Class Initialized
DEBUG - 2011-06-27 08:11:29 --> Router Class Initialized
ERROR - 2011-06-27 08:11:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 11:48:43 --> Config Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Hooks Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Utf8 Class Initialized
DEBUG - 2011-06-27 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 11:48:43 --> URI Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Router Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Output Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Input Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 11:48:43 --> Language Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Loader Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Controller Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 11:48:43 --> Database Driver Class Initialized
DEBUG - 2011-06-27 11:48:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 11:48:43 --> Helper loaded: url_helper
DEBUG - 2011-06-27 11:48:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 11:48:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 11:48:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 11:48:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 11:48:43 --> Final output sent to browser
DEBUG - 2011-06-27 11:48:43 --> Total execution time: 0.7731
DEBUG - 2011-06-27 11:48:46 --> Config Class Initialized
DEBUG - 2011-06-27 11:48:46 --> Hooks Class Initialized
DEBUG - 2011-06-27 11:48:46 --> Utf8 Class Initialized
DEBUG - 2011-06-27 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 11:48:46 --> URI Class Initialized
DEBUG - 2011-06-27 11:48:46 --> Router Class Initialized
ERROR - 2011-06-27 11:48:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 11:48:56 --> Config Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Hooks Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Utf8 Class Initialized
DEBUG - 2011-06-27 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 11:48:56 --> URI Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Router Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Output Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Input Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 11:48:56 --> Language Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Loader Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Controller Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Model Class Initialized
DEBUG - 2011-06-27 11:48:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 11:48:56 --> Database Driver Class Initialized
DEBUG - 2011-06-27 11:48:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 11:48:56 --> Helper loaded: url_helper
DEBUG - 2011-06-27 11:48:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 11:48:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 11:48:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 11:48:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 11:48:56 --> Final output sent to browser
DEBUG - 2011-06-27 11:48:56 --> Total execution time: 0.0575
DEBUG - 2011-06-27 11:48:58 --> Config Class Initialized
DEBUG - 2011-06-27 11:48:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 11:48:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 11:48:58 --> URI Class Initialized
DEBUG - 2011-06-27 11:48:58 --> Router Class Initialized
ERROR - 2011-06-27 11:48:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 11:49:37 --> Config Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Hooks Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Utf8 Class Initialized
DEBUG - 2011-06-27 11:49:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 11:49:37 --> URI Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Router Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Output Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Input Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 11:49:37 --> Language Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Loader Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Controller Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Model Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Model Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Model Class Initialized
DEBUG - 2011-06-27 11:49:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 11:49:37 --> Database Driver Class Initialized
DEBUG - 2011-06-27 11:49:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 11:49:37 --> Helper loaded: url_helper
DEBUG - 2011-06-27 11:49:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 11:49:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 11:49:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 11:49:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 11:49:37 --> Final output sent to browser
DEBUG - 2011-06-27 11:49:37 --> Total execution time: 0.0579
DEBUG - 2011-06-27 12:59:33 --> Config Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Hooks Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Utf8 Class Initialized
DEBUG - 2011-06-27 12:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 12:59:33 --> URI Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Router Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Output Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Input Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 12:59:33 --> Language Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Loader Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Controller Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Model Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Model Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Model Class Initialized
DEBUG - 2011-06-27 12:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 12:59:33 --> Database Driver Class Initialized
DEBUG - 2011-06-27 12:59:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 12:59:34 --> Helper loaded: url_helper
DEBUG - 2011-06-27 12:59:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 12:59:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 12:59:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 12:59:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 12:59:34 --> Final output sent to browser
DEBUG - 2011-06-27 12:59:34 --> Total execution time: 0.5900
DEBUG - 2011-06-27 12:59:36 --> Config Class Initialized
DEBUG - 2011-06-27 12:59:36 --> Hooks Class Initialized
DEBUG - 2011-06-27 12:59:36 --> Utf8 Class Initialized
DEBUG - 2011-06-27 12:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 12:59:36 --> URI Class Initialized
DEBUG - 2011-06-27 12:59:36 --> Router Class Initialized
ERROR - 2011-06-27 12:59:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 14:47:37 --> Config Class Initialized
DEBUG - 2011-06-27 14:47:37 --> Hooks Class Initialized
DEBUG - 2011-06-27 14:47:37 --> Utf8 Class Initialized
DEBUG - 2011-06-27 14:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 14:47:37 --> URI Class Initialized
DEBUG - 2011-06-27 14:47:37 --> Router Class Initialized
ERROR - 2011-06-27 14:47:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 14:56:01 --> Config Class Initialized
DEBUG - 2011-06-27 14:56:01 --> Hooks Class Initialized
DEBUG - 2011-06-27 14:56:01 --> Utf8 Class Initialized
DEBUG - 2011-06-27 14:56:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 14:56:01 --> URI Class Initialized
DEBUG - 2011-06-27 14:56:01 --> Router Class Initialized
DEBUG - 2011-06-27 14:56:02 --> Output Class Initialized
DEBUG - 2011-06-27 14:56:03 --> Input Class Initialized
DEBUG - 2011-06-27 14:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 14:56:04 --> Language Class Initialized
DEBUG - 2011-06-27 14:56:04 --> Loader Class Initialized
DEBUG - 2011-06-27 14:56:05 --> Controller Class Initialized
DEBUG - 2011-06-27 14:56:05 --> Model Class Initialized
DEBUG - 2011-06-27 14:56:05 --> Model Class Initialized
DEBUG - 2011-06-27 14:56:06 --> Model Class Initialized
DEBUG - 2011-06-27 14:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 14:56:07 --> Database Driver Class Initialized
DEBUG - 2011-06-27 14:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 14:56:08 --> Helper loaded: url_helper
DEBUG - 2011-06-27 14:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 14:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 14:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 14:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 14:56:08 --> Final output sent to browser
DEBUG - 2011-06-27 14:56:08 --> Total execution time: 7.2610
DEBUG - 2011-06-27 14:56:09 --> Config Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Hooks Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Utf8 Class Initialized
DEBUG - 2011-06-27 14:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 14:56:09 --> URI Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Router Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Output Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Input Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 14:56:09 --> Language Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Loader Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Controller Class Initialized
ERROR - 2011-06-27 14:56:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 14:56:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 14:56:09 --> Model Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Model Class Initialized
DEBUG - 2011-06-27 14:56:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 14:56:09 --> Database Driver Class Initialized
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 14:56:09 --> Helper loaded: url_helper
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 14:56:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 14:56:09 --> Final output sent to browser
DEBUG - 2011-06-27 14:56:09 --> Total execution time: 0.1428
DEBUG - 2011-06-27 16:11:08 --> Config Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Hooks Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Utf8 Class Initialized
DEBUG - 2011-06-27 16:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 16:11:08 --> URI Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Router Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Output Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Input Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 16:11:08 --> Language Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Loader Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Controller Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Model Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Model Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Model Class Initialized
DEBUG - 2011-06-27 16:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 16:11:08 --> Database Driver Class Initialized
DEBUG - 2011-06-27 16:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 16:11:08 --> Helper loaded: url_helper
DEBUG - 2011-06-27 16:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 16:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 16:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 16:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 16:11:08 --> Final output sent to browser
DEBUG - 2011-06-27 16:11:08 --> Total execution time: 0.9505
DEBUG - 2011-06-27 16:11:22 --> Config Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Hooks Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Utf8 Class Initialized
DEBUG - 2011-06-27 16:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 16:11:22 --> URI Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Router Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Output Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Input Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 16:11:22 --> Language Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Loader Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Controller Class Initialized
ERROR - 2011-06-27 16:11:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 16:11:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 16:11:22 --> Model Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Model Class Initialized
DEBUG - 2011-06-27 16:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 16:11:22 --> Database Driver Class Initialized
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 16:11:22 --> Helper loaded: url_helper
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 16:11:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 16:11:22 --> Final output sent to browser
DEBUG - 2011-06-27 16:11:22 --> Total execution time: 0.1877
DEBUG - 2011-06-27 17:14:30 --> Config Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:14:30 --> URI Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Router Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Output Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Input Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:14:30 --> Language Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Loader Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Controller Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:14:30 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:14:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:14:30 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:14:30 --> Final output sent to browser
DEBUG - 2011-06-27 17:14:30 --> Total execution time: 0.7233
DEBUG - 2011-06-27 17:14:32 --> Config Class Initialized
DEBUG - 2011-06-27 17:14:32 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:14:32 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:14:32 --> URI Class Initialized
DEBUG - 2011-06-27 17:14:32 --> Router Class Initialized
ERROR - 2011-06-27 17:14:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-27 17:15:04 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:04 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Router Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Output Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Input Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:15:04 --> Language Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Loader Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Controller Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:15:04 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:15:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:15:05 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:15:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:15:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:15:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:15:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:15:05 --> Final output sent to browser
DEBUG - 2011-06-27 17:15:05 --> Total execution time: 0.8480
DEBUG - 2011-06-27 17:15:06 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:06 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Router Class Initialized
ERROR - 2011-06-27 17:15:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 17:15:06 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:06 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Router Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Output Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Input Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:15:06 --> Language Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Loader Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Controller Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:15:06 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:15:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:15:06 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:15:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:15:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:15:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:15:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:15:06 --> Final output sent to browser
DEBUG - 2011-06-27 17:15:06 --> Total execution time: 0.0442
DEBUG - 2011-06-27 17:15:24 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:24 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Router Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Output Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Input Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:15:24 --> Language Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Loader Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Controller Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:15:24 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:15:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:15:24 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:15:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:15:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:15:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:15:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:15:24 --> Final output sent to browser
DEBUG - 2011-06-27 17:15:24 --> Total execution time: 0.2651
DEBUG - 2011-06-27 17:15:25 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:25 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Router Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Output Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Input Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:15:25 --> Language Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Loader Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Controller Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:15:25 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:15:25 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:15:25 --> Final output sent to browser
DEBUG - 2011-06-27 17:15:25 --> Total execution time: 0.0527
DEBUG - 2011-06-27 17:15:25 --> Config Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:15:25 --> URI Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Router Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Output Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Input Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:15:25 --> Language Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Loader Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Controller Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Model Class Initialized
DEBUG - 2011-06-27 17:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:15:25 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:15:25 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:15:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:15:25 --> Final output sent to browser
DEBUG - 2011-06-27 17:15:25 --> Total execution time: 0.0430
DEBUG - 2011-06-27 17:16:05 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:05 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:05 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:05 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:06 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:06 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:06 --> Total execution time: 0.2654
DEBUG - 2011-06-27 17:16:08 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:08 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:08 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:08 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:08 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:08 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:08 --> Total execution time: 0.0726
DEBUG - 2011-06-27 17:16:29 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:29 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:29 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:29 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:29 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:29 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:29 --> Total execution time: 0.2685
DEBUG - 2011-06-27 17:16:30 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:30 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:30 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:30 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:30 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:30 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:30 --> Total execution time: 0.0440
DEBUG - 2011-06-27 17:16:30 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:30 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:30 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:30 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:30 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:30 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:30 --> Total execution time: 0.0559
DEBUG - 2011-06-27 17:16:48 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:48 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:48 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:48 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:48 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:48 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:48 --> Total execution time: 0.2016
DEBUG - 2011-06-27 17:16:48 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:48 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:48 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:48 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:48 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:48 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:48 --> Total execution time: 0.0465
DEBUG - 2011-06-27 17:16:58 --> Config Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:16:58 --> URI Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Router Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Output Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Input Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:16:58 --> Language Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Loader Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Controller Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:16:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:16:58 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:16:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:16:59 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:16:59 --> Final output sent to browser
DEBUG - 2011-06-27 17:16:59 --> Total execution time: 0.2639
DEBUG - 2011-06-27 17:17:00 --> Config Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:17:00 --> URI Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Router Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Output Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Input Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:17:00 --> Language Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Loader Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Controller Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:17:00 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:17:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:17:00 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:17:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:17:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:17:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:17:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:17:00 --> Final output sent to browser
DEBUG - 2011-06-27 17:17:00 --> Total execution time: 0.0424
DEBUG - 2011-06-27 17:17:11 --> Config Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:17:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:17:11 --> URI Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Router Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Output Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Input Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:17:11 --> Language Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Loader Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Controller Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:17:11 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:17:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:17:12 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:17:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:17:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:17:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:17:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:17:12 --> Final output sent to browser
DEBUG - 2011-06-27 17:17:12 --> Total execution time: 0.3039
DEBUG - 2011-06-27 17:17:13 --> Config Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:17:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:17:13 --> URI Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Router Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Output Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Input Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:17:13 --> Language Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Loader Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Controller Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:17:13 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:17:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:17:13 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:17:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:17:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:17:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:17:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:17:13 --> Final output sent to browser
DEBUG - 2011-06-27 17:17:13 --> Total execution time: 0.0821
DEBUG - 2011-06-27 17:17:41 --> Config Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:17:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:17:41 --> URI Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Router Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Output Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Input Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:17:41 --> Language Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Loader Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Controller Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:17:41 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:17:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:17:41 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:17:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:17:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:17:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:17:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:17:41 --> Final output sent to browser
DEBUG - 2011-06-27 17:17:41 --> Total execution time: 0.2106
DEBUG - 2011-06-27 17:17:42 --> Config Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:17:42 --> URI Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Router Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Output Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Input Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:17:42 --> Language Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Loader Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Controller Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Model Class Initialized
DEBUG - 2011-06-27 17:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:17:42 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:17:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:17:42 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:17:42 --> Final output sent to browser
DEBUG - 2011-06-27 17:17:42 --> Total execution time: 0.0491
DEBUG - 2011-06-27 17:18:01 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:01 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:01 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:01 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:02 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:02 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:02 --> Total execution time: 0.4825
DEBUG - 2011-06-27 17:18:03 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:03 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:03 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:03 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:03 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:03 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:03 --> Total execution time: 0.0472
DEBUG - 2011-06-27 17:18:23 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:23 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:23 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:23 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:23 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:23 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:23 --> Total execution time: 0.2743
DEBUG - 2011-06-27 17:18:24 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:24 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:24 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:24 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:24 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:24 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:24 --> Total execution time: 0.0463
DEBUG - 2011-06-27 17:18:34 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:34 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:34 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:34 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:34 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:34 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:34 --> Total execution time: 0.2890
DEBUG - 2011-06-27 17:18:35 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:35 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:35 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:35 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:35 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:35 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:35 --> Total execution time: 0.0485
DEBUG - 2011-06-27 17:18:56 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:56 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:56 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:56 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:56 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:56 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:56 --> Total execution time: 0.6618
DEBUG - 2011-06-27 17:18:58 --> Config Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:18:58 --> URI Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Router Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Output Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Input Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:18:58 --> Language Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Loader Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Controller Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Model Class Initialized
DEBUG - 2011-06-27 17:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:18:58 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:18:58 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:18:58 --> Final output sent to browser
DEBUG - 2011-06-27 17:18:58 --> Total execution time: 0.1042
DEBUG - 2011-06-27 17:19:11 --> Config Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:19:11 --> URI Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Router Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Output Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Input Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:19:11 --> Language Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Loader Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Controller Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:19:11 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:19:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:19:12 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:19:12 --> Final output sent to browser
DEBUG - 2011-06-27 17:19:12 --> Total execution time: 0.2231
DEBUG - 2011-06-27 17:19:13 --> Config Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:19:13 --> URI Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Router Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Output Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Input Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:19:13 --> Language Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Loader Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Controller Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:19:13 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:19:13 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:19:13 --> Final output sent to browser
DEBUG - 2011-06-27 17:19:13 --> Total execution time: 0.0656
DEBUG - 2011-06-27 17:19:13 --> Config Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Hooks Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Utf8 Class Initialized
DEBUG - 2011-06-27 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 17:19:13 --> URI Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Router Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Output Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Input Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 17:19:13 --> Language Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Loader Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Controller Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Model Class Initialized
DEBUG - 2011-06-27 17:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 17:19:13 --> Database Driver Class Initialized
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 17:19:13 --> Helper loaded: url_helper
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 17:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 17:19:13 --> Final output sent to browser
DEBUG - 2011-06-27 17:19:13 --> Total execution time: 0.0524
DEBUG - 2011-06-27 20:44:00 --> Config Class Initialized
DEBUG - 2011-06-27 20:44:00 --> Hooks Class Initialized
DEBUG - 2011-06-27 20:44:00 --> Utf8 Class Initialized
DEBUG - 2011-06-27 20:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 20:44:00 --> URI Class Initialized
DEBUG - 2011-06-27 20:44:00 --> Router Class Initialized
ERROR - 2011-06-27 20:44:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 21:57:58 --> Config Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 21:57:58 --> URI Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Router Class Initialized
ERROR - 2011-06-27 21:57:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 21:57:58 --> Config Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Hooks Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Utf8 Class Initialized
DEBUG - 2011-06-27 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 21:57:58 --> URI Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Router Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Output Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Input Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 21:57:58 --> Language Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Loader Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Controller Class Initialized
ERROR - 2011-06-27 21:57:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-27 21:57:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 21:57:58 --> Model Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Model Class Initialized
DEBUG - 2011-06-27 21:57:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 21:57:58 --> Database Driver Class Initialized
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-27 21:57:58 --> Helper loaded: url_helper
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 21:57:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 21:57:58 --> Final output sent to browser
DEBUG - 2011-06-27 21:57:58 --> Total execution time: 0.7653
DEBUG - 2011-06-27 22:08:34 --> Config Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Hooks Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Utf8 Class Initialized
DEBUG - 2011-06-27 22:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 22:08:34 --> URI Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Router Class Initialized
ERROR - 2011-06-27 22:08:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-27 22:08:34 --> Config Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Hooks Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Utf8 Class Initialized
DEBUG - 2011-06-27 22:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 22:08:34 --> URI Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Router Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Output Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Input Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 22:08:34 --> Language Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Loader Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Controller Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Model Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Model Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Model Class Initialized
DEBUG - 2011-06-27 22:08:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-27 22:08:34 --> Database Driver Class Initialized
DEBUG - 2011-06-27 22:08:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-27 22:08:35 --> Helper loaded: url_helper
DEBUG - 2011-06-27 22:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 22:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 22:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 22:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 22:08:35 --> Final output sent to browser
DEBUG - 2011-06-27 22:08:35 --> Total execution time: 0.9463
DEBUG - 2011-06-27 22:36:48 --> Config Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Hooks Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Utf8 Class Initialized
DEBUG - 2011-06-27 22:36:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 22:36:48 --> URI Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Router Class Initialized
DEBUG - 2011-06-27 22:36:48 --> No URI present. Default controller set.
DEBUG - 2011-06-27 22:36:48 --> Output Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Input Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 22:36:48 --> Language Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Loader Class Initialized
DEBUG - 2011-06-27 22:36:48 --> Controller Class Initialized
DEBUG - 2011-06-27 22:36:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-27 22:36:48 --> Helper loaded: url_helper
DEBUG - 2011-06-27 22:36:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 22:36:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 22:36:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 22:36:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 22:36:48 --> Final output sent to browser
DEBUG - 2011-06-27 22:36:48 --> Total execution time: 0.1035
DEBUG - 2011-06-27 22:48:49 --> Config Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Hooks Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Utf8 Class Initialized
DEBUG - 2011-06-27 22:48:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 22:48:49 --> URI Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Router Class Initialized
DEBUG - 2011-06-27 22:48:49 --> No URI present. Default controller set.
DEBUG - 2011-06-27 22:48:49 --> Output Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Input Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 22:48:49 --> Language Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Loader Class Initialized
DEBUG - 2011-06-27 22:48:49 --> Controller Class Initialized
DEBUG - 2011-06-27 22:48:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-27 22:48:49 --> Helper loaded: url_helper
DEBUG - 2011-06-27 22:48:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 22:48:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 22:48:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 22:48:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 22:48:49 --> Final output sent to browser
DEBUG - 2011-06-27 22:48:49 --> Total execution time: 0.0231
DEBUG - 2011-06-27 22:49:29 --> Config Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Hooks Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Utf8 Class Initialized
DEBUG - 2011-06-27 22:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-27 22:49:29 --> URI Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Router Class Initialized
DEBUG - 2011-06-27 22:49:29 --> No URI present. Default controller set.
DEBUG - 2011-06-27 22:49:29 --> Output Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Input Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-27 22:49:29 --> Language Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Loader Class Initialized
DEBUG - 2011-06-27 22:49:29 --> Controller Class Initialized
DEBUG - 2011-06-27 22:49:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-27 22:49:29 --> Helper loaded: url_helper
DEBUG - 2011-06-27 22:49:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-27 22:49:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-27 22:49:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-27 22:49:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-27 22:49:29 --> Final output sent to browser
DEBUG - 2011-06-27 22:49:29 --> Total execution time: 0.0183

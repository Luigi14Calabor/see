<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-30 00:15:57 --> Config Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 00:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 00:15:57 --> URI Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Router Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Output Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Input Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 00:15:57 --> Language Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Loader Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Controller Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Model Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Model Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Model Class Initialized
DEBUG - 2011-07-30 00:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 00:15:57 --> Database Driver Class Initialized
DEBUG - 2011-07-30 00:15:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 00:15:57 --> Helper loaded: url_helper
DEBUG - 2011-07-30 00:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 00:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 00:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 00:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 00:15:57 --> Final output sent to browser
DEBUG - 2011-07-30 00:15:57 --> Total execution time: 0.5762
DEBUG - 2011-07-30 00:16:26 --> Config Class Initialized
DEBUG - 2011-07-30 00:16:26 --> Hooks Class Initialized
DEBUG - 2011-07-30 00:16:26 --> Utf8 Class Initialized
DEBUG - 2011-07-30 00:16:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 00:16:26 --> URI Class Initialized
DEBUG - 2011-07-30 00:16:26 --> Router Class Initialized
ERROR - 2011-07-30 00:16:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 00:17:03 --> Config Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Hooks Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Utf8 Class Initialized
DEBUG - 2011-07-30 00:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 00:17:03 --> URI Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Router Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Output Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Input Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 00:17:03 --> Language Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Loader Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Controller Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Model Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Model Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Model Class Initialized
DEBUG - 2011-07-30 00:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 00:17:03 --> Database Driver Class Initialized
DEBUG - 2011-07-30 00:17:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 00:17:03 --> Helper loaded: url_helper
DEBUG - 2011-07-30 00:17:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 00:17:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 00:17:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 00:17:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 00:17:03 --> Final output sent to browser
DEBUG - 2011-07-30 00:17:03 --> Total execution time: 0.2330
DEBUG - 2011-07-30 00:17:18 --> Config Class Initialized
DEBUG - 2011-07-30 00:17:18 --> Hooks Class Initialized
DEBUG - 2011-07-30 00:17:18 --> Utf8 Class Initialized
DEBUG - 2011-07-30 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 00:17:18 --> URI Class Initialized
DEBUG - 2011-07-30 00:17:18 --> Router Class Initialized
ERROR - 2011-07-30 00:17:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 01:07:13 --> Config Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Hooks Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Utf8 Class Initialized
DEBUG - 2011-07-30 01:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 01:07:13 --> URI Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Router Class Initialized
DEBUG - 2011-07-30 01:07:13 --> No URI present. Default controller set.
DEBUG - 2011-07-30 01:07:13 --> Output Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Input Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 01:07:13 --> Language Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Loader Class Initialized
DEBUG - 2011-07-30 01:07:13 --> Controller Class Initialized
DEBUG - 2011-07-30 01:07:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-30 01:07:13 --> Helper loaded: url_helper
DEBUG - 2011-07-30 01:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 01:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 01:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 01:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 01:07:13 --> Final output sent to browser
DEBUG - 2011-07-30 01:07:13 --> Total execution time: 0.0539
DEBUG - 2011-07-30 01:14:36 --> Config Class Initialized
DEBUG - 2011-07-30 01:14:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 01:14:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 01:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 01:14:36 --> URI Class Initialized
DEBUG - 2011-07-30 01:14:36 --> Router Class Initialized
ERROR - 2011-07-30 01:14:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-30 01:15:20 --> Config Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 01:15:20 --> URI Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Router Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Output Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Input Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 01:15:20 --> Language Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Loader Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Controller Class Initialized
ERROR - 2011-07-30 01:15:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 01:15:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 01:15:20 --> Model Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Model Class Initialized
DEBUG - 2011-07-30 01:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 01:15:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 01:15:20 --> Helper loaded: url_helper
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 01:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 01:15:20 --> Final output sent to browser
DEBUG - 2011-07-30 01:15:20 --> Total execution time: 0.0932
DEBUG - 2011-07-30 03:03:02 --> Config Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:03:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:03:02 --> URI Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Router Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Output Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Input Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:03:02 --> Language Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Loader Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Controller Class Initialized
ERROR - 2011-07-30 03:03:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 03:03:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 03:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:03:02 --> Model Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Model Class Initialized
DEBUG - 2011-07-30 03:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:03:02 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:03:03 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:03:03 --> Final output sent to browser
DEBUG - 2011-07-30 03:03:03 --> Total execution time: 0.5033
DEBUG - 2011-07-30 03:03:05 --> Config Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:03:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:03:05 --> URI Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Router Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Output Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Input Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:03:05 --> Language Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Loader Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Controller Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Model Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Model Class Initialized
DEBUG - 2011-07-30 03:03:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:03:05 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:03:06 --> Final output sent to browser
DEBUG - 2011-07-30 03:03:06 --> Total execution time: 0.7828
DEBUG - 2011-07-30 03:03:11 --> Config Class Initialized
DEBUG - 2011-07-30 03:03:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:03:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:03:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:03:11 --> URI Class Initialized
DEBUG - 2011-07-30 03:03:11 --> Router Class Initialized
ERROR - 2011-07-30 03:03:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 03:05:07 --> Config Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:05:07 --> URI Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Router Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Output Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Input Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:05:07 --> Language Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Loader Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Controller Class Initialized
ERROR - 2011-07-30 03:05:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 03:05:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:05:07 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:05:07 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:05:07 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:05:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:05:07 --> Final output sent to browser
DEBUG - 2011-07-30 03:05:07 --> Total execution time: 0.3505
DEBUG - 2011-07-30 03:05:09 --> Config Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:05:09 --> URI Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Router Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Output Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Input Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:05:09 --> Language Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Loader Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Controller Class Initialized
DEBUG - 2011-07-30 03:05:09 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:10 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:05:10 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:05:10 --> Final output sent to browser
DEBUG - 2011-07-30 03:05:10 --> Total execution time: 1.1095
DEBUG - 2011-07-30 03:05:45 --> Config Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:05:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:05:45 --> URI Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Router Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Output Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Input Class Initialized
DEBUG - 2011-07-30 03:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:05:45 --> Language Class Initialized
DEBUG - 2011-07-30 03:05:46 --> Loader Class Initialized
DEBUG - 2011-07-30 03:05:46 --> Controller Class Initialized
ERROR - 2011-07-30 03:05:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 03:05:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:05:46 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:05:46 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:05:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:05:46 --> Final output sent to browser
DEBUG - 2011-07-30 03:05:46 --> Total execution time: 0.0293
DEBUG - 2011-07-30 03:05:47 --> Config Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:05:47 --> URI Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Router Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Output Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Input Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:05:47 --> Language Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Loader Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Controller Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Model Class Initialized
DEBUG - 2011-07-30 03:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:05:47 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:05:49 --> Final output sent to browser
DEBUG - 2011-07-30 03:05:49 --> Total execution time: 1.3837
DEBUG - 2011-07-30 03:38:51 --> Config Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:38:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:38:51 --> URI Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Router Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Output Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Input Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:38:51 --> Language Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Loader Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Controller Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Model Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Model Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Model Class Initialized
DEBUG - 2011-07-30 03:38:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:38:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 03:38:53 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:38:53 --> Final output sent to browser
DEBUG - 2011-07-30 03:38:53 --> Total execution time: 2.4825
DEBUG - 2011-07-30 03:39:21 --> Config Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:39:21 --> URI Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Router Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Output Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Input Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:39:21 --> Language Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Loader Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Controller Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Model Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Model Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Model Class Initialized
DEBUG - 2011-07-30 03:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:39:21 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:39:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 03:39:22 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:39:22 --> Final output sent to browser
DEBUG - 2011-07-30 03:39:22 --> Total execution time: 0.1408
DEBUG - 2011-07-30 03:39:28 --> Config Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-30 03:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 03:39:28 --> URI Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Router Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Output Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Input Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 03:39:28 --> Language Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Loader Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Controller Class Initialized
ERROR - 2011-07-30 03:39:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 03:39:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:39:28 --> Model Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Model Class Initialized
DEBUG - 2011-07-30 03:39:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 03:39:28 --> Database Driver Class Initialized
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 03:39:28 --> Helper loaded: url_helper
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 03:39:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 03:39:28 --> Final output sent to browser
DEBUG - 2011-07-30 03:39:28 --> Total execution time: 0.1569
DEBUG - 2011-07-30 04:33:52 --> Config Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:33:52 --> URI Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Router Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Output Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Input Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:33:52 --> Language Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Loader Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Controller Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Model Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Model Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Model Class Initialized
DEBUG - 2011-07-30 04:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:33:52 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:33:53 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:33:53 --> Final output sent to browser
DEBUG - 2011-07-30 04:33:53 --> Total execution time: 1.6387
DEBUG - 2011-07-30 04:35:25 --> Config Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:35:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:35:25 --> URI Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Router Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Output Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Input Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:35:25 --> Language Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Loader Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Controller Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:35:25 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:35:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:35:26 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:35:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:35:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:35:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:35:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:35:26 --> Final output sent to browser
DEBUG - 2011-07-30 04:35:26 --> Total execution time: 0.9911
DEBUG - 2011-07-30 04:35:34 --> Config Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:35:34 --> URI Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Router Class Initialized
ERROR - 2011-07-30 04:35:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-30 04:35:34 --> Config Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:35:34 --> URI Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Router Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Output Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Input Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:35:34 --> Language Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Loader Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Controller Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Model Class Initialized
DEBUG - 2011-07-30 04:35:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:35:34 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:35:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:35:34 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:35:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:35:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:35:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:35:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:35:34 --> Final output sent to browser
DEBUG - 2011-07-30 04:35:34 --> Total execution time: 0.1582
DEBUG - 2011-07-30 04:36:05 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:05 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:05 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:05 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:05 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:05 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:05 --> Total execution time: 0.0656
DEBUG - 2011-07-30 04:36:11 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:11 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:11 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:11 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:12 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:12 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:12 --> Total execution time: 0.3071
DEBUG - 2011-07-30 04:36:14 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:14 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:14 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:14 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:15 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:15 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:15 --> Total execution time: 0.0556
DEBUG - 2011-07-30 04:36:35 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:35 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:35 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:35 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:36 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:36 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:36 --> Total execution time: 1.3902
DEBUG - 2011-07-30 04:36:40 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:40 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:40 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:40 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:40 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:40 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:40 --> Total execution time: 0.0488
DEBUG - 2011-07-30 04:36:56 --> Config Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:36:56 --> URI Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Router Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Output Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Input Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:36:56 --> Language Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Loader Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Controller Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Model Class Initialized
DEBUG - 2011-07-30 04:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:36:56 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:36:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:36:56 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:36:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:36:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:36:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:36:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:36:56 --> Final output sent to browser
DEBUG - 2011-07-30 04:36:56 --> Total execution time: 0.3462
DEBUG - 2011-07-30 04:37:00 --> Config Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:37:00 --> URI Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Router Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Output Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Input Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:37:00 --> Language Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Loader Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Controller Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:37:00 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:37:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:37:00 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:37:00 --> Final output sent to browser
DEBUG - 2011-07-30 04:37:00 --> Total execution time: 0.1686
DEBUG - 2011-07-30 04:37:09 --> Config Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:37:09 --> URI Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Router Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Output Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Input Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:37:09 --> Language Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Loader Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Controller Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:37:09 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:37:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:37:10 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:37:10 --> Final output sent to browser
DEBUG - 2011-07-30 04:37:10 --> Total execution time: 0.1930
DEBUG - 2011-07-30 04:37:13 --> Config Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:37:13 --> URI Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Router Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Output Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Input Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:37:13 --> Language Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Loader Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Controller Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Model Class Initialized
DEBUG - 2011-07-30 04:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:37:13 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:37:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:37:13 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:37:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:37:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:37:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:37:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:37:13 --> Final output sent to browser
DEBUG - 2011-07-30 04:37:13 --> Total execution time: 0.0715
DEBUG - 2011-07-30 04:38:49 --> Config Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:38:49 --> URI Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Router Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Output Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Input Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:38:49 --> Language Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Loader Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Controller Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Model Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Model Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Model Class Initialized
DEBUG - 2011-07-30 04:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:38:49 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:38:50 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:38:50 --> Final output sent to browser
DEBUG - 2011-07-30 04:38:50 --> Total execution time: 0.4962
DEBUG - 2011-07-30 04:39:00 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:00 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:00 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:01 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:01 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:01 --> Total execution time: 0.0483
DEBUG - 2011-07-30 04:39:08 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:08 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:08 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:08 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:08 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:08 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:08 --> Total execution time: 0.2851
DEBUG - 2011-07-30 04:39:12 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:12 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:12 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:12 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:12 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:12 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:12 --> Total execution time: 0.0449
DEBUG - 2011-07-30 04:39:17 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:17 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:17 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:17 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:17 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:17 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:17 --> Total execution time: 0.0506
DEBUG - 2011-07-30 04:39:23 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:23 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:23 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:23 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:23 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:23 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:23 --> Total execution time: 0.2386
DEBUG - 2011-07-30 04:39:27 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:27 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:27 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:27 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:27 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:27 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:27 --> Total execution time: 0.0515
DEBUG - 2011-07-30 04:39:32 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:32 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:32 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:32 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:33 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:33 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:33 --> Total execution time: 1.2451
DEBUG - 2011-07-30 04:39:36 --> Config Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:39:36 --> URI Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Router Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Output Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Input Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:39:36 --> Language Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Loader Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Controller Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Model Class Initialized
DEBUG - 2011-07-30 04:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:39:36 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:39:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:39:37 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:39:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:39:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:39:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:39:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:39:37 --> Final output sent to browser
DEBUG - 2011-07-30 04:39:37 --> Total execution time: 0.3803
DEBUG - 2011-07-30 04:42:24 --> Config Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:42:24 --> URI Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Router Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Output Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Input Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 04:42:24 --> Language Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Loader Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Controller Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Model Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Model Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Model Class Initialized
DEBUG - 2011-07-30 04:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 04:42:24 --> Database Driver Class Initialized
DEBUG - 2011-07-30 04:42:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 04:42:24 --> Helper loaded: url_helper
DEBUG - 2011-07-30 04:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 04:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 04:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 04:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 04:42:24 --> Final output sent to browser
DEBUG - 2011-07-30 04:42:24 --> Total execution time: 0.0478
DEBUG - 2011-07-30 04:42:27 --> Config Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:42:27 --> URI Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Router Class Initialized
ERROR - 2011-07-30 04:42:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 04:42:27 --> Config Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:42:27 --> URI Class Initialized
DEBUG - 2011-07-30 04:42:27 --> Router Class Initialized
ERROR - 2011-07-30 04:42:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 04:42:28 --> Config Class Initialized
DEBUG - 2011-07-30 04:42:28 --> Hooks Class Initialized
DEBUG - 2011-07-30 04:42:28 --> Utf8 Class Initialized
DEBUG - 2011-07-30 04:42:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 04:42:28 --> URI Class Initialized
DEBUG - 2011-07-30 04:42:28 --> Router Class Initialized
ERROR - 2011-07-30 04:42:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 05:28:41 --> Config Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:28:41 --> URI Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Router Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Output Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Input Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:28:41 --> Language Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Loader Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Controller Class Initialized
ERROR - 2011-07-30 05:28:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 05:28:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:28:41 --> Model Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Model Class Initialized
DEBUG - 2011-07-30 05:28:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:28:41 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:28:41 --> Helper loaded: url_helper
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 05:28:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 05:28:41 --> Final output sent to browser
DEBUG - 2011-07-30 05:28:41 --> Total execution time: 0.2534
DEBUG - 2011-07-30 05:28:43 --> Config Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:28:43 --> URI Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Router Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Output Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Input Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:28:43 --> Language Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Loader Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Controller Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Model Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Model Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:28:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:28:43 --> Final output sent to browser
DEBUG - 2011-07-30 05:28:43 --> Total execution time: 0.7377
DEBUG - 2011-07-30 05:28:45 --> Config Class Initialized
DEBUG - 2011-07-30 05:28:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:28:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:28:45 --> URI Class Initialized
DEBUG - 2011-07-30 05:28:45 --> Router Class Initialized
ERROR - 2011-07-30 05:28:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 05:41:29 --> Config Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:41:29 --> URI Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Router Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Output Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Input Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:41:29 --> Language Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Loader Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Controller Class Initialized
ERROR - 2011-07-30 05:41:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 05:41:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:41:29 --> Model Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Model Class Initialized
DEBUG - 2011-07-30 05:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:41:29 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:41:29 --> Helper loaded: url_helper
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 05:41:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 05:41:29 --> Final output sent to browser
DEBUG - 2011-07-30 05:41:29 --> Total execution time: 0.2573
DEBUG - 2011-07-30 05:41:33 --> Config Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:41:33 --> URI Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Router Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Output Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Input Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:41:33 --> Language Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Loader Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Controller Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Model Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Model Class Initialized
DEBUG - 2011-07-30 05:41:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:41:33 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:41:35 --> Final output sent to browser
DEBUG - 2011-07-30 05:41:35 --> Total execution time: 2.1287
DEBUG - 2011-07-30 05:48:51 --> Config Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:48:51 --> URI Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Router Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Output Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Input Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:48:51 --> Language Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Loader Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Controller Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Config Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:48:51 --> URI Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Router Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Output Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Input Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:48:51 --> Language Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:48:51 --> Loader Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Controller Class Initialized
ERROR - 2011-07-30 05:48:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 05:48:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:48:51 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:48:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:48:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 05:48:51 --> Helper loaded: url_helper
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 05:48:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 05:48:51 --> Final output sent to browser
DEBUG - 2011-07-30 05:48:51 --> Total execution time: 0.0313
DEBUG - 2011-07-30 05:48:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 05:48:52 --> Helper loaded: url_helper
DEBUG - 2011-07-30 05:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 05:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 05:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 05:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 05:48:52 --> Final output sent to browser
DEBUG - 2011-07-30 05:48:52 --> Total execution time: 0.3426
DEBUG - 2011-07-30 05:48:52 --> Config Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Hooks Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Utf8 Class Initialized
DEBUG - 2011-07-30 05:48:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 05:48:52 --> URI Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Router Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Output Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Input Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 05:48:52 --> Language Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Loader Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Controller Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Model Class Initialized
DEBUG - 2011-07-30 05:48:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 05:48:52 --> Database Driver Class Initialized
DEBUG - 2011-07-30 05:48:53 --> Final output sent to browser
DEBUG - 2011-07-30 05:48:53 --> Total execution time: 0.5104
DEBUG - 2011-07-30 06:11:49 --> Config Class Initialized
DEBUG - 2011-07-30 06:11:49 --> Hooks Class Initialized
DEBUG - 2011-07-30 06:11:49 --> Utf8 Class Initialized
DEBUG - 2011-07-30 06:11:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 06:11:49 --> URI Class Initialized
DEBUG - 2011-07-30 06:11:49 --> Router Class Initialized
ERROR - 2011-07-30 06:11:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 06:11:50 --> Config Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Hooks Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Utf8 Class Initialized
DEBUG - 2011-07-30 06:11:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 06:11:50 --> URI Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Router Class Initialized
DEBUG - 2011-07-30 06:11:50 --> No URI present. Default controller set.
DEBUG - 2011-07-30 06:11:50 --> Output Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Input Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 06:11:50 --> Language Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Loader Class Initialized
DEBUG - 2011-07-30 06:11:50 --> Controller Class Initialized
DEBUG - 2011-07-30 06:11:50 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-30 06:11:50 --> Helper loaded: url_helper
DEBUG - 2011-07-30 06:11:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 06:11:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 06:11:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 06:11:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 06:11:50 --> Final output sent to browser
DEBUG - 2011-07-30 06:11:50 --> Total execution time: 0.1777
DEBUG - 2011-07-30 07:49:36 --> Config Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:49:36 --> URI Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Router Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Output Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Input Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:49:36 --> Language Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Loader Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Controller Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Model Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Model Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Model Class Initialized
DEBUG - 2011-07-30 07:49:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:49:36 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:49:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:49:36 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:49:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:49:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:49:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:49:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:49:36 --> Final output sent to browser
DEBUG - 2011-07-30 07:49:36 --> Total execution time: 0.7065
DEBUG - 2011-07-30 07:49:39 --> Config Class Initialized
DEBUG - 2011-07-30 07:49:39 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:49:39 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:49:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:49:39 --> URI Class Initialized
DEBUG - 2011-07-30 07:49:39 --> Router Class Initialized
ERROR - 2011-07-30 07:49:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 07:50:12 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:12 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:12 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:12 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:14 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:14 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:14 --> Total execution time: 1.2874
DEBUG - 2011-07-30 07:50:33 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:33 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:33 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:33 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:34 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:34 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:34 --> Total execution time: 0.2603
DEBUG - 2011-07-30 07:50:42 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:42 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:42 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:42 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:42 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:42 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:42 --> Total execution time: 0.0453
DEBUG - 2011-07-30 07:50:48 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:48 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:48 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:48 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:48 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:48 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:48 --> Total execution time: 0.0824
DEBUG - 2011-07-30 07:50:50 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:50 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:50 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:50 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:50 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:50 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:50 --> Total execution time: 0.1998
DEBUG - 2011-07-30 07:50:51 --> Config Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:50:51 --> URI Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Router Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Output Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Input Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:50:51 --> Language Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Loader Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Controller Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Model Class Initialized
DEBUG - 2011-07-30 07:50:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:50:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:50:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:50:51 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:50:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:50:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:50:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:50:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:50:51 --> Final output sent to browser
DEBUG - 2011-07-30 07:50:51 --> Total execution time: 0.0427
DEBUG - 2011-07-30 07:51:00 --> Config Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:51:00 --> URI Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Router Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Output Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Input Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:51:00 --> Language Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Loader Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Controller Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:51:00 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:51:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:51:00 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:51:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:51:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:51:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:51:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:51:00 --> Final output sent to browser
DEBUG - 2011-07-30 07:51:00 --> Total execution time: 0.2453
DEBUG - 2011-07-30 07:51:05 --> Config Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:51:05 --> URI Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Router Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Output Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Input Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:51:05 --> Language Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Loader Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Controller Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:51:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:51:05 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:51:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:51:05 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:51:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:51:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:51:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:51:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:51:05 --> Final output sent to browser
DEBUG - 2011-07-30 07:51:05 --> Total execution time: 0.0459
DEBUG - 2011-07-30 07:52:01 --> Config Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:52:01 --> URI Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Router Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Output Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Input Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:52:01 --> Language Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Loader Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Controller Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:52:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:52:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:52:01 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:52:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:52:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:52:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:52:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:52:01 --> Final output sent to browser
DEBUG - 2011-07-30 07:52:01 --> Total execution time: 0.0463
DEBUG - 2011-07-30 07:52:02 --> Config Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:52:02 --> URI Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Router Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Output Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Input Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:52:02 --> Language Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Loader Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Controller Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:52:02 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:52:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:52:02 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:52:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:52:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:52:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:52:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:52:02 --> Final output sent to browser
DEBUG - 2011-07-30 07:52:02 --> Total execution time: 0.1010
DEBUG - 2011-07-30 07:52:05 --> Config Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Hooks Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Utf8 Class Initialized
DEBUG - 2011-07-30 07:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 07:52:05 --> URI Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Router Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Output Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Input Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 07:52:05 --> Language Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Loader Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Controller Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Model Class Initialized
DEBUG - 2011-07-30 07:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 07:52:05 --> Database Driver Class Initialized
DEBUG - 2011-07-30 07:52:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 07:52:05 --> Helper loaded: url_helper
DEBUG - 2011-07-30 07:52:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 07:52:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 07:52:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 07:52:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 07:52:05 --> Final output sent to browser
DEBUG - 2011-07-30 07:52:05 --> Total execution time: 0.0650
DEBUG - 2011-07-30 08:13:46 --> Config Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Hooks Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Utf8 Class Initialized
DEBUG - 2011-07-30 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 08:13:46 --> URI Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Router Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Output Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Input Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 08:13:46 --> Language Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Loader Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Controller Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Model Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Model Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Model Class Initialized
DEBUG - 2011-07-30 08:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 08:13:46 --> Database Driver Class Initialized
DEBUG - 2011-07-30 08:13:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 08:13:47 --> Helper loaded: url_helper
DEBUG - 2011-07-30 08:13:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 08:13:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 08:13:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 08:13:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 08:13:47 --> Final output sent to browser
DEBUG - 2011-07-30 08:13:47 --> Total execution time: 0.3746
DEBUG - 2011-07-30 08:13:48 --> Config Class Initialized
DEBUG - 2011-07-30 08:13:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 08:13:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 08:13:48 --> URI Class Initialized
DEBUG - 2011-07-30 08:13:48 --> Router Class Initialized
ERROR - 2011-07-30 08:13:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 08:16:58 --> Config Class Initialized
DEBUG - 2011-07-30 08:16:58 --> Hooks Class Initialized
DEBUG - 2011-07-30 08:16:58 --> Utf8 Class Initialized
DEBUG - 2011-07-30 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 08:16:58 --> URI Class Initialized
DEBUG - 2011-07-30 08:16:58 --> Router Class Initialized
ERROR - 2011-07-30 08:16:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-30 09:15:27 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:27 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Router Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Output Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Input Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:15:27 --> Language Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Loader Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Controller Class Initialized
ERROR - 2011-07-30 09:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 09:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 09:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:15:27 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:15:27 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:15:28 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:15:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:15:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:15:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:15:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:15:28 --> Final output sent to browser
DEBUG - 2011-07-30 09:15:28 --> Total execution time: 0.2456
DEBUG - 2011-07-30 09:15:29 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:29 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Router Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Output Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Input Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:15:29 --> Language Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Loader Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Controller Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:15:29 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:15:30 --> Final output sent to browser
DEBUG - 2011-07-30 09:15:30 --> Total execution time: 0.5949
DEBUG - 2011-07-30 09:15:33 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:33 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:33 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:33 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:33 --> Router Class Initialized
ERROR - 2011-07-30 09:15:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 09:15:34 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:34 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:34 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:34 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:34 --> Router Class Initialized
ERROR - 2011-07-30 09:15:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 09:15:49 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:49 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Router Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Output Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Input Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:15:49 --> Language Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Loader Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Controller Class Initialized
ERROR - 2011-07-30 09:15:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 09:15:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 09:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:15:49 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:15:49 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:15:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:15:50 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:15:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:15:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:15:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:15:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:15:50 --> Final output sent to browser
DEBUG - 2011-07-30 09:15:50 --> Total execution time: 0.0299
DEBUG - 2011-07-30 09:15:50 --> Config Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:15:50 --> URI Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Router Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Output Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Input Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:15:50 --> Language Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Loader Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Controller Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Model Class Initialized
DEBUG - 2011-07-30 09:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:15:50 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:15:51 --> Final output sent to browser
DEBUG - 2011-07-30 09:15:51 --> Total execution time: 0.6486
DEBUG - 2011-07-30 09:16:01 --> Config Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:16:01 --> URI Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Router Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Output Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Input Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:16:01 --> Language Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Loader Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Controller Class Initialized
ERROR - 2011-07-30 09:16:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 09:16:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:16:01 --> Model Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Model Class Initialized
DEBUG - 2011-07-30 09:16:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:16:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:16:01 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:16:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:16:01 --> Final output sent to browser
DEBUG - 2011-07-30 09:16:01 --> Total execution time: 0.0384
DEBUG - 2011-07-30 09:16:02 --> Config Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:16:02 --> URI Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Router Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Output Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Input Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:16:02 --> Language Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Loader Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Controller Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Model Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Model Class Initialized
DEBUG - 2011-07-30 09:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:16:02 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:16:03 --> Final output sent to browser
DEBUG - 2011-07-30 09:16:03 --> Total execution time: 0.5698
DEBUG - 2011-07-30 09:17:16 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:16 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Router Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Output Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Input Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:17:16 --> Language Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Loader Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Controller Class Initialized
ERROR - 2011-07-30 09:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 09:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:17:16 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:17:16 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:17:16 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:17:16 --> Final output sent to browser
DEBUG - 2011-07-30 09:17:16 --> Total execution time: 0.0366
DEBUG - 2011-07-30 09:17:17 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:17 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Router Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Output Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Input Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:17:17 --> Language Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Loader Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Controller Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:17:17 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:17:18 --> Final output sent to browser
DEBUG - 2011-07-30 09:17:18 --> Total execution time: 0.6590
DEBUG - 2011-07-30 09:17:20 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:20 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:20 --> Router Class Initialized
ERROR - 2011-07-30 09:17:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 09:17:45 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:45 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Router Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Output Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Input Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:17:45 --> Language Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Loader Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Controller Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Model Class Initialized
DEBUG - 2011-07-30 09:17:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:17:45 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:17:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 09:17:45 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:17:45 --> Final output sent to browser
DEBUG - 2011-07-30 09:17:45 --> Total execution time: 0.3610
DEBUG - 2011-07-30 09:17:48 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:48 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Router Class Initialized
ERROR - 2011-07-30 09:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 09:17:48 --> Config Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:17:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:17:48 --> URI Class Initialized
DEBUG - 2011-07-30 09:17:48 --> Router Class Initialized
ERROR - 2011-07-30 09:17:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 09:18:19 --> Config Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:18:19 --> URI Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Router Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Output Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Input Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:18:19 --> Language Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Loader Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Controller Class Initialized
ERROR - 2011-07-30 09:18:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 09:18:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:18:19 --> Model Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Model Class Initialized
DEBUG - 2011-07-30 09:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:18:19 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 09:18:19 --> Helper loaded: url_helper
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 09:18:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 09:18:19 --> Final output sent to browser
DEBUG - 2011-07-30 09:18:19 --> Total execution time: 0.0264
DEBUG - 2011-07-30 09:18:20 --> Config Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 09:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 09:18:20 --> URI Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Router Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Output Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Input Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 09:18:20 --> Language Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Loader Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Controller Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Model Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Model Class Initialized
DEBUG - 2011-07-30 09:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 09:18:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 09:18:21 --> Final output sent to browser
DEBUG - 2011-07-30 09:18:21 --> Total execution time: 0.4750
DEBUG - 2011-07-30 10:00:37 --> Config Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:00:37 --> URI Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Router Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Output Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Input Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:00:37 --> Language Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Loader Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Controller Class Initialized
ERROR - 2011-07-30 10:00:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 10:00:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:00:37 --> Model Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Model Class Initialized
DEBUG - 2011-07-30 10:00:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:00:37 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:00:37 --> Helper loaded: url_helper
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 10:00:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 10:00:37 --> Final output sent to browser
DEBUG - 2011-07-30 10:00:37 --> Total execution time: 0.0363
DEBUG - 2011-07-30 10:01:59 --> Config Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:01:59 --> URI Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Router Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Output Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Input Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:01:59 --> Language Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Loader Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Controller Class Initialized
ERROR - 2011-07-30 10:01:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 10:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:01:59 --> Model Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Model Class Initialized
DEBUG - 2011-07-30 10:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:01:59 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:01:59 --> Helper loaded: url_helper
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 10:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 10:01:59 --> Final output sent to browser
DEBUG - 2011-07-30 10:01:59 --> Total execution time: 0.0756
DEBUG - 2011-07-30 10:27:45 --> Config Class Initialized
DEBUG - 2011-07-30 10:27:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:27:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:27:45 --> URI Class Initialized
DEBUG - 2011-07-30 10:27:45 --> Router Class Initialized
ERROR - 2011-07-30 10:27:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-30 10:29:56 --> Config Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:29:56 --> URI Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Router Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Output Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Input Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:29:56 --> Language Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Loader Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Controller Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Model Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Model Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Model Class Initialized
DEBUG - 2011-07-30 10:29:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:29:56 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 10:29:57 --> Helper loaded: url_helper
DEBUG - 2011-07-30 10:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 10:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 10:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 10:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 10:29:57 --> Final output sent to browser
DEBUG - 2011-07-30 10:29:57 --> Total execution time: 1.2189
DEBUG - 2011-07-30 10:36:49 --> Config Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:36:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:36:49 --> URI Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Router Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Output Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Input Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:36:49 --> Language Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Loader Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Controller Class Initialized
ERROR - 2011-07-30 10:36:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 10:36:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:36:49 --> Model Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Model Class Initialized
DEBUG - 2011-07-30 10:36:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:36:49 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:36:49 --> Helper loaded: url_helper
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 10:36:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 10:36:49 --> Final output sent to browser
DEBUG - 2011-07-30 10:36:49 --> Total execution time: 0.0269
DEBUG - 2011-07-30 10:36:52 --> Config Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:36:52 --> URI Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Router Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Output Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Input Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:36:52 --> Language Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Loader Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Controller Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Model Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Model Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:36:52 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:36:52 --> Final output sent to browser
DEBUG - 2011-07-30 10:36:52 --> Total execution time: 0.6295
DEBUG - 2011-07-30 10:38:11 --> Config Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:38:11 --> URI Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Router Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Output Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Input Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:38:11 --> Language Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Loader Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Controller Class Initialized
ERROR - 2011-07-30 10:38:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 10:38:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:38:11 --> Model Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Model Class Initialized
DEBUG - 2011-07-30 10:38:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:38:11 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 10:38:11 --> Helper loaded: url_helper
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 10:38:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 10:38:11 --> Final output sent to browser
DEBUG - 2011-07-30 10:38:11 --> Total execution time: 0.0298
DEBUG - 2011-07-30 10:38:14 --> Config Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Hooks Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Utf8 Class Initialized
DEBUG - 2011-07-30 10:38:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 10:38:14 --> URI Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Router Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Output Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Input Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 10:38:14 --> Language Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Loader Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Controller Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Model Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Model Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 10:38:14 --> Database Driver Class Initialized
DEBUG - 2011-07-30 10:38:14 --> Final output sent to browser
DEBUG - 2011-07-30 10:38:14 --> Total execution time: 0.6024
DEBUG - 2011-07-30 11:04:15 --> Config Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:04:15 --> URI Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Router Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Output Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Input Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 11:04:15 --> Language Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Loader Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Controller Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 11:04:15 --> Database Driver Class Initialized
DEBUG - 2011-07-30 11:04:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 11:04:16 --> Helper loaded: url_helper
DEBUG - 2011-07-30 11:04:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 11:04:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 11:04:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 11:04:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 11:04:16 --> Final output sent to browser
DEBUG - 2011-07-30 11:04:16 --> Total execution time: 0.4672
DEBUG - 2011-07-30 11:04:19 --> Config Class Initialized
DEBUG - 2011-07-30 11:04:19 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:04:19 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:04:19 --> URI Class Initialized
DEBUG - 2011-07-30 11:04:19 --> Router Class Initialized
ERROR - 2011-07-30 11:04:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 11:04:21 --> Config Class Initialized
DEBUG - 2011-07-30 11:04:21 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:04:21 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:04:21 --> URI Class Initialized
DEBUG - 2011-07-30 11:04:21 --> Router Class Initialized
ERROR - 2011-07-30 11:04:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 11:04:25 --> Config Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:04:25 --> URI Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Router Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Output Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Input Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 11:04:25 --> Language Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Loader Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Controller Class Initialized
ERROR - 2011-07-30 11:04:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 11:04:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 11:04:25 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 11:04:25 --> Database Driver Class Initialized
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 11:04:25 --> Helper loaded: url_helper
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 11:04:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 11:04:25 --> Final output sent to browser
DEBUG - 2011-07-30 11:04:25 --> Total execution time: 0.0271
DEBUG - 2011-07-30 11:04:26 --> Config Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:04:26 --> URI Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Router Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Output Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Input Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 11:04:26 --> Language Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Loader Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Controller Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Model Class Initialized
DEBUG - 2011-07-30 11:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 11:04:26 --> Database Driver Class Initialized
DEBUG - 2011-07-30 11:04:27 --> Final output sent to browser
DEBUG - 2011-07-30 11:04:27 --> Total execution time: 0.5397
DEBUG - 2011-07-30 11:36:17 --> Config Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:36:17 --> URI Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Router Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Output Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Input Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 11:36:17 --> Language Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Loader Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Controller Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Model Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Model Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Model Class Initialized
DEBUG - 2011-07-30 11:36:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 11:36:17 --> Database Driver Class Initialized
DEBUG - 2011-07-30 11:36:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 11:36:17 --> Helper loaded: url_helper
DEBUG - 2011-07-30 11:36:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 11:36:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 11:36:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 11:36:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 11:36:17 --> Final output sent to browser
DEBUG - 2011-07-30 11:36:17 --> Total execution time: 0.3271
DEBUG - 2011-07-30 11:36:19 --> Config Class Initialized
DEBUG - 2011-07-30 11:36:19 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:36:19 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:36:19 --> URI Class Initialized
DEBUG - 2011-07-30 11:36:19 --> Router Class Initialized
ERROR - 2011-07-30 11:36:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 11:54:50 --> Config Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:54:50 --> URI Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Router Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Output Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Input Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 11:54:50 --> Language Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Loader Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Controller Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Model Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Model Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Model Class Initialized
DEBUG - 2011-07-30 11:54:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 11:54:50 --> Database Driver Class Initialized
DEBUG - 2011-07-30 11:54:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 11:54:50 --> Helper loaded: url_helper
DEBUG - 2011-07-30 11:54:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 11:54:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 11:54:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 11:54:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 11:54:50 --> Final output sent to browser
DEBUG - 2011-07-30 11:54:50 --> Total execution time: 0.1047
DEBUG - 2011-07-30 11:54:57 --> Config Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:54:57 --> URI Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Router Class Initialized
ERROR - 2011-07-30 11:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 11:54:57 --> Config Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 11:54:57 --> URI Class Initialized
DEBUG - 2011-07-30 11:54:57 --> Router Class Initialized
ERROR - 2011-07-30 11:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 12:02:27 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:27 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:27 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Controller Class Initialized
ERROR - 2011-07-30 12:02:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:02:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:27 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:27 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:27 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:02:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:02:27 --> Final output sent to browser
DEBUG - 2011-07-30 12:02:27 --> Total execution time: 0.0298
DEBUG - 2011-07-30 12:02:28 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:28 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:28 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Controller Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:28 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:02:28 --> Final output sent to browser
DEBUG - 2011-07-30 12:02:28 --> Total execution time: 0.6134
DEBUG - 2011-07-30 12:02:30 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:30 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Router Class Initialized
ERROR - 2011-07-30 12:02:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 12:02:30 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:30 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:30 --> Router Class Initialized
ERROR - 2011-07-30 12:02:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 12:02:31 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:31 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:31 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:31 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:31 --> Router Class Initialized
ERROR - 2011-07-30 12:02:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 12:02:43 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:43 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:43 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Controller Class Initialized
ERROR - 2011-07-30 12:02:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:02:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:43 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:43 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:02:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:02:43 --> Final output sent to browser
DEBUG - 2011-07-30 12:02:43 --> Total execution time: 0.0266
DEBUG - 2011-07-30 12:02:44 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:44 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:44 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Controller Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:44 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:02:45 --> Final output sent to browser
DEBUG - 2011-07-30 12:02:45 --> Total execution time: 0.6000
DEBUG - 2011-07-30 12:02:59 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:59 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:59 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Controller Class Initialized
ERROR - 2011-07-30 12:02:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:02:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:59 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:59 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:02:59 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:02:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:02:59 --> Final output sent to browser
DEBUG - 2011-07-30 12:02:59 --> Total execution time: 0.0497
DEBUG - 2011-07-30 12:02:59 --> Config Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:02:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:02:59 --> URI Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Router Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Output Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Input Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:02:59 --> Language Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Loader Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Controller Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Model Class Initialized
DEBUG - 2011-07-30 12:02:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:02:59 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Final output sent to browser
DEBUG - 2011-07-30 12:03:00 --> Total execution time: 0.6312
DEBUG - 2011-07-30 12:03:00 --> Config Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:03:00 --> URI Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Router Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Output Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Input Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:03:00 --> Language Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Loader Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Controller Class Initialized
ERROR - 2011-07-30 12:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:03:00 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:03:00 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:03:00 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:03:00 --> Final output sent to browser
DEBUG - 2011-07-30 12:03:00 --> Total execution time: 0.0314
DEBUG - 2011-07-30 12:03:13 --> Config Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:03:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:03:13 --> URI Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Router Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Output Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Input Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:03:13 --> Language Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Loader Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Controller Class Initialized
ERROR - 2011-07-30 12:03:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:03:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:03:13 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:03:13 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:03:13 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:03:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:03:13 --> Final output sent to browser
DEBUG - 2011-07-30 12:03:13 --> Total execution time: 0.0282
DEBUG - 2011-07-30 12:03:14 --> Config Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:03:14 --> URI Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Router Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Output Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Input Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:03:14 --> Language Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Loader Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Controller Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Model Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:03:14 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:03:14 --> Final output sent to browser
DEBUG - 2011-07-30 12:03:14 --> Total execution time: 0.5671
DEBUG - 2011-07-30 12:45:56 --> Config Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:45:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:45:56 --> URI Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Router Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Output Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Input Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:45:56 --> Language Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Loader Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Controller Class Initialized
ERROR - 2011-07-30 12:45:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 12:45:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:45:56 --> Model Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Model Class Initialized
DEBUG - 2011-07-30 12:45:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:45:56 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 12:45:56 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:45:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:45:56 --> Final output sent to browser
DEBUG - 2011-07-30 12:45:56 --> Total execution time: 0.0457
DEBUG - 2011-07-30 12:45:58 --> Config Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:45:58 --> URI Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Router Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Output Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Input Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:45:58 --> Language Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Loader Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Controller Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Model Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Model Class Initialized
DEBUG - 2011-07-30 12:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:45:58 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:45:59 --> Final output sent to browser
DEBUG - 2011-07-30 12:45:59 --> Total execution time: 0.6162
DEBUG - 2011-07-30 12:46:02 --> Config Class Initialized
DEBUG - 2011-07-30 12:46:02 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:46:02 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:46:02 --> URI Class Initialized
DEBUG - 2011-07-30 12:46:02 --> Router Class Initialized
ERROR - 2011-07-30 12:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 12:48:41 --> Config Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:48:41 --> URI Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Router Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Output Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Input Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 12:48:41 --> Language Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Loader Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Controller Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Model Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Model Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Model Class Initialized
DEBUG - 2011-07-30 12:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 12:48:41 --> Database Driver Class Initialized
DEBUG - 2011-07-30 12:48:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 12:48:42 --> Helper loaded: url_helper
DEBUG - 2011-07-30 12:48:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 12:48:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 12:48:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 12:48:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 12:48:42 --> Final output sent to browser
DEBUG - 2011-07-30 12:48:42 --> Total execution time: 0.2059
DEBUG - 2011-07-30 12:48:45 --> Config Class Initialized
DEBUG - 2011-07-30 12:48:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 12:48:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 12:48:45 --> URI Class Initialized
DEBUG - 2011-07-30 12:48:45 --> Router Class Initialized
ERROR - 2011-07-30 12:48:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 13:07:01 --> Config Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:07:01 --> URI Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Router Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Output Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Input Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:07:01 --> Language Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Loader Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Controller Class Initialized
ERROR - 2011-07-30 13:07:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 13:07:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:07:01 --> Model Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Model Class Initialized
DEBUG - 2011-07-30 13:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:07:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:07:01 --> Helper loaded: url_helper
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 13:07:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 13:07:01 --> Final output sent to browser
DEBUG - 2011-07-30 13:07:01 --> Total execution time: 0.0294
DEBUG - 2011-07-30 13:07:02 --> Config Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:07:02 --> URI Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Router Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Output Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Input Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:07:02 --> Language Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Loader Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Controller Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Model Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Model Class Initialized
DEBUG - 2011-07-30 13:07:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:07:02 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:07:03 --> Final output sent to browser
DEBUG - 2011-07-30 13:07:03 --> Total execution time: 0.6772
DEBUG - 2011-07-30 13:07:04 --> Config Class Initialized
DEBUG - 2011-07-30 13:07:04 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:07:04 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:07:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:07:04 --> URI Class Initialized
DEBUG - 2011-07-30 13:07:04 --> Router Class Initialized
ERROR - 2011-07-30 13:07:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 13:51:04 --> Config Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:51:04 --> URI Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Router Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Output Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Input Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:51:04 --> Language Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Loader Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Controller Class Initialized
ERROR - 2011-07-30 13:51:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 13:51:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:51:04 --> Model Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Model Class Initialized
DEBUG - 2011-07-30 13:51:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:51:04 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:51:04 --> Helper loaded: url_helper
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 13:51:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 13:51:04 --> Final output sent to browser
DEBUG - 2011-07-30 13:51:04 --> Total execution time: 0.0302
DEBUG - 2011-07-30 13:51:06 --> Config Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:51:06 --> URI Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Router Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Output Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Input Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:51:06 --> Language Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Loader Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Controller Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Model Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Model Class Initialized
DEBUG - 2011-07-30 13:51:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:51:06 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:51:07 --> Final output sent to browser
DEBUG - 2011-07-30 13:51:07 --> Total execution time: 0.5965
DEBUG - 2011-07-30 13:51:11 --> Config Class Initialized
DEBUG - 2011-07-30 13:51:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:51:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:51:11 --> URI Class Initialized
DEBUG - 2011-07-30 13:51:11 --> Router Class Initialized
ERROR - 2011-07-30 13:51:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 13:58:53 --> Config Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:58:53 --> URI Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Router Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Output Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Input Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:58:53 --> Language Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Loader Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Controller Class Initialized
ERROR - 2011-07-30 13:58:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 13:58:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:58:53 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:58:53 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 13:58:53 --> Helper loaded: url_helper
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 13:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 13:58:53 --> Final output sent to browser
DEBUG - 2011-07-30 13:58:53 --> Total execution time: 0.0287
DEBUG - 2011-07-30 13:58:54 --> Config Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:58:54 --> URI Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Router Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Output Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Input Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:58:54 --> Language Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Loader Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Controller Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:58:54 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:58:54 --> Final output sent to browser
DEBUG - 2011-07-30 13:58:54 --> Total execution time: 0.5254
DEBUG - 2011-07-30 13:58:55 --> Config Class Initialized
DEBUG - 2011-07-30 13:58:55 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:58:55 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:58:55 --> URI Class Initialized
DEBUG - 2011-07-30 13:58:55 --> Router Class Initialized
ERROR - 2011-07-30 13:58:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 13:58:59 --> Config Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:58:59 --> URI Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Router Class Initialized
ERROR - 2011-07-30 13:58:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 13:58:59 --> Config Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:58:59 --> URI Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Router Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Output Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Input Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:58:59 --> Language Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Loader Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Controller Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Model Class Initialized
DEBUG - 2011-07-30 13:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:58:59 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:59:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 13:59:00 --> Helper loaded: url_helper
DEBUG - 2011-07-30 13:59:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 13:59:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 13:59:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 13:59:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 13:59:00 --> Final output sent to browser
DEBUG - 2011-07-30 13:59:00 --> Total execution time: 0.7198
DEBUG - 2011-07-30 13:59:53 --> Config Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Hooks Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Utf8 Class Initialized
DEBUG - 2011-07-30 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 13:59:53 --> URI Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Router Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Output Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Input Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 13:59:53 --> Language Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Loader Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Controller Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Model Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Model Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Model Class Initialized
DEBUG - 2011-07-30 13:59:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 13:59:53 --> Database Driver Class Initialized
DEBUG - 2011-07-30 13:59:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 13:59:53 --> Helper loaded: url_helper
DEBUG - 2011-07-30 13:59:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 13:59:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 13:59:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 13:59:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 13:59:53 --> Final output sent to browser
DEBUG - 2011-07-30 13:59:53 --> Total execution time: 0.0526
DEBUG - 2011-07-30 14:50:05 --> Config Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Hooks Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Utf8 Class Initialized
DEBUG - 2011-07-30 14:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 14:50:05 --> URI Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Router Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Output Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Input Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 14:50:05 --> Language Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Loader Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Controller Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Model Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Model Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Model Class Initialized
DEBUG - 2011-07-30 14:50:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 14:50:05 --> Database Driver Class Initialized
DEBUG - 2011-07-30 14:50:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 14:50:05 --> Helper loaded: url_helper
DEBUG - 2011-07-30 14:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 14:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 14:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 14:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 14:50:05 --> Final output sent to browser
DEBUG - 2011-07-30 14:50:05 --> Total execution time: 0.6544
DEBUG - 2011-07-30 15:24:39 --> Config Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Hooks Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Utf8 Class Initialized
DEBUG - 2011-07-30 15:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 15:24:39 --> URI Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Router Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Output Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Input Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 15:24:39 --> Language Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Loader Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Controller Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Model Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Model Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Model Class Initialized
DEBUG - 2011-07-30 15:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 15:24:39 --> Database Driver Class Initialized
DEBUG - 2011-07-30 15:24:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 15:24:39 --> Helper loaded: url_helper
DEBUG - 2011-07-30 15:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 15:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 15:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 15:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 15:24:39 --> Final output sent to browser
DEBUG - 2011-07-30 15:24:39 --> Total execution time: 0.4796
DEBUG - 2011-07-30 15:24:41 --> Config Class Initialized
DEBUG - 2011-07-30 15:24:41 --> Hooks Class Initialized
DEBUG - 2011-07-30 15:24:41 --> Utf8 Class Initialized
DEBUG - 2011-07-30 15:24:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 15:24:41 --> URI Class Initialized
DEBUG - 2011-07-30 15:24:41 --> Router Class Initialized
ERROR - 2011-07-30 15:24:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 16:19:31 --> Config Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Hooks Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Utf8 Class Initialized
DEBUG - 2011-07-30 16:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 16:19:31 --> URI Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Router Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Output Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Input Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 16:19:31 --> Language Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Loader Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Controller Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Model Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Model Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Model Class Initialized
DEBUG - 2011-07-30 16:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 16:19:31 --> Database Driver Class Initialized
DEBUG - 2011-07-30 16:19:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 16:19:32 --> Helper loaded: url_helper
DEBUG - 2011-07-30 16:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 16:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 16:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 16:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 16:19:32 --> Final output sent to browser
DEBUG - 2011-07-30 16:19:32 --> Total execution time: 0.5372
DEBUG - 2011-07-30 16:19:37 --> Config Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 16:19:37 --> URI Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Router Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Output Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Input Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 16:19:37 --> Language Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Loader Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Controller Class Initialized
ERROR - 2011-07-30 16:19:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 16:19:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 16:19:37 --> Model Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Model Class Initialized
DEBUG - 2011-07-30 16:19:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 16:19:37 --> Database Driver Class Initialized
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 16:19:37 --> Helper loaded: url_helper
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 16:19:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 16:19:37 --> Final output sent to browser
DEBUG - 2011-07-30 16:19:37 --> Total execution time: 0.0445
DEBUG - 2011-07-30 16:52:43 --> Config Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 16:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 16:52:43 --> URI Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Router Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Output Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Input Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 16:52:43 --> Language Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Loader Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Controller Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Model Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Model Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Model Class Initialized
DEBUG - 2011-07-30 16:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 16:52:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 16:52:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 16:52:43 --> Helper loaded: url_helper
DEBUG - 2011-07-30 16:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 16:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 16:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 16:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 16:52:43 --> Final output sent to browser
DEBUG - 2011-07-30 16:52:43 --> Total execution time: 0.3365
DEBUG - 2011-07-30 16:52:58 --> Config Class Initialized
DEBUG - 2011-07-30 16:52:58 --> Hooks Class Initialized
DEBUG - 2011-07-30 16:52:58 --> Utf8 Class Initialized
DEBUG - 2011-07-30 16:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 16:52:58 --> URI Class Initialized
DEBUG - 2011-07-30 16:52:58 --> Router Class Initialized
ERROR - 2011-07-30 16:52:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 17:19:10 --> Config Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Hooks Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Utf8 Class Initialized
DEBUG - 2011-07-30 17:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 17:19:10 --> URI Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Router Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Output Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Input Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 17:19:10 --> Language Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Loader Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Controller Class Initialized
ERROR - 2011-07-30 17:19:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 17:19:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 17:19:10 --> Model Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Model Class Initialized
DEBUG - 2011-07-30 17:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 17:19:10 --> Database Driver Class Initialized
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 17:19:10 --> Helper loaded: url_helper
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 17:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 17:19:10 --> Final output sent to browser
DEBUG - 2011-07-30 17:19:10 --> Total execution time: 0.0512
DEBUG - 2011-07-30 17:19:11 --> Config Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 17:19:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 17:19:11 --> URI Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Router Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Output Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Input Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 17:19:11 --> Language Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Loader Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Controller Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Model Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Model Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 17:19:11 --> Database Driver Class Initialized
DEBUG - 2011-07-30 17:19:11 --> Final output sent to browser
DEBUG - 2011-07-30 17:19:11 --> Total execution time: 0.6082
DEBUG - 2011-07-30 17:19:12 --> Config Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Hooks Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Utf8 Class Initialized
DEBUG - 2011-07-30 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 17:19:12 --> URI Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Router Class Initialized
ERROR - 2011-07-30 17:19:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 17:19:12 --> Config Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Hooks Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Utf8 Class Initialized
DEBUG - 2011-07-30 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 17:19:12 --> URI Class Initialized
DEBUG - 2011-07-30 17:19:12 --> Router Class Initialized
ERROR - 2011-07-30 17:19:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 19:13:33 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:33 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Router Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Output Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Input Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 19:13:33 --> Language Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Loader Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Controller Class Initialized
ERROR - 2011-07-30 19:13:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 19:13:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:13:33 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 19:13:33 --> Database Driver Class Initialized
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:13:33 --> Helper loaded: url_helper
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 19:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 19:13:33 --> Final output sent to browser
DEBUG - 2011-07-30 19:13:33 --> Total execution time: 0.0660
DEBUG - 2011-07-30 19:13:35 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:35 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Router Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Output Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Input Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 19:13:35 --> Language Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Loader Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Controller Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 19:13:35 --> Database Driver Class Initialized
DEBUG - 2011-07-30 19:13:35 --> Final output sent to browser
DEBUG - 2011-07-30 19:13:35 --> Total execution time: 0.5425
DEBUG - 2011-07-30 19:13:37 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:37 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:37 --> Router Class Initialized
ERROR - 2011-07-30 19:13:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 19:13:45 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:45 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Router Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Output Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Input Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 19:13:45 --> Language Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Loader Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Controller Class Initialized
ERROR - 2011-07-30 19:13:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 19:13:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:13:45 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 19:13:45 --> Database Driver Class Initialized
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:13:45 --> Helper loaded: url_helper
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 19:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 19:13:45 --> Final output sent to browser
DEBUG - 2011-07-30 19:13:45 --> Total execution time: 0.0322
DEBUG - 2011-07-30 19:13:45 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:45 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Router Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Output Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Input Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 19:13:45 --> Language Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Loader Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Controller Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Model Class Initialized
DEBUG - 2011-07-30 19:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 19:13:45 --> Database Driver Class Initialized
DEBUG - 2011-07-30 19:13:46 --> Final output sent to browser
DEBUG - 2011-07-30 19:13:46 --> Total execution time: 0.5158
DEBUG - 2011-07-30 19:13:48 --> Config Class Initialized
DEBUG - 2011-07-30 19:13:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:13:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:13:48 --> URI Class Initialized
DEBUG - 2011-07-30 19:13:48 --> Router Class Initialized
ERROR - 2011-07-30 19:13:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 19:14:17 --> Config Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:14:17 --> URI Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Router Class Initialized
ERROR - 2011-07-30 19:14:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-30 19:14:17 --> Config Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Hooks Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Utf8 Class Initialized
DEBUG - 2011-07-30 19:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 19:14:17 --> URI Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Router Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Output Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Input Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 19:14:17 --> Language Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Loader Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Controller Class Initialized
ERROR - 2011-07-30 19:14:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 19:14:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:14:17 --> Model Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Model Class Initialized
DEBUG - 2011-07-30 19:14:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 19:14:17 --> Database Driver Class Initialized
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 19:14:17 --> Helper loaded: url_helper
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 19:14:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 19:14:17 --> Final output sent to browser
DEBUG - 2011-07-30 19:14:17 --> Total execution time: 0.0274
DEBUG - 2011-07-30 20:16:31 --> Config Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Hooks Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Utf8 Class Initialized
DEBUG - 2011-07-30 20:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 20:16:31 --> URI Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Router Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Output Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Input Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 20:16:31 --> Language Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Loader Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Controller Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Model Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Model Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Model Class Initialized
DEBUG - 2011-07-30 20:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 20:16:31 --> Database Driver Class Initialized
DEBUG - 2011-07-30 20:16:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 20:16:31 --> Helper loaded: url_helper
DEBUG - 2011-07-30 20:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 20:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 20:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 20:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 20:16:31 --> Final output sent to browser
DEBUG - 2011-07-30 20:16:31 --> Total execution time: 0.2457
DEBUG - 2011-07-30 20:16:36 --> Config Class Initialized
DEBUG - 2011-07-30 20:16:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 20:16:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 20:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 20:16:36 --> URI Class Initialized
DEBUG - 2011-07-30 20:16:36 --> Router Class Initialized
ERROR - 2011-07-30 20:16:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 20:16:37 --> Config Class Initialized
DEBUG - 2011-07-30 20:16:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 20:16:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 20:16:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 20:16:37 --> URI Class Initialized
DEBUG - 2011-07-30 20:16:37 --> Router Class Initialized
ERROR - 2011-07-30 20:16:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 21:08:42 --> Config Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Hooks Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Utf8 Class Initialized
DEBUG - 2011-07-30 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 21:08:42 --> URI Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Router Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Output Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Input Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 21:08:42 --> Language Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Loader Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Controller Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Model Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Model Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Model Class Initialized
DEBUG - 2011-07-30 21:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 21:08:42 --> Database Driver Class Initialized
DEBUG - 2011-07-30 21:08:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 21:08:42 --> Helper loaded: url_helper
DEBUG - 2011-07-30 21:08:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 21:08:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 21:08:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 21:08:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 21:08:42 --> Final output sent to browser
DEBUG - 2011-07-30 21:08:42 --> Total execution time: 0.3377
DEBUG - 2011-07-30 22:54:27 --> Config Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 22:54:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 22:54:27 --> URI Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Router Class Initialized
DEBUG - 2011-07-30 22:54:27 --> No URI present. Default controller set.
DEBUG - 2011-07-30 22:54:27 --> Output Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Input Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 22:54:27 --> Language Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Loader Class Initialized
DEBUG - 2011-07-30 22:54:27 --> Controller Class Initialized
DEBUG - 2011-07-30 22:54:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-30 22:54:27 --> Helper loaded: url_helper
DEBUG - 2011-07-30 22:54:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 22:54:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 22:54:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 22:54:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 22:54:27 --> Final output sent to browser
DEBUG - 2011-07-30 22:54:27 --> Total execution time: 0.0738
DEBUG - 2011-07-30 23:04:26 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:26 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:26 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Controller Class Initialized
ERROR - 2011-07-30 23:04:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:04:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:26 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:26 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:04:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:04:26 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:26 --> Total execution time: 0.0473
DEBUG - 2011-07-30 23:04:27 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:27 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:27 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Controller Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:27 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:27 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:27 --> Total execution time: 0.6868
DEBUG - 2011-07-30 23:04:28 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:28 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:28 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:28 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:28 --> Router Class Initialized
ERROR - 2011-07-30 23:04:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:04:30 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:30 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:30 --> Router Class Initialized
ERROR - 2011-07-30 23:04:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:04:47 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:47 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:47 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Controller Class Initialized
ERROR - 2011-07-30 23:04:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:04:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:47 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:47 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:04:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:04:47 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:47 --> Total execution time: 0.0259
DEBUG - 2011-07-30 23:04:47 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:47 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:47 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Controller Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:47 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:48 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:48 --> Total execution time: 0.6767
DEBUG - 2011-07-30 23:04:49 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:49 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:49 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:49 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:49 --> Router Class Initialized
ERROR - 2011-07-30 23:04:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:04:55 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:55 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:55 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Controller Class Initialized
ERROR - 2011-07-30 23:04:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:04:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:55 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:04:55 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:04:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:04:55 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:55 --> Total execution time: 0.0272
DEBUG - 2011-07-30 23:04:55 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:55 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Router Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Output Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Input Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:04:55 --> Language Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Loader Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Controller Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:04:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:04:55 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:04:56 --> Final output sent to browser
DEBUG - 2011-07-30 23:04:56 --> Total execution time: 0.8612
DEBUG - 2011-07-30 23:04:57 --> Config Class Initialized
DEBUG - 2011-07-30 23:04:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:04:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:04:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:04:57 --> URI Class Initialized
DEBUG - 2011-07-30 23:04:57 --> Router Class Initialized
ERROR - 2011-07-30 23:04:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:04 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:04 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:04 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:04 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:04 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:04 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:04 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:04 --> Total execution time: 0.0455
DEBUG - 2011-07-30 23:05:04 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:04 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:04 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:04 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:06 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:06 --> Total execution time: 1.6671
DEBUG - 2011-07-30 23:05:07 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:07 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:07 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:07 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:07 --> Router Class Initialized
ERROR - 2011-07-30 23:05:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:13 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:13 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:13 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:13 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:13 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:13 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:13 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:13 --> Total execution time: 0.0291
DEBUG - 2011-07-30 23:05:14 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:14 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:14 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:14 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:14 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:14 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:14 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:14 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:14 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:14 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:14 --> Total execution time: 0.0452
DEBUG - 2011-07-30 23:05:14 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:14 --> Total execution time: 0.5488
DEBUG - 2011-07-30 23:05:15 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:15 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:15 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:15 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:15 --> Router Class Initialized
ERROR - 2011-07-30 23:05:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:20 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:20 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:20 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:20 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:20 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:20 --> Total execution time: 0.0747
DEBUG - 2011-07-30 23:05:21 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:21 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:21 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:21 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:21 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:21 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:21 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:21 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:21 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:21 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:21 --> Total execution time: 0.0286
DEBUG - 2011-07-30 23:05:21 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:21 --> Total execution time: 0.5530
DEBUG - 2011-07-30 23:05:22 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:22 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:22 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:22 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:22 --> Router Class Initialized
ERROR - 2011-07-30 23:05:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:30 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:30 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:30 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:30 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:30 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:30 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:30 --> Total execution time: 0.0276
DEBUG - 2011-07-30 23:05:30 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:30 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:30 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:30 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:31 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:31 --> Total execution time: 0.5446
DEBUG - 2011-07-30 23:05:32 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:32 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:32 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:32 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:32 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:32 --> Router Class Initialized
ERROR - 2011-07-30 23:05:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:32 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:32 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:32 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:32 --> Total execution time: 0.0303
DEBUG - 2011-07-30 23:05:36 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:36 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:36 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:36 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:36 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:36 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:36 --> Total execution time: 0.0296
DEBUG - 2011-07-30 23:05:37 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:37 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:37 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:37 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:37 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:37 --> Total execution time: 0.5741
DEBUG - 2011-07-30 23:05:39 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:39 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:39 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:39 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:39 --> Router Class Initialized
ERROR - 2011-07-30 23:05:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:46 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:46 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:46 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:46 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:46 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:46 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:46 --> Total execution time: 0.0304
DEBUG - 2011-07-30 23:05:46 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:46 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:46 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:46 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:47 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:47 --> Total execution time: 0.6119
DEBUG - 2011-07-30 23:05:47 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:47 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:47 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:47 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:47 --> Router Class Initialized
ERROR - 2011-07-30 23:05:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:51 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:51 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:51 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:51 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:51 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:51 --> Total execution time: 0.0289
DEBUG - 2011-07-30 23:05:51 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:51 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:51 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:52 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:52 --> Total execution time: 0.5457
DEBUG - 2011-07-30 23:05:54 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:54 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:54 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:54 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:54 --> Router Class Initialized
ERROR - 2011-07-30 23:05:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:05:57 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:57 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:57 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Controller Class Initialized
ERROR - 2011-07-30 23:05:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:05:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:57 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:57 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:05:57 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:05:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:05:57 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:57 --> Total execution time: 0.0282
DEBUG - 2011-07-30 23:05:57 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:57 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Router Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Output Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Input Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:05:57 --> Language Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Loader Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Controller Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Model Class Initialized
DEBUG - 2011-07-30 23:05:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:05:57 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:05:58 --> Final output sent to browser
DEBUG - 2011-07-30 23:05:58 --> Total execution time: 0.5495
DEBUG - 2011-07-30 23:05:59 --> Config Class Initialized
DEBUG - 2011-07-30 23:05:59 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:05:59 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:05:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:05:59 --> URI Class Initialized
DEBUG - 2011-07-30 23:05:59 --> Router Class Initialized
ERROR - 2011-07-30 23:05:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:01 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:01 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:01 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:01 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:01 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:01 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:01 --> Total execution time: 0.0302
DEBUG - 2011-07-30 23:06:01 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:01 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:01 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:01 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:02 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:02 --> Total execution time: 0.5279
DEBUG - 2011-07-30 23:06:03 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:03 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:03 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:03 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:03 --> Router Class Initialized
ERROR - 2011-07-30 23:06:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:09 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:09 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:09 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:09 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:09 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:09 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:09 --> Total execution time: 0.0282
DEBUG - 2011-07-30 23:06:09 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:09 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:09 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:09 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:09 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:09 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:09 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:09 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:09 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:09 --> Total execution time: 0.0282
DEBUG - 2011-07-30 23:06:10 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:10 --> Total execution time: 0.6264
DEBUG - 2011-07-30 23:06:11 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:11 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:11 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:11 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:11 --> Router Class Initialized
ERROR - 2011-07-30 23:06:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:16 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:16 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:16 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:16 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:16 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:16 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:16 --> Total execution time: 0.0385
DEBUG - 2011-07-30 23:06:16 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:16 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:16 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:16 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:16 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:16 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:16 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:16 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:16 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:16 --> Total execution time: 0.0282
DEBUG - 2011-07-30 23:06:17 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:17 --> Total execution time: 0.5433
DEBUG - 2011-07-30 23:06:18 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:18 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:18 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:18 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:18 --> Router Class Initialized
ERROR - 2011-07-30 23:06:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:20 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:20 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:20 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:20 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:20 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:20 --> Total execution time: 0.0319
DEBUG - 2011-07-30 23:06:20 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:20 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:20 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:20 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:20 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:20 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:20 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:20 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:20 --> Total execution time: 0.0295
DEBUG - 2011-07-30 23:06:21 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:21 --> Total execution time: 0.5080
DEBUG - 2011-07-30 23:06:22 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:22 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:22 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:22 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:22 --> Router Class Initialized
ERROR - 2011-07-30 23:06:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:24 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:24 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:24 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:24 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:24 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:24 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:24 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:24 --> Total execution time: 0.0318
DEBUG - 2011-07-30 23:06:25 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:25 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:25 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:25 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:25 --> Total execution time: 0.5135
DEBUG - 2011-07-30 23:06:25 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:25 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:25 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:25 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:25 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:25 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:25 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:25 --> Total execution time: 0.0287
DEBUG - 2011-07-30 23:06:29 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:29 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:29 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:29 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:29 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:29 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:29 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:29 --> Total execution time: 0.0279
DEBUG - 2011-07-30 23:06:30 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:30 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Router Class Initialized
ERROR - 2011-07-30 23:06:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:30 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:30 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:30 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:30 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:30 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:30 --> Total execution time: 0.5211
DEBUG - 2011-07-30 23:06:31 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:31 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:31 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:31 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:31 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:31 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:31 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:31 --> Total execution time: 0.0271
DEBUG - 2011-07-30 23:06:34 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:34 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:34 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:34 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:34 --> Router Class Initialized
ERROR - 2011-07-30 23:06:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:35 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:35 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:35 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:35 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:35 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:35 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:35 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:35 --> Total execution time: 0.0308
DEBUG - 2011-07-30 23:06:36 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:36 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:36 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:36 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:36 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:36 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:36 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:36 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:36 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:36 --> Total execution time: 0.0280
DEBUG - 2011-07-30 23:06:36 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:36 --> Total execution time: 0.4958
DEBUG - 2011-07-30 23:06:37 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:37 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:37 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:37 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:37 --> Router Class Initialized
ERROR - 2011-07-30 23:06:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:39 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:39 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:39 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:39 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:39 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:39 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:39 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:39 --> Total execution time: 0.0406
DEBUG - 2011-07-30 23:06:39 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:39 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:39 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:39 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:40 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:40 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:40 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:40 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:40 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:40 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:40 --> Total execution time: 0.0652
DEBUG - 2011-07-30 23:06:40 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:40 --> Total execution time: 0.5373
DEBUG - 2011-07-30 23:06:40 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:40 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:40 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:40 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:40 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:40 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:40 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:40 --> Total execution time: 0.0269
DEBUG - 2011-07-30 23:06:42 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:42 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:42 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:42 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:42 --> Router Class Initialized
ERROR - 2011-07-30 23:06:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:43 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:43 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:43 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:43 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:43 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:43 --> Total execution time: 0.0494
DEBUG - 2011-07-30 23:06:43 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:43 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:43 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:43 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:43 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:43 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:43 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:43 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:43 --> Total execution time: 0.0301
DEBUG - 2011-07-30 23:06:44 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:44 --> Total execution time: 0.7132
DEBUG - 2011-07-30 23:06:45 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:45 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:45 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:45 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:45 --> Router Class Initialized
ERROR - 2011-07-30 23:06:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:46 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:46 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:46 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:46 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:46 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:46 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:46 --> Total execution time: 0.0272
DEBUG - 2011-07-30 23:06:47 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:47 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:47 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:47 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:47 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:47 --> Total execution time: 0.5581
DEBUG - 2011-07-30 23:06:48 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:48 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:48 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:48 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:48 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:48 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:48 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:48 --> Total execution time: 0.0294
DEBUG - 2011-07-30 23:06:50 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:50 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:50 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:50 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:50 --> Router Class Initialized
ERROR - 2011-07-30 23:06:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:51 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:51 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:51 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:51 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:51 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:51 --> Total execution time: 0.0289
DEBUG - 2011-07-30 23:06:51 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:51 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:51 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:51 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:52 --> Total execution time: 0.5191
DEBUG - 2011-07-30 23:06:52 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:52 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:52 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:52 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:52 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:52 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:52 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:52 --> Total execution time: 0.0289
DEBUG - 2011-07-30 23:06:53 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:53 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:53 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:53 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:53 --> Router Class Initialized
ERROR - 2011-07-30 23:06:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:06:54 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:54 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:54 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:54 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:54 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:54 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:54 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:54 --> Total execution time: 0.0285
DEBUG - 2011-07-30 23:06:55 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:55 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:55 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Controller Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:55 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:55 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:55 --> Total execution time: 0.6199
DEBUG - 2011-07-30 23:06:56 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:56 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Router Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Output Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Input Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:06:56 --> Language Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Loader Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Controller Class Initialized
ERROR - 2011-07-30 23:06:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-30 23:06:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:56 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Model Class Initialized
DEBUG - 2011-07-30 23:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:06:56 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-30 23:06:56 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:06:56 --> Final output sent to browser
DEBUG - 2011-07-30 23:06:56 --> Total execution time: 0.0275
DEBUG - 2011-07-30 23:06:57 --> Config Class Initialized
DEBUG - 2011-07-30 23:06:57 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:06:57 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:06:57 --> URI Class Initialized
DEBUG - 2011-07-30 23:06:57 --> Router Class Initialized
ERROR - 2011-07-30 23:06:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-30 23:07:16 --> Config Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:07:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:07:16 --> URI Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Router Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Output Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Input Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-30 23:07:16 --> Language Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Loader Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Controller Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Model Class Initialized
DEBUG - 2011-07-30 23:07:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-30 23:07:16 --> Database Driver Class Initialized
DEBUG - 2011-07-30 23:07:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-30 23:07:16 --> Helper loaded: url_helper
DEBUG - 2011-07-30 23:07:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-30 23:07:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-30 23:07:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-30 23:07:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-30 23:07:16 --> Final output sent to browser
DEBUG - 2011-07-30 23:07:16 --> Total execution time: 0.3645
DEBUG - 2011-07-30 23:07:20 --> Config Class Initialized
DEBUG - 2011-07-30 23:07:20 --> Hooks Class Initialized
DEBUG - 2011-07-30 23:07:20 --> Utf8 Class Initialized
DEBUG - 2011-07-30 23:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-30 23:07:20 --> URI Class Initialized
DEBUG - 2011-07-30 23:07:20 --> Router Class Initialized
ERROR - 2011-07-30 23:07:20 --> 404 Page Not Found --> favicon.ico

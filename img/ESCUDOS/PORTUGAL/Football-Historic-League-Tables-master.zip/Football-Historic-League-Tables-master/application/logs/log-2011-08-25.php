<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-25 00:02:20 --> Config Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:02:20 --> URI Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Router Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Output Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Input Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:02:20 --> Language Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Loader Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Controller Class Initialized
ERROR - 2011-08-25 00:02:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 00:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 00:02:20 --> Model Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Model Class Initialized
DEBUG - 2011-08-25 00:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:02:20 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 00:02:20 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:02:20 --> Final output sent to browser
DEBUG - 2011-08-25 00:02:20 --> Total execution time: 0.0567
DEBUG - 2011-08-25 00:02:21 --> Config Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:02:21 --> URI Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Router Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Output Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Input Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:02:21 --> Language Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Loader Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Controller Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Model Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Model Class Initialized
DEBUG - 2011-08-25 00:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:02:21 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:02:23 --> Final output sent to browser
DEBUG - 2011-08-25 00:02:23 --> Total execution time: 1.1488
DEBUG - 2011-08-25 00:02:25 --> Config Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:02:25 --> URI Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Router Class Initialized
ERROR - 2011-08-25 00:02:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 00:02:25 --> Config Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:02:25 --> URI Class Initialized
DEBUG - 2011-08-25 00:02:25 --> Router Class Initialized
ERROR - 2011-08-25 00:02:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 00:02:26 --> Config Class Initialized
DEBUG - 2011-08-25 00:02:26 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:02:26 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:02:26 --> URI Class Initialized
DEBUG - 2011-08-25 00:02:26 --> Router Class Initialized
ERROR - 2011-08-25 00:02:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 00:48:08 --> Config Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:48:08 --> URI Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Router Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Output Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Input Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:48:08 --> Language Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Loader Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Controller Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Model Class Initialized
DEBUG - 2011-08-25 00:48:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:48:08 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:48:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:48:08 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:48:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:48:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:48:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:48:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:48:08 --> Final output sent to browser
DEBUG - 2011-08-25 00:48:08 --> Total execution time: 0.5219
DEBUG - 2011-08-25 00:48:25 --> Config Class Initialized
DEBUG - 2011-08-25 00:48:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:48:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:48:25 --> URI Class Initialized
DEBUG - 2011-08-25 00:48:25 --> Router Class Initialized
ERROR - 2011-08-25 00:48:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 00:50:13 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:13 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:13 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:13 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:14 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:14 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:14 --> Total execution time: 0.2265
DEBUG - 2011-08-25 00:50:15 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:15 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:15 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:15 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:15 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:15 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:15 --> Total execution time: 0.0488
DEBUG - 2011-08-25 00:50:18 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:18 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:18 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:18 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:18 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:18 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:18 --> Total execution time: 0.0520
DEBUG - 2011-08-25 00:50:18 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:18 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:18 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:18 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:18 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:18 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:18 --> Total execution time: 0.0415
DEBUG - 2011-08-25 00:50:25 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:25 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:25 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:25 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:25 --> Total execution time: 0.2004
DEBUG - 2011-08-25 00:50:28 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:28 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:28 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:28 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:28 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:28 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:28 --> Total execution time: 0.0458
DEBUG - 2011-08-25 00:50:42 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:42 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:42 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:42 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:43 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:43 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:43 --> Total execution time: 0.2727
DEBUG - 2011-08-25 00:50:44 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:44 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:44 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:44 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:44 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:44 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:44 --> Total execution time: 0.0444
DEBUG - 2011-08-25 00:50:45 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:45 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:45 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:45 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:45 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:45 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:45 --> Total execution time: 0.0792
DEBUG - 2011-08-25 00:50:58 --> Config Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:50:58 --> URI Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Router Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Output Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Input Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:50:58 --> Language Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Loader Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Controller Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Model Class Initialized
DEBUG - 2011-08-25 00:50:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:50:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:50:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:50:58 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:50:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:50:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:50:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:50:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:50:58 --> Final output sent to browser
DEBUG - 2011-08-25 00:50:58 --> Total execution time: 0.1017
DEBUG - 2011-08-25 00:51:07 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:07 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:07 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:07 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:07 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:07 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:07 --> Total execution time: 0.1102
DEBUG - 2011-08-25 00:51:16 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:16 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:16 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:16 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:16 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:16 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:16 --> Total execution time: 0.0429
DEBUG - 2011-08-25 00:51:30 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:30 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:30 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:30 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:30 --> Total execution time: 0.2638
DEBUG - 2011-08-25 00:51:32 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:32 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:32 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:32 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:32 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:32 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:32 --> Total execution time: 0.0561
DEBUG - 2011-08-25 00:51:37 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:37 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:37 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:37 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:38 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:38 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:38 --> Total execution time: 0.3044
DEBUG - 2011-08-25 00:51:40 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:40 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:40 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:40 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:40 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:40 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:40 --> Total execution time: 0.0486
DEBUG - 2011-08-25 00:51:55 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:55 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:55 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:55 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:55 --> Total execution time: 0.2199
DEBUG - 2011-08-25 00:51:57 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:57 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:57 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:57 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:57 --> Total execution time: 0.0476
DEBUG - 2011-08-25 00:51:57 --> Config Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 00:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 00:51:57 --> URI Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Router Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Output Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Input Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 00:51:57 --> Language Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Loader Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Controller Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Model Class Initialized
DEBUG - 2011-08-25 00:51:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 00:51:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 00:51:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 00:51:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 00:51:57 --> Final output sent to browser
DEBUG - 2011-08-25 00:51:57 --> Total execution time: 0.0437
DEBUG - 2011-08-25 01:24:47 --> Config Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 01:24:47 --> URI Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Router Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Output Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Input Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 01:24:47 --> Language Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Loader Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Controller Class Initialized
ERROR - 2011-08-25 01:24:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 01:24:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 01:24:47 --> Model Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Model Class Initialized
DEBUG - 2011-08-25 01:24:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 01:24:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 01:24:47 --> Helper loaded: url_helper
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 01:24:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 01:24:47 --> Final output sent to browser
DEBUG - 2011-08-25 01:24:47 --> Total execution time: 0.0628
DEBUG - 2011-08-25 01:24:51 --> Config Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Hooks Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Utf8 Class Initialized
DEBUG - 2011-08-25 01:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 01:24:51 --> URI Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Router Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Output Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Input Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 01:24:51 --> Language Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Loader Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Controller Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Model Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Model Class Initialized
DEBUG - 2011-08-25 01:24:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 01:24:51 --> Database Driver Class Initialized
DEBUG - 2011-08-25 01:24:52 --> Final output sent to browser
DEBUG - 2011-08-25 01:24:52 --> Total execution time: 0.7030
DEBUG - 2011-08-25 01:28:43 --> Config Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Hooks Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Utf8 Class Initialized
DEBUG - 2011-08-25 01:28:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 01:28:43 --> URI Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Router Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Output Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Input Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 01:28:43 --> Language Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Loader Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Controller Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Model Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Model Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Model Class Initialized
DEBUG - 2011-08-25 01:28:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 01:28:43 --> Database Driver Class Initialized
DEBUG - 2011-08-25 01:28:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 01:28:43 --> Helper loaded: url_helper
DEBUG - 2011-08-25 01:28:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 01:28:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 01:28:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 01:28:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 01:28:43 --> Final output sent to browser
DEBUG - 2011-08-25 01:28:43 --> Total execution time: 0.3632
DEBUG - 2011-08-25 01:28:45 --> Config Class Initialized
DEBUG - 2011-08-25 01:28:45 --> Hooks Class Initialized
DEBUG - 2011-08-25 01:28:45 --> Utf8 Class Initialized
DEBUG - 2011-08-25 01:28:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 01:28:45 --> URI Class Initialized
DEBUG - 2011-08-25 01:28:45 --> Router Class Initialized
ERROR - 2011-08-25 01:28:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 02:22:22 --> Config Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 02:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 02:22:22 --> URI Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Router Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Output Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Input Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 02:22:22 --> Language Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Loader Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Controller Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Model Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Model Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Model Class Initialized
DEBUG - 2011-08-25 02:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 02:22:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 02:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 02:22:24 --> Helper loaded: url_helper
DEBUG - 2011-08-25 02:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 02:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 02:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 02:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 02:22:24 --> Final output sent to browser
DEBUG - 2011-08-25 02:22:24 --> Total execution time: 2.3030
DEBUG - 2011-08-25 02:22:26 --> Config Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Hooks Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Utf8 Class Initialized
DEBUG - 2011-08-25 02:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 02:22:26 --> URI Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Router Class Initialized
ERROR - 2011-08-25 02:22:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 02:22:26 --> Config Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Hooks Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Utf8 Class Initialized
DEBUG - 2011-08-25 02:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 02:22:26 --> URI Class Initialized
DEBUG - 2011-08-25 02:22:26 --> Router Class Initialized
ERROR - 2011-08-25 02:22:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 02:24:24 --> Config Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 02:24:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 02:24:24 --> URI Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Router Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Output Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Input Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 02:24:24 --> Language Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Loader Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Controller Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 02:24:24 --> Database Driver Class Initialized
DEBUG - 2011-08-25 02:24:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 02:24:24 --> Helper loaded: url_helper
DEBUG - 2011-08-25 02:24:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 02:24:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 02:24:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 02:24:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 02:24:24 --> Final output sent to browser
DEBUG - 2011-08-25 02:24:24 --> Total execution time: 0.6121
DEBUG - 2011-08-25 02:24:33 --> Config Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 02:24:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 02:24:33 --> URI Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Router Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Output Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Input Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 02:24:33 --> Language Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Loader Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Controller Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Model Class Initialized
DEBUG - 2011-08-25 02:24:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 02:24:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 02:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 02:24:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 02:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 02:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 02:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 02:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 02:24:35 --> Final output sent to browser
DEBUG - 2011-08-25 02:24:35 --> Total execution time: 1.8559
DEBUG - 2011-08-25 03:01:57 --> Config Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:01:57 --> URI Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Router Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Output Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Input Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:01:57 --> Language Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Loader Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Controller Class Initialized
ERROR - 2011-08-25 03:01:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:01:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:01:57 --> Model Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Model Class Initialized
DEBUG - 2011-08-25 03:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:01:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:01:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:01:57 --> Final output sent to browser
DEBUG - 2011-08-25 03:01:57 --> Total execution time: 0.6080
DEBUG - 2011-08-25 03:14:59 --> Config Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:14:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:14:59 --> URI Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Router Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Output Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Input Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:14:59 --> Language Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Loader Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Controller Class Initialized
ERROR - 2011-08-25 03:14:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:14:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:14:59 --> Model Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Model Class Initialized
DEBUG - 2011-08-25 03:14:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:14:59 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:14:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:15:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:15:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:15:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:15:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:15:00 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:00 --> Total execution time: 0.5494
DEBUG - 2011-08-25 03:15:01 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:01 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:01 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Controller Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:01 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:03 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:03 --> Total execution time: 1.8687
DEBUG - 2011-08-25 03:15:04 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:04 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:04 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:04 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:04 --> Router Class Initialized
ERROR - 2011-08-25 03:15:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:15:11 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:11 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:11 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Controller Class Initialized
ERROR - 2011-08-25 03:15:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:15:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:11 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:11 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:11 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:15:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:15:11 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:11 --> Total execution time: 0.0963
DEBUG - 2011-08-25 03:15:12 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:12 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:12 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Controller Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:12 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:13 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:13 --> Total execution time: 0.8889
DEBUG - 2011-08-25 03:15:14 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:14 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:14 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:14 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:14 --> Router Class Initialized
ERROR - 2011-08-25 03:15:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:15:28 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:28 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:28 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Controller Class Initialized
ERROR - 2011-08-25 03:15:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:15:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:15:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:28 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:28 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:28 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:15:29 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:29 --> Total execution time: 0.2303
DEBUG - 2011-08-25 03:15:30 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:30 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:30 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Controller Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:32 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:32 --> Total execution time: 2.2415
DEBUG - 2011-08-25 03:15:33 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:33 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:33 --> Router Class Initialized
ERROR - 2011-08-25 03:15:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:15:38 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:38 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:38 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Controller Class Initialized
ERROR - 2011-08-25 03:15:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:15:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:15:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:38 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:38 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:39 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:15:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:15:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:15:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:15:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:15:39 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:39 --> Total execution time: 0.1799
DEBUG - 2011-08-25 03:15:39 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:39 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:39 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:39 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:40 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Controller Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:40 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:41 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:41 --> Total execution time: 1.3296
DEBUG - 2011-08-25 03:15:42 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:42 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:42 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:42 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:42 --> Router Class Initialized
ERROR - 2011-08-25 03:15:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:15:55 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:55 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:55 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Controller Class Initialized
ERROR - 2011-08-25 03:15:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:15:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:15:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:15:55 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:55 --> Total execution time: 0.0311
DEBUG - 2011-08-25 03:15:55 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:55 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Router Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Output Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Input Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:15:55 --> Language Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Loader Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Controller Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:15:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:15:56 --> Final output sent to browser
DEBUG - 2011-08-25 03:15:56 --> Total execution time: 1.0626
DEBUG - 2011-08-25 03:15:58 --> Config Class Initialized
DEBUG - 2011-08-25 03:15:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:15:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:15:58 --> URI Class Initialized
DEBUG - 2011-08-25 03:15:58 --> Router Class Initialized
ERROR - 2011-08-25 03:15:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:16:02 --> Config Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:16:02 --> URI Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Router Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Output Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Input Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:16:02 --> Language Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Loader Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Controller Class Initialized
ERROR - 2011-08-25 03:16:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:16:02 --> Model Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Model Class Initialized
DEBUG - 2011-08-25 03:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:16:02 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:16:02 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:16:02 --> Final output sent to browser
DEBUG - 2011-08-25 03:16:02 --> Total execution time: 0.1192
DEBUG - 2011-08-25 03:21:25 --> Config Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:21:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:21:25 --> URI Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Router Class Initialized
DEBUG - 2011-08-25 03:21:25 --> No URI present. Default controller set.
DEBUG - 2011-08-25 03:21:25 --> Output Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Input Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:21:25 --> Language Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Loader Class Initialized
DEBUG - 2011-08-25 03:21:25 --> Controller Class Initialized
DEBUG - 2011-08-25 03:21:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 03:21:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:21:25 --> Final output sent to browser
DEBUG - 2011-08-25 03:21:25 --> Total execution time: 0.0582
DEBUG - 2011-08-25 03:25:25 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:25 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Router Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Output Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Input Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:25:25 --> Language Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Loader Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Controller Class Initialized
ERROR - 2011-08-25 03:25:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:25:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:25:25 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:25:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:25:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:25:25 --> Final output sent to browser
DEBUG - 2011-08-25 03:25:25 --> Total execution time: 0.1505
DEBUG - 2011-08-25 03:25:26 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:26 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Router Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Output Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Input Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:25:26 --> Language Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Loader Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Controller Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:25:26 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:25:27 --> Final output sent to browser
DEBUG - 2011-08-25 03:25:27 --> Total execution time: 0.4644
DEBUG - 2011-08-25 03:25:29 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:29 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Router Class Initialized
ERROR - 2011-08-25 03:25:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:25:29 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:29 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:29 --> Router Class Initialized
ERROR - 2011-08-25 03:25:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:25:55 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:55 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Router Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Output Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Input Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:25:55 --> Language Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Loader Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Controller Class Initialized
ERROR - 2011-08-25 03:25:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:25:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:25:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:25:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:25:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:25:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:25:55 --> Final output sent to browser
DEBUG - 2011-08-25 03:25:55 --> Total execution time: 0.0425
DEBUG - 2011-08-25 03:25:56 --> Config Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:25:56 --> URI Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Router Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Output Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Input Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:25:56 --> Language Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Loader Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Controller Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Model Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:25:56 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:25:56 --> Final output sent to browser
DEBUG - 2011-08-25 03:25:56 --> Total execution time: 0.5532
DEBUG - 2011-08-25 03:43:05 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:05 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:05 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Controller Class Initialized
ERROR - 2011-08-25 03:43:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:43:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:05 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:05 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:05 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:43:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:43:05 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:05 --> Total execution time: 0.4947
DEBUG - 2011-08-25 03:43:12 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:12 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:12 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Controller Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:12 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:15 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:15 --> Total execution time: 2.8651
DEBUG - 2011-08-25 03:43:22 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:22 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:22 --> Router Class Initialized
ERROR - 2011-08-25 03:43:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:43:23 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:23 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:23 --> Router Class Initialized
ERROR - 2011-08-25 03:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 03:43:40 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:40 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:40 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Controller Class Initialized
ERROR - 2011-08-25 03:43:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:43:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:40 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:40 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:40 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:43:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:43:40 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:40 --> Total execution time: 0.1104
DEBUG - 2011-08-25 03:43:42 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:42 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:42 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Controller Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:42 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:43 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:43 --> Total execution time: 0.6006
DEBUG - 2011-08-25 03:43:44 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:44 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:44 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Controller Class Initialized
ERROR - 2011-08-25 03:43:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:43:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:44 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:44 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:44 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:43:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:43:44 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:44 --> Total execution time: 0.0766
DEBUG - 2011-08-25 03:43:56 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:56 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:56 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Controller Class Initialized
ERROR - 2011-08-25 03:43:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:43:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:56 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:56 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:43:56 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:43:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:43:56 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:56 --> Total execution time: 0.1520
DEBUG - 2011-08-25 03:43:58 --> Config Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:43:58 --> URI Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Router Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Output Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Input Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:43:58 --> Language Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Loader Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Controller Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Model Class Initialized
DEBUG - 2011-08-25 03:43:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:43:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:43:59 --> Final output sent to browser
DEBUG - 2011-08-25 03:43:59 --> Total execution time: 0.7655
DEBUG - 2011-08-25 03:44:00 --> Config Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:44:00 --> URI Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Router Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Output Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Input Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:44:00 --> Language Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Loader Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Controller Class Initialized
ERROR - 2011-08-25 03:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:00 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:44:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:44:00 --> Final output sent to browser
DEBUG - 2011-08-25 03:44:00 --> Total execution time: 0.1510
DEBUG - 2011-08-25 03:44:09 --> Config Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:44:09 --> URI Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Router Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Output Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Input Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:44:09 --> Language Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Loader Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Controller Class Initialized
ERROR - 2011-08-25 03:44:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:44:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:09 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:44:09 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:09 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:44:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:44:09 --> Final output sent to browser
DEBUG - 2011-08-25 03:44:09 --> Total execution time: 0.1271
DEBUG - 2011-08-25 03:44:12 --> Config Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:44:12 --> URI Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Router Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Output Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Input Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:44:12 --> Language Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Loader Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Controller Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:44:12 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Config Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 03:44:12 --> URI Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Router Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Output Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Input Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 03:44:12 --> Language Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Loader Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Controller Class Initialized
ERROR - 2011-08-25 03:44:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 03:44:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Model Class Initialized
DEBUG - 2011-08-25 03:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 03:44:12 --> Database Driver Class Initialized
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 03:44:12 --> Helper loaded: url_helper
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 03:44:12 --> Final output sent to browser
DEBUG - 2011-08-25 03:44:12 --> Total execution time: 0.7887
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 03:44:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 03:44:12 --> Final output sent to browser
DEBUG - 2011-08-25 03:44:12 --> Total execution time: 0.0740
DEBUG - 2011-08-25 04:13:17 --> Config Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Hooks Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Utf8 Class Initialized
DEBUG - 2011-08-25 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 04:13:17 --> URI Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Router Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Output Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Input Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 04:13:17 --> Language Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Loader Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Controller Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Model Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Model Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Model Class Initialized
DEBUG - 2011-08-25 04:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 04:13:17 --> Database Driver Class Initialized
DEBUG - 2011-08-25 04:13:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 04:13:19 --> Helper loaded: url_helper
DEBUG - 2011-08-25 04:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 04:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 04:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 04:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 04:13:19 --> Final output sent to browser
DEBUG - 2011-08-25 04:13:19 --> Total execution time: 1.9021
DEBUG - 2011-08-25 04:13:20 --> Config Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 04:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 04:13:20 --> URI Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Router Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Output Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Input Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 04:13:20 --> Language Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Loader Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Controller Class Initialized
ERROR - 2011-08-25 04:13:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 04:13:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 04:13:20 --> Model Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Model Class Initialized
DEBUG - 2011-08-25 04:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 04:13:20 --> Database Driver Class Initialized
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 04:13:20 --> Helper loaded: url_helper
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 04:13:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 04:13:20 --> Final output sent to browser
DEBUG - 2011-08-25 04:13:20 --> Total execution time: 0.0882
DEBUG - 2011-08-25 04:59:43 --> Config Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Hooks Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Utf8 Class Initialized
DEBUG - 2011-08-25 04:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 04:59:43 --> URI Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Router Class Initialized
DEBUG - 2011-08-25 04:59:43 --> No URI present. Default controller set.
DEBUG - 2011-08-25 04:59:43 --> Output Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Input Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 04:59:43 --> Language Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Loader Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Controller Class Initialized
DEBUG - 2011-08-25 04:59:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 04:59:43 --> Helper loaded: url_helper
DEBUG - 2011-08-25 04:59:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 04:59:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 04:59:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 04:59:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 04:59:43 --> Final output sent to browser
DEBUG - 2011-08-25 04:59:43 --> Total execution time: 0.1825
DEBUG - 2011-08-25 04:59:43 --> Config Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Hooks Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Utf8 Class Initialized
DEBUG - 2011-08-25 04:59:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 04:59:43 --> URI Class Initialized
DEBUG - 2011-08-25 04:59:43 --> Router Class Initialized
ERROR - 2011-08-25 04:59:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 05:30:22 --> Config Class Initialized
DEBUG - 2011-08-25 05:30:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:30:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:30:22 --> URI Class Initialized
DEBUG - 2011-08-25 05:30:22 --> Router Class Initialized
ERROR - 2011-08-25 05:30:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 05:57:08 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:08 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Router Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Output Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Input Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 05:57:08 --> Language Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Loader Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Controller Class Initialized
ERROR - 2011-08-25 05:57:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 05:57:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:08 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 05:57:08 --> Database Driver Class Initialized
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:08 --> Helper loaded: url_helper
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 05:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 05:57:08 --> Final output sent to browser
DEBUG - 2011-08-25 05:57:08 --> Total execution time: 0.6584
DEBUG - 2011-08-25 05:57:09 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:09 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Router Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Output Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Input Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 05:57:09 --> Language Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Loader Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Controller Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 05:57:09 --> Database Driver Class Initialized
DEBUG - 2011-08-25 05:57:10 --> Final output sent to browser
DEBUG - 2011-08-25 05:57:10 --> Total execution time: 0.8284
DEBUG - 2011-08-25 05:57:11 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:11 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:11 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:11 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:11 --> Router Class Initialized
ERROR - 2011-08-25 05:57:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 05:57:12 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:12 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:12 --> Router Class Initialized
ERROR - 2011-08-25 05:57:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 05:57:34 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:34 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Router Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Output Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Input Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 05:57:34 --> Language Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Loader Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Controller Class Initialized
ERROR - 2011-08-25 05:57:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 05:57:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:34 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 05:57:34 --> Database Driver Class Initialized
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:34 --> Helper loaded: url_helper
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 05:57:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 05:57:34 --> Final output sent to browser
DEBUG - 2011-08-25 05:57:34 --> Total execution time: 0.0316
DEBUG - 2011-08-25 05:57:35 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:35 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Router Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Output Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Input Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 05:57:35 --> Language Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Loader Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Controller Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 05:57:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Final output sent to browser
DEBUG - 2011-08-25 05:57:35 --> Total execution time: 0.6675
DEBUG - 2011-08-25 05:57:35 --> Config Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 05:57:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 05:57:35 --> URI Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Router Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Output Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Input Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 05:57:35 --> Language Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Loader Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Controller Class Initialized
ERROR - 2011-08-25 05:57:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 05:57:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:35 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Model Class Initialized
DEBUG - 2011-08-25 05:57:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 05:57:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 05:57:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 05:57:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 05:57:35 --> Final output sent to browser
DEBUG - 2011-08-25 05:57:35 --> Total execution time: 0.0288
DEBUG - 2011-08-25 06:00:31 --> Config Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Hooks Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Utf8 Class Initialized
DEBUG - 2011-08-25 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 06:00:31 --> URI Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Router Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Output Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Input Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 06:00:31 --> Language Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Loader Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Controller Class Initialized
ERROR - 2011-08-25 06:00:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 06:00:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 06:00:31 --> Model Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Model Class Initialized
DEBUG - 2011-08-25 06:00:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 06:00:31 --> Database Driver Class Initialized
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 06:00:31 --> Helper loaded: url_helper
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 06:00:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 06:00:31 --> Final output sent to browser
DEBUG - 2011-08-25 06:00:31 --> Total execution time: 0.0289
DEBUG - 2011-08-25 07:21:39 --> Config Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:21:39 --> URI Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Router Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Output Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Input Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 07:21:39 --> Language Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Loader Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Controller Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Model Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Model Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Model Class Initialized
DEBUG - 2011-08-25 07:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 07:21:39 --> Database Driver Class Initialized
DEBUG - 2011-08-25 07:21:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 07:21:40 --> Helper loaded: url_helper
DEBUG - 2011-08-25 07:21:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 07:21:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 07:21:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 07:21:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 07:21:40 --> Final output sent to browser
DEBUG - 2011-08-25 07:21:40 --> Total execution time: 1.1440
DEBUG - 2011-08-25 07:22:22 --> Config Class Initialized
DEBUG - 2011-08-25 07:22:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:22:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:22:22 --> URI Class Initialized
DEBUG - 2011-08-25 07:22:22 --> Router Class Initialized
ERROR - 2011-08-25 07:22:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 07:49:29 --> Config Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:49:29 --> URI Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Router Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Output Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Input Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 07:49:29 --> Language Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Loader Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Controller Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:29 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 07:49:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 07:49:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 07:49:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 07:49:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 07:49:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 07:49:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 07:49:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 07:49:30 --> Final output sent to browser
DEBUG - 2011-08-25 07:49:30 --> Total execution time: 0.6164
DEBUG - 2011-08-25 07:49:32 --> Config Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:49:32 --> URI Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Router Class Initialized
ERROR - 2011-08-25 07:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 07:49:32 --> Config Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:49:32 --> URI Class Initialized
DEBUG - 2011-08-25 07:49:32 --> Router Class Initialized
ERROR - 2011-08-25 07:49:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 07:49:33 --> Config Class Initialized
DEBUG - 2011-08-25 07:49:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:49:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:49:33 --> URI Class Initialized
DEBUG - 2011-08-25 07:49:33 --> Router Class Initialized
ERROR - 2011-08-25 07:49:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 07:49:55 --> Config Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:49:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:49:55 --> URI Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Router Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Output Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Input Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 07:49:55 --> Language Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Loader Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Controller Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Model Class Initialized
DEBUG - 2011-08-25 07:49:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 07:49:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 07:49:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 07:49:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 07:49:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 07:49:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 07:49:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 07:49:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 07:49:55 --> Final output sent to browser
DEBUG - 2011-08-25 07:49:55 --> Total execution time: 0.4856
DEBUG - 2011-08-25 07:50:04 --> Config Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Hooks Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Utf8 Class Initialized
DEBUG - 2011-08-25 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 07:50:04 --> URI Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Router Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Output Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Input Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 07:50:04 --> Language Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Loader Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Controller Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Model Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Model Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Model Class Initialized
DEBUG - 2011-08-25 07:50:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 07:50:04 --> Database Driver Class Initialized
DEBUG - 2011-08-25 07:50:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 07:50:05 --> Helper loaded: url_helper
DEBUG - 2011-08-25 07:50:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 07:50:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 07:50:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 07:50:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 07:50:05 --> Final output sent to browser
DEBUG - 2011-08-25 07:50:05 --> Total execution time: 0.9734
DEBUG - 2011-08-25 09:04:54 --> Config Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:04:54 --> URI Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Router Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Output Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Input Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:04:54 --> Language Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Loader Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Controller Class Initialized
ERROR - 2011-08-25 09:04:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 09:04:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:04:54 --> Model Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Model Class Initialized
DEBUG - 2011-08-25 09:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:04:54 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:04:54 --> Helper loaded: url_helper
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 09:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 09:04:54 --> Final output sent to browser
DEBUG - 2011-08-25 09:04:54 --> Total execution time: 0.2857
DEBUG - 2011-08-25 09:04:56 --> Config Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:04:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:04:56 --> URI Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Router Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Output Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Input Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:04:56 --> Language Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Loader Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Controller Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Model Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Model Class Initialized
DEBUG - 2011-08-25 09:04:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:04:56 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:04:57 --> Final output sent to browser
DEBUG - 2011-08-25 09:04:57 --> Total execution time: 0.6352
DEBUG - 2011-08-25 09:04:59 --> Config Class Initialized
DEBUG - 2011-08-25 09:04:59 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:04:59 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:04:59 --> URI Class Initialized
DEBUG - 2011-08-25 09:04:59 --> Router Class Initialized
ERROR - 2011-08-25 09:04:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 09:05:55 --> Config Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:05:55 --> URI Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Router Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Output Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Input Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:05:55 --> Language Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Loader Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Controller Class Initialized
ERROR - 2011-08-25 09:05:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 09:05:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:05:55 --> Model Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Model Class Initialized
DEBUG - 2011-08-25 09:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:05:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:05:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 09:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 09:05:55 --> Final output sent to browser
DEBUG - 2011-08-25 09:05:55 --> Total execution time: 0.0377
DEBUG - 2011-08-25 09:05:56 --> Config Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:05:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:05:56 --> URI Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Router Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Output Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Input Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:05:56 --> Language Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Loader Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Controller Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Model Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Model Class Initialized
DEBUG - 2011-08-25 09:05:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:05:56 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:05:57 --> Final output sent to browser
DEBUG - 2011-08-25 09:05:57 --> Total execution time: 0.6331
DEBUG - 2011-08-25 09:05:58 --> Config Class Initialized
DEBUG - 2011-08-25 09:05:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:05:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:05:58 --> URI Class Initialized
DEBUG - 2011-08-25 09:05:59 --> Router Class Initialized
ERROR - 2011-08-25 09:05:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 09:06:22 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:22 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Router Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Output Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Input Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:06:22 --> Language Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Loader Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Controller Class Initialized
ERROR - 2011-08-25 09:06:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 09:06:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:06:22 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:06:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:06:22 --> Helper loaded: url_helper
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 09:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 09:06:22 --> Final output sent to browser
DEBUG - 2011-08-25 09:06:22 --> Total execution time: 0.0293
DEBUG - 2011-08-25 09:06:23 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:23 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Router Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Output Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Input Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:06:23 --> Language Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Loader Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Controller Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:06:23 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:06:24 --> Final output sent to browser
DEBUG - 2011-08-25 09:06:24 --> Total execution time: 0.5739
DEBUG - 2011-08-25 09:06:25 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:25 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:25 --> Router Class Initialized
ERROR - 2011-08-25 09:06:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 09:06:35 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:35 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Router Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Output Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Input Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:06:35 --> Language Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Loader Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Controller Class Initialized
ERROR - 2011-08-25 09:06:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 09:06:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:06:35 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 09:06:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 09:06:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 09:06:35 --> Final output sent to browser
DEBUG - 2011-08-25 09:06:35 --> Total execution time: 0.0352
DEBUG - 2011-08-25 09:06:35 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:35 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Router Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Output Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Input Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:06:35 --> Language Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Loader Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Controller Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Model Class Initialized
DEBUG - 2011-08-25 09:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 09:06:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 09:06:36 --> Final output sent to browser
DEBUG - 2011-08-25 09:06:36 --> Total execution time: 0.6370
DEBUG - 2011-08-25 09:06:39 --> Config Class Initialized
DEBUG - 2011-08-25 09:06:39 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:06:39 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:06:39 --> URI Class Initialized
DEBUG - 2011-08-25 09:06:39 --> Router Class Initialized
ERROR - 2011-08-25 09:06:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 09:53:20 --> Config Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 09:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 09:53:20 --> URI Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Router Class Initialized
DEBUG - 2011-08-25 09:53:20 --> No URI present. Default controller set.
DEBUG - 2011-08-25 09:53:20 --> Output Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Input Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 09:53:20 --> Language Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Loader Class Initialized
DEBUG - 2011-08-25 09:53:20 --> Controller Class Initialized
DEBUG - 2011-08-25 09:53:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 09:53:20 --> Helper loaded: url_helper
DEBUG - 2011-08-25 09:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 09:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 09:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 09:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 09:53:20 --> Final output sent to browser
DEBUG - 2011-08-25 09:53:20 --> Total execution time: 0.7981
DEBUG - 2011-08-25 10:04:55 --> Config Class Initialized
DEBUG - 2011-08-25 10:04:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 10:04:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 10:04:55 --> URI Class Initialized
DEBUG - 2011-08-25 10:04:55 --> Router Class Initialized
ERROR - 2011-08-25 10:04:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 10:06:20 --> Config Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 10:06:20 --> URI Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Router Class Initialized
ERROR - 2011-08-25 10:06:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 10:06:20 --> Config Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 10:06:20 --> URI Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Router Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Output Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Input Class Initialized
DEBUG - 2011-08-25 10:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 10:06:20 --> Language Class Initialized
DEBUG - 2011-08-25 10:06:21 --> Loader Class Initialized
DEBUG - 2011-08-25 10:06:21 --> Controller Class Initialized
ERROR - 2011-08-25 10:06:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 10:06:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 10:06:21 --> Model Class Initialized
DEBUG - 2011-08-25 10:06:21 --> Model Class Initialized
DEBUG - 2011-08-25 10:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 10:06:21 --> Database Driver Class Initialized
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 10:06:21 --> Helper loaded: url_helper
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 10:06:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 10:06:21 --> Final output sent to browser
DEBUG - 2011-08-25 10:06:21 --> Total execution time: 1.1761
DEBUG - 2011-08-25 11:17:22 --> Config Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:17:22 --> URI Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Router Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Output Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Input Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:17:22 --> Language Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Loader Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Controller Class Initialized
ERROR - 2011-08-25 11:17:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:17:22 --> Model Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Model Class Initialized
DEBUG - 2011-08-25 11:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:17:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:17:22 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:17:22 --> Final output sent to browser
DEBUG - 2011-08-25 11:17:22 --> Total execution time: 0.0781
DEBUG - 2011-08-25 11:19:25 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:25 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:25 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Controller Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 11:19:26 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:26 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:26 --> Total execution time: 0.3229
DEBUG - 2011-08-25 11:19:27 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:27 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:27 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:27 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:27 --> Router Class Initialized
ERROR - 2011-08-25 11:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 11:19:28 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:28 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:28 --> Router Class Initialized
ERROR - 2011-08-25 11:19:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 11:19:33 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:33 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:33 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Controller Class Initialized
ERROR - 2011-08-25 11:19:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:19:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:33 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:33 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:33 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:33 --> Total execution time: 0.0292
DEBUG - 2011-08-25 11:19:33 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:33 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:33 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Controller Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:34 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:34 --> Total execution time: 0.5758
DEBUG - 2011-08-25 11:19:41 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:41 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:41 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Controller Class Initialized
ERROR - 2011-08-25 11:19:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:19:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:41 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:41 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:41 --> Total execution time: 0.0279
DEBUG - 2011-08-25 11:19:41 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:41 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:41 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Controller Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:42 --> Total execution time: 0.5903
DEBUG - 2011-08-25 11:19:42 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:42 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:42 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Controller Class Initialized
ERROR - 2011-08-25 11:19:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:19:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:42 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:42 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:42 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:42 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:42 --> Total execution time: 0.0284
DEBUG - 2011-08-25 11:19:46 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:46 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:46 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Controller Class Initialized
ERROR - 2011-08-25 11:19:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:19:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:46 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:46 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:46 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:46 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:46 --> Total execution time: 0.0299
DEBUG - 2011-08-25 11:19:47 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:47 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:47 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Controller Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Config Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:19:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:19:47 --> URI Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Router Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Output Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Input Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:19:47 --> Language Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Loader Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Controller Class Initialized
ERROR - 2011-08-25 11:19:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:19:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:47 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Model Class Initialized
DEBUG - 2011-08-25 11:19:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:19:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:19:47 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:19:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:19:47 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:47 --> Total execution time: 0.0308
DEBUG - 2011-08-25 11:19:47 --> Final output sent to browser
DEBUG - 2011-08-25 11:19:47 --> Total execution time: 0.6189
DEBUG - 2011-08-25 11:38:00 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:00 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:00 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Controller Class Initialized
ERROR - 2011-08-25 11:38:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:38:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:00 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:38:00 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:00 --> Total execution time: 0.0306
DEBUG - 2011-08-25 11:38:01 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:01 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:01 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Controller Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:01 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:01 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:01 --> Total execution time: 0.5521
DEBUG - 2011-08-25 11:38:02 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:02 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:02 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:02 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:02 --> Router Class Initialized
ERROR - 2011-08-25 11:38:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 11:38:03 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:03 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:03 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:03 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:03 --> Router Class Initialized
ERROR - 2011-08-25 11:38:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 11:38:15 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:15 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:15 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Controller Class Initialized
ERROR - 2011-08-25 11:38:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:38:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:15 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:15 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:15 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:38:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:38:15 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:15 --> Total execution time: 0.0802
DEBUG - 2011-08-25 11:38:15 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:15 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:15 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Controller Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:16 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:16 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:16 --> Total execution time: 0.7382
DEBUG - 2011-08-25 11:38:27 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:27 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:27 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Controller Class Initialized
ERROR - 2011-08-25 11:38:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:38:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:27 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:27 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:27 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:38:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:38:27 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:27 --> Total execution time: 0.0333
DEBUG - 2011-08-25 11:38:28 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:28 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:28 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Controller Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:28 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:28 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:28 --> Total execution time: 0.6115
DEBUG - 2011-08-25 11:38:45 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:45 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:45 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Controller Class Initialized
ERROR - 2011-08-25 11:38:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:38:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:45 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:45 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:45 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:38:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:38:45 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:45 --> Total execution time: 0.0286
DEBUG - 2011-08-25 11:38:46 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:46 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:46 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Controller Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:46 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:46 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:46 --> Total execution time: 0.5011
DEBUG - 2011-08-25 11:38:57 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:57 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:57 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:58 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Controller Class Initialized
ERROR - 2011-08-25 11:38:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 11:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:58 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 11:38:58 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:38:58 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:58 --> Total execution time: 0.2220
DEBUG - 2011-08-25 11:38:58 --> Config Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:38:58 --> URI Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Router Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Output Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Input Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:38:58 --> Language Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Loader Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Controller Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Model Class Initialized
DEBUG - 2011-08-25 11:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:38:59 --> Final output sent to browser
DEBUG - 2011-08-25 11:38:59 --> Total execution time: 0.6463
DEBUG - 2011-08-25 11:59:40 --> Config Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:59:40 --> URI Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Router Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Output Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Input Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:59:40 --> Language Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Loader Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Controller Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:59:40 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:59:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 11:59:41 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:59:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:59:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:59:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:59:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:59:41 --> Final output sent to browser
DEBUG - 2011-08-25 11:59:41 --> Total execution time: 0.9430
DEBUG - 2011-08-25 11:59:45 --> Config Class Initialized
DEBUG - 2011-08-25 11:59:45 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:59:45 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:59:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:59:45 --> URI Class Initialized
DEBUG - 2011-08-25 11:59:45 --> Router Class Initialized
ERROR - 2011-08-25 11:59:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 11:59:57 --> Config Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 11:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 11:59:57 --> URI Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Router Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Output Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Input Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 11:59:57 --> Language Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Loader Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Controller Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Model Class Initialized
DEBUG - 2011-08-25 11:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 11:59:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 11:59:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 11:59:58 --> Helper loaded: url_helper
DEBUG - 2011-08-25 11:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 11:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 11:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 11:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 11:59:58 --> Final output sent to browser
DEBUG - 2011-08-25 11:59:58 --> Total execution time: 0.7116
DEBUG - 2011-08-25 12:00:00 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:00 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Router Class Initialized
ERROR - 2011-08-25 12:00:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 12:00:00 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:00 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Router Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Output Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Input Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:00:00 --> Language Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Loader Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Controller Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:00:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:00:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:00:00 --> Final output sent to browser
DEBUG - 2011-08-25 12:00:00 --> Total execution time: 0.0497
DEBUG - 2011-08-25 12:00:17 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:17 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Router Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Output Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Input Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:00:17 --> Language Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Loader Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Controller Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:00:17 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:00:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:00:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:00:25 --> Final output sent to browser
DEBUG - 2011-08-25 12:00:25 --> Total execution time: 8.3485
DEBUG - 2011-08-25 12:00:28 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:28 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:28 --> Router Class Initialized
ERROR - 2011-08-25 12:00:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 12:00:30 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:30 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Router Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Output Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Input Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:00:30 --> Language Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Loader Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Controller Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:00:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:00:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:00:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:00:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:00:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:00:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:00:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:00:30 --> Final output sent to browser
DEBUG - 2011-08-25 12:00:30 --> Total execution time: 0.1918
DEBUG - 2011-08-25 12:00:50 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:50 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Router Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Output Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Input Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:00:50 --> Language Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Loader Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Controller Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:00:50 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:00:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:00:50 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:00:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:00:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:00:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:00:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:00:50 --> Final output sent to browser
DEBUG - 2011-08-25 12:00:50 --> Total execution time: 0.5241
DEBUG - 2011-08-25 12:00:52 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:52 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Router Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Output Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Input Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:00:52 --> Language Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Loader Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Controller Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Model Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:00:52 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:00:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:00:52 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:00:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:00:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:00:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:00:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:00:52 --> Final output sent to browser
DEBUG - 2011-08-25 12:00:52 --> Total execution time: 0.0659
DEBUG - 2011-08-25 12:00:52 --> Config Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:00:52 --> URI Class Initialized
DEBUG - 2011-08-25 12:00:52 --> Router Class Initialized
ERROR - 2011-08-25 12:00:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 12:07:35 --> Config Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:07:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:07:35 --> URI Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Router Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Output Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Input Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:07:35 --> Language Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Loader Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Controller Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Model Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Model Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:07:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:07:35 --> Final output sent to browser
DEBUG - 2011-08-25 12:07:35 --> Total execution time: 0.6518
DEBUG - 2011-08-25 12:11:00 --> Config Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:11:00 --> URI Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Router Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Output Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Input Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:11:00 --> Language Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Loader Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Controller Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Model Class Initialized
DEBUG - 2011-08-25 12:11:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:11:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:11:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 12:11:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:11:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:11:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:11:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:11:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:11:00 --> Final output sent to browser
DEBUG - 2011-08-25 12:11:00 --> Total execution time: 0.4026
DEBUG - 2011-08-25 12:11:02 --> Config Class Initialized
DEBUG - 2011-08-25 12:11:02 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:11:02 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:11:02 --> URI Class Initialized
DEBUG - 2011-08-25 12:11:02 --> Router Class Initialized
ERROR - 2011-08-25 12:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 12:59:25 --> Config Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:59:25 --> URI Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Router Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Output Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Input Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:59:25 --> Language Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Loader Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Controller Class Initialized
ERROR - 2011-08-25 12:59:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 12:59:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 12:59:25 --> Model Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Model Class Initialized
DEBUG - 2011-08-25 12:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:59:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 12:59:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 12:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 12:59:25 --> Final output sent to browser
DEBUG - 2011-08-25 12:59:25 --> Total execution time: 0.0836
DEBUG - 2011-08-25 12:59:28 --> Config Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:59:28 --> URI Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Router Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Output Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Input Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 12:59:28 --> Language Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Loader Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Controller Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Model Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Model Class Initialized
DEBUG - 2011-08-25 12:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 12:59:28 --> Database Driver Class Initialized
DEBUG - 2011-08-25 12:59:29 --> Final output sent to browser
DEBUG - 2011-08-25 12:59:29 --> Total execution time: 0.6658
DEBUG - 2011-08-25 12:59:34 --> Config Class Initialized
DEBUG - 2011-08-25 12:59:34 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:59:34 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:59:34 --> URI Class Initialized
DEBUG - 2011-08-25 12:59:34 --> Router Class Initialized
ERROR - 2011-08-25 12:59:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 12:59:35 --> Config Class Initialized
DEBUG - 2011-08-25 12:59:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 12:59:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 12:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 12:59:35 --> URI Class Initialized
DEBUG - 2011-08-25 12:59:35 --> Router Class Initialized
ERROR - 2011-08-25 12:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 13:30:47 --> Config Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 13:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 13:30:47 --> URI Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Router Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Output Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Input Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 13:30:47 --> Language Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Loader Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Controller Class Initialized
ERROR - 2011-08-25 13:30:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 13:30:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 13:30:47 --> Model Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Model Class Initialized
DEBUG - 2011-08-25 13:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 13:30:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 13:30:47 --> Helper loaded: url_helper
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 13:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 13:30:47 --> Final output sent to browser
DEBUG - 2011-08-25 13:30:47 --> Total execution time: 0.0450
DEBUG - 2011-08-25 13:30:48 --> Config Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Hooks Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Utf8 Class Initialized
DEBUG - 2011-08-25 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 13:30:48 --> URI Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Router Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Output Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Input Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 13:30:48 --> Language Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Loader Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Controller Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Model Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Model Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 13:30:48 --> Database Driver Class Initialized
DEBUG - 2011-08-25 13:30:48 --> Final output sent to browser
DEBUG - 2011-08-25 13:30:48 --> Total execution time: 0.7403
DEBUG - 2011-08-25 13:30:50 --> Config Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 13:30:50 --> URI Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Router Class Initialized
ERROR - 2011-08-25 13:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 13:30:50 --> Config Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 13:30:50 --> URI Class Initialized
DEBUG - 2011-08-25 13:30:50 --> Router Class Initialized
ERROR - 2011-08-25 13:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 14:29:30 --> Config Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:29:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:29:30 --> URI Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Router Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Output Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Input Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:29:30 --> Language Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Loader Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Controller Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Model Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Model Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Model Class Initialized
DEBUG - 2011-08-25 14:29:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:29:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 14:29:31 --> Helper loaded: url_helper
DEBUG - 2011-08-25 14:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 14:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 14:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 14:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 14:29:31 --> Final output sent to browser
DEBUG - 2011-08-25 14:29:31 --> Total execution time: 0.3467
DEBUG - 2011-08-25 14:33:06 --> Config Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:33:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:33:06 --> URI Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Router Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Output Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Input Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:33:06 --> Language Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Loader Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Controller Class Initialized
ERROR - 2011-08-25 14:33:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 14:33:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 14:33:06 --> Model Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Model Class Initialized
DEBUG - 2011-08-25 14:33:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:33:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 14:33:06 --> Helper loaded: url_helper
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 14:33:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 14:33:06 --> Final output sent to browser
DEBUG - 2011-08-25 14:33:06 --> Total execution time: 0.0356
DEBUG - 2011-08-25 14:33:23 --> Config Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:33:23 --> URI Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Router Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Output Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Input Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:33:23 --> Language Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Loader Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Controller Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Model Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Model Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:33:23 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:33:23 --> Final output sent to browser
DEBUG - 2011-08-25 14:33:23 --> Total execution time: 0.6909
DEBUG - 2011-08-25 14:33:44 --> Config Class Initialized
DEBUG - 2011-08-25 14:33:44 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:33:44 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:33:44 --> URI Class Initialized
DEBUG - 2011-08-25 14:33:44 --> Router Class Initialized
ERROR - 2011-08-25 14:33:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 14:33:46 --> Config Class Initialized
DEBUG - 2011-08-25 14:33:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:33:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:33:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:33:46 --> URI Class Initialized
DEBUG - 2011-08-25 14:33:46 --> Router Class Initialized
ERROR - 2011-08-25 14:33:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 14:40:06 --> Config Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:40:06 --> URI Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Router Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Output Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Input Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:40:06 --> Language Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Loader Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Controller Class Initialized
ERROR - 2011-08-25 14:40:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 14:40:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 14:40:06 --> Model Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Model Class Initialized
DEBUG - 2011-08-25 14:40:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:40:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 14:40:06 --> Helper loaded: url_helper
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 14:40:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 14:40:06 --> Final output sent to browser
DEBUG - 2011-08-25 14:40:06 --> Total execution time: 0.0446
DEBUG - 2011-08-25 14:40:08 --> Config Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:40:08 --> URI Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Router Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Output Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Input Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:40:08 --> Language Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Loader Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Controller Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Model Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Model Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:40:08 --> Final output sent to browser
DEBUG - 2011-08-25 14:40:08 --> Total execution time: 0.7497
DEBUG - 2011-08-25 14:40:11 --> Config Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:40:11 --> URI Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Router Class Initialized
ERROR - 2011-08-25 14:40:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 14:40:11 --> Config Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:40:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:40:11 --> URI Class Initialized
DEBUG - 2011-08-25 14:40:11 --> Router Class Initialized
ERROR - 2011-08-25 14:40:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 14:54:13 --> Config Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:54:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:54:13 --> URI Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Router Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Output Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Input Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 14:54:13 --> Language Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Loader Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Controller Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Model Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Model Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Model Class Initialized
DEBUG - 2011-08-25 14:54:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 14:54:13 --> Database Driver Class Initialized
DEBUG - 2011-08-25 14:54:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 14:54:13 --> Helper loaded: url_helper
DEBUG - 2011-08-25 14:54:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 14:54:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 14:54:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 14:54:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 14:54:13 --> Final output sent to browser
DEBUG - 2011-08-25 14:54:13 --> Total execution time: 0.2448
DEBUG - 2011-08-25 14:54:18 --> Config Class Initialized
DEBUG - 2011-08-25 14:54:18 --> Hooks Class Initialized
DEBUG - 2011-08-25 14:54:18 --> Utf8 Class Initialized
DEBUG - 2011-08-25 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 14:54:18 --> URI Class Initialized
DEBUG - 2011-08-25 14:54:18 --> Router Class Initialized
ERROR - 2011-08-25 14:54:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 15:00:20 --> Config Class Initialized
DEBUG - 2011-08-25 15:00:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 15:00:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 15:00:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 15:00:20 --> URI Class Initialized
DEBUG - 2011-08-25 15:00:20 --> Router Class Initialized
ERROR - 2011-08-25 15:00:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 15:05:19 --> Config Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Hooks Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Utf8 Class Initialized
DEBUG - 2011-08-25 15:05:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 15:05:19 --> URI Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Router Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Output Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Input Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 15:05:19 --> Language Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Loader Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Controller Class Initialized
ERROR - 2011-08-25 15:05:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 15:05:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 15:05:19 --> Model Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Model Class Initialized
DEBUG - 2011-08-25 15:05:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 15:05:19 --> Database Driver Class Initialized
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 15:05:19 --> Helper loaded: url_helper
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 15:05:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 15:05:19 --> Final output sent to browser
DEBUG - 2011-08-25 15:05:19 --> Total execution time: 0.0350
DEBUG - 2011-08-25 15:22:01 --> Config Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Hooks Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Utf8 Class Initialized
DEBUG - 2011-08-25 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 15:22:01 --> URI Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Router Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Output Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Input Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 15:22:01 --> Language Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Loader Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Controller Class Initialized
ERROR - 2011-08-25 15:22:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 15:22:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 15:22:01 --> Model Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Model Class Initialized
DEBUG - 2011-08-25 15:22:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 15:22:01 --> Database Driver Class Initialized
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 15:22:01 --> Helper loaded: url_helper
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 15:22:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 15:22:01 --> Final output sent to browser
DEBUG - 2011-08-25 15:22:01 --> Total execution time: 0.0419
DEBUG - 2011-08-25 15:22:08 --> Config Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 15:22:08 --> URI Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Router Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Output Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Input Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 15:22:08 --> Language Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Loader Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Controller Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Model Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Model Class Initialized
DEBUG - 2011-08-25 15:22:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 15:22:08 --> Database Driver Class Initialized
DEBUG - 2011-08-25 15:22:09 --> Final output sent to browser
DEBUG - 2011-08-25 15:22:09 --> Total execution time: 0.9206
DEBUG - 2011-08-25 15:22:12 --> Config Class Initialized
DEBUG - 2011-08-25 15:22:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 15:22:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 15:22:12 --> URI Class Initialized
DEBUG - 2011-08-25 15:22:12 --> Router Class Initialized
ERROR - 2011-08-25 15:22:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:06:24 --> Config Class Initialized
DEBUG - 2011-08-25 16:06:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:06:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:06:24 --> URI Class Initialized
DEBUG - 2011-08-25 16:06:24 --> Router Class Initialized
ERROR - 2011-08-25 16:06:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 16:18:23 --> Config Class Initialized
DEBUG - 2011-08-25 16:18:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:18:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:18:23 --> URI Class Initialized
DEBUG - 2011-08-25 16:18:23 --> Router Class Initialized
ERROR - 2011-08-25 16:18:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 16:34:29 --> Config Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:34:29 --> URI Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Router Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Output Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Input Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:34:29 --> Language Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Loader Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Controller Class Initialized
ERROR - 2011-08-25 16:34:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 16:34:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 16:34:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:34:29 --> Model Class Initialized
DEBUG - 2011-08-25 16:34:29 --> Model Class Initialized
DEBUG - 2011-08-25 16:34:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:34:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:34:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:34:30 --> Final output sent to browser
DEBUG - 2011-08-25 16:34:30 --> Total execution time: 0.3003
DEBUG - 2011-08-25 16:34:40 --> Config Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:34:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:34:40 --> URI Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Router Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Output Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Input Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:34:40 --> Language Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Loader Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Controller Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Model Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Model Class Initialized
DEBUG - 2011-08-25 16:34:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:34:40 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:34:41 --> Final output sent to browser
DEBUG - 2011-08-25 16:34:41 --> Total execution time: 0.7819
DEBUG - 2011-08-25 16:34:54 --> Config Class Initialized
DEBUG - 2011-08-25 16:34:54 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:34:54 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:34:54 --> URI Class Initialized
DEBUG - 2011-08-25 16:34:54 --> Router Class Initialized
ERROR - 2011-08-25 16:34:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:36:51 --> Config Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:36:51 --> URI Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Router Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Output Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Input Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:36:51 --> Language Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Loader Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Controller Class Initialized
ERROR - 2011-08-25 16:36:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 16:36:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:36:51 --> Model Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Model Class Initialized
DEBUG - 2011-08-25 16:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:36:51 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:36:51 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:36:51 --> Final output sent to browser
DEBUG - 2011-08-25 16:36:51 --> Total execution time: 0.0302
DEBUG - 2011-08-25 16:36:55 --> Config Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:36:55 --> URI Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Router Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Output Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Input Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:36:55 --> Language Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Loader Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Controller Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Model Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Model Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:36:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:36:55 --> Final output sent to browser
DEBUG - 2011-08-25 16:36:55 --> Total execution time: 0.6121
DEBUG - 2011-08-25 16:37:10 --> Config Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:37:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:37:10 --> URI Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Router Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Output Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Input Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:37:10 --> Language Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Loader Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Controller Class Initialized
ERROR - 2011-08-25 16:37:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 16:37:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:37:10 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:37:10 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:37:10 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:37:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:37:10 --> Final output sent to browser
DEBUG - 2011-08-25 16:37:10 --> Total execution time: 0.0287
DEBUG - 2011-08-25 16:37:11 --> Config Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:37:11 --> URI Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Router Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Output Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Input Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:37:11 --> Language Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Loader Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Controller Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:37:11 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:37:12 --> Final output sent to browser
DEBUG - 2011-08-25 16:37:12 --> Total execution time: 0.7231
DEBUG - 2011-08-25 16:37:20 --> Config Class Initialized
DEBUG - 2011-08-25 16:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:37:20 --> URI Class Initialized
DEBUG - 2011-08-25 16:37:20 --> Router Class Initialized
DEBUG - 2011-08-25 16:37:20 --> Output Class Initialized
DEBUG - 2011-08-25 16:37:20 --> Input Class Initialized
DEBUG - 2011-08-25 16:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:37:21 --> Language Class Initialized
DEBUG - 2011-08-25 16:37:21 --> Loader Class Initialized
DEBUG - 2011-08-25 16:37:21 --> Controller Class Initialized
ERROR - 2011-08-25 16:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 16:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:37:21 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:21 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:37:21 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:37:21 --> Final output sent to browser
DEBUG - 2011-08-25 16:37:21 --> Total execution time: 0.0396
DEBUG - 2011-08-25 16:37:24 --> Config Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:37:24 --> URI Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Router Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Output Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Input Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:37:24 --> Language Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Loader Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Controller Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Model Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:37:24 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:37:24 --> Final output sent to browser
DEBUG - 2011-08-25 16:37:24 --> Total execution time: 0.5947
DEBUG - 2011-08-25 16:58:47 --> Config Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:58:47 --> URI Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Router Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Output Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Input Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:58:47 --> Language Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Loader Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Controller Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Model Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Model Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Model Class Initialized
DEBUG - 2011-08-25 16:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:58:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:58:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 16:58:47 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:58:47 --> Final output sent to browser
DEBUG - 2011-08-25 16:58:47 --> Total execution time: 0.4502
DEBUG - 2011-08-25 16:58:50 --> Config Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:58:50 --> URI Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Router Class Initialized
ERROR - 2011-08-25 16:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:58:50 --> Config Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:58:50 --> URI Class Initialized
DEBUG - 2011-08-25 16:58:50 --> Router Class Initialized
ERROR - 2011-08-25 16:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:25 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:25 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Router Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Output Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Input Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:59:25 --> Language Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Loader Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Controller Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:59:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:59:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 16:59:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:59:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:59:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:59:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:59:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:59:25 --> Final output sent to browser
DEBUG - 2011-08-25 16:59:25 --> Total execution time: 0.0511
DEBUG - 2011-08-25 16:59:27 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:27 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Router Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Output Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Input Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:59:27 --> Language Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Loader Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Controller Class Initialized
ERROR - 2011-08-25 16:59:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 16:59:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:59:27 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:59:27 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 16:59:27 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:59:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:59:27 --> Final output sent to browser
DEBUG - 2011-08-25 16:59:27 --> Total execution time: 0.0650
DEBUG - 2011-08-25 16:59:29 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:29 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:29 --> Router Class Initialized
ERROR - 2011-08-25 16:59:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:33 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:33 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Router Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Output Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Input Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:59:33 --> Language Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Loader Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Controller Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:59:33 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:33 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:59:33 --> Router Class Initialized
ERROR - 2011-08-25 16:59:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:33 --> Final output sent to browser
DEBUG - 2011-08-25 16:59:33 --> Total execution time: 0.5268
DEBUG - 2011-08-25 16:59:34 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:34 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Router Class Initialized
ERROR - 2011-08-25 16:59:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:34 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:34 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:34 --> Router Class Initialized
ERROR - 2011-08-25 16:59:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:35 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:35 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Router Class Initialized
ERROR - 2011-08-25 16:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:35 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:35 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:35 --> Router Class Initialized
ERROR - 2011-08-25 16:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:36 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:36 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:36 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:36 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:36 --> Router Class Initialized
ERROR - 2011-08-25 16:59:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 16:59:44 --> Config Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Hooks Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Utf8 Class Initialized
DEBUG - 2011-08-25 16:59:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 16:59:44 --> URI Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Router Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Output Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Input Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 16:59:44 --> Language Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Loader Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Controller Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Model Class Initialized
DEBUG - 2011-08-25 16:59:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 16:59:44 --> Database Driver Class Initialized
DEBUG - 2011-08-25 16:59:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 16:59:44 --> Helper loaded: url_helper
DEBUG - 2011-08-25 16:59:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 16:59:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 16:59:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 16:59:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 16:59:44 --> Final output sent to browser
DEBUG - 2011-08-25 16:59:44 --> Total execution time: 0.2624
DEBUG - 2011-08-25 17:00:25 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:25 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Router Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Output Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Input Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:00:25 --> Language Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Loader Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Controller Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:00:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:00:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:00:25 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:00:25 --> Final output sent to browser
DEBUG - 2011-08-25 17:00:25 --> Total execution time: 0.0491
DEBUG - 2011-08-25 17:00:36 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:36 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Router Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Output Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Input Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:00:36 --> Language Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Loader Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Controller Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:00:36 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:00:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:00:36 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:00:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:00:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:00:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:00:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:00:36 --> Final output sent to browser
DEBUG - 2011-08-25 17:00:36 --> Total execution time: 0.2814
DEBUG - 2011-08-25 17:00:43 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:43 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:43 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:43 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:43 --> Router Class Initialized
ERROR - 2011-08-25 17:00:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:00:57 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:57 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Router Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Output Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Input Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:00:57 --> Language Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Loader Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Controller Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:00:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:00:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:00:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:00:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:00:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:00:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:00:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:00:57 --> Final output sent to browser
DEBUG - 2011-08-25 17:00:57 --> Total execution time: 0.4244
DEBUG - 2011-08-25 17:00:58 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:58 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Router Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Output Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Input Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:00:58 --> Language Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Loader Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Controller Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:00:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:00:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:00:58 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:00:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:00:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:00:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:00:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:00:58 --> Final output sent to browser
DEBUG - 2011-08-25 17:00:58 --> Total execution time: 0.0473
DEBUG - 2011-08-25 17:00:59 --> Config Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:00:59 --> URI Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Router Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Output Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Input Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:00:59 --> Language Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Loader Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Controller Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:00 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:00 --> Total execution time: 0.0918
DEBUG - 2011-08-25 17:01:05 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:05 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:05 --> Router Class Initialized
ERROR - 2011-08-25 17:01:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:01:18 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:18 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:18 --> Language Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Loader Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Controller Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:18 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:19 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:19 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:19 --> Total execution time: 0.8817
DEBUG - 2011-08-25 17:01:20 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:20 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:20 --> Language Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Loader Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Controller Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:20 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:20 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:20 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:20 --> Total execution time: 0.1578
DEBUG - 2011-08-25 17:01:24 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:24 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:24 --> Router Class Initialized
ERROR - 2011-08-25 17:01:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:01:36 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:36 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:36 --> Language Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Loader Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Controller Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:36 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:37 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:37 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:37 --> Total execution time: 0.3598
DEBUG - 2011-08-25 17:01:38 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:38 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:38 --> Language Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Loader Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Controller Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:38 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:38 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:38 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:38 --> Total execution time: 0.0458
DEBUG - 2011-08-25 17:01:45 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:45 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:45 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:45 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:45 --> Router Class Initialized
ERROR - 2011-08-25 17:01:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:01:55 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:55 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:55 --> Language Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Loader Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Controller Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Model Class Initialized
DEBUG - 2011-08-25 17:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:01:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:01:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:01:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:01:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:01:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:01:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:01:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:01:55 --> Final output sent to browser
DEBUG - 2011-08-25 17:01:55 --> Total execution time: 0.2133
DEBUG - 2011-08-25 17:01:59 --> Config Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:01:59 --> URI Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Router Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Output Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Input Class Initialized
DEBUG - 2011-08-25 17:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:01:59 --> Language Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Loader Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Controller Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:02:00 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:02:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:02:00 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:02:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:02:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:02:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:02:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:02:00 --> Final output sent to browser
DEBUG - 2011-08-25 17:02:00 --> Total execution time: 0.0878
DEBUG - 2011-08-25 17:02:00 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:00 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:00 --> Router Class Initialized
ERROR - 2011-08-25 17:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:02:14 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:14 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Router Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Output Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Input Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:02:14 --> Language Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Loader Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Controller Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:02:14 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:02:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:02:14 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:02:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:02:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:02:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:02:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:02:14 --> Final output sent to browser
DEBUG - 2011-08-25 17:02:14 --> Total execution time: 0.2974
DEBUG - 2011-08-25 17:02:15 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:15 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Router Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Output Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Input Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:02:15 --> Language Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Loader Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Controller Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:02:15 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:02:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:02:15 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:02:15 --> Final output sent to browser
DEBUG - 2011-08-25 17:02:15 --> Total execution time: 0.0486
DEBUG - 2011-08-25 17:02:22 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:22 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:22 --> Router Class Initialized
ERROR - 2011-08-25 17:02:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:02:33 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:33 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Router Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Output Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Input Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:02:33 --> Language Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Loader Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Controller Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:02:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:02:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:02:34 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:02:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:02:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:02:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:02:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:02:34 --> Final output sent to browser
DEBUG - 2011-08-25 17:02:34 --> Total execution time: 0.5827
DEBUG - 2011-08-25 17:02:35 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:35 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Router Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Output Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Input Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:02:35 --> Language Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Loader Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Controller Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Model Class Initialized
DEBUG - 2011-08-25 17:02:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:02:35 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:02:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:02:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:02:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:02:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:02:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:02:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:02:35 --> Final output sent to browser
DEBUG - 2011-08-25 17:02:35 --> Total execution time: 0.0461
DEBUG - 2011-08-25 17:02:46 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:46 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Router Class Initialized
ERROR - 2011-08-25 17:02:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:02:46 --> Config Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:02:46 --> URI Class Initialized
DEBUG - 2011-08-25 17:02:46 --> Router Class Initialized
ERROR - 2011-08-25 17:02:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:03:33 --> Config Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:03:33 --> URI Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Router Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Output Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Input Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:03:33 --> Language Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Loader Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Controller Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:03:33 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:03:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:03:33 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:03:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:03:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:03:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:03:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:03:33 --> Final output sent to browser
DEBUG - 2011-08-25 17:03:33 --> Total execution time: 0.0519
DEBUG - 2011-08-25 17:03:38 --> Config Class Initialized
DEBUG - 2011-08-25 17:03:38 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:03:38 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:03:38 --> URI Class Initialized
DEBUG - 2011-08-25 17:03:38 --> Router Class Initialized
ERROR - 2011-08-25 17:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:03:51 --> Config Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:03:51 --> URI Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Router Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Output Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Input Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:03:51 --> Language Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Loader Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Controller Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:03:51 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:03:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:03:51 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:03:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:03:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:03:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:03:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:03:51 --> Final output sent to browser
DEBUG - 2011-08-25 17:03:51 --> Total execution time: 0.2850
DEBUG - 2011-08-25 17:03:53 --> Config Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:03:53 --> URI Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Router Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Output Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Input Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:03:53 --> Language Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Loader Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Controller Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Model Class Initialized
DEBUG - 2011-08-25 17:03:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:03:53 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:03:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:03:53 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:03:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:03:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:03:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:03:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:03:53 --> Final output sent to browser
DEBUG - 2011-08-25 17:03:53 --> Total execution time: 0.0502
DEBUG - 2011-08-25 17:03:56 --> Config Class Initialized
DEBUG - 2011-08-25 17:03:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:03:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:03:56 --> URI Class Initialized
DEBUG - 2011-08-25 17:03:56 --> Router Class Initialized
ERROR - 2011-08-25 17:03:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:04:09 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:09 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Router Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Output Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Input Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:04:09 --> Language Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Loader Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Controller Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:04:09 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:04:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:04:09 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:04:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:04:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:04:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:04:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:04:09 --> Final output sent to browser
DEBUG - 2011-08-25 17:04:09 --> Total execution time: 0.1910
DEBUG - 2011-08-25 17:04:12 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:12 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Router Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Output Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Input Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:04:12 --> Language Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Loader Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Controller Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:04:12 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:04:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:04:12 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:04:12 --> Final output sent to browser
DEBUG - 2011-08-25 17:04:12 --> Total execution time: 0.0738
DEBUG - 2011-08-25 17:04:24 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:24 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:24 --> Router Class Initialized
ERROR - 2011-08-25 17:04:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:04:29 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:29 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Router Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Output Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Input Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:04:29 --> Language Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Loader Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Controller Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:04:29 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:04:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:04:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:04:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:04:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:04:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:04:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:04:30 --> Final output sent to browser
DEBUG - 2011-08-25 17:04:30 --> Total execution time: 0.4237
DEBUG - 2011-08-25 17:04:38 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:38 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:38 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:38 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:38 --> Router Class Initialized
ERROR - 2011-08-25 17:04:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:04:49 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:49 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Router Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Output Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Input Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:04:49 --> Language Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Loader Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Controller Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Model Class Initialized
DEBUG - 2011-08-25 17:04:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:04:49 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:04:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:04:49 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:04:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:04:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:04:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:04:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:04:49 --> Final output sent to browser
DEBUG - 2011-08-25 17:04:49 --> Total execution time: 0.2642
DEBUG - 2011-08-25 17:04:55 --> Config Class Initialized
DEBUG - 2011-08-25 17:04:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:04:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:04:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:04:55 --> URI Class Initialized
DEBUG - 2011-08-25 17:04:55 --> Router Class Initialized
ERROR - 2011-08-25 17:04:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:05:06 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:06 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Router Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Output Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Input Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:05:06 --> Language Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Loader Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Controller Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:05:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:05:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:05:06 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:05:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:05:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:05:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:05:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:05:06 --> Final output sent to browser
DEBUG - 2011-08-25 17:05:06 --> Total execution time: 0.2789
DEBUG - 2011-08-25 17:05:12 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:12 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:12 --> Router Class Initialized
ERROR - 2011-08-25 17:05:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:05:24 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:24 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Router Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Output Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Input Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:05:24 --> Language Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Loader Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Controller Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:05:24 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:05:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:05:24 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:05:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:05:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:05:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:05:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:05:24 --> Final output sent to browser
DEBUG - 2011-08-25 17:05:24 --> Total execution time: 0.2429
DEBUG - 2011-08-25 17:05:29 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:29 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:29 --> Router Class Initialized
ERROR - 2011-08-25 17:05:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:05:40 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:40 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:40 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:40 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Router Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Output Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Input Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:05:41 --> Language Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Loader Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Controller Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:05:41 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:05:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:05:41 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:05:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:05:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:05:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:05:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:05:41 --> Final output sent to browser
DEBUG - 2011-08-25 17:05:41 --> Total execution time: 0.2241
DEBUG - 2011-08-25 17:05:44 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:44 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:44 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:44 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:44 --> Router Class Initialized
ERROR - 2011-08-25 17:05:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:05:54 --> Config Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:05:54 --> URI Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Router Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Output Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Input Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:05:54 --> Language Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Loader Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Controller Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Model Class Initialized
DEBUG - 2011-08-25 17:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:05:54 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:05:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:05:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:05:55 --> Final output sent to browser
DEBUG - 2011-08-25 17:05:55 --> Total execution time: 0.2467
DEBUG - 2011-08-25 17:06:20 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:20 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:20 --> Router Class Initialized
ERROR - 2011-08-25 17:06:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:06:23 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:23 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Router Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Output Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Input Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:06:23 --> Language Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Loader Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Controller Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:06:24 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:06:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:06:26 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:06:26 --> Final output sent to browser
DEBUG - 2011-08-25 17:06:26 --> Total execution time: 2.4520
DEBUG - 2011-08-25 17:06:32 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:32 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:32 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:32 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:32 --> Router Class Initialized
ERROR - 2011-08-25 17:06:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:06:46 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:46 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Router Class Initialized
DEBUG - 2011-08-25 17:06:46 --> No URI present. Default controller set.
DEBUG - 2011-08-25 17:06:46 --> Output Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Input Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:06:46 --> Language Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Loader Class Initialized
DEBUG - 2011-08-25 17:06:46 --> Controller Class Initialized
DEBUG - 2011-08-25 17:06:46 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 17:06:46 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:06:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:06:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:06:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:06:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:06:46 --> Final output sent to browser
DEBUG - 2011-08-25 17:06:46 --> Total execution time: 0.0580
DEBUG - 2011-08-25 17:06:57 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:57 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Router Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Output Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Input Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:06:57 --> Language Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Loader Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Controller Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:06:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:06:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:06:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:06:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:06:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:06:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:06:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:06:57 --> Final output sent to browser
DEBUG - 2011-08-25 17:06:57 --> Total execution time: 0.0444
DEBUG - 2011-08-25 17:06:59 --> Config Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:06:59 --> URI Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Router Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Output Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Input Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 17:06:59 --> Language Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Loader Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Controller Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Model Class Initialized
DEBUG - 2011-08-25 17:06:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 17:06:59 --> Database Driver Class Initialized
DEBUG - 2011-08-25 17:06:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 17:06:59 --> Helper loaded: url_helper
DEBUG - 2011-08-25 17:06:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 17:06:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 17:06:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 17:06:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 17:06:59 --> Final output sent to browser
DEBUG - 2011-08-25 17:06:59 --> Total execution time: 0.0792
DEBUG - 2011-08-25 17:07:02 --> Config Class Initialized
DEBUG - 2011-08-25 17:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:07:02 --> URI Class Initialized
DEBUG - 2011-08-25 17:07:02 --> Router Class Initialized
ERROR - 2011-08-25 17:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 17:58:52 --> Config Class Initialized
DEBUG - 2011-08-25 17:58:52 --> Hooks Class Initialized
DEBUG - 2011-08-25 17:58:52 --> Utf8 Class Initialized
DEBUG - 2011-08-25 17:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 17:58:52 --> URI Class Initialized
DEBUG - 2011-08-25 17:58:52 --> Router Class Initialized
ERROR - 2011-08-25 17:58:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 19:18:34 --> Config Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:18:34 --> URI Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Router Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Output Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Input Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:18:34 --> Language Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Loader Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Controller Class Initialized
ERROR - 2011-08-25 19:18:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 19:18:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 19:18:34 --> Model Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Model Class Initialized
DEBUG - 2011-08-25 19:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:18:34 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 19:18:34 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:18:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:18:34 --> Final output sent to browser
DEBUG - 2011-08-25 19:18:34 --> Total execution time: 0.3073
DEBUG - 2011-08-25 19:18:37 --> Config Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:18:37 --> URI Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Router Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Output Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Input Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:18:37 --> Language Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Loader Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Controller Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Model Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Model Class Initialized
DEBUG - 2011-08-25 19:18:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:18:37 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:18:38 --> Final output sent to browser
DEBUG - 2011-08-25 19:18:38 --> Total execution time: 0.6574
DEBUG - 2011-08-25 19:18:39 --> Config Class Initialized
DEBUG - 2011-08-25 19:18:39 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:18:39 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:18:39 --> URI Class Initialized
DEBUG - 2011-08-25 19:18:39 --> Router Class Initialized
ERROR - 2011-08-25 19:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 19:19:24 --> Config Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:19:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:19:24 --> URI Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Router Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Output Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Input Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:19:24 --> Language Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Loader Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Controller Class Initialized
ERROR - 2011-08-25 19:19:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 19:19:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 19:19:24 --> Model Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Model Class Initialized
DEBUG - 2011-08-25 19:19:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:19:24 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 19:19:24 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:19:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:19:24 --> Final output sent to browser
DEBUG - 2011-08-25 19:19:24 --> Total execution time: 0.0696
DEBUG - 2011-08-25 19:19:25 --> Config Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:19:25 --> URI Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Router Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Output Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Input Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:19:25 --> Language Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Loader Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Controller Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Model Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Model Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:19:25 --> Final output sent to browser
DEBUG - 2011-08-25 19:19:25 --> Total execution time: 0.5838
DEBUG - 2011-08-25 19:19:27 --> Config Class Initialized
DEBUG - 2011-08-25 19:19:27 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:19:27 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:19:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:19:27 --> URI Class Initialized
DEBUG - 2011-08-25 19:19:27 --> Router Class Initialized
ERROR - 2011-08-25 19:19:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 19:26:35 --> Config Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:26:35 --> URI Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Router Class Initialized
ERROR - 2011-08-25 19:26:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 19:26:35 --> Config Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:26:35 --> URI Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Router Class Initialized
DEBUG - 2011-08-25 19:26:35 --> No URI present. Default controller set.
DEBUG - 2011-08-25 19:26:35 --> Output Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Input Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:26:35 --> Language Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Loader Class Initialized
DEBUG - 2011-08-25 19:26:35 --> Controller Class Initialized
DEBUG - 2011-08-25 19:26:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 19:26:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:26:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:26:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:26:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:26:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:26:35 --> Final output sent to browser
DEBUG - 2011-08-25 19:26:35 --> Total execution time: 0.0681
DEBUG - 2011-08-25 19:27:35 --> Config Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:27:35 --> URI Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Router Class Initialized
DEBUG - 2011-08-25 19:27:35 --> No URI present. Default controller set.
DEBUG - 2011-08-25 19:27:35 --> Output Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Input Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:27:35 --> Language Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Loader Class Initialized
DEBUG - 2011-08-25 19:27:35 --> Controller Class Initialized
DEBUG - 2011-08-25 19:27:35 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 19:27:35 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:27:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:27:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:27:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:27:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:27:35 --> Final output sent to browser
DEBUG - 2011-08-25 19:27:35 --> Total execution time: 0.0136
DEBUG - 2011-08-25 19:27:38 --> Config Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:27:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:27:38 --> URI Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Router Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Output Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Input Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:27:38 --> Language Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Loader Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Controller Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Model Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Model Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Model Class Initialized
DEBUG - 2011-08-25 19:27:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:27:38 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:27:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 19:27:38 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:27:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:27:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:27:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:27:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:27:38 --> Final output sent to browser
DEBUG - 2011-08-25 19:27:38 --> Total execution time: 0.2625
DEBUG - 2011-08-25 19:46:06 --> Config Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:46:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:46:06 --> URI Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Router Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Output Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Input Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 19:46:06 --> Language Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Loader Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Controller Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Model Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Model Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Model Class Initialized
DEBUG - 2011-08-25 19:46:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 19:46:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 19:46:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-25 19:46:06 --> Helper loaded: url_helper
DEBUG - 2011-08-25 19:46:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 19:46:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 19:46:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 19:46:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 19:46:06 --> Final output sent to browser
DEBUG - 2011-08-25 19:46:06 --> Total execution time: 0.2179
DEBUG - 2011-08-25 19:46:07 --> Config Class Initialized
DEBUG - 2011-08-25 19:46:07 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:46:07 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:46:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:46:07 --> URI Class Initialized
DEBUG - 2011-08-25 19:46:07 --> Router Class Initialized
ERROR - 2011-08-25 19:46:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 19:46:08 --> Config Class Initialized
DEBUG - 2011-08-25 19:46:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 19:46:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 19:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 19:46:08 --> URI Class Initialized
DEBUG - 2011-08-25 19:46:08 --> Router Class Initialized
ERROR - 2011-08-25 19:46:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 20:39:21 --> Config Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Hooks Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Utf8 Class Initialized
DEBUG - 2011-08-25 20:39:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 20:39:21 --> URI Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Router Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Output Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Input Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 20:39:21 --> Language Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Loader Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Controller Class Initialized
ERROR - 2011-08-25 20:39:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 20:39:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 20:39:21 --> Model Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Model Class Initialized
DEBUG - 2011-08-25 20:39:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 20:39:21 --> Database Driver Class Initialized
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 20:39:21 --> Helper loaded: url_helper
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 20:39:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 20:39:21 --> Final output sent to browser
DEBUG - 2011-08-25 20:39:21 --> Total execution time: 0.1527
DEBUG - 2011-08-25 20:39:22 --> Config Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 20:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 20:39:22 --> URI Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Router Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Output Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Input Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 20:39:22 --> Language Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Loader Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Controller Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Model Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Model Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 20:39:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 20:39:22 --> Final output sent to browser
DEBUG - 2011-08-25 20:39:22 --> Total execution time: 0.6176
DEBUG - 2011-08-25 20:39:23 --> Config Class Initialized
DEBUG - 2011-08-25 20:39:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 20:39:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 20:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 20:39:23 --> URI Class Initialized
DEBUG - 2011-08-25 20:39:23 --> Router Class Initialized
ERROR - 2011-08-25 20:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 22:55:53 --> Config Class Initialized
DEBUG - 2011-08-25 22:55:53 --> Hooks Class Initialized
DEBUG - 2011-08-25 22:55:53 --> Utf8 Class Initialized
DEBUG - 2011-08-25 22:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 22:55:53 --> URI Class Initialized
DEBUG - 2011-08-25 22:55:53 --> Router Class Initialized
ERROR - 2011-08-25 22:55:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 23:17:22 --> Config Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:17:22 --> URI Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Router Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Output Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Input Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:17:22 --> Language Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Loader Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Controller Class Initialized
ERROR - 2011-08-25 23:17:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:17:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:17:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:17:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:17:22 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:17:22 --> Final output sent to browser
DEBUG - 2011-08-25 23:17:22 --> Total execution time: 0.0844
DEBUG - 2011-08-25 23:27:36 --> Config Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:27:36 --> URI Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Router Class Initialized
ERROR - 2011-08-25 23:27:36 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-25 23:27:36 --> Config Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:27:36 --> URI Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Router Class Initialized
DEBUG - 2011-08-25 23:27:36 --> No URI present. Default controller set.
DEBUG - 2011-08-25 23:27:36 --> Output Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Input Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:27:36 --> Language Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Loader Class Initialized
DEBUG - 2011-08-25 23:27:36 --> Controller Class Initialized
DEBUG - 2011-08-25 23:27:36 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 23:27:36 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:27:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:27:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:27:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:27:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:27:36 --> Final output sent to browser
DEBUG - 2011-08-25 23:27:36 --> Total execution time: 0.1078
DEBUG - 2011-08-25 23:29:47 --> Config Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:29:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:29:47 --> URI Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Router Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Output Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Input Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:29:47 --> Language Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Loader Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Controller Class Initialized
ERROR - 2011-08-25 23:29:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:29:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:29:47 --> Model Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Model Class Initialized
DEBUG - 2011-08-25 23:29:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:29:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:29:47 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:29:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:29:47 --> Final output sent to browser
DEBUG - 2011-08-25 23:29:47 --> Total execution time: 0.0322
DEBUG - 2011-08-25 23:29:52 --> Config Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:29:52 --> URI Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Router Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Output Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Input Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:29:52 --> Language Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Loader Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Controller Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Model Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Model Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:29:52 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:29:52 --> Final output sent to browser
DEBUG - 2011-08-25 23:29:52 --> Total execution time: 0.6082
DEBUG - 2011-08-25 23:30:22 --> Config Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:30:22 --> URI Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Router Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Output Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Input Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:30:22 --> Language Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Loader Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Controller Class Initialized
ERROR - 2011-08-25 23:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:30:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:30:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:30:22 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:30:22 --> Final output sent to browser
DEBUG - 2011-08-25 23:30:22 --> Total execution time: 0.0304
DEBUG - 2011-08-25 23:30:23 --> Config Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:30:23 --> URI Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Router Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Output Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Input Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:30:23 --> Language Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Loader Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Controller Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:30:23 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Config Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:30:23 --> URI Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Router Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Output Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Input Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:30:23 --> Language Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Loader Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Controller Class Initialized
ERROR - 2011-08-25 23:30:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:30:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:30:23 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Model Class Initialized
DEBUG - 2011-08-25 23:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:30:23 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:30:23 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:30:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:30:23 --> Final output sent to browser
DEBUG - 2011-08-25 23:30:23 --> Total execution time: 0.0322
DEBUG - 2011-08-25 23:30:24 --> Final output sent to browser
DEBUG - 2011-08-25 23:30:24 --> Total execution time: 0.7905
DEBUG - 2011-08-25 23:56:05 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:05 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Router Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Output Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Input Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:56:05 --> Language Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Loader Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Controller Class Initialized
ERROR - 2011-08-25 23:56:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:56:05 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:56:05 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:56:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:56:06 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:56:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:56:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:56:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:56:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:56:06 --> Final output sent to browser
DEBUG - 2011-08-25 23:56:06 --> Total execution time: 0.3581
DEBUG - 2011-08-25 23:56:06 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:06 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Router Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Output Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Input Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:56:06 --> Language Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Loader Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Controller Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:56:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:56:07 --> Final output sent to browser
DEBUG - 2011-08-25 23:56:07 --> Total execution time: 0.6148
DEBUG - 2011-08-25 23:56:08 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:08 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Router Class Initialized
ERROR - 2011-08-25 23:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 23:56:08 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:08 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:08 --> Router Class Initialized
ERROR - 2011-08-25 23:56:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 23:56:09 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:09 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:09 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:09 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:09 --> Router Class Initialized
ERROR - 2011-08-25 23:56:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-25 23:56:29 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:29 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Router Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Output Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Input Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:56:29 --> Language Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Loader Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Controller Class Initialized
ERROR - 2011-08-25 23:56:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:56:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:56:29 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:56:29 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:56:29 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:56:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:56:29 --> Final output sent to browser
DEBUG - 2011-08-25 23:56:29 --> Total execution time: 0.0329
DEBUG - 2011-08-25 23:56:30 --> Config Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:56:30 --> URI Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Router Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Output Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Input Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:56:30 --> Language Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Loader Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Controller Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Model Class Initialized
DEBUG - 2011-08-25 23:56:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:56:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:56:31 --> Final output sent to browser
DEBUG - 2011-08-25 23:56:31 --> Total execution time: 0.6923
DEBUG - 2011-08-25 23:57:12 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:12 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:12 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:12 --> Controller Class Initialized
ERROR - 2011-08-25 23:57:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:57:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:57:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:12 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:13 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:13 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:13 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:57:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:57:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:57:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:57:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:57:13 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:13 --> Total execution time: 0.0317
DEBUG - 2011-08-25 23:57:14 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:14 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:14 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Controller Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:14 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:14 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:14 --> Total execution time: 0.6632
DEBUG - 2011-08-25 23:57:27 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:27 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:27 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Controller Class Initialized
ERROR - 2011-08-25 23:57:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:57:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:27 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:27 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:57:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:57:27 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:27 --> Total execution time: 0.0421
DEBUG - 2011-08-25 23:57:28 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:28 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:28 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Controller Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:28 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:29 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:29 --> Total execution time: 0.7216
DEBUG - 2011-08-25 23:57:55 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:55 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:55 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Controller Class Initialized
ERROR - 2011-08-25 23:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:55 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:55 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:57:55 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:55 --> Total execution time: 0.0746
DEBUG - 2011-08-25 23:57:56 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:56 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:56 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Controller Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:56 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:57 --> Total execution time: 0.7658
DEBUG - 2011-08-25 23:57:57 --> Config Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:57:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:57:57 --> URI Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Router Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Output Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Input Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:57:57 --> Language Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Loader Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Controller Class Initialized
ERROR - 2011-08-25 23:57:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:57:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:57 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Model Class Initialized
DEBUG - 2011-08-25 23:57:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:57:57 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:57:57 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:57:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:57:57 --> Final output sent to browser
DEBUG - 2011-08-25 23:57:57 --> Total execution time: 0.0279
DEBUG - 2011-08-25 23:58:21 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:21 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:21 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Controller Class Initialized
ERROR - 2011-08-25 23:58:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:58:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:21 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:21 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:21 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:58:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:58:21 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:21 --> Total execution time: 0.0285
DEBUG - 2011-08-25 23:58:22 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:22 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:22 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Controller Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:22 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:23 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:23 --> Total execution time: 0.5292
DEBUG - 2011-08-25 23:58:30 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:30 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:30 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Controller Class Initialized
ERROR - 2011-08-25 23:58:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:58:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:30 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:30 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:30 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:58:30 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:30 --> Total execution time: 0.0264
DEBUG - 2011-08-25 23:58:31 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:31 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:31 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Controller Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:31 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:32 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:32 --> Total execution time: 0.7234
DEBUG - 2011-08-25 23:58:50 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:50 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:50 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Controller Class Initialized
ERROR - 2011-08-25 23:58:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:58:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:50 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:50 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:58:50 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:58:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:58:50 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:50 --> Total execution time: 0.0810
DEBUG - 2011-08-25 23:58:53 --> Config Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:58:53 --> URI Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Router Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Output Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Input Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:58:53 --> Language Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Loader Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Controller Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Model Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:58:53 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:58:53 --> Final output sent to browser
DEBUG - 2011-08-25 23:58:53 --> Total execution time: 0.6497
DEBUG - 2011-08-25 23:59:05 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:05 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:05 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:05 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:05 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:05 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:05 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:05 --> Total execution time: 0.0285
DEBUG - 2011-08-25 23:59:06 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:06 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:06 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Controller Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:06 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:06 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:06 --> Total execution time: 0.5381
DEBUG - 2011-08-25 23:59:07 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:07 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:07 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:07 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:07 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:07 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:07 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:07 --> Total execution time: 0.0295
DEBUG - 2011-08-25 23:59:31 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:31 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:31 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:31 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:31 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:31 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:31 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:31 --> Total execution time: 0.0284
DEBUG - 2011-08-25 23:59:32 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:32 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:32 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Controller Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:32 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:33 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:33 --> Total execution time: 0.5981
DEBUG - 2011-08-25 23:59:46 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:46 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:46 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:46 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:46 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:46 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:46 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:46 --> Total execution time: 0.0302
DEBUG - 2011-08-25 23:59:47 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:47 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:47 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Controller Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:47 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:48 --> Total execution time: 0.5379
DEBUG - 2011-08-25 23:59:48 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:48 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:48 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:48 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:48 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:48 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:48 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:48 --> Total execution time: 0.0327
DEBUG - 2011-08-25 23:59:55 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:55 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:55 --> No URI present. Default controller set.
DEBUG - 2011-08-25 23:59:55 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:55 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:55 --> Controller Class Initialized
DEBUG - 2011-08-25 23:59:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-25 23:59:55 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:55 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:55 --> Total execution time: 0.0353
DEBUG - 2011-08-25 23:59:57 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:57 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:57 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Controller Class Initialized
ERROR - 2011-08-25 23:59:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-25 23:59:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-25 23:59:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:57 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-25 23:59:58 --> Helper loaded: url_helper
DEBUG - 2011-08-25 23:59:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-25 23:59:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-25 23:59:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-25 23:59:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-25 23:59:58 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:58 --> Total execution time: 0.0274
DEBUG - 2011-08-25 23:59:58 --> Config Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Hooks Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Utf8 Class Initialized
DEBUG - 2011-08-25 23:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-25 23:59:58 --> URI Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Router Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Output Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Input Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-25 23:59:58 --> Language Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Loader Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Controller Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Model Class Initialized
DEBUG - 2011-08-25 23:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-25 23:59:58 --> Database Driver Class Initialized
DEBUG - 2011-08-25 23:59:59 --> Final output sent to browser
DEBUG - 2011-08-25 23:59:59 --> Total execution time: 0.8429

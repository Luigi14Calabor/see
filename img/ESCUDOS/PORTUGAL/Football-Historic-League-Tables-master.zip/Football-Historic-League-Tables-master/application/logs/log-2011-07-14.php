<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-14 02:56:13 --> Config Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Hooks Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Utf8 Class Initialized
DEBUG - 2011-07-14 02:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 02:56:13 --> URI Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Router Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Output Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Input Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 02:56:13 --> Language Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Loader Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Controller Class Initialized
ERROR - 2011-07-14 02:56:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 02:56:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 02:56:13 --> Model Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Model Class Initialized
DEBUG - 2011-07-14 02:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 02:56:13 --> Database Driver Class Initialized
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 02:56:13 --> Helper loaded: url_helper
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 02:56:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 02:56:13 --> Final output sent to browser
DEBUG - 2011-07-14 02:56:13 --> Total execution time: 0.6712
DEBUG - 2011-07-14 03:02:34 --> Config Class Initialized
DEBUG - 2011-07-14 03:02:34 --> Hooks Class Initialized
DEBUG - 2011-07-14 03:02:34 --> Utf8 Class Initialized
DEBUG - 2011-07-14 03:02:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 03:02:34 --> URI Class Initialized
DEBUG - 2011-07-14 03:02:34 --> Router Class Initialized
ERROR - 2011-07-14 03:02:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-14 03:52:27 --> Config Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Hooks Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Utf8 Class Initialized
DEBUG - 2011-07-14 03:52:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 03:52:27 --> URI Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Router Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Output Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Input Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 03:52:27 --> Language Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Loader Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Controller Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Model Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Model Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Model Class Initialized
DEBUG - 2011-07-14 03:52:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 03:52:27 --> Database Driver Class Initialized
DEBUG - 2011-07-14 03:52:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 03:52:27 --> Helper loaded: url_helper
DEBUG - 2011-07-14 03:52:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 03:52:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 03:52:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 03:52:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 03:52:27 --> Final output sent to browser
DEBUG - 2011-07-14 03:52:27 --> Total execution time: 0.5352
DEBUG - 2011-07-14 03:52:31 --> Config Class Initialized
DEBUG - 2011-07-14 03:52:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 03:52:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 03:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 03:52:31 --> URI Class Initialized
DEBUG - 2011-07-14 03:52:31 --> Router Class Initialized
ERROR - 2011-07-14 03:52:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:10:09 --> Config Class Initialized
DEBUG - 2011-07-14 04:10:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:10:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:10:09 --> URI Class Initialized
DEBUG - 2011-07-14 04:10:09 --> Router Class Initialized
DEBUG - 2011-07-14 04:10:09 --> Output Class Initialized
DEBUG - 2011-07-14 04:10:10 --> Input Class Initialized
DEBUG - 2011-07-14 04:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:10:10 --> Language Class Initialized
DEBUG - 2011-07-14 04:10:10 --> Loader Class Initialized
DEBUG - 2011-07-14 04:10:10 --> Controller Class Initialized
ERROR - 2011-07-14 04:10:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:10:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:10:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:10:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:10:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:10:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:10:12 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:10:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:10:13 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:10:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:10:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:10:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:10:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:10:13 --> Final output sent to browser
DEBUG - 2011-07-14 04:10:13 --> Total execution time: 4.6925
DEBUG - 2011-07-14 04:10:17 --> Config Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:10:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:10:17 --> URI Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Router Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Output Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Input Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:10:17 --> Language Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Loader Class Initialized
DEBUG - 2011-07-14 04:10:17 --> Controller Class Initialized
DEBUG - 2011-07-14 04:10:18 --> Model Class Initialized
DEBUG - 2011-07-14 04:10:18 --> Model Class Initialized
DEBUG - 2011-07-14 04:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:10:18 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:10:19 --> Final output sent to browser
DEBUG - 2011-07-14 04:10:19 --> Total execution time: 1.7912
DEBUG - 2011-07-14 04:10:23 --> Config Class Initialized
DEBUG - 2011-07-14 04:10:23 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:10:23 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:10:23 --> URI Class Initialized
DEBUG - 2011-07-14 04:10:23 --> Router Class Initialized
ERROR - 2011-07-14 04:10:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:11:13 --> Config Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:11:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:11:13 --> URI Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Router Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Output Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Input Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:11:13 --> Language Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Loader Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Controller Class Initialized
ERROR - 2011-07-14 04:11:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:11:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:11:13 --> Model Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Model Class Initialized
DEBUG - 2011-07-14 04:11:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:11:13 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:11:13 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:11:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:11:13 --> Final output sent to browser
DEBUG - 2011-07-14 04:11:13 --> Total execution time: 0.0271
DEBUG - 2011-07-14 04:11:15 --> Config Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:11:15 --> URI Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Router Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Output Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Input Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:11:15 --> Language Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Loader Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Controller Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Model Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Model Class Initialized
DEBUG - 2011-07-14 04:11:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:11:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:11:16 --> Final output sent to browser
DEBUG - 2011-07-14 04:11:16 --> Total execution time: 0.6550
DEBUG - 2011-07-14 04:11:18 --> Config Class Initialized
DEBUG - 2011-07-14 04:11:18 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:11:18 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:11:18 --> URI Class Initialized
DEBUG - 2011-07-14 04:11:18 --> Router Class Initialized
ERROR - 2011-07-14 04:11:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:12:21 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:21 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Router Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Output Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Input Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:12:21 --> Language Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Loader Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Controller Class Initialized
ERROR - 2011-07-14 04:12:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:12:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:12:21 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:12:21 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:12:21 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:12:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:12:21 --> Final output sent to browser
DEBUG - 2011-07-14 04:12:21 --> Total execution time: 0.0319
DEBUG - 2011-07-14 04:12:23 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:23 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Router Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Output Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Input Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:12:23 --> Language Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Loader Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Controller Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:12:23 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:12:23 --> Final output sent to browser
DEBUG - 2011-07-14 04:12:23 --> Total execution time: 0.5636
DEBUG - 2011-07-14 04:12:26 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:26 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:26 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:26 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:26 --> Router Class Initialized
ERROR - 2011-07-14 04:12:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:12:47 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:47 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Router Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Output Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Input Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:12:47 --> Language Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Loader Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Controller Class Initialized
ERROR - 2011-07-14 04:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:12:47 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:12:47 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:12:47 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:12:47 --> Final output sent to browser
DEBUG - 2011-07-14 04:12:47 --> Total execution time: 0.0268
DEBUG - 2011-07-14 04:12:49 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:49 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Router Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Output Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Input Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:12:49 --> Language Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Loader Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Controller Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Model Class Initialized
DEBUG - 2011-07-14 04:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:12:49 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:12:50 --> Final output sent to browser
DEBUG - 2011-07-14 04:12:50 --> Total execution time: 0.5677
DEBUG - 2011-07-14 04:12:52 --> Config Class Initialized
DEBUG - 2011-07-14 04:12:52 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:12:52 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:12:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:12:52 --> URI Class Initialized
DEBUG - 2011-07-14 04:12:52 --> Router Class Initialized
ERROR - 2011-07-14 04:12:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:13:25 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:25 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Router Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Output Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Input Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:13:25 --> Language Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Loader Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Controller Class Initialized
ERROR - 2011-07-14 04:13:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:13:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:13:25 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:13:25 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:13:25 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:13:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:13:25 --> Final output sent to browser
DEBUG - 2011-07-14 04:13:25 --> Total execution time: 0.0494
DEBUG - 2011-07-14 04:13:28 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:28 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Router Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Output Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Input Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:13:28 --> Language Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Loader Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Controller Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:13:28 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:13:28 --> Final output sent to browser
DEBUG - 2011-07-14 04:13:28 --> Total execution time: 0.6667
DEBUG - 2011-07-14 04:13:31 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:31 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:31 --> Router Class Initialized
ERROR - 2011-07-14 04:13:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:13:51 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:51 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Router Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Output Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Input Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:13:51 --> Language Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Loader Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Controller Class Initialized
ERROR - 2011-07-14 04:13:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:13:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:13:51 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:13:51 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:13:51 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:13:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:13:51 --> Final output sent to browser
DEBUG - 2011-07-14 04:13:51 --> Total execution time: 0.0333
DEBUG - 2011-07-14 04:13:53 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:53 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Router Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Output Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Input Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:13:53 --> Language Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Loader Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Controller Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Model Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:13:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:13:53 --> Final output sent to browser
DEBUG - 2011-07-14 04:13:53 --> Total execution time: 0.6116
DEBUG - 2011-07-14 04:13:56 --> Config Class Initialized
DEBUG - 2011-07-14 04:13:56 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:13:56 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:13:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:13:56 --> URI Class Initialized
DEBUG - 2011-07-14 04:13:56 --> Router Class Initialized
ERROR - 2011-07-14 04:13:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:14:08 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:08 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Router Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Output Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Input Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:14:08 --> Language Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Loader Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Controller Class Initialized
ERROR - 2011-07-14 04:14:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:14:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:08 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:14:08 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:08 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:14:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:14:08 --> Final output sent to browser
DEBUG - 2011-07-14 04:14:08 --> Total execution time: 0.0270
DEBUG - 2011-07-14 04:14:11 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:11 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Router Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Output Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Input Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:14:11 --> Language Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Loader Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Controller Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:14:11 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:14:11 --> Final output sent to browser
DEBUG - 2011-07-14 04:14:11 --> Total execution time: 0.7304
DEBUG - 2011-07-14 04:14:14 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:14 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:14 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:14 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:14 --> Router Class Initialized
ERROR - 2011-07-14 04:14:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:14:16 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:16 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Router Class Initialized
ERROR - 2011-07-14 04:14:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-14 04:14:16 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:16 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Router Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Output Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Input Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:14:16 --> Language Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Loader Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Controller Class Initialized
ERROR - 2011-07-14 04:14:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:14:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:16 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:14:16 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:16 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:14:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:14:16 --> Final output sent to browser
DEBUG - 2011-07-14 04:14:16 --> Total execution time: 0.0308
DEBUG - 2011-07-14 04:14:30 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:30 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Router Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Output Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Input Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:14:30 --> Language Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Loader Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Controller Class Initialized
ERROR - 2011-07-14 04:14:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:14:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:30 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:14:30 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:14:30 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:14:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:14:30 --> Final output sent to browser
DEBUG - 2011-07-14 04:14:30 --> Total execution time: 0.0274
DEBUG - 2011-07-14 04:14:32 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:32 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Router Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Output Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Input Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:14:32 --> Language Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Loader Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Controller Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Model Class Initialized
DEBUG - 2011-07-14 04:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:14:32 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:14:33 --> Final output sent to browser
DEBUG - 2011-07-14 04:14:33 --> Total execution time: 0.5752
DEBUG - 2011-07-14 04:14:36 --> Config Class Initialized
DEBUG - 2011-07-14 04:14:36 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:14:36 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:14:36 --> URI Class Initialized
DEBUG - 2011-07-14 04:14:36 --> Router Class Initialized
ERROR - 2011-07-14 04:14:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:15:03 --> Config Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:15:03 --> URI Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Router Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Output Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Input Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:15:03 --> Language Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Loader Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Controller Class Initialized
ERROR - 2011-07-14 04:15:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:15:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:15:03 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:15:03 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:15:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:15:03 --> Final output sent to browser
DEBUG - 2011-07-14 04:15:03 --> Total execution time: 0.1451
DEBUG - 2011-07-14 04:15:11 --> Config Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:15:11 --> URI Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Router Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Output Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Input Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:15:11 --> Language Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Loader Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Controller Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:15:11 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:15:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:15:12 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:15:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:15:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:15:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:15:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:15:12 --> Final output sent to browser
DEBUG - 2011-07-14 04:15:12 --> Total execution time: 0.9610
DEBUG - 2011-07-14 04:15:16 --> Config Class Initialized
DEBUG - 2011-07-14 04:15:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:15:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:15:16 --> URI Class Initialized
DEBUG - 2011-07-14 04:15:16 --> Router Class Initialized
ERROR - 2011-07-14 04:15:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:15:29 --> Config Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:15:29 --> URI Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Router Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Output Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Input Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:15:29 --> Language Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Loader Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Controller Class Initialized
ERROR - 2011-07-14 04:15:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 04:15:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:15:29 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Model Class Initialized
DEBUG - 2011-07-14 04:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:15:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 04:15:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:15:29 --> Final output sent to browser
DEBUG - 2011-07-14 04:15:29 --> Total execution time: 0.0313
DEBUG - 2011-07-14 04:54:29 --> Config Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:54:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:54:29 --> URI Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Router Class Initialized
DEBUG - 2011-07-14 04:54:29 --> No URI present. Default controller set.
DEBUG - 2011-07-14 04:54:29 --> Output Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Input Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:54:29 --> Language Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Loader Class Initialized
DEBUG - 2011-07-14 04:54:29 --> Controller Class Initialized
DEBUG - 2011-07-14 04:54:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-14 04:54:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:54:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:54:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:54:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:54:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:54:29 --> Final output sent to browser
DEBUG - 2011-07-14 04:54:29 --> Total execution time: 0.2615
DEBUG - 2011-07-14 04:54:31 --> Config Class Initialized
DEBUG - 2011-07-14 04:54:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:54:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:54:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:54:31 --> URI Class Initialized
DEBUG - 2011-07-14 04:54:31 --> Router Class Initialized
ERROR - 2011-07-14 04:54:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:54:43 --> Config Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:54:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:54:43 --> URI Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Router Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Output Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Input Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:54:43 --> Language Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Loader Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Controller Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Model Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Model Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Model Class Initialized
DEBUG - 2011-07-14 04:54:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:54:43 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:54:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:54:43 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:54:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:54:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:54:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:54:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:54:43 --> Final output sent to browser
DEBUG - 2011-07-14 04:54:43 --> Total execution time: 0.4451
DEBUG - 2011-07-14 04:54:44 --> Config Class Initialized
DEBUG - 2011-07-14 04:54:44 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:54:44 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:54:44 --> URI Class Initialized
DEBUG - 2011-07-14 04:54:44 --> Router Class Initialized
ERROR - 2011-07-14 04:54:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:54:50 --> Config Class Initialized
DEBUG - 2011-07-14 04:54:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:54:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:54:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:54:50 --> URI Class Initialized
DEBUG - 2011-07-14 04:54:50 --> Router Class Initialized
ERROR - 2011-07-14 04:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:55:02 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:02 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:02 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:03 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:03 --> Total execution time: 0.8229
DEBUG - 2011-07-14 04:55:07 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:07 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:07 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:07 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:07 --> Router Class Initialized
ERROR - 2011-07-14 04:55:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:55:09 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:09 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:09 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:09 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:09 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:09 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:09 --> Total execution time: 0.0416
DEBUG - 2011-07-14 04:55:18 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:18 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:18 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:18 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:18 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:18 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:18 --> Total execution time: 0.3045
DEBUG - 2011-07-14 04:55:20 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:20 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:20 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:20 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:20 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:20 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:20 --> Total execution time: 0.0414
DEBUG - 2011-07-14 04:55:20 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:20 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:20 --> Router Class Initialized
ERROR - 2011-07-14 04:55:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:55:28 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:28 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:28 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:28 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:29 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:29 --> Total execution time: 0.2159
DEBUG - 2011-07-14 04:55:30 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:30 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:30 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:30 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:30 --> Router Class Initialized
ERROR - 2011-07-14 04:55:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 04:55:32 --> Config Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Hooks Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Utf8 Class Initialized
DEBUG - 2011-07-14 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 04:55:32 --> URI Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Router Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Output Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Input Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 04:55:32 --> Language Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Loader Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Controller Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Model Class Initialized
DEBUG - 2011-07-14 04:55:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 04:55:32 --> Database Driver Class Initialized
DEBUG - 2011-07-14 04:55:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 04:55:32 --> Helper loaded: url_helper
DEBUG - 2011-07-14 04:55:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 04:55:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 04:55:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 04:55:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 04:55:32 --> Final output sent to browser
DEBUG - 2011-07-14 04:55:32 --> Total execution time: 0.0479
DEBUG - 2011-07-14 05:31:43 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:43 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Router Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Output Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Input Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:31:43 --> Language Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Loader Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Controller Class Initialized
ERROR - 2011-07-14 05:31:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:31:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:43 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:31:43 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:43 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:31:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:31:43 --> Final output sent to browser
DEBUG - 2011-07-14 05:31:43 --> Total execution time: 0.4076
DEBUG - 2011-07-14 05:31:44 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:44 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Router Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Output Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Input Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:31:44 --> Language Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Loader Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Controller Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:31:44 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:31:45 --> Final output sent to browser
DEBUG - 2011-07-14 05:31:45 --> Total execution time: 1.0494
DEBUG - 2011-07-14 05:31:46 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:46 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Router Class Initialized
ERROR - 2011-07-14 05:31:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 05:31:46 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:46 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:46 --> Router Class Initialized
ERROR - 2011-07-14 05:31:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 05:31:57 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:57 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Router Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Output Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Input Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:31:57 --> Language Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Loader Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Controller Class Initialized
ERROR - 2011-07-14 05:31:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:31:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:57 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:31:57 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:57 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:31:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:31:57 --> Final output sent to browser
DEBUG - 2011-07-14 05:31:57 --> Total execution time: 0.0348
DEBUG - 2011-07-14 05:31:58 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:58 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Router Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Output Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Input Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:31:58 --> Language Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Loader Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Controller Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:31:58 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Final output sent to browser
DEBUG - 2011-07-14 05:31:58 --> Total execution time: 0.6243
DEBUG - 2011-07-14 05:31:58 --> Config Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:31:58 --> URI Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Router Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Output Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Input Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:31:58 --> Language Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Loader Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Controller Class Initialized
ERROR - 2011-07-14 05:31:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:31:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:31:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Model Class Initialized
DEBUG - 2011-07-14 05:31:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:31:59 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:31:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:31:59 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:31:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:31:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:31:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:31:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:31:59 --> Final output sent to browser
DEBUG - 2011-07-14 05:31:59 --> Total execution time: 0.0306
DEBUG - 2011-07-14 05:32:06 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:06 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:06 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Controller Class Initialized
ERROR - 2011-07-14 05:32:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:32:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:06 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:06 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:06 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:32:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:32:06 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:06 --> Total execution time: 0.0602
DEBUG - 2011-07-14 05:32:07 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:07 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:07 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Controller Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:07 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:07 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:07 --> Total execution time: 0.9122
DEBUG - 2011-07-14 05:32:12 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:12 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:12 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Controller Class Initialized
ERROR - 2011-07-14 05:32:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:32:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:12 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:12 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:12 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:32:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:32:12 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:12 --> Total execution time: 0.0286
DEBUG - 2011-07-14 05:32:12 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:12 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:12 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Controller Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:12 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:13 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:13 --> Total execution time: 0.5664
DEBUG - 2011-07-14 05:32:19 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:19 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:19 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Controller Class Initialized
ERROR - 2011-07-14 05:32:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:32:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:19 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:19 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:19 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:32:19 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:19 --> Total execution time: 0.0269
DEBUG - 2011-07-14 05:32:24 --> Config Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:32:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:32:24 --> URI Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Router Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Output Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Input Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:32:24 --> Language Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Loader Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Controller Class Initialized
ERROR - 2011-07-14 05:32:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 05:32:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:24 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Model Class Initialized
DEBUG - 2011-07-14 05:32:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:32:24 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 05:32:24 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:32:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:32:24 --> Final output sent to browser
DEBUG - 2011-07-14 05:32:24 --> Total execution time: 0.0283
DEBUG - 2011-07-14 05:40:33 --> Config Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:40:33 --> URI Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Router Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Output Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Input Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 05:40:33 --> Language Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Loader Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Controller Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Model Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Model Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Model Class Initialized
DEBUG - 2011-07-14 05:40:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 05:40:33 --> Database Driver Class Initialized
DEBUG - 2011-07-14 05:40:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 05:40:34 --> Helper loaded: url_helper
DEBUG - 2011-07-14 05:40:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 05:40:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 05:40:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 05:40:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 05:40:34 --> Final output sent to browser
DEBUG - 2011-07-14 05:40:34 --> Total execution time: 0.4141
DEBUG - 2011-07-14 05:40:35 --> Config Class Initialized
DEBUG - 2011-07-14 05:40:35 --> Hooks Class Initialized
DEBUG - 2011-07-14 05:40:35 --> Utf8 Class Initialized
DEBUG - 2011-07-14 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 05:40:35 --> URI Class Initialized
DEBUG - 2011-07-14 05:40:35 --> Router Class Initialized
ERROR - 2011-07-14 05:40:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:13:06 --> Config Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:13:07 --> URI Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Router Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Output Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Input Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:13:07 --> Language Class Initialized
DEBUG - 2011-07-14 06:13:07 --> Loader Class Initialized
DEBUG - 2011-07-14 06:13:08 --> Controller Class Initialized
DEBUG - 2011-07-14 06:13:08 --> Model Class Initialized
DEBUG - 2011-07-14 06:13:08 --> Model Class Initialized
DEBUG - 2011-07-14 06:13:08 --> Model Class Initialized
DEBUG - 2011-07-14 06:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:13:08 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:13:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:13:10 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:13:10 --> Final output sent to browser
DEBUG - 2011-07-14 06:13:10 --> Total execution time: 3.9417
DEBUG - 2011-07-14 06:13:11 --> Config Class Initialized
DEBUG - 2011-07-14 06:13:11 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:13:11 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:13:11 --> URI Class Initialized
DEBUG - 2011-07-14 06:13:11 --> Router Class Initialized
ERROR - 2011-07-14 06:13:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:14:02 --> Config Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:14:02 --> URI Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Router Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Output Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Input Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:14:02 --> Language Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Loader Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Controller Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:14:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:14:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:14:03 --> Final output sent to browser
DEBUG - 2011-07-14 06:14:03 --> Total execution time: 0.5891
DEBUG - 2011-07-14 06:14:03 --> Config Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:14:03 --> URI Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Router Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Output Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Input Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:14:03 --> Language Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Loader Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Controller Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:14:03 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:14:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:14:03 --> Final output sent to browser
DEBUG - 2011-07-14 06:14:03 --> Total execution time: 0.0436
DEBUG - 2011-07-14 06:14:04 --> Config Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:14:04 --> URI Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Router Class Initialized
ERROR - 2011-07-14 06:14:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:14:04 --> Config Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:14:04 --> URI Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Router Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Output Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Input Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:14:04 --> Language Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Loader Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Controller Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Model Class Initialized
DEBUG - 2011-07-14 06:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:14:04 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:14:04 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:14:04 --> Final output sent to browser
DEBUG - 2011-07-14 06:14:04 --> Total execution time: 0.0418
DEBUG - 2011-07-14 06:15:15 --> Config Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:15:15 --> URI Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Router Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Output Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Input Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:15:15 --> Language Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Loader Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Controller Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:15:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:15:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:15:15 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:15:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:15:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:15:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:15:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:15:15 --> Final output sent to browser
DEBUG - 2011-07-14 06:15:15 --> Total execution time: 0.2826
DEBUG - 2011-07-14 06:15:16 --> Config Class Initialized
DEBUG - 2011-07-14 06:15:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:15:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:15:16 --> URI Class Initialized
DEBUG - 2011-07-14 06:15:16 --> Router Class Initialized
ERROR - 2011-07-14 06:15:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:15:17 --> Config Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:15:17 --> URI Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Router Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Output Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Input Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:15:17 --> Language Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Loader Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Controller Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Model Class Initialized
DEBUG - 2011-07-14 06:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:15:17 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:15:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:15:17 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:15:17 --> Final output sent to browser
DEBUG - 2011-07-14 06:15:17 --> Total execution time: 0.0782
DEBUG - 2011-07-14 06:16:15 --> Config Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:16:15 --> URI Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Router Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Output Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Input Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:16:15 --> Language Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Loader Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Controller Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:16:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:16:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:16:15 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:16:15 --> Final output sent to browser
DEBUG - 2011-07-14 06:16:15 --> Total execution time: 0.3270
DEBUG - 2011-07-14 06:16:16 --> Config Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:16:16 --> URI Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Router Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Output Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Input Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:16:16 --> Language Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Loader Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Controller Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Model Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:16:16 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:16:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:16:16 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:16:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:16:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:16:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:16:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:16:16 --> Final output sent to browser
DEBUG - 2011-07-14 06:16:16 --> Total execution time: 0.0500
DEBUG - 2011-07-14 06:16:16 --> Config Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:16:16 --> URI Class Initialized
DEBUG - 2011-07-14 06:16:16 --> Router Class Initialized
ERROR - 2011-07-14 06:16:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:27:43 --> Config Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:27:43 --> URI Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Router Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Output Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Input Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:27:43 --> Language Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Loader Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Controller Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:27:43 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:27:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:27:43 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:27:43 --> Final output sent to browser
DEBUG - 2011-07-14 06:27:43 --> Total execution time: 0.2778
DEBUG - 2011-07-14 06:27:44 --> Config Class Initialized
DEBUG - 2011-07-14 06:27:44 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:27:44 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:27:44 --> URI Class Initialized
DEBUG - 2011-07-14 06:27:44 --> Router Class Initialized
ERROR - 2011-07-14 06:27:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:27:52 --> Config Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:27:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:27:52 --> URI Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Router Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Output Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Input Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:27:52 --> Language Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Loader Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Controller Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:27:52 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:27:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:27:52 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:27:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:27:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:27:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:27:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:27:52 --> Final output sent to browser
DEBUG - 2011-07-14 06:27:52 --> Total execution time: 0.2458
DEBUG - 2011-07-14 06:27:53 --> Config Class Initialized
DEBUG - 2011-07-14 06:27:53 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:27:53 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:27:53 --> URI Class Initialized
DEBUG - 2011-07-14 06:27:53 --> Router Class Initialized
ERROR - 2011-07-14 06:27:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:27:54 --> Config Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:27:54 --> URI Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Router Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Output Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Input Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:27:54 --> Language Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Loader Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Controller Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Model Class Initialized
DEBUG - 2011-07-14 06:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:27:54 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:27:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:27:54 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:27:54 --> Final output sent to browser
DEBUG - 2011-07-14 06:27:54 --> Total execution time: 0.0853
DEBUG - 2011-07-14 06:28:00 --> Config Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:28:00 --> URI Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Router Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Output Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Input Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:28:00 --> Language Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Loader Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Controller Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:28:00 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:28:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:28:00 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:28:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:28:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:28:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:28:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:28:00 --> Final output sent to browser
DEBUG - 2011-07-14 06:28:00 --> Total execution time: 0.3638
DEBUG - 2011-07-14 06:28:01 --> Config Class Initialized
DEBUG - 2011-07-14 06:28:01 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:28:01 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:28:01 --> URI Class Initialized
DEBUG - 2011-07-14 06:28:01 --> Router Class Initialized
ERROR - 2011-07-14 06:28:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 06:28:02 --> Config Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 06:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 06:28:02 --> URI Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Router Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Output Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Input Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 06:28:02 --> Language Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Loader Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Controller Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 06:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 06:28:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 06:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 06:28:02 --> Helper loaded: url_helper
DEBUG - 2011-07-14 06:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 06:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 06:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 06:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 06:28:02 --> Final output sent to browser
DEBUG - 2011-07-14 06:28:02 --> Total execution time: 0.1341
DEBUG - 2011-07-14 08:44:04 --> Config Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:44:05 --> URI Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Router Class Initialized
ERROR - 2011-07-14 08:44:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-14 08:44:05 --> Config Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:44:05 --> URI Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Router Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Output Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Input Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:44:05 --> Language Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Loader Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Controller Class Initialized
ERROR - 2011-07-14 08:44:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:44:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:44:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:44:05 --> Model Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Model Class Initialized
DEBUG - 2011-07-14 08:44:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:44:05 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:44:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:44:06 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:44:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:44:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:44:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:44:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:44:06 --> Final output sent to browser
DEBUG - 2011-07-14 08:44:06 --> Total execution time: 0.6499
DEBUG - 2011-07-14 08:51:50 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:50 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:50 --> Router Class Initialized
DEBUG - 2011-07-14 08:51:50 --> Output Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:51 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Router Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Output Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Input Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Input Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:51:51 --> Language Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Language Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Loader Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Loader Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Controller Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Controller Class Initialized
ERROR - 2011-07-14 08:51:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:51:51 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:51 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Router Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Output Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Input Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:51:51 --> Language Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Loader Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Controller Class Initialized
ERROR - 2011-07-14 08:51:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:51:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:51:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:51:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:51:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:51:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:54 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:51:54 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:51:54 --> Final output sent to browser
DEBUG - 2011-07-14 08:51:54 --> Total execution time: 3.2027
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:51:54 --> Final output sent to browser
DEBUG - 2011-07-14 08:51:54 --> Total execution time: 2.2953
DEBUG - 2011-07-14 08:51:54 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:54 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Router Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Output Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Input Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:51:54 --> Language Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Loader Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Controller Class Initialized
ERROR - 2011-07-14 08:51:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:51:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:54 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:51:54 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:51:54 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:51:54 --> Final output sent to browser
DEBUG - 2011-07-14 08:51:54 --> Total execution time: 0.0307
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 08:51:54 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:51:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:51:54 --> Final output sent to browser
DEBUG - 2011-07-14 08:51:54 --> Total execution time: 4.3507
DEBUG - 2011-07-14 08:51:55 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:55 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Router Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Output Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Input Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:51:55 --> Language Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Loader Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Controller Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Model Class Initialized
DEBUG - 2011-07-14 08:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:51:55 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:51:56 --> Final output sent to browser
DEBUG - 2011-07-14 08:51:56 --> Total execution time: 1.0626
DEBUG - 2011-07-14 08:51:58 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:58 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Router Class Initialized
ERROR - 2011-07-14 08:51:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 08:51:58 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:58 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:58 --> Router Class Initialized
ERROR - 2011-07-14 08:51:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 08:51:59 --> Config Class Initialized
DEBUG - 2011-07-14 08:51:59 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:51:59 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:51:59 --> URI Class Initialized
DEBUG - 2011-07-14 08:51:59 --> Router Class Initialized
ERROR - 2011-07-14 08:51:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 08:52:31 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:31 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:31 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Controller Class Initialized
ERROR - 2011-07-14 08:52:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:52:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:31 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:31 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:31 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:52:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:52:31 --> Final output sent to browser
DEBUG - 2011-07-14 08:52:31 --> Total execution time: 0.0321
DEBUG - 2011-07-14 08:52:31 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:31 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:31 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Controller Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:31 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:52:32 --> Final output sent to browser
DEBUG - 2011-07-14 08:52:32 --> Total execution time: 0.6810
DEBUG - 2011-07-14 08:52:43 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:43 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:43 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Controller Class Initialized
ERROR - 2011-07-14 08:52:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:52:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:43 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:43 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:43 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:52:43 --> Final output sent to browser
DEBUG - 2011-07-14 08:52:43 --> Total execution time: 0.0709
DEBUG - 2011-07-14 08:52:45 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:45 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:45 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Controller Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:45 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:52:45 --> Final output sent to browser
DEBUG - 2011-07-14 08:52:45 --> Total execution time: 0.7051
DEBUG - 2011-07-14 08:52:59 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:59 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:59 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Controller Class Initialized
ERROR - 2011-07-14 08:52:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:52:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:59 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:59 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:52:59 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:52:59 --> Final output sent to browser
DEBUG - 2011-07-14 08:52:59 --> Total execution time: 0.0359
DEBUG - 2011-07-14 08:52:59 --> Config Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:52:59 --> URI Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Router Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Output Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Input Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:52:59 --> Language Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Loader Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Controller Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Model Class Initialized
DEBUG - 2011-07-14 08:52:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:52:59 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:01 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:01 --> Total execution time: 1.2341
DEBUG - 2011-07-14 08:53:23 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:23 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:23 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Controller Class Initialized
ERROR - 2011-07-14 08:53:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:53:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:23 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:23 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:23 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:53:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:53:23 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:23 --> Total execution time: 0.0312
DEBUG - 2011-07-14 08:53:24 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:24 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:24 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Controller Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:24 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:25 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:25 --> Total execution time: 0.6622
DEBUG - 2011-07-14 08:53:32 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:32 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:32 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Controller Class Initialized
ERROR - 2011-07-14 08:53:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:53:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:32 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:32 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:32 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:53:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:53:32 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:32 --> Total execution time: 0.0299
DEBUG - 2011-07-14 08:53:33 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:33 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:33 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Controller Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:33 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:35 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:35 --> Total execution time: 2.0258
DEBUG - 2011-07-14 08:53:51 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:51 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:51 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Controller Class Initialized
ERROR - 2011-07-14 08:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:51 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:51 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:53:51 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:51 --> Total execution time: 0.0357
DEBUG - 2011-07-14 08:53:52 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:52 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:52 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Controller Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:52 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:52 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:52 --> Total execution time: 0.5530
DEBUG - 2011-07-14 08:53:57 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:57 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:57 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Controller Class Initialized
ERROR - 2011-07-14 08:53:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 08:53:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:57 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:57 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 08:53:57 --> Helper loaded: url_helper
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 08:53:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 08:53:57 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:57 --> Total execution time: 0.0327
DEBUG - 2011-07-14 08:53:57 --> Config Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 08:53:57 --> URI Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Router Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Output Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Input Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 08:53:57 --> Language Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Loader Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Controller Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Model Class Initialized
DEBUG - 2011-07-14 08:53:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 08:53:57 --> Database Driver Class Initialized
DEBUG - 2011-07-14 08:53:58 --> Final output sent to browser
DEBUG - 2011-07-14 08:53:58 --> Total execution time: 0.5787
DEBUG - 2011-07-14 10:26:04 --> Config Class Initialized
DEBUG - 2011-07-14 10:26:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:26:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:26:04 --> URI Class Initialized
DEBUG - 2011-07-14 10:26:04 --> Router Class Initialized
DEBUG - 2011-07-14 10:26:04 --> No URI present. Default controller set.
DEBUG - 2011-07-14 10:26:05 --> Output Class Initialized
DEBUG - 2011-07-14 10:26:05 --> Input Class Initialized
DEBUG - 2011-07-14 10:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:26:05 --> Language Class Initialized
DEBUG - 2011-07-14 10:26:05 --> Loader Class Initialized
DEBUG - 2011-07-14 10:26:05 --> Controller Class Initialized
DEBUG - 2011-07-14 10:26:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-14 10:26:05 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:26:05 --> Final output sent to browser
DEBUG - 2011-07-14 10:26:05 --> Total execution time: 0.3566
DEBUG - 2011-07-14 10:27:13 --> Config Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:27:13 --> URI Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Router Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Output Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Input Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:27:13 --> Language Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Loader Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Controller Class Initialized
ERROR - 2011-07-14 10:27:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:27:13 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:27:13 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:27:13 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:27:13 --> Final output sent to browser
DEBUG - 2011-07-14 10:27:13 --> Total execution time: 0.2466
DEBUG - 2011-07-14 10:27:14 --> Config Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:27:14 --> URI Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Router Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Output Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Input Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:27:14 --> Language Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Loader Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Controller Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:27:14 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:27:15 --> Final output sent to browser
DEBUG - 2011-07-14 10:27:15 --> Total execution time: 0.6862
DEBUG - 2011-07-14 10:27:16 --> Config Class Initialized
DEBUG - 2011-07-14 10:27:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:27:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:27:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:27:16 --> URI Class Initialized
DEBUG - 2011-07-14 10:27:16 --> Router Class Initialized
ERROR - 2011-07-14 10:27:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:27:50 --> Config Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:27:50 --> URI Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Router Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Output Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Input Class Initialized
DEBUG - 2011-07-14 10:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:27:50 --> Language Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Loader Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Controller Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Model Class Initialized
DEBUG - 2011-07-14 10:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:27:51 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:27:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:27:51 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:27:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:27:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:27:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:27:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:27:51 --> Final output sent to browser
DEBUG - 2011-07-14 10:27:51 --> Total execution time: 0.8988
DEBUG - 2011-07-14 10:27:53 --> Config Class Initialized
DEBUG - 2011-07-14 10:27:53 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:27:53 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:27:53 --> URI Class Initialized
DEBUG - 2011-07-14 10:27:53 --> Router Class Initialized
ERROR - 2011-07-14 10:27:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:28:00 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:00 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:00 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:00 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:01 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:01 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:01 --> Total execution time: 0.2784
DEBUG - 2011-07-14 10:28:02 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:02 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:02 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:02 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:02 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:02 --> Total execution time: 0.0988
DEBUG - 2011-07-14 10:28:02 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:02 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Router Class Initialized
ERROR - 2011-07-14 10:28:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:28:02 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:02 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:02 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:02 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:02 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:02 --> Total execution time: 0.0421
DEBUG - 2011-07-14 10:28:16 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:16 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:16 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:16 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:16 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:16 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:16 --> Total execution time: 0.3118
DEBUG - 2011-07-14 10:28:18 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:18 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:18 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:18 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:19 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:19 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:19 --> Total execution time: 0.1024
DEBUG - 2011-07-14 10:28:19 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:19 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:19 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:19 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:19 --> Router Class Initialized
ERROR - 2011-07-14 10:28:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:28:29 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:29 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:29 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:29 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:29 --> Total execution time: 0.2683
DEBUG - 2011-07-14 10:28:31 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:31 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:31 --> Router Class Initialized
ERROR - 2011-07-14 10:28:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:28:37 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:37 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:37 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:37 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:37 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:37 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:37 --> Total execution time: 0.2472
DEBUG - 2011-07-14 10:28:38 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:38 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:38 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:38 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:38 --> Router Class Initialized
ERROR - 2011-07-14 10:28:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:28:50 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:50 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Router Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Output Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Input Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:28:50 --> Language Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Loader Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Controller Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Model Class Initialized
DEBUG - 2011-07-14 10:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:28:50 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:28:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:28:51 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:28:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:28:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:28:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:28:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:28:51 --> Final output sent to browser
DEBUG - 2011-07-14 10:28:51 --> Total execution time: 0.3842
DEBUG - 2011-07-14 10:28:52 --> Config Class Initialized
DEBUG - 2011-07-14 10:28:52 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:28:52 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:28:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:28:52 --> URI Class Initialized
DEBUG - 2011-07-14 10:28:52 --> Router Class Initialized
ERROR - 2011-07-14 10:28:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:02 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:02 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:02 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:03 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:03 --> Total execution time: 0.8107
DEBUG - 2011-07-14 10:29:04 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:04 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:04 --> Router Class Initialized
ERROR - 2011-07-14 10:29:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:09 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:09 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:09 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:09 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:09 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:09 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:09 --> Total execution time: 0.3529
DEBUG - 2011-07-14 10:29:11 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:11 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:11 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:11 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:11 --> Router Class Initialized
ERROR - 2011-07-14 10:29:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:14 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:14 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:14 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:14 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:14 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:14 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:14 --> Total execution time: 0.0459
DEBUG - 2011-07-14 10:29:16 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:16 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:16 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:16 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:16 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:16 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:16 --> Total execution time: 0.3054
DEBUG - 2011-07-14 10:29:17 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:17 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:17 --> Router Class Initialized
ERROR - 2011-07-14 10:29:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:23 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:23 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:23 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:23 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:23 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:23 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:23 --> Total execution time: 0.8045
DEBUG - 2011-07-14 10:29:24 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:24 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:24 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:24 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:24 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:24 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:24 --> Total execution time: 0.0418
DEBUG - 2011-07-14 10:29:25 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:25 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:25 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:25 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:25 --> Router Class Initialized
ERROR - 2011-07-14 10:29:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:26 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:26 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:26 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:26 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:26 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:26 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:26 --> Total execution time: 0.0499
DEBUG - 2011-07-14 10:29:29 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:29 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:29 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:30 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:30 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:30 --> Total execution time: 0.3372
DEBUG - 2011-07-14 10:29:31 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:31 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:31 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:31 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:31 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:31 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:31 --> Total execution time: 0.0475
DEBUG - 2011-07-14 10:29:31 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:31 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:31 --> Router Class Initialized
ERROR - 2011-07-14 10:29:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:36 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:36 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:36 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:37 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:37 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:37 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:37 --> Total execution time: 0.2218
DEBUG - 2011-07-14 10:29:38 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:38 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:38 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:38 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:38 --> Router Class Initialized
ERROR - 2011-07-14 10:29:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:42 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:42 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:42 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:42 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:43 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:43 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:43 --> Total execution time: 0.2399
DEBUG - 2011-07-14 10:29:44 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:44 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:44 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:44 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:44 --> Router Class Initialized
ERROR - 2011-07-14 10:29:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:45 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:45 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:45 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:45 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:45 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:45 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:45 --> Total execution time: 0.0488
DEBUG - 2011-07-14 10:29:49 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:49 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Router Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Output Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Input Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:29:49 --> Language Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Loader Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Controller Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Model Class Initialized
DEBUG - 2011-07-14 10:29:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:29:49 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:29:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 10:29:49 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:29:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:29:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:29:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:29:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:29:49 --> Final output sent to browser
DEBUG - 2011-07-14 10:29:49 --> Total execution time: 0.0458
DEBUG - 2011-07-14 10:29:50 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:50 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:50 --> Router Class Initialized
ERROR - 2011-07-14 10:29:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:56 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:56 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:56 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:56 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:56 --> Router Class Initialized
ERROR - 2011-07-14 10:29:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:57 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:57 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Router Class Initialized
ERROR - 2011-07-14 10:29:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:57 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:57 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Router Class Initialized
ERROR - 2011-07-14 10:29:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:57 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:57 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Router Class Initialized
ERROR - 2011-07-14 10:29:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:57 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:57 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Router Class Initialized
ERROR - 2011-07-14 10:29:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:57 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:57 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:58 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Router Class Initialized
ERROR - 2011-07-14 10:29:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:58 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:58 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Router Class Initialized
ERROR - 2011-07-14 10:29:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:58 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:58 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Router Class Initialized
ERROR - 2011-07-14 10:29:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:58 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:58 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:58 --> Router Class Initialized
ERROR - 2011-07-14 10:29:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:59 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:59 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Router Class Initialized
ERROR - 2011-07-14 10:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:29:59 --> Config Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:29:59 --> URI Class Initialized
DEBUG - 2011-07-14 10:29:59 --> Router Class Initialized
ERROR - 2011-07-14 10:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:03 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:03 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:03 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:03 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:03 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:03 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:03 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:03 --> Total execution time: 0.3624
DEBUG - 2011-07-14 10:30:04 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:04 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:04 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:04 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:05 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:05 --> Total execution time: 0.7074
DEBUG - 2011-07-14 10:30:06 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:06 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:06 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:06 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:06 --> Router Class Initialized
ERROR - 2011-07-14 10:30:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:08 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:08 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:08 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:08 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:08 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:08 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:08 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:08 --> Total execution time: 0.0412
DEBUG - 2011-07-14 10:30:08 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:08 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:08 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:08 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:09 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:09 --> Total execution time: 0.6868
DEBUG - 2011-07-14 10:30:10 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:10 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:10 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:10 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:10 --> Router Class Initialized
ERROR - 2011-07-14 10:30:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:14 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:14 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:14 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:14 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:14 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:14 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:14 --> Total execution time: 0.0299
DEBUG - 2011-07-14 10:30:15 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:15 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:15 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:15 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:15 --> Total execution time: 0.6067
DEBUG - 2011-07-14 10:30:16 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:16 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:16 --> Router Class Initialized
ERROR - 2011-07-14 10:30:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:20 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:20 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:20 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:20 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:20 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:20 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:20 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:20 --> Total execution time: 0.0271
DEBUG - 2011-07-14 10:30:21 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:21 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:21 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:21 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:21 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:21 --> Total execution time: 0.5142
DEBUG - 2011-07-14 10:30:22 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:22 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:22 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:22 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:22 --> Router Class Initialized
ERROR - 2011-07-14 10:30:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:33 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:33 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:33 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:33 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:33 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:33 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:33 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:33 --> Total execution time: 0.0293
DEBUG - 2011-07-14 10:30:34 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:34 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:34 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:34 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:34 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:34 --> Total execution time: 0.5578
DEBUG - 2011-07-14 10:30:35 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:35 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:35 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:35 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:35 --> Router Class Initialized
ERROR - 2011-07-14 10:30:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:30:45 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:45 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:45 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Controller Class Initialized
ERROR - 2011-07-14 10:30:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:30:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:45 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:30:45 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:30:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:30:45 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:45 --> Total execution time: 0.0461
DEBUG - 2011-07-14 10:30:45 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:45 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Router Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Output Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Input Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:30:45 --> Language Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Loader Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Controller Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Model Class Initialized
DEBUG - 2011-07-14 10:30:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:30:45 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:30:46 --> Final output sent to browser
DEBUG - 2011-07-14 10:30:46 --> Total execution time: 0.5279
DEBUG - 2011-07-14 10:30:46 --> Config Class Initialized
DEBUG - 2011-07-14 10:30:46 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:30:46 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:30:46 --> URI Class Initialized
DEBUG - 2011-07-14 10:30:46 --> Router Class Initialized
ERROR - 2011-07-14 10:30:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 10:33:24 --> Config Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:33:24 --> URI Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Router Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Output Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Input Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:33:24 --> Language Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Loader Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Controller Class Initialized
ERROR - 2011-07-14 10:33:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 10:33:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 10:33:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:33:24 --> Model Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Model Class Initialized
DEBUG - 2011-07-14 10:33:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:33:25 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:33:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 10:33:25 --> Helper loaded: url_helper
DEBUG - 2011-07-14 10:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 10:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 10:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 10:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 10:33:25 --> Final output sent to browser
DEBUG - 2011-07-14 10:33:25 --> Total execution time: 0.0782
DEBUG - 2011-07-14 10:33:26 --> Config Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:33:26 --> URI Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Router Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Output Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Input Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 10:33:26 --> Language Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Loader Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Controller Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Model Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Model Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 10:33:26 --> Database Driver Class Initialized
DEBUG - 2011-07-14 10:33:26 --> Final output sent to browser
DEBUG - 2011-07-14 10:33:26 --> Total execution time: 0.5443
DEBUG - 2011-07-14 10:33:29 --> Config Class Initialized
DEBUG - 2011-07-14 10:33:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 10:33:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 10:33:29 --> URI Class Initialized
DEBUG - 2011-07-14 10:33:29 --> Router Class Initialized
ERROR - 2011-07-14 10:33:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 14:21:24 --> Config Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 14:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 14:21:24 --> URI Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Router Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Output Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Input Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 14:21:24 --> Language Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Loader Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Controller Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 14:21:24 --> Database Driver Class Initialized
DEBUG - 2011-07-14 14:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 14:21:25 --> Helper loaded: url_helper
DEBUG - 2011-07-14 14:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 14:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 14:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 14:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 14:21:25 --> Final output sent to browser
DEBUG - 2011-07-14 14:21:25 --> Total execution time: 0.5591
DEBUG - 2011-07-14 14:21:29 --> Config Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 14:21:29 --> URI Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Router Class Initialized
ERROR - 2011-07-14 14:21:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 14:21:29 --> Config Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 14:21:29 --> URI Class Initialized
DEBUG - 2011-07-14 14:21:29 --> Router Class Initialized
ERROR - 2011-07-14 14:21:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 14:21:30 --> Config Class Initialized
DEBUG - 2011-07-14 14:21:30 --> Hooks Class Initialized
DEBUG - 2011-07-14 14:21:30 --> Utf8 Class Initialized
DEBUG - 2011-07-14 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 14:21:30 --> URI Class Initialized
DEBUG - 2011-07-14 14:21:30 --> Router Class Initialized
ERROR - 2011-07-14 14:21:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 14:21:51 --> Config Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 14:21:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 14:21:51 --> URI Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Router Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Output Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Input Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 14:21:51 --> Language Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Loader Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Controller Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Model Class Initialized
DEBUG - 2011-07-14 14:21:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 14:21:51 --> Database Driver Class Initialized
DEBUG - 2011-07-14 14:21:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 14:21:51 --> Helper loaded: url_helper
DEBUG - 2011-07-14 14:21:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 14:21:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 14:21:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 14:21:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 14:21:51 --> Final output sent to browser
DEBUG - 2011-07-14 14:21:51 --> Total execution time: 0.2016
DEBUG - 2011-07-14 16:15:16 --> Config Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 16:15:16 --> URI Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Router Class Initialized
ERROR - 2011-07-14 16:15:16 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-14 16:15:16 --> Config Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Hooks Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Utf8 Class Initialized
DEBUG - 2011-07-14 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 16:15:16 --> URI Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Router Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Output Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Input Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 16:15:16 --> Language Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Loader Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Controller Class Initialized
ERROR - 2011-07-14 16:15:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 16:15:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 16:15:16 --> Model Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Model Class Initialized
DEBUG - 2011-07-14 16:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 16:15:16 --> Database Driver Class Initialized
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 16:15:16 --> Helper loaded: url_helper
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 16:15:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 16:15:16 --> Final output sent to browser
DEBUG - 2011-07-14 16:15:16 --> Total execution time: 0.3508
DEBUG - 2011-07-14 16:26:11 --> Config Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Hooks Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Utf8 Class Initialized
DEBUG - 2011-07-14 16:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 16:26:11 --> URI Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Router Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Output Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Input Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 16:26:11 --> Language Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Loader Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Controller Class Initialized
ERROR - 2011-07-14 16:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 16:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 16:26:11 --> Model Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Model Class Initialized
DEBUG - 2011-07-14 16:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 16:26:11 --> Database Driver Class Initialized
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 16:26:11 --> Helper loaded: url_helper
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 16:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 16:26:11 --> Final output sent to browser
DEBUG - 2011-07-14 16:26:11 --> Total execution time: 0.2914
DEBUG - 2011-07-14 16:26:15 --> Config Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 16:26:15 --> URI Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Router Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Output Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Input Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 16:26:15 --> Language Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Loader Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Controller Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Model Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Model Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 16:26:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 16:26:15 --> Final output sent to browser
DEBUG - 2011-07-14 16:26:15 --> Total execution time: 0.7077
DEBUG - 2011-07-14 17:11:21 --> Config Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:11:21 --> URI Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Router Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Output Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Input Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:11:21 --> Language Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Loader Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Controller Class Initialized
ERROR - 2011-07-14 17:11:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:11:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:11:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:11:21 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:11:21 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:11:21 --> Final output sent to browser
DEBUG - 2011-07-14 17:11:21 --> Total execution time: 0.3678
DEBUG - 2011-07-14 17:11:22 --> Config Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:11:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:11:22 --> URI Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Router Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Output Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Input Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:11:22 --> Language Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Loader Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Controller Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Model Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Model Class Initialized
DEBUG - 2011-07-14 17:11:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:11:22 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:11:23 --> Final output sent to browser
DEBUG - 2011-07-14 17:11:23 --> Total execution time: 0.5848
DEBUG - 2011-07-14 17:11:24 --> Config Class Initialized
DEBUG - 2011-07-14 17:11:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:11:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:11:24 --> URI Class Initialized
DEBUG - 2011-07-14 17:11:24 --> Router Class Initialized
ERROR - 2011-07-14 17:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:37:17 --> Config Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:37:17 --> URI Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Router Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Output Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Input Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:37:17 --> Language Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Loader Class Initialized
DEBUG - 2011-07-14 17:37:17 --> Controller Class Initialized
DEBUG - 2011-07-14 17:37:18 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:18 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:18 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:37:18 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:37:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 17:37:19 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:37:19 --> Final output sent to browser
DEBUG - 2011-07-14 17:37:19 --> Total execution time: 1.7974
DEBUG - 2011-07-14 17:37:19 --> Config Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:37:19 --> URI Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Router Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Output Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Input Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:37:19 --> Language Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Loader Class Initialized
DEBUG - 2011-07-14 17:37:19 --> Controller Class Initialized
ERROR - 2011-07-14 17:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:37:20 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:20 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:37:20 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:37:20 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:37:20 --> Final output sent to browser
DEBUG - 2011-07-14 17:37:20 --> Total execution time: 0.5546
DEBUG - 2011-07-14 17:37:21 --> Config Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:37:21 --> URI Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Router Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Output Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Input Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:37:21 --> Language Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Loader Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Controller Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:37:21 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:37:23 --> Final output sent to browser
DEBUG - 2011-07-14 17:37:23 --> Total execution time: 1.2738
DEBUG - 2011-07-14 17:37:24 --> Config Class Initialized
DEBUG - 2011-07-14 17:37:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:37:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:37:24 --> URI Class Initialized
DEBUG - 2011-07-14 17:37:24 --> Router Class Initialized
ERROR - 2011-07-14 17:37:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:01 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:01 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:01 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:01 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:01 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:01 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:01 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:01 --> Total execution time: 0.0312
DEBUG - 2011-07-14 17:38:02 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:02 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:02 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:02 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:02 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:02 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:02 --> Total execution time: 0.0267
DEBUG - 2011-07-14 17:38:02 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:02 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:02 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:02 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:03 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:03 --> Total execution time: 0.6566
DEBUG - 2011-07-14 17:38:04 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:04 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:04 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:04 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:04 --> Router Class Initialized
ERROR - 2011-07-14 17:38:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:09 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:09 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:09 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:09 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:09 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:09 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:09 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:09 --> Total execution time: 0.0268
DEBUG - 2011-07-14 17:38:09 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:09 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:09 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:09 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:10 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:10 --> Total execution time: 0.6430
DEBUG - 2011-07-14 17:38:12 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:12 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:12 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:12 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:12 --> Router Class Initialized
ERROR - 2011-07-14 17:38:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:20 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:20 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:20 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:20 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:20 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:20 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:20 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:20 --> Total execution time: 0.0364
DEBUG - 2011-07-14 17:38:21 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:21 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:21 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:21 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:22 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:22 --> Total execution time: 0.9865
DEBUG - 2011-07-14 17:38:23 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:23 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:23 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:23 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:23 --> Router Class Initialized
ERROR - 2011-07-14 17:38:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:25 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:25 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:25 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:25 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:25 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:25 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:25 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:25 --> Total execution time: 0.0264
DEBUG - 2011-07-14 17:38:26 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:26 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:26 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:26 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:26 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:26 --> Total execution time: 0.5219
DEBUG - 2011-07-14 17:38:28 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:28 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:28 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:28 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:28 --> Router Class Initialized
ERROR - 2011-07-14 17:38:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:44 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:44 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:44 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:44 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:44 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:44 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:44 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:44 --> Total execution time: 0.0277
DEBUG - 2011-07-14 17:38:45 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:45 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:45 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:45 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:45 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:45 --> Total execution time: 0.6421
DEBUG - 2011-07-14 17:38:47 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:47 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:47 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:47 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:47 --> Router Class Initialized
ERROR - 2011-07-14 17:38:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:38:53 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:53 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:53 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Controller Class Initialized
ERROR - 2011-07-14 17:38:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:38:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:53 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:38:53 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:38:53 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:53 --> Total execution time: 0.0417
DEBUG - 2011-07-14 17:38:53 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:53 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Router Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Output Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Input Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:38:53 --> Language Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Loader Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Controller Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Model Class Initialized
DEBUG - 2011-07-14 17:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:38:53 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:38:54 --> Final output sent to browser
DEBUG - 2011-07-14 17:38:54 --> Total execution time: 0.5891
DEBUG - 2011-07-14 17:38:55 --> Config Class Initialized
DEBUG - 2011-07-14 17:38:55 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:38:55 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:38:55 --> URI Class Initialized
DEBUG - 2011-07-14 17:38:55 --> Router Class Initialized
ERROR - 2011-07-14 17:38:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:39:00 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:00 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:00 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Controller Class Initialized
ERROR - 2011-07-14 17:39:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:39:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:00 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:00 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:00 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:39:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:39:00 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:00 --> Total execution time: 0.0292
DEBUG - 2011-07-14 17:39:01 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:01 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:01 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Controller Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:01 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:02 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:02 --> Total execution time: 0.5143
DEBUG - 2011-07-14 17:39:03 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:03 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:03 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:03 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:03 --> Router Class Initialized
ERROR - 2011-07-14 17:39:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:39:07 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:07 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:07 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Controller Class Initialized
ERROR - 2011-07-14 17:39:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:39:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:07 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:07 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:07 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:39:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:39:07 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:07 --> Total execution time: 0.0302
DEBUG - 2011-07-14 17:39:07 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:07 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:07 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Controller Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:07 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:08 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:08 --> Total execution time: 0.5475
DEBUG - 2011-07-14 17:39:09 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:09 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:09 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:09 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:09 --> Router Class Initialized
ERROR - 2011-07-14 17:39:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:39:14 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:14 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:14 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Controller Class Initialized
ERROR - 2011-07-14 17:39:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:39:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:14 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:14 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:14 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:39:14 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:14 --> Total execution time: 0.0280
DEBUG - 2011-07-14 17:39:15 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:15 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:15 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Controller Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:15 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:15 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:15 --> Total execution time: 0.5366
DEBUG - 2011-07-14 17:39:17 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:17 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:17 --> Router Class Initialized
ERROR - 2011-07-14 17:39:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 17:39:25 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:25 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:25 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Controller Class Initialized
ERROR - 2011-07-14 17:39:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 17:39:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:25 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:25 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 17:39:25 --> Helper loaded: url_helper
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 17:39:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 17:39:25 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:25 --> Total execution time: 0.0321
DEBUG - 2011-07-14 17:39:26 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:26 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Router Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Output Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Input Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 17:39:26 --> Language Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Loader Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Controller Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Model Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 17:39:26 --> Database Driver Class Initialized
DEBUG - 2011-07-14 17:39:26 --> Final output sent to browser
DEBUG - 2011-07-14 17:39:26 --> Total execution time: 0.5039
DEBUG - 2011-07-14 17:39:28 --> Config Class Initialized
DEBUG - 2011-07-14 17:39:28 --> Hooks Class Initialized
DEBUG - 2011-07-14 17:39:28 --> Utf8 Class Initialized
DEBUG - 2011-07-14 17:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 17:39:28 --> URI Class Initialized
DEBUG - 2011-07-14 17:39:28 --> Router Class Initialized
ERROR - 2011-07-14 17:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 18:33:24 --> Config Class Initialized
DEBUG - 2011-07-14 18:33:24 --> Hooks Class Initialized
DEBUG - 2011-07-14 18:33:24 --> Utf8 Class Initialized
DEBUG - 2011-07-14 18:33:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 18:33:24 --> URI Class Initialized
DEBUG - 2011-07-14 18:33:24 --> Router Class Initialized
ERROR - 2011-07-14 18:33:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 18:36:30 --> Config Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Hooks Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Utf8 Class Initialized
DEBUG - 2011-07-14 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 18:36:30 --> URI Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Router Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Output Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Input Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 18:36:30 --> Language Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Loader Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Controller Class Initialized
ERROR - 2011-07-14 18:36:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 18:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 18:36:30 --> Model Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Model Class Initialized
DEBUG - 2011-07-14 18:36:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 18:36:30 --> Database Driver Class Initialized
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 18:36:30 --> Helper loaded: url_helper
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 18:36:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 18:36:30 --> Final output sent to browser
DEBUG - 2011-07-14 18:36:30 --> Total execution time: 0.3933
DEBUG - 2011-07-14 20:06:28 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:28 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Router Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Output Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Input Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:06:28 --> Language Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Loader Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Controller Class Initialized
ERROR - 2011-07-14 20:06:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:06:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:28 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:06:28 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:28 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:06:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:06:28 --> Final output sent to browser
DEBUG - 2011-07-14 20:06:28 --> Total execution time: 0.4999
DEBUG - 2011-07-14 20:06:29 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:29 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Router Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Output Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Input Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:06:29 --> Language Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Loader Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Controller Class Initialized
ERROR - 2011-07-14 20:06:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:06:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:06:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:06:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:06:29 --> Final output sent to browser
DEBUG - 2011-07-14 20:06:29 --> Total execution time: 0.0438
DEBUG - 2011-07-14 20:06:29 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:29 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Router Class Initialized
ERROR - 2011-07-14 20:06:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:06:29 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:29 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Router Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Output Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Input Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:06:29 --> Language Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Loader Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Controller Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:06:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:06:30 --> Final output sent to browser
DEBUG - 2011-07-14 20:06:30 --> Total execution time: 0.5954
DEBUG - 2011-07-14 20:06:31 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:31 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:31 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:31 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:31 --> Router Class Initialized
ERROR - 2011-07-14 20:06:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:06:50 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:50 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Router Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Output Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Input Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:06:50 --> Language Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Loader Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Controller Class Initialized
ERROR - 2011-07-14 20:06:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:06:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:50 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:06:50 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:06:50 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:06:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:06:50 --> Final output sent to browser
DEBUG - 2011-07-14 20:06:50 --> Total execution time: 0.0447
DEBUG - 2011-07-14 20:06:51 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:51 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Router Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Output Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Input Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:06:51 --> Language Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Loader Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Controller Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Model Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:06:51 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:06:51 --> Final output sent to browser
DEBUG - 2011-07-14 20:06:51 --> Total execution time: 0.5114
DEBUG - 2011-07-14 20:06:52 --> Config Class Initialized
DEBUG - 2011-07-14 20:06:52 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:06:52 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:06:52 --> URI Class Initialized
DEBUG - 2011-07-14 20:06:52 --> Router Class Initialized
ERROR - 2011-07-14 20:06:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:07:00 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:00 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:00 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Controller Class Initialized
ERROR - 2011-07-14 20:07:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:07:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:00 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:00 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:00 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:07:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:07:00 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:00 --> Total execution time: 0.0291
DEBUG - 2011-07-14 20:07:01 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:01 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:01 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Controller Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:01 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:01 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:01 --> Total execution time: 0.5556
DEBUG - 2011-07-14 20:07:02 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:02 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:02 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:02 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:02 --> Router Class Initialized
ERROR - 2011-07-14 20:07:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:07:13 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:13 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:13 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Controller Class Initialized
ERROR - 2011-07-14 20:07:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:07:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:13 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:13 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:13 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:07:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:07:13 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:13 --> Total execution time: 0.0340
DEBUG - 2011-07-14 20:07:13 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:13 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:13 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Controller Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:13 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:14 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:14 --> Total execution time: 0.5484
DEBUG - 2011-07-14 20:07:15 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:15 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:15 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:15 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:15 --> Router Class Initialized
ERROR - 2011-07-14 20:07:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:07:29 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:29 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:29 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Controller Class Initialized
ERROR - 2011-07-14 20:07:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:07:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:29 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:07:29 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:29 --> Total execution time: 0.0271
DEBUG - 2011-07-14 20:07:29 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:29 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:29 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Controller Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:29 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:30 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:30 --> Total execution time: 0.5742
DEBUG - 2011-07-14 20:07:30 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:30 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:30 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:30 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:30 --> Router Class Initialized
ERROR - 2011-07-14 20:07:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 20:07:38 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:38 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:38 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Controller Class Initialized
ERROR - 2011-07-14 20:07:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 20:07:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:38 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:38 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 20:07:38 --> Helper loaded: url_helper
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 20:07:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 20:07:38 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:38 --> Total execution time: 0.0380
DEBUG - 2011-07-14 20:07:38 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:38 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Router Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Output Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Input Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 20:07:38 --> Language Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Loader Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Controller Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Model Class Initialized
DEBUG - 2011-07-14 20:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 20:07:38 --> Database Driver Class Initialized
DEBUG - 2011-07-14 20:07:39 --> Final output sent to browser
DEBUG - 2011-07-14 20:07:39 --> Total execution time: 0.5517
DEBUG - 2011-07-14 20:07:40 --> Config Class Initialized
DEBUG - 2011-07-14 20:07:40 --> Hooks Class Initialized
DEBUG - 2011-07-14 20:07:40 --> Utf8 Class Initialized
DEBUG - 2011-07-14 20:07:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 20:07:40 --> URI Class Initialized
DEBUG - 2011-07-14 20:07:40 --> Router Class Initialized
ERROR - 2011-07-14 20:07:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-14 22:18:17 --> Config Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Hooks Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Utf8 Class Initialized
DEBUG - 2011-07-14 22:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 22:18:17 --> URI Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Router Class Initialized
DEBUG - 2011-07-14 22:18:17 --> No URI present. Default controller set.
DEBUG - 2011-07-14 22:18:17 --> Output Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Input Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 22:18:17 --> Language Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Loader Class Initialized
DEBUG - 2011-07-14 22:18:17 --> Controller Class Initialized
DEBUG - 2011-07-14 22:18:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-14 22:18:17 --> Helper loaded: url_helper
DEBUG - 2011-07-14 22:18:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 22:18:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 22:18:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 22:18:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 22:18:17 --> Final output sent to browser
DEBUG - 2011-07-14 22:18:17 --> Total execution time: 0.3421
DEBUG - 2011-07-14 22:24:20 --> Config Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Hooks Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Utf8 Class Initialized
DEBUG - 2011-07-14 22:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 22:24:20 --> URI Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Router Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Output Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Input Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 22:24:20 --> Language Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Loader Class Initialized
DEBUG - 2011-07-14 22:24:20 --> Controller Class Initialized
DEBUG - 2011-07-14 22:24:21 --> Model Class Initialized
DEBUG - 2011-07-14 22:24:21 --> Model Class Initialized
DEBUG - 2011-07-14 22:24:21 --> Model Class Initialized
DEBUG - 2011-07-14 22:24:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 22:24:22 --> Database Driver Class Initialized
DEBUG - 2011-07-14 22:24:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 22:24:23 --> Helper loaded: url_helper
DEBUG - 2011-07-14 22:24:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 22:24:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 22:24:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 22:24:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 22:24:23 --> Final output sent to browser
DEBUG - 2011-07-14 22:24:23 --> Total execution time: 2.9853
DEBUG - 2011-07-14 22:26:06 --> Config Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Hooks Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Utf8 Class Initialized
DEBUG - 2011-07-14 22:26:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 22:26:06 --> URI Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Router Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Output Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Input Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 22:26:06 --> Language Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Loader Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Controller Class Initialized
ERROR - 2011-07-14 22:26:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 22:26:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 22:26:06 --> Model Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Model Class Initialized
DEBUG - 2011-07-14 22:26:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 22:26:06 --> Database Driver Class Initialized
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 22:26:06 --> Helper loaded: url_helper
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 22:26:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 22:26:06 --> Final output sent to browser
DEBUG - 2011-07-14 22:26:06 --> Total execution time: 0.1210
DEBUG - 2011-07-14 23:50:36 --> Config Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Hooks Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Utf8 Class Initialized
DEBUG - 2011-07-14 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 23:50:36 --> URI Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Router Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Output Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Input Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 23:50:36 --> Language Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Loader Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Controller Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Model Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Model Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Model Class Initialized
DEBUG - 2011-07-14 23:50:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 23:50:36 --> Database Driver Class Initialized
DEBUG - 2011-07-14 23:50:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-14 23:50:37 --> Helper loaded: url_helper
DEBUG - 2011-07-14 23:50:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 23:50:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 23:50:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 23:50:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 23:50:37 --> Final output sent to browser
DEBUG - 2011-07-14 23:50:37 --> Total execution time: 0.8727
DEBUG - 2011-07-14 23:50:38 --> Config Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Hooks Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Utf8 Class Initialized
DEBUG - 2011-07-14 23:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-14 23:50:38 --> URI Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Router Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Output Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Input Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-14 23:50:38 --> Language Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Loader Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Controller Class Initialized
ERROR - 2011-07-14 23:50:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-14 23:50:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-14 23:50:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 23:50:38 --> Model Class Initialized
DEBUG - 2011-07-14 23:50:38 --> Model Class Initialized
DEBUG - 2011-07-14 23:50:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-14 23:50:39 --> Database Driver Class Initialized
DEBUG - 2011-07-14 23:50:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-14 23:50:39 --> Helper loaded: url_helper
DEBUG - 2011-07-14 23:50:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-14 23:50:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-14 23:50:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-14 23:50:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-14 23:50:39 --> Final output sent to browser
DEBUG - 2011-07-14 23:50:39 --> Total execution time: 0.1193

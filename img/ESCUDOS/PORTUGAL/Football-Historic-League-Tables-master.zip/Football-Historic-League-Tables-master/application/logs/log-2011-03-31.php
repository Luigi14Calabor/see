<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-03-31 00:16:54 --> Config Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 00:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 00:16:54 --> URI Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Router Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Output Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Input Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 00:16:54 --> Language Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Loader Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Controller Class Initialized
ERROR - 2011-03-31 00:16:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 00:16:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:16:54 --> Model Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Model Class Initialized
DEBUG - 2011-03-31 00:16:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 00:16:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:16:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 00:16:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 00:16:54 --> Final output sent to browser
DEBUG - 2011-03-31 00:16:54 --> Total execution time: 0.3643
DEBUG - 2011-03-31 00:25:54 --> Config Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 00:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 00:25:54 --> URI Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Router Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Output Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Input Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 00:25:54 --> Language Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Loader Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Controller Class Initialized
ERROR - 2011-03-31 00:25:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 00:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:25:54 --> Model Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Model Class Initialized
DEBUG - 2011-03-31 00:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 00:25:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:25:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 00:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 00:25:54 --> Final output sent to browser
DEBUG - 2011-03-31 00:25:54 --> Total execution time: 0.2269
DEBUG - 2011-03-31 00:33:07 --> Config Class Initialized
DEBUG - 2011-03-31 00:33:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 00:33:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 00:33:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 00:33:07 --> URI Class Initialized
DEBUG - 2011-03-31 00:33:07 --> Router Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Output Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Input Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 00:33:08 --> Language Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Loader Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Controller Class Initialized
ERROR - 2011-03-31 00:33:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 00:33:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:33:08 --> Model Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Model Class Initialized
DEBUG - 2011-03-31 00:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 00:33:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:33:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 00:33:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 00:33:08 --> Final output sent to browser
DEBUG - 2011-03-31 00:33:08 --> Total execution time: 0.2334
DEBUG - 2011-03-31 00:57:55 --> Config Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 00:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 00:57:55 --> URI Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Router Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Output Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Input Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 00:57:55 --> Language Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Loader Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Controller Class Initialized
ERROR - 2011-03-31 00:57:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 00:57:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:57:55 --> Model Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Model Class Initialized
DEBUG - 2011-03-31 00:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 00:57:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 00:57:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 00:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 00:57:55 --> Final output sent to browser
DEBUG - 2011-03-31 00:57:55 --> Total execution time: 0.2981
DEBUG - 2011-03-31 01:06:49 --> Config Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:06:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:06:49 --> URI Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Router Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Output Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Input Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:06:49 --> Language Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Loader Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Controller Class Initialized
ERROR - 2011-03-31 01:06:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:06:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:06:49 --> Model Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Model Class Initialized
DEBUG - 2011-03-31 01:06:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:06:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:06:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:06:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:06:49 --> Final output sent to browser
DEBUG - 2011-03-31 01:06:49 --> Total execution time: 0.1762
DEBUG - 2011-03-31 01:08:02 --> Config Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:08:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:08:02 --> URI Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Router Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Output Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Input Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:08:02 --> Language Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Loader Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Controller Class Initialized
ERROR - 2011-03-31 01:08:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:08:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:08:02 --> Model Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Model Class Initialized
DEBUG - 2011-03-31 01:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:08:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:08:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:08:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:08:02 --> Final output sent to browser
DEBUG - 2011-03-31 01:08:02 --> Total execution time: 0.0511
DEBUG - 2011-03-31 01:10:52 --> Config Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:10:52 --> URI Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Router Class Initialized
DEBUG - 2011-03-31 01:10:52 --> No URI present. Default controller set.
DEBUG - 2011-03-31 01:10:52 --> Output Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Input Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:10:52 --> Language Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Loader Class Initialized
DEBUG - 2011-03-31 01:10:52 --> Controller Class Initialized
DEBUG - 2011-03-31 01:10:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 01:10:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:10:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:10:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:10:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:10:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:10:52 --> Final output sent to browser
DEBUG - 2011-03-31 01:10:52 --> Total execution time: 0.0881
DEBUG - 2011-03-31 01:11:00 --> Config Class Initialized
DEBUG - 2011-03-31 01:11:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:11:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:11:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:11:00 --> URI Class Initialized
DEBUG - 2011-03-31 01:11:00 --> Router Class Initialized
ERROR - 2011-03-31 01:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 01:11:02 --> Config Class Initialized
DEBUG - 2011-03-31 01:11:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:11:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:11:02 --> URI Class Initialized
DEBUG - 2011-03-31 01:11:02 --> Router Class Initialized
ERROR - 2011-03-31 01:11:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 01:20:35 --> Config Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:20:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:20:35 --> URI Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Router Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Output Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Input Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:20:35 --> Language Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Loader Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Controller Class Initialized
ERROR - 2011-03-31 01:20:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:20:35 --> Model Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Model Class Initialized
DEBUG - 2011-03-31 01:20:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:20:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:20:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:20:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:20:35 --> Final output sent to browser
DEBUG - 2011-03-31 01:20:35 --> Total execution time: 0.0759
DEBUG - 2011-03-31 01:32:47 --> Config Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:32:47 --> URI Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Router Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Output Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Input Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:32:47 --> Language Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Loader Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Controller Class Initialized
ERROR - 2011-03-31 01:32:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:32:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:32:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:32:47 --> Model Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Model Class Initialized
DEBUG - 2011-03-31 01:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:32:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:32:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:32:47 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:32:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:32:48 --> Final output sent to browser
DEBUG - 2011-03-31 01:32:48 --> Total execution time: 0.1761
DEBUG - 2011-03-31 01:37:54 --> Config Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:37:54 --> URI Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Router Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Output Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Input Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:37:54 --> Language Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Loader Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Controller Class Initialized
ERROR - 2011-03-31 01:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:37:54 --> Model Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Model Class Initialized
DEBUG - 2011-03-31 01:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:37:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:37:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:37:54 --> Final output sent to browser
DEBUG - 2011-03-31 01:37:54 --> Total execution time: 0.1058
DEBUG - 2011-03-31 01:38:07 --> Config Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:38:07 --> URI Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Router Class Initialized
DEBUG - 2011-03-31 01:38:07 --> No URI present. Default controller set.
DEBUG - 2011-03-31 01:38:07 --> Output Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Input Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:38:07 --> Language Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Loader Class Initialized
DEBUG - 2011-03-31 01:38:07 --> Controller Class Initialized
DEBUG - 2011-03-31 01:38:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 01:38:07 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:38:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:38:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:38:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:38:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:38:07 --> Final output sent to browser
DEBUG - 2011-03-31 01:38:07 --> Total execution time: 0.0633
DEBUG - 2011-03-31 01:54:51 --> Config Class Initialized
DEBUG - 2011-03-31 01:54:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:54:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:54:51 --> URI Class Initialized
DEBUG - 2011-03-31 01:54:51 --> Router Class Initialized
ERROR - 2011-03-31 01:54:51 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 01:59:12 --> Config Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 01:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 01:59:12 --> URI Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Router Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Output Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Input Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 01:59:12 --> Language Class Initialized
DEBUG - 2011-03-31 01:59:12 --> Loader Class Initialized
DEBUG - 2011-03-31 01:59:13 --> Controller Class Initialized
ERROR - 2011-03-31 01:59:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 01:59:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:59:13 --> Model Class Initialized
DEBUG - 2011-03-31 01:59:13 --> Model Class Initialized
DEBUG - 2011-03-31 01:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 01:59:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 01:59:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 01:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 01:59:13 --> Final output sent to browser
DEBUG - 2011-03-31 01:59:13 --> Total execution time: 0.3324
DEBUG - 2011-03-31 02:00:00 --> Config Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:00:00 --> URI Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Router Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Output Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Input Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:00:00 --> Language Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Loader Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Controller Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Model Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Model Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Model Class Initialized
DEBUG - 2011-03-31 02:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:00:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:00:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 02:00:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:00:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:00:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:00:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:00:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:00:01 --> Final output sent to browser
DEBUG - 2011-03-31 02:00:01 --> Total execution time: 0.6848
DEBUG - 2011-03-31 02:00:32 --> Config Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:00:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:00:32 --> URI Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Router Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Output Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Input Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:00:32 --> Language Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Loader Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Controller Class Initialized
ERROR - 2011-03-31 02:00:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:00:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:00:32 --> Model Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Model Class Initialized
DEBUG - 2011-03-31 02:00:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:00:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:00:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:00:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:00:32 --> Final output sent to browser
DEBUG - 2011-03-31 02:00:32 --> Total execution time: 0.0288
DEBUG - 2011-03-31 02:08:14 --> Config Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:08:14 --> URI Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Router Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Output Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Input Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:08:14 --> Language Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Loader Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Controller Class Initialized
ERROR - 2011-03-31 02:08:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:08:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:08:14 --> Model Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Model Class Initialized
DEBUG - 2011-03-31 02:08:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:08:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:08:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:08:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:08:14 --> Final output sent to browser
DEBUG - 2011-03-31 02:08:14 --> Total execution time: 0.0515
DEBUG - 2011-03-31 02:12:49 --> Config Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:12:49 --> URI Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Router Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Output Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Input Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:12:49 --> Language Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Loader Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Controller Class Initialized
ERROR - 2011-03-31 02:12:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:12:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:12:49 --> Model Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Model Class Initialized
DEBUG - 2011-03-31 02:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:12:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:12:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:12:49 --> Final output sent to browser
DEBUG - 2011-03-31 02:12:49 --> Total execution time: 0.0295
DEBUG - 2011-03-31 02:25:44 --> Config Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:25:44 --> URI Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Router Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Output Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Input Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:25:44 --> Language Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Loader Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Controller Class Initialized
ERROR - 2011-03-31 02:25:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:25:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:25:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:25:44 --> Model Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Model Class Initialized
DEBUG - 2011-03-31 02:25:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:25:44 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:25:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:25:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:25:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:25:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:25:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:25:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:25:45 --> Final output sent to browser
DEBUG - 2011-03-31 02:25:45 --> Total execution time: 1.5591
DEBUG - 2011-03-31 02:39:24 --> Config Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:39:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:39:24 --> URI Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Router Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Output Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Input Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:39:24 --> Language Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Loader Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Controller Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Model Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Model Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Model Class Initialized
DEBUG - 2011-03-31 02:39:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:39:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:39:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 02:39:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:39:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:39:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:39:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:39:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:39:25 --> Final output sent to browser
DEBUG - 2011-03-31 02:39:25 --> Total execution time: 1.1897
DEBUG - 2011-03-31 02:39:33 --> Config Class Initialized
DEBUG - 2011-03-31 02:39:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:39:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:39:33 --> URI Class Initialized
DEBUG - 2011-03-31 02:39:33 --> Router Class Initialized
ERROR - 2011-03-31 02:39:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 02:39:34 --> Config Class Initialized
DEBUG - 2011-03-31 02:39:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:39:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:39:34 --> URI Class Initialized
DEBUG - 2011-03-31 02:39:34 --> Router Class Initialized
ERROR - 2011-03-31 02:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 02:40:14 --> Config Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:40:14 --> URI Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Router Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Output Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Input Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:40:14 --> Language Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Loader Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Controller Class Initialized
ERROR - 2011-03-31 02:40:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:40:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:40:14 --> Model Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Model Class Initialized
DEBUG - 2011-03-31 02:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:40:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:40:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:40:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:40:14 --> Final output sent to browser
DEBUG - 2011-03-31 02:40:14 --> Total execution time: 0.1015
DEBUG - 2011-03-31 02:40:15 --> Config Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:40:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:40:15 --> URI Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Router Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Output Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Input Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:40:15 --> Language Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Loader Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Controller Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Model Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Model Class Initialized
DEBUG - 2011-03-31 02:40:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:40:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:40:16 --> Final output sent to browser
DEBUG - 2011-03-31 02:40:16 --> Total execution time: 0.6906
DEBUG - 2011-03-31 02:42:49 --> Config Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:42:49 --> URI Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Router Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Output Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Input Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:42:49 --> Language Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Loader Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Controller Class Initialized
ERROR - 2011-03-31 02:42:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:42:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:42:49 --> Model Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Model Class Initialized
DEBUG - 2011-03-31 02:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:42:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:42:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:42:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:42:49 --> Final output sent to browser
DEBUG - 2011-03-31 02:42:49 --> Total execution time: 0.0327
DEBUG - 2011-03-31 02:42:52 --> Config Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:42:52 --> URI Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Router Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Output Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Input Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:42:52 --> Language Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Loader Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Controller Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Model Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Model Class Initialized
DEBUG - 2011-03-31 02:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:42:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:42:53 --> Final output sent to browser
DEBUG - 2011-03-31 02:42:53 --> Total execution time: 0.7972
DEBUG - 2011-03-31 02:57:09 --> Config Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 02:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 02:57:09 --> URI Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Router Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Output Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Input Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 02:57:09 --> Language Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Loader Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Controller Class Initialized
ERROR - 2011-03-31 02:57:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 02:57:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:57:09 --> Model Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Model Class Initialized
DEBUG - 2011-03-31 02:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 02:57:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 02:57:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 02:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 02:57:09 --> Final output sent to browser
DEBUG - 2011-03-31 02:57:09 --> Total execution time: 0.4068
DEBUG - 2011-03-31 03:14:36 --> Config Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:14:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:14:36 --> URI Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Router Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Output Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Input Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:14:36 --> Language Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Loader Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Controller Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:14:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:14:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:14:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:14:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:14:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:14:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:14:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:14:36 --> Final output sent to browser
DEBUG - 2011-03-31 03:14:36 --> Total execution time: 0.6811
DEBUG - 2011-03-31 03:14:43 --> Config Class Initialized
DEBUG - 2011-03-31 03:14:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:14:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:14:43 --> URI Class Initialized
DEBUG - 2011-03-31 03:14:43 --> Router Class Initialized
ERROR - 2011-03-31 03:14:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 03:14:45 --> Config Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:14:45 --> URI Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Router Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Output Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Input Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:14:45 --> Language Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Loader Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Controller Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:14:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:14:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:14:45 --> Final output sent to browser
DEBUG - 2011-03-31 03:14:45 --> Total execution time: 0.0458
DEBUG - 2011-03-31 03:14:47 --> Config Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:14:47 --> URI Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Router Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Output Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Input Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:14:47 --> Language Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Loader Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Controller Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Model Class Initialized
DEBUG - 2011-03-31 03:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:14:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:14:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:14:47 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:14:47 --> Final output sent to browser
DEBUG - 2011-03-31 03:14:47 --> Total execution time: 0.0580
DEBUG - 2011-03-31 03:14:48 --> Config Class Initialized
DEBUG - 2011-03-31 03:14:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:14:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:14:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:14:48 --> URI Class Initialized
DEBUG - 2011-03-31 03:14:48 --> Router Class Initialized
ERROR - 2011-03-31 03:14:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 03:24:01 --> Config Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:24:01 --> URI Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Router Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Output Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Input Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:24:01 --> Language Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Loader Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Controller Class Initialized
ERROR - 2011-03-31 03:24:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 03:24:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 03:24:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:24:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 03:24:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:24:01 --> Final output sent to browser
DEBUG - 2011-03-31 03:24:01 --> Total execution time: 0.1077
DEBUG - 2011-03-31 03:51:57 --> Config Class Initialized
DEBUG - 2011-03-31 03:51:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:51:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:51:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:51:57 --> URI Class Initialized
DEBUG - 2011-03-31 03:51:57 --> Router Class Initialized
DEBUG - 2011-03-31 03:51:57 --> No URI present. Default controller set.
DEBUG - 2011-03-31 03:51:58 --> Output Class Initialized
DEBUG - 2011-03-31 03:51:58 --> Input Class Initialized
DEBUG - 2011-03-31 03:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:51:58 --> Language Class Initialized
DEBUG - 2011-03-31 03:51:58 --> Loader Class Initialized
DEBUG - 2011-03-31 03:51:58 --> Controller Class Initialized
DEBUG - 2011-03-31 03:51:58 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 03:51:58 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:51:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:51:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:51:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:51:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:51:58 --> Final output sent to browser
DEBUG - 2011-03-31 03:51:58 --> Total execution time: 0.4154
DEBUG - 2011-03-31 03:52:24 --> Config Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:52:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:52:24 --> URI Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Router Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Output Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Input Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:52:24 --> Language Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Loader Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Controller Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:52:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:52:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:52:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:52:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:52:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:52:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:52:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:52:25 --> Final output sent to browser
DEBUG - 2011-03-31 03:52:25 --> Total execution time: 0.4018
DEBUG - 2011-03-31 03:52:58 --> Config Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:52:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:52:58 --> URI Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Router Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Output Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Input Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:52:58 --> Language Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Loader Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Controller Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Model Class Initialized
DEBUG - 2011-03-31 03:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:52:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:52:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:52:59 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:52:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:52:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:52:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:52:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:52:59 --> Final output sent to browser
DEBUG - 2011-03-31 03:52:59 --> Total execution time: 0.3884
DEBUG - 2011-03-31 03:53:01 --> Config Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:53:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:53:01 --> URI Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Router Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Output Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Input Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:53:01 --> Language Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Loader Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Controller Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:53:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:53:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:53:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:53:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:53:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:53:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:53:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:53:01 --> Final output sent to browser
DEBUG - 2011-03-31 03:53:01 --> Total execution time: 0.0559
DEBUG - 2011-03-31 03:53:12 --> Config Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:53:12 --> URI Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Router Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Output Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Input Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:53:12 --> Language Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Loader Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Controller Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:53:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:53:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:53:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:53:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:53:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:53:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:53:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:53:13 --> Final output sent to browser
DEBUG - 2011-03-31 03:53:13 --> Total execution time: 0.2517
DEBUG - 2011-03-31 03:53:15 --> Config Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:53:15 --> URI Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Router Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Output Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Input Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:53:15 --> Language Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Loader Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Controller Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:53:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:53:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:53:15 --> Final output sent to browser
DEBUG - 2011-03-31 03:53:15 --> Total execution time: 0.0475
DEBUG - 2011-03-31 03:53:15 --> Config Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:53:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:53:15 --> URI Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Router Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Output Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Input Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:53:15 --> Language Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Loader Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Controller Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Model Class Initialized
DEBUG - 2011-03-31 03:53:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:53:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:53:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:53:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:53:15 --> Final output sent to browser
DEBUG - 2011-03-31 03:53:15 --> Total execution time: 0.0457
DEBUG - 2011-03-31 03:55:21 --> Config Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:55:21 --> URI Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Router Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Output Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Input Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:55:21 --> Language Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Loader Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Controller Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:55:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:55:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:55:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:55:22 --> Final output sent to browser
DEBUG - 2011-03-31 03:55:22 --> Total execution time: 0.3027
DEBUG - 2011-03-31 03:55:25 --> Config Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:55:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:55:25 --> URI Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Router Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Output Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Input Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:55:25 --> Language Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Loader Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Controller Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:55:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:55:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:55:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:55:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:55:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:55:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:55:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:55:25 --> Final output sent to browser
DEBUG - 2011-03-31 03:55:25 --> Total execution time: 0.0494
DEBUG - 2011-03-31 03:55:28 --> Config Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:55:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:55:28 --> URI Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Router Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Output Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Input Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:55:28 --> Language Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Loader Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Controller Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:55:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:55:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:55:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:55:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:55:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:55:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:55:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:55:28 --> Final output sent to browser
DEBUG - 2011-03-31 03:55:28 --> Total execution time: 0.0537
DEBUG - 2011-03-31 03:55:42 --> Config Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:55:42 --> URI Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Router Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Output Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Input Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:55:42 --> Language Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Loader Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Controller Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:55:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:55:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:55:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:55:42 --> Final output sent to browser
DEBUG - 2011-03-31 03:55:42 --> Total execution time: 0.1967
DEBUG - 2011-03-31 03:55:49 --> Config Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:55:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:55:49 --> URI Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Router Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Output Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Input Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:55:49 --> Language Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Loader Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Controller Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Model Class Initialized
DEBUG - 2011-03-31 03:55:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:55:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:55:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:55:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:55:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:55:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:55:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:55:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:55:49 --> Final output sent to browser
DEBUG - 2011-03-31 03:55:49 --> Total execution time: 0.0493
DEBUG - 2011-03-31 03:56:11 --> Config Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:56:11 --> URI Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Router Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Output Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Input Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:56:11 --> Language Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Loader Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Controller Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:56:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:56:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:56:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:56:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:56:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:56:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:56:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:56:11 --> Final output sent to browser
DEBUG - 2011-03-31 03:56:11 --> Total execution time: 0.1856
DEBUG - 2011-03-31 03:56:16 --> Config Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:56:16 --> URI Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Router Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Output Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Input Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:56:16 --> Language Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Loader Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Controller Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:56:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:56:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:56:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:56:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:56:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:56:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:56:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:56:16 --> Final output sent to browser
DEBUG - 2011-03-31 03:56:16 --> Total execution time: 0.0450
DEBUG - 2011-03-31 03:56:27 --> Config Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:56:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:56:27 --> URI Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Router Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Output Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Input Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:56:27 --> Language Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Loader Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Controller Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:56:27 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:56:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:56:27 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:56:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:56:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:56:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:56:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:56:27 --> Final output sent to browser
DEBUG - 2011-03-31 03:56:27 --> Total execution time: 0.2808
DEBUG - 2011-03-31 03:56:33 --> Config Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:56:33 --> URI Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Router Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Output Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Input Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:56:33 --> Language Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Loader Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Controller Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:56:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:56:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:56:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:56:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:56:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:56:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:56:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:56:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:56:33 --> Final output sent to browser
DEBUG - 2011-03-31 03:56:33 --> Total execution time: 0.0667
DEBUG - 2011-03-31 03:58:27 --> Config Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:58:27 --> URI Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Router Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Output Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Input Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:58:27 --> Language Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Loader Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Controller Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:58:27 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:58:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:58:27 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:58:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:58:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:58:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:58:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:58:27 --> Final output sent to browser
DEBUG - 2011-03-31 03:58:27 --> Total execution time: 0.3063
DEBUG - 2011-03-31 03:58:33 --> Config Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:58:33 --> URI Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Router Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Output Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Input Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:58:33 --> Language Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Loader Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Controller Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:58:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:58:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:58:33 --> Final output sent to browser
DEBUG - 2011-03-31 03:58:33 --> Total execution time: 0.0818
DEBUG - 2011-03-31 03:58:33 --> Config Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:58:33 --> URI Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Router Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Output Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Input Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:58:33 --> Language Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Loader Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Controller Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:58:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:58:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:58:34 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:58:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:58:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:58:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:58:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:58:34 --> Final output sent to browser
DEBUG - 2011-03-31 03:58:34 --> Total execution time: 0.0924
DEBUG - 2011-03-31 03:58:57 --> Config Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:58:57 --> URI Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Router Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Output Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Input Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:58:57 --> Language Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Loader Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Controller Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Model Class Initialized
DEBUG - 2011-03-31 03:58:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:58:57 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:58:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:58:57 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:58:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:58:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:58:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:58:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:58:57 --> Final output sent to browser
DEBUG - 2011-03-31 03:58:57 --> Total execution time: 0.3150
DEBUG - 2011-03-31 03:59:00 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:00 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:00 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:00 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:00 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:00 --> Total execution time: 0.0820
DEBUG - 2011-03-31 03:59:00 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:01 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:01 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:01 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:01 --> Total execution time: 0.1437
DEBUG - 2011-03-31 03:59:13 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:13 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:13 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:14 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:14 --> Total execution time: 0.4351
DEBUG - 2011-03-31 03:59:17 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:17 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:17 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:17 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:17 --> Total execution time: 0.0428
DEBUG - 2011-03-31 03:59:25 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:25 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:25 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:26 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:26 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:26 --> Total execution time: 0.1921
DEBUG - 2011-03-31 03:59:28 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:28 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:28 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:28 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:28 --> Total execution time: 0.0444
DEBUG - 2011-03-31 03:59:34 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:34 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:34 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:34 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:34 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:34 --> Total execution time: 0.2400
DEBUG - 2011-03-31 03:59:38 --> Config Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 03:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 03:59:38 --> URI Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Router Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Output Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Input Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 03:59:38 --> Language Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Loader Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Controller Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Model Class Initialized
DEBUG - 2011-03-31 03:59:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 03:59:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 03:59:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 03:59:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 03:59:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 03:59:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 03:59:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 03:59:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 03:59:38 --> Final output sent to browser
DEBUG - 2011-03-31 03:59:38 --> Total execution time: 0.0463
DEBUG - 2011-03-31 04:00:13 --> Config Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:00:13 --> URI Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Router Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Output Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Input Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:00:13 --> Language Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Loader Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Controller Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 04:00:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 04:00:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 04:00:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:00:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:00:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:00:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:00:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:00:16 --> Final output sent to browser
DEBUG - 2011-03-31 04:00:16 --> Total execution time: 2.6607
DEBUG - 2011-03-31 04:00:21 --> Config Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:00:21 --> URI Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Router Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Output Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Input Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:00:21 --> Language Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Loader Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Controller Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Model Class Initialized
DEBUG - 2011-03-31 04:00:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 04:00:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 04:00:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 04:00:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:00:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:00:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:00:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:00:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:00:21 --> Final output sent to browser
DEBUG - 2011-03-31 04:00:21 --> Total execution time: 0.0642
DEBUG - 2011-03-31 04:08:27 --> Config Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:08:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:08:27 --> URI Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Router Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Output Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Input Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:08:27 --> Language Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Loader Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Controller Class Initialized
ERROR - 2011-03-31 04:08:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 04:08:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 04:08:27 --> Model Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Model Class Initialized
DEBUG - 2011-03-31 04:08:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 04:08:27 --> Database Driver Class Initialized
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 04:08:27 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:08:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:08:27 --> Final output sent to browser
DEBUG - 2011-03-31 04:08:27 --> Total execution time: 0.2409
DEBUG - 2011-03-31 04:09:25 --> Config Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:09:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:09:25 --> URI Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Router Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Output Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Input Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:09:25 --> Language Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Loader Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Controller Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Model Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Model Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Model Class Initialized
DEBUG - 2011-03-31 04:09:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 04:09:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 04:09:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 04:09:26 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:09:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:09:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:09:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:09:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:09:26 --> Final output sent to browser
DEBUG - 2011-03-31 04:09:26 --> Total execution time: 0.1376
DEBUG - 2011-03-31 04:32:41 --> Config Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:32:41 --> URI Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Router Class Initialized
DEBUG - 2011-03-31 04:32:41 --> No URI present. Default controller set.
DEBUG - 2011-03-31 04:32:41 --> Output Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Input Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:32:41 --> Language Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Loader Class Initialized
DEBUG - 2011-03-31 04:32:41 --> Controller Class Initialized
DEBUG - 2011-03-31 04:32:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 04:32:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:32:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:32:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:32:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:32:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:32:42 --> Final output sent to browser
DEBUG - 2011-03-31 04:32:42 --> Total execution time: 0.2305
DEBUG - 2011-03-31 04:32:48 --> Config Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:32:48 --> URI Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Router Class Initialized
DEBUG - 2011-03-31 04:32:48 --> No URI present. Default controller set.
DEBUG - 2011-03-31 04:32:48 --> Output Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Input Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:32:48 --> Language Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Loader Class Initialized
DEBUG - 2011-03-31 04:32:48 --> Controller Class Initialized
DEBUG - 2011-03-31 04:32:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 04:32:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:32:48 --> Final output sent to browser
DEBUG - 2011-03-31 04:32:48 --> Total execution time: 0.0133
DEBUG - 2011-03-31 04:40:47 --> Config Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 04:40:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 04:40:47 --> URI Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Router Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Output Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Input Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 04:40:47 --> Language Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Loader Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Controller Class Initialized
ERROR - 2011-03-31 04:40:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 04:40:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 04:40:47 --> Model Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Model Class Initialized
DEBUG - 2011-03-31 04:40:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 04:40:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 04:40:47 --> Helper loaded: url_helper
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 04:40:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 04:40:47 --> Final output sent to browser
DEBUG - 2011-03-31 04:40:47 --> Total execution time: 0.3091
DEBUG - 2011-03-31 05:12:20 --> Config Class Initialized
DEBUG - 2011-03-31 05:12:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:12:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:12:20 --> URI Class Initialized
DEBUG - 2011-03-31 05:12:20 --> Router Class Initialized
ERROR - 2011-03-31 05:12:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 05:38:16 --> Config Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:38:16 --> URI Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Router Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Output Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Input Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:38:16 --> Language Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Loader Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Controller Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:38:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:38:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:38:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:38:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:38:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:38:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:38:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:38:17 --> Final output sent to browser
DEBUG - 2011-03-31 05:38:17 --> Total execution time: 1.0093
DEBUG - 2011-03-31 05:38:20 --> Config Class Initialized
DEBUG - 2011-03-31 05:38:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:38:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:38:20 --> URI Class Initialized
DEBUG - 2011-03-31 05:38:20 --> Router Class Initialized
ERROR - 2011-03-31 05:38:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:38:41 --> Config Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:38:41 --> URI Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Router Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Output Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Input Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:38:41 --> Language Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Loader Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Controller Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Model Class Initialized
DEBUG - 2011-03-31 05:38:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:38:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:38:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:38:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:38:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:38:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:38:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:38:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:38:41 --> Final output sent to browser
DEBUG - 2011-03-31 05:38:41 --> Total execution time: 0.5397
DEBUG - 2011-03-31 05:38:43 --> Config Class Initialized
DEBUG - 2011-03-31 05:38:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:38:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:38:43 --> URI Class Initialized
DEBUG - 2011-03-31 05:38:43 --> Router Class Initialized
ERROR - 2011-03-31 05:38:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:39:16 --> Config Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:39:16 --> URI Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Router Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Output Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Input Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:39:16 --> Language Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Loader Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Controller Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:39:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:39:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:39:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:39:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:39:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:39:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:39:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:39:16 --> Final output sent to browser
DEBUG - 2011-03-31 05:39:16 --> Total execution time: 0.1616
DEBUG - 2011-03-31 05:39:18 --> Config Class Initialized
DEBUG - 2011-03-31 05:39:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:39:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:39:18 --> URI Class Initialized
DEBUG - 2011-03-31 05:39:18 --> Router Class Initialized
ERROR - 2011-03-31 05:39:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:39:19 --> Config Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:39:19 --> URI Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Router Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Output Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Input Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:39:19 --> Language Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Loader Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Controller Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:39:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:39:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:39:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:39:19 --> Final output sent to browser
DEBUG - 2011-03-31 05:39:19 --> Total execution time: 0.0448
DEBUG - 2011-03-31 05:39:31 --> Config Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:39:31 --> URI Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Router Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Output Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Input Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:39:31 --> Language Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Loader Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Controller Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:39:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:39:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:39:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:39:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:39:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:39:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:39:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:39:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:39:32 --> Final output sent to browser
DEBUG - 2011-03-31 05:39:32 --> Total execution time: 0.4320
DEBUG - 2011-03-31 05:39:34 --> Config Class Initialized
DEBUG - 2011-03-31 05:39:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:39:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:39:34 --> URI Class Initialized
DEBUG - 2011-03-31 05:39:34 --> Router Class Initialized
ERROR - 2011-03-31 05:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:49:32 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:32 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:32 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Controller Class Initialized
ERROR - 2011-03-31 05:49:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:49:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:32 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:49:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:49:32 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:32 --> Total execution time: 0.1239
DEBUG - 2011-03-31 05:49:33 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:33 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:33 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Controller Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:33 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:33 --> Total execution time: 0.5734
DEBUG - 2011-03-31 05:49:35 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:35 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:35 --> Router Class Initialized
ERROR - 2011-03-31 05:49:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:49:42 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:42 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:42 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Controller Class Initialized
ERROR - 2011-03-31 05:49:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:49:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:42 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:49:42 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:42 --> Total execution time: 0.0449
DEBUG - 2011-03-31 05:49:43 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:43 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:43 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Controller Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:43 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:43 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Controller Class Initialized
ERROR - 2011-03-31 05:49:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:49:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:43 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:49:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:49:43 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:43 --> Total execution time: 0.0274
DEBUG - 2011-03-31 05:49:44 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:44 --> Total execution time: 0.5514
DEBUG - 2011-03-31 05:49:50 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:50 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:50 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Controller Class Initialized
ERROR - 2011-03-31 05:49:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:49:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:49:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:50 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:51 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:49:51 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:51 --> Total execution time: 0.2252
DEBUG - 2011-03-31 05:49:51 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:51 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:51 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Controller Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Config Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:49:51 --> URI Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Router Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Output Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Input Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:49:51 --> Language Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Loader Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Controller Class Initialized
ERROR - 2011-03-31 05:49:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:49:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:49:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:51 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Model Class Initialized
DEBUG - 2011-03-31 05:49:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:49:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:49:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:49:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:49:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:49:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:49:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:49:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:49:52 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:52 --> Total execution time: 0.0433
DEBUG - 2011-03-31 05:49:52 --> Final output sent to browser
DEBUG - 2011-03-31 05:49:52 --> Total execution time: 0.9511
DEBUG - 2011-03-31 05:50:00 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:00 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:00 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:00 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:00 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:00 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:00 --> Total execution time: 0.0560
DEBUG - 2011-03-31 05:50:01 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:01 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:01 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Controller Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:02 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:02 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:02 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:02 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:02 --> Total execution time: 0.2397
DEBUG - 2011-03-31 05:50:02 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:02 --> Total execution time: 0.8820
DEBUG - 2011-03-31 05:50:03 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:03 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:03 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:03 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:03 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:03 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:03 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:03 --> Total execution time: 0.0402
DEBUG - 2011-03-31 05:50:17 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:17 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:17 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:17 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:17 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:17 --> Total execution time: 0.0314
DEBUG - 2011-03-31 05:50:18 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:18 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:18 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Controller Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:18 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:18 --> Total execution time: 0.5656
DEBUG - 2011-03-31 05:50:21 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:21 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:21 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:21 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:21 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:21 --> Total execution time: 0.0325
DEBUG - 2011-03-31 05:50:42 --> Config Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:50:42 --> URI Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Router Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Output Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Input Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:50:42 --> Language Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Loader Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Controller Class Initialized
ERROR - 2011-03-31 05:50:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 05:50:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:42 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Model Class Initialized
DEBUG - 2011-03-31 05:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:50:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 05:50:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:50:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:50:42 --> Final output sent to browser
DEBUG - 2011-03-31 05:50:42 --> Total execution time: 0.0421
DEBUG - 2011-03-31 05:58:03 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:03 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:03 --> No URI present. Default controller set.
DEBUG - 2011-03-31 05:58:03 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:03 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:03 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 05:58:03 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:03 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:03 --> Total execution time: 0.0828
DEBUG - 2011-03-31 05:58:05 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:05 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Router Class Initialized
ERROR - 2011-03-31 05:58:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:58:05 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:05 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:05 --> Router Class Initialized
ERROR - 2011-03-31 05:58:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 05:58:08 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:08 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:08 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:09 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:09 --> Total execution time: 1.0189
DEBUG - 2011-03-31 05:58:30 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:30 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:30 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:30 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:30 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:30 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:30 --> Total execution time: 0.3139
DEBUG - 2011-03-31 05:58:31 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:31 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:31 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:31 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:31 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:31 --> Total execution time: 0.0721
DEBUG - 2011-03-31 05:58:38 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:38 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:38 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:39 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:39 --> Total execution time: 0.2670
DEBUG - 2011-03-31 05:58:40 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:40 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:40 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:40 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:40 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:40 --> Total execution time: 0.0578
DEBUG - 2011-03-31 05:58:40 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:40 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:40 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:40 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:40 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:40 --> Total execution time: 0.0442
DEBUG - 2011-03-31 05:58:45 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:45 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:45 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:45 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:45 --> Total execution time: 0.2496
DEBUG - 2011-03-31 05:58:45 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:45 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:45 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:45 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:45 --> Total execution time: 0.0588
DEBUG - 2011-03-31 05:58:46 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:46 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:46 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:46 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:46 --> Total execution time: 0.0491
DEBUG - 2011-03-31 05:58:52 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:52 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:52 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:53 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:53 --> Total execution time: 0.8212
DEBUG - 2011-03-31 05:58:55 --> Config Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 05:58:55 --> URI Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Router Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Output Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Input Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 05:58:55 --> Language Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Loader Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Controller Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Model Class Initialized
DEBUG - 2011-03-31 05:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 05:58:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 05:58:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 05:58:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 05:58:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 05:58:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 05:58:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 05:58:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 05:58:55 --> Final output sent to browser
DEBUG - 2011-03-31 05:58:55 --> Total execution time: 0.1361
DEBUG - 2011-03-31 06:10:28 --> Config Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:10:28 --> URI Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Router Class Initialized
DEBUG - 2011-03-31 06:10:28 --> No URI present. Default controller set.
DEBUG - 2011-03-31 06:10:28 --> Output Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Input Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:10:28 --> Language Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Loader Class Initialized
DEBUG - 2011-03-31 06:10:28 --> Controller Class Initialized
DEBUG - 2011-03-31 06:10:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 06:10:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:10:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:10:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:10:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:10:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:10:28 --> Final output sent to browser
DEBUG - 2011-03-31 06:10:28 --> Total execution time: 0.2898
DEBUG - 2011-03-31 06:10:29 --> Config Class Initialized
DEBUG - 2011-03-31 06:10:29 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:10:29 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:10:29 --> URI Class Initialized
DEBUG - 2011-03-31 06:10:29 --> Router Class Initialized
ERROR - 2011-03-31 06:10:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:10:32 --> Config Class Initialized
DEBUG - 2011-03-31 06:10:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:10:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:10:32 --> URI Class Initialized
DEBUG - 2011-03-31 06:10:32 --> Router Class Initialized
ERROR - 2011-03-31 06:10:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:43:14 --> Config Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:43:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:43:14 --> URI Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Router Class Initialized
DEBUG - 2011-03-31 06:43:14 --> No URI present. Default controller set.
DEBUG - 2011-03-31 06:43:14 --> Output Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Input Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:43:14 --> Language Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Loader Class Initialized
DEBUG - 2011-03-31 06:43:14 --> Controller Class Initialized
DEBUG - 2011-03-31 06:43:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 06:43:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:43:15 --> Final output sent to browser
DEBUG - 2011-03-31 06:43:15 --> Total execution time: 0.9039
DEBUG - 2011-03-31 06:51:09 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:09 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Router Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Output Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Input Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:51:09 --> Language Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Loader Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Controller Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:51:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:51:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 06:51:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:51:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:51:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:51:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:51:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:51:10 --> Final output sent to browser
DEBUG - 2011-03-31 06:51:10 --> Total execution time: 1.0404
DEBUG - 2011-03-31 06:51:14 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:14 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:14 --> Router Class Initialized
ERROR - 2011-03-31 06:51:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:51:15 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:15 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:15 --> Router Class Initialized
ERROR - 2011-03-31 06:51:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:51:16 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:16 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:16 --> Router Class Initialized
ERROR - 2011-03-31 06:51:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:51:30 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:30 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Router Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Output Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Input Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:51:30 --> Language Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Loader Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Controller Class Initialized
ERROR - 2011-03-31 06:51:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 06:51:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:51:30 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:51:30 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:51:30 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:51:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:51:30 --> Final output sent to browser
DEBUG - 2011-03-31 06:51:30 --> Total execution time: 0.7641
DEBUG - 2011-03-31 06:51:33 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:33 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Router Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Output Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Input Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:51:33 --> Language Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Loader Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Controller Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:51:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:51:34 --> Final output sent to browser
DEBUG - 2011-03-31 06:51:34 --> Total execution time: 0.9193
DEBUG - 2011-03-31 06:51:36 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:36 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:36 --> Router Class Initialized
ERROR - 2011-03-31 06:51:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:51:46 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:46 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Router Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Output Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Input Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:51:46 --> Language Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Loader Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Controller Class Initialized
ERROR - 2011-03-31 06:51:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 06:51:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:51:46 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:51:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:51:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:51:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:51:46 --> Final output sent to browser
DEBUG - 2011-03-31 06:51:46 --> Total execution time: 0.0336
DEBUG - 2011-03-31 06:51:47 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:47 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Router Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Output Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Input Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:51:47 --> Language Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Loader Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Controller Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Model Class Initialized
DEBUG - 2011-03-31 06:51:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:51:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:51:48 --> Final output sent to browser
DEBUG - 2011-03-31 06:51:48 --> Total execution time: 0.6389
DEBUG - 2011-03-31 06:51:50 --> Config Class Initialized
DEBUG - 2011-03-31 06:51:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:51:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:51:50 --> URI Class Initialized
DEBUG - 2011-03-31 06:51:50 --> Router Class Initialized
ERROR - 2011-03-31 06:51:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:52:04 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:04 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Router Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Output Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Input Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:52:04 --> Language Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Loader Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Controller Class Initialized
ERROR - 2011-03-31 06:52:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 06:52:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:04 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:52:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:52:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:52:04 --> Final output sent to browser
DEBUG - 2011-03-31 06:52:04 --> Total execution time: 0.0390
DEBUG - 2011-03-31 06:52:05 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:05 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Router Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Output Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Input Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:52:05 --> Language Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Loader Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Controller Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:52:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:52:05 --> Final output sent to browser
DEBUG - 2011-03-31 06:52:05 --> Total execution time: 0.6681
DEBUG - 2011-03-31 06:52:08 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:08 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:08 --> Router Class Initialized
ERROR - 2011-03-31 06:52:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 06:52:43 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:43 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Router Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Output Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Input Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:52:43 --> Language Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Loader Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Controller Class Initialized
ERROR - 2011-03-31 06:52:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 06:52:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:43 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:52:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:52:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:52:43 --> Final output sent to browser
DEBUG - 2011-03-31 06:52:43 --> Total execution time: 0.0290
DEBUG - 2011-03-31 06:52:45 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:45 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Router Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Output Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Input Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:52:45 --> Language Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Loader Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Controller Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:45 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:52:45 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Router Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Output Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Input Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 06:52:45 --> Language Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Loader Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Controller Class Initialized
ERROR - 2011-03-31 06:52:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 06:52:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:45 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Model Class Initialized
DEBUG - 2011-03-31 06:52:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 06:52:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 06:52:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 06:52:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 06:52:45 --> Final output sent to browser
DEBUG - 2011-03-31 06:52:45 --> Total execution time: 0.0364
DEBUG - 2011-03-31 06:52:45 --> Final output sent to browser
DEBUG - 2011-03-31 06:52:45 --> Total execution time: 0.5054
DEBUG - 2011-03-31 06:52:48 --> Config Class Initialized
DEBUG - 2011-03-31 06:52:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 06:52:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 06:52:48 --> URI Class Initialized
DEBUG - 2011-03-31 06:52:48 --> Router Class Initialized
ERROR - 2011-03-31 06:52:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 07:27:42 --> Config Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:27:42 --> URI Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Router Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Output Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Input Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:27:42 --> Language Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Loader Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Controller Class Initialized
ERROR - 2011-03-31 07:27:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:27:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:27:42 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:27:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:27:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:27:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:27:42 --> Final output sent to browser
DEBUG - 2011-03-31 07:27:42 --> Total execution time: 0.3829
DEBUG - 2011-03-31 07:27:43 --> Config Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:27:43 --> URI Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Router Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Output Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Input Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:27:43 --> Language Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Loader Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Controller Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:27:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Config Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:27:43 --> URI Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Router Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Output Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Input Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:27:43 --> Language Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Loader Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Controller Class Initialized
ERROR - 2011-03-31 07:27:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:27:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 07:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:27:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:27:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:27:43 --> Final output sent to browser
DEBUG - 2011-03-31 07:27:43 --> Total execution time: 0.0308
DEBUG - 2011-03-31 07:27:44 --> Final output sent to browser
DEBUG - 2011-03-31 07:27:44 --> Total execution time: 0.6713
DEBUG - 2011-03-31 07:27:45 --> Config Class Initialized
DEBUG - 2011-03-31 07:27:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:27:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:27:45 --> URI Class Initialized
DEBUG - 2011-03-31 07:27:45 --> Router Class Initialized
ERROR - 2011-03-31 07:27:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 07:28:26 --> Config Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:28:26 --> URI Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Router Class Initialized
DEBUG - 2011-03-31 07:28:26 --> No URI present. Default controller set.
DEBUG - 2011-03-31 07:28:26 --> Output Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Input Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:28:26 --> Language Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Loader Class Initialized
DEBUG - 2011-03-31 07:28:26 --> Controller Class Initialized
DEBUG - 2011-03-31 07:28:26 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 07:28:26 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:28:26 --> Final output sent to browser
DEBUG - 2011-03-31 07:28:26 --> Total execution time: 0.0724
DEBUG - 2011-03-31 07:28:37 --> Config Class Initialized
DEBUG - 2011-03-31 07:28:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:28:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:28:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:28:37 --> URI Class Initialized
DEBUG - 2011-03-31 07:28:37 --> Router Class Initialized
ERROR - 2011-03-31 07:28:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 07:28:41 --> Config Class Initialized
DEBUG - 2011-03-31 07:28:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:28:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:28:41 --> URI Class Initialized
DEBUG - 2011-03-31 07:28:41 --> Router Class Initialized
ERROR - 2011-03-31 07:28:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 07:29:34 --> Config Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:29:34 --> URI Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Router Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Output Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Input Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:29:34 --> Language Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Loader Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Controller Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:29:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:29:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:29:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:29:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:29:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:29:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:29:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:29:35 --> Final output sent to browser
DEBUG - 2011-03-31 07:29:35 --> Total execution time: 0.3368
DEBUG - 2011-03-31 07:29:36 --> Config Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:29:36 --> URI Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Router Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Output Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Input Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:29:36 --> Language Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Loader Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Controller Class Initialized
ERROR - 2011-03-31 07:29:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:29:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:29:36 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:29:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:29:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:29:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:29:36 --> Final output sent to browser
DEBUG - 2011-03-31 07:29:36 --> Total execution time: 0.0441
DEBUG - 2011-03-31 07:29:38 --> Config Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:29:39 --> URI Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Router Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Output Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Input Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:29:39 --> Language Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Loader Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Controller Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:29:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:29:39 --> Final output sent to browser
DEBUG - 2011-03-31 07:29:39 --> Total execution time: 0.6929
DEBUG - 2011-03-31 07:29:50 --> Config Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:29:50 --> URI Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Router Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Output Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Input Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:29:50 --> Language Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Loader Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Controller Class Initialized
ERROR - 2011-03-31 07:29:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:29:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:29:50 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:29:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:29:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:29:50 --> Final output sent to browser
DEBUG - 2011-03-31 07:29:50 --> Total execution time: 0.0277
DEBUG - 2011-03-31 07:29:52 --> Config Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:29:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:29:52 --> URI Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Router Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Output Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Input Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:29:52 --> Language Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Loader Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Controller Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Model Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:29:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:29:52 --> Final output sent to browser
DEBUG - 2011-03-31 07:29:52 --> Total execution time: 0.4985
DEBUG - 2011-03-31 07:30:02 --> Config Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:30:02 --> URI Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Router Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Output Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Input Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:30:02 --> Language Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Loader Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Controller Class Initialized
ERROR - 2011-03-31 07:30:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:30:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:30:02 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:30:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:30:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:30:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:30:02 --> Final output sent to browser
DEBUG - 2011-03-31 07:30:02 --> Total execution time: 0.3847
DEBUG - 2011-03-31 07:30:03 --> Config Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:30:03 --> URI Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Router Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Output Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Input Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:30:03 --> Language Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Loader Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Controller Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:30:03 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:30:04 --> Final output sent to browser
DEBUG - 2011-03-31 07:30:04 --> Total execution time: 1.0658
DEBUG - 2011-03-31 07:30:18 --> Config Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:30:18 --> URI Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Router Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Output Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Input Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:30:18 --> Language Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Loader Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Controller Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:30:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:30:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:30:18 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:30:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:30:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:30:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:30:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:30:18 --> Final output sent to browser
DEBUG - 2011-03-31 07:30:18 --> Total execution time: 0.1911
DEBUG - 2011-03-31 07:30:33 --> Config Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:30:33 --> URI Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Router Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Output Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Input Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:30:33 --> Language Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Loader Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Controller Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:30:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:30:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:30:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:30:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:30:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:30:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:30:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:30:33 --> Final output sent to browser
DEBUG - 2011-03-31 07:30:33 --> Total execution time: 0.6772
DEBUG - 2011-03-31 07:30:46 --> Config Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:30:46 --> URI Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Router Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Output Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Input Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:30:46 --> Language Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Loader Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Controller Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Model Class Initialized
DEBUG - 2011-03-31 07:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:30:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:30:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:30:46 --> Final output sent to browser
DEBUG - 2011-03-31 07:30:46 --> Total execution time: 0.0692
DEBUG - 2011-03-31 07:31:07 --> Config Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:31:07 --> URI Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Router Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Output Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Input Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:31:07 --> Language Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Loader Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Controller Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:31:07 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:31:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:31:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:31:08 --> Final output sent to browser
DEBUG - 2011-03-31 07:31:08 --> Total execution time: 0.3817
DEBUG - 2011-03-31 07:31:23 --> Config Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:31:23 --> URI Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Router Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Output Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Input Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:31:23 --> Language Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Loader Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Controller Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:31:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:31:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:31:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:31:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:31:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:31:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:31:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:31:23 --> Final output sent to browser
DEBUG - 2011-03-31 07:31:23 --> Total execution time: 0.0713
DEBUG - 2011-03-31 07:31:38 --> Config Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:31:38 --> URI Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Router Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Output Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Input Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:31:38 --> Language Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Loader Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Controller Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:31:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:31:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:31:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:31:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:31:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:31:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:31:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:31:39 --> Final output sent to browser
DEBUG - 2011-03-31 07:31:39 --> Total execution time: 0.9227
DEBUG - 2011-03-31 07:31:51 --> Config Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:31:51 --> URI Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Router Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Output Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Input Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:31:51 --> Language Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Loader Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Controller Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Model Class Initialized
DEBUG - 2011-03-31 07:31:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:31:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:31:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:31:51 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:31:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:31:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:31:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:31:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:31:51 --> Final output sent to browser
DEBUG - 2011-03-31 07:31:51 --> Total execution time: 0.2093
DEBUG - 2011-03-31 07:32:01 --> Config Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:32:01 --> URI Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Router Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Output Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Input Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:32:01 --> Language Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Loader Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Controller Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:32:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:32:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:32:01 --> Final output sent to browser
DEBUG - 2011-03-31 07:32:01 --> Total execution time: 0.2376
DEBUG - 2011-03-31 07:32:19 --> Config Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:32:19 --> URI Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Router Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Output Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Input Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:32:19 --> Language Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Loader Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Controller Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:32:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:32:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:32:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:32:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:32:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:32:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:32:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:32:20 --> Final output sent to browser
DEBUG - 2011-03-31 07:32:20 --> Total execution time: 0.4491
DEBUG - 2011-03-31 07:32:49 --> Config Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:32:49 --> URI Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Router Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Output Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Input Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:32:49 --> Language Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Loader Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Controller Class Initialized
ERROR - 2011-03-31 07:32:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 07:32:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:32:49 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:32:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 07:32:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:32:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:32:49 --> Final output sent to browser
DEBUG - 2011-03-31 07:32:49 --> Total execution time: 0.2889
DEBUG - 2011-03-31 07:32:50 --> Config Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:32:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:32:50 --> URI Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Router Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Output Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Input Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:32:50 --> Language Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Loader Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Controller Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Model Class Initialized
DEBUG - 2011-03-31 07:32:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:32:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:32:51 --> Final output sent to browser
DEBUG - 2011-03-31 07:32:51 --> Total execution time: 0.5559
DEBUG - 2011-03-31 07:33:33 --> Config Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:33:33 --> URI Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Router Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Output Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Input Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:33:33 --> Language Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Loader Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Controller Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Model Class Initialized
DEBUG - 2011-03-31 07:33:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:33:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:33:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:33:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:33:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:33:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:33:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:33:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:33:33 --> Final output sent to browser
DEBUG - 2011-03-31 07:33:33 --> Total execution time: 0.0482
DEBUG - 2011-03-31 07:39:36 --> Config Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:39:36 --> URI Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Router Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Output Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Input Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:39:36 --> Language Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Loader Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Controller Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Model Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Model Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Model Class Initialized
DEBUG - 2011-03-31 07:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:39:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:39:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:39:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:39:36 --> Final output sent to browser
DEBUG - 2011-03-31 07:39:36 --> Total execution time: 0.2210
DEBUG - 2011-03-31 07:39:45 --> Config Class Initialized
DEBUG - 2011-03-31 07:39:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:39:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:39:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:39:45 --> URI Class Initialized
DEBUG - 2011-03-31 07:39:45 --> Router Class Initialized
ERROR - 2011-03-31 07:39:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 07:58:48 --> Config Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:58:48 --> URI Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Router Class Initialized
DEBUG - 2011-03-31 07:58:48 --> No URI present. Default controller set.
DEBUG - 2011-03-31 07:58:48 --> Output Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Input Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:58:48 --> Language Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Loader Class Initialized
DEBUG - 2011-03-31 07:58:48 --> Controller Class Initialized
DEBUG - 2011-03-31 07:58:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 07:58:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:58:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:58:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:58:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:58:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:58:48 --> Final output sent to browser
DEBUG - 2011-03-31 07:58:48 --> Total execution time: 0.5184
DEBUG - 2011-03-31 07:58:59 --> Config Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:58:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:58:59 --> URI Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Router Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Output Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Input Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:58:59 --> Language Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Loader Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Controller Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Model Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Model Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Model Class Initialized
DEBUG - 2011-03-31 07:58:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:58:59 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:58:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:58:59 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:58:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:58:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:58:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:58:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:58:59 --> Final output sent to browser
DEBUG - 2011-03-31 07:58:59 --> Total execution time: 0.6037
DEBUG - 2011-03-31 07:59:16 --> Config Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:59:16 --> URI Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Router Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Output Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Input Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:59:16 --> Language Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Loader Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Controller Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:59:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:59:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:59:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:59:17 --> Final output sent to browser
DEBUG - 2011-03-31 07:59:17 --> Total execution time: 1.0725
DEBUG - 2011-03-31 07:59:39 --> Config Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 07:59:39 --> URI Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Router Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Output Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Input Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 07:59:39 --> Language Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Loader Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Controller Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Model Class Initialized
DEBUG - 2011-03-31 07:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 07:59:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 07:59:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 07:59:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 07:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 07:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 07:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 07:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 07:59:39 --> Final output sent to browser
DEBUG - 2011-03-31 07:59:39 --> Total execution time: 0.2966
DEBUG - 2011-03-31 08:01:27 --> Config Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:01:27 --> URI Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Router Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Output Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Input Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:01:27 --> Language Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Loader Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Controller Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Model Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Model Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Model Class Initialized
DEBUG - 2011-03-31 08:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:01:27 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:01:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:01:27 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:01:27 --> Final output sent to browser
DEBUG - 2011-03-31 08:01:27 --> Total execution time: 0.4552
DEBUG - 2011-03-31 08:10:53 --> Config Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:10:53 --> URI Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Router Class Initialized
ERROR - 2011-03-31 08:10:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 08:10:53 --> Config Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:10:53 --> URI Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Router Class Initialized
DEBUG - 2011-03-31 08:10:53 --> No URI present. Default controller set.
DEBUG - 2011-03-31 08:10:53 --> Output Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Input Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:10:53 --> Language Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Loader Class Initialized
DEBUG - 2011-03-31 08:10:53 --> Controller Class Initialized
DEBUG - 2011-03-31 08:10:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 08:10:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:10:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:10:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:10:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:10:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:10:53 --> Final output sent to browser
DEBUG - 2011-03-31 08:10:53 --> Total execution time: 0.3104
DEBUG - 2011-03-31 08:19:41 --> Config Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:19:41 --> URI Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Router Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Output Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Input Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:19:41 --> Language Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Loader Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Controller Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Model Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Model Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Model Class Initialized
DEBUG - 2011-03-31 08:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:19:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:19:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:19:41 --> Final output sent to browser
DEBUG - 2011-03-31 08:19:41 --> Total execution time: 0.8704
DEBUG - 2011-03-31 08:19:44 --> Config Class Initialized
DEBUG - 2011-03-31 08:19:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:19:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:19:44 --> URI Class Initialized
DEBUG - 2011-03-31 08:19:44 --> Router Class Initialized
ERROR - 2011-03-31 08:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:20:51 --> Config Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:20:51 --> URI Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Router Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Output Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Input Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:20:51 --> Language Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Loader Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Controller Class Initialized
ERROR - 2011-03-31 08:20:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 08:20:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 08:20:51 --> Model Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Model Class Initialized
DEBUG - 2011-03-31 08:20:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:20:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 08:20:51 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:20:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:20:51 --> Final output sent to browser
DEBUG - 2011-03-31 08:20:51 --> Total execution time: 0.1169
DEBUG - 2011-03-31 08:23:19 --> Config Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:23:19 --> URI Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Router Class Initialized
DEBUG - 2011-03-31 08:23:19 --> No URI present. Default controller set.
DEBUG - 2011-03-31 08:23:19 --> Output Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Input Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:23:19 --> Language Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Loader Class Initialized
DEBUG - 2011-03-31 08:23:19 --> Controller Class Initialized
DEBUG - 2011-03-31 08:23:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 08:23:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:23:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:23:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:23:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:23:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:23:19 --> Final output sent to browser
DEBUG - 2011-03-31 08:23:19 --> Total execution time: 0.0891
DEBUG - 2011-03-31 08:23:23 --> Config Class Initialized
DEBUG - 2011-03-31 08:23:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:23:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:23:23 --> URI Class Initialized
DEBUG - 2011-03-31 08:23:23 --> Router Class Initialized
ERROR - 2011-03-31 08:23:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:23:24 --> Config Class Initialized
DEBUG - 2011-03-31 08:23:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:23:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:23:24 --> URI Class Initialized
DEBUG - 2011-03-31 08:23:24 --> Router Class Initialized
ERROR - 2011-03-31 08:23:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:23:38 --> Config Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:23:38 --> URI Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Router Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Output Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Input Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:23:38 --> Language Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Loader Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Controller Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Model Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Model Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Model Class Initialized
DEBUG - 2011-03-31 08:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:23:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:23:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:23:38 --> Final output sent to browser
DEBUG - 2011-03-31 08:23:38 --> Total execution time: 0.1793
DEBUG - 2011-03-31 08:23:41 --> Config Class Initialized
DEBUG - 2011-03-31 08:23:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:23:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:23:41 --> URI Class Initialized
DEBUG - 2011-03-31 08:23:41 --> Router Class Initialized
ERROR - 2011-03-31 08:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:24:15 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:15 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Router Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Output Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Input Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:24:15 --> Language Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Loader Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Controller Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:24:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:24:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:24:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:24:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:24:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:24:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:24:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:24:16 --> Final output sent to browser
DEBUG - 2011-03-31 08:24:16 --> Total execution time: 1.6295
DEBUG - 2011-03-31 08:24:19 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:19 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Router Class Initialized
ERROR - 2011-03-31 08:24:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:24:19 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:19 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Router Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Output Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Input Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:24:19 --> Language Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Loader Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Controller Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:24:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:24:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:24:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:24:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:24:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:24:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:24:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:24:19 --> Final output sent to browser
DEBUG - 2011-03-31 08:24:19 --> Total execution time: 0.1581
DEBUG - 2011-03-31 08:24:28 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:28 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Router Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Output Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Input Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:24:28 --> Language Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Loader Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Controller Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:24:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:24:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:24:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:24:28 --> Final output sent to browser
DEBUG - 2011-03-31 08:24:28 --> Total execution time: 0.1199
DEBUG - 2011-03-31 08:24:31 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:31 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:31 --> Router Class Initialized
ERROR - 2011-03-31 08:24:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:24:48 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:48 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Router Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Output Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Input Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:24:48 --> Language Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Loader Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Controller Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:24:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:24:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:24:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:24:48 --> Final output sent to browser
DEBUG - 2011-03-31 08:24:48 --> Total execution time: 0.3169
DEBUG - 2011-03-31 08:24:55 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:55 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:55 --> Router Class Initialized
ERROR - 2011-03-31 08:24:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:24:56 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:56 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Router Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Output Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Input Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:24:56 --> Language Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Loader Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Controller Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Model Class Initialized
DEBUG - 2011-03-31 08:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:24:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:24:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:24:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:24:56 --> Final output sent to browser
DEBUG - 2011-03-31 08:24:56 --> Total execution time: 0.3609
DEBUG - 2011-03-31 08:24:59 --> Config Class Initialized
DEBUG - 2011-03-31 08:24:59 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:24:59 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:24:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:24:59 --> URI Class Initialized
DEBUG - 2011-03-31 08:24:59 --> Router Class Initialized
ERROR - 2011-03-31 08:24:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 08:25:13 --> Config Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:25:13 --> URI Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Router Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Output Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Input Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:25:13 --> Language Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Loader Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Controller Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Model Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Model Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Model Class Initialized
DEBUG - 2011-03-31 08:25:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:25:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:25:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:25:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:25:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:25:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:25:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:25:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:25:13 --> Final output sent to browser
DEBUG - 2011-03-31 08:25:13 --> Total execution time: 0.2793
DEBUG - 2011-03-31 08:33:25 --> Config Class Initialized
DEBUG - 2011-03-31 08:33:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:33:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:33:25 --> URI Class Initialized
DEBUG - 2011-03-31 08:33:25 --> Router Class Initialized
ERROR - 2011-03-31 08:33:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 08:55:03 --> Config Class Initialized
DEBUG - 2011-03-31 08:55:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:55:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:55:03 --> URI Class Initialized
DEBUG - 2011-03-31 08:55:03 --> Router Class Initialized
ERROR - 2011-03-31 08:55:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 08:55:04 --> Config Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:55:04 --> URI Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Router Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Output Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Input Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:55:04 --> Language Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Loader Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Controller Class Initialized
ERROR - 2011-03-31 08:55:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 08:55:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 08:55:04 --> Model Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Model Class Initialized
DEBUG - 2011-03-31 08:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:55:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 08:55:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:55:04 --> Final output sent to browser
DEBUG - 2011-03-31 08:55:04 --> Total execution time: 0.4188
DEBUG - 2011-03-31 08:55:35 --> Config Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:55:35 --> URI Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Router Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Output Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Input Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:55:35 --> Language Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Loader Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Controller Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Model Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Model Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Model Class Initialized
DEBUG - 2011-03-31 08:55:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 08:55:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 08:55:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 08:55:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:55:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:55:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:55:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:55:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:55:35 --> Final output sent to browser
DEBUG - 2011-03-31 08:55:35 --> Total execution time: 0.3767
DEBUG - 2011-03-31 08:57:44 --> Config Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 08:57:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 08:57:44 --> URI Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Router Class Initialized
DEBUG - 2011-03-31 08:57:44 --> No URI present. Default controller set.
DEBUG - 2011-03-31 08:57:44 --> Output Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Input Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 08:57:44 --> Language Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Loader Class Initialized
DEBUG - 2011-03-31 08:57:44 --> Controller Class Initialized
DEBUG - 2011-03-31 08:57:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 08:57:44 --> Helper loaded: url_helper
DEBUG - 2011-03-31 08:57:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 08:57:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 08:57:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 08:57:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 08:57:44 --> Final output sent to browser
DEBUG - 2011-03-31 08:57:44 --> Total execution time: 0.1066
DEBUG - 2011-03-31 09:08:05 --> Config Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:08:05 --> URI Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Router Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Output Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Input Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:08:05 --> Language Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Loader Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Controller Class Initialized
ERROR - 2011-03-31 09:08:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:08:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:08:05 --> Model Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Model Class Initialized
DEBUG - 2011-03-31 09:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:08:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:08:05 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:08:05 --> Final output sent to browser
DEBUG - 2011-03-31 09:08:05 --> Total execution time: 0.3387
DEBUG - 2011-03-31 09:36:54 --> Config Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:36:54 --> URI Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Router Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Output Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Input Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:36:54 --> Language Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Loader Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Controller Class Initialized
ERROR - 2011-03-31 09:36:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:36:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:36:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:36:54 --> Model Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Model Class Initialized
DEBUG - 2011-03-31 09:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:36:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:36:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:36:55 --> Final output sent to browser
DEBUG - 2011-03-31 09:36:55 --> Total execution time: 0.3342
DEBUG - 2011-03-31 09:36:56 --> Config Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:36:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:36:56 --> URI Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Router Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Output Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Input Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:36:56 --> Language Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Loader Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Controller Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Model Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Model Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:36:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:36:56 --> Final output sent to browser
DEBUG - 2011-03-31 09:36:56 --> Total execution time: 0.7074
DEBUG - 2011-03-31 09:36:57 --> Config Class Initialized
DEBUG - 2011-03-31 09:36:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:36:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:36:57 --> URI Class Initialized
DEBUG - 2011-03-31 09:36:57 --> Router Class Initialized
ERROR - 2011-03-31 09:36:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:37:12 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:12 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:12 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:12 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:12 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:12 --> Total execution time: 0.0288
DEBUG - 2011-03-31 09:37:13 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:13 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:13 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Controller Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:13 --> Total execution time: 0.5069
DEBUG - 2011-03-31 09:37:13 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:13 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:13 --> Router Class Initialized
ERROR - 2011-03-31 09:37:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:37:21 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:21 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:21 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:21 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:21 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:21 --> Total execution time: 0.0433
DEBUG - 2011-03-31 09:37:21 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:21 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:21 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Controller Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:22 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Router Class Initialized
ERROR - 2011-03-31 09:37:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 09:37:22 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:22 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:22 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:22 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:22 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:22 --> Total execution time: 0.0296
DEBUG - 2011-03-31 09:37:22 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:22 --> Total execution time: 0.7885
DEBUG - 2011-03-31 09:37:22 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:22 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:22 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:22 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:22 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:22 --> Total execution time: 0.0367
DEBUG - 2011-03-31 09:37:22 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:22 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:22 --> Router Class Initialized
ERROR - 2011-03-31 09:37:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:37:36 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:36 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:36 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:36 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:36 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:36 --> Total execution time: 0.0332
DEBUG - 2011-03-31 09:37:37 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:37 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:37 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Controller Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:37 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:38 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:38 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Total execution time: 0.6057
DEBUG - 2011-03-31 09:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:38 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:38 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:38 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:38 --> Total execution time: 0.0381
DEBUG - 2011-03-31 09:37:38 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:38 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:38 --> Router Class Initialized
ERROR - 2011-03-31 09:37:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:37:51 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:51 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:51 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Controller Class Initialized
ERROR - 2011-03-31 09:37:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 09:37:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:51 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 09:37:51 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:37:51 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:51 --> Total execution time: 0.0300
DEBUG - 2011-03-31 09:37:52 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:52 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Router Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Output Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Input Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:37:52 --> Language Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Loader Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Controller Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Model Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 09:37:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Final output sent to browser
DEBUG - 2011-03-31 09:37:52 --> Total execution time: 0.5432
DEBUG - 2011-03-31 09:37:52 --> Config Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:37:52 --> URI Class Initialized
DEBUG - 2011-03-31 09:37:52 --> Router Class Initialized
ERROR - 2011-03-31 09:37:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:59:16 --> Config Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:59:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:59:16 --> URI Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Router Class Initialized
DEBUG - 2011-03-31 09:59:16 --> No URI present. Default controller set.
DEBUG - 2011-03-31 09:59:16 --> Output Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Input Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 09:59:16 --> Language Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Loader Class Initialized
DEBUG - 2011-03-31 09:59:16 --> Controller Class Initialized
DEBUG - 2011-03-31 09:59:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 09:59:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 09:59:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 09:59:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 09:59:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 09:59:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 09:59:17 --> Final output sent to browser
DEBUG - 2011-03-31 09:59:17 --> Total execution time: 0.2931
DEBUG - 2011-03-31 09:59:20 --> Config Class Initialized
DEBUG - 2011-03-31 09:59:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:59:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:59:20 --> URI Class Initialized
DEBUG - 2011-03-31 09:59:20 --> Router Class Initialized
ERROR - 2011-03-31 09:59:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 09:59:21 --> Config Class Initialized
DEBUG - 2011-03-31 09:59:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 09:59:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 09:59:21 --> URI Class Initialized
DEBUG - 2011-03-31 09:59:21 --> Router Class Initialized
ERROR - 2011-03-31 09:59:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:06:17 --> Config Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:06:17 --> URI Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Router Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Output Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Input Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:06:17 --> Language Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Loader Class Initialized
DEBUG - 2011-03-31 10:06:17 --> Controller Class Initialized
ERROR - 2011-03-31 10:06:17 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-03-31 10:08:00 --> Config Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:08:00 --> URI Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Router Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Output Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Input Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:08:00 --> Language Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Loader Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Controller Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:08:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:08:01 --> Model Class Initialized
DEBUG - 2011-03-31 10:08:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:08:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:08:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:08:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:08:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:08:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:08:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:08:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:08:02 --> Final output sent to browser
DEBUG - 2011-03-31 10:08:02 --> Total execution time: 1.9803
DEBUG - 2011-03-31 10:30:53 --> Config Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:30:53 --> URI Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Router Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Output Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Input Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:30:53 --> Language Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Loader Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Controller Class Initialized
ERROR - 2011-03-31 10:30:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:30:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:30:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:30:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:30:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:30:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:30:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:30:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:30:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:30:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:30:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:30:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:30:54 --> Final output sent to browser
DEBUG - 2011-03-31 10:30:54 --> Total execution time: 0.5847
DEBUG - 2011-03-31 10:30:55 --> Config Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:30:55 --> URI Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Router Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Output Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Input Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:30:55 --> Language Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Loader Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Controller Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Model Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Model Class Initialized
DEBUG - 2011-03-31 10:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:30:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:30:56 --> Final output sent to browser
DEBUG - 2011-03-31 10:30:56 --> Total execution time: 0.7445
DEBUG - 2011-03-31 10:30:58 --> Config Class Initialized
DEBUG - 2011-03-31 10:30:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:30:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:30:58 --> URI Class Initialized
DEBUG - 2011-03-31 10:30:58 --> Router Class Initialized
ERROR - 2011-03-31 10:30:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:31:02 --> Config Class Initialized
DEBUG - 2011-03-31 10:31:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:31:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:31:02 --> URI Class Initialized
DEBUG - 2011-03-31 10:31:02 --> Router Class Initialized
ERROR - 2011-03-31 10:31:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:32:36 --> Config Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:32:36 --> URI Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Router Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Output Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Input Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:32:36 --> Language Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Loader Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Controller Class Initialized
ERROR - 2011-03-31 10:32:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:32:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:32:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:32:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:32:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:32:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:32:37 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:32:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:32:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:32:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:32:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:32:37 --> Final output sent to browser
DEBUG - 2011-03-31 10:32:37 --> Total execution time: 0.1044
DEBUG - 2011-03-31 10:32:38 --> Config Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:32:38 --> URI Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Router Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Output Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Input Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:32:38 --> Language Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Loader Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Controller Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Model Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Model Class Initialized
DEBUG - 2011-03-31 10:32:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:32:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:32:39 --> Final output sent to browser
DEBUG - 2011-03-31 10:32:39 --> Total execution time: 0.8902
DEBUG - 2011-03-31 10:33:36 --> Config Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:33:36 --> URI Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Router Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Output Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Input Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:33:36 --> Language Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Loader Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Controller Class Initialized
ERROR - 2011-03-31 10:33:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:33:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:33:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:33:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:33:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:33:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:33:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:33:36 --> Final output sent to browser
DEBUG - 2011-03-31 10:33:36 --> Total execution time: 0.0309
DEBUG - 2011-03-31 10:33:37 --> Config Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:33:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:33:37 --> URI Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Router Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Output Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Input Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:33:37 --> Language Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Loader Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Controller Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Model Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Model Class Initialized
DEBUG - 2011-03-31 10:33:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:33:37 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:33:38 --> Final output sent to browser
DEBUG - 2011-03-31 10:33:38 --> Total execution time: 0.8502
DEBUG - 2011-03-31 10:34:12 --> Config Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:34:12 --> URI Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Router Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Output Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Input Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:34:12 --> Language Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Loader Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Controller Class Initialized
ERROR - 2011-03-31 10:34:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:34:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:34:12 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:34:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:34:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:34:12 --> Final output sent to browser
DEBUG - 2011-03-31 10:34:12 --> Total execution time: 0.0704
DEBUG - 2011-03-31 10:34:13 --> Config Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:34:13 --> URI Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Router Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Output Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Input Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:34:13 --> Language Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Loader Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Controller Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:34:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:34:14 --> Final output sent to browser
DEBUG - 2011-03-31 10:34:14 --> Total execution time: 1.0866
DEBUG - 2011-03-31 10:34:46 --> Config Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:34:46 --> URI Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Router Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Output Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Input Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:34:46 --> Language Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Loader Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Controller Class Initialized
ERROR - 2011-03-31 10:34:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:34:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:34:46 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:34:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:34:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:34:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:34:46 --> Final output sent to browser
DEBUG - 2011-03-31 10:34:46 --> Total execution time: 0.0302
DEBUG - 2011-03-31 10:34:47 --> Config Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:34:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:34:47 --> URI Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Router Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Output Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Input Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:34:47 --> Language Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Loader Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Controller Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Model Class Initialized
DEBUG - 2011-03-31 10:34:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:34:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:34:48 --> Final output sent to browser
DEBUG - 2011-03-31 10:34:48 --> Total execution time: 0.7629
DEBUG - 2011-03-31 10:35:13 --> Config Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:35:13 --> URI Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Router Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Output Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Input Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:35:13 --> Language Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Loader Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Controller Class Initialized
ERROR - 2011-03-31 10:35:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:35:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:35:13 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:35:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:35:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:35:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:35:13 --> Final output sent to browser
DEBUG - 2011-03-31 10:35:13 --> Total execution time: 0.0314
DEBUG - 2011-03-31 10:35:14 --> Config Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:35:14 --> URI Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Router Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Output Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Input Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:35:14 --> Language Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Loader Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Controller Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:35:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:35:15 --> Final output sent to browser
DEBUG - 2011-03-31 10:35:15 --> Total execution time: 0.5729
DEBUG - 2011-03-31 10:35:39 --> Config Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:35:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:35:39 --> URI Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Router Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Output Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Input Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:35:39 --> Language Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Loader Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Controller Class Initialized
ERROR - 2011-03-31 10:35:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:35:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:35:39 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:35:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:35:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:35:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:35:39 --> Final output sent to browser
DEBUG - 2011-03-31 10:35:39 --> Total execution time: 0.0349
DEBUG - 2011-03-31 10:35:43 --> Config Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:35:43 --> URI Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Router Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Output Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Input Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:35:43 --> Language Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Loader Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Controller Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Model Class Initialized
DEBUG - 2011-03-31 10:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:35:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:35:44 --> Final output sent to browser
DEBUG - 2011-03-31 10:35:44 --> Total execution time: 0.5557
DEBUG - 2011-03-31 10:36:10 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:10 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:10 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Controller Class Initialized
ERROR - 2011-03-31 10:36:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:36:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:10 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:36:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:36:10 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:10 --> Total execution time: 0.0832
DEBUG - 2011-03-31 10:36:11 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:11 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:11 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Controller Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:12 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:12 --> Total execution time: 0.5581
DEBUG - 2011-03-31 10:36:14 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:14 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:14 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Controller Class Initialized
ERROR - 2011-03-31 10:36:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:36:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:14 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:36:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:36:14 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:14 --> Total execution time: 0.0320
DEBUG - 2011-03-31 10:36:36 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:36 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:36 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Controller Class Initialized
ERROR - 2011-03-31 10:36:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:36:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:36:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:36:36 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:36 --> Total execution time: 0.0466
DEBUG - 2011-03-31 10:36:38 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:38 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:38 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Controller Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:39 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:39 --> Total execution time: 0.9010
DEBUG - 2011-03-31 10:36:41 --> Config Class Initialized
DEBUG - 2011-03-31 10:36:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:36:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:36:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:36:42 --> URI Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Router Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Output Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Input Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:36:42 --> Language Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Loader Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Controller Class Initialized
ERROR - 2011-03-31 10:36:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:36:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:42 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Model Class Initialized
DEBUG - 2011-03-31 10:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:36:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:36:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:36:42 --> Final output sent to browser
DEBUG - 2011-03-31 10:36:42 --> Total execution time: 0.1390
DEBUG - 2011-03-31 10:37:50 --> Config Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:37:50 --> URI Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Router Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Output Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Input Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:37:50 --> Language Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Loader Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Controller Class Initialized
ERROR - 2011-03-31 10:37:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:37:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:37:50 --> Model Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Model Class Initialized
DEBUG - 2011-03-31 10:37:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:37:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:37:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:37:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:37:50 --> Final output sent to browser
DEBUG - 2011-03-31 10:37:50 --> Total execution time: 0.0578
DEBUG - 2011-03-31 10:37:54 --> Config Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:37:54 --> URI Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Router Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Output Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Input Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:37:54 --> Language Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Loader Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Controller Class Initialized
ERROR - 2011-03-31 10:37:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:37:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:37:54 --> Model Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Model Class Initialized
DEBUG - 2011-03-31 10:37:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:37:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:37:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:37:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:37:54 --> Final output sent to browser
DEBUG - 2011-03-31 10:37:54 --> Total execution time: 0.0840
DEBUG - 2011-03-31 10:38:00 --> Config Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:38:00 --> URI Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Router Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Output Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Input Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:38:00 --> Language Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Loader Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Controller Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:38:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:38:00 --> Final output sent to browser
DEBUG - 2011-03-31 10:38:00 --> Total execution time: 0.5266
DEBUG - 2011-03-31 10:38:52 --> Config Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:38:52 --> URI Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Router Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Output Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Input Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:38:52 --> Language Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Loader Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Controller Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Model Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Model Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Model Class Initialized
DEBUG - 2011-03-31 10:38:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:38:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:38:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:38:53 --> Final output sent to browser
DEBUG - 2011-03-31 10:38:53 --> Total execution time: 0.5003
DEBUG - 2011-03-31 10:39:02 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:02 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:02 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Controller Class Initialized
ERROR - 2011-03-31 10:39:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:02 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:02 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:02 --> Total execution time: 0.0488
DEBUG - 2011-03-31 10:39:03 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:03 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:03 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:03 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:03 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:03 --> Total execution time: 0.4329
DEBUG - 2011-03-31 10:39:05 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:05 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:05 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:39:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:06 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:06 --> Total execution time: 0.4781
DEBUG - 2011-03-31 10:39:08 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:08 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:08 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:39:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:08 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:08 --> Total execution time: 0.0574
DEBUG - 2011-03-31 10:39:15 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:15 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:15 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Controller Class Initialized
ERROR - 2011-03-31 10:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:15 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:15 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:15 --> Total execution time: 0.0333
DEBUG - 2011-03-31 10:39:16 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:16 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:16 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:18 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:18 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:39:18 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:18 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:18 --> Total execution time: 0.3312
DEBUG - 2011-03-31 10:39:24 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:24 --> Total execution time: 8.5080
DEBUG - 2011-03-31 10:39:36 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:36 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:36 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Controller Class Initialized
ERROR - 2011-03-31 10:39:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:39:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:36 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:36 --> Total execution time: 0.1195
DEBUG - 2011-03-31 10:39:37 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:37 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:37 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:37 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:38 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:38 --> Total execution time: 0.6544
DEBUG - 2011-03-31 10:39:50 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:50 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:50 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Controller Class Initialized
ERROR - 2011-03-31 10:39:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:39:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:50 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:39:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:39:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:39:50 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:50 --> Total execution time: 0.0416
DEBUG - 2011-03-31 10:39:53 --> Config Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:39:53 --> URI Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Router Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Output Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Input Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:39:53 --> Language Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Loader Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Controller Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:39:53 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:39:54 --> Final output sent to browser
DEBUG - 2011-03-31 10:39:54 --> Total execution time: 0.5228
DEBUG - 2011-03-31 10:40:02 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:02 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:02 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Controller Class Initialized
ERROR - 2011-03-31 10:40:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:40:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:02 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:40:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:40:02 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:02 --> Total execution time: 0.2949
DEBUG - 2011-03-31 10:40:07 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:07 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:07 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Controller Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:07 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:08 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:08 --> Total execution time: 1.1724
DEBUG - 2011-03-31 10:40:23 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:23 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:23 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Controller Class Initialized
ERROR - 2011-03-31 10:40:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:40:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:23 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:40:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:40:23 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:23 --> Total execution time: 0.0297
DEBUG - 2011-03-31 10:40:24 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:24 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:24 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Controller Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:25 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:25 --> Total execution time: 0.6083
DEBUG - 2011-03-31 10:40:52 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:52 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:52 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Controller Class Initialized
ERROR - 2011-03-31 10:40:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:40:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:52 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:40:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:40:52 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:52 --> Total execution time: 0.0599
DEBUG - 2011-03-31 10:40:53 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:53 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:53 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Controller Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:53 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:53 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:53 --> Total execution time: 0.5692
DEBUG - 2011-03-31 10:40:54 --> Config Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:40:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:40:54 --> URI Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Router Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Output Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Input Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:40:54 --> Language Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Loader Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Controller Class Initialized
ERROR - 2011-03-31 10:40:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:40:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:54 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Model Class Initialized
DEBUG - 2011-03-31 10:40:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:40:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:40:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:40:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:40:54 --> Final output sent to browser
DEBUG - 2011-03-31 10:40:54 --> Total execution time: 0.0354
DEBUG - 2011-03-31 10:45:00 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:00 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Router Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Output Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Input Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:45:00 --> Language Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Loader Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Controller Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:00 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:01 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:45:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 10:45:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:45:01 --> Final output sent to browser
DEBUG - 2011-03-31 10:45:01 --> Total execution time: 0.4499
DEBUG - 2011-03-31 10:45:04 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:04 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:04 --> Router Class Initialized
ERROR - 2011-03-31 10:45:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:45:05 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:05 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:05 --> Router Class Initialized
ERROR - 2011-03-31 10:45:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:45:15 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:15 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Router Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Output Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Input Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:45:15 --> Language Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Loader Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Controller Class Initialized
ERROR - 2011-03-31 10:45:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 10:45:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:45:15 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:45:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 10:45:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 10:45:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 10:45:15 --> Final output sent to browser
DEBUG - 2011-03-31 10:45:15 --> Total execution time: 0.0963
DEBUG - 2011-03-31 10:45:16 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:16 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Router Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Output Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Input Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 10:45:16 --> Language Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Loader Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Controller Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Model Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 10:45:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Config Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 10:45:16 --> URI Class Initialized
DEBUG - 2011-03-31 10:45:16 --> Router Class Initialized
ERROR - 2011-03-31 10:45:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 10:45:16 --> Final output sent to browser
DEBUG - 2011-03-31 10:45:16 --> Total execution time: 0.7026
DEBUG - 2011-03-31 11:32:48 --> Config Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:32:48 --> URI Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Router Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Output Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Input Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:32:48 --> Language Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Loader Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Controller Class Initialized
ERROR - 2011-03-31 11:32:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 11:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:32:48 --> Model Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Model Class Initialized
DEBUG - 2011-03-31 11:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:32:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:32:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:32:48 --> Final output sent to browser
DEBUG - 2011-03-31 11:32:48 --> Total execution time: 0.3741
DEBUG - 2011-03-31 11:32:53 --> Config Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:32:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:32:53 --> URI Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Router Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Output Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Input Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:32:53 --> Language Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Loader Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Controller Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Model Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Model Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Model Class Initialized
DEBUG - 2011-03-31 11:32:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:32:53 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:32:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:32:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:32:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:32:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:32:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:32:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:32:53 --> Final output sent to browser
DEBUG - 2011-03-31 11:32:53 --> Total execution time: 0.6364
DEBUG - 2011-03-31 11:33:25 --> Config Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:33:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:33:25 --> URI Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Router Class Initialized
DEBUG - 2011-03-31 11:33:25 --> No URI present. Default controller set.
DEBUG - 2011-03-31 11:33:25 --> Output Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Input Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:33:25 --> Language Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Loader Class Initialized
DEBUG - 2011-03-31 11:33:25 --> Controller Class Initialized
DEBUG - 2011-03-31 11:33:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 11:33:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:33:25 --> Final output sent to browser
DEBUG - 2011-03-31 11:33:25 --> Total execution time: 0.0759
DEBUG - 2011-03-31 11:42:52 --> Config Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:42:52 --> URI Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Router Class Initialized
DEBUG - 2011-03-31 11:42:52 --> No URI present. Default controller set.
DEBUG - 2011-03-31 11:42:52 --> Output Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Input Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:42:52 --> Language Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Loader Class Initialized
DEBUG - 2011-03-31 11:42:52 --> Controller Class Initialized
DEBUG - 2011-03-31 11:42:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 11:42:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:42:52 --> Final output sent to browser
DEBUG - 2011-03-31 11:42:52 --> Total execution time: 0.2403
DEBUG - 2011-03-31 11:42:53 --> Config Class Initialized
DEBUG - 2011-03-31 11:42:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:42:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:42:53 --> URI Class Initialized
DEBUG - 2011-03-31 11:42:53 --> Router Class Initialized
ERROR - 2011-03-31 11:42:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:42:56 --> Config Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:42:56 --> URI Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Router Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Output Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Input Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:42:56 --> Language Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Loader Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Controller Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Model Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Model Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Model Class Initialized
DEBUG - 2011-03-31 11:42:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:42:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:42:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:42:57 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:42:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:42:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:42:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:42:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:42:57 --> Final output sent to browser
DEBUG - 2011-03-31 11:42:57 --> Total execution time: 1.2148
DEBUG - 2011-03-31 11:42:59 --> Config Class Initialized
DEBUG - 2011-03-31 11:42:59 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:42:59 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:42:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:42:59 --> URI Class Initialized
DEBUG - 2011-03-31 11:42:59 --> Router Class Initialized
ERROR - 2011-03-31 11:42:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:43:09 --> Config Class Initialized
DEBUG - 2011-03-31 11:43:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:43:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:43:09 --> URI Class Initialized
DEBUG - 2011-03-31 11:43:09 --> Router Class Initialized
ERROR - 2011-03-31 11:43:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:43:21 --> Config Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:43:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:43:21 --> URI Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Router Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Output Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Input Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:43:21 --> Language Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Loader Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Controller Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:43:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:43:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:43:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:43:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:43:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:43:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:43:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:43:21 --> Final output sent to browser
DEBUG - 2011-03-31 11:43:21 --> Total execution time: 0.1962
DEBUG - 2011-03-31 11:43:23 --> Config Class Initialized
DEBUG - 2011-03-31 11:43:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:43:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:43:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:43:23 --> URI Class Initialized
DEBUG - 2011-03-31 11:43:23 --> Router Class Initialized
ERROR - 2011-03-31 11:43:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:43:33 --> Config Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:43:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:43:33 --> URI Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Router Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Output Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Input Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:43:33 --> Language Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Loader Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Controller Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Model Class Initialized
DEBUG - 2011-03-31 11:43:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:43:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:43:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:43:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:43:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:43:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:43:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:43:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:43:33 --> Final output sent to browser
DEBUG - 2011-03-31 11:43:33 --> Total execution time: 0.2639
DEBUG - 2011-03-31 11:43:34 --> Config Class Initialized
DEBUG - 2011-03-31 11:43:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:43:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:43:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:43:34 --> URI Class Initialized
DEBUG - 2011-03-31 11:43:34 --> Router Class Initialized
ERROR - 2011-03-31 11:43:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:44:00 --> Config Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:44:00 --> URI Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Router Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Output Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Input Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:44:00 --> Language Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Loader Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Controller Class Initialized
ERROR - 2011-03-31 11:44:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 11:44:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:44:00 --> Model Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Model Class Initialized
DEBUG - 2011-03-31 11:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:44:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:44:00 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:44:00 --> Final output sent to browser
DEBUG - 2011-03-31 11:44:00 --> Total execution time: 0.1536
DEBUG - 2011-03-31 11:44:01 --> Config Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:44:01 --> URI Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Router Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Output Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Input Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:44:01 --> Language Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Loader Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Controller Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Model Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Model Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:44:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:44:01 --> Final output sent to browser
DEBUG - 2011-03-31 11:44:01 --> Total execution time: 0.7910
DEBUG - 2011-03-31 11:44:02 --> Config Class Initialized
DEBUG - 2011-03-31 11:44:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:44:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:44:02 --> URI Class Initialized
DEBUG - 2011-03-31 11:44:02 --> Router Class Initialized
ERROR - 2011-03-31 11:44:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:46:42 --> Config Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:46:42 --> URI Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Router Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Output Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Input Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:46:42 --> Language Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Loader Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Controller Class Initialized
ERROR - 2011-03-31 11:46:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 11:46:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:46:42 --> Model Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Model Class Initialized
DEBUG - 2011-03-31 11:46:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:46:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 11:46:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:46:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:46:42 --> Final output sent to browser
DEBUG - 2011-03-31 11:46:42 --> Total execution time: 0.0392
DEBUG - 2011-03-31 11:46:43 --> Config Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:46:43 --> URI Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Router Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Output Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Input Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:46:43 --> Language Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Loader Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Controller Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Model Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Model Class Initialized
DEBUG - 2011-03-31 11:46:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:46:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:46:44 --> Final output sent to browser
DEBUG - 2011-03-31 11:46:44 --> Total execution time: 1.1844
DEBUG - 2011-03-31 11:46:47 --> Config Class Initialized
DEBUG - 2011-03-31 11:46:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:46:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:46:47 --> URI Class Initialized
DEBUG - 2011-03-31 11:46:47 --> Router Class Initialized
ERROR - 2011-03-31 11:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:47:13 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:13 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Router Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Output Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Input Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:47:13 --> Language Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Loader Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Controller Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:47:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:47:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:47:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:47:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:47:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:47:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:47:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:47:13 --> Final output sent to browser
DEBUG - 2011-03-31 11:47:13 --> Total execution time: 0.1497
DEBUG - 2011-03-31 11:47:15 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:15 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:15 --> Router Class Initialized
ERROR - 2011-03-31 11:47:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:47:23 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:23 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Router Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Output Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Input Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:47:23 --> Language Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Loader Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Controller Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:47:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:47:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:47:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:47:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:47:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:47:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:47:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:47:23 --> Final output sent to browser
DEBUG - 2011-03-31 11:47:23 --> Total execution time: 0.4396
DEBUG - 2011-03-31 11:47:25 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:25 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:25 --> Router Class Initialized
ERROR - 2011-03-31 11:47:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:47:42 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:42 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Router Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Output Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Input Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:47:42 --> Language Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Loader Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Controller Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:47:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:47:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:47:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:47:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:47:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:47:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:47:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:47:42 --> Final output sent to browser
DEBUG - 2011-03-31 11:47:42 --> Total execution time: 0.3764
DEBUG - 2011-03-31 11:47:44 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:44 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:44 --> Router Class Initialized
ERROR - 2011-03-31 11:47:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:47:54 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:54 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Router Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Output Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Input Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:47:54 --> Language Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Loader Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Controller Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Model Class Initialized
DEBUG - 2011-03-31 11:47:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:47:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:47:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:47:54 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:47:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:47:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:47:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:47:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:47:54 --> Final output sent to browser
DEBUG - 2011-03-31 11:47:54 --> Total execution time: 0.2555
DEBUG - 2011-03-31 11:47:56 --> Config Class Initialized
DEBUG - 2011-03-31 11:47:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:47:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:47:56 --> URI Class Initialized
DEBUG - 2011-03-31 11:47:56 --> Router Class Initialized
ERROR - 2011-03-31 11:47:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:01 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:01 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:01 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:02 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:02 --> Total execution time: 0.6355
DEBUG - 2011-03-31 11:48:03 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:03 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:03 --> Router Class Initialized
ERROR - 2011-03-31 11:48:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:09 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:09 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:09 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:10 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:10 --> Total execution time: 0.6162
DEBUG - 2011-03-31 11:48:11 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:11 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:11 --> Router Class Initialized
ERROR - 2011-03-31 11:48:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:18 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:18 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:18 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:18 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:18 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:18 --> Total execution time: 0.2386
DEBUG - 2011-03-31 11:48:19 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:19 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:19 --> Router Class Initialized
ERROR - 2011-03-31 11:48:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:25 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:25 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:25 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:25 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:25 --> Total execution time: 0.2586
DEBUG - 2011-03-31 11:48:27 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:27 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:27 --> Router Class Initialized
ERROR - 2011-03-31 11:48:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:31 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:31 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:31 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:31 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:31 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:31 --> Total execution time: 0.5579
DEBUG - 2011-03-31 11:48:33 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:33 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:33 --> Router Class Initialized
ERROR - 2011-03-31 11:48:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:51 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:51 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:51 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:52 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:52 --> Total execution time: 0.4043
DEBUG - 2011-03-31 11:48:53 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:53 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:53 --> Router Class Initialized
ERROR - 2011-03-31 11:48:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:48:58 --> Config Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:48:58 --> URI Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Router Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Output Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Input Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:48:58 --> Language Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Loader Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Controller Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Model Class Initialized
DEBUG - 2011-03-31 11:48:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:48:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:48:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:48:58 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:48:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:48:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:48:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:48:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:48:58 --> Final output sent to browser
DEBUG - 2011-03-31 11:48:58 --> Total execution time: 0.1652
DEBUG - 2011-03-31 11:49:00 --> Config Class Initialized
DEBUG - 2011-03-31 11:49:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:49:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:49:00 --> URI Class Initialized
DEBUG - 2011-03-31 11:49:00 --> Router Class Initialized
ERROR - 2011-03-31 11:49:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:49:04 --> Config Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:49:04 --> URI Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Router Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Output Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Input Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:49:04 --> Language Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Loader Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Controller Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:49:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:49:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:49:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:49:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:49:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:49:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:49:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:49:04 --> Final output sent to browser
DEBUG - 2011-03-31 11:49:04 --> Total execution time: 0.1947
DEBUG - 2011-03-31 11:49:06 --> Config Class Initialized
DEBUG - 2011-03-31 11:49:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:49:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:49:06 --> URI Class Initialized
DEBUG - 2011-03-31 11:49:06 --> Router Class Initialized
ERROR - 2011-03-31 11:49:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 11:49:15 --> Config Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:49:15 --> URI Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Router Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Output Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Input Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 11:49:15 --> Language Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Loader Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Controller Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Model Class Initialized
DEBUG - 2011-03-31 11:49:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 11:49:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 11:49:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 11:49:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 11:49:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 11:49:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 11:49:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 11:49:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 11:49:15 --> Final output sent to browser
DEBUG - 2011-03-31 11:49:15 --> Total execution time: 0.0457
DEBUG - 2011-03-31 11:49:16 --> Config Class Initialized
DEBUG - 2011-03-31 11:49:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 11:49:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 11:49:16 --> URI Class Initialized
DEBUG - 2011-03-31 11:49:16 --> Router Class Initialized
ERROR - 2011-03-31 11:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:04:12 --> Config Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:04:12 --> URI Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Router Class Initialized
DEBUG - 2011-03-31 12:04:12 --> No URI present. Default controller set.
DEBUG - 2011-03-31 12:04:12 --> Output Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Input Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:04:12 --> Language Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Loader Class Initialized
DEBUG - 2011-03-31 12:04:12 --> Controller Class Initialized
DEBUG - 2011-03-31 12:04:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 12:04:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:04:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:04:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:04:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:04:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:04:12 --> Final output sent to browser
DEBUG - 2011-03-31 12:04:12 --> Total execution time: 0.3555
DEBUG - 2011-03-31 12:04:15 --> Config Class Initialized
DEBUG - 2011-03-31 12:04:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:04:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:04:15 --> URI Class Initialized
DEBUG - 2011-03-31 12:04:15 --> Router Class Initialized
ERROR - 2011-03-31 12:04:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:04:59 --> Config Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:04:59 --> URI Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Router Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Output Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Input Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:04:59 --> Language Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Loader Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Controller Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Model Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Model Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Model Class Initialized
DEBUG - 2011-03-31 12:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:04:59 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:04:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:04:59 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:04:59 --> Final output sent to browser
DEBUG - 2011-03-31 12:04:59 --> Total execution time: 0.6411
DEBUG - 2011-03-31 12:05:02 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:02 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:02 --> Router Class Initialized
ERROR - 2011-03-31 12:05:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:05:09 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:09 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:09 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:09 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:09 --> Total execution time: 0.5042
DEBUG - 2011-03-31 12:05:10 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:10 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:10 --> Router Class Initialized
ERROR - 2011-03-31 12:05:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:05:24 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:24 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:24 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:25 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:25 --> Total execution time: 0.3838
DEBUG - 2011-03-31 12:05:26 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:26 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:26 --> Router Class Initialized
ERROR - 2011-03-31 12:05:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:05:38 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:38 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:38 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:39 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:39 --> Total execution time: 0.7304
DEBUG - 2011-03-31 12:05:40 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:40 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:40 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:40 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:40 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:40 --> Total execution time: 0.0535
DEBUG - 2011-03-31 12:05:41 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:41 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:41 --> Router Class Initialized
ERROR - 2011-03-31 12:05:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:05:48 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:48 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:48 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:48 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:48 --> Total execution time: 0.3338
DEBUG - 2011-03-31 12:05:49 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:49 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Router Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Output Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Input Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:05:49 --> Language Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Loader Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Controller Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Model Class Initialized
DEBUG - 2011-03-31 12:05:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:05:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:05:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:05:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:05:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:05:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:05:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:05:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:05:49 --> Final output sent to browser
DEBUG - 2011-03-31 12:05:49 --> Total execution time: 0.0449
DEBUG - 2011-03-31 12:05:51 --> Config Class Initialized
DEBUG - 2011-03-31 12:05:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:05:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:05:51 --> URI Class Initialized
DEBUG - 2011-03-31 12:05:51 --> Router Class Initialized
ERROR - 2011-03-31 12:05:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:12:54 --> Config Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:12:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:12:54 --> URI Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Router Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Output Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Input Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:12:54 --> Language Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Loader Class Initialized
DEBUG - 2011-03-31 12:12:54 --> Controller Class Initialized
ERROR - 2011-03-31 12:12:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 12:12:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 12:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:12:55 --> Model Class Initialized
DEBUG - 2011-03-31 12:12:55 --> Model Class Initialized
DEBUG - 2011-03-31 12:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:12:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:12:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:12:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:12:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:12:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:12:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:12:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:12:56 --> Final output sent to browser
DEBUG - 2011-03-31 12:12:56 --> Total execution time: 1.6966
DEBUG - 2011-03-31 12:12:57 --> Config Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:12:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:12:57 --> URI Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Router Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Output Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Input Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:12:57 --> Language Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Loader Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Controller Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Model Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Model Class Initialized
DEBUG - 2011-03-31 12:12:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:12:57 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:12:58 --> Final output sent to browser
DEBUG - 2011-03-31 12:12:58 --> Total execution time: 0.8435
DEBUG - 2011-03-31 12:19:55 --> Config Class Initialized
DEBUG - 2011-03-31 12:19:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:19:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:19:56 --> URI Class Initialized
DEBUG - 2011-03-31 12:19:56 --> Router Class Initialized
DEBUG - 2011-03-31 12:19:56 --> No URI present. Default controller set.
DEBUG - 2011-03-31 12:19:56 --> Output Class Initialized
DEBUG - 2011-03-31 12:19:56 --> Input Class Initialized
DEBUG - 2011-03-31 12:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:19:56 --> Language Class Initialized
DEBUG - 2011-03-31 12:19:56 --> Loader Class Initialized
DEBUG - 2011-03-31 12:19:56 --> Controller Class Initialized
DEBUG - 2011-03-31 12:19:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 12:19:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:19:56 --> Final output sent to browser
DEBUG - 2011-03-31 12:19:56 --> Total execution time: 0.2019
DEBUG - 2011-03-31 12:27:42 --> Config Class Initialized
DEBUG - 2011-03-31 12:27:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:27:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:27:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:27:42 --> URI Class Initialized
DEBUG - 2011-03-31 12:27:42 --> Router Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Output Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Input Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:27:43 --> Language Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Loader Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Controller Class Initialized
ERROR - 2011-03-31 12:27:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 12:27:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Model Class Initialized
DEBUG - 2011-03-31 12:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:27:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:27:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:27:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:27:43 --> Final output sent to browser
DEBUG - 2011-03-31 12:27:43 --> Total execution time: 1.9805
DEBUG - 2011-03-31 12:27:47 --> Config Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:27:47 --> URI Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Router Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Output Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Input Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:27:47 --> Language Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Loader Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Controller Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Model Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Model Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:27:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:27:47 --> Final output sent to browser
DEBUG - 2011-03-31 12:27:47 --> Total execution time: 0.6026
DEBUG - 2011-03-31 12:28:09 --> Config Class Initialized
DEBUG - 2011-03-31 12:28:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:28:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:28:09 --> URI Class Initialized
DEBUG - 2011-03-31 12:28:09 --> Router Class Initialized
ERROR - 2011-03-31 12:28:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:48:23 --> Config Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:48:23 --> URI Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Router Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Output Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Input Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:48:23 --> Language Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Loader Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Controller Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Model Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Model Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Model Class Initialized
DEBUG - 2011-03-31 12:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:48:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:48:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 12:48:24 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:48:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:48:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:48:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:48:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:48:24 --> Final output sent to browser
DEBUG - 2011-03-31 12:48:24 --> Total execution time: 0.6826
DEBUG - 2011-03-31 12:54:07 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:07 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Router Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Output Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Input Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:54:07 --> Language Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Loader Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Controller Class Initialized
ERROR - 2011-03-31 12:54:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 12:54:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 12:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:54:07 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:54:07 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:54:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:54:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:54:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:54:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:54:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:54:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:54:08 --> Final output sent to browser
DEBUG - 2011-03-31 12:54:08 --> Total execution time: 0.4916
DEBUG - 2011-03-31 12:54:08 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:09 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Router Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Output Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Input Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:54:09 --> Language Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Loader Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Controller Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:54:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:54:09 --> Final output sent to browser
DEBUG - 2011-03-31 12:54:09 --> Total execution time: 0.7736
DEBUG - 2011-03-31 12:54:10 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:10 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:10 --> Router Class Initialized
ERROR - 2011-03-31 12:54:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 12:54:55 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:55 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Router Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Output Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Input Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:54:55 --> Language Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Loader Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Controller Class Initialized
ERROR - 2011-03-31 12:54:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 12:54:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:54:55 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:54:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 12:54:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 12:54:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 12:54:55 --> Final output sent to browser
DEBUG - 2011-03-31 12:54:55 --> Total execution time: 0.0343
DEBUG - 2011-03-31 12:54:56 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:56 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Router Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Output Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Input Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 12:54:56 --> Language Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Loader Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Controller Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Model Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 12:54:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 12:54:56 --> Final output sent to browser
DEBUG - 2011-03-31 12:54:56 --> Total execution time: 0.5694
DEBUG - 2011-03-31 12:54:57 --> Config Class Initialized
DEBUG - 2011-03-31 12:54:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 12:54:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 12:54:57 --> URI Class Initialized
DEBUG - 2011-03-31 12:54:57 --> Router Class Initialized
ERROR - 2011-03-31 12:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:30:16 --> Config Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:30:16 --> URI Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Router Class Initialized
DEBUG - 2011-03-31 13:30:16 --> No URI present. Default controller set.
DEBUG - 2011-03-31 13:30:16 --> Output Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Input Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:30:16 --> Language Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Loader Class Initialized
DEBUG - 2011-03-31 13:30:16 --> Controller Class Initialized
DEBUG - 2011-03-31 13:30:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 13:30:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:30:16 --> Final output sent to browser
DEBUG - 2011-03-31 13:30:16 --> Total execution time: 0.3078
DEBUG - 2011-03-31 13:30:25 --> Config Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:30:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:30:25 --> URI Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Router Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Output Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Input Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:30:25 --> Language Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Loader Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Controller Class Initialized
ERROR - 2011-03-31 13:30:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:30:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:30:25 --> Model Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Model Class Initialized
DEBUG - 2011-03-31 13:30:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:30:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:30:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:30:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:30:25 --> Final output sent to browser
DEBUG - 2011-03-31 13:30:25 --> Total execution time: 0.2796
DEBUG - 2011-03-31 13:30:28 --> Config Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:30:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:30:28 --> URI Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Router Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Output Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Input Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:30:28 --> Language Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Loader Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Controller Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Model Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Model Class Initialized
DEBUG - 2011-03-31 13:30:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:30:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:30:29 --> Final output sent to browser
DEBUG - 2011-03-31 13:30:29 --> Total execution time: 1.1149
DEBUG - 2011-03-31 13:31:08 --> Config Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:31:08 --> URI Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Router Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Output Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Input Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:31:08 --> Language Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Loader Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Controller Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Model Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Model Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Model Class Initialized
DEBUG - 2011-03-31 13:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:31:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:31:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 13:31:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:31:09 --> Final output sent to browser
DEBUG - 2011-03-31 13:31:09 --> Total execution time: 0.7053
DEBUG - 2011-03-31 13:32:10 --> Config Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:32:10 --> URI Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Router Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Output Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Input Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:32:10 --> Language Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Loader Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Controller Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:32:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:32:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 13:32:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:32:10 --> Final output sent to browser
DEBUG - 2011-03-31 13:32:10 --> Total execution time: 0.3334
DEBUG - 2011-03-31 13:32:15 --> Config Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:32:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:32:15 --> URI Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Router Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Output Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Input Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:32:15 --> Language Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Loader Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Controller Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:32:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:32:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 13:32:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:32:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:32:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:32:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:32:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:32:15 --> Final output sent to browser
DEBUG - 2011-03-31 13:32:15 --> Total execution time: 0.1258
DEBUG - 2011-03-31 13:32:21 --> Config Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:32:21 --> URI Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Router Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Output Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Input Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:32:21 --> Language Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Loader Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Controller Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:32:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:32:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 13:32:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:32:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:32:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:32:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:32:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:32:21 --> Final output sent to browser
DEBUG - 2011-03-31 13:32:21 --> Total execution time: 0.1759
DEBUG - 2011-03-31 13:32:36 --> Config Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:32:36 --> URI Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Router Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Output Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Input Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:32:36 --> Language Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Loader Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Controller Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Model Class Initialized
DEBUG - 2011-03-31 13:32:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:32:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:32:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 13:32:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:32:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:32:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:32:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:32:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:32:36 --> Final output sent to browser
DEBUG - 2011-03-31 13:32:36 --> Total execution time: 0.6326
DEBUG - 2011-03-31 13:47:05 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:05 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Router Class Initialized
DEBUG - 2011-03-31 13:47:05 --> No URI present. Default controller set.
DEBUG - 2011-03-31 13:47:05 --> Output Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Input Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:47:05 --> Language Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Loader Class Initialized
DEBUG - 2011-03-31 13:47:05 --> Controller Class Initialized
DEBUG - 2011-03-31 13:47:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 13:47:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:47:06 --> Final output sent to browser
DEBUG - 2011-03-31 13:47:06 --> Total execution time: 1.3121
DEBUG - 2011-03-31 13:47:07 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:07 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:07 --> Router Class Initialized
ERROR - 2011-03-31 13:47:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:47:08 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:08 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:08 --> Router Class Initialized
ERROR - 2011-03-31 13:47:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:47:10 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:10 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Router Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Output Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Input Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:47:10 --> Language Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Loader Class Initialized
DEBUG - 2011-03-31 13:47:10 --> Controller Class Initialized
ERROR - 2011-03-31 13:47:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:47:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:47:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:47:11 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:11 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:47:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:47:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:47:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:47:11 --> Final output sent to browser
DEBUG - 2011-03-31 13:47:11 --> Total execution time: 1.2727
DEBUG - 2011-03-31 13:47:12 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:12 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Router Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Output Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Input Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:47:12 --> Language Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Loader Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Controller Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:47:12 --> Database Driver Class Initialized
ERROR - 2011-03-31 13:47:13 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: SSL: connection timeout /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-03-31 13:47:13 --> Severity: Warning  --> fopen() [<a href='function.fopen'>function.fopen</a>]: Failed to enable crypto /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-03-31 13:47:13 --> Severity: Warning  --> fopen(https://chart.googleapis.com/chart?chid=6d755faa8c052164872a105c3d897b8b) [<a href='function.fopen'>function.fopen</a>]: failed to open stream: operation failed /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 60
ERROR - 2011-03-31 13:47:13 --> Severity: Warning  --> fpassthru(): supplied argument is not a valid stream resource /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 61
ERROR - 2011-03-31 13:47:13 --> Severity: Warning  --> fclose(): supplied argument is not a valid stream resource /home1/raptorsr/public_html/arsenaliststats/application/controllers/snakes.php 62
DEBUG - 2011-03-31 13:47:13 --> Final output sent to browser
DEBUG - 2011-03-31 13:47:13 --> Total execution time: 0.4925
DEBUG - 2011-03-31 13:47:13 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:13 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:13 --> Router Class Initialized
ERROR - 2011-03-31 13:47:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:47:21 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:21 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Router Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Output Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Input Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:47:21 --> Language Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Loader Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Controller Class Initialized
ERROR - 2011-03-31 13:47:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:47:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:47:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:47:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:47:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:47:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:47:21 --> Final output sent to browser
DEBUG - 2011-03-31 13:47:21 --> Total execution time: 0.0318
DEBUG - 2011-03-31 13:47:22 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:22 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Router Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Output Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Input Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:47:22 --> Language Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Loader Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Controller Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Model Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:47:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:47:22 --> Final output sent to browser
DEBUG - 2011-03-31 13:47:22 --> Total execution time: 0.6062
DEBUG - 2011-03-31 13:47:24 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:24 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:24 --> Router Class Initialized
ERROR - 2011-03-31 13:47:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:47:32 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:32 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:32 --> Router Class Initialized
ERROR - 2011-03-31 13:47:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:47:33 --> Config Class Initialized
DEBUG - 2011-03-31 13:47:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:47:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:47:33 --> URI Class Initialized
DEBUG - 2011-03-31 13:47:33 --> Router Class Initialized
ERROR - 2011-03-31 13:47:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:48:16 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:16 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:16 --> No URI present. Default controller set.
DEBUG - 2011-03-31 13:48:16 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:16 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:16 --> Controller Class Initialized
DEBUG - 2011-03-31 13:48:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 13:48:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:48:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:48:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:48:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:48:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:48:16 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:16 --> Total execution time: 0.0133
DEBUG - 2011-03-31 13:48:17 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:17 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Router Class Initialized
ERROR - 2011-03-31 13:48:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:48:17 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:17 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:17 --> Router Class Initialized
ERROR - 2011-03-31 13:48:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:48:18 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:18 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:18 --> Router Class Initialized
ERROR - 2011-03-31 13:48:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 13:48:21 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:21 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:21 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Controller Class Initialized
ERROR - 2011-03-31 13:48:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:48:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:48:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:48:21 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:21 --> Total execution time: 0.0502
DEBUG - 2011-03-31 13:48:22 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:22 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:22 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Controller Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:22 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:22 --> Total execution time: 0.4716
DEBUG - 2011-03-31 13:48:41 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:41 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:41 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Controller Class Initialized
ERROR - 2011-03-31 13:48:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:48:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:41 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:48:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:48:41 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:41 --> Total execution time: 0.0311
DEBUG - 2011-03-31 13:48:42 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:42 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:42 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Controller Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:43 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:43 --> Total execution time: 0.5883
DEBUG - 2011-03-31 13:48:45 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:46 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:46 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Controller Class Initialized
ERROR - 2011-03-31 13:48:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:48:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:46 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:48:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:48:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:48:46 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:46 --> Total execution time: 0.0832
DEBUG - 2011-03-31 13:48:46 --> Config Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:48:46 --> URI Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Router Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Output Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Input Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:48:46 --> Language Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Loader Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Controller Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Model Class Initialized
DEBUG - 2011-03-31 13:48:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:48:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:48:47 --> Final output sent to browser
DEBUG - 2011-03-31 13:48:47 --> Total execution time: 0.6026
DEBUG - 2011-03-31 13:49:12 --> Config Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:49:12 --> URI Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Router Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Output Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Input Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:49:12 --> Language Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Loader Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Controller Class Initialized
ERROR - 2011-03-31 13:49:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 13:49:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:49:12 --> Model Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Model Class Initialized
DEBUG - 2011-03-31 13:49:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:49:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 13:49:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 13:49:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 13:49:12 --> Final output sent to browser
DEBUG - 2011-03-31 13:49:12 --> Total execution time: 0.1356
DEBUG - 2011-03-31 13:49:13 --> Config Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 13:49:13 --> URI Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Router Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Output Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Input Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 13:49:13 --> Language Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Loader Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Controller Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Model Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Model Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 13:49:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 13:49:13 --> Final output sent to browser
DEBUG - 2011-03-31 13:49:13 --> Total execution time: 0.6904
DEBUG - 2011-03-31 14:07:06 --> Config Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:07:06 --> URI Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Router Class Initialized
ERROR - 2011-03-31 14:07:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 14:07:06 --> Config Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:07:06 --> URI Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Router Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Output Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Input Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:07:06 --> Language Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Loader Class Initialized
DEBUG - 2011-03-31 14:07:06 --> Controller Class Initialized
ERROR - 2011-03-31 14:07:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:07:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:07:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:07:06 --> Model Class Initialized
DEBUG - 2011-03-31 14:07:07 --> Model Class Initialized
DEBUG - 2011-03-31 14:07:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:07:07 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:07:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:07:07 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:07:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:07:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:07:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:07:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:07:07 --> Final output sent to browser
DEBUG - 2011-03-31 14:07:07 --> Total execution time: 0.3214
DEBUG - 2011-03-31 14:24:00 --> Config Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:24:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:24:00 --> URI Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Router Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Output Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Input Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:24:00 --> Language Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Loader Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Controller Class Initialized
ERROR - 2011-03-31 14:24:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:24:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:24:00 --> Model Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Model Class Initialized
DEBUG - 2011-03-31 14:24:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:24:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:24:00 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:24:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:24:00 --> Final output sent to browser
DEBUG - 2011-03-31 14:24:00 --> Total execution time: 0.6642
DEBUG - 2011-03-31 14:24:01 --> Config Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:24:01 --> URI Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Router Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Output Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Input Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:24:01 --> Language Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Loader Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Controller Class Initialized
DEBUG - 2011-03-31 14:24:01 --> Model Class Initialized
DEBUG - 2011-03-31 14:24:02 --> Model Class Initialized
DEBUG - 2011-03-31 14:24:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:24:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:24:02 --> Final output sent to browser
DEBUG - 2011-03-31 14:24:02 --> Total execution time: 0.7767
DEBUG - 2011-03-31 14:24:04 --> Config Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:24:04 --> URI Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Router Class Initialized
ERROR - 2011-03-31 14:24:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 14:24:04 --> Config Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:24:04 --> URI Class Initialized
DEBUG - 2011-03-31 14:24:04 --> Router Class Initialized
ERROR - 2011-03-31 14:24:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 14:24:05 --> Config Class Initialized
DEBUG - 2011-03-31 14:24:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:24:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:24:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:24:05 --> URI Class Initialized
DEBUG - 2011-03-31 14:24:05 --> Router Class Initialized
ERROR - 2011-03-31 14:24:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 14:25:13 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:13 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:13 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Controller Class Initialized
ERROR - 2011-03-31 14:25:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:25:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:13 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:25:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:25:13 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:13 --> Total execution time: 0.0781
DEBUG - 2011-03-31 14:25:14 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:14 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:14 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Controller Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:15 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:15 --> Total execution time: 0.8283
DEBUG - 2011-03-31 14:25:25 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:25 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:25 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Controller Class Initialized
ERROR - 2011-03-31 14:25:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:25:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:25:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:25:25 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:25 --> Total execution time: 0.0528
DEBUG - 2011-03-31 14:25:26 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:26 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:26 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Controller Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:26 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:27 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:27 --> Total execution time: 0.6029
DEBUG - 2011-03-31 14:25:28 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:28 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:28 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Controller Class Initialized
ERROR - 2011-03-31 14:25:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:25:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:28 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:25:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:25:28 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:28 --> Total execution time: 0.0709
DEBUG - 2011-03-31 14:25:39 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:39 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:39 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Controller Class Initialized
ERROR - 2011-03-31 14:25:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:25:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:39 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:25:39 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:39 --> Total execution time: 0.0743
DEBUG - 2011-03-31 14:25:40 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:40 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:40 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Controller Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Config Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:25:41 --> URI Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Router Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Output Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Input Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:25:41 --> Language Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Loader Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Controller Class Initialized
ERROR - 2011-03-31 14:25:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:25:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:41 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Model Class Initialized
DEBUG - 2011-03-31 14:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:25:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:25:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:25:41 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:41 --> Total execution time: 0.0404
DEBUG - 2011-03-31 14:25:41 --> Final output sent to browser
DEBUG - 2011-03-31 14:25:41 --> Total execution time: 0.7888
DEBUG - 2011-03-31 14:27:08 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:08 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:08 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Controller Class Initialized
ERROR - 2011-03-31 14:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:27:08 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:08 --> Total execution time: 0.1240
DEBUG - 2011-03-31 14:27:09 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:09 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:09 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Controller Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:10 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:10 --> Total execution time: 1.2133
DEBUG - 2011-03-31 14:27:44 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:44 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:44 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Controller Class Initialized
ERROR - 2011-03-31 14:27:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:27:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:44 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:44 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:44 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:27:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:27:44 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:44 --> Total execution time: 0.0841
DEBUG - 2011-03-31 14:27:45 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:45 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:45 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:45 --> Controller Class Initialized
DEBUG - 2011-03-31 14:27:46 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:46 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:46 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:46 --> Total execution time: 0.7434
DEBUG - 2011-03-31 14:27:56 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:56 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:56 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Controller Class Initialized
ERROR - 2011-03-31 14:27:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:27:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:56 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:27:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:27:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:27:56 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:56 --> Total execution time: 0.0360
DEBUG - 2011-03-31 14:27:57 --> Config Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:27:57 --> URI Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Router Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Output Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Input Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:27:57 --> Language Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Loader Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Controller Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Model Class Initialized
DEBUG - 2011-03-31 14:27:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:27:57 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:27:58 --> Final output sent to browser
DEBUG - 2011-03-31 14:27:58 --> Total execution time: 1.1524
DEBUG - 2011-03-31 14:28:08 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:08 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:08 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Controller Class Initialized
ERROR - 2011-03-31 14:28:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:28:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:28:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:28:08 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:08 --> Total execution time: 0.0590
DEBUG - 2011-03-31 14:28:08 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:08 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:08 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Controller Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:09 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:09 --> Total execution time: 1.1598
DEBUG - 2011-03-31 14:28:14 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:14 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:14 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Controller Class Initialized
ERROR - 2011-03-31 14:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:28:14 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:14 --> Total execution time: 0.0474
DEBUG - 2011-03-31 14:28:35 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:35 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:35 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Controller Class Initialized
ERROR - 2011-03-31 14:28:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:28:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:35 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:28:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:28:35 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:35 --> Total execution time: 0.4361
DEBUG - 2011-03-31 14:28:36 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:36 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:36 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Controller Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:37 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:37 --> Total execution time: 0.5641
DEBUG - 2011-03-31 14:28:53 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:53 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:53 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Controller Class Initialized
ERROR - 2011-03-31 14:28:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:28:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:53 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:53 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:28:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:28:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:28:53 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:53 --> Total execution time: 0.1211
DEBUG - 2011-03-31 14:28:54 --> Config Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:28:54 --> URI Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Router Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Output Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Input Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:28:54 --> Language Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Loader Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Controller Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Model Class Initialized
DEBUG - 2011-03-31 14:28:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:28:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:28:55 --> Final output sent to browser
DEBUG - 2011-03-31 14:28:55 --> Total execution time: 0.5366
DEBUG - 2011-03-31 14:29:11 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:11 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:11 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Controller Class Initialized
ERROR - 2011-03-31 14:29:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:29:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:11 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:29:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:29:11 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:11 --> Total execution time: 0.0529
DEBUG - 2011-03-31 14:29:12 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:12 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:12 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Controller Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:13 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:13 --> Total execution time: 0.9721
DEBUG - 2011-03-31 14:29:25 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:25 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:25 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Controller Class Initialized
ERROR - 2011-03-31 14:29:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:29:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:29:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:29:25 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:25 --> Total execution time: 0.0343
DEBUG - 2011-03-31 14:29:25 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:25 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:25 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Controller Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:26 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:26 --> Total execution time: 0.5325
DEBUG - 2011-03-31 14:29:32 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:32 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:32 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Controller Class Initialized
ERROR - 2011-03-31 14:29:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:29:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:32 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:29:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:29:32 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:32 --> Total execution time: 0.0793
DEBUG - 2011-03-31 14:29:41 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:41 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:41 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Controller Class Initialized
ERROR - 2011-03-31 14:29:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:29:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:41 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:29:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:29:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:29:41 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:41 --> Total execution time: 0.0698
DEBUG - 2011-03-31 14:29:42 --> Config Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:29:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:29:42 --> URI Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Router Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Output Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Input Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:29:42 --> Language Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Loader Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Controller Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Model Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:29:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:29:42 --> Final output sent to browser
DEBUG - 2011-03-31 14:29:42 --> Total execution time: 0.5893
DEBUG - 2011-03-31 14:30:12 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:12 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:12 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Controller Class Initialized
ERROR - 2011-03-31 14:30:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:30:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:12 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:30:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:30:12 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:12 --> Total execution time: 0.1044
DEBUG - 2011-03-31 14:30:14 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:14 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:14 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Controller Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:14 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:14 --> Total execution time: 0.7464
DEBUG - 2011-03-31 14:30:23 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:23 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:23 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Controller Class Initialized
ERROR - 2011-03-31 14:30:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:30:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:23 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:30:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:30:23 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:23 --> Total execution time: 0.0575
DEBUG - 2011-03-31 14:30:24 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:24 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:24 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Controller Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:25 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:25 --> Total execution time: 0.7243
DEBUG - 2011-03-31 14:30:46 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:46 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:46 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Controller Class Initialized
ERROR - 2011-03-31 14:30:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:30:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:46 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:30:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:30:46 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:46 --> Total execution time: 0.0457
DEBUG - 2011-03-31 14:30:47 --> Config Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:30:47 --> URI Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Router Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Output Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Input Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:30:47 --> Language Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Loader Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Controller Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Model Class Initialized
DEBUG - 2011-03-31 14:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:30:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:30:48 --> Final output sent to browser
DEBUG - 2011-03-31 14:30:48 --> Total execution time: 0.7167
DEBUG - 2011-03-31 14:31:05 --> Config Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:31:05 --> URI Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Router Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Output Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Input Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:31:05 --> Language Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Loader Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Controller Class Initialized
ERROR - 2011-03-31 14:31:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:31:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:31:05 --> Model Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Model Class Initialized
DEBUG - 2011-03-31 14:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:31:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:31:05 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:31:05 --> Final output sent to browser
DEBUG - 2011-03-31 14:31:05 --> Total execution time: 0.1105
DEBUG - 2011-03-31 14:31:10 --> Config Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:31:10 --> URI Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Router Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Output Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Input Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:31:10 --> Language Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Loader Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Controller Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Model Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Model Class Initialized
DEBUG - 2011-03-31 14:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:31:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:31:11 --> Final output sent to browser
DEBUG - 2011-03-31 14:31:11 --> Total execution time: 0.6086
DEBUG - 2011-03-31 14:53:42 --> Config Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:53:42 --> URI Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Router Class Initialized
DEBUG - 2011-03-31 14:53:42 --> No URI present. Default controller set.
DEBUG - 2011-03-31 14:53:42 --> Output Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Input Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:53:42 --> Language Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Loader Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Controller Class Initialized
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 14:53:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:53:42 --> Final output sent to browser
DEBUG - 2011-03-31 14:53:42 --> Total execution time: 0.2596
DEBUG - 2011-03-31 14:53:42 --> Config Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:53:42 --> URI Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Router Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Output Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Input Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:53:42 --> Language Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Loader Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Controller Class Initialized
ERROR - 2011-03-31 14:53:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 14:53:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:53:42 --> Model Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Model Class Initialized
DEBUG - 2011-03-31 14:53:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:53:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 14:53:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:53:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:53:42 --> Final output sent to browser
DEBUG - 2011-03-31 14:53:42 --> Total execution time: 0.1812
DEBUG - 2011-03-31 14:53:45 --> Config Class Initialized
DEBUG - 2011-03-31 14:53:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:53:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:53:45 --> URI Class Initialized
DEBUG - 2011-03-31 14:53:45 --> Router Class Initialized
ERROR - 2011-03-31 14:53:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 14:53:47 --> Config Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:53:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:53:47 --> URI Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Router Class Initialized
DEBUG - 2011-03-31 14:53:47 --> No URI present. Default controller set.
DEBUG - 2011-03-31 14:53:47 --> Output Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Input Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:53:47 --> Language Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Loader Class Initialized
DEBUG - 2011-03-31 14:53:47 --> Controller Class Initialized
DEBUG - 2011-03-31 14:53:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 14:53:47 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:53:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:53:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:53:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:53:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:53:47 --> Final output sent to browser
DEBUG - 2011-03-31 14:53:47 --> Total execution time: 0.0140
DEBUG - 2011-03-31 14:53:55 --> Config Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:53:55 --> URI Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Router Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Output Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Input Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:53:55 --> Language Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Loader Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Controller Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Model Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Model Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Model Class Initialized
DEBUG - 2011-03-31 14:53:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:53:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:53:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 14:53:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:53:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:53:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:53:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:53:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:53:55 --> Final output sent to browser
DEBUG - 2011-03-31 14:53:55 --> Total execution time: 0.3027
DEBUG - 2011-03-31 14:54:24 --> Config Class Initialized
DEBUG - 2011-03-31 14:54:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:54:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:54:24 --> URI Class Initialized
DEBUG - 2011-03-31 14:54:24 --> Router Class Initialized
DEBUG - 2011-03-31 14:54:24 --> Output Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Input Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:54:25 --> Language Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Loader Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Controller Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:54:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:54:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 14:54:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:54:25 --> Final output sent to browser
DEBUG - 2011-03-31 14:54:25 --> Total execution time: 0.9625
DEBUG - 2011-03-31 14:54:35 --> Config Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:54:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:54:35 --> URI Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Router Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Output Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Input Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:54:35 --> Language Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Loader Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Controller Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:54:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:54:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 14:54:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:54:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:54:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:54:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:54:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:54:35 --> Final output sent to browser
DEBUG - 2011-03-31 14:54:35 --> Total execution time: 0.0508
DEBUG - 2011-03-31 14:54:45 --> Config Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:54:45 --> URI Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Router Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Output Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Input Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:54:45 --> Language Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Loader Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Controller Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:54:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:54:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 14:54:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:54:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:54:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:54:45 --> Final output sent to browser
DEBUG - 2011-03-31 14:54:45 --> Total execution time: 0.0789
DEBUG - 2011-03-31 14:54:48 --> Config Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:54:48 --> URI Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Router Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Output Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Input Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:54:48 --> Language Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Loader Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Controller Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Model Class Initialized
DEBUG - 2011-03-31 14:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 14:54:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 14:54:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 14:54:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:54:48 --> Final output sent to browser
DEBUG - 2011-03-31 14:54:48 --> Total execution time: 0.0846
DEBUG - 2011-03-31 14:54:49 --> Config Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 14:54:49 --> URI Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Router Class Initialized
DEBUG - 2011-03-31 14:54:49 --> No URI present. Default controller set.
DEBUG - 2011-03-31 14:54:49 --> Output Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Input Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 14:54:49 --> Language Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Loader Class Initialized
DEBUG - 2011-03-31 14:54:49 --> Controller Class Initialized
DEBUG - 2011-03-31 14:54:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 14:54:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 14:54:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 14:54:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 14:54:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 14:54:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 14:54:49 --> Final output sent to browser
DEBUG - 2011-03-31 14:54:49 --> Total execution time: 0.0140
DEBUG - 2011-03-31 15:11:19 --> Config Class Initialized
DEBUG - 2011-03-31 15:11:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:11:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:11:19 --> URI Class Initialized
DEBUG - 2011-03-31 15:11:19 --> Router Class Initialized
DEBUG - 2011-03-31 15:11:19 --> No URI present. Default controller set.
DEBUG - 2011-03-31 15:11:19 --> Output Class Initialized
DEBUG - 2011-03-31 15:11:19 --> Input Class Initialized
DEBUG - 2011-03-31 15:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:11:19 --> Language Class Initialized
DEBUG - 2011-03-31 15:11:20 --> Loader Class Initialized
DEBUG - 2011-03-31 15:11:20 --> Controller Class Initialized
DEBUG - 2011-03-31 15:11:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 15:11:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:11:20 --> Final output sent to browser
DEBUG - 2011-03-31 15:11:20 --> Total execution time: 0.9880
DEBUG - 2011-03-31 15:11:23 --> Config Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:11:23 --> URI Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Router Class Initialized
ERROR - 2011-03-31 15:11:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 15:11:23 --> Config Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:11:23 --> URI Class Initialized
DEBUG - 2011-03-31 15:11:23 --> Router Class Initialized
ERROR - 2011-03-31 15:11:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 15:11:24 --> Config Class Initialized
DEBUG - 2011-03-31 15:11:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:11:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:11:24 --> URI Class Initialized
DEBUG - 2011-03-31 15:11:24 --> Router Class Initialized
ERROR - 2011-03-31 15:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 15:11:32 --> Config Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:11:32 --> URI Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Router Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Output Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Input Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:11:32 --> Language Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Loader Class Initialized
DEBUG - 2011-03-31 15:11:32 --> Controller Class Initialized
DEBUG - 2011-03-31 15:11:33 --> Model Class Initialized
DEBUG - 2011-03-31 15:11:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:11:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:11:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:11:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:11:37 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:11:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:11:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:11:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:11:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:11:37 --> Final output sent to browser
DEBUG - 2011-03-31 15:11:37 --> Total execution time: 5.4553
DEBUG - 2011-03-31 15:12:10 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:10 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:10 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:10 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:10 --> Total execution time: 0.2167
DEBUG - 2011-03-31 15:12:12 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:12 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:12 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:12 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:12 --> Total execution time: 0.0615
DEBUG - 2011-03-31 15:12:19 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:19 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:19 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:20 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:20 --> Total execution time: 0.1847
DEBUG - 2011-03-31 15:12:22 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:22 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:22 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:22 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:22 --> Total execution time: 0.0916
DEBUG - 2011-03-31 15:12:32 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:32 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:32 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:32 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:32 --> Total execution time: 0.5565
DEBUG - 2011-03-31 15:12:34 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:34 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:34 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:34 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:34 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:34 --> Total execution time: 0.1399
DEBUG - 2011-03-31 15:12:51 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:51 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:51 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:52 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:52 --> Total execution time: 0.7944
DEBUG - 2011-03-31 15:12:58 --> Config Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:12:58 --> URI Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Router Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Output Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Input Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:12:58 --> Language Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Loader Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Controller Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Model Class Initialized
DEBUG - 2011-03-31 15:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:12:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:12:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:12:58 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:12:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:12:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:12:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:12:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:12:58 --> Final output sent to browser
DEBUG - 2011-03-31 15:12:58 --> Total execution time: 0.0516
DEBUG - 2011-03-31 15:13:06 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:06 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:06 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:06 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:06 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:06 --> Total execution time: 0.2019
DEBUG - 2011-03-31 15:13:10 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:10 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:10 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:10 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:10 --> Total execution time: 0.0859
DEBUG - 2011-03-31 15:13:20 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:20 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:20 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:21 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:21 --> Total execution time: 0.2981
DEBUG - 2011-03-31 15:13:22 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:22 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:22 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:22 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:22 --> Total execution time: 0.0534
DEBUG - 2011-03-31 15:13:34 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:34 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:34 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:35 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:35 --> Total execution time: 0.3735
DEBUG - 2011-03-31 15:13:41 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:41 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:41 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:41 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:41 --> Total execution time: 0.1732
DEBUG - 2011-03-31 15:13:50 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:50 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:50 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:50 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:50 --> Total execution time: 0.4592
DEBUG - 2011-03-31 15:13:53 --> Config Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:13:53 --> URI Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Router Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Output Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Input Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:13:53 --> Language Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Loader Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Controller Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Model Class Initialized
DEBUG - 2011-03-31 15:13:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:13:53 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:13:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:13:53 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:13:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:13:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:13:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:13:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:13:53 --> Final output sent to browser
DEBUG - 2011-03-31 15:13:53 --> Total execution time: 0.0485
DEBUG - 2011-03-31 15:14:06 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:06 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:06 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:06 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:06 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:06 --> Total execution time: 0.5835
DEBUG - 2011-03-31 15:14:08 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:08 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:08 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:08 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:08 --> Total execution time: 0.0576
DEBUG - 2011-03-31 15:14:20 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:20 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:20 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:21 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:21 --> Total execution time: 1.3738
DEBUG - 2011-03-31 15:14:32 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:32 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:32 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:32 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:32 --> Total execution time: 0.3111
DEBUG - 2011-03-31 15:14:33 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:33 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:33 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:34 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:34 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:34 --> Total execution time: 0.6094
DEBUG - 2011-03-31 15:14:45 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:45 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:45 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:46 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:46 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:46 --> Total execution time: 1.4091
DEBUG - 2011-03-31 15:14:49 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:49 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:49 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:49 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:49 --> Total execution time: 0.0961
DEBUG - 2011-03-31 15:14:50 --> Config Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:14:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:14:50 --> URI Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Router Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Output Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Input Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:14:50 --> Language Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Loader Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Controller Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Model Class Initialized
DEBUG - 2011-03-31 15:14:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:14:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:14:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:14:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:14:50 --> Final output sent to browser
DEBUG - 2011-03-31 15:14:50 --> Total execution time: 0.0445
DEBUG - 2011-03-31 15:15:01 --> Config Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:15:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:15:01 --> URI Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Router Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Output Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Input Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:15:01 --> Language Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Loader Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Controller Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:15:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:15:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:15:03 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:15:03 --> Final output sent to browser
DEBUG - 2011-03-31 15:15:03 --> Total execution time: 2.4266
DEBUG - 2011-03-31 15:15:08 --> Config Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:15:08 --> URI Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Router Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Output Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Input Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:15:08 --> Language Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Loader Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Controller Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:15:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:15:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:15:08 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:15:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:15:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:15:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:15:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:15:08 --> Final output sent to browser
DEBUG - 2011-03-31 15:15:08 --> Total execution time: 0.4946
DEBUG - 2011-03-31 15:15:19 --> Config Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:15:19 --> URI Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Router Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Output Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Input Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:15:19 --> Language Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Loader Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Controller Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:15:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:15:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:15:21 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:15:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:15:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:15:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:15:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:15:21 --> Final output sent to browser
DEBUG - 2011-03-31 15:15:21 --> Total execution time: 1.2722
DEBUG - 2011-03-31 15:15:23 --> Config Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:15:23 --> URI Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Router Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Output Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Input Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:15:23 --> Language Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Loader Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Controller Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Model Class Initialized
DEBUG - 2011-03-31 15:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:15:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:15:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:15:23 --> Final output sent to browser
DEBUG - 2011-03-31 15:15:23 --> Total execution time: 0.1354
DEBUG - 2011-03-31 15:31:39 --> Config Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:31:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:31:39 --> URI Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Router Class Initialized
DEBUG - 2011-03-31 15:31:39 --> No URI present. Default controller set.
DEBUG - 2011-03-31 15:31:39 --> Output Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Input Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:31:39 --> Language Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Loader Class Initialized
DEBUG - 2011-03-31 15:31:39 --> Controller Class Initialized
DEBUG - 2011-03-31 15:31:39 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 15:31:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:31:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:31:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:31:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:31:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:31:39 --> Final output sent to browser
DEBUG - 2011-03-31 15:31:39 --> Total execution time: 0.6239
DEBUG - 2011-03-31 15:36:33 --> Config Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:36:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:36:33 --> URI Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Router Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Output Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Input Class Initialized
DEBUG - 2011-03-31 15:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:36:33 --> Language Class Initialized
DEBUG - 2011-03-31 15:36:34 --> Loader Class Initialized
DEBUG - 2011-03-31 15:36:34 --> Controller Class Initialized
ERROR - 2011-03-31 15:36:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 15:36:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 15:36:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 15:36:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:36:34 --> Model Class Initialized
DEBUG - 2011-03-31 15:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:36:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:36:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 15:36:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:36:35 --> Final output sent to browser
DEBUG - 2011-03-31 15:36:35 --> Total execution time: 1.7778
DEBUG - 2011-03-31 15:56:37 --> Config Class Initialized
DEBUG - 2011-03-31 15:56:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:56:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:56:37 --> URI Class Initialized
DEBUG - 2011-03-31 15:56:37 --> Router Class Initialized
DEBUG - 2011-03-31 15:56:37 --> No URI present. Default controller set.
DEBUG - 2011-03-31 15:56:37 --> Output Class Initialized
DEBUG - 2011-03-31 15:56:38 --> Input Class Initialized
DEBUG - 2011-03-31 15:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:56:38 --> Language Class Initialized
DEBUG - 2011-03-31 15:56:38 --> Loader Class Initialized
DEBUG - 2011-03-31 15:56:38 --> Controller Class Initialized
DEBUG - 2011-03-31 15:56:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 15:56:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:56:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:56:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:56:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:56:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:56:38 --> Final output sent to browser
DEBUG - 2011-03-31 15:56:38 --> Total execution time: 1.3752
DEBUG - 2011-03-31 15:56:41 --> Config Class Initialized
DEBUG - 2011-03-31 15:56:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:56:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:56:41 --> URI Class Initialized
DEBUG - 2011-03-31 15:56:41 --> Router Class Initialized
ERROR - 2011-03-31 15:56:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 15:56:54 --> Config Class Initialized
DEBUG - 2011-03-31 15:56:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:56:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:56:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:56:54 --> URI Class Initialized
DEBUG - 2011-03-31 15:56:54 --> Router Class Initialized
ERROR - 2011-03-31 15:56:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 15:59:10 --> Config Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:59:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:59:10 --> URI Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Router Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Output Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Input Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:59:10 --> Language Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Loader Class Initialized
DEBUG - 2011-03-31 15:59:10 --> Controller Class Initialized
ERROR - 2011-03-31 15:59:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 15:59:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 15:59:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 15:59:10 --> Model Class Initialized
DEBUG - 2011-03-31 15:59:11 --> Model Class Initialized
DEBUG - 2011-03-31 15:59:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:59:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:59:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 15:59:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:59:11 --> Final output sent to browser
DEBUG - 2011-03-31 15:59:11 --> Total execution time: 0.5502
DEBUG - 2011-03-31 15:59:12 --> Config Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:59:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:59:12 --> URI Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Router Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Output Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Input Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:59:12 --> Language Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Loader Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Controller Class Initialized
DEBUG - 2011-03-31 15:59:12 --> Model Class Initialized
DEBUG - 2011-03-31 15:59:13 --> Model Class Initialized
DEBUG - 2011-03-31 15:59:13 --> Model Class Initialized
DEBUG - 2011-03-31 15:59:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 15:59:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 15:59:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 15:59:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:59:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:59:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:59:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:59:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:59:13 --> Final output sent to browser
DEBUG - 2011-03-31 15:59:13 --> Total execution time: 0.5217
DEBUG - 2011-03-31 15:59:20 --> Config Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 15:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 15:59:20 --> URI Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Router Class Initialized
DEBUG - 2011-03-31 15:59:20 --> No URI present. Default controller set.
DEBUG - 2011-03-31 15:59:20 --> Output Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Input Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 15:59:20 --> Language Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Loader Class Initialized
DEBUG - 2011-03-31 15:59:20 --> Controller Class Initialized
DEBUG - 2011-03-31 15:59:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 15:59:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 15:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 15:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 15:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 15:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 15:59:20 --> Final output sent to browser
DEBUG - 2011-03-31 15:59:20 --> Total execution time: 0.1160
DEBUG - 2011-03-31 16:08:30 --> Config Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:08:30 --> URI Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Router Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Output Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Input Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:08:30 --> Language Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Loader Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Controller Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:08:30 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:08:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 16:08:30 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:08:30 --> Final output sent to browser
DEBUG - 2011-03-31 16:08:30 --> Total execution time: 0.7112
DEBUG - 2011-03-31 16:08:34 --> Config Class Initialized
DEBUG - 2011-03-31 16:08:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:08:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:08:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:08:34 --> URI Class Initialized
DEBUG - 2011-03-31 16:08:34 --> Router Class Initialized
ERROR - 2011-03-31 16:08:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:08:35 --> Config Class Initialized
DEBUG - 2011-03-31 16:08:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:08:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:08:35 --> URI Class Initialized
DEBUG - 2011-03-31 16:08:35 --> Router Class Initialized
ERROR - 2011-03-31 16:08:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:08:47 --> Config Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:08:47 --> URI Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Router Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Output Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Input Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:08:47 --> Language Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Loader Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Controller Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:08:47 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:08:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 16:08:47 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:08:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:08:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:08:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:08:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:08:47 --> Final output sent to browser
DEBUG - 2011-03-31 16:08:47 --> Total execution time: 0.2039
DEBUG - 2011-03-31 16:08:48 --> Config Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:08:48 --> URI Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Router Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Output Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Input Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:08:48 --> Language Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Loader Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Controller Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:08:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:08:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:08:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 16:08:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:08:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:08:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:08:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:08:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:08:48 --> Final output sent to browser
DEBUG - 2011-03-31 16:08:48 --> Total execution time: 0.0478
DEBUG - 2011-03-31 16:23:10 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:10 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:10 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:10 --> No URI present. Default controller set.
DEBUG - 2011-03-31 16:23:11 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:11 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:11 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:11 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:11 --> Controller Class Initialized
DEBUG - 2011-03-31 16:23:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 16:23:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:23:11 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:11 --> Total execution time: 0.7637
DEBUG - 2011-03-31 16:23:13 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:13 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:13 --> Router Class Initialized
ERROR - 2011-03-31 16:23:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:23:16 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:16 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:16 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:17 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Controller Class Initialized
ERROR - 2011-03-31 16:23:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 16:23:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 16:23:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:17 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:18 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:23:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:23:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:23:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:23:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:23:18 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:18 --> Total execution time: 2.0667
DEBUG - 2011-03-31 16:23:19 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:19 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:19 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Controller Class Initialized
DEBUG - 2011-03-31 16:23:19 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:20 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:22 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:22 --> Total execution time: 3.3619
DEBUG - 2011-03-31 16:23:23 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:23 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:23 --> Router Class Initialized
ERROR - 2011-03-31 16:23:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:23:39 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:39 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:39 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Controller Class Initialized
ERROR - 2011-03-31 16:23:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 16:23:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:39 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:23:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:23:39 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:39 --> Total execution time: 0.0331
DEBUG - 2011-03-31 16:23:40 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:40 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:40 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Controller Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:40 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:40 --> Total execution time: 0.6231
DEBUG - 2011-03-31 16:23:41 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:41 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:41 --> Router Class Initialized
ERROR - 2011-03-31 16:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:23:48 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:48 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:48 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Controller Class Initialized
ERROR - 2011-03-31 16:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 16:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 16:23:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:23:48 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:48 --> Total execution time: 0.0363
DEBUG - 2011-03-31 16:23:48 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:48 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Router Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Output Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Input Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:23:48 --> Language Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Loader Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Controller Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Model Class Initialized
DEBUG - 2011-03-31 16:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 16:23:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 16:23:50 --> Final output sent to browser
DEBUG - 2011-03-31 16:23:50 --> Total execution time: 1.9971
DEBUG - 2011-03-31 16:23:51 --> Config Class Initialized
DEBUG - 2011-03-31 16:23:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:23:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:23:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:23:51 --> URI Class Initialized
DEBUG - 2011-03-31 16:23:51 --> Router Class Initialized
ERROR - 2011-03-31 16:23:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:24:45 --> Config Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:24:45 --> URI Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Router Class Initialized
DEBUG - 2011-03-31 16:24:45 --> No URI present. Default controller set.
DEBUG - 2011-03-31 16:24:45 --> Output Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Input Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:24:45 --> Language Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Loader Class Initialized
DEBUG - 2011-03-31 16:24:45 --> Controller Class Initialized
DEBUG - 2011-03-31 16:24:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 16:24:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:24:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:24:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:24:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:24:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:24:45 --> Final output sent to browser
DEBUG - 2011-03-31 16:24:45 --> Total execution time: 0.0588
DEBUG - 2011-03-31 16:24:48 --> Config Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:24:48 --> URI Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Router Class Initialized
ERROR - 2011-03-31 16:24:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:24:48 --> Config Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:24:48 --> URI Class Initialized
DEBUG - 2011-03-31 16:24:48 --> Router Class Initialized
ERROR - 2011-03-31 16:24:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 16:30:16 --> Config Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 16:30:16 --> URI Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Router Class Initialized
DEBUG - 2011-03-31 16:30:16 --> No URI present. Default controller set.
DEBUG - 2011-03-31 16:30:16 --> Output Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Input Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 16:30:16 --> Language Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Loader Class Initialized
DEBUG - 2011-03-31 16:30:16 --> Controller Class Initialized
DEBUG - 2011-03-31 16:30:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 16:30:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 16:30:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 16:30:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 16:30:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 16:30:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 16:30:16 --> Final output sent to browser
DEBUG - 2011-03-31 16:30:16 --> Total execution time: 0.1001
DEBUG - 2011-03-31 17:10:21 --> Config Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 17:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 17:10:21 --> URI Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Router Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Output Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Input Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 17:10:21 --> Language Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Loader Class Initialized
DEBUG - 2011-03-31 17:10:21 --> Controller Class Initialized
ERROR - 2011-03-31 17:10:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 17:10:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 17:10:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 17:10:22 --> Model Class Initialized
DEBUG - 2011-03-31 17:10:22 --> Model Class Initialized
DEBUG - 2011-03-31 17:10:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 17:10:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 17:10:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 17:10:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 17:10:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 17:10:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 17:10:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 17:10:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 17:10:22 --> Final output sent to browser
DEBUG - 2011-03-31 17:10:22 --> Total execution time: 0.5316
DEBUG - 2011-03-31 17:22:04 --> Config Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 17:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 17:22:04 --> URI Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Router Class Initialized
DEBUG - 2011-03-31 17:22:04 --> No URI present. Default controller set.
DEBUG - 2011-03-31 17:22:04 --> Output Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Input Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 17:22:04 --> Language Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Loader Class Initialized
DEBUG - 2011-03-31 17:22:04 --> Controller Class Initialized
DEBUG - 2011-03-31 17:22:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 17:22:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 17:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 17:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 17:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 17:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 17:22:04 --> Final output sent to browser
DEBUG - 2011-03-31 17:22:04 --> Total execution time: 0.2159
DEBUG - 2011-03-31 18:28:14 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:14 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:14 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Controller Class Initialized
ERROR - 2011-03-31 18:28:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 18:28:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:14 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:28:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:28:14 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:14 --> Total execution time: 0.3795
DEBUG - 2011-03-31 18:28:15 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:15 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:15 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Controller Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 18:28:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:28:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:28:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:28:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:28:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:28:15 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:15 --> Total execution time: 0.3104
DEBUG - 2011-03-31 18:28:16 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:16 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:16 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Controller Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:16 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:16 --> Total execution time: 0.7092
DEBUG - 2011-03-31 18:28:17 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:17 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Router Class Initialized
ERROR - 2011-03-31 18:28:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:28:17 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:17 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:17 --> Router Class Initialized
ERROR - 2011-03-31 18:28:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:28:28 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:28 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:28 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Controller Class Initialized
ERROR - 2011-03-31 18:28:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 18:28:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:28 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:28:28 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:28 --> Total execution time: 0.0376
DEBUG - 2011-03-31 18:28:28 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:28 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:28 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Controller Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:29 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:29 --> Total execution time: 0.6135
DEBUG - 2011-03-31 18:28:30 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:30 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:30 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:30 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:30 --> Router Class Initialized
ERROR - 2011-03-31 18:28:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:28:38 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:38 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:38 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Controller Class Initialized
ERROR - 2011-03-31 18:28:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 18:28:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:38 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:28:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:28:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:28:38 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:38 --> Total execution time: 0.0333
DEBUG - 2011-03-31 18:28:38 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:38 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Router Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Output Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Input Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:28:38 --> Language Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Loader Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Controller Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Model Class Initialized
DEBUG - 2011-03-31 18:28:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:28:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:28:39 --> Final output sent to browser
DEBUG - 2011-03-31 18:28:39 --> Total execution time: 0.5237
DEBUG - 2011-03-31 18:28:40 --> Config Class Initialized
DEBUG - 2011-03-31 18:28:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:28:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:28:40 --> URI Class Initialized
DEBUG - 2011-03-31 18:28:40 --> Router Class Initialized
ERROR - 2011-03-31 18:28:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:29:50 --> Config Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:29:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:29:50 --> URI Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Router Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Output Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Input Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:29:50 --> Language Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Loader Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Controller Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Model Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Model Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Model Class Initialized
DEBUG - 2011-03-31 18:29:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:29:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:29:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 18:29:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:29:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:29:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:29:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:29:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:29:50 --> Final output sent to browser
DEBUG - 2011-03-31 18:29:50 --> Total execution time: 0.0501
DEBUG - 2011-03-31 18:29:59 --> Config Class Initialized
DEBUG - 2011-03-31 18:29:59 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:29:59 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:29:59 --> URI Class Initialized
DEBUG - 2011-03-31 18:29:59 --> Router Class Initialized
ERROR - 2011-03-31 18:29:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:30:03 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:03 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:04 --> Router Class Initialized
ERROR - 2011-03-31 18:30:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:30:15 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:15 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:15 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Controller Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 18:30:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:30:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:30:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:30:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:30:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:30:15 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:15 --> Total execution time: 0.3251
DEBUG - 2011-03-31 18:30:17 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:17 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:17 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Controller Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 18:30:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:30:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:30:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:30:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:30:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:30:17 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:17 --> Total execution time: 0.0386
DEBUG - 2011-03-31 18:30:19 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:19 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:19 --> Router Class Initialized
ERROR - 2011-03-31 18:30:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:30:33 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:33 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:33 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Controller Class Initialized
ERROR - 2011-03-31 18:30:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 18:30:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 18:30:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:30:33 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:30:34 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:30:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:30:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:30:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:30:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:30:34 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:34 --> Total execution time: 0.0287
DEBUG - 2011-03-31 18:30:39 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:39 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:39 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Controller Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:39 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:39 --> Total execution time: 0.4976
DEBUG - 2011-03-31 18:30:42 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:42 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:42 --> Router Class Initialized
ERROR - 2011-03-31 18:30:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 18:30:49 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:49 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:49 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Controller Class Initialized
ERROR - 2011-03-31 18:30:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 18:30:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:30:49 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 18:30:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 18:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 18:30:49 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:49 --> Total execution time: 0.0271
DEBUG - 2011-03-31 18:30:54 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:54 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Router Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Output Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Input Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 18:30:54 --> Language Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Loader Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Controller Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Model Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 18:30:54 --> Database Driver Class Initialized
DEBUG - 2011-03-31 18:30:54 --> Final output sent to browser
DEBUG - 2011-03-31 18:30:54 --> Total execution time: 0.6096
DEBUG - 2011-03-31 18:30:58 --> Config Class Initialized
DEBUG - 2011-03-31 18:30:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 18:30:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 18:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 18:30:58 --> URI Class Initialized
DEBUG - 2011-03-31 18:30:58 --> Router Class Initialized
ERROR - 2011-03-31 18:30:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:11:41 --> Config Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:11:42 --> URI Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Router Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Output Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Input Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:11:42 --> Language Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Loader Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Controller Class Initialized
ERROR - 2011-03-31 19:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:11:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:11:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:11:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:11:42 --> Final output sent to browser
DEBUG - 2011-03-31 19:11:42 --> Total execution time: 0.4133
DEBUG - 2011-03-31 19:11:42 --> Config Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:11:42 --> URI Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Router Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Output Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Input Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:11:42 --> Language Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Loader Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Controller Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:11:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:11:43 --> Final output sent to browser
DEBUG - 2011-03-31 19:11:43 --> Total execution time: 0.5700
DEBUG - 2011-03-31 19:12:04 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:04 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Router Class Initialized
ERROR - 2011-03-31 19:12:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:12:04 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:04 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:04 --> Router Class Initialized
ERROR - 2011-03-31 19:12:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:12:07 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:07 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:07 --> Router Class Initialized
ERROR - 2011-03-31 19:12:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:12:11 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:11 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Router Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Output Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Input Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:12:11 --> Language Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Loader Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Controller Class Initialized
ERROR - 2011-03-31 19:12:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:12:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:12:11 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:12:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:12:11 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:12:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:12:11 --> Final output sent to browser
DEBUG - 2011-03-31 19:12:11 --> Total execution time: 0.0532
DEBUG - 2011-03-31 19:12:12 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:12 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Router Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Output Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Input Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:12:12 --> Language Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Loader Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Controller Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:12:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:12:13 --> Final output sent to browser
DEBUG - 2011-03-31 19:12:13 --> Total execution time: 0.8096
DEBUG - 2011-03-31 19:12:48 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:48 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Router Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Output Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Input Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:12:48 --> Language Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Loader Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Controller Class Initialized
ERROR - 2011-03-31 19:12:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:12:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:12:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:12:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:12:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:12:48 --> Final output sent to browser
DEBUG - 2011-03-31 19:12:48 --> Total execution time: 0.0318
DEBUG - 2011-03-31 19:12:49 --> Config Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:12:49 --> URI Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Router Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Output Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Input Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:12:49 --> Language Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Loader Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Controller Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Model Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:12:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:12:49 --> Final output sent to browser
DEBUG - 2011-03-31 19:12:49 --> Total execution time: 0.5824
DEBUG - 2011-03-31 19:13:07 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:07 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:07 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:07 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Controller Class Initialized
ERROR - 2011-03-31 19:13:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:13:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:07 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:07 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:07 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:13:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:13:07 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:07 --> Total execution time: 0.0312
DEBUG - 2011-03-31 19:13:08 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:08 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:08 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Controller Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:08 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:09 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:09 --> Total execution time: 0.6727
DEBUG - 2011-03-31 19:13:26 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:26 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:26 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Controller Class Initialized
ERROR - 2011-03-31 19:13:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:13:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:26 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:26 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:26 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:13:26 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:26 --> Total execution time: 0.0462
DEBUG - 2011-03-31 19:13:27 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:27 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:27 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:27 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Controller Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:27 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:27 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:27 --> Total execution time: 0.5285
DEBUG - 2011-03-31 19:13:35 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:35 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:35 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Controller Class Initialized
ERROR - 2011-03-31 19:13:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:13:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:35 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:13:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:13:35 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:35 --> Total execution time: 0.0427
DEBUG - 2011-03-31 19:13:36 --> Config Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:13:36 --> URI Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Router Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Output Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Input Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:13:36 --> Language Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Loader Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Controller Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Model Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:13:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:13:36 --> Final output sent to browser
DEBUG - 2011-03-31 19:13:36 --> Total execution time: 0.5540
DEBUG - 2011-03-31 19:14:02 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:02 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:02 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Controller Class Initialized
ERROR - 2011-03-31 19:14:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:14:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:14:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:14:02 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:02 --> Total execution time: 0.0437
DEBUG - 2011-03-31 19:14:02 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:02 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:02 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Controller Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:03 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:03 --> Total execution time: 0.5087
DEBUG - 2011-03-31 19:14:10 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:10 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:10 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:10 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Controller Class Initialized
ERROR - 2011-03-31 19:14:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:14:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:10 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:10 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:10 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:14:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:14:10 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:10 --> Total execution time: 0.0283
DEBUG - 2011-03-31 19:14:11 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:11 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:11 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Controller Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:11 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:11 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:11 --> Total execution time: 0.5302
DEBUG - 2011-03-31 19:14:20 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:20 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:20 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Controller Class Initialized
ERROR - 2011-03-31 19:14:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:14:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:14:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:14:20 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:20 --> Total execution time: 0.0331
DEBUG - 2011-03-31 19:14:20 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:20 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:20 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Controller Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:21 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:21 --> Total execution time: 0.5845
DEBUG - 2011-03-31 19:14:32 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:32 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:32 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Controller Class Initialized
ERROR - 2011-03-31 19:14:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:14:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:14:32 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:32 --> Total execution time: 0.0281
DEBUG - 2011-03-31 19:14:32 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:32 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:32 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Controller Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:33 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:33 --> Total execution time: 0.5054
DEBUG - 2011-03-31 19:14:37 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:37 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:37 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:37 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Controller Class Initialized
ERROR - 2011-03-31 19:14:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:14:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:37 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:37 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:14:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:14:38 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:38 --> Total execution time: 0.0281
DEBUG - 2011-03-31 19:14:39 --> Config Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:14:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:14:39 --> URI Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Router Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Output Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Input Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:14:39 --> Language Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Loader Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Controller Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Model Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:14:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:14:39 --> Final output sent to browser
DEBUG - 2011-03-31 19:14:39 --> Total execution time: 0.5265
DEBUG - 2011-03-31 19:15:04 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:04 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:04 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Controller Class Initialized
ERROR - 2011-03-31 19:15:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:15:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:15:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:15:04 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:04 --> Total execution time: 0.0665
DEBUG - 2011-03-31 19:15:04 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:04 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:04 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Controller Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:05 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:05 --> Total execution time: 0.7423
DEBUG - 2011-03-31 19:15:23 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:23 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:23 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Controller Class Initialized
ERROR - 2011-03-31 19:15:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:15:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:23 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:15:23 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:23 --> Total execution time: 0.0303
DEBUG - 2011-03-31 19:15:24 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:24 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:24 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Controller Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:24 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:24 --> Total execution time: 0.5618
DEBUG - 2011-03-31 19:15:29 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:29 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:29 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Controller Class Initialized
ERROR - 2011-03-31 19:15:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:15:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:29 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:29 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:29 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:15:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:15:29 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:29 --> Total execution time: 0.0612
DEBUG - 2011-03-31 19:15:30 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:30 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:30 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:30 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Controller Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:30 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:30 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:30 --> Total execution time: 0.5725
DEBUG - 2011-03-31 19:15:48 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:48 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:48 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Controller Class Initialized
ERROR - 2011-03-31 19:15:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:15:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:15:48 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:15:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:15:48 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:48 --> Total execution time: 0.0279
DEBUG - 2011-03-31 19:15:48 --> Config Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:15:48 --> URI Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Router Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Output Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Input Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:15:48 --> Language Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Loader Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Controller Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Model Class Initialized
DEBUG - 2011-03-31 19:15:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:15:48 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:15:49 --> Final output sent to browser
DEBUG - 2011-03-31 19:15:49 --> Total execution time: 0.5659
DEBUG - 2011-03-31 19:16:06 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:06 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:06 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:06 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:16:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:06 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:06 --> Total execution time: 0.5916
DEBUG - 2011-03-31 19:16:11 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:11 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:11 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:11 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:11 --> Router Class Initialized
ERROR - 2011-03-31 19:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:16:12 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:12 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Router Class Initialized
ERROR - 2011-03-31 19:16:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:16:12 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:12 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:12 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Controller Class Initialized
ERROR - 2011-03-31 19:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:12 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:12 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:12 --> Total execution time: 0.0397
DEBUG - 2011-03-31 19:16:13 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:13 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:13 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:13 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:13 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:13 --> Total execution time: 0.5329
DEBUG - 2011-03-31 19:16:18 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:18 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:18 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:18 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:16:18 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:18 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:18 --> Total execution time: 0.1928
DEBUG - 2011-03-31 19:16:24 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:24 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:24 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Controller Class Initialized
ERROR - 2011-03-31 19:16:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:24 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:24 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:24 --> Total execution time: 0.0317
DEBUG - 2011-03-31 19:16:24 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:24 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:24 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:25 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:25 --> Total execution time: 0.4669
DEBUG - 2011-03-31 19:16:31 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:31 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:31 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Controller Class Initialized
ERROR - 2011-03-31 19:16:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:16:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:31 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:31 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:31 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:31 --> Total execution time: 0.1404
DEBUG - 2011-03-31 19:16:32 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:32 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:32 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:33 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:33 --> Total execution time: 0.6226
DEBUG - 2011-03-31 19:16:38 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:38 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:38 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:38 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:16:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:38 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:38 --> Total execution time: 0.5247
DEBUG - 2011-03-31 19:16:41 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:41 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:41 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:16:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:41 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:41 --> Total execution time: 0.0530
DEBUG - 2011-03-31 19:16:41 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:41 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:41 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Controller Class Initialized
ERROR - 2011-03-31 19:16:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:16:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:41 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:41 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:16:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:16:41 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:41 --> Total execution time: 0.0362
DEBUG - 2011-03-31 19:16:42 --> Config Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:16:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:16:42 --> URI Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Router Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Output Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Input Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:16:42 --> Language Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Loader Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Controller Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Model Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:16:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:16:42 --> Final output sent to browser
DEBUG - 2011-03-31 19:16:42 --> Total execution time: 0.5089
DEBUG - 2011-03-31 19:17:01 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:01 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:01 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Controller Class Initialized
ERROR - 2011-03-31 19:17:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:17:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:17:01 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:17:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:01 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:01 --> Total execution time: 0.1345
DEBUG - 2011-03-31 19:17:02 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:02 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:02 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:03 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:03 --> Total execution time: 0.5576
DEBUG - 2011-03-31 19:17:09 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:09 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Router Class Initialized
ERROR - 2011-03-31 19:17:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 19:17:09 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:09 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:09 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Controller Class Initialized
ERROR - 2011-03-31 19:17:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:17:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:17:09 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:17:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:09 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:09 --> Total execution time: 0.0287
DEBUG - 2011-03-31 19:17:22 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:22 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:22 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:17:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:22 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:22 --> Total execution time: 0.2711
DEBUG - 2011-03-31 19:17:24 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:24 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:24 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:24 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:24 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:17:24 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:24 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:24 --> Total execution time: 0.0581
DEBUG - 2011-03-31 19:17:25 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:25 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:25 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:17:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:25 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:25 --> Total execution time: 0.0943
DEBUG - 2011-03-31 19:17:25 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:25 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:25 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:17:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:25 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:25 --> Total execution time: 0.0492
DEBUG - 2011-03-31 19:17:44 --> Config Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:17:44 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:17:44 --> URI Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Router Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Output Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Input Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:17:44 --> Language Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Loader Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Controller Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Model Class Initialized
DEBUG - 2011-03-31 19:17:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:17:44 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:17:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:17:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:17:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:17:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:17:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:17:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:17:45 --> Final output sent to browser
DEBUG - 2011-03-31 19:17:45 --> Total execution time: 0.4424
DEBUG - 2011-03-31 19:18:04 --> Config Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:18:04 --> URI Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Router Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Output Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Input Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:18:04 --> Language Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Loader Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Controller Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:18:04 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:18:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:18:04 --> Final output sent to browser
DEBUG - 2011-03-31 19:18:04 --> Total execution time: 0.0559
DEBUG - 2011-03-31 19:18:16 --> Config Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:18:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:18:16 --> URI Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Router Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Output Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Input Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:18:16 --> Language Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Loader Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Controller Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:18:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:18:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:18:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:18:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:18:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:18:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:18:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:18:16 --> Final output sent to browser
DEBUG - 2011-03-31 19:18:16 --> Total execution time: 0.1835
DEBUG - 2011-03-31 19:18:20 --> Config Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:18:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:18:20 --> URI Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Router Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Output Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Input Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:18:20 --> Language Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Loader Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Controller Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:18:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:18:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:18:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:18:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:18:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:18:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:18:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:18:20 --> Final output sent to browser
DEBUG - 2011-03-31 19:18:20 --> Total execution time: 0.0524
DEBUG - 2011-03-31 19:18:28 --> Config Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:18:28 --> URI Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Router Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Output Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Input Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:18:28 --> Language Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Loader Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Controller Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Model Class Initialized
DEBUG - 2011-03-31 19:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:18:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:18:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 19:18:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:18:28 --> Final output sent to browser
DEBUG - 2011-03-31 19:18:28 --> Total execution time: 0.2367
DEBUG - 2011-03-31 19:29:00 --> Config Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:29:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:29:00 --> URI Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Router Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Output Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Input Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:29:00 --> Language Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Loader Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Controller Class Initialized
ERROR - 2011-03-31 19:29:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:29:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:29:00 --> Model Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Model Class Initialized
DEBUG - 2011-03-31 19:29:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:29:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:29:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:29:01 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:29:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:29:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:29:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:29:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:29:01 --> Final output sent to browser
DEBUG - 2011-03-31 19:29:01 --> Total execution time: 0.7339
DEBUG - 2011-03-31 19:29:01 --> Config Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:29:01 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:29:01 --> URI Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Router Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Output Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Input Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:29:01 --> Language Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Loader Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Controller Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Model Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Model Class Initialized
DEBUG - 2011-03-31 19:29:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:29:01 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:29:02 --> Final output sent to browser
DEBUG - 2011-03-31 19:29:02 --> Total execution time: 0.7247
DEBUG - 2011-03-31 19:29:17 --> Config Class Initialized
DEBUG - 2011-03-31 19:29:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:29:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:29:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:29:17 --> URI Class Initialized
DEBUG - 2011-03-31 19:29:17 --> Router Class Initialized
ERROR - 2011-03-31 19:29:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:29:19 --> Config Class Initialized
DEBUG - 2011-03-31 19:29:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:29:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:29:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:29:19 --> URI Class Initialized
DEBUG - 2011-03-31 19:29:19 --> Router Class Initialized
ERROR - 2011-03-31 19:29:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 19:31:15 --> Config Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:31:15 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:31:15 --> URI Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Router Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Output Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Input Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:31:15 --> Language Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Loader Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Controller Class Initialized
ERROR - 2011-03-31 19:31:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:31:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:31:15 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:31:15 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:31:15 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:31:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:31:15 --> Final output sent to browser
DEBUG - 2011-03-31 19:31:15 --> Total execution time: 0.1394
DEBUG - 2011-03-31 19:31:16 --> Config Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:31:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:31:16 --> URI Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Router Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Output Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Input Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:31:16 --> Language Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Loader Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Controller Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:31:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:31:16 --> Final output sent to browser
DEBUG - 2011-03-31 19:31:16 --> Total execution time: 0.6053
DEBUG - 2011-03-31 19:31:25 --> Config Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:31:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:31:25 --> URI Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Router Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Output Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Input Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:31:25 --> Language Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Loader Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Controller Class Initialized
ERROR - 2011-03-31 19:31:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 19:31:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:31:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:31:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 19:31:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 19:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 19:31:25 --> Final output sent to browser
DEBUG - 2011-03-31 19:31:25 --> Total execution time: 0.0281
DEBUG - 2011-03-31 19:31:26 --> Config Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 19:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 19:31:26 --> URI Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Router Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Output Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Input Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 19:31:26 --> Language Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Loader Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Controller Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Model Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 19:31:26 --> Database Driver Class Initialized
DEBUG - 2011-03-31 19:31:26 --> Final output sent to browser
DEBUG - 2011-03-31 19:31:26 --> Total execution time: 0.5722
DEBUG - 2011-03-31 20:10:38 --> Config Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:10:38 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:10:38 --> URI Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Router Class Initialized
DEBUG - 2011-03-31 20:10:38 --> No URI present. Default controller set.
DEBUG - 2011-03-31 20:10:38 --> Output Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Input Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:10:38 --> Language Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Loader Class Initialized
DEBUG - 2011-03-31 20:10:38 --> Controller Class Initialized
DEBUG - 2011-03-31 20:10:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 20:10:38 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:10:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 20:10:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 20:10:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 20:10:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 20:10:38 --> Final output sent to browser
DEBUG - 2011-03-31 20:10:38 --> Total execution time: 0.2093
DEBUG - 2011-03-31 20:10:40 --> Config Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:10:40 --> URI Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Router Class Initialized
ERROR - 2011-03-31 20:10:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 20:10:40 --> Config Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:10:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:10:40 --> URI Class Initialized
DEBUG - 2011-03-31 20:10:40 --> Router Class Initialized
ERROR - 2011-03-31 20:10:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 20:10:42 --> Config Class Initialized
DEBUG - 2011-03-31 20:10:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:10:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:10:42 --> URI Class Initialized
DEBUG - 2011-03-31 20:10:42 --> Router Class Initialized
ERROR - 2011-03-31 20:10:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 20:35:34 --> Config Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:35:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:35:34 --> URI Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Router Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Output Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Input Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:35:34 --> Language Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Loader Class Initialized
DEBUG - 2011-03-31 20:35:34 --> Controller Class Initialized
ERROR - 2011-03-31 20:35:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 20:35:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 20:35:35 --> Model Class Initialized
DEBUG - 2011-03-31 20:35:35 --> Model Class Initialized
DEBUG - 2011-03-31 20:35:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 20:35:35 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 20:35:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 20:35:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 20:35:35 --> Final output sent to browser
DEBUG - 2011-03-31 20:35:35 --> Total execution time: 0.3669
DEBUG - 2011-03-31 20:36:34 --> Config Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:36:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:36:34 --> URI Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Router Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Output Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Input Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:36:34 --> Language Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Loader Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Controller Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Model Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Model Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Model Class Initialized
DEBUG - 2011-03-31 20:36:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 20:36:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 20:36:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 20:36:35 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:36:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 20:36:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 20:36:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 20:36:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 20:36:35 --> Final output sent to browser
DEBUG - 2011-03-31 20:36:35 --> Total execution time: 0.9791
DEBUG - 2011-03-31 20:53:40 --> Config Class Initialized
DEBUG - 2011-03-31 20:53:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:53:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:53:40 --> URI Class Initialized
DEBUG - 2011-03-31 20:53:40 --> Router Class Initialized
DEBUG - 2011-03-31 20:53:40 --> No URI present. Default controller set.
DEBUG - 2011-03-31 20:53:41 --> Output Class Initialized
DEBUG - 2011-03-31 20:53:41 --> Input Class Initialized
DEBUG - 2011-03-31 20:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 20:53:41 --> Language Class Initialized
DEBUG - 2011-03-31 20:53:41 --> Loader Class Initialized
DEBUG - 2011-03-31 20:53:41 --> Controller Class Initialized
DEBUG - 2011-03-31 20:53:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 20:53:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 20:53:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 20:53:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 20:53:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 20:53:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 20:53:41 --> Final output sent to browser
DEBUG - 2011-03-31 20:53:41 --> Total execution time: 0.3176
DEBUG - 2011-03-31 20:53:43 --> Config Class Initialized
DEBUG - 2011-03-31 20:53:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 20:53:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 20:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 20:53:43 --> URI Class Initialized
DEBUG - 2011-03-31 20:53:43 --> Router Class Initialized
ERROR - 2011-03-31 20:53:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:28:23 --> Config Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:28:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:28:23 --> URI Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Router Class Initialized
DEBUG - 2011-03-31 21:28:23 --> No URI present. Default controller set.
DEBUG - 2011-03-31 21:28:23 --> Output Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Input Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:28:23 --> Language Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Loader Class Initialized
DEBUG - 2011-03-31 21:28:23 --> Controller Class Initialized
DEBUG - 2011-03-31 21:28:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 21:28:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:28:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:28:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:28:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:28:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:28:23 --> Final output sent to browser
DEBUG - 2011-03-31 21:28:23 --> Total execution time: 0.2309
DEBUG - 2011-03-31 21:28:25 --> Config Class Initialized
DEBUG - 2011-03-31 21:28:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:28:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:28:25 --> URI Class Initialized
DEBUG - 2011-03-31 21:28:25 --> Router Class Initialized
ERROR - 2011-03-31 21:28:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:28:31 --> Config Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:28:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:28:31 --> URI Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Router Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Output Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Input Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:28:31 --> Language Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Loader Class Initialized
DEBUG - 2011-03-31 21:28:31 --> Controller Class Initialized
ERROR - 2011-03-31 21:28:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:28:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:28:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:28:32 --> Model Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Model Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:28:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:28:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:28:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:28:32 --> Final output sent to browser
DEBUG - 2011-03-31 21:28:32 --> Total execution time: 0.5935
DEBUG - 2011-03-31 21:28:32 --> Config Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:28:32 --> URI Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Router Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Output Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Input Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:28:32 --> Language Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Loader Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Controller Class Initialized
DEBUG - 2011-03-31 21:28:32 --> Model Class Initialized
DEBUG - 2011-03-31 21:28:33 --> Model Class Initialized
DEBUG - 2011-03-31 21:28:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:28:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:28:33 --> Final output sent to browser
DEBUG - 2011-03-31 21:28:33 --> Total execution time: 0.6006
DEBUG - 2011-03-31 21:28:36 --> Config Class Initialized
DEBUG - 2011-03-31 21:28:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:28:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:28:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:28:36 --> URI Class Initialized
DEBUG - 2011-03-31 21:28:36 --> Router Class Initialized
ERROR - 2011-03-31 21:28:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:52:22 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:22 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:22 --> No URI present. Default controller set.
DEBUG - 2011-03-31 21:52:22 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:22 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:22 --> Controller Class Initialized
DEBUG - 2011-03-31 21:52:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 21:52:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:52:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:52:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:52:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:52:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:52:22 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:22 --> Total execution time: 0.1742
DEBUG - 2011-03-31 21:52:23 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:23 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:23 --> Router Class Initialized
ERROR - 2011-03-31 21:52:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:52:25 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:25 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:25 --> Router Class Initialized
ERROR - 2011-03-31 21:52:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:52:53 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:53 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:53 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:53 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Controller Class Initialized
ERROR - 2011-03-31 21:52:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:52:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:52:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:52:54 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:54 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:54 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:54 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:54 --> Controller Class Initialized
DEBUG - 2011-03-31 21:52:55 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:52:55 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:55 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:52:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:52:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:52:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:52:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:52:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:52:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:52:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:52:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:52:55 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:55 --> Total execution time: 2.0188
DEBUG - 2011-03-31 21:52:56 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:56 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:56 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Controller Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:52:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:52:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 21:52:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:52:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:52:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:52:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:52:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:52:56 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:56 --> Total execution time: 2.1267
DEBUG - 2011-03-31 21:52:56 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:56 --> Total execution time: 0.7578
DEBUG - 2011-03-31 21:52:57 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:57 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:57 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Controller Class Initialized
ERROR - 2011-03-31 21:52:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:52:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:52:57 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:52:57 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:52:57 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:52:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:52:57 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:57 --> Total execution time: 0.0293
DEBUG - 2011-03-31 21:52:57 --> Config Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:52:57 --> URI Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Router Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Output Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Input Class Initialized
DEBUG - 2011-03-31 21:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:52:57 --> Language Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Loader Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Controller Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Model Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:52:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:52:58 --> Final output sent to browser
DEBUG - 2011-03-31 21:52:58 --> Total execution time: 0.7536
DEBUG - 2011-03-31 21:53:20 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:20 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:20 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Controller Class Initialized
ERROR - 2011-03-31 21:53:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:53:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:20 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:20 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:20 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:53:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:53:20 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:20 --> Total execution time: 0.0287
DEBUG - 2011-03-31 21:53:21 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:21 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:21 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Controller Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:21 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:21 --> Total execution time: 0.5149
DEBUG - 2011-03-31 21:53:22 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:22 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:22 --> Router Class Initialized
ERROR - 2011-03-31 21:53:22 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-03-31 21:53:23 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:23 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:23 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Controller Class Initialized
ERROR - 2011-03-31 21:53:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:53:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:53:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:53:23 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:23 --> Total execution time: 0.0492
DEBUG - 2011-03-31 21:53:33 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:33 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:33 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Controller Class Initialized
ERROR - 2011-03-31 21:53:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:53:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:33 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:33 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:53:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:53:33 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:33 --> Total execution time: 0.0375
DEBUG - 2011-03-31 21:53:34 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:34 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:34 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:34 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Controller Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:34 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:34 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:34 --> Total execution time: 0.5918
DEBUG - 2011-03-31 21:53:43 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:43 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:43 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Controller Class Initialized
ERROR - 2011-03-31 21:53:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:53:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:43 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:53:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:53:43 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:43 --> Total execution time: 0.0343
DEBUG - 2011-03-31 21:53:43 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:43 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:43 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Controller Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:44 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:44 --> Total execution time: 0.6007
DEBUG - 2011-03-31 21:53:56 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:56 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:56 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Controller Class Initialized
ERROR - 2011-03-31 21:53:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:53:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:53:56 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:53:56 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:56 --> Total execution time: 0.0549
DEBUG - 2011-03-31 21:53:56 --> Config Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:53:56 --> URI Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Router Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Output Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Input Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:53:56 --> Language Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Loader Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Controller Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Model Class Initialized
DEBUG - 2011-03-31 21:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:53:56 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:53:57 --> Final output sent to browser
DEBUG - 2011-03-31 21:53:57 --> Total execution time: 0.8842
DEBUG - 2011-03-31 21:54:05 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:05 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:05 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Controller Class Initialized
ERROR - 2011-03-31 21:54:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:54:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:05 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:05 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:54:05 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:05 --> Total execution time: 0.0290
DEBUG - 2011-03-31 21:54:05 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:05 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:05 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Controller Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:05 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:06 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:06 --> Total execution time: 0.5331
DEBUG - 2011-03-31 21:54:12 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:12 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:12 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Controller Class Initialized
ERROR - 2011-03-31 21:54:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:54:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:12 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:54:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:54:12 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:12 --> Total execution time: 0.0268
DEBUG - 2011-03-31 21:54:12 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:12 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:12 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Controller Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:13 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:13 --> Total execution time: 0.4975
DEBUG - 2011-03-31 21:54:16 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:16 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:16 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Controller Class Initialized
ERROR - 2011-03-31 21:54:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:54:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:16 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:16 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:54:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:54:16 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:16 --> Total execution time: 0.0283
DEBUG - 2011-03-31 21:54:16 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:16 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:16 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:16 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Controller Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:16 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:17 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:17 --> Total execution time: 0.5449
DEBUG - 2011-03-31 21:54:23 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:23 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:23 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Controller Class Initialized
ERROR - 2011-03-31 21:54:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:54:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:54:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:54:23 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:23 --> Total execution time: 0.1000
DEBUG - 2011-03-31 21:54:23 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:23 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:23 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Controller Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:24 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:24 --> Total execution time: 0.5709
DEBUG - 2011-03-31 21:54:28 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:28 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:28 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Controller Class Initialized
ERROR - 2011-03-31 21:54:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:54:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:28 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:54:28 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:54:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:54:28 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:28 --> Total execution time: 0.0311
DEBUG - 2011-03-31 21:54:28 --> Config Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:54:28 --> URI Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Router Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Output Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Input Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:54:28 --> Language Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Loader Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Controller Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Model Class Initialized
DEBUG - 2011-03-31 21:54:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:54:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:54:29 --> Final output sent to browser
DEBUG - 2011-03-31 21:54:29 --> Total execution time: 0.4805
DEBUG - 2011-03-31 21:57:45 --> Config Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:57:45 --> URI Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Router Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Output Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Input Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:57:45 --> Language Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Loader Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Controller Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Model Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Model Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Model Class Initialized
DEBUG - 2011-03-31 21:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:57:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:57:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 21:57:45 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:57:45 --> Final output sent to browser
DEBUG - 2011-03-31 21:57:45 --> Total execution time: 0.0999
DEBUG - 2011-03-31 21:57:48 --> Config Class Initialized
DEBUG - 2011-03-31 21:57:48 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:57:48 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:57:48 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:57:48 --> URI Class Initialized
DEBUG - 2011-03-31 21:57:48 --> Router Class Initialized
ERROR - 2011-03-31 21:57:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 21:59:22 --> Config Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 21:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 21:59:22 --> URI Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Router Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Output Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Input Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 21:59:22 --> Language Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Loader Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Controller Class Initialized
ERROR - 2011-03-31 21:59:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 21:59:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:59:22 --> Model Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Model Class Initialized
DEBUG - 2011-03-31 21:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 21:59:22 --> Database Driver Class Initialized
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 21:59:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 21:59:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 21:59:22 --> Final output sent to browser
DEBUG - 2011-03-31 21:59:22 --> Total execution time: 0.0733
DEBUG - 2011-03-31 22:00:55 --> Config Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:00:55 --> URI Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Router Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Output Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Input Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:00:55 --> Language Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Loader Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Controller Class Initialized
ERROR - 2011-03-31 22:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 22:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 22:00:55 --> Model Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Model Class Initialized
DEBUG - 2011-03-31 22:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:00:55 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 22:00:55 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:00:55 --> Final output sent to browser
DEBUG - 2011-03-31 22:00:55 --> Total execution time: 0.0770
DEBUG - 2011-03-31 22:00:58 --> Config Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:00:58 --> URI Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Router Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Output Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Input Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:00:58 --> Language Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Loader Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Controller Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Model Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Model Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:00:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:00:58 --> Final output sent to browser
DEBUG - 2011-03-31 22:00:58 --> Total execution time: 0.4688
DEBUG - 2011-03-31 22:01:05 --> Config Class Initialized
DEBUG - 2011-03-31 22:01:05 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:01:05 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:01:05 --> URI Class Initialized
DEBUG - 2011-03-31 22:01:05 --> Router Class Initialized
ERROR - 2011-03-31 22:01:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 22:01:08 --> Config Class Initialized
DEBUG - 2011-03-31 22:01:08 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:01:08 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:01:08 --> URI Class Initialized
DEBUG - 2011-03-31 22:01:08 --> Router Class Initialized
ERROR - 2011-03-31 22:01:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 22:03:17 --> Config Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:03:17 --> URI Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Router Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Output Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Input Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:03:17 --> Language Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Loader Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Controller Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:03:17 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:03:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:03:17 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:03:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:03:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:03:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:03:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:03:17 --> Final output sent to browser
DEBUG - 2011-03-31 22:03:17 --> Total execution time: 0.2100
DEBUG - 2011-03-31 22:03:18 --> Config Class Initialized
DEBUG - 2011-03-31 22:03:18 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:03:18 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:03:18 --> URI Class Initialized
DEBUG - 2011-03-31 22:03:18 --> Router Class Initialized
ERROR - 2011-03-31 22:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 22:03:21 --> Config Class Initialized
DEBUG - 2011-03-31 22:03:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:03:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:03:21 --> URI Class Initialized
DEBUG - 2011-03-31 22:03:21 --> Router Class Initialized
ERROR - 2011-03-31 22:03:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 22:03:25 --> Config Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:03:25 --> URI Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Router Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Output Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Input Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:03:25 --> Language Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Loader Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Controller Class Initialized
ERROR - 2011-03-31 22:03:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 22:03:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 22:03:25 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:03:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 22:03:25 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:03:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:03:25 --> Final output sent to browser
DEBUG - 2011-03-31 22:03:25 --> Total execution time: 0.0344
DEBUG - 2011-03-31 22:03:25 --> Config Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:03:25 --> URI Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Router Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Output Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Input Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:03:25 --> Language Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Loader Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Controller Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Model Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:03:25 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:03:25 --> Final output sent to browser
DEBUG - 2011-03-31 22:03:25 --> Total execution time: 0.4909
DEBUG - 2011-03-31 22:13:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:13:50 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:13:50 --> URI Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Router Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Output Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Input Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:13:50 --> Language Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Loader Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Controller Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Model Class Initialized
DEBUG - 2011-03-31 22:13:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:13:50 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:13:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:13:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:13:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:13:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:13:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:13:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:13:50 --> Final output sent to browser
DEBUG - 2011-03-31 22:13:50 --> Total execution time: 0.5074
DEBUG - 2011-03-31 22:15:42 --> Config Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:15:42 --> URI Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Router Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Output Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Input Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:15:42 --> Language Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Loader Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Controller Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:15:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:15:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:15:42 --> Final output sent to browser
DEBUG - 2011-03-31 22:15:42 --> Total execution time: 0.3942
DEBUG - 2011-03-31 22:39:33 --> Config Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:39:33 --> URI Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Router Class Initialized
DEBUG - 2011-03-31 22:39:33 --> No URI present. Default controller set.
DEBUG - 2011-03-31 22:39:33 --> Output Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Input Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:39:33 --> Language Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Loader Class Initialized
DEBUG - 2011-03-31 22:39:33 --> Controller Class Initialized
DEBUG - 2011-03-31 22:39:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-03-31 22:39:33 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:39:33 --> Final output sent to browser
DEBUG - 2011-03-31 22:39:33 --> Total execution time: 0.2930
DEBUG - 2011-03-31 22:39:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:39:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:39:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:39:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:39:49 --> URI Class Initialized
DEBUG - 2011-03-31 22:39:49 --> Router Class Initialized
ERROR - 2011-03-31 22:39:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-03-31 22:40:12 --> Config Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:40:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:40:12 --> URI Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Router Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Output Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Input Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:40:12 --> Language Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Loader Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Controller Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:40:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:40:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:40:12 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:40:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:40:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:40:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:40:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:40:12 --> Final output sent to browser
DEBUG - 2011-03-31 22:40:12 --> Total execution time: 0.3552
DEBUG - 2011-03-31 22:40:45 --> Config Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:40:45 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:40:45 --> URI Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Router Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Output Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Input Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:40:45 --> Language Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Loader Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Controller Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Model Class Initialized
DEBUG - 2011-03-31 22:40:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:40:45 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:40:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:40:46 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:40:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:40:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:40:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:40:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:40:46 --> Final output sent to browser
DEBUG - 2011-03-31 22:40:46 --> Total execution time: 0.3388
DEBUG - 2011-03-31 22:41:09 --> Config Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:41:09 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:41:09 --> URI Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Router Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Output Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Input Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:41:09 --> Language Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Loader Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Controller Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:41:09 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:41:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:41:09 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:41:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:41:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:41:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:41:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:41:09 --> Final output sent to browser
DEBUG - 2011-03-31 22:41:09 --> Total execution time: 0.2002
DEBUG - 2011-03-31 22:41:31 --> Config Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:41:31 --> URI Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Router Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Output Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Input Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:41:31 --> Language Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Loader Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Controller Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:41:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:41:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:41:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:41:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:41:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:41:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:41:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:41:32 --> Final output sent to browser
DEBUG - 2011-03-31 22:41:32 --> Total execution time: 1.1669
DEBUG - 2011-03-31 22:41:57 --> Config Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:41:57 --> URI Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Router Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Output Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Input Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:41:57 --> Language Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Loader Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Controller Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Model Class Initialized
DEBUG - 2011-03-31 22:41:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:41:57 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:41:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:41:57 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:41:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:41:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:41:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:41:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:41:57 --> Final output sent to browser
DEBUG - 2011-03-31 22:41:57 --> Total execution time: 0.4452
DEBUG - 2011-03-31 22:42:22 --> Config Class Initialized
DEBUG - 2011-03-31 22:42:22 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:42:22 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:42:22 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:42:22 --> URI Class Initialized
DEBUG - 2011-03-31 22:42:22 --> Router Class Initialized
DEBUG - 2011-03-31 22:42:22 --> Output Class Initialized
DEBUG - 2011-03-31 22:42:22 --> Input Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:42:23 --> Language Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Loader Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Controller Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:42:23 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:42:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:42:23 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:42:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:42:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:42:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:42:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:42:23 --> Final output sent to browser
DEBUG - 2011-03-31 22:42:23 --> Total execution time: 0.0564
DEBUG - 2011-03-31 22:42:36 --> Config Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:42:36 --> URI Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Router Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Output Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Input Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:42:36 --> Language Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Loader Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Controller Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:42:36 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:42:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:42:36 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:42:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:42:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:42:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:42:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:42:36 --> Final output sent to browser
DEBUG - 2011-03-31 22:42:36 --> Total execution time: 0.2068
DEBUG - 2011-03-31 22:42:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:42:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:42:49 --> URI Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Router Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Output Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Input Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:42:49 --> Language Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Loader Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Controller Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:42:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:42:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:42:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:42:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:42:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:42:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:42:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:42:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:42:49 --> Final output sent to browser
DEBUG - 2011-03-31 22:42:49 --> Total execution time: 0.1929
DEBUG - 2011-03-31 22:43:26 --> Config Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:43:26 --> URI Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Router Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Output Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Input Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:43:26 --> Language Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Loader Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Controller Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:43:26 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:43:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:43:27 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:43:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:43:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:43:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:43:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:43:27 --> Final output sent to browser
DEBUG - 2011-03-31 22:43:27 --> Total execution time: 0.5945
DEBUG - 2011-03-31 22:43:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:43:49 --> URI Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Router Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Output Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Input Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:43:49 --> Language Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Loader Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Controller Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:43:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:43:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:43:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:43:49 --> Final output sent to browser
DEBUG - 2011-03-31 22:43:49 --> Total execution time: 0.3076
DEBUG - 2011-03-31 22:44:02 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:02 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:02 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:02 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:02 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:02 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:02 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:02 --> Total execution time: 0.2339
DEBUG - 2011-03-31 22:44:19 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:19 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:19 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:19 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:19 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:19 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:19 --> Total execution time: 0.2829
DEBUG - 2011-03-31 22:44:29 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:29 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:29 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:29 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:29 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:29 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:29 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:29 --> Total execution time: 0.0502
DEBUG - 2011-03-31 22:44:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:49 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:49 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:50 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:50 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:50 --> Total execution time: 0.2604
DEBUG - 2011-03-31 22:44:51 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:51 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:51 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:51 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:51 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:51 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:51 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:51 --> Total execution time: 0.0483
DEBUG - 2011-03-31 22:44:52 --> Config Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:44:52 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:44:52 --> URI Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Router Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Output Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Input Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:44:52 --> Language Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Loader Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Controller Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Model Class Initialized
DEBUG - 2011-03-31 22:44:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:44:52 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:44:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:44:52 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:44:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:44:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:44:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:44:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:44:52 --> Final output sent to browser
DEBUG - 2011-03-31 22:44:52 --> Total execution time: 0.0446
DEBUG - 2011-03-31 22:45:03 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:03 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:03 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:03 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:03 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:04 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:04 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:04 --> Total execution time: 0.8678
DEBUG - 2011-03-31 22:45:06 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:06 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:06 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:06 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:06 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:06 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:06 --> Total execution time: 0.0449
DEBUG - 2011-03-31 22:45:12 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:12 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:12 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:12 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:13 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:13 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:13 --> Total execution time: 0.1923
DEBUG - 2011-03-31 22:45:14 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:14 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:14 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:14 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:14 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:14 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:14 --> Total execution time: 0.0515
DEBUG - 2011-03-31 22:45:28 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:28 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:28 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:28 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:28 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:29 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:29 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:29 --> Total execution time: 0.2739
DEBUG - 2011-03-31 22:45:31 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:31 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:31 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:31 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:31 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:31 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:31 --> Total execution time: 0.0882
DEBUG - 2011-03-31 22:45:40 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:40 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:40 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:41 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:41 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:41 --> Total execution time: 0.3630
DEBUG - 2011-03-31 22:45:42 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:42 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:42 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:42 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:42 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:42 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:42 --> Total execution time: 0.0593
DEBUG - 2011-03-31 22:45:43 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:43 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:43 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:43 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:43 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:43 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:43 --> Total execution time: 0.0479
DEBUG - 2011-03-31 22:45:58 --> Config Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:45:58 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:45:58 --> URI Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Router Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Output Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Input Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:45:58 --> Language Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Loader Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Controller Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Model Class Initialized
DEBUG - 2011-03-31 22:45:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:45:58 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:45:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:45:58 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:45:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:45:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:45:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:45:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:45:58 --> Final output sent to browser
DEBUG - 2011-03-31 22:45:58 --> Total execution time: 0.2617
DEBUG - 2011-03-31 22:46:00 --> Config Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:46:00 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:46:00 --> URI Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Router Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Output Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Input Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:46:00 --> Language Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Loader Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Controller Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:46:00 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:46:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:46:00 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:46:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:46:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:46:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:46:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:46:00 --> Final output sent to browser
DEBUG - 2011-03-31 22:46:00 --> Total execution time: 0.0575
DEBUG - 2011-03-31 22:46:21 --> Config Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:46:21 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:46:21 --> URI Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Router Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Output Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Input Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:46:21 --> Language Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Loader Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Controller Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:46:21 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:46:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:46:22 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:46:22 --> Final output sent to browser
DEBUG - 2011-03-31 22:46:22 --> Total execution time: 0.3319
DEBUG - 2011-03-31 22:46:31 --> Config Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:46:32 --> URI Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Router Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Output Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Input Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:46:32 --> Language Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Loader Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Controller Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:46:32 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:46:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:46:32 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:46:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:46:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:46:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:46:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:46:32 --> Final output sent to browser
DEBUG - 2011-03-31 22:46:32 --> Total execution time: 1.0436
DEBUG - 2011-03-31 22:46:49 --> Config Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Hooks Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Utf8 Class Initialized
DEBUG - 2011-03-31 22:46:49 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 22:46:49 --> URI Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Router Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Output Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Input Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 22:46:49 --> Language Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Loader Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Controller Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Model Class Initialized
DEBUG - 2011-03-31 22:46:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 22:46:49 --> Database Driver Class Initialized
DEBUG - 2011-03-31 22:46:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-03-31 22:46:49 --> Helper loaded: url_helper
DEBUG - 2011-03-31 22:46:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 22:46:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 22:46:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 22:46:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 22:46:49 --> Final output sent to browser
DEBUG - 2011-03-31 22:46:49 --> Total execution time: 0.1666
DEBUG - 2011-03-31 23:59:39 --> Config Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Hooks Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Utf8 Class Initialized
DEBUG - 2011-03-31 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 23:59:39 --> URI Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Router Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Output Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Input Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 23:59:39 --> Language Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Loader Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Controller Class Initialized
ERROR - 2011-03-31 23:59:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-03-31 23:59:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 23:59:39 --> Model Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Model Class Initialized
DEBUG - 2011-03-31 23:59:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 23:59:39 --> Database Driver Class Initialized
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-03-31 23:59:39 --> Helper loaded: url_helper
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-03-31 23:59:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-03-31 23:59:39 --> Final output sent to browser
DEBUG - 2011-03-31 23:59:39 --> Total execution time: 0.4077
DEBUG - 2011-03-31 23:59:40 --> Config Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Hooks Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Utf8 Class Initialized
DEBUG - 2011-03-31 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 23:59:40 --> URI Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Router Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Output Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Input Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-03-31 23:59:40 --> Language Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Loader Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Controller Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Model Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Model Class Initialized
DEBUG - 2011-03-31 23:59:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-03-31 23:59:40 --> Database Driver Class Initialized
DEBUG - 2011-03-31 23:59:41 --> Final output sent to browser
DEBUG - 2011-03-31 23:59:41 --> Total execution time: 0.7603
DEBUG - 2011-03-31 23:59:41 --> Config Class Initialized
DEBUG - 2011-03-31 23:59:41 --> Hooks Class Initialized
DEBUG - 2011-03-31 23:59:41 --> Utf8 Class Initialized
DEBUG - 2011-03-31 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2011-03-31 23:59:41 --> URI Class Initialized
DEBUG - 2011-03-31 23:59:41 --> Router Class Initialized
ERROR - 2011-03-31 23:59:41 --> 404 Page Not Found --> favicon.ico

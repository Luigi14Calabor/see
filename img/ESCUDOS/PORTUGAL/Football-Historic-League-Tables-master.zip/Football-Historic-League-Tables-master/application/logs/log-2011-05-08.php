<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-08 01:07:14 --> Config Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Hooks Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Utf8 Class Initialized
DEBUG - 2011-05-08 01:07:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 01:07:14 --> URI Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Router Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Output Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Input Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 01:07:14 --> Language Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Loader Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Controller Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Model Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Model Class Initialized
DEBUG - 2011-05-08 01:07:14 --> Model Class Initialized
DEBUG - 2011-05-08 01:07:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 01:07:15 --> Database Driver Class Initialized
DEBUG - 2011-05-08 01:07:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 01:07:18 --> Helper loaded: url_helper
DEBUG - 2011-05-08 01:07:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 01:07:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 01:07:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 01:07:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 01:07:18 --> Final output sent to browser
DEBUG - 2011-05-08 01:07:18 --> Total execution time: 4.7179
DEBUG - 2011-05-08 02:07:06 --> Config Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 02:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 02:07:06 --> URI Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Router Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Output Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Input Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 02:07:06 --> Language Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Loader Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Controller Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Model Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Model Class Initialized
DEBUG - 2011-05-08 02:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 02:07:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 02:07:09 --> Final output sent to browser
DEBUG - 2011-05-08 02:07:09 --> Total execution time: 2.3948
DEBUG - 2011-05-08 03:08:44 --> Config Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 03:08:44 --> URI Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Router Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Output Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Input Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 03:08:44 --> Language Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Loader Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Controller Class Initialized
ERROR - 2011-05-08 03:08:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 03:08:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 03:08:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 03:08:44 --> Model Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Model Class Initialized
DEBUG - 2011-05-08 03:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 03:08:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 03:08:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 03:08:45 --> Helper loaded: url_helper
DEBUG - 2011-05-08 03:08:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 03:08:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 03:08:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 03:08:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 03:08:45 --> Final output sent to browser
DEBUG - 2011-05-08 03:08:45 --> Total execution time: 0.9063
DEBUG - 2011-05-08 03:21:14 --> Config Class Initialized
DEBUG - 2011-05-08 03:21:14 --> Hooks Class Initialized
DEBUG - 2011-05-08 03:21:14 --> Utf8 Class Initialized
DEBUG - 2011-05-08 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 03:21:14 --> URI Class Initialized
DEBUG - 2011-05-08 03:21:14 --> Router Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Output Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Input Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 03:21:15 --> Language Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Loader Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Controller Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Model Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Model Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Model Class Initialized
DEBUG - 2011-05-08 03:21:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 03:21:15 --> Database Driver Class Initialized
DEBUG - 2011-05-08 03:21:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 03:21:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 03:21:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 03:21:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 03:21:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 03:21:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 03:21:23 --> Final output sent to browser
DEBUG - 2011-05-08 03:21:23 --> Total execution time: 8.9772
DEBUG - 2011-05-08 03:21:24 --> Config Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 03:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 03:21:24 --> URI Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Router Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Output Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Input Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 03:21:24 --> Language Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Loader Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Controller Class Initialized
ERROR - 2011-05-08 03:21:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 03:21:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 03:21:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 03:21:24 --> Model Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Model Class Initialized
DEBUG - 2011-05-08 03:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 03:21:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 03:21:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 03:21:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 03:21:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 03:21:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 03:21:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 03:21:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 03:21:25 --> Final output sent to browser
DEBUG - 2011-05-08 03:21:25 --> Total execution time: 0.4200
DEBUG - 2011-05-08 05:20:25 --> Config Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 05:20:25 --> URI Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Router Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Output Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Input Class Initialized
DEBUG - 2011-05-08 05:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 05:20:26 --> Language Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Loader Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Controller Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Model Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Model Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Model Class Initialized
DEBUG - 2011-05-08 05:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 05:20:26 --> Database Driver Class Initialized
DEBUG - 2011-05-08 05:20:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 05:20:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 05:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 05:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 05:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 05:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 05:20:33 --> Final output sent to browser
DEBUG - 2011-05-08 05:20:33 --> Total execution time: 9.2003
DEBUG - 2011-05-08 06:45:53 --> Config Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 06:45:53 --> URI Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Router Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Output Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Input Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 06:45:53 --> Language Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Loader Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Controller Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Model Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Model Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Model Class Initialized
DEBUG - 2011-05-08 06:45:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 06:45:53 --> Database Driver Class Initialized
DEBUG - 2011-05-08 06:45:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 06:45:54 --> Helper loaded: url_helper
DEBUG - 2011-05-08 06:45:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 06:45:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 06:45:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 06:45:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 06:45:54 --> Final output sent to browser
DEBUG - 2011-05-08 06:45:54 --> Total execution time: 0.6565
DEBUG - 2011-05-08 06:46:22 --> Config Class Initialized
DEBUG - 2011-05-08 06:46:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 06:46:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 06:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 06:46:22 --> URI Class Initialized
DEBUG - 2011-05-08 06:46:22 --> Router Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Output Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Input Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 06:46:23 --> Language Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Loader Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Controller Class Initialized
ERROR - 2011-05-08 06:46:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 06:46:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 06:46:23 --> Model Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Model Class Initialized
DEBUG - 2011-05-08 06:46:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 06:46:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 06:46:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 06:46:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 06:46:23 --> Final output sent to browser
DEBUG - 2011-05-08 06:46:23 --> Total execution time: 1.1718
DEBUG - 2011-05-08 06:46:56 --> Config Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 06:46:56 --> URI Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Router Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Output Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Input Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 06:46:56 --> Language Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Loader Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Controller Class Initialized
ERROR - 2011-05-08 06:46:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 06:46:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 06:46:56 --> Model Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Model Class Initialized
DEBUG - 2011-05-08 06:46:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 06:46:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 06:46:56 --> Helper loaded: url_helper
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 06:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 06:46:56 --> Final output sent to browser
DEBUG - 2011-05-08 06:46:56 --> Total execution time: 0.0294
DEBUG - 2011-05-08 07:15:32 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:32 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Router Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Output Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Input Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 07:15:32 --> Language Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Loader Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Controller Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 07:15:32 --> Database Driver Class Initialized
DEBUG - 2011-05-08 07:15:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 07:15:32 --> Helper loaded: url_helper
DEBUG - 2011-05-08 07:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 07:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 07:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 07:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 07:15:32 --> Final output sent to browser
DEBUG - 2011-05-08 07:15:32 --> Total execution time: 0.6074
DEBUG - 2011-05-08 07:15:35 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:35 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Router Class Initialized
ERROR - 2011-05-08 07:15:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 07:15:35 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:35 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:35 --> Router Class Initialized
ERROR - 2011-05-08 07:15:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 07:15:36 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:36 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:36 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:36 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:36 --> Router Class Initialized
ERROR - 2011-05-08 07:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 07:15:53 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:53 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Router Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Output Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Input Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 07:15:53 --> Language Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Loader Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Controller Class Initialized
ERROR - 2011-05-08 07:15:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 07:15:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 07:15:53 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 07:15:53 --> Database Driver Class Initialized
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 07:15:53 --> Helper loaded: url_helper
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 07:15:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 07:15:53 --> Final output sent to browser
DEBUG - 2011-05-08 07:15:53 --> Total execution time: 0.1035
DEBUG - 2011-05-08 07:15:55 --> Config Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Hooks Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Utf8 Class Initialized
DEBUG - 2011-05-08 07:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 07:15:55 --> URI Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Router Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Output Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Input Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 07:15:55 --> Language Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Loader Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Controller Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Model Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 07:15:55 --> Database Driver Class Initialized
DEBUG - 2011-05-08 07:15:55 --> Final output sent to browser
DEBUG - 2011-05-08 07:15:55 --> Total execution time: 0.6454
DEBUG - 2011-05-08 08:52:57 --> Config Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Hooks Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Utf8 Class Initialized
DEBUG - 2011-05-08 08:52:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 08:52:57 --> URI Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Router Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Output Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Input Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 08:52:57 --> Language Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Loader Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Controller Class Initialized
ERROR - 2011-05-08 08:52:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 08:52:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 08:52:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 08:52:57 --> Model Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Model Class Initialized
DEBUG - 2011-05-08 08:52:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 08:52:57 --> Database Driver Class Initialized
DEBUG - 2011-05-08 08:52:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 08:52:58 --> Helper loaded: url_helper
DEBUG - 2011-05-08 08:52:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 08:52:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 08:52:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 08:52:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 08:52:58 --> Final output sent to browser
DEBUG - 2011-05-08 08:52:58 --> Total execution time: 0.3653
DEBUG - 2011-05-08 08:53:02 --> Config Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 08:53:02 --> URI Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Router Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Output Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Input Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 08:53:02 --> Language Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Loader Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Controller Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Model Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Model Class Initialized
DEBUG - 2011-05-08 08:53:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 08:53:02 --> Database Driver Class Initialized
DEBUG - 2011-05-08 08:53:04 --> Final output sent to browser
DEBUG - 2011-05-08 08:53:04 --> Total execution time: 1.9193
DEBUG - 2011-05-08 08:53:10 --> Config Class Initialized
DEBUG - 2011-05-08 08:53:10 --> Hooks Class Initialized
DEBUG - 2011-05-08 08:53:10 --> Utf8 Class Initialized
DEBUG - 2011-05-08 08:53:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 08:53:10 --> URI Class Initialized
DEBUG - 2011-05-08 08:53:10 --> Router Class Initialized
ERROR - 2011-05-08 08:53:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 08:53:13 --> Config Class Initialized
DEBUG - 2011-05-08 08:53:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 08:53:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 08:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 08:53:13 --> URI Class Initialized
DEBUG - 2011-05-08 08:53:13 --> Router Class Initialized
ERROR - 2011-05-08 08:53:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:01:24 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:24 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Router Class Initialized
DEBUG - 2011-05-08 09:01:24 --> No URI present. Default controller set.
DEBUG - 2011-05-08 09:01:24 --> Output Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Input Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:01:24 --> Language Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Loader Class Initialized
DEBUG - 2011-05-08 09:01:24 --> Controller Class Initialized
DEBUG - 2011-05-08 09:01:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 09:01:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:01:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:01:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:01:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:01:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:01:24 --> Final output sent to browser
DEBUG - 2011-05-08 09:01:24 --> Total execution time: 0.2330
DEBUG - 2011-05-08 09:01:27 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:27 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:27 --> Router Class Initialized
ERROR - 2011-05-08 09:01:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:01:28 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:28 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:28 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:28 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:28 --> Router Class Initialized
ERROR - 2011-05-08 09:01:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:01:29 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:29 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:29 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:29 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:29 --> Router Class Initialized
ERROR - 2011-05-08 09:01:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:01:36 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:36 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Router Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Output Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Input Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:01:36 --> Language Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Loader Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Controller Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:01:36 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:01:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:01:36 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:01:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:01:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:01:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:01:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:01:36 --> Final output sent to browser
DEBUG - 2011-05-08 09:01:36 --> Total execution time: 0.2858
DEBUG - 2011-05-08 09:01:52 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:52 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Router Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Output Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Input Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:01:52 --> Language Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Loader Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Controller Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:01:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:01:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:01:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:01:52 --> Final output sent to browser
DEBUG - 2011-05-08 09:01:52 --> Total execution time: 0.2940
DEBUG - 2011-05-08 09:01:57 --> Config Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:01:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:01:57 --> URI Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Router Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Output Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Input Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:01:57 --> Language Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Loader Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Controller Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Model Class Initialized
DEBUG - 2011-05-08 09:01:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:01:57 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:01:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:01:57 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:01:57 --> Final output sent to browser
DEBUG - 2011-05-08 09:01:57 --> Total execution time: 0.0451
DEBUG - 2011-05-08 09:13:10 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:10 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:10 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:10 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:10 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:10 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:10 --> Total execution time: 0.3100
DEBUG - 2011-05-08 09:13:12 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:12 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:12 --> Router Class Initialized
ERROR - 2011-05-08 09:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:13:29 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:29 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:29 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:30 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:30 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:30 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:33 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:33 --> Total execution time: 3.3567
DEBUG - 2011-05-08 09:13:34 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:34 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:34 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:34 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:34 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:34 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:34 --> Total execution time: 0.0467
DEBUG - 2011-05-08 09:13:34 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:34 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:34 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:34 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:34 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:34 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:34 --> Total execution time: 0.0460
DEBUG - 2011-05-08 09:13:34 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:34 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:34 --> Router Class Initialized
ERROR - 2011-05-08 09:13:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:13:51 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:51 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:51 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:51 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:52 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:52 --> Total execution time: 0.6853
DEBUG - 2011-05-08 09:13:53 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:53 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Router Class Initialized
ERROR - 2011-05-08 09:13:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:13:53 --> Config Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:13:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:13:53 --> URI Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Router Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Output Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Input Class Initialized
DEBUG - 2011-05-08 09:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:13:53 --> Language Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Loader Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Controller Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Model Class Initialized
DEBUG - 2011-05-08 09:13:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:13:54 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:13:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:13:54 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:13:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:13:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:13:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:13:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:13:54 --> Final output sent to browser
DEBUG - 2011-05-08 09:13:54 --> Total execution time: 0.0456
DEBUG - 2011-05-08 09:14:02 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:02 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:02 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:02 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:02 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:02 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:02 --> Total execution time: 0.4236
DEBUG - 2011-05-08 09:14:03 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:03 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:03 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:03 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:03 --> Router Class Initialized
ERROR - 2011-05-08 09:14:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:14:04 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:04 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:04 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:04 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:04 --> Total execution time: 0.0455
DEBUG - 2011-05-08 09:14:23 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:23 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:23 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:24 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:24 --> Total execution time: 0.2441
DEBUG - 2011-05-08 09:14:25 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:25 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:25 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:25 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:25 --> Total execution time: 0.0475
DEBUG - 2011-05-08 09:14:25 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:25 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:25 --> Router Class Initialized
ERROR - 2011-05-08 09:14:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:14:33 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:33 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:33 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:33 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:33 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:33 --> Total execution time: 0.2144
DEBUG - 2011-05-08 09:14:35 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:35 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:35 --> Router Class Initialized
ERROR - 2011-05-08 09:14:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:14:38 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:38 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:38 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:38 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:38 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:38 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:38 --> Total execution time: 0.0496
DEBUG - 2011-05-08 09:14:45 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:45 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:45 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:45 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:45 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:45 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:45 --> Total execution time: 0.1996
DEBUG - 2011-05-08 09:14:46 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:46 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:46 --> Router Class Initialized
ERROR - 2011-05-08 09:14:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:14:47 --> Config Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:14:47 --> URI Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Router Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Output Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Input Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:14:47 --> Language Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Loader Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Controller Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Model Class Initialized
DEBUG - 2011-05-08 09:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:14:47 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:14:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:14:47 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:14:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:14:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:14:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:14:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:14:47 --> Final output sent to browser
DEBUG - 2011-05-08 09:14:47 --> Total execution time: 0.0756
DEBUG - 2011-05-08 09:15:10 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:10 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Router Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Output Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Input Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:15:10 --> Language Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Loader Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Controller Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:15:10 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:15:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:15:10 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:15:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:15:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:15:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:15:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:15:10 --> Final output sent to browser
DEBUG - 2011-05-08 09:15:10 --> Total execution time: 0.2179
DEBUG - 2011-05-08 09:15:11 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:11 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:11 --> Router Class Initialized
ERROR - 2011-05-08 09:15:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:15:20 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:20 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Router Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Output Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Input Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:15:20 --> Language Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Loader Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Controller Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:15:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:15:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:15:20 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:15:20 --> Final output sent to browser
DEBUG - 2011-05-08 09:15:20 --> Total execution time: 0.0456
DEBUG - 2011-05-08 09:15:22 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:22 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Router Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Output Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Input Class Initialized
DEBUG - 2011-05-08 09:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:15:22 --> Language Class Initialized
DEBUG - 2011-05-08 09:15:23 --> Loader Class Initialized
DEBUG - 2011-05-08 09:15:23 --> Controller Class Initialized
ERROR - 2011-05-08 09:15:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:15:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:15:24 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:24 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:15:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:15:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:15:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:15:24 --> Final output sent to browser
DEBUG - 2011-05-08 09:15:24 --> Total execution time: 1.9532
DEBUG - 2011-05-08 09:15:25 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:25 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Router Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Output Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Input Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:15:25 --> Language Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Loader Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Controller Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Model Class Initialized
DEBUG - 2011-05-08 09:15:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:15:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:15:26 --> Final output sent to browser
DEBUG - 2011-05-08 09:15:26 --> Total execution time: 0.8611
DEBUG - 2011-05-08 09:15:27 --> Config Class Initialized
DEBUG - 2011-05-08 09:15:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:15:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:15:27 --> URI Class Initialized
DEBUG - 2011-05-08 09:15:27 --> Router Class Initialized
ERROR - 2011-05-08 09:15:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:21:38 --> Config Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:21:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:21:38 --> URI Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Router Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Output Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Input Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:21:38 --> Language Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Loader Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Controller Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Model Class Initialized
DEBUG - 2011-05-08 09:21:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:21:38 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:21:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 09:21:38 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:21:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:21:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:21:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:21:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:21:38 --> Final output sent to browser
DEBUG - 2011-05-08 09:21:38 --> Total execution time: 0.0605
DEBUG - 2011-05-08 09:43:49 --> Config Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:43:49 --> URI Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Router Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Output Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Input Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:43:49 --> Language Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Loader Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Controller Class Initialized
ERROR - 2011-05-08 09:43:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:43:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:43:49 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:43:49 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:43:49 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:43:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:43:49 --> Final output sent to browser
DEBUG - 2011-05-08 09:43:49 --> Total execution time: 0.2966
DEBUG - 2011-05-08 09:43:50 --> Config Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:43:50 --> URI Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Router Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Output Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Input Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:43:50 --> Language Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Loader Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Controller Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:43:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Config Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:43:50 --> URI Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Router Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Output Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Input Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:43:50 --> Language Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Loader Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Controller Class Initialized
ERROR - 2011-05-08 09:43:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:43:50 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Model Class Initialized
DEBUG - 2011-05-08 09:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:43:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:43:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:43:50 --> Final output sent to browser
DEBUG - 2011-05-08 09:43:50 --> Total execution time: 0.0308
DEBUG - 2011-05-08 09:43:51 --> Final output sent to browser
DEBUG - 2011-05-08 09:43:51 --> Total execution time: 0.8015
DEBUG - 2011-05-08 09:47:37 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:37 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Router Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Output Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Input Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:47:37 --> Language Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Loader Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Controller Class Initialized
ERROR - 2011-05-08 09:47:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:47:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:37 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:47:37 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:37 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:47:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:47:37 --> Final output sent to browser
DEBUG - 2011-05-08 09:47:37 --> Total execution time: 0.0314
DEBUG - 2011-05-08 09:47:37 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:37 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Router Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Output Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Input Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:47:37 --> Language Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Loader Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Controller Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:47:37 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:47:38 --> Final output sent to browser
DEBUG - 2011-05-08 09:47:38 --> Total execution time: 0.6432
DEBUG - 2011-05-08 09:47:40 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:40 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Router Class Initialized
ERROR - 2011-05-08 09:47:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:47:40 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:40 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:40 --> Router Class Initialized
ERROR - 2011-05-08 09:47:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:47:56 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:56 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Router Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Output Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Input Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:47:56 --> Language Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Loader Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Controller Class Initialized
ERROR - 2011-05-08 09:47:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:47:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:47:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:56 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:47:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:47:56 --> Final output sent to browser
DEBUG - 2011-05-08 09:47:56 --> Total execution time: 0.0501
DEBUG - 2011-05-08 09:47:56 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:56 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Router Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Output Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Input Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:47:56 --> Language Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Loader Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Controller Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:47:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Config Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:47:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:47:57 --> URI Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Router Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Output Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Input Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:47:57 --> Language Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Loader Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Controller Class Initialized
ERROR - 2011-05-08 09:47:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:47:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:57 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Model Class Initialized
DEBUG - 2011-05-08 09:47:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:47:57 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:47:57 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:47:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:47:57 --> Final output sent to browser
DEBUG - 2011-05-08 09:47:57 --> Total execution time: 0.0294
DEBUG - 2011-05-08 09:47:57 --> Final output sent to browser
DEBUG - 2011-05-08 09:47:57 --> Total execution time: 0.8850
DEBUG - 2011-05-08 09:48:11 --> Config Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:48:11 --> URI Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Router Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Output Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Input Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:48:11 --> Language Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Loader Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Controller Class Initialized
ERROR - 2011-05-08 09:48:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:48:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:48:11 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:48:11 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:48:11 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:48:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:48:11 --> Final output sent to browser
DEBUG - 2011-05-08 09:48:11 --> Total execution time: 0.0298
DEBUG - 2011-05-08 09:48:12 --> Config Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:48:12 --> URI Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Router Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Output Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Input Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:48:12 --> Language Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Loader Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Controller Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:48:12 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Config Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:48:12 --> URI Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Router Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Output Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Input Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:48:12 --> Language Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Loader Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Controller Class Initialized
ERROR - 2011-05-08 09:48:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:48:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:48:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Model Class Initialized
DEBUG - 2011-05-08 09:48:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:48:13 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:48:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:48:13 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:48:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:48:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:48:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:48:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:48:13 --> Final output sent to browser
DEBUG - 2011-05-08 09:48:13 --> Total execution time: 0.0350
DEBUG - 2011-05-08 09:48:13 --> Final output sent to browser
DEBUG - 2011-05-08 09:48:13 --> Total execution time: 0.6748
DEBUG - 2011-05-08 09:58:04 --> Config Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:58:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:58:04 --> URI Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Router Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Output Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Input Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:58:04 --> Language Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Loader Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Controller Class Initialized
ERROR - 2011-05-08 09:58:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:58:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:58:04 --> Model Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Model Class Initialized
DEBUG - 2011-05-08 09:58:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:58:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:58:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:58:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:58:04 --> Final output sent to browser
DEBUG - 2011-05-08 09:58:04 --> Total execution time: 0.2874
DEBUG - 2011-05-08 09:58:05 --> Config Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:58:05 --> URI Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Router Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Output Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Input Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:58:05 --> Language Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Loader Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Controller Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Model Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Model Class Initialized
DEBUG - 2011-05-08 09:58:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:58:05 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:58:06 --> Final output sent to browser
DEBUG - 2011-05-08 09:58:06 --> Total execution time: 0.7146
DEBUG - 2011-05-08 09:58:07 --> Config Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:58:07 --> URI Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Router Class Initialized
ERROR - 2011-05-08 09:58:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:58:07 --> Config Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:58:07 --> URI Class Initialized
DEBUG - 2011-05-08 09:58:07 --> Router Class Initialized
ERROR - 2011-05-08 09:58:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:58:08 --> Config Class Initialized
DEBUG - 2011-05-08 09:58:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:58:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:58:08 --> URI Class Initialized
DEBUG - 2011-05-08 09:58:08 --> Router Class Initialized
ERROR - 2011-05-08 09:58:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 09:59:23 --> Config Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:59:23 --> URI Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Router Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Output Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Input Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:59:23 --> Language Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Loader Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Controller Class Initialized
ERROR - 2011-05-08 09:59:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 09:59:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:59:23 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:59:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 09:59:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 09:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 09:59:23 --> Final output sent to browser
DEBUG - 2011-05-08 09:59:23 --> Total execution time: 0.0308
DEBUG - 2011-05-08 09:59:24 --> Config Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:59:24 --> URI Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Router Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Output Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Input Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:59:24 --> Language Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Loader Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Controller Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:59:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:59:25 --> Final output sent to browser
DEBUG - 2011-05-08 09:59:25 --> Total execution time: 0.7631
DEBUG - 2011-05-08 09:59:56 --> Config Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:59:56 --> URI Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Router Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Output Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Input Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:59:56 --> Language Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Loader Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Controller Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:59:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:59:57 --> Final output sent to browser
DEBUG - 2011-05-08 09:59:57 --> Total execution time: 0.5064
DEBUG - 2011-05-08 09:59:58 --> Config Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Hooks Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Utf8 Class Initialized
DEBUG - 2011-05-08 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 09:59:58 --> URI Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Router Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Output Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Input Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 09:59:58 --> Language Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Loader Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Controller Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Model Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 09:59:58 --> Database Driver Class Initialized
DEBUG - 2011-05-08 09:59:58 --> Final output sent to browser
DEBUG - 2011-05-08 09:59:58 --> Total execution time: 0.4531
DEBUG - 2011-05-08 10:08:17 --> Config Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:08:17 --> URI Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Router Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Output Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Input Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:08:17 --> Language Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Loader Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Controller Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Model Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Model Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Model Class Initialized
DEBUG - 2011-05-08 10:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:08:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:08:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:08:18 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:08:18 --> Final output sent to browser
DEBUG - 2011-05-08 10:08:18 --> Total execution time: 1.3487
DEBUG - 2011-05-08 10:31:18 --> Config Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:31:18 --> URI Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Router Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Output Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Input Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:31:18 --> Language Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Loader Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Controller Class Initialized
ERROR - 2011-05-08 10:31:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 10:31:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 10:31:18 --> Model Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Model Class Initialized
DEBUG - 2011-05-08 10:31:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:31:18 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 10:31:18 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:31:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:31:18 --> Final output sent to browser
DEBUG - 2011-05-08 10:31:18 --> Total execution time: 0.3991
DEBUG - 2011-05-08 10:31:20 --> Config Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:31:20 --> URI Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Router Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Output Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Input Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:31:20 --> Language Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Loader Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Controller Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Model Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Model Class Initialized
DEBUG - 2011-05-08 10:31:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:31:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:31:21 --> Final output sent to browser
DEBUG - 2011-05-08 10:31:21 --> Total execution time: 1.2319
DEBUG - 2011-05-08 10:31:22 --> Config Class Initialized
DEBUG - 2011-05-08 10:31:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:31:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:31:22 --> URI Class Initialized
DEBUG - 2011-05-08 10:31:22 --> Router Class Initialized
ERROR - 2011-05-08 10:31:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:37:11 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:11 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Router Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Output Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Input Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:37:11 --> Language Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Loader Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Controller Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:37:11 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:37:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:37:11 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:37:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:37:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:37:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:37:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:37:11 --> Final output sent to browser
DEBUG - 2011-05-08 10:37:11 --> Total execution time: 0.4392
DEBUG - 2011-05-08 10:37:13 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:13 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:13 --> Router Class Initialized
ERROR - 2011-05-08 10:37:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:37:40 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:40 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Router Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Output Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Input Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:37:40 --> Language Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Loader Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Controller Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:37:40 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:37:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:37:41 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:37:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:37:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:37:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:37:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:37:41 --> Final output sent to browser
DEBUG - 2011-05-08 10:37:41 --> Total execution time: 1.0479
DEBUG - 2011-05-08 10:37:42 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:42 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:42 --> Router Class Initialized
ERROR - 2011-05-08 10:37:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:37:51 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:51 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Router Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Output Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Input Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:37:51 --> Language Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Loader Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Controller Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Model Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:37:51 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:37:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:37:51 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:37:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:37:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:37:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:37:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:37:51 --> Final output sent to browser
DEBUG - 2011-05-08 10:37:51 --> Total execution time: 0.0564
DEBUG - 2011-05-08 10:37:51 --> Config Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:37:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:37:51 --> URI Class Initialized
DEBUG - 2011-05-08 10:37:51 --> Router Class Initialized
ERROR - 2011-05-08 10:37:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:38:04 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:04 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Router Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Output Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Input Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:38:04 --> Language Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Loader Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Controller Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:38:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:38:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:38:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:38:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:38:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:38:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:38:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:38:04 --> Final output sent to browser
DEBUG - 2011-05-08 10:38:04 --> Total execution time: 0.2775
DEBUG - 2011-05-08 10:38:05 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:05 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:05 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:05 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:05 --> Router Class Initialized
ERROR - 2011-05-08 10:38:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:38:20 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:20 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Router Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Output Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Input Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:38:20 --> Language Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Loader Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Controller Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:38:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:38:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:38:21 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:38:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:38:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:38:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:38:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:38:21 --> Final output sent to browser
DEBUG - 2011-05-08 10:38:21 --> Total execution time: 0.4083
DEBUG - 2011-05-08 10:38:22 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:22 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:22 --> Router Class Initialized
ERROR - 2011-05-08 10:38:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:38:49 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:49 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Router Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Output Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Input Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:38:49 --> Language Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Loader Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Controller Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Model Class Initialized
DEBUG - 2011-05-08 10:38:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:38:49 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:38:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:38:50 --> Final output sent to browser
DEBUG - 2011-05-08 10:38:50 --> Total execution time: 0.2697
DEBUG - 2011-05-08 10:38:50 --> Config Class Initialized
DEBUG - 2011-05-08 10:38:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:38:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:38:50 --> URI Class Initialized
DEBUG - 2011-05-08 10:38:50 --> Router Class Initialized
ERROR - 2011-05-08 10:38:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 10:39:12 --> Config Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:39:12 --> URI Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Router Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Output Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Input Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 10:39:12 --> Language Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Loader Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Controller Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Model Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Model Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Model Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 10:39:12 --> Database Driver Class Initialized
DEBUG - 2011-05-08 10:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 10:39:12 --> Helper loaded: url_helper
DEBUG - 2011-05-08 10:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 10:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 10:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 10:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 10:39:12 --> Final output sent to browser
DEBUG - 2011-05-08 10:39:12 --> Total execution time: 0.2806
DEBUG - 2011-05-08 10:39:12 --> Config Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 10:39:12 --> URI Class Initialized
DEBUG - 2011-05-08 10:39:12 --> Router Class Initialized
ERROR - 2011-05-08 10:39:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 11:20:24 --> Config Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:20:24 --> URI Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Router Class Initialized
DEBUG - 2011-05-08 11:20:24 --> No URI present. Default controller set.
DEBUG - 2011-05-08 11:20:24 --> Output Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Input Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 11:20:24 --> Language Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Loader Class Initialized
DEBUG - 2011-05-08 11:20:24 --> Controller Class Initialized
DEBUG - 2011-05-08 11:20:24 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 11:20:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 11:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 11:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 11:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 11:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 11:20:24 --> Final output sent to browser
DEBUG - 2011-05-08 11:20:24 --> Total execution time: 0.6431
DEBUG - 2011-05-08 11:20:27 --> Config Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:20:27 --> URI Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Router Class Initialized
ERROR - 2011-05-08 11:20:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 11:20:27 --> Config Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:20:27 --> URI Class Initialized
DEBUG - 2011-05-08 11:20:27 --> Router Class Initialized
ERROR - 2011-05-08 11:20:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 11:39:22 --> Config Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:39:22 --> URI Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Router Class Initialized
DEBUG - 2011-05-08 11:39:22 --> No URI present. Default controller set.
DEBUG - 2011-05-08 11:39:22 --> Output Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Input Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 11:39:22 --> Language Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Loader Class Initialized
DEBUG - 2011-05-08 11:39:22 --> Controller Class Initialized
DEBUG - 2011-05-08 11:39:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 11:39:22 --> Helper loaded: url_helper
DEBUG - 2011-05-08 11:39:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 11:39:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 11:39:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 11:39:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 11:39:22 --> Final output sent to browser
DEBUG - 2011-05-08 11:39:22 --> Total execution time: 0.2519
DEBUG - 2011-05-08 11:39:23 --> Config Class Initialized
DEBUG - 2011-05-08 11:39:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:39:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:39:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:39:23 --> URI Class Initialized
DEBUG - 2011-05-08 11:39:23 --> Router Class Initialized
ERROR - 2011-05-08 11:39:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 11:49:41 --> Config Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Hooks Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Utf8 Class Initialized
DEBUG - 2011-05-08 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 11:49:41 --> URI Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Router Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Output Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Input Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 11:49:41 --> Language Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Loader Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Controller Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Model Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Model Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Model Class Initialized
DEBUG - 2011-05-08 11:49:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 11:49:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 11:49:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 11:49:42 --> Helper loaded: url_helper
DEBUG - 2011-05-08 11:49:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 11:49:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 11:49:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 11:49:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 11:49:42 --> Final output sent to browser
DEBUG - 2011-05-08 11:49:42 --> Total execution time: 0.5788
DEBUG - 2011-05-08 12:00:00 --> Config Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:00:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:00:00 --> URI Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Router Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Output Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Input Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:00:00 --> Language Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Loader Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Controller Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Model Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Model Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Model Class Initialized
DEBUG - 2011-05-08 12:00:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:00:00 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:00:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:00:00 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:00:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:00:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:00:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:00:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:00:00 --> Final output sent to browser
DEBUG - 2011-05-08 12:00:00 --> Total execution time: 0.4491
DEBUG - 2011-05-08 12:12:49 --> Config Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:12:49 --> URI Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Router Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Output Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Input Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:12:49 --> Language Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Loader Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Controller Class Initialized
ERROR - 2011-05-08 12:12:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 12:12:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:12:49 --> Model Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Model Class Initialized
DEBUG - 2011-05-08 12:12:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:12:49 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:12:49 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:12:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:12:49 --> Final output sent to browser
DEBUG - 2011-05-08 12:12:49 --> Total execution time: 0.3864
DEBUG - 2011-05-08 12:12:50 --> Config Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:12:50 --> URI Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Router Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Output Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Input Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:12:50 --> Language Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Loader Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Controller Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Model Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Model Class Initialized
DEBUG - 2011-05-08 12:12:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:12:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:12:51 --> Final output sent to browser
DEBUG - 2011-05-08 12:12:51 --> Total execution time: 0.6535
DEBUG - 2011-05-08 12:13:17 --> Config Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:13:17 --> URI Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Router Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Output Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Input Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:13:17 --> Language Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Loader Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Controller Class Initialized
ERROR - 2011-05-08 12:13:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 12:13:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:13:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:13:17 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:13:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:13:17 --> Final output sent to browser
DEBUG - 2011-05-08 12:13:17 --> Total execution time: 0.0362
DEBUG - 2011-05-08 12:13:17 --> Config Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:13:17 --> URI Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Router Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Output Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Input Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:13:17 --> Language Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Loader Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Controller Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:13:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Final output sent to browser
DEBUG - 2011-05-08 12:13:18 --> Total execution time: 0.6970
DEBUG - 2011-05-08 12:13:18 --> Config Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:13:18 --> URI Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Router Class Initialized
ERROR - 2011-05-08 12:13:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-08 12:13:18 --> Config Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:13:18 --> URI Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Router Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Output Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Input Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:13:18 --> Language Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Loader Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Controller Class Initialized
ERROR - 2011-05-08 12:13:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 12:13:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 12:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:13:18 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Model Class Initialized
DEBUG - 2011-05-08 12:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:13:18 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:13:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:13:19 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:13:19 --> Final output sent to browser
DEBUG - 2011-05-08 12:13:19 --> Total execution time: 0.0289
DEBUG - 2011-05-08 12:14:44 --> Config Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:14:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:14:44 --> URI Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Router Class Initialized
DEBUG - 2011-05-08 12:14:44 --> No URI present. Default controller set.
DEBUG - 2011-05-08 12:14:44 --> Output Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Input Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:14:44 --> Language Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Loader Class Initialized
DEBUG - 2011-05-08 12:14:44 --> Controller Class Initialized
DEBUG - 2011-05-08 12:14:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 12:14:44 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:14:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:14:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:14:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:14:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:14:44 --> Final output sent to browser
DEBUG - 2011-05-08 12:14:44 --> Total execution time: 0.0638
DEBUG - 2011-05-08 12:14:53 --> Config Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:14:53 --> URI Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Router Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Output Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Input Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:14:53 --> Language Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Loader Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Controller Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Model Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Model Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Model Class Initialized
DEBUG - 2011-05-08 12:14:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:14:53 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:14:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:14:53 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:14:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:14:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:14:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:14:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:14:53 --> Final output sent to browser
DEBUG - 2011-05-08 12:14:53 --> Total execution time: 0.0958
DEBUG - 2011-05-08 12:15:33 --> Config Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:15:33 --> URI Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Router Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Output Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Input Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:15:33 --> Language Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Loader Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Controller Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:15:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:15:33 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:15:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:15:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:15:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:15:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:15:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:15:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:15:33 --> Final output sent to browser
DEBUG - 2011-05-08 12:15:33 --> Total execution time: 0.1911
DEBUG - 2011-05-08 12:26:33 --> Config Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:26:33 --> URI Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Router Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Output Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Input Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:26:33 --> Language Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Loader Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Controller Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Model Class Initialized
DEBUG - 2011-05-08 12:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:26:33 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:26:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:26:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:26:33 --> Final output sent to browser
DEBUG - 2011-05-08 12:26:33 --> Total execution time: 0.2812
DEBUG - 2011-05-08 12:26:34 --> Config Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:26:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:26:34 --> URI Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Router Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Output Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Input Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:26:34 --> Language Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Loader Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Controller Class Initialized
ERROR - 2011-05-08 12:26:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 12:26:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:26:34 --> Model Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Model Class Initialized
DEBUG - 2011-05-08 12:26:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:26:34 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 12:26:34 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:26:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:26:34 --> Final output sent to browser
DEBUG - 2011-05-08 12:26:34 --> Total execution time: 0.0737
DEBUG - 2011-05-08 12:42:44 --> Config Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:42:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:42:44 --> URI Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Router Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Output Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Input Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:42:44 --> Language Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Loader Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Controller Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:42:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:42:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:42:44 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:42:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:42:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:42:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:42:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:42:44 --> Final output sent to browser
DEBUG - 2011-05-08 12:42:44 --> Total execution time: 0.1581
DEBUG - 2011-05-08 12:42:46 --> Config Class Initialized
DEBUG - 2011-05-08 12:42:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:42:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:42:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:42:46 --> URI Class Initialized
DEBUG - 2011-05-08 12:42:46 --> Router Class Initialized
ERROR - 2011-05-08 12:42:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 12:42:47 --> Config Class Initialized
DEBUG - 2011-05-08 12:42:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:42:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:42:47 --> URI Class Initialized
DEBUG - 2011-05-08 12:42:47 --> Router Class Initialized
ERROR - 2011-05-08 12:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 12:42:48 --> Config Class Initialized
DEBUG - 2011-05-08 12:42:48 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:42:48 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:42:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:42:48 --> URI Class Initialized
DEBUG - 2011-05-08 12:42:48 --> Router Class Initialized
ERROR - 2011-05-08 12:42:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 12:42:52 --> Config Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:42:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:42:52 --> URI Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Router Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Output Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Input Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:42:52 --> Language Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Loader Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Controller Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Model Class Initialized
DEBUG - 2011-05-08 12:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:42:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:42:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:42:52 --> Final output sent to browser
DEBUG - 2011-05-08 12:42:52 --> Total execution time: 0.2319
DEBUG - 2011-05-08 12:43:04 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:04 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:04 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:04 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:04 --> Total execution time: 0.2000
DEBUG - 2011-05-08 12:43:06 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:06 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:06 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:06 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:06 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:06 --> Total execution time: 0.0886
DEBUG - 2011-05-08 12:43:08 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:08 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:08 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:08 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:08 --> Total execution time: 0.3056
DEBUG - 2011-05-08 12:43:11 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:11 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:11 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:11 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:11 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:11 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:11 --> Total execution time: 0.0528
DEBUG - 2011-05-08 12:43:13 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:13 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:13 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:13 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:14 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:14 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:14 --> Total execution time: 0.3200
DEBUG - 2011-05-08 12:43:15 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:15 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:15 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:15 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:15 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:15 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:15 --> Total execution time: 0.0433
DEBUG - 2011-05-08 12:43:15 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:15 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:15 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:15 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:15 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:15 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:15 --> Total execution time: 0.0486
DEBUG - 2011-05-08 12:43:17 --> Config Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:43:17 --> URI Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Router Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Output Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Input Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:43:17 --> Language Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Loader Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Controller Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Model Class Initialized
DEBUG - 2011-05-08 12:43:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:43:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:43:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:43:17 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:43:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:43:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:43:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:43:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:43:17 --> Final output sent to browser
DEBUG - 2011-05-08 12:43:17 --> Total execution time: 0.1175
DEBUG - 2011-05-08 12:54:58 --> Config Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Hooks Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Utf8 Class Initialized
DEBUG - 2011-05-08 12:54:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 12:54:58 --> URI Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Router Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Output Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Input Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 12:54:58 --> Language Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Loader Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Controller Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Model Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Model Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Model Class Initialized
DEBUG - 2011-05-08 12:54:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 12:54:58 --> Database Driver Class Initialized
DEBUG - 2011-05-08 12:54:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 12:54:58 --> Helper loaded: url_helper
DEBUG - 2011-05-08 12:54:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 12:54:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 12:54:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 12:54:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 12:54:58 --> Final output sent to browser
DEBUG - 2011-05-08 12:54:58 --> Total execution time: 0.0507
DEBUG - 2011-05-08 13:41:26 --> Config Class Initialized
DEBUG - 2011-05-08 13:41:26 --> Hooks Class Initialized
DEBUG - 2011-05-08 13:41:26 --> Utf8 Class Initialized
DEBUG - 2011-05-08 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 13:41:26 --> URI Class Initialized
DEBUG - 2011-05-08 13:41:26 --> Router Class Initialized
DEBUG - 2011-05-08 13:41:26 --> No URI present. Default controller set.
DEBUG - 2011-05-08 13:41:27 --> Output Class Initialized
DEBUG - 2011-05-08 13:41:27 --> Input Class Initialized
DEBUG - 2011-05-08 13:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 13:41:27 --> Language Class Initialized
DEBUG - 2011-05-08 13:41:28 --> Loader Class Initialized
DEBUG - 2011-05-08 13:41:28 --> Controller Class Initialized
DEBUG - 2011-05-08 13:41:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 13:41:28 --> Helper loaded: url_helper
DEBUG - 2011-05-08 13:41:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 13:41:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 13:41:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 13:41:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 13:41:28 --> Final output sent to browser
DEBUG - 2011-05-08 13:41:28 --> Total execution time: 2.0839
DEBUG - 2011-05-08 13:53:06 --> Config Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 13:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 13:53:06 --> URI Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Router Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Output Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Input Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 13:53:06 --> Language Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Loader Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Controller Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Model Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Model Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Model Class Initialized
DEBUG - 2011-05-08 13:53:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 13:53:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 13:53:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 13:53:07 --> Helper loaded: url_helper
DEBUG - 2011-05-08 13:53:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 13:53:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 13:53:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 13:53:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 13:53:07 --> Final output sent to browser
DEBUG - 2011-05-08 13:53:07 --> Total execution time: 1.1466
DEBUG - 2011-05-08 13:53:08 --> Config Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 13:53:08 --> URI Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Router Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Output Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Input Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 13:53:08 --> Language Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Loader Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Controller Class Initialized
ERROR - 2011-05-08 13:53:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 13:53:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 13:53:08 --> Model Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Model Class Initialized
DEBUG - 2011-05-08 13:53:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 13:53:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 13:53:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 13:53:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 13:53:08 --> Final output sent to browser
DEBUG - 2011-05-08 13:53:08 --> Total execution time: 0.3531
DEBUG - 2011-05-08 14:25:04 --> Config Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 14:25:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 14:25:04 --> URI Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Router Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Output Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Input Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 14:25:04 --> Language Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Loader Class Initialized
DEBUG - 2011-05-08 14:25:04 --> Controller Class Initialized
ERROR - 2011-05-08 14:25:04 --> 404 Page Not Found --> snakes/image%3Fcode%3Deng12010
DEBUG - 2011-05-08 15:08:42 --> Config Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:08:42 --> URI Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Router Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Output Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Input Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:08:42 --> Language Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Loader Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Controller Class Initialized
ERROR - 2011-05-08 15:08:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:08:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:08:42 --> Model Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Model Class Initialized
DEBUG - 2011-05-08 15:08:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:08:42 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:08:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:08:43 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:08:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:08:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:08:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:08:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:08:43 --> Final output sent to browser
DEBUG - 2011-05-08 15:08:43 --> Total execution time: 0.7771
DEBUG - 2011-05-08 15:08:44 --> Config Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:08:44 --> URI Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Router Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Output Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Input Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:08:44 --> Language Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Loader Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Controller Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:08:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:08:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:08:45 --> Final output sent to browser
DEBUG - 2011-05-08 15:08:45 --> Total execution time: 1.0897
DEBUG - 2011-05-08 15:08:47 --> Config Class Initialized
DEBUG - 2011-05-08 15:08:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:08:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:08:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:08:47 --> URI Class Initialized
DEBUG - 2011-05-08 15:08:47 --> Router Class Initialized
ERROR - 2011-05-08 15:08:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:08:48 --> Config Class Initialized
DEBUG - 2011-05-08 15:08:48 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:08:48 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:08:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:08:48 --> URI Class Initialized
DEBUG - 2011-05-08 15:08:48 --> Router Class Initialized
ERROR - 2011-05-08 15:08:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:25:21 --> Config Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:25:21 --> URI Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Router Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Output Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Input Class Initialized
DEBUG - 2011-05-08 15:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:25:21 --> Language Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Loader Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Controller Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Model Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Model Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Model Class Initialized
DEBUG - 2011-05-08 15:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:25:22 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:25:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 15:25:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:25:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:25:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:25:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:25:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:25:23 --> Final output sent to browser
DEBUG - 2011-05-08 15:25:23 --> Total execution time: 1.2251
DEBUG - 2011-05-08 15:25:24 --> Config Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:25:24 --> URI Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Router Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Output Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Input Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:25:24 --> Language Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Loader Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Controller Class Initialized
ERROR - 2011-05-08 15:25:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:25:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:25:24 --> Model Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Model Class Initialized
DEBUG - 2011-05-08 15:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:25:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:25:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:25:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:25:24 --> Final output sent to browser
DEBUG - 2011-05-08 15:25:24 --> Total execution time: 0.1051
DEBUG - 2011-05-08 15:30:03 --> Config Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:30:03 --> URI Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Router Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Output Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Input Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:30:03 --> Language Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Loader Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Controller Class Initialized
ERROR - 2011-05-08 15:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:30:03 --> Model Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Model Class Initialized
DEBUG - 2011-05-08 15:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:30:03 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:30:03 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:30:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:30:03 --> Final output sent to browser
DEBUG - 2011-05-08 15:30:03 --> Total execution time: 0.3792
DEBUG - 2011-05-08 15:30:08 --> Config Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:30:08 --> URI Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Router Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Output Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Input Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:30:08 --> Language Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Loader Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Controller Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:30:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:30:09 --> Final output sent to browser
DEBUG - 2011-05-08 15:30:09 --> Total execution time: 0.8251
DEBUG - 2011-05-08 15:30:18 --> Config Class Initialized
DEBUG - 2011-05-08 15:30:18 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:30:18 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:30:18 --> URI Class Initialized
DEBUG - 2011-05-08 15:30:18 --> Router Class Initialized
ERROR - 2011-05-08 15:30:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:33:05 --> Config Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:33:05 --> URI Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Router Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Output Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Input Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:33:05 --> Language Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Loader Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Controller Class Initialized
ERROR - 2011-05-08 15:33:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:33:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:33:05 --> Model Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Model Class Initialized
DEBUG - 2011-05-08 15:33:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:33:05 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:33:05 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:33:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:33:05 --> Final output sent to browser
DEBUG - 2011-05-08 15:33:05 --> Total execution time: 0.0348
DEBUG - 2011-05-08 15:33:08 --> Config Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:33:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:33:08 --> URI Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Router Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Output Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Input Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:33:08 --> Language Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Loader Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Controller Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:33:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:33:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:33:10 --> Final output sent to browser
DEBUG - 2011-05-08 15:33:10 --> Total execution time: 1.4954
DEBUG - 2011-05-08 15:33:13 --> Config Class Initialized
DEBUG - 2011-05-08 15:33:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:33:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:33:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:33:13 --> URI Class Initialized
DEBUG - 2011-05-08 15:33:13 --> Router Class Initialized
ERROR - 2011-05-08 15:33:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:34:08 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:08 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Router Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Output Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Input Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:34:08 --> Language Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Loader Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Controller Class Initialized
ERROR - 2011-05-08 15:34:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:34:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:34:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:34:08 --> Final output sent to browser
DEBUG - 2011-05-08 15:34:08 --> Total execution time: 0.0300
DEBUG - 2011-05-08 15:34:09 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:09 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Router Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Output Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Input Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:34:09 --> Language Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Loader Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Controller Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:34:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:34:09 --> Final output sent to browser
DEBUG - 2011-05-08 15:34:09 --> Total execution time: 0.6085
DEBUG - 2011-05-08 15:34:10 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:10 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Router Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Output Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Input Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:34:10 --> Language Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Loader Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Controller Class Initialized
ERROR - 2011-05-08 15:34:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:34:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:10 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:34:10 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:10 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:34:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:34:10 --> Final output sent to browser
DEBUG - 2011-05-08 15:34:10 --> Total execution time: 0.0382
DEBUG - 2011-05-08 15:34:12 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:12 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:12 --> Router Class Initialized
ERROR - 2011-05-08 15:34:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:34:30 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:30 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Router Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Output Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Input Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:34:30 --> Language Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Loader Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Controller Class Initialized
ERROR - 2011-05-08 15:34:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:34:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:30 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:34:30 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:34:30 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:34:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:34:30 --> Final output sent to browser
DEBUG - 2011-05-08 15:34:30 --> Total execution time: 0.0369
DEBUG - 2011-05-08 15:34:31 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:31 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Router Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Output Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Input Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:34:31 --> Language Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Loader Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Controller Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Model Class Initialized
DEBUG - 2011-05-08 15:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:34:31 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:34:32 --> Final output sent to browser
DEBUG - 2011-05-08 15:34:32 --> Total execution time: 0.7879
DEBUG - 2011-05-08 15:34:34 --> Config Class Initialized
DEBUG - 2011-05-08 15:34:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:34:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:34:34 --> URI Class Initialized
DEBUG - 2011-05-08 15:34:34 --> Router Class Initialized
ERROR - 2011-05-08 15:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:35:08 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:08 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Router Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Output Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Input Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:35:08 --> Language Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Loader Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Controller Class Initialized
ERROR - 2011-05-08 15:35:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:35:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:35:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:35:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:35:08 --> Final output sent to browser
DEBUG - 2011-05-08 15:35:08 --> Total execution time: 0.0304
DEBUG - 2011-05-08 15:35:09 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:09 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Router Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Output Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Input Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:35:09 --> Language Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Loader Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Controller Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:35:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:35:10 --> Final output sent to browser
DEBUG - 2011-05-08 15:35:10 --> Total execution time: 0.9982
DEBUG - 2011-05-08 15:35:12 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:12 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:12 --> Router Class Initialized
ERROR - 2011-05-08 15:35:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:35:43 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:43 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Router Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Output Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Input Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:35:43 --> Language Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Loader Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Controller Class Initialized
ERROR - 2011-05-08 15:35:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:35:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:43 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:35:43 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:43 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:35:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:35:43 --> Final output sent to browser
DEBUG - 2011-05-08 15:35:43 --> Total execution time: 0.0485
DEBUG - 2011-05-08 15:35:44 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:44 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Router Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Output Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Input Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:35:44 --> Language Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Loader Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Controller Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:35:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:44 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Router Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Output Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Input Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:35:44 --> Language Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Loader Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Controller Class Initialized
ERROR - 2011-05-08 15:35:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:35:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Model Class Initialized
DEBUG - 2011-05-08 15:35:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:35:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:35:44 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:35:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:35:44 --> Final output sent to browser
DEBUG - 2011-05-08 15:35:44 --> Total execution time: 0.0291
DEBUG - 2011-05-08 15:35:44 --> Final output sent to browser
DEBUG - 2011-05-08 15:35:44 --> Total execution time: 0.8342
DEBUG - 2011-05-08 15:35:46 --> Config Class Initialized
DEBUG - 2011-05-08 15:35:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:35:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:35:46 --> URI Class Initialized
DEBUG - 2011-05-08 15:35:46 --> Router Class Initialized
ERROR - 2011-05-08 15:35:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:36:11 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:11 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:11 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:11 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:11 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:11 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:11 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:11 --> Total execution time: 0.0737
DEBUG - 2011-05-08 15:36:12 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:12 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:12 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Controller Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:12 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:13 --> Total execution time: 1.0714
DEBUG - 2011-05-08 15:36:13 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:13 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:13 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:13 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:13 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:13 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:13 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:13 --> Total execution time: 0.0285
DEBUG - 2011-05-08 15:36:15 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:15 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:15 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:15 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:15 --> Router Class Initialized
ERROR - 2011-05-08 15:36:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:36:20 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:20 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:20 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:20 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:20 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:20 --> Total execution time: 0.0448
DEBUG - 2011-05-08 15:36:20 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:20 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:20 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Controller Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:21 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:21 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:21 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:21 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:21 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:21 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:21 --> Total execution time: 0.0391
DEBUG - 2011-05-08 15:36:21 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:21 --> Total execution time: 0.5200
DEBUG - 2011-05-08 15:36:23 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:23 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:23 --> Router Class Initialized
ERROR - 2011-05-08 15:36:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:36:27 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:27 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:27 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:27 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:27 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:27 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:27 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:27 --> Total execution time: 0.0291
DEBUG - 2011-05-08 15:36:29 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:29 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:29 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Controller Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:29 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:30 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:30 --> Total execution time: 1.1337
DEBUG - 2011-05-08 15:36:32 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:32 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Router Class Initialized
ERROR - 2011-05-08 15:36:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:36:32 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:32 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:32 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:32 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:32 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:32 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:32 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:32 --> Total execution time: 0.0281
DEBUG - 2011-05-08 15:36:42 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:42 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:42 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:42 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:42 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:42 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:42 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:42 --> Total execution time: 0.0308
DEBUG - 2011-05-08 15:36:43 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:43 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:43 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Controller Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:43 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:44 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:44 --> Total execution time: 0.6020
DEBUG - 2011-05-08 15:36:47 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:47 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:47 --> Router Class Initialized
ERROR - 2011-05-08 15:36:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:36:55 --> Config Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:36:55 --> URI Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Router Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Output Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Input Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:36:55 --> Language Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Loader Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Controller Class Initialized
ERROR - 2011-05-08 15:36:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:36:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:55 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Model Class Initialized
DEBUG - 2011-05-08 15:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:36:55 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:36:55 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:36:55 --> Final output sent to browser
DEBUG - 2011-05-08 15:36:55 --> Total execution time: 0.0289
DEBUG - 2011-05-08 15:37:02 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:02 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:02 --> Router Class Initialized
DEBUG - 2011-05-08 15:37:02 --> Output Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Input Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:37:03 --> Language Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Loader Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Controller Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:37:03 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:37:03 --> Final output sent to browser
DEBUG - 2011-05-08 15:37:03 --> Total execution time: 0.7304
DEBUG - 2011-05-08 15:37:04 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:04 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Router Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Output Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Input Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:37:04 --> Language Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Loader Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Controller Class Initialized
ERROR - 2011-05-08 15:37:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:37:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:37:04 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:37:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:37:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:37:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:37:04 --> Final output sent to browser
DEBUG - 2011-05-08 15:37:04 --> Total execution time: 0.1096
DEBUG - 2011-05-08 15:37:06 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:06 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:06 --> Router Class Initialized
ERROR - 2011-05-08 15:37:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:37:20 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:20 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Router Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Output Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Input Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:37:20 --> Language Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Loader Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Controller Class Initialized
ERROR - 2011-05-08 15:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:37:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:37:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:37:20 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:37:20 --> Final output sent to browser
DEBUG - 2011-05-08 15:37:20 --> Total execution time: 0.0639
DEBUG - 2011-05-08 15:37:21 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:21 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Router Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Output Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Input Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:37:21 --> Language Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Loader Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Controller Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Model Class Initialized
DEBUG - 2011-05-08 15:37:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:37:21 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:37:22 --> Final output sent to browser
DEBUG - 2011-05-08 15:37:22 --> Total execution time: 0.5349
DEBUG - 2011-05-08 15:37:24 --> Config Class Initialized
DEBUG - 2011-05-08 15:37:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:37:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:37:24 --> URI Class Initialized
DEBUG - 2011-05-08 15:37:24 --> Router Class Initialized
ERROR - 2011-05-08 15:37:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:52:06 --> Config Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:52:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:52:07 --> URI Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Router Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Output Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Input Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:52:07 --> Language Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Loader Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Controller Class Initialized
ERROR - 2011-05-08 15:52:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:52:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:52:07 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:52:07 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:52:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:52:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:52:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:52:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:52:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:52:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:52:08 --> Final output sent to browser
DEBUG - 2011-05-08 15:52:08 --> Total execution time: 1.7172
DEBUG - 2011-05-08 15:52:09 --> Config Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:52:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:52:09 --> URI Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Router Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Output Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Input Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:52:09 --> Language Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Loader Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Controller Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:52:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:52:10 --> Final output sent to browser
DEBUG - 2011-05-08 15:52:10 --> Total execution time: 0.6814
DEBUG - 2011-05-08 15:52:11 --> Config Class Initialized
DEBUG - 2011-05-08 15:52:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:52:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:52:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:52:11 --> URI Class Initialized
DEBUG - 2011-05-08 15:52:11 --> Router Class Initialized
ERROR - 2011-05-08 15:52:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 15:52:34 --> Config Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:52:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:52:34 --> URI Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Router Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Output Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Input Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:52:34 --> Language Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Loader Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Controller Class Initialized
ERROR - 2011-05-08 15:52:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:52:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:52:34 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:52:34 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:52:34 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:52:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:52:34 --> Final output sent to browser
DEBUG - 2011-05-08 15:52:34 --> Total execution time: 0.0359
DEBUG - 2011-05-08 15:52:35 --> Config Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:52:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:52:35 --> URI Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Router Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Output Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Input Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:52:35 --> Language Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Loader Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Controller Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Model Class Initialized
DEBUG - 2011-05-08 15:52:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:52:35 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:52:36 --> Final output sent to browser
DEBUG - 2011-05-08 15:52:36 --> Total execution time: 0.6703
DEBUG - 2011-05-08 15:55:07 --> Config Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 15:55:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 15:55:07 --> URI Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Router Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Output Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Input Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 15:55:07 --> Language Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Loader Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Controller Class Initialized
ERROR - 2011-05-08 15:55:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 15:55:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:55:07 --> Model Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Model Class Initialized
DEBUG - 2011-05-08 15:55:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 15:55:07 --> Database Driver Class Initialized
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 15:55:07 --> Helper loaded: url_helper
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 15:55:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 15:55:07 --> Final output sent to browser
DEBUG - 2011-05-08 15:55:07 --> Total execution time: 0.0280
DEBUG - 2011-05-08 16:12:51 --> Config Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:12:51 --> URI Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Router Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Output Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Input Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:12:51 --> Language Class Initialized
DEBUG - 2011-05-08 16:12:51 --> Loader Class Initialized
DEBUG - 2011-05-08 16:12:52 --> Controller Class Initialized
DEBUG - 2011-05-08 16:12:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:12:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:12:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:12:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:12:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:12:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:12:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:12:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:12:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:12:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:12:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:12:52 --> Final output sent to browser
DEBUG - 2011-05-08 16:12:52 --> Total execution time: 0.6134
DEBUG - 2011-05-08 16:17:02 --> Config Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:17:02 --> URI Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Router Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Output Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Input Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:17:02 --> Language Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Loader Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Controller Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:17:02 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:17:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:17:02 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:17:02 --> Final output sent to browser
DEBUG - 2011-05-08 16:17:02 --> Total execution time: 0.1197
DEBUG - 2011-05-08 16:17:31 --> Config Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:17:31 --> URI Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Router Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Output Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Input Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:17:31 --> Language Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Loader Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Controller Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:17:31 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:17:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:17:31 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:17:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:17:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:17:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:17:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:17:31 --> Final output sent to browser
DEBUG - 2011-05-08 16:17:31 --> Total execution time: 0.2484
DEBUG - 2011-05-08 16:17:33 --> Config Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:17:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:17:33 --> URI Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Router Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Output Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Input Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:17:33 --> Language Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Loader Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Controller Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:17:33 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:17:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:17:33 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:17:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:17:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:17:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:17:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:17:33 --> Final output sent to browser
DEBUG - 2011-05-08 16:17:33 --> Total execution time: 0.0449
DEBUG - 2011-05-08 16:17:56 --> Config Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:17:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:17:56 --> URI Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Router Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Output Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Input Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:17:56 --> Language Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Loader Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Controller Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:17:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:17:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:17:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:17:57 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:17:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:17:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:17:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:17:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:17:57 --> Final output sent to browser
DEBUG - 2011-05-08 16:17:57 --> Total execution time: 0.6495
DEBUG - 2011-05-08 16:18:49 --> Config Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:18:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:18:49 --> URI Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Router Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Output Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Input Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:18:49 --> Language Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Loader Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Controller Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:18:49 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:18:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:18:49 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:18:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:18:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:18:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:18:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:18:49 --> Final output sent to browser
DEBUG - 2011-05-08 16:18:49 --> Total execution time: 0.2215
DEBUG - 2011-05-08 16:18:50 --> Config Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:18:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:18:50 --> URI Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Router Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Output Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Input Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:18:50 --> Language Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Loader Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Controller Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:18:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:18:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:18:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:18:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:18:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:18:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:18:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:18:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:18:50 --> Final output sent to browser
DEBUG - 2011-05-08 16:18:50 --> Total execution time: 0.0462
DEBUG - 2011-05-08 16:19:25 --> Config Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:19:25 --> URI Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Router Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Output Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Input Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:19:25 --> Language Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Loader Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Controller Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:19:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:19:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:19:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:19:25 --> Final output sent to browser
DEBUG - 2011-05-08 16:19:25 --> Total execution time: 0.2322
DEBUG - 2011-05-08 16:19:28 --> Config Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:19:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:19:28 --> URI Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Router Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Output Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Input Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:19:28 --> Language Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Loader Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Controller Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:19:29 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:19:29 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:19:29 --> Final output sent to browser
DEBUG - 2011-05-08 16:19:29 --> Total execution time: 0.0451
DEBUG - 2011-05-08 16:19:58 --> Config Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:19:58 --> URI Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Router Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Output Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Input Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:19:58 --> Language Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Loader Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Controller Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:19:58 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:19:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:19:58 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:19:58 --> Final output sent to browser
DEBUG - 2011-05-08 16:19:58 --> Total execution time: 0.2253
DEBUG - 2011-05-08 16:20:09 --> Config Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:20:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:20:09 --> URI Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Router Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Output Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Input Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:20:09 --> Language Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Loader Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Controller Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:20:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:20:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:20:09 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:20:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:20:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:20:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:20:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:20:09 --> Final output sent to browser
DEBUG - 2011-05-08 16:20:09 --> Total execution time: 0.0536
DEBUG - 2011-05-08 16:20:20 --> Config Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:20:20 --> URI Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Router Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Output Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Input Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:20:20 --> Language Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Loader Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Controller Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:20:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:20:21 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:20:21 --> Final output sent to browser
DEBUG - 2011-05-08 16:20:21 --> Total execution time: 0.5419
DEBUG - 2011-05-08 16:20:38 --> Config Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:20:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:20:38 --> URI Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Router Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Output Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Input Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:20:38 --> Language Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Loader Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Controller Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:20:38 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:20:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:20:38 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:20:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:20:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:20:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:20:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:20:38 --> Final output sent to browser
DEBUG - 2011-05-08 16:20:38 --> Total execution time: 0.0457
DEBUG - 2011-05-08 16:20:46 --> Config Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:20:46 --> URI Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Router Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Output Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Input Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:20:46 --> Language Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Loader Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Controller Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:20:46 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:20:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:20:46 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:20:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:20:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:20:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:20:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:20:46 --> Final output sent to browser
DEBUG - 2011-05-08 16:20:46 --> Total execution time: 0.1832
DEBUG - 2011-05-08 16:20:58 --> Config Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:20:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:20:58 --> URI Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Router Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Output Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Input Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:20:58 --> Language Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Loader Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Controller Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:20:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:20:58 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:20:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:20:58 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:20:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:20:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:20:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:20:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:20:58 --> Final output sent to browser
DEBUG - 2011-05-08 16:20:58 --> Total execution time: 0.0430
DEBUG - 2011-05-08 16:21:00 --> Config Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:21:00 --> URI Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Router Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Output Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Input Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:21:00 --> Language Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Loader Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Controller Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:21:00 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:21:00 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:21:00 --> Final output sent to browser
DEBUG - 2011-05-08 16:21:00 --> Total execution time: 0.0454
DEBUG - 2011-05-08 16:21:24 --> Config Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:21:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:21:24 --> URI Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Router Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Output Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Input Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:21:24 --> Language Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Loader Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Controller Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:21:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:21:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:21:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:21:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:21:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:21:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:21:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:21:24 --> Final output sent to browser
DEBUG - 2011-05-08 16:21:24 --> Total execution time: 0.1843
DEBUG - 2011-05-08 16:21:29 --> Config Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:21:29 --> URI Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Router Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Output Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Input Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:21:29 --> Language Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Loader Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Controller Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:21:29 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:21:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:21:29 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:21:29 --> Final output sent to browser
DEBUG - 2011-05-08 16:21:29 --> Total execution time: 0.0431
DEBUG - 2011-05-08 16:21:46 --> Config Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:21:46 --> URI Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Router Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Output Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Input Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:21:46 --> Language Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Loader Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Controller Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:21:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:21:46 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:21:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:21:46 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:21:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:21:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:21:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:21:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:21:46 --> Final output sent to browser
DEBUG - 2011-05-08 16:21:46 --> Total execution time: 0.0601
DEBUG - 2011-05-08 16:22:02 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:02 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:02 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:02 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:02 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:02 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:02 --> Total execution time: 0.2094
DEBUG - 2011-05-08 16:22:03 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:03 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:03 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:03 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:03 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:03 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:03 --> Total execution time: 0.0539
DEBUG - 2011-05-08 16:22:04 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:04 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:04 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:04 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:04 --> Total execution time: 0.0489
DEBUG - 2011-05-08 16:22:22 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:22 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:22 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:22 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:22 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:22 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:22 --> Total execution time: 0.2334
DEBUG - 2011-05-08 16:22:23 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:23 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:23 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:24 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:24 --> Total execution time: 0.0519
DEBUG - 2011-05-08 16:22:52 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:52 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:52 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:52 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:52 --> Total execution time: 0.2535
DEBUG - 2011-05-08 16:22:54 --> Config Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:22:54 --> URI Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Router Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Output Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Input Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:22:54 --> Language Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Loader Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Controller Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:22:54 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:22:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:22:54 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:22:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:22:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:22:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:22:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:22:54 --> Final output sent to browser
DEBUG - 2011-05-08 16:22:54 --> Total execution time: 0.1190
DEBUG - 2011-05-08 16:23:06 --> Config Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:23:06 --> URI Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Router Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Output Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Input Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:23:06 --> Language Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Loader Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Controller Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:23:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:23:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:23:07 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:23:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:23:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:23:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:23:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:23:07 --> Final output sent to browser
DEBUG - 2011-05-08 16:23:07 --> Total execution time: 0.2280
DEBUG - 2011-05-08 16:23:08 --> Config Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:23:08 --> URI Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Router Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Output Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Input Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:23:08 --> Language Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Loader Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Controller Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:23:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:23:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:23:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:23:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:23:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:23:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:23:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:23:08 --> Final output sent to browser
DEBUG - 2011-05-08 16:23:08 --> Total execution time: 0.0499
DEBUG - 2011-05-08 16:23:38 --> Config Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:23:38 --> URI Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Router Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Output Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Input Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:23:38 --> Language Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Loader Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Controller Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:23:38 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:23:38 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:23:38 --> Final output sent to browser
DEBUG - 2011-05-08 16:23:38 --> Total execution time: 0.1908
DEBUG - 2011-05-08 16:23:45 --> Config Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:23:45 --> URI Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Router Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Output Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Input Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:23:45 --> Language Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Loader Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Controller Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:23:45 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:23:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:23:45 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:23:45 --> Final output sent to browser
DEBUG - 2011-05-08 16:23:45 --> Total execution time: 0.1328
DEBUG - 2011-05-08 16:23:54 --> Config Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:23:54 --> URI Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Router Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Output Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Input Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:23:54 --> Language Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Loader Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Controller Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Model Class Initialized
DEBUG - 2011-05-08 16:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:23:54 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:23:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:23:54 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:23:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:23:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:23:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:23:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:23:54 --> Final output sent to browser
DEBUG - 2011-05-08 16:23:54 --> Total execution time: 0.3547
DEBUG - 2011-05-08 16:24:13 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:13 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:13 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:13 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:13 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:13 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:13 --> Total execution time: 0.2041
DEBUG - 2011-05-08 16:24:35 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:35 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:35 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:35 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:35 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:35 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:35 --> Total execution time: 0.2311
DEBUG - 2011-05-08 16:24:46 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:46 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:46 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:46 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:46 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:46 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:46 --> Total execution time: 0.0499
DEBUG - 2011-05-08 16:24:48 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:48 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:48 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:48 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:48 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:48 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:48 --> Total execution time: 0.0702
DEBUG - 2011-05-08 16:24:49 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:50 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:50 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:50 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:50 --> Total execution time: 0.0510
DEBUG - 2011-05-08 16:24:53 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:53 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:53 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:53 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:53 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:53 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:53 --> Total execution time: 0.1782
DEBUG - 2011-05-08 16:24:56 --> Config Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:24:56 --> URI Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Router Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Output Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Input Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:24:56 --> Language Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Loader Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Controller Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Model Class Initialized
DEBUG - 2011-05-08 16:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:24:56 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:24:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:24:56 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:24:56 --> Final output sent to browser
DEBUG - 2011-05-08 16:24:56 --> Total execution time: 0.0463
DEBUG - 2011-05-08 16:25:08 --> Config Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:25:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:25:08 --> URI Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Router Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Output Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Input Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:25:08 --> Language Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Loader Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Controller Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:25:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:25:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:25:09 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:25:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:25:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:25:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:25:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:25:09 --> Final output sent to browser
DEBUG - 2011-05-08 16:25:09 --> Total execution time: 0.6754
DEBUG - 2011-05-08 16:25:09 --> Config Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:25:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:25:09 --> URI Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Router Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Output Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Input Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:25:09 --> Language Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Loader Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Controller Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:25:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:25:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:25:10 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:25:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:25:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:25:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:25:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:25:10 --> Final output sent to browser
DEBUG - 2011-05-08 16:25:10 --> Total execution time: 0.1241
DEBUG - 2011-05-08 16:25:47 --> Config Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:25:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:25:47 --> URI Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Router Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Output Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Input Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:25:47 --> Language Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Loader Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Controller Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:25:47 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:25:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:25:48 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:25:48 --> Final output sent to browser
DEBUG - 2011-05-08 16:25:48 --> Total execution time: 0.6135
DEBUG - 2011-05-08 16:25:50 --> Config Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:25:50 --> URI Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Router Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Output Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Input Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:25:50 --> Language Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Loader Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Controller Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Model Class Initialized
DEBUG - 2011-05-08 16:25:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:25:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:25:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:25:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:25:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:25:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:25:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:25:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:25:50 --> Final output sent to browser
DEBUG - 2011-05-08 16:25:50 --> Total execution time: 0.0687
DEBUG - 2011-05-08 16:26:01 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:01 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:01 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:01 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:01 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:01 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:01 --> Total execution time: 0.2767
DEBUG - 2011-05-08 16:26:02 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:02 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:02 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:02 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:02 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:02 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:02 --> Total execution time: 0.0521
DEBUG - 2011-05-08 16:26:15 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:15 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:15 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:15 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:15 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:15 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:15 --> Total execution time: 0.2212
DEBUG - 2011-05-08 16:26:20 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:20 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:20 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:20 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:20 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:20 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:20 --> Total execution time: 0.0488
DEBUG - 2011-05-08 16:26:37 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:37 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:37 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:37 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:37 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:37 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:37 --> Total execution time: 0.2295
DEBUG - 2011-05-08 16:26:43 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:43 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:43 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:43 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:43 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:43 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:43 --> Total execution time: 0.0481
DEBUG - 2011-05-08 16:26:58 --> Config Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:26:58 --> URI Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Router Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Output Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Input Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:26:58 --> Language Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Loader Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Controller Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Model Class Initialized
DEBUG - 2011-05-08 16:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:26:58 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:26:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:26:59 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:26:59 --> Final output sent to browser
DEBUG - 2011-05-08 16:26:59 --> Total execution time: 0.2159
DEBUG - 2011-05-08 16:27:00 --> Config Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:27:00 --> URI Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Router Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Output Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Input Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:27:00 --> Language Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Loader Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Controller Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:27:00 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:27:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:27:00 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:27:00 --> Final output sent to browser
DEBUG - 2011-05-08 16:27:00 --> Total execution time: 0.0529
DEBUG - 2011-05-08 16:27:21 --> Config Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:27:21 --> URI Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Router Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Output Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Input Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:27:21 --> Language Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Loader Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Controller Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:27:21 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:27:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:27:22 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:27:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:27:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:27:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:27:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:27:22 --> Final output sent to browser
DEBUG - 2011-05-08 16:27:22 --> Total execution time: 0.2696
DEBUG - 2011-05-08 16:27:23 --> Config Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:27:23 --> URI Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Router Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Output Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Input Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:27:23 --> Language Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Loader Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Controller Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Model Class Initialized
DEBUG - 2011-05-08 16:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:27:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:27:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:27:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:27:23 --> Final output sent to browser
DEBUG - 2011-05-08 16:27:23 --> Total execution time: 0.0533
DEBUG - 2011-05-08 16:28:06 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:06 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:06 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:06 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:06 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:06 --> Total execution time: 0.1955
DEBUG - 2011-05-08 16:28:09 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:09 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:09 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:09 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:09 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:09 --> Total execution time: 0.0465
DEBUG - 2011-05-08 16:28:24 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:24 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:24 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:24 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:24 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:24 --> Total execution time: 0.3155
DEBUG - 2011-05-08 16:28:25 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:25 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:25 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:25 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:25 --> Total execution time: 0.0542
DEBUG - 2011-05-08 16:28:39 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:39 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:39 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:39 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:39 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:39 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:39 --> Total execution time: 0.2464
DEBUG - 2011-05-08 16:28:42 --> Config Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:28:42 --> URI Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Router Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Output Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Input Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:28:42 --> Language Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Loader Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Controller Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Model Class Initialized
DEBUG - 2011-05-08 16:28:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:28:42 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:28:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:28:42 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:28:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:28:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:28:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:28:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:28:42 --> Final output sent to browser
DEBUG - 2011-05-08 16:28:42 --> Total execution time: 0.0440
DEBUG - 2011-05-08 16:36:27 --> Config Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:36:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:36:27 --> URI Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Router Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Output Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Input Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:36:27 --> Language Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Loader Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Controller Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Model Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Model Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Model Class Initialized
DEBUG - 2011-05-08 16:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:36:27 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:36:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:36:27 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:36:27 --> Final output sent to browser
DEBUG - 2011-05-08 16:36:27 --> Total execution time: 0.1348
DEBUG - 2011-05-08 16:53:49 --> Config Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:53:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:53:49 --> URI Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Router Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Output Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Input Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:53:49 --> Language Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Loader Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Controller Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Model Class Initialized
DEBUG - 2011-05-08 16:53:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:53:49 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:53:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 16:53:49 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:53:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:53:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:53:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:53:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:53:49 --> Final output sent to browser
DEBUG - 2011-05-08 16:53:49 --> Total execution time: 0.4324
DEBUG - 2011-05-08 16:53:51 --> Config Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 16:53:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 16:53:51 --> URI Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Router Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Output Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Input Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 16:53:51 --> Language Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Loader Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Controller Class Initialized
ERROR - 2011-05-08 16:53:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 16:53:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 16:53:51 --> Model Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Model Class Initialized
DEBUG - 2011-05-08 16:53:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 16:53:51 --> Database Driver Class Initialized
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 16:53:51 --> Helper loaded: url_helper
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 16:53:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 16:53:51 --> Final output sent to browser
DEBUG - 2011-05-08 16:53:51 --> Total execution time: 0.0991
DEBUG - 2011-05-08 18:17:50 --> Config Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:17:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:17:50 --> URI Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Router Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Output Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Input Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:17:50 --> Language Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Loader Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Controller Class Initialized
ERROR - 2011-05-08 18:17:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:17:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:17:50 --> Model Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Model Class Initialized
DEBUG - 2011-05-08 18:17:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:17:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:17:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:17:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:17:50 --> Final output sent to browser
DEBUG - 2011-05-08 18:17:50 --> Total execution time: 0.3998
DEBUG - 2011-05-08 18:17:51 --> Config Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:17:51 --> URI Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Router Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Output Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Input Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:17:51 --> Language Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Loader Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Controller Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Model Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Model Class Initialized
DEBUG - 2011-05-08 18:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:17:51 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:17:52 --> Final output sent to browser
DEBUG - 2011-05-08 18:17:52 --> Total execution time: 0.9561
DEBUG - 2011-05-08 18:17:53 --> Config Class Initialized
DEBUG - 2011-05-08 18:17:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:17:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:17:53 --> URI Class Initialized
DEBUG - 2011-05-08 18:17:53 --> Router Class Initialized
ERROR - 2011-05-08 18:17:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:23 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:23 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:23 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Controller Class Initialized
ERROR - 2011-05-08 18:18:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:18:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:23 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:23 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:23 --> Total execution time: 0.0559
DEBUG - 2011-05-08 18:18:23 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:23 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:23 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Controller Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:24 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:24 --> Total execution time: 0.6661
DEBUG - 2011-05-08 18:18:24 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:24 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:24 --> Router Class Initialized
ERROR - 2011-05-08 18:18:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:37 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:37 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:37 --> No URI present. Default controller set.
DEBUG - 2011-05-08 18:18:37 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:37 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Controller Class Initialized
DEBUG - 2011-05-08 18:18:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 18:18:37 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:37 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:37 --> Total execution time: 0.0986
DEBUG - 2011-05-08 18:18:37 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:37 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:37 --> Router Class Initialized
ERROR - 2011-05-08 18:18:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:38 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:38 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:38 --> Router Class Initialized
ERROR - 2011-05-08 18:18:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:39 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:39 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:39 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:39 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:39 --> Router Class Initialized
ERROR - 2011-05-08 18:18:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:41 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:41 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:41 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Controller Class Initialized
ERROR - 2011-05-08 18:18:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:18:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:41 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:41 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:41 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:41 --> Total execution time: 0.0337
DEBUG - 2011-05-08 18:18:41 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:41 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:41 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Controller Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:42 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:42 --> Total execution time: 0.5467
DEBUG - 2011-05-08 18:18:42 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:42 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:42 --> Router Class Initialized
ERROR - 2011-05-08 18:18:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:45 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:45 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:45 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Controller Class Initialized
ERROR - 2011-05-08 18:18:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:18:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:45 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:45 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:45 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:45 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:45 --> Total execution time: 0.0465
DEBUG - 2011-05-08 18:18:46 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:46 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:46 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Controller Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:46 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:46 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:46 --> Total execution time: 0.5839
DEBUG - 2011-05-08 18:18:47 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:47 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:47 --> Router Class Initialized
ERROR - 2011-05-08 18:18:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:18:51 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:51 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:51 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Controller Class Initialized
ERROR - 2011-05-08 18:18:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:18:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:51 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:51 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:51 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:51 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:51 --> Total execution time: 0.0318
DEBUG - 2011-05-08 18:18:52 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:52 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:52 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Controller Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:53 --> Total execution time: 0.6243
DEBUG - 2011-05-08 18:18:53 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:53 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Router Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Output Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Input Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:18:53 --> Language Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Loader Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Controller Class Initialized
ERROR - 2011-05-08 18:18:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:18:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:53 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Model Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:18:53 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:18:53 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:18:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:18:53 --> Final output sent to browser
DEBUG - 2011-05-08 18:18:53 --> Total execution time: 0.0299
DEBUG - 2011-05-08 18:18:53 --> Config Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:18:53 --> URI Class Initialized
DEBUG - 2011-05-08 18:18:53 --> Router Class Initialized
ERROR - 2011-05-08 18:18:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 18:23:24 --> Config Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:23:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:23:24 --> URI Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Router Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Output Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Input Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:23:24 --> Language Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Loader Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Controller Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Model Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Model Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Model Class Initialized
DEBUG - 2011-05-08 18:23:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:23:24 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:23:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 18:23:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:23:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:23:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:23:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:23:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:23:25 --> Final output sent to browser
DEBUG - 2011-05-08 18:23:25 --> Total execution time: 0.2620
DEBUG - 2011-05-08 18:23:26 --> Config Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:23:26 --> URI Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Router Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Output Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Input Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:23:26 --> Language Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Loader Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Controller Class Initialized
ERROR - 2011-05-08 18:23:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 18:23:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:23:26 --> Model Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Model Class Initialized
DEBUG - 2011-05-08 18:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 18:23:26 --> Database Driver Class Initialized
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 18:23:26 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:23:26 --> Final output sent to browser
DEBUG - 2011-05-08 18:23:26 --> Total execution time: 0.0360
DEBUG - 2011-05-08 18:34:09 --> Config Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 18:34:09 --> URI Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Router Class Initialized
DEBUG - 2011-05-08 18:34:09 --> No URI present. Default controller set.
DEBUG - 2011-05-08 18:34:09 --> Output Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Input Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 18:34:09 --> Language Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Loader Class Initialized
DEBUG - 2011-05-08 18:34:09 --> Controller Class Initialized
DEBUG - 2011-05-08 18:34:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 18:34:09 --> Helper loaded: url_helper
DEBUG - 2011-05-08 18:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 18:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 18:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 18:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 18:34:09 --> Final output sent to browser
DEBUG - 2011-05-08 18:34:09 --> Total execution time: 0.0814
DEBUG - 2011-05-08 19:07:09 --> Config Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:07:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:07:09 --> URI Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Router Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Output Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Input Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:07:09 --> Language Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Loader Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Controller Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:07:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:07:10 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:07:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 19:07:10 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:07:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:07:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:07:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:07:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:07:10 --> Final output sent to browser
DEBUG - 2011-05-08 19:07:10 --> Total execution time: 0.9318
DEBUG - 2011-05-08 19:07:13 --> Config Class Initialized
DEBUG - 2011-05-08 19:07:13 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:07:13 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:07:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:07:13 --> URI Class Initialized
DEBUG - 2011-05-08 19:07:13 --> Router Class Initialized
ERROR - 2011-05-08 19:07:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 19:13:16 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:16 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Router Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Output Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Input Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:13:16 --> Language Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Loader Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Controller Class Initialized
ERROR - 2011-05-08 19:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:16 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:13:16 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:16 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:13:16 --> Final output sent to browser
DEBUG - 2011-05-08 19:13:16 --> Total execution time: 0.2655
DEBUG - 2011-05-08 19:13:17 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:17 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Router Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Output Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Input Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:13:17 --> Language Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Loader Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Controller Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:13:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:13:18 --> Final output sent to browser
DEBUG - 2011-05-08 19:13:18 --> Total execution time: 0.8558
DEBUG - 2011-05-08 19:13:20 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:20 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Router Class Initialized
ERROR - 2011-05-08 19:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 19:13:20 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:20 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:20 --> Router Class Initialized
ERROR - 2011-05-08 19:13:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 19:13:44 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:44 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Router Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Output Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Input Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:13:44 --> Language Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Loader Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Controller Class Initialized
ERROR - 2011-05-08 19:13:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:13:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:13:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:44 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:13:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:13:44 --> Final output sent to browser
DEBUG - 2011-05-08 19:13:44 --> Total execution time: 0.0274
DEBUG - 2011-05-08 19:13:44 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:44 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Router Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Output Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Input Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:13:44 --> Language Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Loader Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Controller Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:13:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:13:45 --> Final output sent to browser
DEBUG - 2011-05-08 19:13:45 --> Total execution time: 0.5985
DEBUG - 2011-05-08 19:13:59 --> Config Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:13:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:13:59 --> URI Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Router Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Output Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Input Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:13:59 --> Language Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Loader Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Controller Class Initialized
ERROR - 2011-05-08 19:13:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:13:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:59 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Model Class Initialized
DEBUG - 2011-05-08 19:13:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:13:59 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:13:59 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:13:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:13:59 --> Final output sent to browser
DEBUG - 2011-05-08 19:13:59 --> Total execution time: 0.0306
DEBUG - 2011-05-08 19:14:00 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:00 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:00 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:00 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:00 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:00 --> Total execution time: 0.5053
DEBUG - 2011-05-08 19:14:07 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:07 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:07 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:07 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:07 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:07 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:07 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:07 --> Total execution time: 0.0277
DEBUG - 2011-05-08 19:14:07 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:07 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:07 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:07 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:08 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:08 --> Total execution time: 0.5901
DEBUG - 2011-05-08 19:14:16 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:16 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:16 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:16 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:16 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:16 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:16 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:16 --> Total execution time: 0.0281
DEBUG - 2011-05-08 19:14:17 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:17 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:17 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:17 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:17 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:17 --> Total execution time: 0.5173
DEBUG - 2011-05-08 19:14:19 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:19 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:19 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:19 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:19 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:19 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:19 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:19 --> Total execution time: 0.0335
DEBUG - 2011-05-08 19:14:25 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:25 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:25 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:25 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:25 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:25 --> Total execution time: 0.0314
DEBUG - 2011-05-08 19:14:26 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:26 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:26 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:26 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:27 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:27 --> Total execution time: 0.6164
DEBUG - 2011-05-08 19:14:28 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:28 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:28 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:28 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:28 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:28 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:28 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:28 --> Total execution time: 0.0300
DEBUG - 2011-05-08 19:14:41 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:41 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:41 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:41 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:41 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:41 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:41 --> Total execution time: 0.0294
DEBUG - 2011-05-08 19:14:41 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:41 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:41 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:42 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:42 --> Total execution time: 0.5172
DEBUG - 2011-05-08 19:14:54 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:54 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:54 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Controller Class Initialized
ERROR - 2011-05-08 19:14:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:14:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:54 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:54 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:14:54 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:14:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:14:54 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:54 --> Total execution time: 0.0314
DEBUG - 2011-05-08 19:14:54 --> Config Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:14:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:14:54 --> URI Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Router Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Output Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Input Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:14:54 --> Language Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Loader Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Controller Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Model Class Initialized
DEBUG - 2011-05-08 19:14:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:14:54 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:14:55 --> Final output sent to browser
DEBUG - 2011-05-08 19:14:55 --> Total execution time: 0.7138
DEBUG - 2011-05-08 19:15:09 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:09 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:09 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Controller Class Initialized
ERROR - 2011-05-08 19:15:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:15:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:09 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:15:09 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:09 --> Total execution time: 0.0293
DEBUG - 2011-05-08 19:15:09 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:09 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:09 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Controller Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:09 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:10 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:10 --> Total execution time: 0.7683
DEBUG - 2011-05-08 19:15:27 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:27 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:27 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Controller Class Initialized
ERROR - 2011-05-08 19:15:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:15:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:27 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:27 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:27 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:15:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:15:27 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:27 --> Total execution time: 0.0403
DEBUG - 2011-05-08 19:15:27 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:27 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:27 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Controller Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:27 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:28 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:28 --> Total execution time: 0.7193
DEBUG - 2011-05-08 19:15:42 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:42 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:42 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Controller Class Initialized
ERROR - 2011-05-08 19:15:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:15:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:15:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:42 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:43 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:15:43 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:15:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:15:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:15:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:15:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:15:43 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:43 --> Total execution time: 0.1041
DEBUG - 2011-05-08 19:15:44 --> Config Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:15:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:15:44 --> URI Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Router Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Output Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Input Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:15:44 --> Language Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Loader Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Controller Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Model Class Initialized
DEBUG - 2011-05-08 19:15:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:15:44 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:15:45 --> Final output sent to browser
DEBUG - 2011-05-08 19:15:45 --> Total execution time: 0.7923
DEBUG - 2011-05-08 19:16:00 --> Config Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:16:00 --> URI Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Router Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Output Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Input Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:16:00 --> Language Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Loader Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Controller Class Initialized
ERROR - 2011-05-08 19:16:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:16:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:16:00 --> Model Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Model Class Initialized
DEBUG - 2011-05-08 19:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:16:00 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:16:00 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:16:00 --> Final output sent to browser
DEBUG - 2011-05-08 19:16:00 --> Total execution time: 0.0740
DEBUG - 2011-05-08 19:16:01 --> Config Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:16:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:16:01 --> URI Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Router Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Output Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Input Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:16:01 --> Language Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Loader Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Controller Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Model Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Model Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:16:01 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:16:01 --> Final output sent to browser
DEBUG - 2011-05-08 19:16:01 --> Total execution time: 0.5206
DEBUG - 2011-05-08 19:29:07 --> Config Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:29:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:29:07 --> URI Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Router Class Initialized
DEBUG - 2011-05-08 19:29:07 --> No URI present. Default controller set.
DEBUG - 2011-05-08 19:29:07 --> Output Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Input Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:29:07 --> Language Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Loader Class Initialized
DEBUG - 2011-05-08 19:29:07 --> Controller Class Initialized
DEBUG - 2011-05-08 19:29:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 19:29:07 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:29:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:29:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:29:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:29:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:29:07 --> Final output sent to browser
DEBUG - 2011-05-08 19:29:07 --> Total execution time: 0.1532
DEBUG - 2011-05-08 19:53:03 --> Config Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:53:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:53:03 --> URI Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Router Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Output Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Input Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:53:03 --> Language Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Loader Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Controller Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Model Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Model Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Model Class Initialized
DEBUG - 2011-05-08 19:53:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:53:03 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:53:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 19:53:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:53:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:53:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:53:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:53:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:53:04 --> Final output sent to browser
DEBUG - 2011-05-08 19:53:04 --> Total execution time: 0.6514
DEBUG - 2011-05-08 19:53:05 --> Config Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Hooks Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Utf8 Class Initialized
DEBUG - 2011-05-08 19:53:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 19:53:05 --> URI Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Router Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Output Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Input Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 19:53:05 --> Language Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Loader Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Controller Class Initialized
ERROR - 2011-05-08 19:53:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 19:53:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 19:53:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:53:05 --> Model Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Model Class Initialized
DEBUG - 2011-05-08 19:53:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 19:53:05 --> Database Driver Class Initialized
DEBUG - 2011-05-08 19:53:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 19:53:06 --> Helper loaded: url_helper
DEBUG - 2011-05-08 19:53:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 19:53:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 19:53:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 19:53:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 19:53:06 --> Final output sent to browser
DEBUG - 2011-05-08 19:53:06 --> Total execution time: 0.0934
DEBUG - 2011-05-08 20:56:59 --> Config Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Hooks Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Utf8 Class Initialized
DEBUG - 2011-05-08 20:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 20:56:59 --> URI Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Router Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Output Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Input Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 20:56:59 --> Language Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Loader Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Controller Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Model Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Model Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Model Class Initialized
DEBUG - 2011-05-08 20:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 20:56:59 --> Database Driver Class Initialized
DEBUG - 2011-05-08 20:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 20:56:59 --> Helper loaded: url_helper
DEBUG - 2011-05-08 20:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 20:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 20:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 20:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 20:56:59 --> Final output sent to browser
DEBUG - 2011-05-08 20:56:59 --> Total execution time: 0.6457
DEBUG - 2011-05-08 21:25:25 --> Config Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:25:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:25:25 --> URI Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Router Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Output Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Input Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:25:25 --> Language Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Loader Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Controller Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Model Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Model Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Model Class Initialized
DEBUG - 2011-05-08 21:25:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:25:25 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:25:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:25:26 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:25:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:25:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:25:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:25:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:25:26 --> Final output sent to browser
DEBUG - 2011-05-08 21:25:26 --> Total execution time: 0.7144
DEBUG - 2011-05-08 21:25:40 --> Config Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:25:40 --> URI Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Router Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Output Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Input Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:25:40 --> Language Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Loader Class Initialized
DEBUG - 2011-05-08 21:25:40 --> Controller Class Initialized
ERROR - 2011-05-08 21:25:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 21:25:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 21:25:41 --> Model Class Initialized
DEBUG - 2011-05-08 21:25:41 --> Model Class Initialized
DEBUG - 2011-05-08 21:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:25:41 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 21:25:41 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:25:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:25:41 --> Final output sent to browser
DEBUG - 2011-05-08 21:25:41 --> Total execution time: 0.1108
DEBUG - 2011-05-08 21:55:03 --> Config Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:55:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:55:03 --> URI Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Router Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Output Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Input Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:55:03 --> Language Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Loader Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Controller Class Initialized
DEBUG - 2011-05-08 21:55:03 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:04 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:04 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:55:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:55:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:55:04 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:55:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:55:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:55:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:55:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:55:04 --> Final output sent to browser
DEBUG - 2011-05-08 21:55:04 --> Total execution time: 1.1385
DEBUG - 2011-05-08 21:55:27 --> Config Class Initialized
DEBUG - 2011-05-08 21:55:27 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:55:27 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:55:27 --> URI Class Initialized
DEBUG - 2011-05-08 21:55:27 --> Router Class Initialized
ERROR - 2011-05-08 21:55:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 21:55:40 --> Config Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:55:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:55:40 --> URI Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Router Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Output Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Input Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:55:40 --> Language Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Loader Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Controller Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Model Class Initialized
DEBUG - 2011-05-08 21:55:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:55:40 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:55:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:55:41 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:55:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:55:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:55:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:55:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:55:41 --> Final output sent to browser
DEBUG - 2011-05-08 21:55:41 --> Total execution time: 0.2770
DEBUG - 2011-05-08 21:55:47 --> Config Class Initialized
DEBUG - 2011-05-08 21:55:47 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:55:47 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:55:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:55:47 --> URI Class Initialized
DEBUG - 2011-05-08 21:55:47 --> Router Class Initialized
ERROR - 2011-05-08 21:55:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 21:56:11 --> Config Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:56:11 --> URI Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Router Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Output Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Input Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:56:11 --> Language Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Loader Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Controller Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:56:11 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:56:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:56:12 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:56:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:56:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:56:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:56:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:56:12 --> Final output sent to browser
DEBUG - 2011-05-08 21:56:12 --> Total execution time: 1.2059
DEBUG - 2011-05-08 21:56:18 --> Config Class Initialized
DEBUG - 2011-05-08 21:56:18 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:56:18 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:56:18 --> URI Class Initialized
DEBUG - 2011-05-08 21:56:18 --> Router Class Initialized
ERROR - 2011-05-08 21:56:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 21:56:50 --> Config Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:56:50 --> URI Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Router Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Output Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Input Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:56:50 --> Language Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Loader Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Controller Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:56:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:56:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:56:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:56:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:56:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:56:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:56:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:56:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:56:50 --> Final output sent to browser
DEBUG - 2011-05-08 21:56:50 --> Total execution time: 0.2607
DEBUG - 2011-05-08 21:58:50 --> Config Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:58:50 --> URI Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Router Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Output Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Input Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:58:50 --> Language Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Loader Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Controller Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Model Class Initialized
DEBUG - 2011-05-08 21:58:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:58:50 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:58:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:58:50 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:58:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:58:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:58:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:58:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:58:50 --> Final output sent to browser
DEBUG - 2011-05-08 21:58:50 --> Total execution time: 0.2629
DEBUG - 2011-05-08 21:59:28 --> Config Class Initialized
DEBUG - 2011-05-08 21:59:28 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:59:28 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:59:28 --> URI Class Initialized
DEBUG - 2011-05-08 21:59:28 --> Router Class Initialized
ERROR - 2011-05-08 21:59:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 21:59:35 --> Config Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:59:35 --> URI Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Router Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Output Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Input Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 21:59:35 --> Language Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Loader Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Controller Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Model Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Model Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Model Class Initialized
DEBUG - 2011-05-08 21:59:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 21:59:35 --> Database Driver Class Initialized
DEBUG - 2011-05-08 21:59:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 21:59:35 --> Helper loaded: url_helper
DEBUG - 2011-05-08 21:59:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 21:59:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 21:59:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 21:59:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 21:59:35 --> Final output sent to browser
DEBUG - 2011-05-08 21:59:35 --> Total execution time: 0.2387
DEBUG - 2011-05-08 21:59:38 --> Config Class Initialized
DEBUG - 2011-05-08 21:59:38 --> Hooks Class Initialized
DEBUG - 2011-05-08 21:59:38 --> Utf8 Class Initialized
DEBUG - 2011-05-08 21:59:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 21:59:38 --> URI Class Initialized
DEBUG - 2011-05-08 21:59:38 --> Router Class Initialized
ERROR - 2011-05-08 21:59:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 22:00:04 --> Config Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:00:04 --> URI Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Router Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Output Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Input Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:00:04 --> Language Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Loader Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Controller Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:00:04 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:00:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:00:05 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:00:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:00:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:00:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:00:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:00:05 --> Final output sent to browser
DEBUG - 2011-05-08 22:00:05 --> Total execution time: 0.6621
DEBUG - 2011-05-08 22:00:08 --> Config Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:00:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:00:08 --> URI Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Router Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Output Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Input Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:00:08 --> Language Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Loader Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Controller Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Model Class Initialized
DEBUG - 2011-05-08 22:00:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:00:08 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:00:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:00:08 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:00:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:00:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:00:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:00:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:00:08 --> Final output sent to browser
DEBUG - 2011-05-08 22:00:08 --> Total execution time: 0.1160
DEBUG - 2011-05-08 22:00:12 --> Config Class Initialized
DEBUG - 2011-05-08 22:00:12 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:00:12 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:00:12 --> URI Class Initialized
DEBUG - 2011-05-08 22:00:12 --> Router Class Initialized
ERROR - 2011-05-08 22:00:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 22:01:52 --> Config Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:01:52 --> URI Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Router Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Output Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Input Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:01:52 --> Language Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Loader Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Controller Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Model Class Initialized
DEBUG - 2011-05-08 22:01:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:01:52 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:01:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:01:52 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:01:52 --> Final output sent to browser
DEBUG - 2011-05-08 22:01:52 --> Total execution time: 0.0432
DEBUG - 2011-05-08 22:01:55 --> Config Class Initialized
DEBUG - 2011-05-08 22:01:55 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:01:55 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:01:55 --> URI Class Initialized
DEBUG - 2011-05-08 22:01:55 --> Router Class Initialized
ERROR - 2011-05-08 22:01:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 22:02:23 --> Config Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:02:23 --> URI Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Router Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Output Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Input Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:02:23 --> Language Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Loader Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Controller Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:02:23 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:02:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:02:23 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:02:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:02:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:02:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:02:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:02:23 --> Final output sent to browser
DEBUG - 2011-05-08 22:02:23 --> Total execution time: 0.2202
DEBUG - 2011-05-08 22:02:25 --> Config Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:02:25 --> URI Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Router Class Initialized
ERROR - 2011-05-08 22:02:25 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-08 22:02:25 --> Config Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:02:25 --> URI Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Router Class Initialized
DEBUG - 2011-05-08 22:02:25 --> No URI present. Default controller set.
DEBUG - 2011-05-08 22:02:25 --> Output Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Input Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:02:25 --> Language Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Loader Class Initialized
DEBUG - 2011-05-08 22:02:25 --> Controller Class Initialized
DEBUG - 2011-05-08 22:02:25 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-08 22:02:25 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:02:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:02:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:02:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:02:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:02:25 --> Final output sent to browser
DEBUG - 2011-05-08 22:02:25 --> Total execution time: 0.0879
DEBUG - 2011-05-08 22:02:26 --> Config Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:02:26 --> URI Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Router Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Output Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Input Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:02:26 --> Language Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Loader Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Controller Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Model Class Initialized
DEBUG - 2011-05-08 22:02:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:02:26 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:02:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:02:26 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:02:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:02:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:02:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:02:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:02:26 --> Final output sent to browser
DEBUG - 2011-05-08 22:02:26 --> Total execution time: 0.0536
DEBUG - 2011-05-08 22:02:32 --> Config Class Initialized
DEBUG - 2011-05-08 22:02:32 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:02:32 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:02:32 --> URI Class Initialized
DEBUG - 2011-05-08 22:02:32 --> Router Class Initialized
ERROR - 2011-05-08 22:02:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-08 22:57:00 --> Config Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:57:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:57:00 --> URI Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Router Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Output Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Input Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:57:00 --> Language Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Loader Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Controller Class Initialized
DEBUG - 2011-05-08 22:57:00 --> Model Class Initialized
DEBUG - 2011-05-08 22:57:01 --> Model Class Initialized
DEBUG - 2011-05-08 22:57:01 --> Model Class Initialized
DEBUG - 2011-05-08 22:57:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:57:01 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-08 22:57:01 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:57:01 --> Final output sent to browser
DEBUG - 2011-05-08 22:57:01 --> Total execution time: 0.7671
DEBUG - 2011-05-08 22:57:02 --> Config Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Hooks Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Utf8 Class Initialized
DEBUG - 2011-05-08 22:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 22:57:02 --> URI Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Router Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Output Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Input Class Initialized
DEBUG - 2011-05-08 22:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 22:57:02 --> Language Class Initialized
DEBUG - 2011-05-08 22:57:03 --> Loader Class Initialized
DEBUG - 2011-05-08 22:57:03 --> Controller Class Initialized
ERROR - 2011-05-08 22:57:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 22:57:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 22:57:03 --> Model Class Initialized
DEBUG - 2011-05-08 22:57:03 --> Model Class Initialized
DEBUG - 2011-05-08 22:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 22:57:03 --> Database Driver Class Initialized
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 22:57:03 --> Helper loaded: url_helper
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 22:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 22:57:03 --> Final output sent to browser
DEBUG - 2011-05-08 22:57:03 --> Total execution time: 0.1114
DEBUG - 2011-05-08 23:02:06 --> Config Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Hooks Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Utf8 Class Initialized
DEBUG - 2011-05-08 23:02:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 23:02:06 --> URI Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Router Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Output Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Input Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 23:02:06 --> Language Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Loader Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Controller Class Initialized
ERROR - 2011-05-08 23:02:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 23:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 23:02:06 --> Model Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Model Class Initialized
DEBUG - 2011-05-08 23:02:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 23:02:06 --> Database Driver Class Initialized
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 23:02:06 --> Helper loaded: url_helper
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 23:02:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 23:02:06 --> Final output sent to browser
DEBUG - 2011-05-08 23:02:06 --> Total execution time: 0.0342
DEBUG - 2011-05-08 23:55:43 --> Config Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Hooks Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Utf8 Class Initialized
DEBUG - 2011-05-08 23:55:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 23:55:43 --> URI Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Router Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Output Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Input Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 23:55:43 --> Language Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Loader Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Controller Class Initialized
ERROR - 2011-05-08 23:55:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-08 23:55:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 23:55:43 --> Model Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Model Class Initialized
DEBUG - 2011-05-08 23:55:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 23:55:43 --> Database Driver Class Initialized
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-08 23:55:43 --> Helper loaded: url_helper
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-08 23:55:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-08 23:55:43 --> Final output sent to browser
DEBUG - 2011-05-08 23:55:43 --> Total execution time: 0.6132
DEBUG - 2011-05-08 23:55:45 --> Config Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Hooks Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Utf8 Class Initialized
DEBUG - 2011-05-08 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 23:55:45 --> URI Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Router Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Output Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Input Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-08 23:55:45 --> Language Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Loader Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Controller Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Model Class Initialized
DEBUG - 2011-05-08 23:55:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-08 23:55:45 --> Database Driver Class Initialized
DEBUG - 2011-05-08 23:55:46 --> Final output sent to browser
DEBUG - 2011-05-08 23:55:46 --> Total execution time: 0.9637
DEBUG - 2011-05-08 23:55:46 --> Config Class Initialized
DEBUG - 2011-05-08 23:55:46 --> Hooks Class Initialized
DEBUG - 2011-05-08 23:55:46 --> Utf8 Class Initialized
DEBUG - 2011-05-08 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-08 23:55:46 --> URI Class Initialized
DEBUG - 2011-05-08 23:55:46 --> Router Class Initialized
ERROR - 2011-05-08 23:55:46 --> 404 Page Not Found --> favicon.ico

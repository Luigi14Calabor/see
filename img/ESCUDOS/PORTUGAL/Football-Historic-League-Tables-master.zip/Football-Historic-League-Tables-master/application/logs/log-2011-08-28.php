<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-28 00:00:07 --> Config Class Initialized
DEBUG - 2011-08-28 00:00:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:00:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:00:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:00:07 --> URI Class Initialized
DEBUG - 2011-08-28 00:00:07 --> Router Class Initialized
ERROR - 2011-08-28 00:00:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 00:24:10 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:10 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Router Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Output Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Input Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 00:24:10 --> Language Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Loader Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Controller Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 00:24:10 --> Database Driver Class Initialized
DEBUG - 2011-08-28 00:24:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 00:24:10 --> Helper loaded: url_helper
DEBUG - 2011-08-28 00:24:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 00:24:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 00:24:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 00:24:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 00:24:10 --> Final output sent to browser
DEBUG - 2011-08-28 00:24:10 --> Total execution time: 0.2610
DEBUG - 2011-08-28 00:24:13 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:13 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:13 --> Router Class Initialized
ERROR - 2011-08-28 00:24:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 00:24:27 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:27 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Router Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Output Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Input Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 00:24:27 --> Language Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Loader Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Controller Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 00:24:27 --> Database Driver Class Initialized
DEBUG - 2011-08-28 00:24:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 00:24:27 --> Helper loaded: url_helper
DEBUG - 2011-08-28 00:24:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 00:24:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 00:24:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 00:24:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 00:24:27 --> Final output sent to browser
DEBUG - 2011-08-28 00:24:27 --> Total execution time: 0.2369
DEBUG - 2011-08-28 00:24:29 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:29 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Router Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Output Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Input Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 00:24:29 --> Language Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Loader Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Controller Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 00:24:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 00:24:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 00:24:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 00:24:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 00:24:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 00:24:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 00:24:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 00:24:29 --> Final output sent to browser
DEBUG - 2011-08-28 00:24:29 --> Total execution time: 0.0454
DEBUG - 2011-08-28 00:24:44 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:44 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Router Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Output Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Input Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 00:24:44 --> Language Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Loader Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Controller Class Initialized
ERROR - 2011-08-28 00:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 00:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 00:24:44 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 00:24:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 00:24:44 --> Helper loaded: url_helper
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 00:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 00:24:44 --> Final output sent to browser
DEBUG - 2011-08-28 00:24:44 --> Total execution time: 0.0693
DEBUG - 2011-08-28 00:24:45 --> Config Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:24:45 --> URI Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Router Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Output Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Input Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 00:24:45 --> Language Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Loader Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Controller Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Model Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 00:24:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 00:24:45 --> Final output sent to browser
DEBUG - 2011-08-28 00:24:45 --> Total execution time: 0.5713
DEBUG - 2011-08-28 00:25:38 --> Config Class Initialized
DEBUG - 2011-08-28 00:25:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 00:25:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 00:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 00:25:38 --> URI Class Initialized
DEBUG - 2011-08-28 00:25:38 --> Router Class Initialized
ERROR - 2011-08-28 00:25:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 04:12:58 --> Config Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:12:58 --> URI Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Router Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Output Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Input Class Initialized
DEBUG - 2011-08-28 04:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 04:12:58 --> Language Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Loader Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Controller Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Model Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Model Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Model Class Initialized
DEBUG - 2011-08-28 04:12:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 04:12:59 --> Database Driver Class Initialized
DEBUG - 2011-08-28 04:13:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 04:13:00 --> Helper loaded: url_helper
DEBUG - 2011-08-28 04:13:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 04:13:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 04:13:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 04:13:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 04:13:00 --> Final output sent to browser
DEBUG - 2011-08-28 04:13:00 --> Total execution time: 1.6149
DEBUG - 2011-08-28 04:13:01 --> Config Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:13:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:13:01 --> URI Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Router Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Output Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Input Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 04:13:01 --> Language Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Loader Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Controller Class Initialized
ERROR - 2011-08-28 04:13:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 04:13:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 04:13:01 --> Model Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Model Class Initialized
DEBUG - 2011-08-28 04:13:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 04:13:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 04:13:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 04:13:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 04:13:01 --> Final output sent to browser
DEBUG - 2011-08-28 04:13:01 --> Total execution time: 0.0997
DEBUG - 2011-08-28 04:23:36 --> Config Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:23:36 --> URI Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Router Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Output Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Input Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 04:23:36 --> Language Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Loader Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Controller Class Initialized
ERROR - 2011-08-28 04:23:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 04:23:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 04:23:36 --> Model Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Model Class Initialized
DEBUG - 2011-08-28 04:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 04:23:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 04:23:36 --> Helper loaded: url_helper
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 04:23:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 04:23:36 --> Final output sent to browser
DEBUG - 2011-08-28 04:23:36 --> Total execution time: 0.0287
DEBUG - 2011-08-28 04:23:37 --> Config Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:23:37 --> URI Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Router Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Output Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Input Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 04:23:37 --> Language Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Loader Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Controller Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Model Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Model Class Initialized
DEBUG - 2011-08-28 04:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 04:23:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 04:23:38 --> Final output sent to browser
DEBUG - 2011-08-28 04:23:38 --> Total execution time: 0.6785
DEBUG - 2011-08-28 04:23:40 --> Config Class Initialized
DEBUG - 2011-08-28 04:23:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:23:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:23:40 --> URI Class Initialized
DEBUG - 2011-08-28 04:23:40 --> Router Class Initialized
ERROR - 2011-08-28 04:23:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 04:35:32 --> Config Class Initialized
DEBUG - 2011-08-28 04:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:35:32 --> URI Class Initialized
DEBUG - 2011-08-28 04:35:32 --> Router Class Initialized
ERROR - 2011-08-28 04:35:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 04:54:33 --> Config Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 04:54:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 04:54:33 --> URI Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Router Class Initialized
DEBUG - 2011-08-28 04:54:33 --> No URI present. Default controller set.
DEBUG - 2011-08-28 04:54:33 --> Output Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Input Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 04:54:33 --> Language Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Loader Class Initialized
DEBUG - 2011-08-28 04:54:33 --> Controller Class Initialized
DEBUG - 2011-08-28 04:54:33 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 04:54:33 --> Helper loaded: url_helper
DEBUG - 2011-08-28 04:54:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 04:54:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 04:54:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 04:54:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 04:54:33 --> Final output sent to browser
DEBUG - 2011-08-28 04:54:33 --> Total execution time: 0.1645
DEBUG - 2011-08-28 05:06:23 --> Config Class Initialized
DEBUG - 2011-08-28 05:06:23 --> Hooks Class Initialized
DEBUG - 2011-08-28 05:06:23 --> Utf8 Class Initialized
DEBUG - 2011-08-28 05:06:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 05:06:23 --> URI Class Initialized
DEBUG - 2011-08-28 05:06:23 --> Router Class Initialized
ERROR - 2011-08-28 05:06:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 05:38:41 --> Config Class Initialized
DEBUG - 2011-08-28 05:38:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 05:38:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 05:38:41 --> URI Class Initialized
DEBUG - 2011-08-28 05:38:41 --> Router Class Initialized
ERROR - 2011-08-28 05:38:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 05:38:42 --> Config Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 05:38:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 05:38:42 --> URI Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Router Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Output Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Input Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 05:38:42 --> Language Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Loader Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Controller Class Initialized
ERROR - 2011-08-28 05:38:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 05:38:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 05:38:42 --> Model Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Model Class Initialized
DEBUG - 2011-08-28 05:38:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 05:38:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 05:38:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 05:38:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 05:38:42 --> Final output sent to browser
DEBUG - 2011-08-28 05:38:42 --> Total execution time: 0.2395
DEBUG - 2011-08-28 05:51:43 --> Config Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 05:51:43 --> URI Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Router Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Output Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Input Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 05:51:43 --> Language Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Loader Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Controller Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Model Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Model Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Model Class Initialized
DEBUG - 2011-08-28 05:51:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 05:51:43 --> Database Driver Class Initialized
DEBUG - 2011-08-28 05:51:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 05:51:44 --> Helper loaded: url_helper
DEBUG - 2011-08-28 05:51:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 05:51:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 05:51:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 05:51:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 05:51:44 --> Final output sent to browser
DEBUG - 2011-08-28 05:51:44 --> Total execution time: 0.5073
DEBUG - 2011-08-28 06:01:44 --> Config Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:01:44 --> URI Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Router Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Output Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Input Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:01:44 --> Language Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Loader Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Controller Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:01:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:01:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:01:44 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:01:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:01:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:01:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:01:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:01:44 --> Final output sent to browser
DEBUG - 2011-08-28 06:01:44 --> Total execution time: 0.3241
DEBUG - 2011-08-28 06:02:18 --> Config Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:02:18 --> URI Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Router Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Output Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Input Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:02:18 --> Language Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Loader Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Controller Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:02:18 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:02:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:02:19 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:02:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:02:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:02:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:02:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:02:19 --> Final output sent to browser
DEBUG - 2011-08-28 06:02:19 --> Total execution time: 0.4882
DEBUG - 2011-08-28 06:02:21 --> Config Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:02:21 --> URI Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Router Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Output Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Input Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:02:21 --> Language Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Loader Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Controller Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:02:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:02:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:02:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:02:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:02:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:02:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:02:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:02:21 --> Final output sent to browser
DEBUG - 2011-08-28 06:02:21 --> Total execution time: 0.0471
DEBUG - 2011-08-28 06:02:26 --> Config Class Initialized
DEBUG - 2011-08-28 06:02:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:02:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:02:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:02:26 --> URI Class Initialized
DEBUG - 2011-08-28 06:02:26 --> Router Class Initialized
ERROR - 2011-08-28 06:02:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 06:02:44 --> Config Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:02:44 --> URI Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Router Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Output Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Input Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:02:44 --> Language Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Loader Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Controller Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:02:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:02:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:02:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:02:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:02:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:02:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:02:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:02:45 --> Final output sent to browser
DEBUG - 2011-08-28 06:02:45 --> Total execution time: 0.2693
DEBUG - 2011-08-28 06:02:47 --> Config Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:02:47 --> URI Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Router Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Output Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Input Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:02:47 --> Language Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Loader Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Controller Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Model Class Initialized
DEBUG - 2011-08-28 06:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:02:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:02:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:02:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:02:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:02:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:02:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:02:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:02:48 --> Final output sent to browser
DEBUG - 2011-08-28 06:02:48 --> Total execution time: 0.0427
DEBUG - 2011-08-28 06:03:00 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:00 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:00 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:00 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:00 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:00 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:00 --> Total execution time: 0.3173
DEBUG - 2011-08-28 06:03:04 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:04 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:04 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:04 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:04 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:04 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:04 --> Total execution time: 0.0512
DEBUG - 2011-08-28 06:03:17 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:17 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:17 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:17 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:18 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:18 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:18 --> Total execution time: 0.2608
DEBUG - 2011-08-28 06:03:21 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:21 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:21 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:21 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:21 --> Total execution time: 0.0457
DEBUG - 2011-08-28 06:03:48 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:48 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:48 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:48 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:48 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:48 --> Total execution time: 0.2709
DEBUG - 2011-08-28 06:03:51 --> Config Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:03:51 --> URI Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Router Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Output Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Input Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:03:51 --> Language Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Loader Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Controller Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Model Class Initialized
DEBUG - 2011-08-28 06:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:03:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:03:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:03:51 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:03:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:03:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:03:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:03:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:03:51 --> Final output sent to browser
DEBUG - 2011-08-28 06:03:51 --> Total execution time: 0.0442
DEBUG - 2011-08-28 06:04:07 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:07 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:07 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:07 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:07 --> Total execution time: 0.2680
DEBUG - 2011-08-28 06:04:10 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:10 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:10 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:10 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:10 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:10 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:10 --> Total execution time: 0.0438
DEBUG - 2011-08-28 06:04:24 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:24 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:24 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:24 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:24 --> Total execution time: 0.2306
DEBUG - 2011-08-28 06:04:27 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:27 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:27 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:27 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:27 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:27 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:27 --> Total execution time: 0.0448
DEBUG - 2011-08-28 06:04:39 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:39 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:39 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:39 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:39 --> Total execution time: 0.2299
DEBUG - 2011-08-28 06:04:42 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:42 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:42 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:42 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:42 --> Total execution time: 0.0473
DEBUG - 2011-08-28 06:04:59 --> Config Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:04:59 --> URI Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Router Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Output Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Input Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:04:59 --> Language Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Loader Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Controller Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Model Class Initialized
DEBUG - 2011-08-28 06:04:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:04:59 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:04:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:04:59 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:04:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:04:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:04:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:04:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:04:59 --> Final output sent to browser
DEBUG - 2011-08-28 06:04:59 --> Total execution time: 0.2004
DEBUG - 2011-08-28 06:05:02 --> Config Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:05:02 --> URI Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Router Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Output Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Input Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:05:02 --> Language Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Loader Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Controller Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:05:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:05:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:05:02 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:05:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:05:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:05:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:05:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:05:02 --> Final output sent to browser
DEBUG - 2011-08-28 06:05:02 --> Total execution time: 0.3917
DEBUG - 2011-08-28 06:05:12 --> Config Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:05:12 --> URI Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Router Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Output Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Input Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:05:12 --> Language Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Loader Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Controller Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:05:12 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:05:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:05:13 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:05:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:05:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:05:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:05:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:05:13 --> Final output sent to browser
DEBUG - 2011-08-28 06:05:13 --> Total execution time: 1.4814
DEBUG - 2011-08-28 06:05:15 --> Config Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:05:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:05:15 --> URI Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Router Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Output Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Input Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:05:15 --> Language Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Loader Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Controller Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Model Class Initialized
DEBUG - 2011-08-28 06:05:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:05:15 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:05:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:05:15 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:05:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:05:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:05:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:05:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:05:15 --> Final output sent to browser
DEBUG - 2011-08-28 06:05:15 --> Total execution time: 0.0461
DEBUG - 2011-08-28 06:06:21 --> Config Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:06:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:06:21 --> URI Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Router Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Output Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Input Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:06:21 --> Language Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Loader Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Controller Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:06:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:06:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:06:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:06:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:06:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:06:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:06:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:06:21 --> Final output sent to browser
DEBUG - 2011-08-28 06:06:21 --> Total execution time: 0.1988
DEBUG - 2011-08-28 06:06:24 --> Config Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:06:24 --> URI Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Router Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Output Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Input Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 06:06:24 --> Language Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Loader Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Controller Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Model Class Initialized
DEBUG - 2011-08-28 06:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 06:06:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 06:06:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 06:06:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 06:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 06:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 06:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 06:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 06:06:24 --> Final output sent to browser
DEBUG - 2011-08-28 06:06:24 --> Total execution time: 0.0472
DEBUG - 2011-08-28 06:07:02 --> Config Class Initialized
DEBUG - 2011-08-28 06:07:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:07:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:07:02 --> URI Class Initialized
DEBUG - 2011-08-28 06:07:02 --> Router Class Initialized
ERROR - 2011-08-28 06:07:02 --> 404 Page Not Found --> t
DEBUG - 2011-08-28 06:07:03 --> Config Class Initialized
DEBUG - 2011-08-28 06:07:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 06:07:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 06:07:03 --> URI Class Initialized
DEBUG - 2011-08-28 06:07:03 --> Router Class Initialized
ERROR - 2011-08-28 06:07:03 --> 404 Page Not Found --> t
DEBUG - 2011-08-28 07:46:37 --> Config Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 07:46:37 --> URI Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Router Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Output Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Input Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 07:46:37 --> Language Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Loader Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Controller Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 07:46:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 07:46:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 07:46:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 07:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 07:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 07:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 07:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 07:46:38 --> Final output sent to browser
DEBUG - 2011-08-28 07:46:38 --> Total execution time: 0.4685
DEBUG - 2011-08-28 07:46:39 --> Config Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 07:46:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 07:46:39 --> URI Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Router Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Output Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Input Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 07:46:39 --> Language Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Loader Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Controller Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Model Class Initialized
DEBUG - 2011-08-28 07:46:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 07:46:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 07:46:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 07:46:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 07:46:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 07:46:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 07:46:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 07:46:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 07:46:39 --> Final output sent to browser
DEBUG - 2011-08-28 07:46:39 --> Total execution time: 0.0537
DEBUG - 2011-08-28 08:20:02 --> Config Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:20:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:20:02 --> URI Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Router Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Output Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Input Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 08:20:02 --> Language Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Loader Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Controller Class Initialized
ERROR - 2011-08-28 08:20:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 08:20:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 08:20:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 08:20:02 --> Model Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Model Class Initialized
DEBUG - 2011-08-28 08:20:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 08:20:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 08:20:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 08:20:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 08:20:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 08:20:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 08:20:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 08:20:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 08:20:03 --> Final output sent to browser
DEBUG - 2011-08-28 08:20:03 --> Total execution time: 0.2879
DEBUG - 2011-08-28 08:20:03 --> Config Class Initialized
DEBUG - 2011-08-28 08:20:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:20:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:20:03 --> URI Class Initialized
DEBUG - 2011-08-28 08:20:03 --> Router Class Initialized
DEBUG - 2011-08-28 08:20:03 --> Output Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Input Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 08:20:04 --> Language Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Loader Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Controller Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Model Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Model Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 08:20:04 --> Database Driver Class Initialized
DEBUG - 2011-08-28 08:20:04 --> Final output sent to browser
DEBUG - 2011-08-28 08:20:04 --> Total execution time: 1.0209
DEBUG - 2011-08-28 08:20:05 --> Config Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:20:05 --> URI Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Router Class Initialized
ERROR - 2011-08-28 08:20:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 08:20:05 --> Config Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:20:05 --> URI Class Initialized
DEBUG - 2011-08-28 08:20:05 --> Router Class Initialized
ERROR - 2011-08-28 08:20:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 08:20:06 --> Config Class Initialized
DEBUG - 2011-08-28 08:20:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:20:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:20:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:20:06 --> URI Class Initialized
DEBUG - 2011-08-28 08:20:06 --> Router Class Initialized
ERROR - 2011-08-28 08:20:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 08:38:37 --> Config Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:38:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:38:37 --> URI Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Router Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Output Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Input Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 08:38:37 --> Language Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Loader Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Controller Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Model Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Model Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Model Class Initialized
DEBUG - 2011-08-28 08:38:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 08:38:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 08:38:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 08:38:37 --> Helper loaded: url_helper
DEBUG - 2011-08-28 08:38:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 08:38:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 08:38:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 08:38:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 08:38:37 --> Final output sent to browser
DEBUG - 2011-08-28 08:38:37 --> Total execution time: 0.2297
DEBUG - 2011-08-28 08:38:38 --> Config Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:38:38 --> URI Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Router Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Output Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Input Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 08:38:38 --> Language Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Loader Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Controller Class Initialized
ERROR - 2011-08-28 08:38:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 08:38:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 08:38:38 --> Model Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Model Class Initialized
DEBUG - 2011-08-28 08:38:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 08:38:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 08:38:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 08:38:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 08:38:38 --> Final output sent to browser
DEBUG - 2011-08-28 08:38:38 --> Total execution time: 0.0315
DEBUG - 2011-08-28 08:57:03 --> Config Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:57:03 --> URI Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Router Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Output Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Input Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 08:57:03 --> Language Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Loader Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Controller Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Model Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Model Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Model Class Initialized
DEBUG - 2011-08-28 08:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 08:57:03 --> Database Driver Class Initialized
DEBUG - 2011-08-28 08:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 08:57:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 08:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 08:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 08:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 08:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 08:57:03 --> Final output sent to browser
DEBUG - 2011-08-28 08:57:03 --> Total execution time: 0.0645
DEBUG - 2011-08-28 08:57:06 --> Config Class Initialized
DEBUG - 2011-08-28 08:57:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 08:57:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 08:57:06 --> URI Class Initialized
DEBUG - 2011-08-28 08:57:06 --> Router Class Initialized
ERROR - 2011-08-28 08:57:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:11:20 --> Config Class Initialized
DEBUG - 2011-08-28 09:11:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:11:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:11:20 --> URI Class Initialized
DEBUG - 2011-08-28 09:11:20 --> Router Class Initialized
ERROR - 2011-08-28 09:11:20 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 09:14:03 --> Config Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:14:03 --> URI Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Router Class Initialized
DEBUG - 2011-08-28 09:14:03 --> No URI present. Default controller set.
DEBUG - 2011-08-28 09:14:03 --> Output Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Input Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:14:03 --> Language Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Loader Class Initialized
DEBUG - 2011-08-28 09:14:03 --> Controller Class Initialized
DEBUG - 2011-08-28 09:14:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 09:14:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:14:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:14:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:14:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:14:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:14:03 --> Final output sent to browser
DEBUG - 2011-08-28 09:14:03 --> Total execution time: 0.0745
DEBUG - 2011-08-28 09:30:04 --> Config Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:30:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:30:04 --> URI Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Router Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Output Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Input Class Initialized
DEBUG - 2011-08-28 09:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:30:04 --> Language Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Loader Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Controller Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Model Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Model Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Model Class Initialized
DEBUG - 2011-08-28 09:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:30:05 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:30:05 --> Final output sent to browser
DEBUG - 2011-08-28 09:30:05 --> Total execution time: 0.7255
DEBUG - 2011-08-28 09:30:12 --> Config Class Initialized
DEBUG - 2011-08-28 09:30:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:30:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:30:12 --> URI Class Initialized
DEBUG - 2011-08-28 09:30:12 --> Router Class Initialized
ERROR - 2011-08-28 09:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:30:13 --> Config Class Initialized
DEBUG - 2011-08-28 09:30:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:30:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:30:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:30:13 --> URI Class Initialized
DEBUG - 2011-08-28 09:30:13 --> Router Class Initialized
ERROR - 2011-08-28 09:30:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:31:13 --> Config Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:31:13 --> URI Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Router Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Output Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Input Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:31:13 --> Language Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Loader Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Controller Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:31:13 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:31:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:31:13 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:31:13 --> Final output sent to browser
DEBUG - 2011-08-28 09:31:13 --> Total execution time: 0.0521
DEBUG - 2011-08-28 09:36:51 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:51 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Router Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Output Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Input Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:36:51 --> Language Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Loader Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Controller Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Model Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Model Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Model Class Initialized
DEBUG - 2011-08-28 09:36:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:36:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:36:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:36:51 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:36:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:36:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:36:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:36:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:36:51 --> Final output sent to browser
DEBUG - 2011-08-28 09:36:51 --> Total execution time: 0.0492
DEBUG - 2011-08-28 09:36:57 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:57 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Router Class Initialized
ERROR - 2011-08-28 09:36:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:36:57 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:57 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:57 --> Router Class Initialized
ERROR - 2011-08-28 09:36:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:36:58 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:58 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Router Class Initialized
ERROR - 2011-08-28 09:36:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:36:58 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:58 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Router Class Initialized
ERROR - 2011-08-28 09:36:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:36:58 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:58 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:58 --> Router Class Initialized
ERROR - 2011-08-28 09:36:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:36:59 --> Config Class Initialized
DEBUG - 2011-08-28 09:36:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:36:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:36:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:36:59 --> URI Class Initialized
DEBUG - 2011-08-28 09:36:59 --> Router Class Initialized
ERROR - 2011-08-28 09:36:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:37:26 --> Config Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:37:26 --> URI Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Router Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Output Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Input Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:37:26 --> Language Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Loader Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Controller Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:37:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:37:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:37:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:37:26 --> Final output sent to browser
DEBUG - 2011-08-28 09:37:26 --> Total execution time: 0.2745
DEBUG - 2011-08-28 09:37:28 --> Config Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:37:28 --> URI Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Router Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Output Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Input Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:37:28 --> Language Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Loader Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Controller Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Model Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:37:28 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:37:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:37:28 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:37:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:37:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:37:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:37:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:37:28 --> Final output sent to browser
DEBUG - 2011-08-28 09:37:28 --> Total execution time: 0.0453
DEBUG - 2011-08-28 09:37:28 --> Config Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:37:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:37:28 --> URI Class Initialized
DEBUG - 2011-08-28 09:37:28 --> Router Class Initialized
ERROR - 2011-08-28 09:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:38:53 --> Config Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:38:53 --> URI Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Router Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Output Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Input Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:38:53 --> Language Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Loader Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Controller Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:38:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:38:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:38:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:38:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:38:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:38:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:38:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:38:53 --> Final output sent to browser
DEBUG - 2011-08-28 09:38:53 --> Total execution time: 0.2975
DEBUG - 2011-08-28 09:38:55 --> Config Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:38:55 --> URI Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Router Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Output Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Input Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:38:55 --> Language Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Loader Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Controller Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:38:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:38:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:38:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:38:55 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:38:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:38:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:38:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:38:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:38:55 --> Final output sent to browser
DEBUG - 2011-08-28 09:38:55 --> Total execution time: 0.0409
DEBUG - 2011-08-28 09:39:00 --> Config Class Initialized
DEBUG - 2011-08-28 09:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:39:00 --> URI Class Initialized
DEBUG - 2011-08-28 09:39:00 --> Router Class Initialized
ERROR - 2011-08-28 09:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:51:55 --> Config Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:51:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:51:55 --> URI Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Router Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Output Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Input Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:51:55 --> Language Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Loader Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Controller Class Initialized
ERROR - 2011-08-28 09:51:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:51:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:51:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:51:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:51:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:51:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:51:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:51:55 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:51:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:51:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:51:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:51:56 --> Config Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:51:56 --> URI Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Router Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Output Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Input Class Initialized
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:51:56 --> Final output sent to browser
DEBUG - 2011-08-28 09:51:56 --> Total execution time: 0.1833
DEBUG - 2011-08-28 09:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:51:56 --> Language Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Loader Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Controller Class Initialized
ERROR - 2011-08-28 09:51:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:51:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:51:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:51:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:51:56 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:51:56 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:51:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:51:56 --> Final output sent to browser
DEBUG - 2011-08-28 09:51:56 --> Total execution time: 0.1284
DEBUG - 2011-08-28 09:52:02 --> Config Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:52:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:52:02 --> URI Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Router Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Output Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Input Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:52:02 --> Language Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Loader Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Controller Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Model Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Model Class Initialized
DEBUG - 2011-08-28 09:52:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:52:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:52:04 --> Final output sent to browser
DEBUG - 2011-08-28 09:52:04 --> Total execution time: 1.2751
DEBUG - 2011-08-28 09:52:05 --> Config Class Initialized
DEBUG - 2011-08-28 09:52:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:52:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:52:05 --> URI Class Initialized
DEBUG - 2011-08-28 09:52:05 --> Router Class Initialized
ERROR - 2011-08-28 09:52:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:53:29 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:29 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Router Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Output Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Input Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:53:29 --> Language Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Loader Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Controller Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:53:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:53:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:53:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:53:29 --> Final output sent to browser
DEBUG - 2011-08-28 09:53:29 --> Total execution time: 0.0443
DEBUG - 2011-08-28 09:53:32 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:32 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:32 --> Router Class Initialized
ERROR - 2011-08-28 09:53:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:53:56 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:56 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Router Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Output Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Input Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:53:56 --> Language Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Loader Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Controller Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:53:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:53:56 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:53:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:53:56 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:53:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:53:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:53:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:53:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:53:56 --> Final output sent to browser
DEBUG - 2011-08-28 09:53:56 --> Total execution time: 0.0504
DEBUG - 2011-08-28 09:53:58 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:58 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Router Class Initialized
ERROR - 2011-08-28 09:53:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:53:58 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:58 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:58 --> Router Class Initialized
ERROR - 2011-08-28 09:53:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:53:59 --> Config Class Initialized
DEBUG - 2011-08-28 09:53:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:53:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:53:59 --> URI Class Initialized
DEBUG - 2011-08-28 09:53:59 --> Router Class Initialized
ERROR - 2011-08-28 09:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:54:09 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:09 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:09 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:09 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:09 --> Total execution time: 0.5629
DEBUG - 2011-08-28 09:54:19 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:19 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:19 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:19 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:19 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:19 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:19 --> Total execution time: 0.2430
DEBUG - 2011-08-28 09:54:25 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:25 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:25 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:25 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:25 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:25 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:25 --> Total execution time: 0.1920
DEBUG - 2011-08-28 09:54:32 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:32 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:32 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:32 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:32 --> Total execution time: 0.1922
DEBUG - 2011-08-28 09:54:39 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:39 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:39 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:39 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:39 --> Total execution time: 0.2103
DEBUG - 2011-08-28 09:54:46 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:46 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:46 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:46 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:46 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:46 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:46 --> Total execution time: 0.2812
DEBUG - 2011-08-28 09:54:53 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:53 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:53 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:54:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:54:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:54:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:54:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:54:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:54:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:54:53 --> Final output sent to browser
DEBUG - 2011-08-28 09:54:53 --> Total execution time: 0.2178
DEBUG - 2011-08-28 09:54:59 --> Config Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:54:59 --> URI Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Router Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Output Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Input Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:54:59 --> Language Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Loader Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Controller Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Model Class Initialized
DEBUG - 2011-08-28 09:54:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:54:59 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:55:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:55:00 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:55:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:55:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:55:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:55:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:55:00 --> Final output sent to browser
DEBUG - 2011-08-28 09:55:00 --> Total execution time: 0.3222
DEBUG - 2011-08-28 09:55:02 --> Config Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:55:02 --> URI Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Router Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Output Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Input Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:55:02 --> Language Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Loader Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Controller Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:55:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:55:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:55:02 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:55:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:55:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:55:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:55:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:55:02 --> Final output sent to browser
DEBUG - 2011-08-28 09:55:02 --> Total execution time: 0.0476
DEBUG - 2011-08-28 09:55:13 --> Config Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:55:13 --> URI Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Router Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Output Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Input Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:55:13 --> Language Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Loader Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Controller Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:55:13 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:55:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:55:15 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:55:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:55:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:55:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:55:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:55:15 --> Final output sent to browser
DEBUG - 2011-08-28 09:55:15 --> Total execution time: 1.9071
DEBUG - 2011-08-28 09:55:26 --> Config Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:55:26 --> URI Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Router Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Output Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Input Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:55:26 --> Language Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Loader Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Controller Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Model Class Initialized
DEBUG - 2011-08-28 09:55:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:55:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:55:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 09:55:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:55:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:55:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:55:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:55:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:55:26 --> Final output sent to browser
DEBUG - 2011-08-28 09:55:26 --> Total execution time: 0.2198
DEBUG - 2011-08-28 09:57:49 --> Config Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:57:49 --> URI Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Router Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Output Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Input Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:57:49 --> Language Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Loader Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Controller Class Initialized
ERROR - 2011-08-28 09:57:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:57:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:57:49 --> Model Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Model Class Initialized
DEBUG - 2011-08-28 09:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:57:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:57:49 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:57:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:57:49 --> Final output sent to browser
DEBUG - 2011-08-28 09:57:49 --> Total execution time: 0.0360
DEBUG - 2011-08-28 09:57:51 --> Config Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:57:51 --> URI Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Router Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Output Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Input Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:57:51 --> Language Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Loader Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Controller Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Model Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Model Class Initialized
DEBUG - 2011-08-28 09:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:57:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:57:52 --> Final output sent to browser
DEBUG - 2011-08-28 09:57:52 --> Total execution time: 0.6518
DEBUG - 2011-08-28 09:58:00 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:00 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:00 --> Router Class Initialized
ERROR - 2011-08-28 09:58:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:58:02 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:02 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:02 --> Router Class Initialized
ERROR - 2011-08-28 09:58:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 09:58:18 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:18 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Router Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Output Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Input Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:58:18 --> Language Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Loader Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Controller Class Initialized
ERROR - 2011-08-28 09:58:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:58:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:58:18 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:58:18 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:58:18 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:58:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:58:18 --> Final output sent to browser
DEBUG - 2011-08-28 09:58:18 --> Total execution time: 0.0328
DEBUG - 2011-08-28 09:58:18 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:18 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Router Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Output Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Input Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:58:18 --> Language Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Loader Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Controller Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:58:18 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:58:19 --> Final output sent to browser
DEBUG - 2011-08-28 09:58:19 --> Total execution time: 0.5650
DEBUG - 2011-08-28 09:58:47 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:47 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Router Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Output Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Input Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:58:47 --> Language Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Loader Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Controller Class Initialized
ERROR - 2011-08-28 09:58:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:58:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:58:47 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:58:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:58:47 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:58:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:58:47 --> Final output sent to browser
DEBUG - 2011-08-28 09:58:47 --> Total execution time: 0.0278
DEBUG - 2011-08-28 09:58:49 --> Config Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:58:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:58:49 --> URI Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Router Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Output Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Input Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:58:49 --> Language Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Loader Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Controller Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Model Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:58:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:58:49 --> Final output sent to browser
DEBUG - 2011-08-28 09:58:49 --> Total execution time: 0.5131
DEBUG - 2011-08-28 09:59:21 --> Config Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:59:21 --> URI Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Router Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Output Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Input Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:59:21 --> Language Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Loader Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Controller Class Initialized
ERROR - 2011-08-28 09:59:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:59:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:59:21 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:59:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:59:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:59:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:59:21 --> Final output sent to browser
DEBUG - 2011-08-28 09:59:21 --> Total execution time: 0.0270
DEBUG - 2011-08-28 09:59:22 --> Config Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:59:22 --> URI Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Router Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Output Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Input Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:59:22 --> Language Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Loader Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Controller Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:59:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:59:22 --> Final output sent to browser
DEBUG - 2011-08-28 09:59:22 --> Total execution time: 0.5681
DEBUG - 2011-08-28 09:59:55 --> Config Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:59:55 --> URI Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Router Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Output Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Input Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:59:55 --> Language Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Loader Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Controller Class Initialized
ERROR - 2011-08-28 09:59:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 09:59:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:59:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:59:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 09:59:55 --> Helper loaded: url_helper
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 09:59:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 09:59:55 --> Final output sent to browser
DEBUG - 2011-08-28 09:59:55 --> Total execution time: 0.0329
DEBUG - 2011-08-28 09:59:56 --> Config Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 09:59:56 --> URI Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Router Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Output Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Input Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 09:59:56 --> Language Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Loader Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Controller Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Model Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 09:59:56 --> Database Driver Class Initialized
DEBUG - 2011-08-28 09:59:56 --> Final output sent to browser
DEBUG - 2011-08-28 09:59:56 --> Total execution time: 0.5426
DEBUG - 2011-08-28 10:00:22 --> Config Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:00:22 --> URI Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Router Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Output Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Input Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:00:22 --> Language Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Loader Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Controller Class Initialized
ERROR - 2011-08-28 10:00:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:00:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:22 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:00:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:22 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:00:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:00:22 --> Final output sent to browser
DEBUG - 2011-08-28 10:00:22 --> Total execution time: 0.0337
DEBUG - 2011-08-28 10:00:23 --> Config Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:00:23 --> URI Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Router Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Output Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Input Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:00:23 --> Language Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Loader Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Controller Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:00:23 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:00:24 --> Final output sent to browser
DEBUG - 2011-08-28 10:00:24 --> Total execution time: 1.2053
DEBUG - 2011-08-28 10:00:25 --> Config Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:00:25 --> URI Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Router Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Output Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Input Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:00:25 --> Language Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Loader Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Controller Class Initialized
ERROR - 2011-08-28 10:00:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:00:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:25 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:00:25 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:25 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:00:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:00:25 --> Final output sent to browser
DEBUG - 2011-08-28 10:00:25 --> Total execution time: 0.1225
DEBUG - 2011-08-28 10:00:49 --> Config Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:00:49 --> URI Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Router Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Output Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Input Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:00:49 --> Language Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Loader Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Controller Class Initialized
ERROR - 2011-08-28 10:00:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:00:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:49 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:00:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:00:49 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:00:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:00:49 --> Final output sent to browser
DEBUG - 2011-08-28 10:00:49 --> Total execution time: 0.0368
DEBUG - 2011-08-28 10:00:50 --> Config Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:00:50 --> URI Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Router Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Output Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Input Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:00:50 --> Language Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Loader Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Controller Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Model Class Initialized
DEBUG - 2011-08-28 10:00:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:00:50 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:00:51 --> Final output sent to browser
DEBUG - 2011-08-28 10:00:51 --> Total execution time: 0.6488
DEBUG - 2011-08-28 10:01:07 --> Config Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:01:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:01:07 --> URI Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Router Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Output Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Input Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:01:07 --> Language Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Loader Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Controller Class Initialized
ERROR - 2011-08-28 10:01:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:01:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:01:07 --> Model Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Model Class Initialized
DEBUG - 2011-08-28 10:01:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:01:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:01:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:01:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:01:07 --> Final output sent to browser
DEBUG - 2011-08-28 10:01:07 --> Total execution time: 0.0340
DEBUG - 2011-08-28 10:01:08 --> Config Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:01:08 --> URI Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Router Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Output Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Input Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:01:08 --> Language Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Loader Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Controller Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Model Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Model Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:01:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:01:08 --> Final output sent to browser
DEBUG - 2011-08-28 10:01:08 --> Total execution time: 0.5087
DEBUG - 2011-08-28 10:02:44 --> Config Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:02:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:02:44 --> URI Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Router Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Output Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Input Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:02:44 --> Language Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Loader Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Controller Class Initialized
ERROR - 2011-08-28 10:02:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:02:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:02:44 --> Model Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Model Class Initialized
DEBUG - 2011-08-28 10:02:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:02:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:02:44 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:02:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:02:44 --> Final output sent to browser
DEBUG - 2011-08-28 10:02:44 --> Total execution time: 0.0308
DEBUG - 2011-08-28 10:02:45 --> Config Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:02:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:02:45 --> URI Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Router Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Output Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Input Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:02:45 --> Language Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Loader Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Controller Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Model Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Model Class Initialized
DEBUG - 2011-08-28 10:02:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:02:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:02:46 --> Final output sent to browser
DEBUG - 2011-08-28 10:02:46 --> Total execution time: 0.5041
DEBUG - 2011-08-28 10:02:47 --> Config Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:02:47 --> URI Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Router Class Initialized
ERROR - 2011-08-28 10:02:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 10:02:47 --> Config Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:02:47 --> URI Class Initialized
DEBUG - 2011-08-28 10:02:47 --> Router Class Initialized
ERROR - 2011-08-28 10:02:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 10:08:29 --> Config Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:08:29 --> URI Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Router Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Output Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Input Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:08:29 --> Language Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Loader Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Controller Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Model Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Model Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Model Class Initialized
DEBUG - 2011-08-28 10:08:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:08:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:08:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 10:08:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:08:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:08:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:08:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:08:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:08:29 --> Final output sent to browser
DEBUG - 2011-08-28 10:08:29 --> Total execution time: 0.0479
DEBUG - 2011-08-28 10:08:30 --> Config Class Initialized
DEBUG - 2011-08-28 10:08:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:08:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:08:30 --> URI Class Initialized
DEBUG - 2011-08-28 10:08:30 --> Router Class Initialized
ERROR - 2011-08-28 10:08:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 10:08:33 --> Config Class Initialized
DEBUG - 2011-08-28 10:08:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:08:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:08:33 --> URI Class Initialized
DEBUG - 2011-08-28 10:08:33 --> Router Class Initialized
ERROR - 2011-08-28 10:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 10:12:37 --> Config Class Initialized
DEBUG - 2011-08-28 10:12:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:12:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:12:37 --> URI Class Initialized
DEBUG - 2011-08-28 10:12:37 --> Router Class Initialized
ERROR - 2011-08-28 10:12:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 10:17:25 --> Config Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:17:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:17:25 --> URI Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Router Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Output Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Input Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:17:25 --> Language Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Loader Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Controller Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:17:25 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:17:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 10:17:25 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:17:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:17:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:17:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:17:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:17:25 --> Final output sent to browser
DEBUG - 2011-08-28 10:17:25 --> Total execution time: 0.0469
DEBUG - 2011-08-28 10:17:28 --> Config Class Initialized
DEBUG - 2011-08-28 10:17:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:17:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:17:28 --> URI Class Initialized
DEBUG - 2011-08-28 10:17:28 --> Router Class Initialized
ERROR - 2011-08-28 10:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 10:17:34 --> Config Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:17:34 --> URI Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Router Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Output Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Input Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:17:34 --> Language Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Loader Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Controller Class Initialized
ERROR - 2011-08-28 10:17:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:17:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:17:34 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:17:34 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:17:34 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:17:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:17:34 --> Final output sent to browser
DEBUG - 2011-08-28 10:17:34 --> Total execution time: 0.0276
DEBUG - 2011-08-28 10:17:36 --> Config Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:17:36 --> URI Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Router Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Output Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Input Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:17:36 --> Language Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Loader Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Controller Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Model Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:17:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:17:36 --> Final output sent to browser
DEBUG - 2011-08-28 10:17:36 --> Total execution time: 0.4514
DEBUG - 2011-08-28 10:31:37 --> Config Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:31:37 --> URI Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Router Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Output Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Input Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:31:37 --> Language Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Loader Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Controller Class Initialized
ERROR - 2011-08-28 10:31:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 10:31:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:31:37 --> Model Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Model Class Initialized
DEBUG - 2011-08-28 10:31:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:31:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 10:31:37 --> Helper loaded: url_helper
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 10:31:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 10:31:37 --> Final output sent to browser
DEBUG - 2011-08-28 10:31:37 --> Total execution time: 0.0323
DEBUG - 2011-08-28 10:31:38 --> Config Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:31:38 --> URI Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Router Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Output Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Input Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 10:31:38 --> Language Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Loader Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Controller Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Model Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Model Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 10:31:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 10:31:38 --> Final output sent to browser
DEBUG - 2011-08-28 10:31:38 --> Total execution time: 0.5547
DEBUG - 2011-08-28 10:31:41 --> Config Class Initialized
DEBUG - 2011-08-28 10:31:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 10:31:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 10:31:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 10:31:41 --> URI Class Initialized
DEBUG - 2011-08-28 10:31:41 --> Router Class Initialized
ERROR - 2011-08-28 10:31:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:06:56 --> Config Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:06:56 --> URI Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Router Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Output Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Input Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:06:56 --> Language Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Loader Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Controller Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Model Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Model Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Model Class Initialized
DEBUG - 2011-08-28 11:06:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:06:56 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:06:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:06:56 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:06:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:06:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:06:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:06:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:06:56 --> Final output sent to browser
DEBUG - 2011-08-28 11:06:56 --> Total execution time: 0.2249
DEBUG - 2011-08-28 11:06:59 --> Config Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:06:59 --> URI Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Router Class Initialized
ERROR - 2011-08-28 11:06:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:06:59 --> Config Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:06:59 --> URI Class Initialized
DEBUG - 2011-08-28 11:06:59 --> Router Class Initialized
ERROR - 2011-08-28 11:06:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:07:00 --> Config Class Initialized
DEBUG - 2011-08-28 11:07:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:07:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:07:00 --> URI Class Initialized
DEBUG - 2011-08-28 11:07:00 --> Router Class Initialized
ERROR - 2011-08-28 11:07:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:11:32 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:32 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Router Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Output Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Input Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:11:32 --> Language Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Loader Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Controller Class Initialized
ERROR - 2011-08-28 11:11:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:11:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:11:32 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:11:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:11:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:11:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:11:32 --> Final output sent to browser
DEBUG - 2011-08-28 11:11:32 --> Total execution time: 0.0271
DEBUG - 2011-08-28 11:11:33 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:33 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Router Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Output Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Input Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:11:33 --> Language Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Loader Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Controller Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:11:33 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:11:34 --> Final output sent to browser
DEBUG - 2011-08-28 11:11:34 --> Total execution time: 0.7890
DEBUG - 2011-08-28 11:11:36 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:36 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Router Class Initialized
ERROR - 2011-08-28 11:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:11:36 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:36 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:36 --> Router Class Initialized
ERROR - 2011-08-28 11:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:11:42 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:42 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Router Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Output Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Input Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:11:42 --> Language Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Loader Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Controller Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:11:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:11:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:11:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:11:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:11:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:11:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:11:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:11:42 --> Final output sent to browser
DEBUG - 2011-08-28 11:11:42 --> Total execution time: 0.0451
DEBUG - 2011-08-28 11:11:54 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:54 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Router Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Output Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Input Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:11:54 --> Language Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Loader Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Controller Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:11:54 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:11:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:11:54 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:11:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:11:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:11:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:11:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:11:54 --> Final output sent to browser
DEBUG - 2011-08-28 11:11:54 --> Total execution time: 0.1597
DEBUG - 2011-08-28 11:11:57 --> Config Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:11:57 --> URI Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Router Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Output Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Input Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:11:57 --> Language Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Loader Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Controller Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Model Class Initialized
DEBUG - 2011-08-28 11:11:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:11:57 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:11:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:11:57 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:11:57 --> Final output sent to browser
DEBUG - 2011-08-28 11:11:57 --> Total execution time: 0.0383
DEBUG - 2011-08-28 11:12:01 --> Config Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:12:01 --> URI Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Router Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Output Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Input Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:12:01 --> Language Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Loader Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Controller Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:12:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:12:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:12:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:12:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:12:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:12:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:12:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:12:01 --> Final output sent to browser
DEBUG - 2011-08-28 11:12:01 --> Total execution time: 0.2400
DEBUG - 2011-08-28 11:12:03 --> Config Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:12:03 --> URI Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Router Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Output Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Input Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:12:03 --> Language Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Loader Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Controller Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:12:03 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:12:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:12:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:12:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:12:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:12:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:12:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:12:03 --> Final output sent to browser
DEBUG - 2011-08-28 11:12:03 --> Total execution time: 0.0569
DEBUG - 2011-08-28 11:12:07 --> Config Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:12:07 --> URI Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Router Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Output Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Input Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:12:07 --> Language Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Loader Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Controller Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:12:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:12:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:12:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:12:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:12:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:12:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:12:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:12:08 --> Final output sent to browser
DEBUG - 2011-08-28 11:12:08 --> Total execution time: 0.6453
DEBUG - 2011-08-28 11:12:28 --> Config Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:12:28 --> URI Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Router Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Output Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Input Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:12:28 --> Language Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Loader Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Controller Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:12:28 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:12:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:12:28 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:12:28 --> Final output sent to browser
DEBUG - 2011-08-28 11:12:28 --> Total execution time: 0.0633
DEBUG - 2011-08-28 11:12:31 --> Config Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:12:31 --> URI Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Router Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Output Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Input Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:12:31 --> Language Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Loader Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Controller Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:12:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:12:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:12:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:12:31 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:12:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:12:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:12:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:12:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:12:31 --> Final output sent to browser
DEBUG - 2011-08-28 11:12:31 --> Total execution time: 0.0486
DEBUG - 2011-08-28 11:22:39 --> Config Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:22:39 --> URI Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Router Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Output Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Input Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:22:39 --> Language Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Loader Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Controller Class Initialized
ERROR - 2011-08-28 11:22:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:22:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:22:39 --> Model Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Model Class Initialized
DEBUG - 2011-08-28 11:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:22:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:22:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:22:39 --> Final output sent to browser
DEBUG - 2011-08-28 11:22:39 --> Total execution time: 0.0306
DEBUG - 2011-08-28 11:22:40 --> Config Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:22:40 --> URI Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Router Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Output Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Input Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:22:40 --> Language Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Loader Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Controller Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Model Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Model Class Initialized
DEBUG - 2011-08-28 11:22:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:22:40 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:22:41 --> Final output sent to browser
DEBUG - 2011-08-28 11:22:41 --> Total execution time: 0.5899
DEBUG - 2011-08-28 11:22:43 --> Config Class Initialized
DEBUG - 2011-08-28 11:22:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:22:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:22:43 --> URI Class Initialized
DEBUG - 2011-08-28 11:22:43 --> Router Class Initialized
ERROR - 2011-08-28 11:22:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:22:45 --> Config Class Initialized
DEBUG - 2011-08-28 11:22:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:22:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:22:45 --> URI Class Initialized
DEBUG - 2011-08-28 11:22:45 --> Router Class Initialized
ERROR - 2011-08-28 11:22:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:23:06 --> Config Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:23:06 --> URI Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Router Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Output Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Input Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:23:06 --> Language Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Loader Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Controller Class Initialized
ERROR - 2011-08-28 11:23:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:23:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:23:06 --> Model Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Model Class Initialized
DEBUG - 2011-08-28 11:23:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:23:06 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:23:06 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:23:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:23:06 --> Final output sent to browser
DEBUG - 2011-08-28 11:23:06 --> Total execution time: 0.0296
DEBUG - 2011-08-28 11:23:07 --> Config Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:23:07 --> URI Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Router Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Output Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Input Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:23:07 --> Language Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Loader Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Controller Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:23:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:23:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:23:08 --> Final output sent to browser
DEBUG - 2011-08-28 11:23:08 --> Total execution time: 0.6333
DEBUG - 2011-08-28 11:23:09 --> Config Class Initialized
DEBUG - 2011-08-28 11:23:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:23:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:23:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:23:09 --> URI Class Initialized
DEBUG - 2011-08-28 11:23:09 --> Router Class Initialized
ERROR - 2011-08-28 11:23:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:26:03 --> Config Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:26:03 --> URI Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Router Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Output Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Input Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:26:03 --> Language Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Loader Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Controller Class Initialized
ERROR - 2011-08-28 11:26:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:26:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:26:03 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:26:03 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:26:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:26:03 --> Final output sent to browser
DEBUG - 2011-08-28 11:26:03 --> Total execution time: 0.0335
DEBUG - 2011-08-28 11:26:07 --> Config Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:26:07 --> URI Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Router Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Output Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Input Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:26:07 --> Language Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Loader Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Controller Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:26:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:26:07 --> Final output sent to browser
DEBUG - 2011-08-28 11:26:07 --> Total execution time: 0.5901
DEBUG - 2011-08-28 11:26:09 --> Config Class Initialized
DEBUG - 2011-08-28 11:26:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:26:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:26:09 --> URI Class Initialized
DEBUG - 2011-08-28 11:26:09 --> Router Class Initialized
ERROR - 2011-08-28 11:26:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:26:23 --> Config Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:26:23 --> URI Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Router Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Output Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Input Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:26:23 --> Language Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Loader Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Controller Class Initialized
ERROR - 2011-08-28 11:26:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:26:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:26:23 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Model Class Initialized
DEBUG - 2011-08-28 11:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:26:23 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:26:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:26:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:26:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:26:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:26:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:26:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:26:24 --> Final output sent to browser
DEBUG - 2011-08-28 11:26:24 --> Total execution time: 0.0265
DEBUG - 2011-08-28 11:26:24 --> Config Class Initialized
DEBUG - 2011-08-28 11:26:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:26:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:26:24 --> URI Class Initialized
DEBUG - 2011-08-28 11:26:24 --> Router Class Initialized
ERROR - 2011-08-28 11:26:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:34:29 --> Config Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:34:29 --> URI Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Router Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Output Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Input Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:34:29 --> Language Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Loader Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Controller Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Model Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Model Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Model Class Initialized
DEBUG - 2011-08-28 11:34:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:34:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:34:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:34:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:34:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:34:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:34:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:34:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:34:29 --> Final output sent to browser
DEBUG - 2011-08-28 11:34:29 --> Total execution time: 0.0746
DEBUG - 2011-08-28 11:35:05 --> Config Class Initialized
DEBUG - 2011-08-28 11:35:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:35:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:35:05 --> URI Class Initialized
DEBUG - 2011-08-28 11:35:05 --> Router Class Initialized
ERROR - 2011-08-28 11:35:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:38:50 --> Config Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:38:50 --> URI Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Router Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Output Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Input Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:38:50 --> Language Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Loader Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Controller Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Model Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Model Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Model Class Initialized
DEBUG - 2011-08-28 11:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:38:50 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:38:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:38:50 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:38:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:38:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:38:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:38:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:38:50 --> Final output sent to browser
DEBUG - 2011-08-28 11:38:50 --> Total execution time: 0.0433
DEBUG - 2011-08-28 11:38:53 --> Config Class Initialized
DEBUG - 2011-08-28 11:38:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:38:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:38:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:38:53 --> URI Class Initialized
DEBUG - 2011-08-28 11:38:53 --> Router Class Initialized
ERROR - 2011-08-28 11:38:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:39:00 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:00 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:00 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:00 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:01 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:01 --> Total execution time: 0.3807
DEBUG - 2011-08-28 11:39:02 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:02 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:02 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:02 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:02 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:02 --> Total execution time: 0.0925
DEBUG - 2011-08-28 11:39:12 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:12 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:12 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:12 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:12 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:12 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:12 --> Total execution time: 0.2485
DEBUG - 2011-08-28 11:39:14 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:14 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:14 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:14 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:14 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:14 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:14 --> Total execution time: 0.0440
DEBUG - 2011-08-28 11:39:33 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:33 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:33 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:33 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:33 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:33 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:33 --> Total execution time: 0.1843
DEBUG - 2011-08-28 11:39:41 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:41 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:41 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:41 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:41 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:41 --> Total execution time: 0.2194
DEBUG - 2011-08-28 11:39:42 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:42 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:42 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:42 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:42 --> Total execution time: 0.0461
DEBUG - 2011-08-28 11:39:53 --> Config Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:39:53 --> URI Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Router Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Output Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Input Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:39:53 --> Language Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Loader Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Controller Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:39:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:39:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:39:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:39:54 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:39:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:39:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:39:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:39:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:39:54 --> Final output sent to browser
DEBUG - 2011-08-28 11:39:54 --> Total execution time: 0.2871
DEBUG - 2011-08-28 11:40:08 --> Config Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:40:08 --> URI Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Router Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Output Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Input Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:40:08 --> Language Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Loader Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Controller Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:40:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:40:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:40:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:40:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:40:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:40:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:40:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:40:09 --> Final output sent to browser
DEBUG - 2011-08-28 11:40:09 --> Total execution time: 0.2794
DEBUG - 2011-08-28 11:40:21 --> Config Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:40:21 --> URI Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Router Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Output Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Input Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:40:21 --> Language Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Loader Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Controller Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:40:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:40:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:40:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:40:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:40:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:40:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:40:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:40:21 --> Final output sent to browser
DEBUG - 2011-08-28 11:40:21 --> Total execution time: 0.2917
DEBUG - 2011-08-28 11:40:32 --> Config Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:40:32 --> URI Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Router Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Output Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Input Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:40:32 --> Language Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Loader Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Controller Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:40:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:40:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:40:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:40:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:40:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:40:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:40:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:40:32 --> Final output sent to browser
DEBUG - 2011-08-28 11:40:32 --> Total execution time: 0.0496
DEBUG - 2011-08-28 11:40:48 --> Config Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:40:48 --> URI Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Router Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Output Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Input Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:40:48 --> Language Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Loader Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Controller Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Model Class Initialized
DEBUG - 2011-08-28 11:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:40:48 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:40:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:40:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:40:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:40:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:40:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:40:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:40:48 --> Final output sent to browser
DEBUG - 2011-08-28 11:40:48 --> Total execution time: 0.0536
DEBUG - 2011-08-28 11:41:16 --> Config Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:41:16 --> URI Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Router Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Output Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Input Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:41:16 --> Language Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Loader Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Controller Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Model Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Model Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Model Class Initialized
DEBUG - 2011-08-28 11:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:41:16 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:41:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:41:16 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:41:16 --> Final output sent to browser
DEBUG - 2011-08-28 11:41:16 --> Total execution time: 0.0670
DEBUG - 2011-08-28 11:42:07 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:07 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:07 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:07 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:07 --> Total execution time: 0.0455
DEBUG - 2011-08-28 11:42:11 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:11 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:11 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:11 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:11 --> Total execution time: 0.0599
DEBUG - 2011-08-28 11:42:26 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:26 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:26 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:26 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:26 --> Total execution time: 0.0456
DEBUG - 2011-08-28 11:42:31 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:31 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:31 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:31 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:31 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:31 --> Total execution time: 0.0450
DEBUG - 2011-08-28 11:42:38 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:38 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:38 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:38 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:38 --> Total execution time: 0.0430
DEBUG - 2011-08-28 11:42:45 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:45 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:45 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:45 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:45 --> Total execution time: 0.0446
DEBUG - 2011-08-28 11:42:53 --> Config Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:42:53 --> URI Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Router Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Output Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Input Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:42:53 --> Language Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Loader Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Controller Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 11:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:42:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 11:42:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:42:53 --> Final output sent to browser
DEBUG - 2011-08-28 11:42:53 --> Total execution time: 0.0460
DEBUG - 2011-08-28 11:43:48 --> Config Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:43:48 --> URI Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Router Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Output Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Input Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:43:48 --> Language Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Loader Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Controller Class Initialized
ERROR - 2011-08-28 11:43:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:43:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:43:48 --> Model Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Model Class Initialized
DEBUG - 2011-08-28 11:43:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:43:48 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:43:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:43:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:43:48 --> Final output sent to browser
DEBUG - 2011-08-28 11:43:48 --> Total execution time: 0.0284
DEBUG - 2011-08-28 11:43:49 --> Config Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:43:49 --> URI Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Router Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Output Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Input Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:43:49 --> Language Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Loader Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Controller Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Model Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Model Class Initialized
DEBUG - 2011-08-28 11:43:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:43:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:43:50 --> Final output sent to browser
DEBUG - 2011-08-28 11:43:50 --> Total execution time: 0.4556
DEBUG - 2011-08-28 11:43:51 --> Config Class Initialized
DEBUG - 2011-08-28 11:43:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:43:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:43:51 --> URI Class Initialized
DEBUG - 2011-08-28 11:43:51 --> Router Class Initialized
ERROR - 2011-08-28 11:43:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 11:47:51 --> Config Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:47:51 --> URI Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Router Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Output Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Input Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:47:51 --> Language Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Loader Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Controller Class Initialized
ERROR - 2011-08-28 11:47:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 11:47:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:47:51 --> Model Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Model Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:47:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 11:47:51 --> Helper loaded: url_helper
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 11:47:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 11:47:51 --> Final output sent to browser
DEBUG - 2011-08-28 11:47:51 --> Total execution time: 0.0290
DEBUG - 2011-08-28 11:47:51 --> Config Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:47:51 --> URI Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Router Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Output Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Input Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 11:47:51 --> Language Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Loader Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Controller Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Model Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Model Class Initialized
DEBUG - 2011-08-28 11:47:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 11:47:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 11:47:52 --> Final output sent to browser
DEBUG - 2011-08-28 11:47:52 --> Total execution time: 0.6110
DEBUG - 2011-08-28 11:47:53 --> Config Class Initialized
DEBUG - 2011-08-28 11:47:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 11:47:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 11:47:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 11:47:53 --> URI Class Initialized
DEBUG - 2011-08-28 11:47:53 --> Router Class Initialized
ERROR - 2011-08-28 11:47:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:00:33 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:33 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Router Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Output Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Input Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:00:33 --> Language Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Loader Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Controller Class Initialized
ERROR - 2011-08-28 12:00:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 12:00:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:00:33 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:00:33 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:00:33 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:00:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:00:33 --> Final output sent to browser
DEBUG - 2011-08-28 12:00:33 --> Total execution time: 0.1828
DEBUG - 2011-08-28 12:00:35 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:35 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Router Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Output Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Input Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:00:35 --> Language Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Loader Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Controller Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:00:35 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:00:36 --> Final output sent to browser
DEBUG - 2011-08-28 12:00:36 --> Total execution time: 0.9057
DEBUG - 2011-08-28 12:00:37 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:37 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:37 --> Router Class Initialized
ERROR - 2011-08-28 12:00:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:00:53 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:53 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Router Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Output Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Input Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:00:53 --> Language Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Loader Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Controller Class Initialized
ERROR - 2011-08-28 12:00:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 12:00:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:00:53 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:00:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:00:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:00:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:00:53 --> Final output sent to browser
DEBUG - 2011-08-28 12:00:53 --> Total execution time: 0.0414
DEBUG - 2011-08-28 12:00:54 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:54 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Router Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Output Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Input Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:00:54 --> Language Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Loader Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Controller Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Model Class Initialized
DEBUG - 2011-08-28 12:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:00:54 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:00:55 --> Final output sent to browser
DEBUG - 2011-08-28 12:00:55 --> Total execution time: 0.5452
DEBUG - 2011-08-28 12:00:56 --> Config Class Initialized
DEBUG - 2011-08-28 12:00:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:00:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:00:56 --> URI Class Initialized
DEBUG - 2011-08-28 12:00:56 --> Router Class Initialized
ERROR - 2011-08-28 12:00:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:02:42 --> Config Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:02:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:02:42 --> URI Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Router Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Output Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Input Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:02:42 --> Language Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Loader Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Controller Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Model Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Model Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Model Class Initialized
DEBUG - 2011-08-28 12:02:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:02:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:02:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:02:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:02:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:02:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:02:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:02:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:02:42 --> Final output sent to browser
DEBUG - 2011-08-28 12:02:42 --> Total execution time: 0.0503
DEBUG - 2011-08-28 12:02:46 --> Config Class Initialized
DEBUG - 2011-08-28 12:02:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:02:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:02:46 --> URI Class Initialized
DEBUG - 2011-08-28 12:02:46 --> Router Class Initialized
ERROR - 2011-08-28 12:02:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:04:11 --> Config Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:04:11 --> URI Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Router Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Output Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Input Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:04:11 --> Language Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Loader Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Controller Class Initialized
ERROR - 2011-08-28 12:04:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 12:04:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:04:11 --> Model Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Model Class Initialized
DEBUG - 2011-08-28 12:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:04:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:04:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:04:11 --> Final output sent to browser
DEBUG - 2011-08-28 12:04:11 --> Total execution time: 0.0291
DEBUG - 2011-08-28 12:04:12 --> Config Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:04:12 --> URI Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Router Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Output Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Input Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:04:12 --> Language Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Loader Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Controller Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Model Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Model Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:04:12 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:04:12 --> Final output sent to browser
DEBUG - 2011-08-28 12:04:12 --> Total execution time: 0.4434
DEBUG - 2011-08-28 12:04:13 --> Config Class Initialized
DEBUG - 2011-08-28 12:04:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:04:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:04:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:04:13 --> URI Class Initialized
DEBUG - 2011-08-28 12:04:13 --> Router Class Initialized
ERROR - 2011-08-28 12:04:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:06:46 --> Config Class Initialized
DEBUG - 2011-08-28 12:06:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:06:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:06:46 --> URI Class Initialized
DEBUG - 2011-08-28 12:06:46 --> Router Class Initialized
DEBUG - 2011-08-28 12:06:46 --> No URI present. Default controller set.
DEBUG - 2011-08-28 12:06:46 --> Output Class Initialized
DEBUG - 2011-08-28 12:06:47 --> Input Class Initialized
DEBUG - 2011-08-28 12:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:06:47 --> Language Class Initialized
DEBUG - 2011-08-28 12:06:47 --> Loader Class Initialized
DEBUG - 2011-08-28 12:06:47 --> Controller Class Initialized
DEBUG - 2011-08-28 12:06:47 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 12:06:47 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:06:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:06:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:06:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:06:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:06:47 --> Final output sent to browser
DEBUG - 2011-08-28 12:06:47 --> Total execution time: 0.0609
DEBUG - 2011-08-28 12:16:07 --> Config Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:16:07 --> URI Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Router Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Output Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Input Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:16:07 --> Language Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Loader Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Controller Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:16:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:16:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:16:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:16:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:16:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:16:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:16:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:16:07 --> Final output sent to browser
DEBUG - 2011-08-28 12:16:07 --> Total execution time: 0.0485
DEBUG - 2011-08-28 12:16:11 --> Config Class Initialized
DEBUG - 2011-08-28 12:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:16:11 --> URI Class Initialized
DEBUG - 2011-08-28 12:16:11 --> Router Class Initialized
ERROR - 2011-08-28 12:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:16:13 --> Config Class Initialized
DEBUG - 2011-08-28 12:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:16:13 --> URI Class Initialized
DEBUG - 2011-08-28 12:16:13 --> Router Class Initialized
ERROR - 2011-08-28 12:16:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:16:41 --> Config Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:16:41 --> URI Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Router Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Output Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Input Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:16:41 --> Language Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Loader Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Controller Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:16:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:16:41 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:16:41 --> Final output sent to browser
DEBUG - 2011-08-28 12:16:41 --> Total execution time: 0.1992
DEBUG - 2011-08-28 12:16:43 --> Config Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:16:43 --> URI Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Router Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Output Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Input Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:16:43 --> Language Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Loader Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Controller Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Model Class Initialized
DEBUG - 2011-08-28 12:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:16:43 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:16:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:16:43 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:16:43 --> Final output sent to browser
DEBUG - 2011-08-28 12:16:43 --> Total execution time: 0.0486
DEBUG - 2011-08-28 12:20:45 --> Config Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:20:45 --> URI Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Router Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Output Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Input Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:20:45 --> Language Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Loader Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Controller Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Model Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Model Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Model Class Initialized
DEBUG - 2011-08-28 12:20:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:20:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:20:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:20:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:20:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:20:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:20:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:20:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:20:45 --> Final output sent to browser
DEBUG - 2011-08-28 12:20:45 --> Total execution time: 0.0473
DEBUG - 2011-08-28 12:22:35 --> Config Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:22:35 --> URI Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Router Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Output Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Input Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:22:35 --> Language Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Config Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:22:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:22:35 --> Loader Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Controller Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Model Class Initialized
DEBUG - 2011-08-28 12:22:35 --> URI Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Model Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Model Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Router Class Initialized
DEBUG - 2011-08-28 12:22:35 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-08-28 12:22:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:22:35 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:22:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:22:36 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:22:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:22:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:22:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:22:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:22:36 --> Final output sent to browser
DEBUG - 2011-08-28 12:22:36 --> Total execution time: 0.2666
DEBUG - 2011-08-28 12:22:49 --> Config Class Initialized
DEBUG - 2011-08-28 12:22:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:22:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:22:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:22:49 --> URI Class Initialized
DEBUG - 2011-08-28 12:22:49 --> Router Class Initialized
ERROR - 2011-08-28 12:22:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 12:23:29 --> Config Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:23:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:23:29 --> URI Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Router Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Output Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Input Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:23:29 --> Language Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Loader Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Controller Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Model Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Model Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Model Class Initialized
DEBUG - 2011-08-28 12:23:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:23:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:23:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:23:30 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:23:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:23:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:23:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:23:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:23:30 --> Final output sent to browser
DEBUG - 2011-08-28 12:23:30 --> Total execution time: 0.0475
DEBUG - 2011-08-28 12:23:52 --> Config Class Initialized
DEBUG - 2011-08-28 12:23:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:23:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:23:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:23:52 --> URI Class Initialized
DEBUG - 2011-08-28 12:23:52 --> Router Class Initialized
ERROR - 2011-08-28 12:23:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:24:30 --> Config Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:24:30 --> URI Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Router Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Output Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Input Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:24:30 --> Language Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Loader Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Controller Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Model Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Model Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Model Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:24:30 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Config Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:24:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:24:30 --> URI Class Initialized
DEBUG - 2011-08-28 12:24:30 --> Router Class Initialized
ERROR - 2011-08-28 12:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:24:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:24:31 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:24:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:24:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:24:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:24:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:24:31 --> Final output sent to browser
DEBUG - 2011-08-28 12:24:31 --> Total execution time: 0.5771
DEBUG - 2011-08-28 12:25:17 --> Config Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:25:17 --> URI Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Router Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Output Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Config Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:25:17 --> Input Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:25:17 --> Language Class Initialized
DEBUG - 2011-08-28 12:25:17 --> URI Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Router Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Loader Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Controller Class Initialized
ERROR - 2011-08-28 12:25:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:25:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:25:17 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:25:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:25:17 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:25:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:25:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:25:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:25:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:25:17 --> Final output sent to browser
DEBUG - 2011-08-28 12:25:17 --> Total execution time: 0.6705
DEBUG - 2011-08-28 12:25:19 --> Config Class Initialized
DEBUG - 2011-08-28 12:25:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:25:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:25:19 --> URI Class Initialized
DEBUG - 2011-08-28 12:25:19 --> Router Class Initialized
ERROR - 2011-08-28 12:25:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:25:58 --> Config Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:25:58 --> URI Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Router Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Output Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Input Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:25:58 --> Language Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Loader Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Controller Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Model Class Initialized
DEBUG - 2011-08-28 12:25:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:25:58 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:25:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:25:59 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:25:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:25:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:25:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:25:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:25:59 --> Final output sent to browser
DEBUG - 2011-08-28 12:25:59 --> Total execution time: 0.2129
DEBUG - 2011-08-28 12:26:02 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:02 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:02 --> Router Class Initialized
ERROR - 2011-08-28 12:26:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:26:03 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:03 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:03 --> Router Class Initialized
ERROR - 2011-08-28 12:26:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:26:20 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:20 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Router Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Output Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Input Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:26:20 --> Language Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Loader Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Controller Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:26:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:26:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:26:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:26:21 --> Final output sent to browser
DEBUG - 2011-08-28 12:26:21 --> Total execution time: 0.2421
DEBUG - 2011-08-28 12:26:26 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:26 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:26 --> Router Class Initialized
ERROR - 2011-08-28 12:26:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:26:49 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:49 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Router Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Output Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Input Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:26:49 --> Language Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Loader Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Controller Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Model Class Initialized
DEBUG - 2011-08-28 12:26:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:26:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:26:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:26:49 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:26:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:26:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:26:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:26:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:26:49 --> Final output sent to browser
DEBUG - 2011-08-28 12:26:49 --> Total execution time: 0.3909
DEBUG - 2011-08-28 12:26:54 --> Config Class Initialized
DEBUG - 2011-08-28 12:26:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:26:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:26:54 --> URI Class Initialized
DEBUG - 2011-08-28 12:26:54 --> Router Class Initialized
ERROR - 2011-08-28 12:26:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:27:17 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:17 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Router Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Output Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Input Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:27:17 --> Language Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Loader Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Controller Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:27:17 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:27:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:27:17 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:27:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:27:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:27:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:27:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:27:17 --> Final output sent to browser
DEBUG - 2011-08-28 12:27:17 --> Total execution time: 0.2862
DEBUG - 2011-08-28 12:27:19 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:19 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:19 --> Router Class Initialized
ERROR - 2011-08-28 12:27:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:27:33 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:33 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Router Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Output Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Input Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:27:33 --> Language Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Loader Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Controller Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:27:33 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:27:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:27:33 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:27:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:27:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:27:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:27:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:27:33 --> Final output sent to browser
DEBUG - 2011-08-28 12:27:33 --> Total execution time: 0.2307
DEBUG - 2011-08-28 12:27:37 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:37 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:37 --> Router Class Initialized
ERROR - 2011-08-28 12:27:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:27:54 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:54 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Router Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Output Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Input Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:27:54 --> Language Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Loader Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Controller Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Model Class Initialized
DEBUG - 2011-08-28 12:27:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:27:54 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:27:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 12:27:54 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:27:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:27:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:27:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:27:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:27:54 --> Final output sent to browser
DEBUG - 2011-08-28 12:27:54 --> Total execution time: 0.3287
DEBUG - 2011-08-28 12:27:56 --> Config Class Initialized
DEBUG - 2011-08-28 12:27:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:27:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:27:56 --> URI Class Initialized
DEBUG - 2011-08-28 12:27:56 --> Router Class Initialized
ERROR - 2011-08-28 12:27:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:39:26 --> Config Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:39:26 --> URI Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Router Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Output Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Input Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:39:26 --> Language Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Loader Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Controller Class Initialized
ERROR - 2011-08-28 12:39:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 12:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:39:26 --> Model Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Model Class Initialized
DEBUG - 2011-08-28 12:39:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:39:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 12:39:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 12:39:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 12:39:26 --> Final output sent to browser
DEBUG - 2011-08-28 12:39:26 --> Total execution time: 0.0269
DEBUG - 2011-08-28 12:39:27 --> Config Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:39:27 --> URI Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Router Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Output Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Input Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 12:39:27 --> Language Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Loader Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Controller Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Model Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Model Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 12:39:27 --> Database Driver Class Initialized
DEBUG - 2011-08-28 12:39:27 --> Final output sent to browser
DEBUG - 2011-08-28 12:39:27 --> Total execution time: 0.6403
DEBUG - 2011-08-28 12:39:28 --> Config Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:39:28 --> URI Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Router Class Initialized
ERROR - 2011-08-28 12:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:39:28 --> Config Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:39:28 --> URI Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Router Class Initialized
ERROR - 2011-08-28 12:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 12:39:28 --> Config Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 12:39:28 --> URI Class Initialized
DEBUG - 2011-08-28 12:39:28 --> Router Class Initialized
ERROR - 2011-08-28 12:39:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:15:49 --> Config Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:15:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:15:49 --> URI Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Router Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Output Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Input Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:15:49 --> Language Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Loader Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Controller Class Initialized
ERROR - 2011-08-28 13:15:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:15:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:15:49 --> Model Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Model Class Initialized
DEBUG - 2011-08-28 13:15:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:15:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:15:49 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:15:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:15:49 --> Final output sent to browser
DEBUG - 2011-08-28 13:15:49 --> Total execution time: 0.0374
DEBUG - 2011-08-28 13:16:04 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:04 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Router Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Output Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Input Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:16:04 --> Language Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Loader Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Controller Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:16:04 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:16:05 --> Final output sent to browser
DEBUG - 2011-08-28 13:16:05 --> Total execution time: 0.6811
DEBUG - 2011-08-28 13:16:21 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:21 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Router Class Initialized
ERROR - 2011-08-28 13:16:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 13:16:21 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:21 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Router Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Output Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Input Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:16:21 --> Language Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Loader Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Controller Class Initialized
ERROR - 2011-08-28 13:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:16:21 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:16:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:16:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:16:21 --> Final output sent to browser
DEBUG - 2011-08-28 13:16:21 --> Total execution time: 0.0281
DEBUG - 2011-08-28 13:16:35 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:35 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Router Class Initialized
ERROR - 2011-08-28 13:16:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 13:16:35 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:35 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Router Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Output Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Input Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:16:35 --> Language Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Loader Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Controller Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:16:35 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:16:36 --> Final output sent to browser
DEBUG - 2011-08-28 13:16:36 --> Total execution time: 0.4393
DEBUG - 2011-08-28 13:16:39 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:39 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Router Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Output Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Input Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:16:39 --> Language Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Loader Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Controller Class Initialized
ERROR - 2011-08-28 13:16:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:16:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:16:39 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:16:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:16:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:16:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:16:39 --> Final output sent to browser
DEBUG - 2011-08-28 13:16:39 --> Total execution time: 0.0336
DEBUG - 2011-08-28 13:16:47 --> Config Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:16:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:16:47 --> URI Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Router Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Output Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Input Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:16:47 --> Language Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Loader Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Controller Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:16:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:16:47 --> Final output sent to browser
DEBUG - 2011-08-28 13:16:47 --> Total execution time: 0.4480
DEBUG - 2011-08-28 13:17:34 --> Config Class Initialized
DEBUG - 2011-08-28 13:17:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:17:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:17:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:17:34 --> URI Class Initialized
DEBUG - 2011-08-28 13:17:34 --> Router Class Initialized
DEBUG - 2011-08-28 13:17:34 --> Output Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Input Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:17:35 --> Language Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Loader Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Controller Class Initialized
ERROR - 2011-08-28 13:17:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:17:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:17:35 --> Model Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Model Class Initialized
DEBUG - 2011-08-28 13:17:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:17:35 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:17:35 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:17:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:17:35 --> Final output sent to browser
DEBUG - 2011-08-28 13:17:35 --> Total execution time: 0.0294
DEBUG - 2011-08-28 13:17:37 --> Config Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:17:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:17:37 --> URI Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Router Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Output Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Input Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:17:37 --> Language Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Loader Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Controller Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Model Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Model Class Initialized
DEBUG - 2011-08-28 13:17:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:17:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:17:38 --> Final output sent to browser
DEBUG - 2011-08-28 13:17:38 --> Total execution time: 0.5530
DEBUG - 2011-08-28 13:18:09 --> Config Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:18:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:18:09 --> URI Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Router Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Output Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Input Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:18:09 --> Language Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Loader Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Controller Class Initialized
ERROR - 2011-08-28 13:18:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:18:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:18:09 --> Model Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Model Class Initialized
DEBUG - 2011-08-28 13:18:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:18:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:18:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:18:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:18:09 --> Final output sent to browser
DEBUG - 2011-08-28 13:18:09 --> Total execution time: 0.0294
DEBUG - 2011-08-28 13:18:11 --> Config Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:18:11 --> URI Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Router Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Output Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Input Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:18:11 --> Language Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Loader Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Controller Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Model Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Model Class Initialized
DEBUG - 2011-08-28 13:18:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:18:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:18:12 --> Final output sent to browser
DEBUG - 2011-08-28 13:18:12 --> Total execution time: 0.6730
DEBUG - 2011-08-28 13:29:59 --> Config Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:29:59 --> URI Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Router Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Output Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Input Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:29:59 --> Language Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Loader Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Controller Class Initialized
ERROR - 2011-08-28 13:29:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:29:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:29:59 --> Model Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Model Class Initialized
DEBUG - 2011-08-28 13:29:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:29:59 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:29:59 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:29:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:29:59 --> Final output sent to browser
DEBUG - 2011-08-28 13:29:59 --> Total execution time: 0.0265
DEBUG - 2011-08-28 13:30:01 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:01 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:01 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Controller Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:02 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:02 --> Total execution time: 1.1367
DEBUG - 2011-08-28 13:30:22 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:22 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:22 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Controller Class Initialized
ERROR - 2011-08-28 13:30:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:30:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:22 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:22 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:30:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:30:22 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:22 --> Total execution time: 0.0664
DEBUG - 2011-08-28 13:30:24 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:24 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:24 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Controller Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:25 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:25 --> Total execution time: 0.6883
DEBUG - 2011-08-28 13:30:39 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:39 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:39 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Controller Class Initialized
ERROR - 2011-08-28 13:30:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:30:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:39 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:30:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:30:39 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:39 --> Total execution time: 0.0284
DEBUG - 2011-08-28 13:30:41 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:41 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:41 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Controller Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:42 --> Total execution time: 0.5460
DEBUG - 2011-08-28 13:30:42 --> Config Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:30:42 --> URI Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Router Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Output Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Input Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:30:42 --> Language Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Loader Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Controller Class Initialized
ERROR - 2011-08-28 13:30:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:30:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:42 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Model Class Initialized
DEBUG - 2011-08-28 13:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:30:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:30:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:30:42 --> Final output sent to browser
DEBUG - 2011-08-28 13:30:42 --> Total execution time: 0.0273
DEBUG - 2011-08-28 13:31:10 --> Config Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:31:10 --> URI Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Router Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Output Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Input Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:31:10 --> Language Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Loader Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Controller Class Initialized
ERROR - 2011-08-28 13:31:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:31:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:31:10 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:31:10 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:31:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:31:10 --> Final output sent to browser
DEBUG - 2011-08-28 13:31:10 --> Total execution time: 0.0280
DEBUG - 2011-08-28 13:31:12 --> Config Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:31:12 --> URI Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Router Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Output Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Input Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:31:12 --> Language Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Loader Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Controller Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:31:12 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:31:13 --> Final output sent to browser
DEBUG - 2011-08-28 13:31:13 --> Total execution time: 0.5892
DEBUG - 2011-08-28 13:31:26 --> Config Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:31:26 --> URI Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Router Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Output Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Input Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:31:26 --> Language Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Loader Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Controller Class Initialized
ERROR - 2011-08-28 13:31:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 13:31:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:31:26 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:31:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 13:31:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:31:26 --> Final output sent to browser
DEBUG - 2011-08-28 13:31:26 --> Total execution time: 0.0287
DEBUG - 2011-08-28 13:31:27 --> Config Class Initialized
DEBUG - 2011-08-28 13:31:27 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:31:27 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:31:27 --> URI Class Initialized
DEBUG - 2011-08-28 13:31:27 --> Router Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Output Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Input Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:31:28 --> Language Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Loader Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Controller Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-28 13:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:31:28 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:31:29 --> Final output sent to browser
DEBUG - 2011-08-28 13:31:29 --> Total execution time: 1.0461
DEBUG - 2011-08-28 13:43:22 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:22 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Router Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Output Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Input Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:43:22 --> Language Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Loader Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Controller Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:43:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:43:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:43:22 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:43:22 --> Final output sent to browser
DEBUG - 2011-08-28 13:43:22 --> Total execution time: 0.2782
DEBUG - 2011-08-28 13:43:25 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:25 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Router Class Initialized
ERROR - 2011-08-28 13:43:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:43:25 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:25 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:25 --> Router Class Initialized
ERROR - 2011-08-28 13:43:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:43:37 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:37 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Router Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Output Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Input Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:43:37 --> Language Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Loader Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Controller Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:43:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:43:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:43:37 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:43:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:43:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:43:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:43:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:43:37 --> Final output sent to browser
DEBUG - 2011-08-28 13:43:37 --> Total execution time: 0.2417
DEBUG - 2011-08-28 13:43:38 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:38 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:38 --> Router Class Initialized
ERROR - 2011-08-28 13:43:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:43:47 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:47 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Router Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Output Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Input Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:43:47 --> Language Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Loader Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Controller Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:43:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:43:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:43:47 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:43:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:43:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:43:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:43:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:43:47 --> Final output sent to browser
DEBUG - 2011-08-28 13:43:47 --> Total execution time: 0.2668
DEBUG - 2011-08-28 13:43:49 --> Config Class Initialized
DEBUG - 2011-08-28 13:43:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:43:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:43:49 --> URI Class Initialized
DEBUG - 2011-08-28 13:43:49 --> Router Class Initialized
ERROR - 2011-08-28 13:43:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:44:00 --> Config Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:44:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:44:00 --> URI Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Router Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Output Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Input Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:44:00 --> Language Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Loader Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Controller Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:44:00 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:44:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:44:00 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:44:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:44:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:44:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:44:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:44:00 --> Final output sent to browser
DEBUG - 2011-08-28 13:44:00 --> Total execution time: 0.1921
DEBUG - 2011-08-28 13:44:01 --> Config Class Initialized
DEBUG - 2011-08-28 13:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:44:01 --> URI Class Initialized
DEBUG - 2011-08-28 13:44:01 --> Router Class Initialized
ERROR - 2011-08-28 13:44:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:44:15 --> Config Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:44:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:44:15 --> URI Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Router Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Output Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Input Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:44:15 --> Language Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Loader Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Controller Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Model Class Initialized
DEBUG - 2011-08-28 13:44:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:44:15 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:44:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:44:15 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:44:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:44:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:44:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:44:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:44:15 --> Final output sent to browser
DEBUG - 2011-08-28 13:44:15 --> Total execution time: 0.1851
DEBUG - 2011-08-28 13:44:17 --> Config Class Initialized
DEBUG - 2011-08-28 13:44:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:44:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:44:17 --> URI Class Initialized
DEBUG - 2011-08-28 13:44:17 --> Router Class Initialized
ERROR - 2011-08-28 13:44:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:45:34 --> Config Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:45:34 --> URI Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Router Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Output Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Input Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:45:34 --> Language Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Loader Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Controller Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:45:34 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:45:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:45:34 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:45:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:45:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:45:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:45:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:45:34 --> Final output sent to browser
DEBUG - 2011-08-28 13:45:34 --> Total execution time: 0.3013
DEBUG - 2011-08-28 13:45:38 --> Config Class Initialized
DEBUG - 2011-08-28 13:45:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:45:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:45:38 --> URI Class Initialized
DEBUG - 2011-08-28 13:45:38 --> Router Class Initialized
ERROR - 2011-08-28 13:45:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:45:47 --> Config Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:45:47 --> URI Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Router Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Output Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Input Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 13:45:47 --> Language Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Loader Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Controller Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Model Class Initialized
DEBUG - 2011-08-28 13:45:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 13:45:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 13:45:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 13:45:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 13:45:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 13:45:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 13:45:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 13:45:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 13:45:48 --> Final output sent to browser
DEBUG - 2011-08-28 13:45:48 --> Total execution time: 0.2332
DEBUG - 2011-08-28 13:45:49 --> Config Class Initialized
DEBUG - 2011-08-28 13:45:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:45:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:45:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:45:49 --> URI Class Initialized
DEBUG - 2011-08-28 13:45:49 --> Router Class Initialized
ERROR - 2011-08-28 13:45:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 13:46:23 --> Config Class Initialized
DEBUG - 2011-08-28 13:46:23 --> Hooks Class Initialized
DEBUG - 2011-08-28 13:46:23 --> Utf8 Class Initialized
DEBUG - 2011-08-28 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 13:46:23 --> URI Class Initialized
DEBUG - 2011-08-28 13:46:23 --> Router Class Initialized
ERROR - 2011-08-28 13:46:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 14:07:29 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:29 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:29 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Controller Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 14:07:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:07:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:07:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:07:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:07:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:07:29 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:29 --> Total execution time: 0.2648
DEBUG - 2011-08-28 14:07:31 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:31 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Router Class Initialized
ERROR - 2011-08-28 14:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:07:31 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:31 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:31 --> Router Class Initialized
ERROR - 2011-08-28 14:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:07:43 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:43 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:43 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Controller Class Initialized
ERROR - 2011-08-28 14:07:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:07:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:43 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:43 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:43 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:07:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:07:43 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:43 --> Total execution time: 0.0312
DEBUG - 2011-08-28 14:07:44 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:44 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:44 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Controller Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:44 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:44 --> Total execution time: 0.6005
DEBUG - 2011-08-28 14:07:45 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:45 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:45 --> Router Class Initialized
ERROR - 2011-08-28 14:07:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:07:52 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:52 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:52 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Controller Class Initialized
ERROR - 2011-08-28 14:07:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:07:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:52 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:52 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:52 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:07:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:07:52 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:52 --> Total execution time: 0.0281
DEBUG - 2011-08-28 14:07:53 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:53 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:53 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Controller Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:53 --> Total execution time: 0.4616
DEBUG - 2011-08-28 14:07:53 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:53 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:53 --> Router Class Initialized
ERROR - 2011-08-28 14:07:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:07:54 --> Config Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:07:54 --> URI Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Router Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Output Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Input Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:07:54 --> Language Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Loader Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Controller Class Initialized
ERROR - 2011-08-28 14:07:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:07:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:54 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Model Class Initialized
DEBUG - 2011-08-28 14:07:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:07:54 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:07:54 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:07:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:07:54 --> Final output sent to browser
DEBUG - 2011-08-28 14:07:54 --> Total execution time: 0.0287
DEBUG - 2011-08-28 14:08:05 --> Config Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:08:05 --> URI Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Router Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Output Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Input Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:08:05 --> Language Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Loader Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Controller Class Initialized
ERROR - 2011-08-28 14:08:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:08:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:08:05 --> Model Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Model Class Initialized
DEBUG - 2011-08-28 14:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:08:05 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:08:05 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:08:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:08:05 --> Final output sent to browser
DEBUG - 2011-08-28 14:08:05 --> Total execution time: 0.0294
DEBUG - 2011-08-28 14:08:06 --> Config Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:08:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:08:06 --> URI Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Router Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Output Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Input Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:08:06 --> Language Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Loader Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Controller Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Model Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Model Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:08:06 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:08:06 --> Final output sent to browser
DEBUG - 2011-08-28 14:08:06 --> Total execution time: 0.4766
DEBUG - 2011-08-28 14:08:07 --> Config Class Initialized
DEBUG - 2011-08-28 14:08:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:08:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:08:07 --> URI Class Initialized
DEBUG - 2011-08-28 14:08:07 --> Router Class Initialized
ERROR - 2011-08-28 14:08:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:30:05 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:05 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:05 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Controller Class Initialized
ERROR - 2011-08-28 14:30:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:30:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:05 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:05 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:05 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:30:05 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:05 --> Total execution time: 0.1580
DEBUG - 2011-08-28 14:30:09 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:09 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:09 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Controller Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:09 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:09 --> Total execution time: 0.5619
DEBUG - 2011-08-28 14:30:14 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:14 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:14 --> Router Class Initialized
ERROR - 2011-08-28 14:30:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:30:30 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:30 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:30 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Controller Class Initialized
ERROR - 2011-08-28 14:30:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:30:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:30 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:30 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:30 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:30:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:30:30 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:30 --> Total execution time: 0.0297
DEBUG - 2011-08-28 14:30:31 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:31 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:31 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Controller Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:31 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:31 --> Total execution time: 0.6423
DEBUG - 2011-08-28 14:30:35 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:35 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:35 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:35 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:35 --> Router Class Initialized
ERROR - 2011-08-28 14:30:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:30:42 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:42 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:42 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Controller Class Initialized
ERROR - 2011-08-28 14:30:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:30:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:42 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:42 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:30:42 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:30:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:30:42 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:42 --> Total execution time: 0.0305
DEBUG - 2011-08-28 14:30:44 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:44 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Router Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Output Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Input Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:30:44 --> Language Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Loader Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Controller Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Model Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:30:44 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:30:44 --> Final output sent to browser
DEBUG - 2011-08-28 14:30:44 --> Total execution time: 0.5087
DEBUG - 2011-08-28 14:30:47 --> Config Class Initialized
DEBUG - 2011-08-28 14:30:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:30:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:30:47 --> URI Class Initialized
DEBUG - 2011-08-28 14:30:47 --> Router Class Initialized
ERROR - 2011-08-28 14:30:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:47:45 --> Config Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:47:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:47:45 --> URI Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Router Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Output Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Input Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:47:45 --> Language Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Loader Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Controller Class Initialized
ERROR - 2011-08-28 14:47:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:47:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:47:45 --> Model Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Model Class Initialized
DEBUG - 2011-08-28 14:47:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:47:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:47:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:47:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:47:45 --> Final output sent to browser
DEBUG - 2011-08-28 14:47:45 --> Total execution time: 0.0382
DEBUG - 2011-08-28 14:47:46 --> Config Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:47:46 --> URI Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Router Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Output Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Input Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:47:46 --> Language Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Loader Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Controller Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Model Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Model Class Initialized
DEBUG - 2011-08-28 14:47:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:47:46 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:47:47 --> Final output sent to browser
DEBUG - 2011-08-28 14:47:47 --> Total execution time: 0.5518
DEBUG - 2011-08-28 14:47:49 --> Config Class Initialized
DEBUG - 2011-08-28 14:47:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:47:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:47:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:47:49 --> URI Class Initialized
DEBUG - 2011-08-28 14:47:49 --> Router Class Initialized
ERROR - 2011-08-28 14:47:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:48:18 --> Config Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:48:18 --> URI Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Router Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Output Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Input Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:48:18 --> Language Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Loader Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Controller Class Initialized
ERROR - 2011-08-28 14:48:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:48:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:48:18 --> Model Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Model Class Initialized
DEBUG - 2011-08-28 14:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:48:18 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:48:18 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:48:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:48:18 --> Final output sent to browser
DEBUG - 2011-08-28 14:48:18 --> Total execution time: 0.0278
DEBUG - 2011-08-28 14:48:19 --> Config Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:48:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:48:19 --> URI Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Router Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Output Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Input Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:48:19 --> Language Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Loader Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Controller Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Model Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Model Class Initialized
DEBUG - 2011-08-28 14:48:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:48:19 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:48:20 --> Final output sent to browser
DEBUG - 2011-08-28 14:48:20 --> Total execution time: 0.6553
DEBUG - 2011-08-28 14:48:24 --> Config Class Initialized
DEBUG - 2011-08-28 14:48:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:48:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:48:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:48:24 --> URI Class Initialized
DEBUG - 2011-08-28 14:48:24 --> Router Class Initialized
ERROR - 2011-08-28 14:48:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:49:53 --> Config Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:49:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:49:53 --> URI Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Router Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Output Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Input Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:49:53 --> Language Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Loader Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Controller Class Initialized
ERROR - 2011-08-28 14:49:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:49:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:49:53 --> Model Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Model Class Initialized
DEBUG - 2011-08-28 14:49:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:49:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:49:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:49:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:49:53 --> Final output sent to browser
DEBUG - 2011-08-28 14:49:53 --> Total execution time: 0.0285
DEBUG - 2011-08-28 14:56:08 --> Config Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:56:08 --> URI Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Router Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Output Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Input Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:56:08 --> Language Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Loader Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Controller Class Initialized
ERROR - 2011-08-28 14:56:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:56:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:56:08 --> Model Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Model Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:56:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:56:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:56:08 --> Final output sent to browser
DEBUG - 2011-08-28 14:56:08 --> Total execution time: 0.0386
DEBUG - 2011-08-28 14:56:08 --> Config Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:56:08 --> URI Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Router Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Output Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Input Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:56:08 --> Language Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Loader Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Controller Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Model Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Model Class Initialized
DEBUG - 2011-08-28 14:56:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:56:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:56:09 --> Final output sent to browser
DEBUG - 2011-08-28 14:56:09 --> Total execution time: 0.6768
DEBUG - 2011-08-28 14:56:13 --> Config Class Initialized
DEBUG - 2011-08-28 14:56:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:56:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:56:13 --> URI Class Initialized
DEBUG - 2011-08-28 14:56:13 --> Router Class Initialized
ERROR - 2011-08-28 14:56:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:56:14 --> Config Class Initialized
DEBUG - 2011-08-28 14:56:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:56:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:56:14 --> URI Class Initialized
DEBUG - 2011-08-28 14:56:14 --> Router Class Initialized
ERROR - 2011-08-28 14:56:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 14:57:45 --> Config Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:57:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:57:45 --> URI Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Router Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Output Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Input Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:57:45 --> Language Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Loader Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Controller Class Initialized
ERROR - 2011-08-28 14:57:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 14:57:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:57:45 --> Model Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Model Class Initialized
DEBUG - 2011-08-28 14:57:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:57:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 14:57:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 14:57:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 14:57:45 --> Final output sent to browser
DEBUG - 2011-08-28 14:57:45 --> Total execution time: 0.0288
DEBUG - 2011-08-28 14:57:46 --> Config Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 14:57:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 14:57:46 --> URI Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Router Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Output Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Input Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 14:57:46 --> Language Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Loader Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Controller Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Model Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Model Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 14:57:46 --> Database Driver Class Initialized
DEBUG - 2011-08-28 14:57:46 --> Final output sent to browser
DEBUG - 2011-08-28 14:57:46 --> Total execution time: 0.4333
DEBUG - 2011-08-28 15:09:19 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:19 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Router Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Output Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Input Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:09:19 --> Language Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Loader Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Controller Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:09:19 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:09:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:09:19 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:09:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:09:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:09:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:09:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:09:19 --> Final output sent to browser
DEBUG - 2011-08-28 15:09:19 --> Total execution time: 0.2599
DEBUG - 2011-08-28 15:09:23 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:23 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:23 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:23 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:23 --> Router Class Initialized
ERROR - 2011-08-28 15:09:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:09:30 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:30 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Router Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Output Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Input Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:09:30 --> Language Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Loader Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Controller Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:09:30 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:09:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:09:30 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:09:30 --> Final output sent to browser
DEBUG - 2011-08-28 15:09:30 --> Total execution time: 0.2511
DEBUG - 2011-08-28 15:09:33 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:33 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Router Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Output Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Input Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:09:33 --> Language Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Loader Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Controller Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:09:33 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:09:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:09:33 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:09:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:09:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:09:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:09:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:09:33 --> Final output sent to browser
DEBUG - 2011-08-28 15:09:33 --> Total execution time: 0.1022
DEBUG - 2011-08-28 15:09:38 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:38 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Router Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Output Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Input Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:09:38 --> Language Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Loader Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Controller Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:09:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:09:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:09:38 --> Final output sent to browser
DEBUG - 2011-08-28 15:09:38 --> Total execution time: 0.2760
DEBUG - 2011-08-28 15:09:50 --> Config Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:09:50 --> URI Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Router Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Output Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Input Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:09:50 --> Language Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Loader Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Controller Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Model Class Initialized
DEBUG - 2011-08-28 15:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:09:50 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:09:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:09:50 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:09:50 --> Final output sent to browser
DEBUG - 2011-08-28 15:09:50 --> Total execution time: 0.3389
DEBUG - 2011-08-28 15:10:02 --> Config Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:10:02 --> URI Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Router Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Output Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Input Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:10:02 --> Language Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Loader Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Controller Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:10:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:10:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:10:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:10:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:10:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:10:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:10:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:10:03 --> Final output sent to browser
DEBUG - 2011-08-28 15:10:03 --> Total execution time: 1.1125
DEBUG - 2011-08-28 15:10:13 --> Config Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:10:13 --> URI Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Router Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Output Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Input Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:10:13 --> Language Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Loader Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Controller Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:10:13 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:10:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:10:13 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:10:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:10:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:10:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:10:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:10:13 --> Final output sent to browser
DEBUG - 2011-08-28 15:10:13 --> Total execution time: 0.3179
DEBUG - 2011-08-28 15:10:20 --> Config Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:10:20 --> URI Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Router Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Output Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Input Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:10:20 --> Language Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Loader Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Controller Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:10:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:10:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:10:20 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:10:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:10:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:10:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:10:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:10:20 --> Final output sent to browser
DEBUG - 2011-08-28 15:10:20 --> Total execution time: 0.2568
DEBUG - 2011-08-28 15:10:32 --> Config Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:10:32 --> URI Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Router Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Output Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Input Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:10:32 --> Language Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Loader Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Controller Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:10:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:10:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:10:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:10:32 --> Final output sent to browser
DEBUG - 2011-08-28 15:10:32 --> Total execution time: 0.2910
DEBUG - 2011-08-28 15:10:47 --> Config Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:10:47 --> URI Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Router Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Output Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Input Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:10:47 --> Language Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Loader Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Controller Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:10:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:10:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:10:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:10:47 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:10:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:10:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:10:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:10:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:10:47 --> Final output sent to browser
DEBUG - 2011-08-28 15:10:47 --> Total execution time: 0.3973
DEBUG - 2011-08-28 15:11:01 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:01 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:01 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:01 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:01 --> Total execution time: 0.2533
DEBUG - 2011-08-28 15:11:08 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:08 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:08 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:08 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:08 --> Total execution time: 0.4601
DEBUG - 2011-08-28 15:11:21 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:21 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:21 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:21 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:21 --> Total execution time: 0.3499
DEBUG - 2011-08-28 15:11:29 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:29 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:29 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:29 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:29 --> Total execution time: 0.2652
DEBUG - 2011-08-28 15:11:37 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:37 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:37 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:38 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:38 --> Total execution time: 0.2947
DEBUG - 2011-08-28 15:11:47 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:47 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:47 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:47 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:47 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:47 --> Total execution time: 0.3147
DEBUG - 2011-08-28 15:11:56 --> Config Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:11:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:11:56 --> URI Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Router Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Output Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Input Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:11:56 --> Language Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Loader Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Controller Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Model Class Initialized
DEBUG - 2011-08-28 15:11:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:11:56 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:11:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:11:57 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:11:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:11:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:11:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:11:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:11:57 --> Final output sent to browser
DEBUG - 2011-08-28 15:11:57 --> Total execution time: 0.1941
DEBUG - 2011-08-28 15:12:15 --> Config Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:12:15 --> URI Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Router Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Output Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Input Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:12:15 --> Language Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Loader Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Controller Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:12:15 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:12:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:12:16 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:12:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:12:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:12:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:12:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:12:16 --> Final output sent to browser
DEBUG - 2011-08-28 15:12:16 --> Total execution time: 0.5951
DEBUG - 2011-08-28 15:12:36 --> Config Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:12:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:12:36 --> URI Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Router Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Output Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Input Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:12:36 --> Language Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Loader Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Controller Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:12:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:12:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:12:36 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:12:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:12:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:12:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:12:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:12:36 --> Final output sent to browser
DEBUG - 2011-08-28 15:12:36 --> Total execution time: 0.2781
DEBUG - 2011-08-28 15:12:55 --> Config Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:12:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:12:55 --> URI Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Router Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Output Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Input Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:12:55 --> Language Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Loader Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Controller Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Model Class Initialized
DEBUG - 2011-08-28 15:12:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:12:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:12:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:12:55 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:12:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:12:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:12:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:12:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:12:55 --> Final output sent to browser
DEBUG - 2011-08-28 15:12:55 --> Total execution time: 0.3039
DEBUG - 2011-08-28 15:13:11 --> Config Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:13:11 --> URI Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Router Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Output Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Input Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:13:11 --> Language Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Loader Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Controller Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:13:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:13:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:13:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:13:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:13:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:13:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:13:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:13:11 --> Final output sent to browser
DEBUG - 2011-08-28 15:13:11 --> Total execution time: 0.0470
DEBUG - 2011-08-28 15:13:26 --> Config Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:13:26 --> URI Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Router Class Initialized
ERROR - 2011-08-28 15:13:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 15:13:26 --> Config Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:13:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:13:26 --> URI Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Router Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Output Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Input Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:13:26 --> Language Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Loader Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Controller Class Initialized
ERROR - 2011-08-28 15:13:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 15:13:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 15:13:26 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:13:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 15:13:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:13:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:13:26 --> Final output sent to browser
DEBUG - 2011-08-28 15:13:26 --> Total execution time: 0.0286
DEBUG - 2011-08-28 15:13:34 --> Config Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:13:34 --> URI Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Router Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Output Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Input Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:13:34 --> Language Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Loader Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Controller Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Model Class Initialized
DEBUG - 2011-08-28 15:13:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:13:34 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:13:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:13:34 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:13:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:13:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:13:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:13:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:13:34 --> Final output sent to browser
DEBUG - 2011-08-28 15:13:34 --> Total execution time: 0.0733
DEBUG - 2011-08-28 15:20:20 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:20 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Router Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Output Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Input Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:20:20 --> Language Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Loader Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Controller Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:20:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:20:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:20:20 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:20:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:20:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:20:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:20:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:20:20 --> Final output sent to browser
DEBUG - 2011-08-28 15:20:20 --> Total execution time: 0.0586
DEBUG - 2011-08-28 15:20:22 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:22 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Router Class Initialized
ERROR - 2011-08-28 15:20:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:20:22 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:22 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:22 --> Router Class Initialized
ERROR - 2011-08-28 15:20:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:20:39 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:39 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Router Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Output Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Input Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:20:39 --> Language Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Loader Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Controller Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:20:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:20:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:20:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:20:39 --> Final output sent to browser
DEBUG - 2011-08-28 15:20:39 --> Total execution time: 0.1253
DEBUG - 2011-08-28 15:20:40 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:40 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:40 --> Router Class Initialized
ERROR - 2011-08-28 15:20:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:20:52 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:52 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Router Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Output Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Input Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:20:52 --> Language Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Loader Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Controller Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Model Class Initialized
DEBUG - 2011-08-28 15:20:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:20:52 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:20:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:20:52 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:20:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:20:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:20:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:20:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:20:52 --> Final output sent to browser
DEBUG - 2011-08-28 15:20:52 --> Total execution time: 0.0458
DEBUG - 2011-08-28 15:20:53 --> Config Class Initialized
DEBUG - 2011-08-28 15:20:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:20:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:20:53 --> URI Class Initialized
DEBUG - 2011-08-28 15:20:53 --> Router Class Initialized
ERROR - 2011-08-28 15:20:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:21:11 --> Config Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:21:11 --> URI Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Router Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Output Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Input Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:21:11 --> Language Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Loader Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Controller Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:21:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:21:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:21:11 --> Final output sent to browser
DEBUG - 2011-08-28 15:21:11 --> Total execution time: 0.0439
DEBUG - 2011-08-28 15:21:12 --> Config Class Initialized
DEBUG - 2011-08-28 15:21:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:21:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:21:12 --> URI Class Initialized
DEBUG - 2011-08-28 15:21:12 --> Router Class Initialized
ERROR - 2011-08-28 15:21:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 15:21:20 --> Config Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:21:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:21:20 --> URI Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Router Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Output Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Input Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 15:21:20 --> Language Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Loader Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Controller Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Model Class Initialized
DEBUG - 2011-08-28 15:21:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 15:21:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 15:21:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 15:21:20 --> Helper loaded: url_helper
DEBUG - 2011-08-28 15:21:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 15:21:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 15:21:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 15:21:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 15:21:20 --> Final output sent to browser
DEBUG - 2011-08-28 15:21:20 --> Total execution time: 0.0486
DEBUG - 2011-08-28 15:21:21 --> Config Class Initialized
DEBUG - 2011-08-28 15:21:21 --> Hooks Class Initialized
DEBUG - 2011-08-28 15:21:21 --> Utf8 Class Initialized
DEBUG - 2011-08-28 15:21:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 15:21:21 --> URI Class Initialized
DEBUG - 2011-08-28 15:21:21 --> Router Class Initialized
ERROR - 2011-08-28 15:21:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:00:05 --> Config Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:00:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:00:05 --> URI Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Router Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Output Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Input Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:00:05 --> Language Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Loader Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Controller Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Model Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Model Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Model Class Initialized
DEBUG - 2011-08-28 16:00:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:00:05 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:00:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:00:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:00:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:00:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:00:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:00:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:00:07 --> Final output sent to browser
DEBUG - 2011-08-28 16:00:07 --> Total execution time: 2.8311
DEBUG - 2011-08-28 16:00:10 --> Config Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:00:10 --> URI Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Router Class Initialized
ERROR - 2011-08-28 16:00:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:00:10 --> Config Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:00:10 --> URI Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Router Class Initialized
ERROR - 2011-08-28 16:00:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:00:10 --> Config Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:00:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:00:10 --> URI Class Initialized
DEBUG - 2011-08-28 16:00:10 --> Router Class Initialized
ERROR - 2011-08-28 16:00:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:05:53 --> Config Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:05:53 --> URI Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Router Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Output Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Input Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:05:53 --> Language Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Loader Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Controller Class Initialized
ERROR - 2011-08-28 16:05:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 16:05:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:05:53 --> Model Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Model Class Initialized
DEBUG - 2011-08-28 16:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:05:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:05:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:05:53 --> Final output sent to browser
DEBUG - 2011-08-28 16:05:53 --> Total execution time: 0.0408
DEBUG - 2011-08-28 16:05:55 --> Config Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:05:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:05:55 --> URI Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Router Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Output Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Input Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:05:55 --> Language Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Loader Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Controller Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Model Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Model Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:05:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:05:55 --> Final output sent to browser
DEBUG - 2011-08-28 16:05:55 --> Total execution time: 0.7902
DEBUG - 2011-08-28 16:05:58 --> Config Class Initialized
DEBUG - 2011-08-28 16:05:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:05:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:05:58 --> URI Class Initialized
DEBUG - 2011-08-28 16:05:58 --> Router Class Initialized
ERROR - 2011-08-28 16:05:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:05:59 --> Config Class Initialized
DEBUG - 2011-08-28 16:05:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:05:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:05:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:05:59 --> URI Class Initialized
DEBUG - 2011-08-28 16:05:59 --> Router Class Initialized
ERROR - 2011-08-28 16:05:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:06:16 --> Config Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:06:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:06:16 --> URI Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Router Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Output Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Input Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:06:16 --> Language Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Loader Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Controller Class Initialized
ERROR - 2011-08-28 16:06:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 16:06:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:06:16 --> Model Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Model Class Initialized
DEBUG - 2011-08-28 16:06:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:06:16 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:06:16 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:06:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:06:16 --> Final output sent to browser
DEBUG - 2011-08-28 16:06:16 --> Total execution time: 0.0261
DEBUG - 2011-08-28 16:06:17 --> Config Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:06:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:06:17 --> URI Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Router Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Output Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Input Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:06:17 --> Language Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Loader Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Controller Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Model Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Model Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:06:17 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:06:17 --> Final output sent to browser
DEBUG - 2011-08-28 16:06:17 --> Total execution time: 0.6052
DEBUG - 2011-08-28 16:06:20 --> Config Class Initialized
DEBUG - 2011-08-28 16:06:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:06:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:06:20 --> URI Class Initialized
DEBUG - 2011-08-28 16:06:20 --> Router Class Initialized
ERROR - 2011-08-28 16:06:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:21:48 --> Config Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:21:48 --> URI Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Router Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Output Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Input Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:21:48 --> Language Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Loader Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Controller Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Model Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Model Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Model Class Initialized
DEBUG - 2011-08-28 16:21:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:21:48 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:21:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:21:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:21:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:21:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:21:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:21:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:21:48 --> Final output sent to browser
DEBUG - 2011-08-28 16:21:48 --> Total execution time: 0.0459
DEBUG - 2011-08-28 16:21:52 --> Config Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:21:52 --> URI Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Router Class Initialized
ERROR - 2011-08-28 16:21:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:21:52 --> Config Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:21:52 --> URI Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Router Class Initialized
ERROR - 2011-08-28 16:21:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:21:52 --> Config Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:21:52 --> URI Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Router Class Initialized
ERROR - 2011-08-28 16:21:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:21:52 --> Config Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:21:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:21:52 --> URI Class Initialized
DEBUG - 2011-08-28 16:21:52 --> Router Class Initialized
ERROR - 2011-08-28 16:21:52 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-08-28 16:22:11 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:11 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:11 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:12 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:12 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:12 --> Total execution time: 0.2096
DEBUG - 2011-08-28 16:22:14 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:14 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:14 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:14 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:14 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:14 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:14 --> Total execution time: 0.0451
DEBUG - 2011-08-28 16:22:22 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:22 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:22 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:23 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:23 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:23 --> Total execution time: 0.2775
DEBUG - 2011-08-28 16:22:24 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:24 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:24 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:24 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:24 --> Total execution time: 0.0429
DEBUG - 2011-08-28 16:22:30 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:30 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:30 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:30 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:30 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:30 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:30 --> Total execution time: 0.2415
DEBUG - 2011-08-28 16:22:31 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:31 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:31 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:32 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:32 --> Total execution time: 0.0466
DEBUG - 2011-08-28 16:22:36 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:36 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:36 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:37 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:37 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:37 --> Total execution time: 0.2757
DEBUG - 2011-08-28 16:22:39 --> Config Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:22:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:22:39 --> URI Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Router Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Output Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Input Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:22:39 --> Language Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Loader Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Controller Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Model Class Initialized
DEBUG - 2011-08-28 16:22:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:22:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:22:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:22:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:22:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:22:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:22:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:22:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:22:39 --> Final output sent to browser
DEBUG - 2011-08-28 16:22:39 --> Total execution time: 0.0494
DEBUG - 2011-08-28 16:26:56 --> Config Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:26:56 --> URI Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Router Class Initialized
DEBUG - 2011-08-28 16:26:56 --> No URI present. Default controller set.
DEBUG - 2011-08-28 16:26:56 --> Output Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Input Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:26:56 --> Language Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Loader Class Initialized
DEBUG - 2011-08-28 16:26:56 --> Controller Class Initialized
DEBUG - 2011-08-28 16:26:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 16:26:56 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:26:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:26:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:26:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:26:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:26:56 --> Final output sent to browser
DEBUG - 2011-08-28 16:26:56 --> Total execution time: 0.0407
DEBUG - 2011-08-28 16:28:25 --> Config Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:28:25 --> URI Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Router Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Output Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Input Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:28:25 --> Language Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Loader Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Controller Class Initialized
ERROR - 2011-08-28 16:28:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 16:28:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:28:25 --> Model Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Model Class Initialized
DEBUG - 2011-08-28 16:28:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:28:25 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:28:25 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:28:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:28:25 --> Final output sent to browser
DEBUG - 2011-08-28 16:28:25 --> Total execution time: 0.0325
DEBUG - 2011-08-28 16:28:26 --> Config Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:28:26 --> URI Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Router Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Output Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Input Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:28:26 --> Language Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Loader Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Controller Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Model Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Model Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:28:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:28:26 --> Final output sent to browser
DEBUG - 2011-08-28 16:28:26 --> Total execution time: 0.5039
DEBUG - 2011-08-28 16:28:27 --> Config Class Initialized
DEBUG - 2011-08-28 16:28:27 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:28:27 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:28:27 --> URI Class Initialized
DEBUG - 2011-08-28 16:28:27 --> Router Class Initialized
ERROR - 2011-08-28 16:28:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:29:13 --> Config Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:29:13 --> URI Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Router Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Output Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Input Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:29:13 --> Language Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Loader Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Controller Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Model Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Model Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Model Class Initialized
DEBUG - 2011-08-28 16:29:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:29:13 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:29:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:29:13 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:29:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:29:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:29:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:29:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:29:13 --> Final output sent to browser
DEBUG - 2011-08-28 16:29:13 --> Total execution time: 0.0551
DEBUG - 2011-08-28 16:29:15 --> Config Class Initialized
DEBUG - 2011-08-28 16:29:15 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:29:15 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:29:15 --> URI Class Initialized
DEBUG - 2011-08-28 16:29:15 --> Router Class Initialized
ERROR - 2011-08-28 16:29:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 16:31:05 --> Config Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:31:05 --> URI Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Router Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Output Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Input Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:31:05 --> Language Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Loader Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Controller Class Initialized
ERROR - 2011-08-28 16:31:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 16:31:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:31:05 --> Model Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Model Class Initialized
DEBUG - 2011-08-28 16:31:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:31:05 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:31:05 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:31:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:31:05 --> Final output sent to browser
DEBUG - 2011-08-28 16:31:05 --> Total execution time: 0.0264
DEBUG - 2011-08-28 16:33:53 --> Config Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:33:53 --> URI Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Router Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Output Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Input Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:33:53 --> Language Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Loader Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Controller Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Model Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Model Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Model Class Initialized
DEBUG - 2011-08-28 16:33:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:33:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:33:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 16:33:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:33:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:33:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:33:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:33:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:33:53 --> Final output sent to browser
DEBUG - 2011-08-28 16:33:53 --> Total execution time: 0.0470
DEBUG - 2011-08-28 16:45:04 --> Config Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:45:04 --> URI Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Router Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Output Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Input Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:45:04 --> Language Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Loader Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Controller Class Initialized
ERROR - 2011-08-28 16:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 16:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:45:04 --> Model Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Model Class Initialized
DEBUG - 2011-08-28 16:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:45:04 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 16:45:04 --> Helper loaded: url_helper
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 16:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 16:45:04 --> Final output sent to browser
DEBUG - 2011-08-28 16:45:04 --> Total execution time: 0.0921
DEBUG - 2011-08-28 16:45:06 --> Config Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:45:06 --> URI Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Router Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Output Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Input Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 16:45:06 --> Language Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Loader Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Controller Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Model Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Model Class Initialized
DEBUG - 2011-08-28 16:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 16:45:06 --> Database Driver Class Initialized
DEBUG - 2011-08-28 16:45:07 --> Final output sent to browser
DEBUG - 2011-08-28 16:45:07 --> Total execution time: 0.6509
DEBUG - 2011-08-28 16:45:08 --> Config Class Initialized
DEBUG - 2011-08-28 16:45:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 16:45:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 16:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 16:45:08 --> URI Class Initialized
DEBUG - 2011-08-28 16:45:08 --> Router Class Initialized
ERROR - 2011-08-28 16:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 17:41:36 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:36 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Router Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Output Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Input Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:41:36 --> Language Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Loader Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Controller Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:41:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:41:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:41:36 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:41:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:41:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:41:37 --> Final output sent to browser
DEBUG - 2011-08-28 17:41:37 --> Total execution time: 0.4746
DEBUG - 2011-08-28 17:41:38 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:38 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:38 --> Router Class Initialized
ERROR - 2011-08-28 17:41:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 17:41:52 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:52 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Router Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Output Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Input Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:41:52 --> Language Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Loader Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Controller Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:41:52 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:41:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:41:52 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:41:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:41:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:41:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:41:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:41:52 --> Final output sent to browser
DEBUG - 2011-08-28 17:41:52 --> Total execution time: 0.0443
DEBUG - 2011-08-28 17:41:55 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:55 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Router Class Initialized
ERROR - 2011-08-28 17:41:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 17:41:55 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:55 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:55 --> Router Class Initialized
ERROR - 2011-08-28 17:41:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 17:41:58 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:58 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Router Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Output Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Input Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:41:58 --> Language Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Loader Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Controller Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Model Class Initialized
DEBUG - 2011-08-28 17:41:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:41:58 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:41:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:41:58 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:41:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:41:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:41:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:41:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:41:58 --> Final output sent to browser
DEBUG - 2011-08-28 17:41:58 --> Total execution time: 0.2003
DEBUG - 2011-08-28 17:41:59 --> Config Class Initialized
DEBUG - 2011-08-28 17:41:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:41:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:41:59 --> URI Class Initialized
DEBUG - 2011-08-28 17:41:59 --> Router Class Initialized
ERROR - 2011-08-28 17:41:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 17:42:00 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:00 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:00 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:00 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:00 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:00 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:00 --> Total execution time: 0.0889
DEBUG - 2011-08-28 17:42:07 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:07 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:07 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:07 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:07 --> Total execution time: 0.2223
DEBUG - 2011-08-28 17:42:19 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:19 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:19 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:19 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:19 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:19 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:19 --> Total execution time: 0.2117
DEBUG - 2011-08-28 17:42:24 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:24 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:24 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:24 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:24 --> Total execution time: 0.0427
DEBUG - 2011-08-28 17:42:31 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:31 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:31 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:31 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:32 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:32 --> Total execution time: 0.3560
DEBUG - 2011-08-28 17:42:36 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:36 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:36 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:37 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:37 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:37 --> Total execution time: 0.2499
DEBUG - 2011-08-28 17:42:47 --> Config Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:42:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:42:47 --> URI Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Router Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Output Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Input Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:42:47 --> Language Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Loader Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Controller Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Model Class Initialized
DEBUG - 2011-08-28 17:42:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:42:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:42:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 17:42:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:42:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:42:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:42:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:42:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:42:48 --> Final output sent to browser
DEBUG - 2011-08-28 17:42:48 --> Total execution time: 0.2186
DEBUG - 2011-08-28 17:43:11 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:11 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:11 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:11 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:11 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:11 --> Total execution time: 0.0658
DEBUG - 2011-08-28 17:43:11 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:11 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:11 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:12 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:12 --> Total execution time: 0.5379
DEBUG - 2011-08-28 17:43:20 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:20 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:20 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:20 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:20 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:20 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:20 --> Total execution time: 0.0305
DEBUG - 2011-08-28 17:43:20 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:20 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:20 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:21 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:21 --> Total execution time: 0.6371
DEBUG - 2011-08-28 17:43:31 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:31 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:31 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:31 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:31 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:31 --> Total execution time: 0.0355
DEBUG - 2011-08-28 17:43:31 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:31 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:31 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:31 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:32 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:32 --> Total execution time: 0.6362
DEBUG - 2011-08-28 17:43:36 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:36 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:36 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:36 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:36 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:36 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:36 --> Total execution time: 0.0272
DEBUG - 2011-08-28 17:43:37 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:37 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:37 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:37 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:37 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:37 --> Total execution time: 0.6142
DEBUG - 2011-08-28 17:43:41 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:41 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:41 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:41 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:41 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:41 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:41 --> Total execution time: 0.0295
DEBUG - 2011-08-28 17:43:41 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:41 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:41 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:42 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:42 --> Total execution time: 0.5420
DEBUG - 2011-08-28 17:43:46 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:46 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:46 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:46 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:46 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:46 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:46 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:46 --> Total execution time: 0.0692
DEBUG - 2011-08-28 17:43:47 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:47 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:47 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:47 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:47 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:47 --> Total execution time: 0.5739
DEBUG - 2011-08-28 17:43:50 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:50 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:50 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:50 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:50 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:50 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:50 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:50 --> Total execution time: 0.0272
DEBUG - 2011-08-28 17:43:51 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:51 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:51 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:52 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:52 --> Total execution time: 0.6915
DEBUG - 2011-08-28 17:43:54 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:54 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:54 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Controller Class Initialized
ERROR - 2011-08-28 17:43:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:43:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:54 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:54 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:43:54 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:43:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:43:54 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:54 --> Total execution time: 0.0301
DEBUG - 2011-08-28 17:43:55 --> Config Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:43:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:43:55 --> URI Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Router Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Output Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Input Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:43:55 --> Language Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Loader Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Controller Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Model Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:43:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:43:55 --> Final output sent to browser
DEBUG - 2011-08-28 17:43:55 --> Total execution time: 0.4988
DEBUG - 2011-08-28 17:44:01 --> Config Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:44:01 --> URI Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Router Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Output Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Input Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:44:01 --> Language Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Loader Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Controller Class Initialized
ERROR - 2011-08-28 17:44:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 17:44:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:44:01 --> Model Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Model Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:44:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 17:44:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 17:44:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 17:44:01 --> Final output sent to browser
DEBUG - 2011-08-28 17:44:01 --> Total execution time: 0.0465
DEBUG - 2011-08-28 17:44:01 --> Config Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 17:44:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 17:44:01 --> URI Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Router Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Output Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Input Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 17:44:01 --> Language Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Loader Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Controller Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Model Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Model Class Initialized
DEBUG - 2011-08-28 17:44:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 17:44:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 17:44:02 --> Final output sent to browser
DEBUG - 2011-08-28 17:44:02 --> Total execution time: 0.5001
DEBUG - 2011-08-28 18:21:08 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:08 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:08 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Controller Class Initialized
ERROR - 2011-08-28 18:21:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:21:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:08 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:21:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:21:08 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:08 --> Total execution time: 0.0413
DEBUG - 2011-08-28 18:21:09 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:09 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:09 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Controller Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:09 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:09 --> Total execution time: 0.6072
DEBUG - 2011-08-28 18:21:10 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:10 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:10 --> Router Class Initialized
ERROR - 2011-08-28 18:21:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:21:29 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:29 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:29 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Controller Class Initialized
ERROR - 2011-08-28 18:21:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:21:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:29 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:21:29 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:29 --> Total execution time: 0.0304
DEBUG - 2011-08-28 18:21:29 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:29 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:29 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Controller Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:29 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:29 --> Total execution time: 0.6303
DEBUG - 2011-08-28 18:21:34 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:34 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:34 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Controller Class Initialized
ERROR - 2011-08-28 18:21:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:21:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:34 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:34 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:34 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:21:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:21:34 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:34 --> Total execution time: 0.0477
DEBUG - 2011-08-28 18:21:34 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:34 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:34 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Controller Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:34 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:35 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:35 --> Total execution time: 0.4981
DEBUG - 2011-08-28 18:21:39 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:39 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:39 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Controller Class Initialized
ERROR - 2011-08-28 18:21:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:21:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:21:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:21:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:21:39 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:39 --> Total execution time: 0.0492
DEBUG - 2011-08-28 18:21:39 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:39 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Router Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Output Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Input Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:21:39 --> Language Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Loader Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Controller Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:21:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:21:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:21:40 --> Final output sent to browser
DEBUG - 2011-08-28 18:21:40 --> Total execution time: 0.5464
DEBUG - 2011-08-28 18:21:53 --> Config Class Initialized
DEBUG - 2011-08-28 18:21:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:21:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:21:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:21:53 --> URI Class Initialized
DEBUG - 2011-08-28 18:21:53 --> Router Class Initialized
ERROR - 2011-08-28 18:21:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 18:23:07 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:07 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:07 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Controller Class Initialized
ERROR - 2011-08-28 18:23:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:23:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:07 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:07 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:07 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:23:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:23:07 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:07 --> Total execution time: 0.0283
DEBUG - 2011-08-28 18:23:08 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:08 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:08 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Controller Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:08 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:08 --> Total execution time: 0.6824
DEBUG - 2011-08-28 18:23:38 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:38 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:38 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Controller Class Initialized
ERROR - 2011-08-28 18:23:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:23:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:38 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:38 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:23:38 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:38 --> Total execution time: 0.0268
DEBUG - 2011-08-28 18:23:38 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:38 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:38 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Controller Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:38 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:39 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:39 --> Total execution time: 0.4959
DEBUG - 2011-08-28 18:23:45 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:45 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:45 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Controller Class Initialized
ERROR - 2011-08-28 18:23:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:23:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:45 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:45 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:23:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:23:45 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:45 --> Total execution time: 0.0281
DEBUG - 2011-08-28 18:23:45 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:45 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:45 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Controller Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:45 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:46 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:46 --> Total execution time: 0.5117
DEBUG - 2011-08-28 18:23:55 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:55 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:55 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Controller Class Initialized
ERROR - 2011-08-28 18:23:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:23:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:55 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:23:55 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:23:55 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:55 --> Total execution time: 0.0268
DEBUG - 2011-08-28 18:23:55 --> Config Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:23:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:23:55 --> URI Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Router Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Output Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Input Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:23:55 --> Language Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Loader Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Controller Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Model Class Initialized
DEBUG - 2011-08-28 18:23:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:23:55 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:23:56 --> Final output sent to browser
DEBUG - 2011-08-28 18:23:56 --> Total execution time: 0.5407
DEBUG - 2011-08-28 18:24:01 --> Config Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:24:01 --> URI Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Router Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Output Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Input Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:24:01 --> Language Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Loader Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Controller Class Initialized
ERROR - 2011-08-28 18:24:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:24:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:24:01 --> Model Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Model Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:24:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:24:01 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:24:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:24:01 --> Final output sent to browser
DEBUG - 2011-08-28 18:24:01 --> Total execution time: 0.1440
DEBUG - 2011-08-28 18:24:01 --> Config Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:24:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:24:01 --> URI Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Router Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Output Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Input Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:24:01 --> Language Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Loader Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Controller Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Model Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Model Class Initialized
DEBUG - 2011-08-28 18:24:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:24:01 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:24:02 --> Final output sent to browser
DEBUG - 2011-08-28 18:24:02 --> Total execution time: 0.5551
DEBUG - 2011-08-28 18:25:20 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:20 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Router Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Output Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Input Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:25:20 --> Language Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Loader Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Controller Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:25:20 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:25:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:25:20 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:25:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:25:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:25:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:25:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:25:20 --> Final output sent to browser
DEBUG - 2011-08-28 18:25:20 --> Total execution time: 0.2868
DEBUG - 2011-08-28 18:25:24 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:24 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:24 --> Router Class Initialized
ERROR - 2011-08-28 18:25:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:25:39 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:39 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Router Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Output Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Input Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:25:39 --> Language Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Loader Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Controller Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:25:39 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:25:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:25:39 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:25:39 --> Final output sent to browser
DEBUG - 2011-08-28 18:25:39 --> Total execution time: 0.0486
DEBUG - 2011-08-28 18:25:40 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:40 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Router Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Output Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Input Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:25:40 --> Language Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Loader Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Controller Class Initialized
ERROR - 2011-08-28 18:25:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:25:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:25:40 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:25:40 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:25:40 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:25:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:25:40 --> Final output sent to browser
DEBUG - 2011-08-28 18:25:40 --> Total execution time: 0.0283
DEBUG - 2011-08-28 18:25:41 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:41 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Router Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Output Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Input Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:25:41 --> Language Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Loader Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Controller Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Model Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:25:41 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:25:41 --> Final output sent to browser
DEBUG - 2011-08-28 18:25:41 --> Total execution time: 0.4571
DEBUG - 2011-08-28 18:25:43 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:43 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Router Class Initialized
ERROR - 2011-08-28 18:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:25:43 --> Config Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:25:43 --> URI Class Initialized
DEBUG - 2011-08-28 18:25:43 --> Router Class Initialized
ERROR - 2011-08-28 18:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:26:02 --> Config Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:26:02 --> URI Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Router Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Output Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Input Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:26:02 --> Language Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Loader Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Controller Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:26:02 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:26:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:26:02 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:26:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:26:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:26:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:26:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:26:02 --> Final output sent to browser
DEBUG - 2011-08-28 18:26:02 --> Total execution time: 0.2092
DEBUG - 2011-08-28 18:26:03 --> Config Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:26:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:26:03 --> URI Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Router Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Output Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Input Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:26:03 --> Language Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Loader Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Controller Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:26:03 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:26:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:26:03 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:26:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:26:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:26:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:26:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:26:03 --> Final output sent to browser
DEBUG - 2011-08-28 18:26:03 --> Total execution time: 0.0435
DEBUG - 2011-08-28 18:26:05 --> Config Class Initialized
DEBUG - 2011-08-28 18:26:05 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:26:05 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:26:05 --> URI Class Initialized
DEBUG - 2011-08-28 18:26:05 --> Router Class Initialized
ERROR - 2011-08-28 18:26:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:26:15 --> Config Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:26:15 --> URI Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Router Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Output Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Input Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:26:15 --> Language Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Loader Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Controller Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Model Class Initialized
DEBUG - 2011-08-28 18:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:26:15 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:26:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:26:15 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:26:15 --> Final output sent to browser
DEBUG - 2011-08-28 18:26:15 --> Total execution time: 0.1946
DEBUG - 2011-08-28 18:26:18 --> Config Class Initialized
DEBUG - 2011-08-28 18:26:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:26:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:26:18 --> URI Class Initialized
DEBUG - 2011-08-28 18:26:18 --> Router Class Initialized
ERROR - 2011-08-28 18:26:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:38:30 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:30 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Router Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Output Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Input Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:38:30 --> Language Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Loader Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Controller Class Initialized
ERROR - 2011-08-28 18:38:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:38:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:30 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:38:30 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:30 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:38:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:38:30 --> Final output sent to browser
DEBUG - 2011-08-28 18:38:30 --> Total execution time: 0.0295
DEBUG - 2011-08-28 18:38:32 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:32 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Router Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Output Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Input Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:38:32 --> Language Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Loader Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Controller Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:38:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:38:33 --> Final output sent to browser
DEBUG - 2011-08-28 18:38:33 --> Total execution time: 0.5114
DEBUG - 2011-08-28 18:38:39 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:39 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:39 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:39 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:39 --> Router Class Initialized
ERROR - 2011-08-28 18:38:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:38:57 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:57 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Router Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Output Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Input Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:38:57 --> Language Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Loader Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Controller Class Initialized
ERROR - 2011-08-28 18:38:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:38:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:57 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:38:57 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:57 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:38:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:38:57 --> Final output sent to browser
DEBUG - 2011-08-28 18:38:57 --> Total execution time: 0.0331
DEBUG - 2011-08-28 18:38:58 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:58 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Router Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Output Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Input Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:38:58 --> Language Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Loader Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Controller Class Initialized
ERROR - 2011-08-28 18:38:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 18:38:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:58 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 18:38:58 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:38:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:38:58 --> Final output sent to browser
DEBUG - 2011-08-28 18:38:58 --> Total execution time: 0.0288
DEBUG - 2011-08-28 18:38:58 --> Config Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:38:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:38:58 --> URI Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Router Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Output Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Input Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:38:58 --> Language Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Loader Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Controller Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Model Class Initialized
DEBUG - 2011-08-28 18:38:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:38:58 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:38:59 --> Final output sent to browser
DEBUG - 2011-08-28 18:38:59 --> Total execution time: 0.5476
DEBUG - 2011-08-28 18:39:02 --> Config Class Initialized
DEBUG - 2011-08-28 18:39:02 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:39:02 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:39:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:39:02 --> URI Class Initialized
DEBUG - 2011-08-28 18:39:02 --> Router Class Initialized
ERROR - 2011-08-28 18:39:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:42:53 --> Config Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:42:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:42:53 --> URI Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Router Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Output Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Input Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:42:53 --> Language Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Loader Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Controller Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Model Class Initialized
DEBUG - 2011-08-28 18:42:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:42:53 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:42:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:42:53 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:42:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:42:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:42:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:42:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:42:53 --> Final output sent to browser
DEBUG - 2011-08-28 18:42:53 --> Total execution time: 0.0540
DEBUG - 2011-08-28 18:42:54 --> Config Class Initialized
DEBUG - 2011-08-28 18:42:54 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:42:54 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:42:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:42:54 --> URI Class Initialized
DEBUG - 2011-08-28 18:42:54 --> Router Class Initialized
ERROR - 2011-08-28 18:42:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 18:51:59 --> Config Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Hooks Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Utf8 Class Initialized
DEBUG - 2011-08-28 18:51:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 18:51:59 --> URI Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Router Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Output Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Input Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 18:51:59 --> Language Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Loader Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Controller Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Model Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Model Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Model Class Initialized
DEBUG - 2011-08-28 18:51:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 18:51:59 --> Database Driver Class Initialized
DEBUG - 2011-08-28 18:51:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 18:51:59 --> Helper loaded: url_helper
DEBUG - 2011-08-28 18:51:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 18:51:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 18:51:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 18:51:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 18:51:59 --> Final output sent to browser
DEBUG - 2011-08-28 18:51:59 --> Total execution time: 0.2057
DEBUG - 2011-08-28 19:02:29 --> Config Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:02:29 --> URI Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Router Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Output Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Input Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 19:02:29 --> Language Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Loader Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Controller Class Initialized
ERROR - 2011-08-28 19:02:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 19:02:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 19:02:29 --> Model Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Model Class Initialized
DEBUG - 2011-08-28 19:02:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 19:02:29 --> Database Driver Class Initialized
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 19:02:29 --> Helper loaded: url_helper
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 19:02:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 19:02:29 --> Final output sent to browser
DEBUG - 2011-08-28 19:02:29 --> Total execution time: 0.0309
DEBUG - 2011-08-28 19:57:09 --> Config Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:57:09 --> URI Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Router Class Initialized
ERROR - 2011-08-28 19:57:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 19:57:09 --> Config Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:57:09 --> URI Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Router Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Output Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Input Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 19:57:09 --> Language Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Loader Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Controller Class Initialized
ERROR - 2011-08-28 19:57:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 19:57:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 19:57:09 --> Model Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Model Class Initialized
DEBUG - 2011-08-28 19:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 19:57:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 19:57:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 19:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 19:57:09 --> Final output sent to browser
DEBUG - 2011-08-28 19:57:09 --> Total execution time: 0.0320
DEBUG - 2011-08-28 19:57:14 --> Config Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:57:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:57:14 --> URI Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Router Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Output Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Input Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 19:57:14 --> Language Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Loader Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Controller Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Model Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Model Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Model Class Initialized
DEBUG - 2011-08-28 19:57:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 19:57:14 --> Database Driver Class Initialized
DEBUG - 2011-08-28 19:57:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 19:57:15 --> Helper loaded: url_helper
DEBUG - 2011-08-28 19:57:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 19:57:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 19:57:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 19:57:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 19:57:15 --> Final output sent to browser
DEBUG - 2011-08-28 19:57:15 --> Total execution time: 0.2613
DEBUG - 2011-08-28 19:57:17 --> Config Class Initialized
DEBUG - 2011-08-28 19:57:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:57:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:57:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:57:17 --> URI Class Initialized
DEBUG - 2011-08-28 19:57:17 --> Router Class Initialized
ERROR - 2011-08-28 19:57:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 19:57:19 --> Config Class Initialized
DEBUG - 2011-08-28 19:57:19 --> Hooks Class Initialized
DEBUG - 2011-08-28 19:57:19 --> Utf8 Class Initialized
DEBUG - 2011-08-28 19:57:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 19:57:19 --> URI Class Initialized
DEBUG - 2011-08-28 19:57:19 --> Router Class Initialized
ERROR - 2011-08-28 19:57:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:10:09 --> Config Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:10:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:10:09 --> URI Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Router Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Output Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Input Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:10:09 --> Language Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Loader Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Controller Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Model Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Model Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Model Class Initialized
DEBUG - 2011-08-28 20:10:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:10:09 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:10:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 20:10:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:10:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:10:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:10:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:10:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:10:09 --> Final output sent to browser
DEBUG - 2011-08-28 20:10:09 --> Total execution time: 0.0572
DEBUG - 2011-08-28 20:10:11 --> Config Class Initialized
DEBUG - 2011-08-28 20:10:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:10:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:10:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:10:11 --> URI Class Initialized
DEBUG - 2011-08-28 20:10:11 --> Router Class Initialized
ERROR - 2011-08-28 20:10:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:19:25 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:25 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Router Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Output Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Input Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:19:25 --> Language Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Loader Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Controller Class Initialized
ERROR - 2011-08-28 20:19:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 20:19:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:19:25 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:19:25 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:19:25 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:19:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:19:25 --> Final output sent to browser
DEBUG - 2011-08-28 20:19:25 --> Total execution time: 0.0426
DEBUG - 2011-08-28 20:19:26 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:26 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Router Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Output Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Input Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:19:26 --> Language Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Loader Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Controller Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:19:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:19:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 20:19:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:19:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:19:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:19:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:19:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:19:26 --> Final output sent to browser
DEBUG - 2011-08-28 20:19:26 --> Total execution time: 0.1718
DEBUG - 2011-08-28 20:19:40 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:40 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Router Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Output Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Input Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:19:40 --> Language Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Loader Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Controller Class Initialized
ERROR - 2011-08-28 20:19:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 20:19:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:19:40 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:19:40 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:19:40 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:19:40 --> Final output sent to browser
DEBUG - 2011-08-28 20:19:40 --> Total execution time: 0.0424
DEBUG - 2011-08-28 20:19:40 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:40 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Router Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Output Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Input Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:19:40 --> Language Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Loader Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Controller Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Model Class Initialized
DEBUG - 2011-08-28 20:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:19:40 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:19:41 --> Final output sent to browser
DEBUG - 2011-08-28 20:19:41 --> Total execution time: 0.6673
DEBUG - 2011-08-28 20:19:44 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:44 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:44 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:44 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:44 --> Router Class Initialized
ERROR - 2011-08-28 20:19:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:19:45 --> Config Class Initialized
DEBUG - 2011-08-28 20:19:45 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:19:45 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:19:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:19:45 --> URI Class Initialized
DEBUG - 2011-08-28 20:19:45 --> Router Class Initialized
ERROR - 2011-08-28 20:19:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:29:26 --> Config Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:29:26 --> URI Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Router Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Output Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Input Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:29:26 --> Language Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Loader Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Controller Class Initialized
ERROR - 2011-08-28 20:29:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 20:29:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:29:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:29:26 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:29:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:29:26 --> Final output sent to browser
DEBUG - 2011-08-28 20:29:26 --> Total execution time: 0.0284
DEBUG - 2011-08-28 20:29:26 --> Config Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:29:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:29:26 --> URI Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Router Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Output Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Input Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:29:26 --> Language Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Loader Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Controller Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Model Class Initialized
DEBUG - 2011-08-28 20:29:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:29:26 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:29:27 --> Final output sent to browser
DEBUG - 2011-08-28 20:29:27 --> Total execution time: 0.5050
DEBUG - 2011-08-28 20:29:28 --> Config Class Initialized
DEBUG - 2011-08-28 20:29:28 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:29:28 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:29:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:29:28 --> URI Class Initialized
DEBUG - 2011-08-28 20:29:28 --> Router Class Initialized
ERROR - 2011-08-28 20:29:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:29:29 --> Config Class Initialized
DEBUG - 2011-08-28 20:29:29 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:29:29 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:29:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:29:29 --> URI Class Initialized
DEBUG - 2011-08-28 20:29:29 --> Router Class Initialized
ERROR - 2011-08-28 20:29:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 20:44:10 --> Config Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:44:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:44:10 --> URI Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Router Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Output Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Input Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 20:44:10 --> Language Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Loader Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Controller Class Initialized
ERROR - 2011-08-28 20:44:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 20:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:44:10 --> Model Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Model Class Initialized
DEBUG - 2011-08-28 20:44:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 20:44:10 --> Database Driver Class Initialized
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 20:44:10 --> Helper loaded: url_helper
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 20:44:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 20:44:10 --> Final output sent to browser
DEBUG - 2011-08-28 20:44:10 --> Total execution time: 0.0356
DEBUG - 2011-08-28 20:44:13 --> Config Class Initialized
DEBUG - 2011-08-28 20:44:13 --> Hooks Class Initialized
DEBUG - 2011-08-28 20:44:13 --> Utf8 Class Initialized
DEBUG - 2011-08-28 20:44:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 20:44:13 --> URI Class Initialized
DEBUG - 2011-08-28 20:44:13 --> Router Class Initialized
ERROR - 2011-08-28 20:44:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 21:11:33 --> Config Class Initialized
DEBUG - 2011-08-28 21:11:33 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:11:33 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:11:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:11:33 --> URI Class Initialized
DEBUG - 2011-08-28 21:11:33 --> Router Class Initialized
ERROR - 2011-08-28 21:11:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 21:51:06 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:06 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Router Class Initialized
ERROR - 2011-08-28 21:51:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 21:51:06 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:06 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:06 --> Router Class Initialized
ERROR - 2011-08-28 21:51:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 21:51:08 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:08 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Router Class Initialized
DEBUG - 2011-08-28 21:51:08 --> No URI present. Default controller set.
DEBUG - 2011-08-28 21:51:08 --> Output Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Input Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 21:51:08 --> Language Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Loader Class Initialized
DEBUG - 2011-08-28 21:51:08 --> Controller Class Initialized
DEBUG - 2011-08-28 21:51:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 21:51:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 21:51:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 21:51:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 21:51:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 21:51:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 21:51:08 --> Final output sent to browser
DEBUG - 2011-08-28 21:51:08 --> Total execution time: 0.3503
DEBUG - 2011-08-28 21:51:09 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:09 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Router Class Initialized
DEBUG - 2011-08-28 21:51:09 --> No URI present. Default controller set.
DEBUG - 2011-08-28 21:51:09 --> Output Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Input Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 21:51:09 --> Language Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Loader Class Initialized
DEBUG - 2011-08-28 21:51:09 --> Controller Class Initialized
DEBUG - 2011-08-28 21:51:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 21:51:09 --> Helper loaded: url_helper
DEBUG - 2011-08-28 21:51:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 21:51:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 21:51:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 21:51:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 21:51:09 --> Final output sent to browser
DEBUG - 2011-08-28 21:51:09 --> Total execution time: 0.0186
DEBUG - 2011-08-28 21:51:11 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:11 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Router Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Output Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Input Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 21:51:11 --> Language Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Loader Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Controller Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Model Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Model Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Model Class Initialized
DEBUG - 2011-08-28 21:51:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 21:51:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 21:51:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 21:51:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 21:51:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 21:51:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 21:51:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 21:51:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 21:51:11 --> Final output sent to browser
DEBUG - 2011-08-28 21:51:11 --> Total execution time: 0.2599
DEBUG - 2011-08-28 21:51:12 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:12 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Router Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Output Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Input Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 21:51:12 --> Language Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Loader Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Controller Class Initialized
ERROR - 2011-08-28 21:51:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 21:51:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 21:51:12 --> Model Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Model Class Initialized
DEBUG - 2011-08-28 21:51:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 21:51:12 --> Database Driver Class Initialized
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 21:51:12 --> Helper loaded: url_helper
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 21:51:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 21:51:12 --> Final output sent to browser
DEBUG - 2011-08-28 21:51:12 --> Total execution time: 0.0377
DEBUG - 2011-08-28 21:51:14 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:14 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:14 --> Router Class Initialized
DEBUG - 2011-08-28 21:51:17 --> Config Class Initialized
DEBUG - 2011-08-28 21:51:17 --> Hooks Class Initialized
DEBUG - 2011-08-28 21:51:17 --> Utf8 Class Initialized
DEBUG - 2011-08-28 21:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 21:51:17 --> URI Class Initialized
DEBUG - 2011-08-28 21:51:17 --> Router Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Config Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:10:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:10:14 --> URI Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Router Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Output Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Input Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 22:10:14 --> Language Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Loader Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Controller Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Model Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Model Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Model Class Initialized
DEBUG - 2011-08-28 22:10:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 22:10:14 --> Database Driver Class Initialized
DEBUG - 2011-08-28 22:10:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 22:10:14 --> Helper loaded: url_helper
DEBUG - 2011-08-28 22:10:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 22:10:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 22:10:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 22:10:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 22:10:14 --> Final output sent to browser
DEBUG - 2011-08-28 22:10:14 --> Total execution time: 0.0927
DEBUG - 2011-08-28 22:10:20 --> Config Class Initialized
DEBUG - 2011-08-28 22:10:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:10:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:10:20 --> URI Class Initialized
DEBUG - 2011-08-28 22:10:20 --> Router Class Initialized
ERROR - 2011-08-28 22:10:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 22:11:34 --> Config Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:11:34 --> URI Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Router Class Initialized
DEBUG - 2011-08-28 22:11:34 --> No URI present. Default controller set.
DEBUG - 2011-08-28 22:11:34 --> Output Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Input Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 22:11:34 --> Language Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Loader Class Initialized
DEBUG - 2011-08-28 22:11:34 --> Controller Class Initialized
DEBUG - 2011-08-28 22:11:34 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 22:11:34 --> Helper loaded: url_helper
DEBUG - 2011-08-28 22:11:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 22:11:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 22:11:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 22:11:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 22:11:34 --> Final output sent to browser
DEBUG - 2011-08-28 22:11:34 --> Total execution time: 0.0832
DEBUG - 2011-08-28 22:33:48 --> Config Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:33:48 --> URI Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Router Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Output Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Input Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 22:33:48 --> Language Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Loader Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Controller Class Initialized
ERROR - 2011-08-28 22:33:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 22:33:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 22:33:48 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 22:33:48 --> Database Driver Class Initialized
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 22:33:48 --> Helper loaded: url_helper
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 22:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 22:33:48 --> Final output sent to browser
DEBUG - 2011-08-28 22:33:48 --> Total execution time: 0.0756
DEBUG - 2011-08-28 22:33:49 --> Config Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:33:49 --> URI Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Router Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Output Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Input Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 22:33:49 --> Language Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Loader Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Controller Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 22:33:49 --> Database Driver Class Initialized
DEBUG - 2011-08-28 22:33:50 --> Final output sent to browser
DEBUG - 2011-08-28 22:33:50 --> Total execution time: 0.7130
DEBUG - 2011-08-28 22:33:51 --> Config Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:33:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:33:51 --> URI Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Router Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Output Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Input Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 22:33:51 --> Language Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Loader Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Controller Class Initialized
ERROR - 2011-08-28 22:33:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-28 22:33:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 22:33:51 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Model Class Initialized
DEBUG - 2011-08-28 22:33:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 22:33:51 --> Database Driver Class Initialized
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-28 22:33:51 --> Helper loaded: url_helper
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 22:33:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 22:33:51 --> Final output sent to browser
DEBUG - 2011-08-28 22:33:51 --> Total execution time: 0.0305
DEBUG - 2011-08-28 22:33:52 --> Config Class Initialized
DEBUG - 2011-08-28 22:33:52 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:33:52 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:33:52 --> URI Class Initialized
DEBUG - 2011-08-28 22:33:52 --> Router Class Initialized
ERROR - 2011-08-28 22:33:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 22:33:53 --> Config Class Initialized
DEBUG - 2011-08-28 22:33:53 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:33:53 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:33:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:33:53 --> URI Class Initialized
DEBUG - 2011-08-28 22:33:53 --> Router Class Initialized
ERROR - 2011-08-28 22:33:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 22:57:30 --> Config Class Initialized
DEBUG - 2011-08-28 22:57:30 --> Hooks Class Initialized
DEBUG - 2011-08-28 22:57:30 --> Utf8 Class Initialized
DEBUG - 2011-08-28 22:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 22:57:30 --> URI Class Initialized
DEBUG - 2011-08-28 22:57:30 --> Router Class Initialized
ERROR - 2011-08-28 22:57:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-28 23:28:18 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:18 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Router Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Output Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Input Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:28:18 --> Language Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Loader Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Controller Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:28:18 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:18 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Router Class Initialized
DEBUG - 2011-08-28 23:28:18 --> No URI present. Default controller set.
DEBUG - 2011-08-28 23:28:18 --> Output Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Input Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:28:18 --> Language Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Loader Class Initialized
DEBUG - 2011-08-28 23:28:18 --> Controller Class Initialized
DEBUG - 2011-08-28 23:28:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-28 23:28:18 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:28:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:28:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:28:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:28:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:28:18 --> Final output sent to browser
DEBUG - 2011-08-28 23:28:18 --> Total execution time: 0.0579
DEBUG - 2011-08-28 23:28:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:28:19 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:28:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:28:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:28:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:28:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:28:19 --> Final output sent to browser
DEBUG - 2011-08-28 23:28:19 --> Total execution time: 0.9688
DEBUG - 2011-08-28 23:28:25 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:25 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Router Class Initialized
ERROR - 2011-08-28 23:28:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 23:28:25 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:25 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:25 --> Router Class Initialized
ERROR - 2011-08-28 23:28:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 23:28:26 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:26 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:26 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:26 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:26 --> Router Class Initialized
ERROR - 2011-08-28 23:28:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-28 23:28:32 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:32 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Router Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Output Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Input Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:28:32 --> Language Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Loader Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Controller Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:28:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:28:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:28:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:28:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:28:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:28:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:28:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:28:32 --> Final output sent to browser
DEBUG - 2011-08-28 23:28:32 --> Total execution time: 0.2075
DEBUG - 2011-08-28 23:28:57 --> Config Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:28:57 --> URI Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Router Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Output Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Input Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:28:57 --> Language Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Loader Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Controller Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:28:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:28:57 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:28:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:28:57 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:28:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:28:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:28:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:28:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:28:57 --> Final output sent to browser
DEBUG - 2011-08-28 23:28:57 --> Total execution time: 0.1856
DEBUG - 2011-08-28 23:29:08 --> Config Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:29:08 --> URI Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Router Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Output Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Input Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:29:08 --> Language Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Loader Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Controller Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:29:08 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:29:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:29:08 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:29:08 --> Final output sent to browser
DEBUG - 2011-08-28 23:29:08 --> Total execution time: 0.3546
DEBUG - 2011-08-28 23:29:22 --> Config Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:29:22 --> URI Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Router Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Output Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Input Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:29:22 --> Language Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Loader Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Controller Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:29:22 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:29:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:29:22 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:29:22 --> Final output sent to browser
DEBUG - 2011-08-28 23:29:22 --> Total execution time: 0.1945
DEBUG - 2011-08-28 23:29:40 --> Config Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:29:40 --> URI Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Router Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Output Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Input Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:29:40 --> Language Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Loader Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Controller Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:29:40 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:29:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:29:40 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:29:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:29:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:29:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:29:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:29:40 --> Final output sent to browser
DEBUG - 2011-08-28 23:29:40 --> Total execution time: 0.2472
DEBUG - 2011-08-28 23:29:57 --> Config Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:29:57 --> URI Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Router Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Output Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Input Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:29:57 --> Language Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Loader Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Controller Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Model Class Initialized
DEBUG - 2011-08-28 23:29:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:29:57 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:29:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:29:57 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:29:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:29:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:29:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:29:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:29:57 --> Final output sent to browser
DEBUG - 2011-08-28 23:29:57 --> Total execution time: 0.4085
DEBUG - 2011-08-28 23:30:11 --> Config Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:30:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:30:11 --> URI Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Router Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Output Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Input Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:30:11 --> Language Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Loader Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Controller Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:30:11 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:30:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:30:11 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:30:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:30:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:30:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:30:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:30:11 --> Final output sent to browser
DEBUG - 2011-08-28 23:30:11 --> Total execution time: 0.2602
DEBUG - 2011-08-28 23:30:24 --> Config Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:30:24 --> URI Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Router Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Output Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Input Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:30:24 --> Language Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Loader Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Controller Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:30:24 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:30:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:30:24 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:30:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:30:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:30:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:30:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:30:24 --> Final output sent to browser
DEBUG - 2011-08-28 23:30:24 --> Total execution time: 0.2904
DEBUG - 2011-08-28 23:30:46 --> Config Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:30:46 --> URI Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Router Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Output Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Input Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:30:46 --> Language Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Loader Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Controller Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Model Class Initialized
DEBUG - 2011-08-28 23:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:30:46 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:30:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:30:46 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:30:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:30:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:30:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:30:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:30:46 --> Final output sent to browser
DEBUG - 2011-08-28 23:30:46 --> Total execution time: 0.3866
DEBUG - 2011-08-28 23:31:20 --> Config Class Initialized
DEBUG - 2011-08-28 23:31:20 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:31:20 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:31:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:31:20 --> URI Class Initialized
DEBUG - 2011-08-28 23:31:20 --> Router Class Initialized
DEBUG - 2011-08-28 23:31:20 --> Output Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Input Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:31:21 --> Language Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Loader Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Controller Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:31:21 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:31:21 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:31:21 --> Final output sent to browser
DEBUG - 2011-08-28 23:31:21 --> Total execution time: 0.2012
DEBUG - 2011-08-28 23:31:32 --> Config Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Hooks Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Utf8 Class Initialized
DEBUG - 2011-08-28 23:31:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-28 23:31:32 --> URI Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Router Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Output Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Input Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-28 23:31:32 --> Language Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Loader Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Controller Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Model Class Initialized
DEBUG - 2011-08-28 23:31:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-28 23:31:32 --> Database Driver Class Initialized
DEBUG - 2011-08-28 23:31:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-28 23:31:32 --> Helper loaded: url_helper
DEBUG - 2011-08-28 23:31:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-28 23:31:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-28 23:31:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-28 23:31:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-28 23:31:32 --> Final output sent to browser
DEBUG - 2011-08-28 23:31:32 --> Total execution time: 0.2349

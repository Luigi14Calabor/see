<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-07 00:25:39 --> Config Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:25:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:25:39 --> URI Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Router Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Output Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Input Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:25:39 --> Language Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Loader Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Controller Class Initialized
ERROR - 2011-08-07 00:25:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:25:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:25:39 --> Model Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Model Class Initialized
DEBUG - 2011-08-07 00:25:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:25:39 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:25:39 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:25:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:25:39 --> Final output sent to browser
DEBUG - 2011-08-07 00:25:39 --> Total execution time: 0.1265
DEBUG - 2011-08-07 00:25:40 --> Config Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:25:40 --> URI Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Router Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Output Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Input Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:25:40 --> Language Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Loader Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Controller Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Model Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Model Class Initialized
DEBUG - 2011-08-07 00:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:25:40 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:25:41 --> Final output sent to browser
DEBUG - 2011-08-07 00:25:41 --> Total execution time: 0.5439
DEBUG - 2011-08-07 00:25:43 --> Config Class Initialized
DEBUG - 2011-08-07 00:25:43 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:25:43 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:25:43 --> URI Class Initialized
DEBUG - 2011-08-07 00:25:43 --> Router Class Initialized
ERROR - 2011-08-07 00:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:25:44 --> Config Class Initialized
DEBUG - 2011-08-07 00:25:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:25:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:25:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:25:44 --> URI Class Initialized
DEBUG - 2011-08-07 00:25:44 --> Router Class Initialized
ERROR - 2011-08-07 00:25:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:26:11 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:11 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:11 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:11 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:11 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:11 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:11 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:11 --> Total execution time: 0.0288
DEBUG - 2011-08-07 00:26:11 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:11 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:11 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Controller Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:11 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:12 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:12 --> Total execution time: 0.6430
DEBUG - 2011-08-07 00:26:13 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:13 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Router Class Initialized
ERROR - 2011-08-07 00:26:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 00:26:13 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:13 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:13 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:13 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:13 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:13 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:13 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:13 --> Total execution time: 0.0266
DEBUG - 2011-08-07 00:26:14 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:14 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:14 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:14 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:14 --> Router Class Initialized
ERROR - 2011-08-07 00:26:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:26:21 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:21 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:21 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:21 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:21 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:21 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:21 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:21 --> Total execution time: 0.0574
DEBUG - 2011-08-07 00:26:21 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:21 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:22 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:22 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Controller Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:22 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:22 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:22 --> Total execution time: 0.5690
DEBUG - 2011-08-07 00:26:24 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:24 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:24 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:24 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:24 --> Router Class Initialized
ERROR - 2011-08-07 00:26:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:26:37 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:37 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:37 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:37 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:37 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:37 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:37 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:37 --> Total execution time: 0.0973
DEBUG - 2011-08-07 00:26:37 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:38 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:38 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Controller Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:38 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:38 --> Total execution time: 0.7267
DEBUG - 2011-08-07 00:26:41 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:41 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:41 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:41 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:41 --> Router Class Initialized
ERROR - 2011-08-07 00:26:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:26:47 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:47 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:47 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:47 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:47 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:47 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:47 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:47 --> Total execution time: 0.0289
DEBUG - 2011-08-07 00:26:47 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:47 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:47 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Controller Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:47 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:48 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:48 --> Total execution time: 0.5281
DEBUG - 2011-08-07 00:26:50 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:50 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:50 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:50 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:50 --> Router Class Initialized
ERROR - 2011-08-07 00:26:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:26:59 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:59 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:59 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Controller Class Initialized
ERROR - 2011-08-07 00:26:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:26:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:26:59 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:26:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:26:59 --> Final output sent to browser
DEBUG - 2011-08-07 00:26:59 --> Total execution time: 0.0693
DEBUG - 2011-08-07 00:26:59 --> Config Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:26:59 --> URI Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Router Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Output Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Input Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:26:59 --> Language Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Loader Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Controller Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:26:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:00 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:00 --> Total execution time: 0.5392
DEBUG - 2011-08-07 00:27:02 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:02 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:02 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:02 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:02 --> Router Class Initialized
ERROR - 2011-08-07 00:27:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:08 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:08 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:08 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:08 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:08 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:08 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:08 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:08 --> Total execution time: 0.0267
DEBUG - 2011-08-07 00:27:09 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:09 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:09 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:09 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:09 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:09 --> Total execution time: 0.5239
DEBUG - 2011-08-07 00:27:11 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:11 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:11 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:11 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:11 --> Router Class Initialized
ERROR - 2011-08-07 00:27:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:17 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:17 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:17 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:17 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:17 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:17 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:17 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:17 --> Total execution time: 0.0278
DEBUG - 2011-08-07 00:27:18 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:18 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:18 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:18 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:19 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:19 --> Total execution time: 0.5515
DEBUG - 2011-08-07 00:27:21 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:21 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:21 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:21 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:21 --> Router Class Initialized
ERROR - 2011-08-07 00:27:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:27 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:27 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:27 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:27 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:27 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:27 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:27 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:27 --> Total execution time: 0.0270
DEBUG - 2011-08-07 00:27:28 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:28 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:28 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:28 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:29 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:29 --> Total execution time: 0.5235
DEBUG - 2011-08-07 00:27:31 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:31 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:31 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:31 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:31 --> Router Class Initialized
ERROR - 2011-08-07 00:27:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:35 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:35 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:35 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:35 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:35 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:35 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:35 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:35 --> Total execution time: 0.0309
DEBUG - 2011-08-07 00:27:36 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:36 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:36 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:37 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:37 --> Total execution time: 0.5199
DEBUG - 2011-08-07 00:27:39 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:39 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:39 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:39 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:39 --> Router Class Initialized
ERROR - 2011-08-07 00:27:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:50 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:50 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:50 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:50 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:50 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:50 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:50 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:50 --> Total execution time: 0.0283
DEBUG - 2011-08-07 00:27:51 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:51 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:51 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:51 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:51 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:51 --> Total execution time: 0.5047
DEBUG - 2011-08-07 00:27:54 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:54 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:54 --> Router Class Initialized
ERROR - 2011-08-07 00:27:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:27:59 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:59 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:59 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Controller Class Initialized
ERROR - 2011-08-07 00:27:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:27:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:27:59 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:27:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:27:59 --> Final output sent to browser
DEBUG - 2011-08-07 00:27:59 --> Total execution time: 0.0271
DEBUG - 2011-08-07 00:27:59 --> Config Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:27:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:27:59 --> URI Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Router Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Output Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Input Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:27:59 --> Language Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Loader Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Controller Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Model Class Initialized
DEBUG - 2011-08-07 00:27:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:27:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:00 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:00 --> Total execution time: 0.5331
DEBUG - 2011-08-07 00:28:02 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:02 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:02 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:02 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:02 --> Router Class Initialized
ERROR - 2011-08-07 00:28:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:06 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:06 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:06 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Controller Class Initialized
ERROR - 2011-08-07 00:28:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:28:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:06 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:06 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:06 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:06 --> Total execution time: 0.0284
DEBUG - 2011-08-07 00:28:06 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:06 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:06 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Controller Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:06 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:06 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:06 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Controller Class Initialized
ERROR - 2011-08-07 00:28:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:28:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:06 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:06 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:06 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:06 --> Total execution time: 0.0276
DEBUG - 2011-08-07 00:28:07 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:07 --> Total execution time: 0.5037
DEBUG - 2011-08-07 00:28:09 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:09 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:09 --> Router Class Initialized
ERROR - 2011-08-07 00:28:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:16 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:16 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:16 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Controller Class Initialized
ERROR - 2011-08-07 00:28:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:28:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:16 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:16 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:16 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:16 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:16 --> Total execution time: 0.0297
DEBUG - 2011-08-07 00:28:17 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:17 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:17 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Controller Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:17 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:18 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:18 --> Total execution time: 0.5003
DEBUG - 2011-08-07 00:28:20 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:20 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:20 --> Router Class Initialized
ERROR - 2011-08-07 00:28:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:27 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:27 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:27 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Controller Class Initialized
DEBUG - 2011-08-07 00:28:27 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:28 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:28 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:28 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 00:28:28 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:28 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:28 --> Total execution time: 0.2579
DEBUG - 2011-08-07 00:28:29 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:29 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:29 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Controller Class Initialized
ERROR - 2011-08-07 00:28:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:28:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:29 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:29 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:29 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:29 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:29 --> Total execution time: 0.0277
DEBUG - 2011-08-07 00:28:30 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:30 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Router Class Initialized
ERROR - 2011-08-07 00:28:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:30 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:30 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:30 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Controller Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:30 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:30 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Router Class Initialized
ERROR - 2011-08-07 00:28:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:30 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:30 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:30 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Controller Class Initialized
ERROR - 2011-08-07 00:28:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 00:28:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:30 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:30 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 00:28:30 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:30 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:30 --> Total execution time: 0.0321
DEBUG - 2011-08-07 00:28:30 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:30 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:30 --> Router Class Initialized
ERROR - 2011-08-07 00:28:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:31 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:31 --> Total execution time: 0.5837
DEBUG - 2011-08-07 00:28:33 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:33 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:33 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:33 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:33 --> Router Class Initialized
ERROR - 2011-08-07 00:28:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 00:28:58 --> Config Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Hooks Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Utf8 Class Initialized
DEBUG - 2011-08-07 00:28:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 00:28:58 --> URI Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Router Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Output Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Input Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 00:28:58 --> Language Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Loader Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Controller Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Model Class Initialized
DEBUG - 2011-08-07 00:28:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 00:28:58 --> Database Driver Class Initialized
DEBUG - 2011-08-07 00:28:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 00:28:58 --> Helper loaded: url_helper
DEBUG - 2011-08-07 00:28:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 00:28:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 00:28:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 00:28:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 00:28:58 --> Final output sent to browser
DEBUG - 2011-08-07 00:28:58 --> Total execution time: 0.0469
DEBUG - 2011-08-07 02:08:31 --> Config Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Hooks Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Utf8 Class Initialized
DEBUG - 2011-08-07 02:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 02:08:32 --> URI Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Router Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Output Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Input Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 02:08:32 --> Language Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Loader Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Controller Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Model Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Model Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Model Class Initialized
DEBUG - 2011-08-07 02:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 02:08:32 --> Database Driver Class Initialized
DEBUG - 2011-08-07 02:08:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 02:08:34 --> Helper loaded: url_helper
DEBUG - 2011-08-07 02:08:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 02:08:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 02:08:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 02:08:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 02:08:34 --> Final output sent to browser
DEBUG - 2011-08-07 02:08:34 --> Total execution time: 2.2630
DEBUG - 2011-08-07 02:08:35 --> Config Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Hooks Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Utf8 Class Initialized
DEBUG - 2011-08-07 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 02:08:35 --> URI Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Router Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Output Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Input Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 02:08:35 --> Language Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Loader Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Controller Class Initialized
ERROR - 2011-08-07 02:08:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 02:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 02:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 02:08:35 --> Model Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Model Class Initialized
DEBUG - 2011-08-07 02:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 02:08:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 02:08:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 02:08:36 --> Helper loaded: url_helper
DEBUG - 2011-08-07 02:08:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 02:08:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 02:08:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 02:08:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 02:08:36 --> Final output sent to browser
DEBUG - 2011-08-07 02:08:36 --> Total execution time: 0.1737
DEBUG - 2011-08-07 02:15:45 --> Config Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Hooks Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Utf8 Class Initialized
DEBUG - 2011-08-07 02:15:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 02:15:45 --> URI Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Router Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Output Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Input Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 02:15:45 --> Language Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Loader Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Controller Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Model Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Model Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Model Class Initialized
DEBUG - 2011-08-07 02:15:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 02:15:45 --> Database Driver Class Initialized
DEBUG - 2011-08-07 02:15:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 02:15:45 --> Helper loaded: url_helper
DEBUG - 2011-08-07 02:15:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 02:15:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 02:15:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 02:15:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 02:15:45 --> Final output sent to browser
DEBUG - 2011-08-07 02:15:45 --> Total execution time: 0.1239
DEBUG - 2011-08-07 02:15:48 --> Config Class Initialized
DEBUG - 2011-08-07 02:15:48 --> Hooks Class Initialized
DEBUG - 2011-08-07 02:15:48 --> Utf8 Class Initialized
DEBUG - 2011-08-07 02:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 02:15:48 --> URI Class Initialized
DEBUG - 2011-08-07 02:15:48 --> Router Class Initialized
ERROR - 2011-08-07 02:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 02:22:52 --> Config Class Initialized
DEBUG - 2011-08-07 02:22:52 --> Hooks Class Initialized
DEBUG - 2011-08-07 02:22:52 --> Utf8 Class Initialized
DEBUG - 2011-08-07 02:22:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 02:22:52 --> URI Class Initialized
DEBUG - 2011-08-07 02:22:52 --> Router Class Initialized
ERROR - 2011-08-07 02:22:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 03:09:44 --> Config Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:09:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:09:44 --> URI Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Router Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Output Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Input Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:09:44 --> Language Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Loader Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Controller Class Initialized
ERROR - 2011-08-07 03:09:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:09:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:09:44 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:09:44 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:09:44 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:09:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:09:44 --> Final output sent to browser
DEBUG - 2011-08-07 03:09:44 --> Total execution time: 0.4331
DEBUG - 2011-08-07 03:09:46 --> Config Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:09:46 --> URI Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Router Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Output Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Input Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:09:46 --> Language Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Loader Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Controller Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:09:46 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:09:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 03:09:46 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:09:46 --> Final output sent to browser
DEBUG - 2011-08-07 03:09:46 --> Total execution time: 0.2666
DEBUG - 2011-08-07 03:09:47 --> Config Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:09:47 --> URI Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Router Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Output Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Input Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:09:47 --> Language Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Loader Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Controller Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Model Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:09:47 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:09:47 --> Final output sent to browser
DEBUG - 2011-08-07 03:09:47 --> Total execution time: 0.5088
DEBUG - 2011-08-07 03:09:49 --> Config Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:09:49 --> URI Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Router Class Initialized
ERROR - 2011-08-07 03:09:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:09:49 --> Config Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:09:49 --> URI Class Initialized
DEBUG - 2011-08-07 03:09:49 --> Router Class Initialized
ERROR - 2011-08-07 03:09:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:10:41 --> Config Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:10:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:10:41 --> URI Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Router Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Output Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Input Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:10:41 --> Language Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Loader Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Controller Class Initialized
ERROR - 2011-08-07 03:10:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:10:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:10:41 --> Model Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Model Class Initialized
DEBUG - 2011-08-07 03:10:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:10:41 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:10:41 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:10:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:10:41 --> Final output sent to browser
DEBUG - 2011-08-07 03:10:41 --> Total execution time: 0.0346
DEBUG - 2011-08-07 03:10:42 --> Config Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:10:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:10:42 --> URI Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Router Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Output Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Input Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:10:42 --> Language Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Loader Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Controller Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Model Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Model Class Initialized
DEBUG - 2011-08-07 03:10:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:10:42 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:10:43 --> Final output sent to browser
DEBUG - 2011-08-07 03:10:43 --> Total execution time: 0.6914
DEBUG - 2011-08-07 03:10:44 --> Config Class Initialized
DEBUG - 2011-08-07 03:10:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:10:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:10:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:10:44 --> URI Class Initialized
DEBUG - 2011-08-07 03:10:44 --> Router Class Initialized
ERROR - 2011-08-07 03:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:50:15 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:15 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:15 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Controller Class Initialized
ERROR - 2011-08-07 03:50:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:50:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:15 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:15 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:15 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:50:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:50:15 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:15 --> Total execution time: 0.5632
DEBUG - 2011-08-07 03:50:16 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:16 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:16 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Controller Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:16 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:17 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:17 --> Total execution time: 0.7723
DEBUG - 2011-08-07 03:50:18 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:18 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Router Class Initialized
ERROR - 2011-08-07 03:50:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:50:18 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:18 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Router Class Initialized
ERROR - 2011-08-07 03:50:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:50:18 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:18 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:18 --> Router Class Initialized
ERROR - 2011-08-07 03:50:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 03:50:32 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:32 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:32 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Controller Class Initialized
ERROR - 2011-08-07 03:50:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:50:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:32 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:32 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:32 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:50:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:50:32 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:32 --> Total execution time: 0.0469
DEBUG - 2011-08-07 03:50:32 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:32 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:32 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Controller Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:32 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:33 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:33 --> Total execution time: 0.6583
DEBUG - 2011-08-07 03:50:37 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:37 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:37 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Controller Class Initialized
ERROR - 2011-08-07 03:50:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:50:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:37 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:37 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:38 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:50:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:50:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:50:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:50:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:50:38 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:38 --> Total execution time: 0.0392
DEBUG - 2011-08-07 03:50:38 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:38 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:38 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Controller Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:39 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:39 --> Total execution time: 0.6945
DEBUG - 2011-08-07 03:50:41 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:41 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:41 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Controller Class Initialized
ERROR - 2011-08-07 03:50:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 03:50:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:41 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:41 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 03:50:41 --> Helper loaded: url_helper
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 03:50:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 03:50:41 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:41 --> Total execution time: 0.0279
DEBUG - 2011-08-07 03:50:42 --> Config Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Hooks Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Utf8 Class Initialized
DEBUG - 2011-08-07 03:50:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 03:50:42 --> URI Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Router Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Output Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Input Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 03:50:42 --> Language Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Loader Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Controller Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Model Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 03:50:42 --> Database Driver Class Initialized
DEBUG - 2011-08-07 03:50:42 --> Final output sent to browser
DEBUG - 2011-08-07 03:50:42 --> Total execution time: 0.5439
DEBUG - 2011-08-07 04:46:02 --> Config Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Hooks Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Utf8 Class Initialized
DEBUG - 2011-08-07 04:46:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 04:46:02 --> URI Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Router Class Initialized
DEBUG - 2011-08-07 04:46:02 --> No URI present. Default controller set.
DEBUG - 2011-08-07 04:46:02 --> Output Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Input Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 04:46:02 --> Language Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Loader Class Initialized
DEBUG - 2011-08-07 04:46:02 --> Controller Class Initialized
DEBUG - 2011-08-07 04:46:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-07 04:46:02 --> Helper loaded: url_helper
DEBUG - 2011-08-07 04:46:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 04:46:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 04:46:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 04:46:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 04:46:02 --> Final output sent to browser
DEBUG - 2011-08-07 04:46:02 --> Total execution time: 0.1431
DEBUG - 2011-08-07 05:01:15 --> Config Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Hooks Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Utf8 Class Initialized
DEBUG - 2011-08-07 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 05:01:15 --> URI Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Router Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Output Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Input Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 05:01:15 --> Language Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Loader Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Controller Class Initialized
ERROR - 2011-08-07 05:01:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 05:01:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 05:01:15 --> Model Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Model Class Initialized
DEBUG - 2011-08-07 05:01:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 05:01:15 --> Database Driver Class Initialized
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 05:01:15 --> Helper loaded: url_helper
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 05:01:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 05:01:15 --> Final output sent to browser
DEBUG - 2011-08-07 05:01:15 --> Total execution time: 0.2212
DEBUG - 2011-08-07 06:13:57 --> Config Class Initialized
DEBUG - 2011-08-07 06:13:57 --> Hooks Class Initialized
DEBUG - 2011-08-07 06:13:57 --> Utf8 Class Initialized
DEBUG - 2011-08-07 06:13:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 06:13:57 --> URI Class Initialized
DEBUG - 2011-08-07 06:13:57 --> Router Class Initialized
ERROR - 2011-08-07 06:13:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 06:45:55 --> Config Class Initialized
DEBUG - 2011-08-07 06:45:55 --> Hooks Class Initialized
DEBUG - 2011-08-07 06:45:55 --> Utf8 Class Initialized
DEBUG - 2011-08-07 06:45:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 06:45:55 --> URI Class Initialized
DEBUG - 2011-08-07 06:45:55 --> Router Class Initialized
ERROR - 2011-08-07 06:45:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 07:58:31 --> Config Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Hooks Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Utf8 Class Initialized
DEBUG - 2011-08-07 07:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 07:58:31 --> URI Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Router Class Initialized
ERROR - 2011-08-07 07:58:31 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 07:58:31 --> Config Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Hooks Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Utf8 Class Initialized
DEBUG - 2011-08-07 07:58:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 07:58:31 --> URI Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Router Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Output Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Input Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 07:58:31 --> Language Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Loader Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Controller Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Model Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Model Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Model Class Initialized
DEBUG - 2011-08-07 07:58:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 07:58:31 --> Database Driver Class Initialized
DEBUG - 2011-08-07 07:58:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 07:58:32 --> Helper loaded: url_helper
DEBUG - 2011-08-07 07:58:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 07:58:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 07:58:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 07:58:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 07:58:32 --> Final output sent to browser
DEBUG - 2011-08-07 07:58:32 --> Total execution time: 0.8124
DEBUG - 2011-08-07 09:23:38 --> Config Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 09:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 09:23:38 --> URI Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Router Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Output Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Input Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 09:23:38 --> Language Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Loader Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Controller Class Initialized
ERROR - 2011-08-07 09:23:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 09:23:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 09:23:38 --> Model Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Model Class Initialized
DEBUG - 2011-08-07 09:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 09:23:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 09:23:38 --> Helper loaded: url_helper
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 09:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 09:23:38 --> Final output sent to browser
DEBUG - 2011-08-07 09:23:38 --> Total execution time: 0.1278
DEBUG - 2011-08-07 09:23:47 --> Config Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Hooks Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Utf8 Class Initialized
DEBUG - 2011-08-07 09:23:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 09:23:47 --> URI Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Router Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Output Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Input Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 09:23:47 --> Language Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Loader Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Controller Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Model Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Model Class Initialized
DEBUG - 2011-08-07 09:23:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 09:23:47 --> Database Driver Class Initialized
DEBUG - 2011-08-07 09:23:48 --> Final output sent to browser
DEBUG - 2011-08-07 09:23:48 --> Total execution time: 0.5878
DEBUG - 2011-08-07 09:24:15 --> Config Class Initialized
DEBUG - 2011-08-07 09:24:15 --> Hooks Class Initialized
DEBUG - 2011-08-07 09:24:15 --> Utf8 Class Initialized
DEBUG - 2011-08-07 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 09:24:15 --> URI Class Initialized
DEBUG - 2011-08-07 09:24:15 --> Router Class Initialized
ERROR - 2011-08-07 09:24:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 10:08:23 --> Config Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:08:23 --> URI Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Router Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Output Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Input Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:08:23 --> Language Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Loader Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Controller Class Initialized
ERROR - 2011-08-07 10:08:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:08:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:08:23 --> Model Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Model Class Initialized
DEBUG - 2011-08-07 10:08:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:08:23 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:08:23 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:08:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:08:23 --> Final output sent to browser
DEBUG - 2011-08-07 10:08:23 --> Total execution time: 0.0516
DEBUG - 2011-08-07 10:46:53 --> Config Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:46:53 --> URI Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Router Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Output Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Input Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:46:53 --> Language Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Loader Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Controller Class Initialized
ERROR - 2011-08-07 10:46:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:46:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:46:53 --> Model Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Model Class Initialized
DEBUG - 2011-08-07 10:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:46:53 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:46:53 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:46:53 --> Final output sent to browser
DEBUG - 2011-08-07 10:46:53 --> Total execution time: 0.0427
DEBUG - 2011-08-07 10:46:55 --> Config Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:46:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:46:55 --> URI Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Router Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Output Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Input Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:46:55 --> Language Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Loader Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Controller Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Model Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Model Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Model Class Initialized
DEBUG - 2011-08-07 10:46:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:46:56 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:46:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 10:46:56 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:46:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:46:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:46:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:46:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:46:56 --> Final output sent to browser
DEBUG - 2011-08-07 10:46:56 --> Total execution time: 0.2857
DEBUG - 2011-08-07 10:58:36 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:36 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Router Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Output Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Input Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:58:36 --> Language Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Loader Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Controller Class Initialized
ERROR - 2011-08-07 10:58:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:58:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:58:36 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:58:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:58:36 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:58:36 --> Final output sent to browser
DEBUG - 2011-08-07 10:58:36 --> Total execution time: 0.0288
DEBUG - 2011-08-07 10:58:37 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:37 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Router Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Output Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Input Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:58:37 --> Language Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Loader Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Controller Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:58:37 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:58:37 --> Final output sent to browser
DEBUG - 2011-08-07 10:58:37 --> Total execution time: 0.5995
DEBUG - 2011-08-07 10:58:39 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:39 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:39 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:39 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:39 --> Router Class Initialized
ERROR - 2011-08-07 10:58:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 10:58:54 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:54 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Router Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Output Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Input Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:58:54 --> Language Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Loader Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Controller Class Initialized
ERROR - 2011-08-07 10:58:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:58:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:58:54 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:58:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:58:54 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:58:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:58:54 --> Final output sent to browser
DEBUG - 2011-08-07 10:58:54 --> Total execution time: 0.0274
DEBUG - 2011-08-07 10:58:55 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:55 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Router Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Output Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Input Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:58:55 --> Language Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Loader Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Controller Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Model Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:58:55 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:58:55 --> Final output sent to browser
DEBUG - 2011-08-07 10:58:55 --> Total execution time: 0.5017
DEBUG - 2011-08-07 10:58:57 --> Config Class Initialized
DEBUG - 2011-08-07 10:58:57 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:58:57 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:58:57 --> URI Class Initialized
DEBUG - 2011-08-07 10:58:57 --> Router Class Initialized
ERROR - 2011-08-07 10:58:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 10:59:20 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:20 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:20 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Controller Class Initialized
ERROR - 2011-08-07 10:59:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:59:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:20 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:20 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:20 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:59:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:59:20 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:20 --> Total execution time: 0.0589
DEBUG - 2011-08-07 10:59:20 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:20 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:20 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Controller Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:20 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:21 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:21 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Controller Class Initialized
ERROR - 2011-08-07 10:59:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:59:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:21 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:21 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:21 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:59:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:59:21 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:21 --> Total execution time: 0.0334
DEBUG - 2011-08-07 10:59:21 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:21 --> Total execution time: 0.5523
DEBUG - 2011-08-07 10:59:22 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:22 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:22 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:22 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:22 --> Router Class Initialized
ERROR - 2011-08-07 10:59:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 10:59:28 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:28 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:28 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Controller Class Initialized
ERROR - 2011-08-07 10:59:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:59:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:28 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:28 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:28 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:59:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:59:28 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:28 --> Total execution time: 0.0447
DEBUG - 2011-08-07 10:59:29 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:29 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:29 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Controller Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:29 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:29 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Router Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Output Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Input Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 10:59:29 --> Language Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Loader Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Controller Class Initialized
ERROR - 2011-08-07 10:59:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 10:59:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:29 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Model Class Initialized
DEBUG - 2011-08-07 10:59:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 10:59:29 --> Database Driver Class Initialized
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 10:59:29 --> Helper loaded: url_helper
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 10:59:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 10:59:29 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:29 --> Total execution time: 0.0300
DEBUG - 2011-08-07 10:59:30 --> Final output sent to browser
DEBUG - 2011-08-07 10:59:30 --> Total execution time: 0.6999
DEBUG - 2011-08-07 10:59:32 --> Config Class Initialized
DEBUG - 2011-08-07 10:59:32 --> Hooks Class Initialized
DEBUG - 2011-08-07 10:59:32 --> Utf8 Class Initialized
DEBUG - 2011-08-07 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 10:59:32 --> URI Class Initialized
DEBUG - 2011-08-07 10:59:32 --> Router Class Initialized
ERROR - 2011-08-07 10:59:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 11:08:39 --> Config Class Initialized
DEBUG - 2011-08-07 11:08:39 --> Hooks Class Initialized
DEBUG - 2011-08-07 11:08:39 --> Utf8 Class Initialized
DEBUG - 2011-08-07 11:08:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 11:08:39 --> URI Class Initialized
DEBUG - 2011-08-07 11:08:39 --> Router Class Initialized
ERROR - 2011-08-07 11:08:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 11:31:07 --> Config Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Hooks Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Utf8 Class Initialized
DEBUG - 2011-08-07 11:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 11:31:07 --> URI Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Router Class Initialized
ERROR - 2011-08-07 11:31:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 11:31:07 --> Config Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Hooks Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Utf8 Class Initialized
DEBUG - 2011-08-07 11:31:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 11:31:07 --> URI Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Router Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Output Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Input Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 11:31:07 --> Language Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Loader Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Controller Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Model Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Model Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Model Class Initialized
DEBUG - 2011-08-07 11:31:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 11:31:07 --> Database Driver Class Initialized
DEBUG - 2011-08-07 11:31:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 11:31:08 --> Helper loaded: url_helper
DEBUG - 2011-08-07 11:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 11:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 11:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 11:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 11:31:08 --> Final output sent to browser
DEBUG - 2011-08-07 11:31:08 --> Total execution time: 0.7719
DEBUG - 2011-08-07 12:23:37 --> Config Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:23:37 --> URI Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Router Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Output Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Input Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 12:23:37 --> Language Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Loader Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Controller Class Initialized
ERROR - 2011-08-07 12:23:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 12:23:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:23:37 --> Model Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Model Class Initialized
DEBUG - 2011-08-07 12:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 12:23:37 --> Database Driver Class Initialized
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:23:37 --> Helper loaded: url_helper
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 12:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 12:23:37 --> Final output sent to browser
DEBUG - 2011-08-07 12:23:37 --> Total execution time: 0.0842
DEBUG - 2011-08-07 12:23:38 --> Config Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:23:38 --> URI Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Router Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Output Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Input Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 12:23:38 --> Language Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Loader Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Controller Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Model Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Model Class Initialized
DEBUG - 2011-08-07 12:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 12:23:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 12:23:39 --> Final output sent to browser
DEBUG - 2011-08-07 12:23:39 --> Total execution time: 0.6395
DEBUG - 2011-08-07 12:23:40 --> Config Class Initialized
DEBUG - 2011-08-07 12:23:40 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:23:40 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:23:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:23:40 --> URI Class Initialized
DEBUG - 2011-08-07 12:23:40 --> Router Class Initialized
ERROR - 2011-08-07 12:23:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 12:23:41 --> Config Class Initialized
DEBUG - 2011-08-07 12:23:41 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:23:41 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:23:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:23:41 --> URI Class Initialized
DEBUG - 2011-08-07 12:23:41 --> Router Class Initialized
ERROR - 2011-08-07 12:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 12:24:20 --> Config Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:24:20 --> URI Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Router Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Output Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Input Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 12:24:20 --> Language Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Loader Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Controller Class Initialized
ERROR - 2011-08-07 12:24:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 12:24:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:24:20 --> Model Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Model Class Initialized
DEBUG - 2011-08-07 12:24:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 12:24:20 --> Database Driver Class Initialized
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:24:20 --> Helper loaded: url_helper
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 12:24:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 12:24:20 --> Final output sent to browser
DEBUG - 2011-08-07 12:24:20 --> Total execution time: 0.0688
DEBUG - 2011-08-07 12:24:28 --> Config Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Hooks Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Utf8 Class Initialized
DEBUG - 2011-08-07 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 12:24:28 --> URI Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Router Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Output Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Input Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 12:24:28 --> Language Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Loader Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Controller Class Initialized
ERROR - 2011-08-07 12:24:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 12:24:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:24:28 --> Model Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Model Class Initialized
DEBUG - 2011-08-07 12:24:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 12:24:28 --> Database Driver Class Initialized
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 12:24:28 --> Helper loaded: url_helper
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 12:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 12:24:28 --> Final output sent to browser
DEBUG - 2011-08-07 12:24:28 --> Total execution time: 0.0275
DEBUG - 2011-08-07 13:03:44 --> Config Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 13:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 13:03:44 --> URI Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Router Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Output Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Input Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 13:03:44 --> Language Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Loader Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Controller Class Initialized
ERROR - 2011-08-07 13:03:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 13:03:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 13:03:44 --> Model Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Model Class Initialized
DEBUG - 2011-08-07 13:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 13:03:44 --> Database Driver Class Initialized
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 13:03:44 --> Helper loaded: url_helper
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 13:03:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 13:03:44 --> Final output sent to browser
DEBUG - 2011-08-07 13:03:44 --> Total execution time: 0.0603
DEBUG - 2011-08-07 13:03:46 --> Config Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 13:03:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 13:03:46 --> URI Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Router Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Output Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Input Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 13:03:46 --> Language Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Loader Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Controller Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Model Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Model Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 13:03:46 --> Database Driver Class Initialized
DEBUG - 2011-08-07 13:03:46 --> Final output sent to browser
DEBUG - 2011-08-07 13:03:46 --> Total execution time: 0.6398
DEBUG - 2011-08-07 13:03:48 --> Config Class Initialized
DEBUG - 2011-08-07 13:03:48 --> Hooks Class Initialized
DEBUG - 2011-08-07 13:03:48 --> Utf8 Class Initialized
DEBUG - 2011-08-07 13:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 13:03:48 --> URI Class Initialized
DEBUG - 2011-08-07 13:03:48 --> Router Class Initialized
ERROR - 2011-08-07 13:03:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 13:38:07 --> Config Class Initialized
DEBUG - 2011-08-07 13:38:07 --> Hooks Class Initialized
DEBUG - 2011-08-07 13:38:07 --> Utf8 Class Initialized
DEBUG - 2011-08-07 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 13:38:07 --> URI Class Initialized
DEBUG - 2011-08-07 13:38:07 --> Router Class Initialized
ERROR - 2011-08-07 13:38:07 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 14:28:50 --> Config Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Hooks Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Utf8 Class Initialized
DEBUG - 2011-08-07 14:28:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 14:28:50 --> URI Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Router Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Output Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Input Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 14:28:50 --> Language Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Loader Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Controller Class Initialized
ERROR - 2011-08-07 14:28:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 14:28:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 14:28:50 --> Model Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Model Class Initialized
DEBUG - 2011-08-07 14:28:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 14:28:50 --> Database Driver Class Initialized
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 14:28:50 --> Helper loaded: url_helper
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 14:28:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 14:28:50 --> Final output sent to browser
DEBUG - 2011-08-07 14:28:50 --> Total execution time: 0.0475
DEBUG - 2011-08-07 14:28:51 --> Config Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Hooks Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Utf8 Class Initialized
DEBUG - 2011-08-07 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 14:28:51 --> URI Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Router Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Output Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Input Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 14:28:51 --> Language Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Loader Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Controller Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Model Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Model Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 14:28:51 --> Database Driver Class Initialized
DEBUG - 2011-08-07 14:28:51 --> Final output sent to browser
DEBUG - 2011-08-07 14:28:51 --> Total execution time: 0.5889
DEBUG - 2011-08-07 14:28:53 --> Config Class Initialized
DEBUG - 2011-08-07 14:28:53 --> Hooks Class Initialized
DEBUG - 2011-08-07 14:28:53 --> Utf8 Class Initialized
DEBUG - 2011-08-07 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 14:28:53 --> URI Class Initialized
DEBUG - 2011-08-07 14:28:53 --> Router Class Initialized
ERROR - 2011-08-07 14:28:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:30:38 --> Config Class Initialized
DEBUG - 2011-08-07 15:30:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:30:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:30:38 --> URI Class Initialized
DEBUG - 2011-08-07 15:30:38 --> Router Class Initialized
ERROR - 2011-08-07 15:30:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 15:35:46 --> Config Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:35:46 --> URI Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Router Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Output Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Input Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:35:46 --> Language Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Loader Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Controller Class Initialized
ERROR - 2011-08-07 15:35:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:35:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:35:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:35:46 --> Config Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:35:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:35:46 --> URI Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Router Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Output Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Input Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:35:46 --> Language Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Loader Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Controller Class Initialized
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/snakes/main.php
ERROR - 2011-08-07 15:35:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:35:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:35:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:35:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:46 --> Final output sent to browser
DEBUG - 2011-08-07 15:35:46 --> Total execution time: 0.0840
DEBUG - 2011-08-07 15:35:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:35:46 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:35:46 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:35:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:35:46 --> Final output sent to browser
DEBUG - 2011-08-07 15:35:46 --> Total execution time: 0.0599
DEBUG - 2011-08-07 15:35:49 --> Config Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:35:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:35:49 --> URI Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Router Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Output Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Input Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:35:49 --> Language Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Loader Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Controller Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Model Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:35:49 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:35:49 --> Final output sent to browser
DEBUG - 2011-08-07 15:35:49 --> Total execution time: 0.5663
DEBUG - 2011-08-07 15:35:53 --> Config Class Initialized
DEBUG - 2011-08-07 15:35:53 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:35:53 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:35:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:35:53 --> URI Class Initialized
DEBUG - 2011-08-07 15:35:53 --> Router Class Initialized
ERROR - 2011-08-07 15:35:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:36:11 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:11 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:11 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Controller Class Initialized
ERROR - 2011-08-07 15:36:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:36:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:11 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:11 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:11 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:36:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:36:11 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:11 --> Total execution time: 0.0545
DEBUG - 2011-08-07 15:36:13 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:13 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:13 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Controller Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:13 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:13 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:13 --> Total execution time: 0.4579
DEBUG - 2011-08-07 15:36:14 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:14 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:14 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:14 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:14 --> Router Class Initialized
ERROR - 2011-08-07 15:36:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:36:38 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:38 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:38 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Controller Class Initialized
ERROR - 2011-08-07 15:36:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:36:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:38 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:38 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:36:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:36:38 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:38 --> Total execution time: 0.0285
DEBUG - 2011-08-07 15:36:40 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:40 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:40 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Controller Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:40 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:41 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:41 --> Total execution time: 0.6464
DEBUG - 2011-08-07 15:36:44 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:44 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:44 --> Router Class Initialized
ERROR - 2011-08-07 15:36:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:36:45 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:45 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:45 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Controller Class Initialized
ERROR - 2011-08-07 15:36:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:36:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:45 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:45 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:36:45 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:36:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:36:45 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:45 --> Total execution time: 0.0272
DEBUG - 2011-08-07 15:36:46 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:46 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Router Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Output Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Input Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:36:46 --> Language Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Loader Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Controller Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Model Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:36:46 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:36:46 --> Final output sent to browser
DEBUG - 2011-08-07 15:36:46 --> Total execution time: 0.5581
DEBUG - 2011-08-07 15:36:47 --> Config Class Initialized
DEBUG - 2011-08-07 15:36:47 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:36:47 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:36:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:36:47 --> URI Class Initialized
DEBUG - 2011-08-07 15:36:47 --> Router Class Initialized
ERROR - 2011-08-07 15:36:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:37:12 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:12 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:12 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Controller Class Initialized
ERROR - 2011-08-07 15:37:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:37:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:12 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:12 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:12 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:37:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:37:12 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:12 --> Total execution time: 0.0287
DEBUG - 2011-08-07 15:37:13 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:13 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:13 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Controller Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:13 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:13 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:13 --> Total execution time: 0.4931
DEBUG - 2011-08-07 15:37:14 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:14 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:14 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:14 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:14 --> Router Class Initialized
ERROR - 2011-08-07 15:37:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:37:19 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:19 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:19 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Controller Class Initialized
ERROR - 2011-08-07 15:37:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:37:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:19 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:19 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:19 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:37:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:37:19 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:19 --> Total execution time: 0.0275
DEBUG - 2011-08-07 15:37:20 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:20 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:20 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Controller Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:21 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:21 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:21 --> Total execution time: 0.5420
DEBUG - 2011-08-07 15:37:37 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:37 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:37 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Controller Class Initialized
ERROR - 2011-08-07 15:37:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 15:37:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:37 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:37 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 15:37:37 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:37:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:37:37 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:37 --> Total execution time: 0.0294
DEBUG - 2011-08-07 15:37:37 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:37 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Router Class Initialized
ERROR - 2011-08-07 15:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:37:37 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:37 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Router Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Output Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Input Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:37:37 --> Language Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Loader Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Controller Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Model Class Initialized
DEBUG - 2011-08-07 15:37:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:37:38 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:37:38 --> Final output sent to browser
DEBUG - 2011-08-07 15:37:38 --> Total execution time: 0.4671
DEBUG - 2011-08-07 15:37:43 --> Config Class Initialized
DEBUG - 2011-08-07 15:37:43 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:37:43 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:37:43 --> URI Class Initialized
DEBUG - 2011-08-07 15:37:43 --> Router Class Initialized
ERROR - 2011-08-07 15:37:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:38:02 --> Config Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:38:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:38:02 --> URI Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Router Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Output Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Input Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:38:02 --> Language Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Loader Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Controller Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:38:02 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:38:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 15:38:02 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:38:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:38:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:38:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:38:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:38:02 --> Final output sent to browser
DEBUG - 2011-08-07 15:38:02 --> Total execution time: 0.4441
DEBUG - 2011-08-07 15:38:07 --> Config Class Initialized
DEBUG - 2011-08-07 15:38:07 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:38:07 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:38:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:38:07 --> URI Class Initialized
DEBUG - 2011-08-07 15:38:07 --> Router Class Initialized
ERROR - 2011-08-07 15:38:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 15:38:09 --> Config Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:38:09 --> URI Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Router Class Initialized
ERROR - 2011-08-07 15:38:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 15:38:09 --> Config Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 15:38:09 --> URI Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Router Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Output Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Input Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 15:38:09 --> Language Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Loader Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Controller Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Model Class Initialized
DEBUG - 2011-08-07 15:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 15:38:09 --> Database Driver Class Initialized
DEBUG - 2011-08-07 15:38:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-07 15:38:09 --> Helper loaded: url_helper
DEBUG - 2011-08-07 15:38:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 15:38:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 15:38:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 15:38:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 15:38:09 --> Final output sent to browser
DEBUG - 2011-08-07 15:38:09 --> Total execution time: 0.0434
DEBUG - 2011-08-07 16:00:11 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:11 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:11 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:11 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:11 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:11 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:11 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:11 --> Total execution time: 0.0508
DEBUG - 2011-08-07 16:00:13 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:13 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:13 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Controller Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:13 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:13 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:13 --> Total execution time: 0.4797
DEBUG - 2011-08-07 16:00:15 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:15 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:15 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:15 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:15 --> Router Class Initialized
ERROR - 2011-08-07 16:00:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:00:35 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:35 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:35 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:35 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:35 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:35 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:35 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:35 --> Total execution time: 0.0352
DEBUG - 2011-08-07 16:00:36 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:36 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:36 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:36 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:36 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:36 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:36 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:36 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Total execution time: 0.0309
DEBUG - 2011-08-07 16:00:36 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:36 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Controller Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:36 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:36 --> Total execution time: 0.4956
DEBUG - 2011-08-07 16:00:37 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:37 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:37 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:37 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:37 --> Router Class Initialized
ERROR - 2011-08-07 16:00:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:00:43 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:43 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:43 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:43 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:43 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:43 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:43 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:43 --> Total execution time: 0.0287
DEBUG - 2011-08-07 16:00:44 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:44 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:44 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Controller Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:44 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:44 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:44 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:44 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:44 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:44 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:44 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:44 --> Total execution time: 0.0382
DEBUG - 2011-08-07 16:00:45 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:45 --> Total execution time: 1.0928
DEBUG - 2011-08-07 16:00:46 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:46 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:46 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:46 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:46 --> Router Class Initialized
ERROR - 2011-08-07 16:00:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:00:58 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:58 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:58 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Controller Class Initialized
ERROR - 2011-08-07 16:00:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:00:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:58 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:58 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:00:58 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:00:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:00:58 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:58 --> Total execution time: 0.0308
DEBUG - 2011-08-07 16:00:59 --> Config Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:00:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:00:59 --> URI Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Router Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Output Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Input Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:00:59 --> Language Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Loader Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Controller Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Model Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:00:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:00:59 --> Final output sent to browser
DEBUG - 2011-08-07 16:00:59 --> Total execution time: 0.5262
DEBUG - 2011-08-07 16:01:00 --> Config Class Initialized
DEBUG - 2011-08-07 16:01:00 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:01:00 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:01:00 --> URI Class Initialized
DEBUG - 2011-08-07 16:01:00 --> Router Class Initialized
ERROR - 2011-08-07 16:01:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:03:22 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:22 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:22 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Controller Class Initialized
ERROR - 2011-08-07 16:03:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:22 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:22 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:22 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:03:22 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:22 --> Total execution time: 0.0291
DEBUG - 2011-08-07 16:03:23 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:23 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:23 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Controller Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:23 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:23 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:23 --> Total execution time: 0.4450
DEBUG - 2011-08-07 16:03:25 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:25 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Router Class Initialized
ERROR - 2011-08-07 16:03:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:03:25 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:25 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:25 --> Router Class Initialized
ERROR - 2011-08-07 16:03:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:03:41 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:41 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:41 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Controller Class Initialized
ERROR - 2011-08-07 16:03:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:03:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:41 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:41 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:41 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:03:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:03:41 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:41 --> Total execution time: 0.0318
DEBUG - 2011-08-07 16:03:42 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:42 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:42 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Controller Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:42 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:43 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:43 --> Total execution time: 0.5096
DEBUG - 2011-08-07 16:03:50 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:50 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:50 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Controller Class Initialized
ERROR - 2011-08-07 16:03:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:03:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:50 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:50 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:50 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:03:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:03:50 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:50 --> Total execution time: 0.0274
DEBUG - 2011-08-07 16:03:51 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:51 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:51 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Controller Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:51 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:51 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:51 --> Total execution time: 0.4529
DEBUG - 2011-08-07 16:03:56 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:56 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:56 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Controller Class Initialized
ERROR - 2011-08-07 16:03:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:03:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:56 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:03:56 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:03:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:03:56 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:56 --> Total execution time: 0.0270
DEBUG - 2011-08-07 16:03:56 --> Config Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:03:56 --> URI Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Router Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Output Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Input Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:03:56 --> Language Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Loader Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Controller Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:03:56 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:03:57 --> Final output sent to browser
DEBUG - 2011-08-07 16:03:57 --> Total execution time: 0.5801
DEBUG - 2011-08-07 16:34:56 --> Config Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:34:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:34:56 --> URI Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Router Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Output Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Input Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:34:56 --> Language Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Loader Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Controller Class Initialized
ERROR - 2011-08-07 16:34:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:34:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:34:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:34:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:34:56 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:34:56 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:34:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:34:56 --> Final output sent to browser
DEBUG - 2011-08-07 16:34:56 --> Total execution time: 0.0929
DEBUG - 2011-08-07 16:35:02 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:02 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Router Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Output Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Input Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:35:02 --> Language Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Loader Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Controller Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:35:02 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:35:03 --> Final output sent to browser
DEBUG - 2011-08-07 16:35:03 --> Total execution time: 0.7963
DEBUG - 2011-08-07 16:35:09 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:09 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:09 --> Router Class Initialized
ERROR - 2011-08-07 16:35:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:35:32 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:32 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Router Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Output Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Input Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:35:32 --> Language Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Loader Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Controller Class Initialized
ERROR - 2011-08-07 16:35:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:35:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:35:32 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:35:32 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:35:32 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:35:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:35:32 --> Final output sent to browser
DEBUG - 2011-08-07 16:35:32 --> Total execution time: 0.0269
DEBUG - 2011-08-07 16:35:33 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:33 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Router Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Output Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Input Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:35:33 --> Language Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Loader Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Controller Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:35:33 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:35:35 --> Final output sent to browser
DEBUG - 2011-08-07 16:35:35 --> Total execution time: 1.4625
DEBUG - 2011-08-07 16:35:38 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:38 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:38 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:38 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:38 --> Router Class Initialized
ERROR - 2011-08-07 16:35:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:35:54 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:54 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Router Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Output Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Input Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:35:54 --> Language Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Loader Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Controller Class Initialized
ERROR - 2011-08-07 16:35:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:35:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:35:54 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:35:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:35:54 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:35:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:35:54 --> Final output sent to browser
DEBUG - 2011-08-07 16:35:54 --> Total execution time: 0.1128
DEBUG - 2011-08-07 16:35:56 --> Config Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:35:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:35:56 --> URI Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Router Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Output Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Input Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:35:56 --> Language Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Loader Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Controller Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Model Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:35:56 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:35:56 --> Final output sent to browser
DEBUG - 2011-08-07 16:35:56 --> Total execution time: 0.4640
DEBUG - 2011-08-07 16:36:00 --> Config Class Initialized
DEBUG - 2011-08-07 16:36:00 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:36:00 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:36:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:36:00 --> URI Class Initialized
DEBUG - 2011-08-07 16:36:00 --> Router Class Initialized
ERROR - 2011-08-07 16:36:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 16:36:07 --> Config Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:36:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:36:07 --> URI Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Router Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Output Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Input Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:36:07 --> Language Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Loader Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Controller Class Initialized
ERROR - 2011-08-07 16:36:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:36:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:36:07 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:36:07 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:36:07 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:36:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:36:07 --> Final output sent to browser
DEBUG - 2011-08-07 16:36:07 --> Total execution time: 0.0375
DEBUG - 2011-08-07 16:36:09 --> Config Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:36:09 --> URI Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Router Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Output Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Input Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:36:09 --> Language Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Loader Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Controller Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:36:09 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Config Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:36:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:36:09 --> URI Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Router Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Output Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Input Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 16:36:09 --> Language Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Loader Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Controller Class Initialized
ERROR - 2011-08-07 16:36:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 16:36:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:36:09 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Model Class Initialized
DEBUG - 2011-08-07 16:36:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 16:36:09 --> Database Driver Class Initialized
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 16:36:09 --> Helper loaded: url_helper
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 16:36:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 16:36:09 --> Final output sent to browser
DEBUG - 2011-08-07 16:36:09 --> Total execution time: 0.0285
DEBUG - 2011-08-07 16:36:10 --> Final output sent to browser
DEBUG - 2011-08-07 16:36:10 --> Total execution time: 0.5239
DEBUG - 2011-08-07 16:36:13 --> Config Class Initialized
DEBUG - 2011-08-07 16:36:13 --> Hooks Class Initialized
DEBUG - 2011-08-07 16:36:13 --> Utf8 Class Initialized
DEBUG - 2011-08-07 16:36:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 16:36:13 --> URI Class Initialized
DEBUG - 2011-08-07 16:36:13 --> Router Class Initialized
ERROR - 2011-08-07 16:36:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 18:06:27 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:27 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:27 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Controller Class Initialized
ERROR - 2011-08-07 18:06:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 18:06:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:27 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:27 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:27 --> Helper loaded: url_helper
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 18:06:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 18:06:27 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:27 --> Total execution time: 0.0678
DEBUG - 2011-08-07 18:06:28 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:28 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:28 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Controller Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:28 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:29 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:29 --> Total execution time: 0.7159
DEBUG - 2011-08-07 18:06:30 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:30 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:30 --> Router Class Initialized
ERROR - 2011-08-07 18:06:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 18:06:54 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:54 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:54 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Controller Class Initialized
ERROR - 2011-08-07 18:06:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 18:06:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 18:06:54 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:54 --> Total execution time: 0.0283
DEBUG - 2011-08-07 18:06:54 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:54 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:54 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Controller Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:54 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:54 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Controller Class Initialized
ERROR - 2011-08-07 18:06:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 18:06:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:54 --> Helper loaded: url_helper
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 18:06:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 18:06:54 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:54 --> Total execution time: 0.0265
DEBUG - 2011-08-07 18:06:55 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:55 --> Total execution time: 0.5126
DEBUG - 2011-08-07 18:06:56 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:56 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:56 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:56 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:56 --> Router Class Initialized
ERROR - 2011-08-07 18:06:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 18:06:59 --> Config Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:06:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:06:59 --> URI Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Router Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Output Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Input Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:06:59 --> Language Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Loader Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Controller Class Initialized
ERROR - 2011-08-07 18:06:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 18:06:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:59 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Model Class Initialized
DEBUG - 2011-08-07 18:06:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:06:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 18:06:59 --> Helper loaded: url_helper
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 18:06:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 18:06:59 --> Final output sent to browser
DEBUG - 2011-08-07 18:06:59 --> Total execution time: 0.0289
DEBUG - 2011-08-07 18:07:00 --> Config Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:07:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:07:00 --> URI Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Router Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Output Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Input Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 18:07:00 --> Language Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Loader Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Controller Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Model Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Model Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 18:07:00 --> Database Driver Class Initialized
DEBUG - 2011-08-07 18:07:00 --> Final output sent to browser
DEBUG - 2011-08-07 18:07:00 --> Total execution time: 0.4499
DEBUG - 2011-08-07 18:07:01 --> Config Class Initialized
DEBUG - 2011-08-07 18:07:01 --> Hooks Class Initialized
DEBUG - 2011-08-07 18:07:01 --> Utf8 Class Initialized
DEBUG - 2011-08-07 18:07:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 18:07:01 --> URI Class Initialized
DEBUG - 2011-08-07 18:07:01 --> Router Class Initialized
ERROR - 2011-08-07 18:07:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 19:48:30 --> Config Class Initialized
DEBUG - 2011-08-07 19:48:30 --> Hooks Class Initialized
DEBUG - 2011-08-07 19:48:30 --> Utf8 Class Initialized
DEBUG - 2011-08-07 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 19:48:30 --> URI Class Initialized
DEBUG - 2011-08-07 19:48:30 --> Router Class Initialized
ERROR - 2011-08-07 19:48:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 20:31:19 --> Config Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Hooks Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Utf8 Class Initialized
DEBUG - 2011-08-07 20:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 20:31:19 --> URI Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Router Class Initialized
ERROR - 2011-08-07 20:31:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 20:31:19 --> Config Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Hooks Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Utf8 Class Initialized
DEBUG - 2011-08-07 20:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 20:31:19 --> URI Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Router Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Output Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Input Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 20:31:19 --> Language Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Loader Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Controller Class Initialized
ERROR - 2011-08-07 20:31:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 20:31:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 20:31:19 --> Model Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Model Class Initialized
DEBUG - 2011-08-07 20:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 20:31:19 --> Database Driver Class Initialized
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 20:31:19 --> Helper loaded: url_helper
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 20:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 20:31:19 --> Final output sent to browser
DEBUG - 2011-08-07 20:31:19 --> Total execution time: 0.0663
DEBUG - 2011-08-07 20:41:34 --> Config Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Hooks Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Utf8 Class Initialized
DEBUG - 2011-08-07 20:41:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 20:41:34 --> URI Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Router Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Output Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Input Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 20:41:34 --> Language Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Loader Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Controller Class Initialized
ERROR - 2011-08-07 20:41:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 20:41:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 20:41:34 --> Model Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Model Class Initialized
DEBUG - 2011-08-07 20:41:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 20:41:34 --> Database Driver Class Initialized
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 20:41:34 --> Helper loaded: url_helper
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 20:41:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 20:41:34 --> Final output sent to browser
DEBUG - 2011-08-07 20:41:34 --> Total execution time: 0.0306
DEBUG - 2011-08-07 20:41:36 --> Config Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Hooks Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Utf8 Class Initialized
DEBUG - 2011-08-07 20:41:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 20:41:36 --> URI Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Router Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Output Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Input Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 20:41:36 --> Language Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Loader Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Controller Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Model Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Model Class Initialized
DEBUG - 2011-08-07 20:41:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 20:41:36 --> Database Driver Class Initialized
DEBUG - 2011-08-07 20:41:37 --> Final output sent to browser
DEBUG - 2011-08-07 20:41:37 --> Total execution time: 0.5631
DEBUG - 2011-08-07 20:41:39 --> Config Class Initialized
DEBUG - 2011-08-07 20:41:39 --> Hooks Class Initialized
DEBUG - 2011-08-07 20:41:39 --> Utf8 Class Initialized
DEBUG - 2011-08-07 20:41:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 20:41:39 --> URI Class Initialized
DEBUG - 2011-08-07 20:41:39 --> Router Class Initialized
ERROR - 2011-08-07 20:41:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 22:02:29 --> Config Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:02:29 --> URI Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Router Class Initialized
ERROR - 2011-08-07 22:02:29 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 22:02:29 --> Config Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:02:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:02:29 --> URI Class Initialized
DEBUG - 2011-08-07 22:02:29 --> Router Class Initialized
DEBUG - 2011-08-07 22:02:30 --> No URI present. Default controller set.
DEBUG - 2011-08-07 22:02:30 --> Output Class Initialized
DEBUG - 2011-08-07 22:02:30 --> Input Class Initialized
DEBUG - 2011-08-07 22:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:02:30 --> Language Class Initialized
DEBUG - 2011-08-07 22:02:30 --> Loader Class Initialized
DEBUG - 2011-08-07 22:02:30 --> Controller Class Initialized
DEBUG - 2011-08-07 22:02:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-07 22:02:30 --> Helper loaded: url_helper
DEBUG - 2011-08-07 22:02:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 22:02:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 22:02:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 22:02:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 22:02:30 --> Final output sent to browser
DEBUG - 2011-08-07 22:02:30 --> Total execution time: 1.0547
DEBUG - 2011-08-07 22:36:53 --> Config Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:36:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:36:53 --> URI Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Router Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Output Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Input Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:36:53 --> Language Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Loader Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Controller Class Initialized
ERROR - 2011-08-07 22:36:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 22:36:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:36:53 --> Model Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Model Class Initialized
DEBUG - 2011-08-07 22:36:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:36:53 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:36:53 --> Helper loaded: url_helper
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 22:36:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 22:36:53 --> Final output sent to browser
DEBUG - 2011-08-07 22:36:53 --> Total execution time: 0.0288
DEBUG - 2011-08-07 22:36:54 --> Config Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:36:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:36:54 --> URI Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Router Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Output Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Input Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:36:54 --> Language Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Loader Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Controller Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Model Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Model Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:36:54 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:36:54 --> Final output sent to browser
DEBUG - 2011-08-07 22:36:54 --> Total execution time: 0.4872
DEBUG - 2011-08-07 22:37:00 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:00 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Router Class Initialized
ERROR - 2011-08-07 22:37:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 22:37:00 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:00 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:00 --> Router Class Initialized
ERROR - 2011-08-07 22:37:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-07 22:37:20 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:20 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:20 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Controller Class Initialized
ERROR - 2011-08-07 22:37:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 22:37:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:20 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:20 --> Helper loaded: url_helper
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 22:37:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 22:37:20 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:20 --> Total execution time: 0.0451
DEBUG - 2011-08-07 22:37:20 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:20 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:20 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Controller Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:20 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:21 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:21 --> Total execution time: 0.6009
DEBUG - 2011-08-07 22:37:24 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:24 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:24 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:24 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:24 --> Router Class Initialized
ERROR - 2011-08-07 22:37:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-07 22:37:25 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:25 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:25 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Controller Class Initialized
ERROR - 2011-08-07 22:37:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 22:37:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:25 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:25 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:25 --> Helper loaded: url_helper
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 22:37:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 22:37:25 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:25 --> Total execution time: 0.0317
DEBUG - 2011-08-07 22:37:25 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:25 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:25 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Controller Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:25 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:25 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:25 --> Total execution time: 0.3171
DEBUG - 2011-08-07 22:37:58 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:58 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:58 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Controller Class Initialized
ERROR - 2011-08-07 22:37:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-07 22:37:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:58 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:58 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-07 22:37:58 --> Helper loaded: url_helper
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-07 22:37:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-07 22:37:58 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:58 --> Total execution time: 0.0286
DEBUG - 2011-08-07 22:37:59 --> Config Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Hooks Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Utf8 Class Initialized
DEBUG - 2011-08-07 22:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-07 22:37:59 --> URI Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Router Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Output Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Input Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-07 22:37:59 --> Language Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Loader Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Controller Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Model Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-07 22:37:59 --> Database Driver Class Initialized
DEBUG - 2011-08-07 22:37:59 --> Final output sent to browser
DEBUG - 2011-08-07 22:37:59 --> Total execution time: 0.4494

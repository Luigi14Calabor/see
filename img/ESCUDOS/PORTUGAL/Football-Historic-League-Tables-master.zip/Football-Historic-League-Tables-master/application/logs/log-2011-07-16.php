<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-16 01:40:55 --> Config Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Hooks Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Utf8 Class Initialized
DEBUG - 2011-07-16 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 01:40:55 --> URI Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Router Class Initialized
ERROR - 2011-07-16 01:40:55 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-16 01:40:55 --> Config Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Hooks Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Utf8 Class Initialized
DEBUG - 2011-07-16 01:40:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 01:40:55 --> URI Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Router Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Output Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Input Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 01:40:55 --> Language Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Loader Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Controller Class Initialized
ERROR - 2011-07-16 01:40:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 01:40:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 01:40:55 --> Model Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Model Class Initialized
DEBUG - 2011-07-16 01:40:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 01:40:55 --> Database Driver Class Initialized
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 01:40:55 --> Helper loaded: url_helper
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 01:40:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 01:40:55 --> Final output sent to browser
DEBUG - 2011-07-16 01:40:55 --> Total execution time: 0.2390
DEBUG - 2011-07-16 02:35:52 --> Config Class Initialized
DEBUG - 2011-07-16 02:35:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 02:35:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 02:35:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 02:35:52 --> URI Class Initialized
DEBUG - 2011-07-16 02:35:52 --> Router Class Initialized
ERROR - 2011-07-16 02:35:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-16 02:36:26 --> Config Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Hooks Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Utf8 Class Initialized
DEBUG - 2011-07-16 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 02:36:26 --> URI Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Router Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Output Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Input Class Initialized
DEBUG - 2011-07-16 02:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 02:36:27 --> Language Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Loader Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Controller Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Model Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Model Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Model Class Initialized
DEBUG - 2011-07-16 02:36:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 02:36:27 --> Database Driver Class Initialized
DEBUG - 2011-07-16 02:36:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 02:36:27 --> Helper loaded: url_helper
DEBUG - 2011-07-16 02:36:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 02:36:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 02:36:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 02:36:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 02:36:27 --> Final output sent to browser
DEBUG - 2011-07-16 02:36:27 --> Total execution time: 0.6081
DEBUG - 2011-07-16 04:52:44 --> Config Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Hooks Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Utf8 Class Initialized
DEBUG - 2011-07-16 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 04:52:44 --> URI Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Router Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Output Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Input Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 04:52:44 --> Language Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Loader Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Controller Class Initialized
ERROR - 2011-07-16 04:52:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 04:52:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 04:52:44 --> Model Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Model Class Initialized
DEBUG - 2011-07-16 04:52:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 04:52:44 --> Database Driver Class Initialized
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 04:52:44 --> Helper loaded: url_helper
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 04:52:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 04:52:44 --> Final output sent to browser
DEBUG - 2011-07-16 04:52:44 --> Total execution time: 0.3018
DEBUG - 2011-07-16 04:52:50 --> Config Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Hooks Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Utf8 Class Initialized
DEBUG - 2011-07-16 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 04:52:50 --> URI Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Router Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Output Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Input Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 04:52:50 --> Language Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Loader Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Controller Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Model Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Model Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 04:52:50 --> Database Driver Class Initialized
DEBUG - 2011-07-16 04:52:50 --> Final output sent to browser
DEBUG - 2011-07-16 04:52:50 --> Total execution time: 0.7120
DEBUG - 2011-07-16 05:09:30 --> Config Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 05:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 05:09:30 --> URI Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Router Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Output Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Input Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 05:09:30 --> Language Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Loader Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Controller Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Model Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Model Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Model Class Initialized
DEBUG - 2011-07-16 05:09:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 05:09:30 --> Database Driver Class Initialized
DEBUG - 2011-07-16 05:09:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 05:09:32 --> Helper loaded: url_helper
DEBUG - 2011-07-16 05:09:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 05:09:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 05:09:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 05:09:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 05:09:32 --> Final output sent to browser
DEBUG - 2011-07-16 05:09:32 --> Total execution time: 1.5057
DEBUG - 2011-07-16 05:09:36 --> Config Class Initialized
DEBUG - 2011-07-16 05:09:36 --> Hooks Class Initialized
DEBUG - 2011-07-16 05:09:36 --> Utf8 Class Initialized
DEBUG - 2011-07-16 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 05:09:36 --> URI Class Initialized
DEBUG - 2011-07-16 05:09:36 --> Router Class Initialized
ERROR - 2011-07-16 05:09:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 05:09:37 --> Config Class Initialized
DEBUG - 2011-07-16 05:09:37 --> Hooks Class Initialized
DEBUG - 2011-07-16 05:09:37 --> Utf8 Class Initialized
DEBUG - 2011-07-16 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 05:09:37 --> URI Class Initialized
DEBUG - 2011-07-16 05:09:37 --> Router Class Initialized
ERROR - 2011-07-16 05:09:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 05:27:43 --> Config Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 05:27:43 --> URI Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Router Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Output Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Input Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 05:27:43 --> Language Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Loader Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Controller Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Model Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Model Class Initialized
DEBUG - 2011-07-16 05:27:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 05:27:43 --> Database Driver Class Initialized
DEBUG - 2011-07-16 05:27:44 --> Final output sent to browser
DEBUG - 2011-07-16 05:27:44 --> Total execution time: 0.8192
DEBUG - 2011-07-16 06:27:41 --> Config Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:27:41 --> URI Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Router Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Output Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Input Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:27:41 --> Language Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Loader Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Controller Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Model Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Model Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Model Class Initialized
DEBUG - 2011-07-16 06:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:27:41 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:27:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:27:41 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:27:41 --> Final output sent to browser
DEBUG - 2011-07-16 06:27:41 --> Total execution time: 0.6648
DEBUG - 2011-07-16 06:27:49 --> Config Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:27:49 --> URI Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Router Class Initialized
ERROR - 2011-07-16 06:27:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:27:49 --> Config Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:27:49 --> URI Class Initialized
DEBUG - 2011-07-16 06:27:49 --> Router Class Initialized
ERROR - 2011-07-16 06:27:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:28:26 --> Config Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:28:26 --> URI Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Router Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Output Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Input Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:28:26 --> Language Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Loader Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Controller Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Model Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Model Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Model Class Initialized
DEBUG - 2011-07-16 06:28:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:28:26 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:28:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:28:26 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:28:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:28:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:28:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:28:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:28:26 --> Final output sent to browser
DEBUG - 2011-07-16 06:28:26 --> Total execution time: 0.0578
DEBUG - 2011-07-16 06:32:59 --> Config Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:32:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:32:59 --> URI Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Router Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Output Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Input Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:32:59 --> Language Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Loader Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Controller Class Initialized
ERROR - 2011-07-16 06:32:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 06:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 06:32:59 --> Model Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Model Class Initialized
DEBUG - 2011-07-16 06:32:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:32:59 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 06:32:59 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:32:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:32:59 --> Final output sent to browser
DEBUG - 2011-07-16 06:32:59 --> Total execution time: 0.0825
DEBUG - 2011-07-16 06:33:00 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:00 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:00 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:00 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:33:00 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:33:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:33:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:33:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:33:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:33:00 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:00 --> Total execution time: 0.0483
DEBUG - 2011-07-16 06:33:01 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:01 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Router Class Initialized
ERROR - 2011-07-16 06:33:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:33:01 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:01 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:01 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:02 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:02 --> Total execution time: 0.6216
DEBUG - 2011-07-16 06:33:02 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:02 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:02 --> Router Class Initialized
ERROR - 2011-07-16 06:33:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:33:05 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:05 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:05 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:05 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:05 --> Router Class Initialized
ERROR - 2011-07-16 06:33:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:33:28 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:28 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:28 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:28 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:33:28 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:33:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:33:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:33:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:33:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:33:28 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:28 --> Total execution time: 0.1526
DEBUG - 2011-07-16 06:33:29 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:29 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:29 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:33:29 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:33:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:33:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:33:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:33:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:33:29 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:29 --> Total execution time: 0.0449
DEBUG - 2011-07-16 06:33:30 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:30 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:30 --> Router Class Initialized
ERROR - 2011-07-16 06:33:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 06:33:38 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:38 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:38 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:38 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:33:38 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:33:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:33:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:33:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:33:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:33:38 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:38 --> Total execution time: 0.1274
DEBUG - 2011-07-16 06:33:40 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:40 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Router Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Output Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Input Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 06:33:40 --> Language Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Loader Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Controller Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Model Class Initialized
DEBUG - 2011-07-16 06:33:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 06:33:40 --> Database Driver Class Initialized
DEBUG - 2011-07-16 06:33:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 06:33:40 --> Helper loaded: url_helper
DEBUG - 2011-07-16 06:33:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 06:33:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 06:33:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 06:33:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 06:33:40 --> Final output sent to browser
DEBUG - 2011-07-16 06:33:40 --> Total execution time: 0.0418
DEBUG - 2011-07-16 06:33:41 --> Config Class Initialized
DEBUG - 2011-07-16 06:33:41 --> Hooks Class Initialized
DEBUG - 2011-07-16 06:33:41 --> Utf8 Class Initialized
DEBUG - 2011-07-16 06:33:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 06:33:41 --> URI Class Initialized
DEBUG - 2011-07-16 06:33:41 --> Router Class Initialized
ERROR - 2011-07-16 06:33:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 07:10:29 --> Config Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:10:29 --> URI Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Router Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Output Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Input Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:10:29 --> Language Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Loader Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Controller Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:10:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:10:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:10:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:10:29 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:10:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:10:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:10:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:10:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:10:29 --> Final output sent to browser
DEBUG - 2011-07-16 07:10:29 --> Total execution time: 0.5745
DEBUG - 2011-07-16 07:55:30 --> Config Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:55:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:55:30 --> URI Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Router Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Output Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Input Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:55:30 --> Language Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Loader Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Controller Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:55:30 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:55:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:55:30 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:55:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:55:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:55:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:55:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:55:30 --> Final output sent to browser
DEBUG - 2011-07-16 07:55:30 --> Total execution time: 0.7726
DEBUG - 2011-07-16 07:55:32 --> Config Class Initialized
DEBUG - 2011-07-16 07:55:32 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:55:32 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:55:32 --> URI Class Initialized
DEBUG - 2011-07-16 07:55:32 --> Router Class Initialized
ERROR - 2011-07-16 07:55:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 07:55:35 --> Config Class Initialized
DEBUG - 2011-07-16 07:55:35 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:55:35 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:55:35 --> URI Class Initialized
DEBUG - 2011-07-16 07:55:35 --> Router Class Initialized
ERROR - 2011-07-16 07:55:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 07:55:54 --> Config Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:55:54 --> URI Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Router Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Output Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Input Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:55:54 --> Language Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Loader Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Controller Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Model Class Initialized
DEBUG - 2011-07-16 07:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:55:54 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:55:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:55:54 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:55:54 --> Final output sent to browser
DEBUG - 2011-07-16 07:55:54 --> Total execution time: 0.0731
DEBUG - 2011-07-16 07:56:02 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:02 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:02 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:02 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:02 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:02 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:02 --> Total execution time: 0.4363
DEBUG - 2011-07-16 07:56:07 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:07 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:07 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:07 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:08 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:08 --> Total execution time: 0.2962
DEBUG - 2011-07-16 07:56:13 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:13 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:13 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:13 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:14 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:14 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:14 --> Total execution time: 0.3112
DEBUG - 2011-07-16 07:56:31 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:31 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:31 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:31 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:31 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:31 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:31 --> Total execution time: 0.2394
DEBUG - 2011-07-16 07:56:40 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:40 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:40 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:40 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:40 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:40 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:40 --> Total execution time: 0.2406
DEBUG - 2011-07-16 07:56:47 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:47 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Router Class Initialized
ERROR - 2011-07-16 07:56:47 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-16 07:56:47 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:47 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:47 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:47 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:47 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:47 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:47 --> Total execution time: 0.0467
DEBUG - 2011-07-16 07:56:49 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:49 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:49 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:49 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:50 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:50 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:50 --> Total execution time: 0.4532
DEBUG - 2011-07-16 07:56:55 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:55 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:55 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:55 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:55 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:55 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:55 --> Total execution time: 0.0460
DEBUG - 2011-07-16 07:56:56 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:56 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:56 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:56 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:56 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:56 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:56 --> Total execution time: 0.0510
DEBUG - 2011-07-16 07:56:57 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:57 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:57 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:57 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:57 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:57 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:57 --> Total execution time: 0.2184
DEBUG - 2011-07-16 07:56:59 --> Config Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:56:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:56:59 --> URI Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Router Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Output Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Input Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:56:59 --> Language Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Loader Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Controller Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Model Class Initialized
DEBUG - 2011-07-16 07:56:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:56:59 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:56:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:56:59 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:56:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:56:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:56:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:56:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:56:59 --> Final output sent to browser
DEBUG - 2011-07-16 07:56:59 --> Total execution time: 0.0469
DEBUG - 2011-07-16 07:57:02 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:02 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:02 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:02 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:02 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:02 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:02 --> Total execution time: 0.0424
DEBUG - 2011-07-16 07:57:03 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:03 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:03 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:03 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:03 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:03 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:03 --> Total execution time: 0.0543
DEBUG - 2011-07-16 07:57:04 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:04 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:04 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:04 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:05 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:05 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:05 --> Total execution time: 0.2197
DEBUG - 2011-07-16 07:57:07 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:07 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:07 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:07 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:07 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:07 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:07 --> Total execution time: 0.0435
DEBUG - 2011-07-16 07:57:08 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:08 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:08 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:08 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:08 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:08 --> Total execution time: 0.0419
DEBUG - 2011-07-16 07:57:15 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:15 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:15 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:16 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:16 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:16 --> Total execution time: 0.2022
DEBUG - 2011-07-16 07:57:17 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:17 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:17 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:17 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:17 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:17 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:17 --> Total execution time: 0.0518
DEBUG - 2011-07-16 07:57:21 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:21 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:21 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:21 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:21 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:21 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:21 --> Total execution time: 0.2761
DEBUG - 2011-07-16 07:57:23 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:23 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:23 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:23 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:23 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:23 --> Total execution time: 0.0536
DEBUG - 2011-07-16 07:57:29 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:29 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:29 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:29 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:29 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:29 --> Total execution time: 0.2029
DEBUG - 2011-07-16 07:57:30 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:30 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:30 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:30 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:30 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:30 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:30 --> Total execution time: 0.0454
DEBUG - 2011-07-16 07:57:41 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:41 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:41 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:41 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:42 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:42 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:42 --> Total execution time: 0.2440
DEBUG - 2011-07-16 07:57:43 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:43 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:43 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:43 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:43 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:43 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:43 --> Total execution time: 0.0585
DEBUG - 2011-07-16 07:57:49 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:49 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:49 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:49 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:50 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:50 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:50 --> Total execution time: 0.2249
DEBUG - 2011-07-16 07:57:51 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:51 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:51 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:51 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:51 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:51 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:51 --> Total execution time: 0.0784
DEBUG - 2011-07-16 07:57:55 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:55 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:55 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:55 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:55 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:55 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:55 --> Total execution time: 0.3352
DEBUG - 2011-07-16 07:57:56 --> Config Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:57:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:57:56 --> URI Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Router Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Output Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Input Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:57:56 --> Language Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Loader Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Controller Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Model Class Initialized
DEBUG - 2011-07-16 07:57:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:57:56 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:57:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:57:56 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:57:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:57:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:57:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:57:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:57:56 --> Final output sent to browser
DEBUG - 2011-07-16 07:57:56 --> Total execution time: 0.0429
DEBUG - 2011-07-16 07:58:01 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:01 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:01 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:01 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:01 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:01 --> Total execution time: 0.4148
DEBUG - 2011-07-16 07:58:02 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:02 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:02 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:02 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:02 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:02 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:02 --> Total execution time: 0.0469
DEBUG - 2011-07-16 07:58:07 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:07 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:07 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:07 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:07 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:07 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:07 --> Total execution time: 0.1918
DEBUG - 2011-07-16 07:58:08 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:08 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:08 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:08 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:08 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:08 --> Total execution time: 0.0430
DEBUG - 2011-07-16 07:58:12 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:12 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:12 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:12 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:12 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:12 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:12 --> Total execution time: 0.0439
DEBUG - 2011-07-16 07:58:13 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:13 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:13 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:13 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:13 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:13 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:13 --> Total execution time: 0.0511
DEBUG - 2011-07-16 07:58:18 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:18 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:18 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:18 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:18 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:18 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:18 --> Total execution time: 0.3496
DEBUG - 2011-07-16 07:58:19 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:19 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:19 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:19 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:19 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:19 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:19 --> Total execution time: 0.0408
DEBUG - 2011-07-16 07:58:23 --> Config Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 07:58:23 --> URI Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Router Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Output Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Input Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 07:58:23 --> Language Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Loader Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Controller Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Model Class Initialized
DEBUG - 2011-07-16 07:58:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 07:58:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 07:58:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 07:58:23 --> Helper loaded: url_helper
DEBUG - 2011-07-16 07:58:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 07:58:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 07:58:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 07:58:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 07:58:23 --> Final output sent to browser
DEBUG - 2011-07-16 07:58:23 --> Total execution time: 0.0615
DEBUG - 2011-07-16 08:09:09 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:09 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:09 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:09 --> Controller Class Initialized
ERROR - 2011-07-16 08:09:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:09:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:10 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:10 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:10 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:10 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:09:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:09:10 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:10 --> Total execution time: 1.2517
DEBUG - 2011-07-16 08:09:11 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:11 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:11 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Controller Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:11 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:12 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:12 --> Total execution time: 1.2770
DEBUG - 2011-07-16 08:09:23 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:23 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:23 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Controller Class Initialized
ERROR - 2011-07-16 08:09:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:09:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:23 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:09:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:09:23 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:23 --> Total execution time: 0.0275
DEBUG - 2011-07-16 08:09:24 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:24 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:24 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Controller Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:25 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:25 --> Total execution time: 0.5655
DEBUG - 2011-07-16 08:09:39 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:39 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:39 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Controller Class Initialized
ERROR - 2011-07-16 08:09:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:09:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:39 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:39 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:39 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:09:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:09:39 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:39 --> Total execution time: 0.0287
DEBUG - 2011-07-16 08:09:39 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:39 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:39 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Controller Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:39 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:40 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:40 --> Total execution time: 0.5887
DEBUG - 2011-07-16 08:09:58 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:58 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:58 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Controller Class Initialized
ERROR - 2011-07-16 08:09:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:09:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:58 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:58 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:09:58 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:09:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:09:58 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:58 --> Total execution time: 0.0285
DEBUG - 2011-07-16 08:09:58 --> Config Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:09:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:09:58 --> URI Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Router Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Output Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Input Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:09:58 --> Language Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Loader Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Controller Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Model Class Initialized
DEBUG - 2011-07-16 08:09:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:09:58 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:09:59 --> Final output sent to browser
DEBUG - 2011-07-16 08:09:59 --> Total execution time: 0.5581
DEBUG - 2011-07-16 08:10:05 --> Config Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:10:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:10:05 --> URI Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Router Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Output Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Input Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:10:05 --> Language Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Loader Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Controller Class Initialized
ERROR - 2011-07-16 08:10:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:10:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:05 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:10:05 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:05 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:10:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:10:05 --> Final output sent to browser
DEBUG - 2011-07-16 08:10:05 --> Total execution time: 0.1866
DEBUG - 2011-07-16 08:10:18 --> Config Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:10:18 --> URI Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Router Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Output Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Input Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:10:18 --> Language Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Loader Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Controller Class Initialized
ERROR - 2011-07-16 08:10:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:10:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:18 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:10:18 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:18 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:10:18 --> Final output sent to browser
DEBUG - 2011-07-16 08:10:18 --> Total execution time: 0.0676
DEBUG - 2011-07-16 08:10:18 --> Config Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:10:18 --> URI Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Router Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Output Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Input Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:10:18 --> Language Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Loader Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Controller Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:10:18 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:10:19 --> Final output sent to browser
DEBUG - 2011-07-16 08:10:19 --> Total execution time: 0.5575
DEBUG - 2011-07-16 08:10:23 --> Config Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:10:23 --> URI Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Router Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Output Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Input Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:10:23 --> Language Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Loader Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Controller Class Initialized
ERROR - 2011-07-16 08:10:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:10:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:10:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:10:23 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:10:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:10:23 --> Final output sent to browser
DEBUG - 2011-07-16 08:10:23 --> Total execution time: 0.0264
DEBUG - 2011-07-16 08:10:23 --> Config Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:10:23 --> URI Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Router Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Output Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Input Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:10:23 --> Language Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Loader Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Controller Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Model Class Initialized
DEBUG - 2011-07-16 08:10:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:10:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:10:24 --> Final output sent to browser
DEBUG - 2011-07-16 08:10:24 --> Total execution time: 0.5701
DEBUG - 2011-07-16 08:41:15 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:15 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:15 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:15 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:15 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:15 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:15 --> Total execution time: 0.2664
DEBUG - 2011-07-16 08:41:16 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:16 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:16 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Controller Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:16 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:16 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:16 --> Total execution time: 0.7232
DEBUG - 2011-07-16 08:41:18 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:18 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Router Class Initialized
ERROR - 2011-07-16 08:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 08:41:18 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:18 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:18 --> Router Class Initialized
ERROR - 2011-07-16 08:41:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 08:41:19 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:19 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:19 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:19 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:19 --> Router Class Initialized
ERROR - 2011-07-16 08:41:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 08:41:29 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:29 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:29 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:29 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:29 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:29 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:29 --> Total execution time: 0.0279
DEBUG - 2011-07-16 08:41:29 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:29 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:29 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Controller Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:30 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:30 --> Total execution time: 0.5866
DEBUG - 2011-07-16 08:41:37 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:37 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:37 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:37 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:37 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:37 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:37 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:37 --> Total execution time: 0.0280
DEBUG - 2011-07-16 08:41:38 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:38 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:38 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Controller Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:38 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:38 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:38 --> Total execution time: 0.5009
DEBUG - 2011-07-16 08:41:45 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:45 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:45 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:45 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:45 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:45 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:45 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:45 --> Total execution time: 0.0284
DEBUG - 2011-07-16 08:41:45 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:45 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:45 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Controller Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:45 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:46 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:46 --> Total execution time: 0.6762
DEBUG - 2011-07-16 08:41:50 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:50 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:50 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:50 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:50 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:50 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:50 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:50 --> Total execution time: 0.0274
DEBUG - 2011-07-16 08:41:52 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:52 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:52 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Controller Class Initialized
ERROR - 2011-07-16 08:41:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:41:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:52 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:41:52 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:41:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:41:52 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:52 --> Total execution time: 0.0303
DEBUG - 2011-07-16 08:41:52 --> Config Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:41:52 --> URI Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Router Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Output Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Input Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:41:52 --> Language Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Loader Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Controller Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Model Class Initialized
DEBUG - 2011-07-16 08:41:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:41:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:41:53 --> Final output sent to browser
DEBUG - 2011-07-16 08:41:53 --> Total execution time: 0.6446
DEBUG - 2011-07-16 08:42:00 --> Config Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:42:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:42:00 --> URI Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Router Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Output Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Input Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:42:00 --> Language Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Loader Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Controller Class Initialized
ERROR - 2011-07-16 08:42:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 08:42:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:42:00 --> Model Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Model Class Initialized
DEBUG - 2011-07-16 08:42:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:42:00 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 08:42:00 --> Helper loaded: url_helper
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 08:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 08:42:00 --> Final output sent to browser
DEBUG - 2011-07-16 08:42:00 --> Total execution time: 0.0419
DEBUG - 2011-07-16 08:42:01 --> Config Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 08:42:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 08:42:01 --> URI Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Router Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Output Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Input Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 08:42:01 --> Language Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Loader Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Controller Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Model Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Model Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 08:42:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 08:42:01 --> Final output sent to browser
DEBUG - 2011-07-16 08:42:01 --> Total execution time: 0.5104
DEBUG - 2011-07-16 09:33:47 --> Config Class Initialized
DEBUG - 2011-07-16 09:33:47 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:33:47 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:33:47 --> URI Class Initialized
DEBUG - 2011-07-16 09:33:47 --> Router Class Initialized
DEBUG - 2011-07-16 09:33:47 --> No URI present. Default controller set.
DEBUG - 2011-07-16 09:33:47 --> Output Class Initialized
DEBUG - 2011-07-16 09:33:47 --> Input Class Initialized
DEBUG - 2011-07-16 09:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 09:33:47 --> Language Class Initialized
DEBUG - 2011-07-16 09:33:48 --> Loader Class Initialized
DEBUG - 2011-07-16 09:33:48 --> Controller Class Initialized
DEBUG - 2011-07-16 09:33:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-16 09:33:48 --> Helper loaded: url_helper
DEBUG - 2011-07-16 09:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 09:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 09:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 09:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 09:33:48 --> Final output sent to browser
DEBUG - 2011-07-16 09:33:48 --> Total execution time: 0.2956
DEBUG - 2011-07-16 09:33:49 --> Config Class Initialized
DEBUG - 2011-07-16 09:33:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:33:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:33:49 --> URI Class Initialized
DEBUG - 2011-07-16 09:33:49 --> Router Class Initialized
ERROR - 2011-07-16 09:33:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:33:52 --> Config Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:33:52 --> URI Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Router Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Output Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Input Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 09:33:52 --> Language Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Loader Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Controller Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Model Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Model Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Model Class Initialized
DEBUG - 2011-07-16 09:33:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 09:33:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 09:33:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 09:33:52 --> Helper loaded: url_helper
DEBUG - 2011-07-16 09:33:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 09:33:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 09:33:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 09:33:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 09:33:52 --> Final output sent to browser
DEBUG - 2011-07-16 09:33:52 --> Total execution time: 0.4468
DEBUG - 2011-07-16 09:33:54 --> Config Class Initialized
DEBUG - 2011-07-16 09:33:54 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:33:54 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:33:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:33:54 --> URI Class Initialized
DEBUG - 2011-07-16 09:33:54 --> Router Class Initialized
ERROR - 2011-07-16 09:33:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:15 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:15 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Router Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Output Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Input Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 09:34:15 --> Language Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Loader Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Controller Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 09:34:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 09:34:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 09:34:15 --> Helper loaded: url_helper
DEBUG - 2011-07-16 09:34:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 09:34:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 09:34:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 09:34:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 09:34:15 --> Final output sent to browser
DEBUG - 2011-07-16 09:34:15 --> Total execution time: 0.4433
DEBUG - 2011-07-16 09:34:19 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:19 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:19 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:19 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:19 --> Router Class Initialized
ERROR - 2011-07-16 09:34:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:36 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:36 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Router Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Output Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Input Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 09:34:36 --> Language Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Loader Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Controller Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Model Class Initialized
DEBUG - 2011-07-16 09:34:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 09:34:36 --> Database Driver Class Initialized
DEBUG - 2011-07-16 09:34:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 09:34:36 --> Helper loaded: url_helper
DEBUG - 2011-07-16 09:34:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 09:34:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 09:34:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 09:34:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 09:34:36 --> Final output sent to browser
DEBUG - 2011-07-16 09:34:36 --> Total execution time: 0.2729
DEBUG - 2011-07-16 09:34:37 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:37 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:37 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:37 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:37 --> Router Class Initialized
ERROR - 2011-07-16 09:34:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:45 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:45 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:45 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:45 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:45 --> Router Class Initialized
ERROR - 2011-07-16 09:34:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:48 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:48 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:48 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:48 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:48 --> Router Class Initialized
ERROR - 2011-07-16 09:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:52 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:52 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:52 --> Router Class Initialized
ERROR - 2011-07-16 09:34:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:54 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:54 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:54 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:54 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:54 --> Router Class Initialized
ERROR - 2011-07-16 09:34:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:57 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:57 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:57 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:57 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:57 --> Router Class Initialized
ERROR - 2011-07-16 09:34:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 09:34:59 --> Config Class Initialized
DEBUG - 2011-07-16 09:34:59 --> Hooks Class Initialized
DEBUG - 2011-07-16 09:34:59 --> Utf8 Class Initialized
DEBUG - 2011-07-16 09:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 09:34:59 --> URI Class Initialized
DEBUG - 2011-07-16 09:34:59 --> Router Class Initialized
ERROR - 2011-07-16 09:34:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 10:06:42 --> Config Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Hooks Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Utf8 Class Initialized
DEBUG - 2011-07-16 10:06:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 10:06:42 --> URI Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Router Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Output Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Input Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 10:06:42 --> Language Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Loader Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Controller Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Model Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Model Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Model Class Initialized
DEBUG - 2011-07-16 10:06:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 10:06:42 --> Database Driver Class Initialized
DEBUG - 2011-07-16 10:06:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 10:06:43 --> Helper loaded: url_helper
DEBUG - 2011-07-16 10:06:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 10:06:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 10:06:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 10:06:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 10:06:43 --> Final output sent to browser
DEBUG - 2011-07-16 10:06:43 --> Total execution time: 0.4003
DEBUG - 2011-07-16 11:31:52 --> Config Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 11:31:52 --> URI Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Router Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Output Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Input Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 11:31:52 --> Language Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Loader Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Controller Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Model Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Model Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Model Class Initialized
DEBUG - 2011-07-16 11:31:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 11:31:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 11:31:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 11:31:52 --> Helper loaded: url_helper
DEBUG - 2011-07-16 11:31:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 11:31:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 11:31:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 11:31:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 11:31:52 --> Final output sent to browser
DEBUG - 2011-07-16 11:31:52 --> Total execution time: 0.5610
DEBUG - 2011-07-16 11:32:13 --> Config Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Hooks Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Utf8 Class Initialized
DEBUG - 2011-07-16 11:32:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 11:32:13 --> URI Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Router Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Output Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Input Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 11:32:13 --> Language Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Loader Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Controller Class Initialized
ERROR - 2011-07-16 11:32:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 11:32:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 11:32:13 --> Model Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Model Class Initialized
DEBUG - 2011-07-16 11:32:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 11:32:13 --> Database Driver Class Initialized
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 11:32:13 --> Helper loaded: url_helper
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 11:32:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 11:32:13 --> Final output sent to browser
DEBUG - 2011-07-16 11:32:13 --> Total execution time: 0.1355
DEBUG - 2011-07-16 11:32:20 --> Config Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Hooks Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Utf8 Class Initialized
DEBUG - 2011-07-16 11:32:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 11:32:20 --> URI Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Router Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Output Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Input Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 11:32:20 --> Language Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Loader Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Controller Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Model Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Model Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 11:32:20 --> Database Driver Class Initialized
DEBUG - 2011-07-16 11:32:20 --> Final output sent to browser
DEBUG - 2011-07-16 11:32:20 --> Total execution time: 0.6470
DEBUG - 2011-07-16 12:22:07 --> Config Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Hooks Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Utf8 Class Initialized
DEBUG - 2011-07-16 12:22:07 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 12:22:07 --> URI Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Router Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Output Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Input Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 12:22:07 --> Language Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Loader Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Controller Class Initialized
ERROR - 2011-07-16 12:22:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 12:22:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 12:22:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 12:22:07 --> Model Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Model Class Initialized
DEBUG - 2011-07-16 12:22:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 12:22:07 --> Database Driver Class Initialized
DEBUG - 2011-07-16 12:22:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 12:22:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 12:22:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 12:22:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 12:22:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 12:22:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 12:22:08 --> Final output sent to browser
DEBUG - 2011-07-16 12:22:08 --> Total execution time: 0.3399
DEBUG - 2011-07-16 12:22:16 --> Config Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Hooks Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Utf8 Class Initialized
DEBUG - 2011-07-16 12:22:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 12:22:16 --> URI Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Router Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Output Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Input Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 12:22:16 --> Language Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Loader Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Controller Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Model Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Model Class Initialized
DEBUG - 2011-07-16 12:22:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 12:22:16 --> Database Driver Class Initialized
DEBUG - 2011-07-16 12:22:17 --> Final output sent to browser
DEBUG - 2011-07-16 12:22:17 --> Total execution time: 0.7994
DEBUG - 2011-07-16 13:35:55 --> Config Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Hooks Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Utf8 Class Initialized
DEBUG - 2011-07-16 13:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 13:35:55 --> URI Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Router Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Output Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Input Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 13:35:55 --> Language Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Loader Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Controller Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Model Class Initialized
DEBUG - 2011-07-16 13:35:55 --> Model Class Initialized
DEBUG - 2011-07-16 13:35:56 --> Model Class Initialized
DEBUG - 2011-07-16 13:35:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 13:35:56 --> Database Driver Class Initialized
DEBUG - 2011-07-16 13:35:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 13:35:56 --> Helper loaded: url_helper
DEBUG - 2011-07-16 13:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 13:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 13:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 13:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 13:35:56 --> Final output sent to browser
DEBUG - 2011-07-16 13:35:56 --> Total execution time: 0.8325
DEBUG - 2011-07-16 14:00:39 --> Config Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:00:39 --> URI Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Router Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Output Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Input Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:00:39 --> Language Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Loader Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Controller Class Initialized
DEBUG - 2011-07-16 14:00:39 --> Model Class Initialized
DEBUG - 2011-07-16 14:00:40 --> Model Class Initialized
DEBUG - 2011-07-16 14:00:40 --> Model Class Initialized
DEBUG - 2011-07-16 14:00:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:00:40 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:00:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 14:00:41 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:00:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:00:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:00:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:00:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:00:41 --> Final output sent to browser
DEBUG - 2011-07-16 14:00:41 --> Total execution time: 1.5184
DEBUG - 2011-07-16 14:00:42 --> Config Class Initialized
DEBUG - 2011-07-16 14:00:42 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:00:42 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:00:42 --> URI Class Initialized
DEBUG - 2011-07-16 14:00:42 --> Router Class Initialized
ERROR - 2011-07-16 14:00:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:00:43 --> Config Class Initialized
DEBUG - 2011-07-16 14:00:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:00:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:00:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:00:43 --> URI Class Initialized
DEBUG - 2011-07-16 14:00:43 --> Router Class Initialized
ERROR - 2011-07-16 14:00:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:25:40 --> Config Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:25:40 --> URI Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Router Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Output Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Input Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:25:40 --> Language Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Loader Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Controller Class Initialized
ERROR - 2011-07-16 14:25:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:25:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:25:40 --> Model Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Model Class Initialized
DEBUG - 2011-07-16 14:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:25:40 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:25:40 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:25:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:25:40 --> Final output sent to browser
DEBUG - 2011-07-16 14:25:40 --> Total execution time: 0.2410
DEBUG - 2011-07-16 14:25:42 --> Config Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:25:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:25:42 --> URI Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Router Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Output Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Input Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:25:42 --> Language Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Loader Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Controller Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Model Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Model Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:25:42 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:25:42 --> Final output sent to browser
DEBUG - 2011-07-16 14:25:42 --> Total execution time: 0.6754
DEBUG - 2011-07-16 14:25:43 --> Config Class Initialized
DEBUG - 2011-07-16 14:25:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:25:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:25:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:25:43 --> URI Class Initialized
DEBUG - 2011-07-16 14:25:43 --> Router Class Initialized
ERROR - 2011-07-16 14:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:26:00 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:00 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:00 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:00 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Controller Class Initialized
ERROR - 2011-07-16 14:26:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:26:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:26:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:00 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:01 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:26:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:26:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:26:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:26:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:26:01 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:01 --> Total execution time: 0.0334
DEBUG - 2011-07-16 14:26:01 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:01 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:01 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Controller Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:01 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:01 --> Total execution time: 0.4712
DEBUG - 2011-07-16 14:26:02 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:02 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:02 --> Router Class Initialized
ERROR - 2011-07-16 14:26:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:26:23 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:23 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:23 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Controller Class Initialized
ERROR - 2011-07-16 14:26:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:26:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:23 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:23 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:23 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:26:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:26:23 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:23 --> Total execution time: 0.0275
DEBUG - 2011-07-16 14:26:24 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:24 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:24 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Controller Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:24 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:24 --> Total execution time: 0.5088
DEBUG - 2011-07-16 14:26:25 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:25 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:25 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:25 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:25 --> Router Class Initialized
ERROR - 2011-07-16 14:26:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:26:32 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:32 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:32 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Controller Class Initialized
ERROR - 2011-07-16 14:26:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:26:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:32 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:32 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:32 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:26:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:26:32 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:32 --> Total execution time: 0.0284
DEBUG - 2011-07-16 14:26:33 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:33 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:33 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Controller Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:33 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:34 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:34 --> Total execution time: 0.6021
DEBUG - 2011-07-16 14:26:35 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:35 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:35 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:35 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:35 --> Router Class Initialized
ERROR - 2011-07-16 14:26:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:26:42 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:42 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:42 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Controller Class Initialized
ERROR - 2011-07-16 14:26:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:26:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:42 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:42 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:42 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:26:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:26:42 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:42 --> Total execution time: 0.0286
DEBUG - 2011-07-16 14:26:43 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:43 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:43 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Controller Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:43 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:43 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:43 --> Total execution time: 0.5653
DEBUG - 2011-07-16 14:26:44 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:44 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:44 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:44 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:44 --> Router Class Initialized
ERROR - 2011-07-16 14:26:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:26:52 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:52 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:52 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Controller Class Initialized
ERROR - 2011-07-16 14:26:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:26:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:52 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:26:52 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:26:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:26:52 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:52 --> Total execution time: 0.0307
DEBUG - 2011-07-16 14:26:52 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:52 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Router Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Output Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Input Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:26:52 --> Language Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Loader Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Controller Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Model Class Initialized
DEBUG - 2011-07-16 14:26:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:26:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:26:53 --> Final output sent to browser
DEBUG - 2011-07-16 14:26:53 --> Total execution time: 0.6815
DEBUG - 2011-07-16 14:26:54 --> Config Class Initialized
DEBUG - 2011-07-16 14:26:54 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:26:54 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:26:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:26:54 --> URI Class Initialized
DEBUG - 2011-07-16 14:26:54 --> Router Class Initialized
ERROR - 2011-07-16 14:26:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 14:27:24 --> Config Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:27:24 --> URI Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Router Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Output Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Input Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:27:24 --> Language Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Loader Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Controller Class Initialized
ERROR - 2011-07-16 14:27:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:27:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Model Class Initialized
DEBUG - 2011-07-16 14:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:27:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:27:24 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:27:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:27:24 --> Final output sent to browser
DEBUG - 2011-07-16 14:27:24 --> Total execution time: 0.0289
DEBUG - 2011-07-16 14:29:02 --> Config Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:29:02 --> URI Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Router Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Output Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Input Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:29:02 --> Language Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Loader Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Controller Class Initialized
ERROR - 2011-07-16 14:29:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:29:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:02 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:29:02 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:02 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:29:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:29:02 --> Final output sent to browser
DEBUG - 2011-07-16 14:29:02 --> Total execution time: 0.0727
DEBUG - 2011-07-16 14:29:14 --> Config Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:29:14 --> URI Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Router Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Output Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Input Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:29:14 --> Language Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Loader Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Controller Class Initialized
ERROR - 2011-07-16 14:29:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:29:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:14 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:29:14 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:14 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:29:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:29:14 --> Final output sent to browser
DEBUG - 2011-07-16 14:29:14 --> Total execution time: 0.0270
DEBUG - 2011-07-16 14:29:22 --> Config Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Hooks Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Utf8 Class Initialized
DEBUG - 2011-07-16 14:29:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 14:29:22 --> URI Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Router Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Output Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Input Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 14:29:22 --> Language Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Loader Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Controller Class Initialized
ERROR - 2011-07-16 14:29:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 14:29:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:22 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Model Class Initialized
DEBUG - 2011-07-16 14:29:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 14:29:22 --> Database Driver Class Initialized
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 14:29:22 --> Helper loaded: url_helper
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 14:29:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 14:29:22 --> Final output sent to browser
DEBUG - 2011-07-16 14:29:22 --> Total execution time: 0.0324
DEBUG - 2011-07-16 15:45:05 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:05 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:05 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Controller Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:06 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 15:45:06 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:45:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:45:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:45:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:45:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:45:06 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:06 --> Total execution time: 1.0151
DEBUG - 2011-07-16 15:45:11 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:11 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:11 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:11 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:11 --> Router Class Initialized
ERROR - 2011-07-16 15:45:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 15:45:26 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:26 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:26 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Controller Class Initialized
ERROR - 2011-07-16 15:45:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 15:45:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 15:45:26 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:26 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 15:45:26 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:45:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:45:26 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:26 --> Total execution time: 0.0997
DEBUG - 2011-07-16 15:45:27 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:27 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:27 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Controller Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:27 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:27 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:27 --> Total execution time: 0.5820
DEBUG - 2011-07-16 15:45:30 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:30 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:30 --> Router Class Initialized
ERROR - 2011-07-16 15:45:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 15:45:44 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:44 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:44 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Controller Class Initialized
ERROR - 2011-07-16 15:45:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 15:45:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 15:45:44 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:44 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 15:45:44 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:45:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:45:44 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:44 --> Total execution time: 0.0285
DEBUG - 2011-07-16 15:45:45 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:45 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:45 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Controller Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:45 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:46 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:46 --> Total execution time: 0.5809
DEBUG - 2011-07-16 15:45:48 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:48 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Router Class Initialized
ERROR - 2011-07-16 15:45:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 15:45:48 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:48 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Router Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Output Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Input Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:45:48 --> Language Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Loader Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Controller Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Model Class Initialized
DEBUG - 2011-07-16 15:45:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:45:48 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:45:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 15:45:49 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:45:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:45:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:45:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:45:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:45:49 --> Final output sent to browser
DEBUG - 2011-07-16 15:45:49 --> Total execution time: 0.0439
DEBUG - 2011-07-16 15:45:50 --> Config Class Initialized
DEBUG - 2011-07-16 15:45:50 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:45:50 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:45:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:45:50 --> URI Class Initialized
DEBUG - 2011-07-16 15:45:50 --> Router Class Initialized
ERROR - 2011-07-16 15:45:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 15:46:53 --> Config Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:46:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:46:53 --> URI Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Router Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Output Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Input Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:46:53 --> Language Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Loader Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Controller Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Model Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Model Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Model Class Initialized
DEBUG - 2011-07-16 15:46:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:46:53 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:46:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 15:46:53 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:46:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:46:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:46:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:46:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:46:53 --> Final output sent to browser
DEBUG - 2011-07-16 15:46:53 --> Total execution time: 0.2007
DEBUG - 2011-07-16 15:47:20 --> Config Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Hooks Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Utf8 Class Initialized
DEBUG - 2011-07-16 15:47:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 15:47:20 --> URI Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Router Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Output Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Input Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 15:47:20 --> Language Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Loader Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Controller Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Model Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Model Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Model Class Initialized
DEBUG - 2011-07-16 15:47:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 15:47:20 --> Database Driver Class Initialized
DEBUG - 2011-07-16 15:47:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 15:47:20 --> Helper loaded: url_helper
DEBUG - 2011-07-16 15:47:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 15:47:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 15:47:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 15:47:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 15:47:20 --> Final output sent to browser
DEBUG - 2011-07-16 15:47:20 --> Total execution time: 0.0413
DEBUG - 2011-07-16 17:06:04 --> Config Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:06:04 --> URI Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Router Class Initialized
ERROR - 2011-07-16 17:06:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-16 17:06:04 --> Config Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:06:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:06:04 --> URI Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Router Class Initialized
DEBUG - 2011-07-16 17:06:04 --> No URI present. Default controller set.
DEBUG - 2011-07-16 17:06:04 --> Output Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Input Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 17:06:04 --> Language Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Loader Class Initialized
DEBUG - 2011-07-16 17:06:04 --> Controller Class Initialized
DEBUG - 2011-07-16 17:06:04 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-16 17:06:04 --> Helper loaded: url_helper
DEBUG - 2011-07-16 17:06:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 17:06:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 17:06:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 17:06:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 17:06:04 --> Final output sent to browser
DEBUG - 2011-07-16 17:06:04 --> Total execution time: 0.1678
DEBUG - 2011-07-16 17:18:24 --> Config Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:18:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:18:24 --> URI Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Router Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Output Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Input Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 17:18:24 --> Language Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Loader Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Controller Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Model Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Model Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Model Class Initialized
DEBUG - 2011-07-16 17:18:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 17:18:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 17:18:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 17:18:24 --> Helper loaded: url_helper
DEBUG - 2011-07-16 17:18:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 17:18:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 17:18:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 17:18:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 17:18:24 --> Final output sent to browser
DEBUG - 2011-07-16 17:18:24 --> Total execution time: 0.4729
DEBUG - 2011-07-16 17:18:29 --> Config Class Initialized
DEBUG - 2011-07-16 17:18:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:18:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:18:29 --> URI Class Initialized
DEBUG - 2011-07-16 17:18:29 --> Router Class Initialized
ERROR - 2011-07-16 17:18:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 17:18:30 --> Config Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:18:30 --> URI Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Router Class Initialized
ERROR - 2011-07-16 17:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 17:18:30 --> Config Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:18:30 --> URI Class Initialized
DEBUG - 2011-07-16 17:18:30 --> Router Class Initialized
ERROR - 2011-07-16 17:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 17:40:08 --> Config Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:40:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:40:08 --> URI Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Router Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Output Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Input Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 17:40:08 --> Language Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Loader Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Controller Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Model Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Model Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Model Class Initialized
DEBUG - 2011-07-16 17:40:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 17:40:08 --> Database Driver Class Initialized
DEBUG - 2011-07-16 17:40:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 17:40:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 17:40:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 17:40:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 17:40:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 17:40:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 17:40:08 --> Final output sent to browser
DEBUG - 2011-07-16 17:40:08 --> Total execution time: 0.7908
DEBUG - 2011-07-16 17:40:10 --> Config Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Hooks Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Utf8 Class Initialized
DEBUG - 2011-07-16 17:40:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 17:40:10 --> URI Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Router Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Output Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Input Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 17:40:10 --> Language Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Loader Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Controller Class Initialized
ERROR - 2011-07-16 17:40:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 17:40:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 17:40:10 --> Model Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Model Class Initialized
DEBUG - 2011-07-16 17:40:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 17:40:10 --> Database Driver Class Initialized
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 17:40:10 --> Helper loaded: url_helper
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 17:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 17:40:10 --> Final output sent to browser
DEBUG - 2011-07-16 17:40:10 --> Total execution time: 0.1043
DEBUG - 2011-07-16 19:08:30 --> Config Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:08:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:08:30 --> URI Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Router Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Output Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Input Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 19:08:30 --> Language Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Loader Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Controller Class Initialized
ERROR - 2011-07-16 19:08:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 19:08:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:08:30 --> Model Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Model Class Initialized
DEBUG - 2011-07-16 19:08:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 19:08:30 --> Database Driver Class Initialized
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:08:30 --> Helper loaded: url_helper
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 19:08:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 19:08:30 --> Final output sent to browser
DEBUG - 2011-07-16 19:08:30 --> Total execution time: 0.3012
DEBUG - 2011-07-16 19:08:32 --> Config Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:08:32 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:08:32 --> URI Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Router Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Output Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Input Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 19:08:32 --> Language Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Loader Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Controller Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Model Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Model Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 19:08:32 --> Database Driver Class Initialized
DEBUG - 2011-07-16 19:08:32 --> Final output sent to browser
DEBUG - 2011-07-16 19:08:32 --> Total execution time: 0.6041
DEBUG - 2011-07-16 19:08:33 --> Config Class Initialized
DEBUG - 2011-07-16 19:08:33 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:08:33 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:08:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:08:33 --> URI Class Initialized
DEBUG - 2011-07-16 19:08:33 --> Router Class Initialized
ERROR - 2011-07-16 19:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 19:09:02 --> Config Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:09:02 --> URI Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Router Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Output Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Input Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 19:09:02 --> Language Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Loader Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Controller Class Initialized
ERROR - 2011-07-16 19:09:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 19:09:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:09:02 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 19:09:02 --> Database Driver Class Initialized
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:09:02 --> Helper loaded: url_helper
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 19:09:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 19:09:02 --> Final output sent to browser
DEBUG - 2011-07-16 19:09:02 --> Total execution time: 0.0368
DEBUG - 2011-07-16 19:09:15 --> Config Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:09:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:09:15 --> URI Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Router Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Output Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Input Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 19:09:15 --> Language Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Loader Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Controller Class Initialized
ERROR - 2011-07-16 19:09:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 19:09:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:09:15 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 19:09:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 19:09:15 --> Helper loaded: url_helper
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 19:09:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 19:09:15 --> Final output sent to browser
DEBUG - 2011-07-16 19:09:15 --> Total execution time: 0.0306
DEBUG - 2011-07-16 19:09:15 --> Config Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:09:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:09:15 --> URI Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Router Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Output Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Input Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 19:09:15 --> Language Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Loader Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Controller Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Model Class Initialized
DEBUG - 2011-07-16 19:09:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 19:09:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 19:09:16 --> Final output sent to browser
DEBUG - 2011-07-16 19:09:16 --> Total execution time: 0.5525
DEBUG - 2011-07-16 19:09:17 --> Config Class Initialized
DEBUG - 2011-07-16 19:09:17 --> Hooks Class Initialized
DEBUG - 2011-07-16 19:09:17 --> Utf8 Class Initialized
DEBUG - 2011-07-16 19:09:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 19:09:17 --> URI Class Initialized
DEBUG - 2011-07-16 19:09:17 --> Router Class Initialized
ERROR - 2011-07-16 19:09:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 20:43:44 --> Config Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:43:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:43:44 --> URI Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Router Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Output Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Input Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:43:44 --> Language Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Loader Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Controller Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Model Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Model Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Model Class Initialized
DEBUG - 2011-07-16 20:43:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:43:44 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:43:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:43:44 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:43:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:43:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:43:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:43:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:43:44 --> Final output sent to browser
DEBUG - 2011-07-16 20:43:44 --> Total execution time: 0.5319
DEBUG - 2011-07-16 20:43:48 --> Config Class Initialized
DEBUG - 2011-07-16 20:43:48 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:43:48 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:43:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:43:48 --> URI Class Initialized
DEBUG - 2011-07-16 20:43:48 --> Router Class Initialized
ERROR - 2011-07-16 20:43:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 20:43:49 --> Config Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:43:49 --> URI Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Router Class Initialized
ERROR - 2011-07-16 20:43:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 20:43:49 --> Config Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:43:49 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:43:49 --> URI Class Initialized
DEBUG - 2011-07-16 20:43:49 --> Router Class Initialized
ERROR - 2011-07-16 20:43:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-16 20:44:03 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:03 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Router Class Initialized
ERROR - 2011-07-16 20:44:03 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-16 20:44:03 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:03 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:03 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:03 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:03 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:03 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:03 --> Total execution time: 0.0465
DEBUG - 2011-07-16 20:44:11 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:11 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:11 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:11 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:11 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:11 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:11 --> Total execution time: 0.2065
DEBUG - 2011-07-16 20:44:12 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:12 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:12 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:12 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:12 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:12 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:12 --> Total execution time: 0.0472
DEBUG - 2011-07-16 20:44:19 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:19 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:19 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:19 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:20 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:20 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:20 --> Total execution time: 1.2157
DEBUG - 2011-07-16 20:44:21 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:21 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:21 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:21 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:21 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:21 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:21 --> Total execution time: 0.0422
DEBUG - 2011-07-16 20:44:38 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:38 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:38 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:38 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:38 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:38 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:38 --> Total execution time: 0.2101
DEBUG - 2011-07-16 20:44:39 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:39 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:39 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:39 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:39 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:39 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:39 --> Total execution time: 0.0425
DEBUG - 2011-07-16 20:44:47 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:47 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:47 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:47 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:47 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:47 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:47 --> Total execution time: 0.0430
DEBUG - 2011-07-16 20:44:53 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:53 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:53 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:53 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:44:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:44:53 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:44:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:44:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:44:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:44:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:44:53 --> Final output sent to browser
DEBUG - 2011-07-16 20:44:53 --> Total execution time: 0.0445
DEBUG - 2011-07-16 20:44:59 --> Config Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:44:59 --> URI Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Router Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Output Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Input Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:44:59 --> Language Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Loader Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Controller Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Model Class Initialized
DEBUG - 2011-07-16 20:44:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:44:59 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:00 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:00 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:00 --> Total execution time: 0.2390
DEBUG - 2011-07-16 20:45:01 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:01 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:01 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:01 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:01 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:01 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:01 --> Total execution time: 0.0657
DEBUG - 2011-07-16 20:45:08 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:08 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:08 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:08 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:08 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:08 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:08 --> Total execution time: 0.0574
DEBUG - 2011-07-16 20:45:15 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:15 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:15 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:15 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:15 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:15 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:15 --> Total execution time: 0.2297
DEBUG - 2011-07-16 20:45:17 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:17 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:17 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:17 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:17 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:17 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:17 --> Total execution time: 0.0430
DEBUG - 2011-07-16 20:45:27 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:27 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:27 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:27 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:27 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:27 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:27 --> Total execution time: 0.2135
DEBUG - 2011-07-16 20:45:29 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:29 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:29 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:29 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 20:45:29 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:29 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:29 --> Total execution time: 0.0432
DEBUG - 2011-07-16 20:45:42 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:42 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:42 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Controller Class Initialized
ERROR - 2011-07-16 20:45:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:45:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:45:42 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:42 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:45:42 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:42 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:42 --> Total execution time: 0.0978
DEBUG - 2011-07-16 20:45:43 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:43 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:43 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:43 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:44 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:44 --> Total execution time: 0.7966
DEBUG - 2011-07-16 20:45:52 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:52 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:52 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Controller Class Initialized
ERROR - 2011-07-16 20:45:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:45:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:45:52 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:45:52 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:45:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:45:52 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:52 --> Total execution time: 0.0261
DEBUG - 2011-07-16 20:45:52 --> Config Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:45:52 --> URI Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Router Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Output Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Input Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:45:52 --> Language Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Loader Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Controller Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Model Class Initialized
DEBUG - 2011-07-16 20:45:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:45:52 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:45:53 --> Final output sent to browser
DEBUG - 2011-07-16 20:45:53 --> Total execution time: 0.6371
DEBUG - 2011-07-16 20:46:24 --> Config Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:46:24 --> URI Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Router Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Output Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Input Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:46:24 --> Language Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Loader Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Controller Class Initialized
ERROR - 2011-07-16 20:46:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:46:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:24 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:46:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:24 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:46:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:46:24 --> Final output sent to browser
DEBUG - 2011-07-16 20:46:24 --> Total execution time: 0.0300
DEBUG - 2011-07-16 20:46:24 --> Config Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:46:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:46:24 --> URI Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Router Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Output Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Input Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:46:24 --> Language Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Loader Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Controller Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:46:24 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:46:25 --> Final output sent to browser
DEBUG - 2011-07-16 20:46:25 --> Total execution time: 0.6974
DEBUG - 2011-07-16 20:46:36 --> Config Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:46:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:46:36 --> URI Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Router Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Output Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Input Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:46:36 --> Language Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Loader Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Controller Class Initialized
ERROR - 2011-07-16 20:46:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:46:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:36 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:46:36 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:36 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:46:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:46:36 --> Final output sent to browser
DEBUG - 2011-07-16 20:46:36 --> Total execution time: 0.0392
DEBUG - 2011-07-16 20:46:37 --> Config Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:46:37 --> URI Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Router Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Output Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Input Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:46:37 --> Language Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Loader Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Controller Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:46:37 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Config Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:46:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:46:37 --> URI Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Router Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Output Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Input Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:46:37 --> Language Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Loader Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Controller Class Initialized
ERROR - 2011-07-16 20:46:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:46:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:37 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Model Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:46:37 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:46:37 --> Final output sent to browser
DEBUG - 2011-07-16 20:46:37 --> Total execution time: 0.5837
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:46:37 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:46:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:46:37 --> Final output sent to browser
DEBUG - 2011-07-16 20:46:37 --> Total execution time: 0.0264
DEBUG - 2011-07-16 20:47:06 --> Config Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:47:06 --> URI Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Router Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Output Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Input Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:47:06 --> Language Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Loader Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Controller Class Initialized
ERROR - 2011-07-16 20:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:47:06 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:47:06 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:47:06 --> Final output sent to browser
DEBUG - 2011-07-16 20:47:06 --> Total execution time: 0.0277
DEBUG - 2011-07-16 20:47:06 --> Config Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:47:06 --> URI Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Router Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Output Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Input Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:47:06 --> Language Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Loader Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Controller Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:47:06 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Config Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Hooks Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Utf8 Class Initialized
DEBUG - 2011-07-16 20:47:06 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 20:47:06 --> URI Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Router Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Output Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Input Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 20:47:06 --> Language Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Loader Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Controller Class Initialized
ERROR - 2011-07-16 20:47:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 20:47:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Model Class Initialized
DEBUG - 2011-07-16 20:47:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 20:47:06 --> Database Driver Class Initialized
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 20:47:06 --> Helper loaded: url_helper
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 20:47:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 20:47:06 --> Final output sent to browser
DEBUG - 2011-07-16 20:47:06 --> Total execution time: 0.0275
DEBUG - 2011-07-16 20:47:07 --> Final output sent to browser
DEBUG - 2011-07-16 20:47:07 --> Total execution time: 0.5593
DEBUG - 2011-07-16 23:21:45 --> Config Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Hooks Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Utf8 Class Initialized
DEBUG - 2011-07-16 23:21:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 23:21:45 --> URI Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Router Class Initialized
DEBUG - 2011-07-16 23:21:45 --> No URI present. Default controller set.
DEBUG - 2011-07-16 23:21:45 --> Output Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Input Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 23:21:45 --> Language Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Loader Class Initialized
DEBUG - 2011-07-16 23:21:45 --> Controller Class Initialized
DEBUG - 2011-07-16 23:21:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-16 23:21:45 --> Helper loaded: url_helper
DEBUG - 2011-07-16 23:21:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 23:21:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 23:21:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 23:21:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 23:21:45 --> Final output sent to browser
DEBUG - 2011-07-16 23:21:45 --> Total execution time: 0.6377
DEBUG - 2011-07-16 23:56:34 --> Config Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Hooks Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Utf8 Class Initialized
DEBUG - 2011-07-16 23:56:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 23:56:34 --> URI Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Router Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Output Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Input Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 23:56:34 --> Language Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Loader Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Controller Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Model Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Model Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Model Class Initialized
DEBUG - 2011-07-16 23:56:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 23:56:34 --> Database Driver Class Initialized
DEBUG - 2011-07-16 23:56:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-16 23:56:34 --> Helper loaded: url_helper
DEBUG - 2011-07-16 23:56:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 23:56:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 23:56:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 23:56:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 23:56:34 --> Final output sent to browser
DEBUG - 2011-07-16 23:56:34 --> Total execution time: 0.7103
DEBUG - 2011-07-16 23:56:36 --> Config Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Hooks Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Utf8 Class Initialized
DEBUG - 2011-07-16 23:56:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-16 23:56:36 --> URI Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Router Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Output Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Input Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-16 23:56:36 --> Language Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Loader Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Controller Class Initialized
ERROR - 2011-07-16 23:56:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-16 23:56:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 23:56:36 --> Model Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Model Class Initialized
DEBUG - 2011-07-16 23:56:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-16 23:56:36 --> Database Driver Class Initialized
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-16 23:56:36 --> Helper loaded: url_helper
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-16 23:56:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-16 23:56:36 --> Final output sent to browser
DEBUG - 2011-07-16 23:56:36 --> Total execution time: 0.1271

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-08 02:38:50 --> Config Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:38:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:38:50 --> URI Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Router Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Output Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Input Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 02:38:50 --> Language Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Loader Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Controller Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Model Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Model Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Model Class Initialized
DEBUG - 2011-10-08 02:38:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 02:38:50 --> Database Driver Class Initialized
DEBUG - 2011-10-08 02:38:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 02:38:51 --> Helper loaded: url_helper
DEBUG - 2011-10-08 02:38:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 02:38:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 02:38:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 02:38:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 02:38:51 --> Final output sent to browser
DEBUG - 2011-10-08 02:38:51 --> Total execution time: 1.4574
DEBUG - 2011-10-08 02:38:55 --> Config Class Initialized
DEBUG - 2011-10-08 02:38:55 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:38:55 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:38:55 --> URI Class Initialized
DEBUG - 2011-10-08 02:38:55 --> Router Class Initialized
ERROR - 2011-10-08 02:38:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 02:39:15 --> Config Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:39:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:39:15 --> URI Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Router Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Output Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Input Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 02:39:15 --> Language Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Loader Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Controller Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 02:39:15 --> Database Driver Class Initialized
DEBUG - 2011-10-08 02:39:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 02:39:17 --> Helper loaded: url_helper
DEBUG - 2011-10-08 02:39:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 02:39:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 02:39:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 02:39:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 02:39:17 --> Final output sent to browser
DEBUG - 2011-10-08 02:39:17 --> Total execution time: 2.4061
DEBUG - 2011-10-08 02:39:20 --> Config Class Initialized
DEBUG - 2011-10-08 02:39:20 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:39:20 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:39:20 --> URI Class Initialized
DEBUG - 2011-10-08 02:39:20 --> Router Class Initialized
ERROR - 2011-10-08 02:39:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 02:39:27 --> Config Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:39:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:39:27 --> URI Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Router Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Output Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Input Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 02:39:27 --> Language Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Loader Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Controller Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 02:39:27 --> Database Driver Class Initialized
DEBUG - 2011-10-08 02:39:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 02:39:27 --> Helper loaded: url_helper
DEBUG - 2011-10-08 02:39:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 02:39:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 02:39:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 02:39:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 02:39:27 --> Final output sent to browser
DEBUG - 2011-10-08 02:39:27 --> Total execution time: 0.3128
DEBUG - 2011-10-08 02:39:29 --> Config Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:39:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:39:29 --> URI Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Router Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Output Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Input Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 02:39:29 --> Language Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Loader Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Controller Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Model Class Initialized
DEBUG - 2011-10-08 02:39:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 02:39:29 --> Database Driver Class Initialized
DEBUG - 2011-10-08 02:39:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 02:39:30 --> Helper loaded: url_helper
DEBUG - 2011-10-08 02:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 02:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 02:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 02:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 02:39:30 --> Final output sent to browser
DEBUG - 2011-10-08 02:39:30 --> Total execution time: 0.9611
DEBUG - 2011-10-08 02:39:32 --> Config Class Initialized
DEBUG - 2011-10-08 02:39:32 --> Hooks Class Initialized
DEBUG - 2011-10-08 02:39:32 --> Utf8 Class Initialized
DEBUG - 2011-10-08 02:39:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 02:39:32 --> URI Class Initialized
DEBUG - 2011-10-08 02:39:32 --> Router Class Initialized
ERROR - 2011-10-08 02:39:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 04:09:21 --> Config Class Initialized
DEBUG - 2011-10-08 04:09:21 --> Hooks Class Initialized
DEBUG - 2011-10-08 04:09:21 --> Utf8 Class Initialized
DEBUG - 2011-10-08 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 04:09:21 --> URI Class Initialized
DEBUG - 2011-10-08 04:09:21 --> Router Class Initialized
ERROR - 2011-10-08 04:09:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-08 04:32:18 --> Config Class Initialized
DEBUG - 2011-10-08 04:32:18 --> Hooks Class Initialized
DEBUG - 2011-10-08 04:32:18 --> Utf8 Class Initialized
DEBUG - 2011-10-08 04:32:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 04:32:18 --> URI Class Initialized
DEBUG - 2011-10-08 04:32:18 --> Router Class Initialized
ERROR - 2011-10-08 04:32:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-08 04:38:16 --> Config Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Hooks Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Utf8 Class Initialized
DEBUG - 2011-10-08 04:38:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 04:38:16 --> URI Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Router Class Initialized
DEBUG - 2011-10-08 04:38:16 --> No URI present. Default controller set.
DEBUG - 2011-10-08 04:38:16 --> Output Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Input Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 04:38:16 --> Language Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Loader Class Initialized
DEBUG - 2011-10-08 04:38:16 --> Controller Class Initialized
DEBUG - 2011-10-08 04:38:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 04:38:16 --> Helper loaded: url_helper
DEBUG - 2011-10-08 04:38:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 04:38:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 04:38:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 04:38:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 04:38:16 --> Final output sent to browser
DEBUG - 2011-10-08 04:38:16 --> Total execution time: 0.1869
DEBUG - 2011-10-08 05:27:40 --> Config Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Hooks Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Utf8 Class Initialized
DEBUG - 2011-10-08 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 05:27:40 --> URI Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Router Class Initialized
ERROR - 2011-10-08 05:27:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-08 05:27:40 --> Config Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Hooks Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Utf8 Class Initialized
DEBUG - 2011-10-08 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 05:27:40 --> URI Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Router Class Initialized
DEBUG - 2011-10-08 05:27:40 --> No URI present. Default controller set.
DEBUG - 2011-10-08 05:27:40 --> Output Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Input Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 05:27:40 --> Language Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Loader Class Initialized
DEBUG - 2011-10-08 05:27:40 --> Controller Class Initialized
DEBUG - 2011-10-08 05:27:40 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 05:27:40 --> Helper loaded: url_helper
DEBUG - 2011-10-08 05:27:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 05:27:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 05:27:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 05:27:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 05:27:40 --> Final output sent to browser
DEBUG - 2011-10-08 05:27:40 --> Total execution time: 0.1598
DEBUG - 2011-10-08 05:27:41 --> Config Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Hooks Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Utf8 Class Initialized
DEBUG - 2011-10-08 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 05:27:41 --> URI Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Router Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Output Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Input Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 05:27:41 --> Language Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Loader Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Controller Class Initialized
ERROR - 2011-10-08 05:27:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-08 05:27:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-08 05:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 05:27:41 --> Model Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Model Class Initialized
DEBUG - 2011-10-08 05:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 05:27:41 --> Database Driver Class Initialized
DEBUG - 2011-10-08 05:27:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 05:27:42 --> Helper loaded: url_helper
DEBUG - 2011-10-08 05:27:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 05:27:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 05:27:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 05:27:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 05:27:42 --> Final output sent to browser
DEBUG - 2011-10-08 05:27:42 --> Total execution time: 0.5243
DEBUG - 2011-10-08 08:09:28 --> Config Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:09:28 --> URI Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Router Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Output Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Input Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:09:28 --> Language Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Loader Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Controller Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:09:28 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:09:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:09:31 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:09:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:09:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:09:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:09:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:09:31 --> Final output sent to browser
DEBUG - 2011-10-08 08:09:31 --> Total execution time: 2.4681
DEBUG - 2011-10-08 08:09:33 --> Config Class Initialized
DEBUG - 2011-10-08 08:09:33 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:09:33 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:09:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:09:33 --> URI Class Initialized
DEBUG - 2011-10-08 08:09:33 --> Router Class Initialized
ERROR - 2011-10-08 08:09:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 08:09:34 --> Config Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:09:34 --> URI Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Router Class Initialized
ERROR - 2011-10-08 08:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 08:09:34 --> Config Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:09:34 --> URI Class Initialized
DEBUG - 2011-10-08 08:09:34 --> Router Class Initialized
ERROR - 2011-10-08 08:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 08:09:37 --> Config Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:09:37 --> URI Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Router Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Output Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Input Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:09:37 --> Language Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Loader Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Controller Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:09:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:09:37 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:09:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:09:38 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:09:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:09:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:09:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:09:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:09:38 --> Final output sent to browser
DEBUG - 2011-10-08 08:09:38 --> Total execution time: 0.8327
DEBUG - 2011-10-08 08:10:23 --> Config Class Initialized
DEBUG - 2011-10-08 08:10:23 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:10:23 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:10:23 --> URI Class Initialized
DEBUG - 2011-10-08 08:10:23 --> Router Class Initialized
ERROR - 2011-10-08 08:10:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-08 08:10:24 --> Config Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:10:24 --> URI Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Router Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Output Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Input Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:10:24 --> Language Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Loader Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Controller Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Model Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Model Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Model Class Initialized
DEBUG - 2011-10-08 08:10:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:10:24 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:10:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:10:24 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:10:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:10:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:10:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:10:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:10:24 --> Final output sent to browser
DEBUG - 2011-10-08 08:10:24 --> Total execution time: 0.1389
DEBUG - 2011-10-08 08:22:26 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:26 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:26 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:26 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:26 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:26 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:26 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:26 --> Total execution time: 0.6302
DEBUG - 2011-10-08 08:22:29 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:29 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:29 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:29 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:29 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:29 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:29 --> Total execution time: 0.1344
DEBUG - 2011-10-08 08:22:41 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:41 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:41 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:41 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:42 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:42 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:42 --> Total execution time: 0.9664
DEBUG - 2011-10-08 08:22:44 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:44 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:44 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:44 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:44 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:44 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:44 --> Total execution time: 0.0482
DEBUG - 2011-10-08 08:22:47 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:47 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:47 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:47 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:48 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:48 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:48 --> Total execution time: 0.6315
DEBUG - 2011-10-08 08:22:53 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:53 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:53 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:53 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:53 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:53 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:53 --> Total execution time: 0.3059
DEBUG - 2011-10-08 08:22:54 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:54 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:54 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:54 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:54 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:54 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:54 --> Total execution time: 0.0672
DEBUG - 2011-10-08 08:22:55 --> Config Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:22:55 --> URI Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Router Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Output Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Input Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:22:55 --> Language Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Loader Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Controller Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Model Class Initialized
DEBUG - 2011-10-08 08:22:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:22:55 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:22:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:22:55 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:22:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:22:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:22:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:22:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:22:55 --> Final output sent to browser
DEBUG - 2011-10-08 08:22:55 --> Total execution time: 0.0531
DEBUG - 2011-10-08 08:23:04 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:04 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:04 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:04 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:04 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:04 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:04 --> Total execution time: 0.3667
DEBUG - 2011-10-08 08:23:10 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:10 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:10 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:10 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:11 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:11 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:11 --> Total execution time: 1.2642
DEBUG - 2011-10-08 08:23:21 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:21 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:21 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:21 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:21 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:21 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:21 --> Total execution time: 0.2712
DEBUG - 2011-10-08 08:23:27 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:27 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:27 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:27 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:27 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:27 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:27 --> Total execution time: 0.2651
DEBUG - 2011-10-08 08:23:34 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:34 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:34 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:35 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:35 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:35 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:35 --> Total execution time: 0.2969
DEBUG - 2011-10-08 08:23:37 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:37 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:37 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:37 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:37 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:37 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:37 --> Total execution time: 0.1365
DEBUG - 2011-10-08 08:23:37 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:37 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:37 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:37 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:37 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:37 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:37 --> Total execution time: 0.0494
DEBUG - 2011-10-08 08:23:38 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:38 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:38 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:38 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:38 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:38 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:38 --> Total execution time: 0.0517
DEBUG - 2011-10-08 08:23:48 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:48 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:48 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:48 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:49 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:49 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:49 --> Total execution time: 0.3214
DEBUG - 2011-10-08 08:23:50 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:50 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:50 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:50 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:50 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:50 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:50 --> Total execution time: 0.0601
DEBUG - 2011-10-08 08:23:54 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:54 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:54 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:54 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:55 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:55 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:55 --> Total execution time: 0.6889
DEBUG - 2011-10-08 08:23:57 --> Config Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Hooks Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Utf8 Class Initialized
DEBUG - 2011-10-08 08:23:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 08:23:57 --> URI Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Router Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Output Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Input Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 08:23:57 --> Language Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Loader Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Controller Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Model Class Initialized
DEBUG - 2011-10-08 08:23:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 08:23:57 --> Database Driver Class Initialized
DEBUG - 2011-10-08 08:23:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 08:23:57 --> Helper loaded: url_helper
DEBUG - 2011-10-08 08:23:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 08:23:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 08:23:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 08:23:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 08:23:57 --> Final output sent to browser
DEBUG - 2011-10-08 08:23:57 --> Total execution time: 0.1590
DEBUG - 2011-10-08 09:40:57 --> Config Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Hooks Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Utf8 Class Initialized
DEBUG - 2011-10-08 09:40:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 09:40:57 --> URI Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Router Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Output Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Input Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 09:40:57 --> Language Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Loader Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Controller Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Model Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Model Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Model Class Initialized
DEBUG - 2011-10-08 09:40:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 09:40:57 --> Database Driver Class Initialized
DEBUG - 2011-10-08 09:40:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 09:40:58 --> Helper loaded: url_helper
DEBUG - 2011-10-08 09:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 09:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 09:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 09:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 09:40:58 --> Final output sent to browser
DEBUG - 2011-10-08 09:40:58 --> Total execution time: 1.1150
DEBUG - 2011-10-08 09:41:03 --> Config Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Hooks Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Utf8 Class Initialized
DEBUG - 2011-10-08 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 09:41:03 --> URI Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Router Class Initialized
ERROR - 2011-10-08 09:41:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 09:41:03 --> Config Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Hooks Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Utf8 Class Initialized
DEBUG - 2011-10-08 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 09:41:03 --> URI Class Initialized
DEBUG - 2011-10-08 09:41:03 --> Router Class Initialized
ERROR - 2011-10-08 09:41:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 09:41:04 --> Config Class Initialized
DEBUG - 2011-10-08 09:41:04 --> Hooks Class Initialized
DEBUG - 2011-10-08 09:41:04 --> Utf8 Class Initialized
DEBUG - 2011-10-08 09:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 09:41:04 --> URI Class Initialized
DEBUG - 2011-10-08 09:41:04 --> Router Class Initialized
ERROR - 2011-10-08 09:41:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 10:38:49 --> Config Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Hooks Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Utf8 Class Initialized
DEBUG - 2011-10-08 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 10:38:49 --> URI Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Router Class Initialized
DEBUG - 2011-10-08 10:38:49 --> No URI present. Default controller set.
DEBUG - 2011-10-08 10:38:49 --> Output Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Input Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 10:38:49 --> Language Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Loader Class Initialized
DEBUG - 2011-10-08 10:38:49 --> Controller Class Initialized
DEBUG - 2011-10-08 10:38:49 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 10:38:49 --> Helper loaded: url_helper
DEBUG - 2011-10-08 10:38:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 10:38:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 10:38:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 10:38:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 10:38:49 --> Final output sent to browser
DEBUG - 2011-10-08 10:38:49 --> Total execution time: 0.1157
DEBUG - 2011-10-08 10:55:11 --> Config Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Hooks Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Utf8 Class Initialized
DEBUG - 2011-10-08 10:55:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 10:55:11 --> URI Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Router Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Output Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Input Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 10:55:11 --> Language Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Loader Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Controller Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Model Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Model Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Model Class Initialized
DEBUG - 2011-10-08 10:55:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 10:55:11 --> Database Driver Class Initialized
DEBUG - 2011-10-08 10:55:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 10:55:13 --> Helper loaded: url_helper
DEBUG - 2011-10-08 10:55:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 10:55:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 10:55:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 10:55:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 10:55:13 --> Final output sent to browser
DEBUG - 2011-10-08 10:55:13 --> Total execution time: 1.7466
DEBUG - 2011-10-08 10:55:23 --> Config Class Initialized
DEBUG - 2011-10-08 10:55:23 --> Hooks Class Initialized
DEBUG - 2011-10-08 10:55:23 --> Utf8 Class Initialized
DEBUG - 2011-10-08 10:55:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 10:55:23 --> URI Class Initialized
DEBUG - 2011-10-08 10:55:23 --> Router Class Initialized
ERROR - 2011-10-08 10:55:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 12:14:14 --> Config Class Initialized
DEBUG - 2011-10-08 12:14:14 --> Hooks Class Initialized
DEBUG - 2011-10-08 12:14:14 --> Utf8 Class Initialized
DEBUG - 2011-10-08 12:14:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 12:14:14 --> URI Class Initialized
DEBUG - 2011-10-08 12:14:14 --> Router Class Initialized
DEBUG - 2011-10-08 12:14:14 --> No URI present. Default controller set.
DEBUG - 2011-10-08 12:14:14 --> Output Class Initialized
DEBUG - 2011-10-08 12:14:14 --> Input Class Initialized
DEBUG - 2011-10-08 12:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 12:14:15 --> Language Class Initialized
DEBUG - 2011-10-08 12:14:15 --> Loader Class Initialized
DEBUG - 2011-10-08 12:14:15 --> Controller Class Initialized
DEBUG - 2011-10-08 12:14:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 12:14:15 --> Helper loaded: url_helper
DEBUG - 2011-10-08 12:14:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 12:14:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 12:14:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 12:14:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 12:14:15 --> Final output sent to browser
DEBUG - 2011-10-08 12:14:15 --> Total execution time: 0.0793
DEBUG - 2011-10-08 15:38:09 --> Config Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Hooks Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Utf8 Class Initialized
DEBUG - 2011-10-08 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 15:38:09 --> URI Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Router Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Output Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Input Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 15:38:09 --> Language Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Loader Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Controller Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Model Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Model Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Model Class Initialized
DEBUG - 2011-10-08 15:38:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 15:38:09 --> Database Driver Class Initialized
DEBUG - 2011-10-08 15:38:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 15:38:10 --> Helper loaded: url_helper
DEBUG - 2011-10-08 15:38:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 15:38:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 15:38:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 15:38:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 15:38:10 --> Final output sent to browser
DEBUG - 2011-10-08 15:38:10 --> Total execution time: 0.9413
DEBUG - 2011-10-08 16:01:39 --> Config Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:01:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:01:39 --> URI Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Router Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Output Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Input Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:01:39 --> Language Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Loader Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Controller Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Model Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Model Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Model Class Initialized
DEBUG - 2011-10-08 16:01:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:01:39 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:01:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 16:01:40 --> Helper loaded: url_helper
DEBUG - 2011-10-08 16:01:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 16:01:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 16:01:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 16:01:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 16:01:40 --> Final output sent to browser
DEBUG - 2011-10-08 16:01:40 --> Total execution time: 0.5736
DEBUG - 2011-10-08 16:16:34 --> Config Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:16:34 --> URI Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Router Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Output Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Input Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:16:34 --> Language Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Loader Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Controller Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Model Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Model Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Model Class Initialized
DEBUG - 2011-10-08 16:16:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:16:34 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:16:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 16:16:34 --> Helper loaded: url_helper
DEBUG - 2011-10-08 16:16:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 16:16:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 16:16:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 16:16:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 16:16:34 --> Final output sent to browser
DEBUG - 2011-10-08 16:16:34 --> Total execution time: 0.0522
DEBUG - 2011-10-08 16:16:35 --> Config Class Initialized
DEBUG - 2011-10-08 16:16:35 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:16:35 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:16:35 --> URI Class Initialized
DEBUG - 2011-10-08 16:16:35 --> Router Class Initialized
ERROR - 2011-10-08 16:16:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 16:17:14 --> Config Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:17:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:17:14 --> URI Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Router Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Output Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Input Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:17:14 --> Language Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Loader Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Controller Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Model Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Model Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Model Class Initialized
DEBUG - 2011-10-08 16:17:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:17:14 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:17:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 16:17:15 --> Helper loaded: url_helper
DEBUG - 2011-10-08 16:17:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 16:17:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 16:17:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 16:17:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 16:17:15 --> Final output sent to browser
DEBUG - 2011-10-08 16:17:15 --> Total execution time: 0.3633
DEBUG - 2011-10-08 16:17:15 --> Config Class Initialized
DEBUG - 2011-10-08 16:17:15 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:17:15 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:17:15 --> URI Class Initialized
DEBUG - 2011-10-08 16:17:15 --> Router Class Initialized
ERROR - 2011-10-08 16:17:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 16:18:07 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:07 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Router Class Initialized
ERROR - 2011-10-08 16:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 16:18:07 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:07 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:07 --> Router Class Initialized
ERROR - 2011-10-08 16:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 16:18:11 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:11 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Router Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Output Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Input Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:18:11 --> Language Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Loader Class Initialized
DEBUG - 2011-10-08 16:18:11 --> Controller Class Initialized
ERROR - 2011-10-08 16:18:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-08 16:18:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 16:18:12 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:18:12 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 16:18:12 --> Helper loaded: url_helper
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 16:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 16:18:12 --> Final output sent to browser
DEBUG - 2011-10-08 16:18:12 --> Total execution time: 0.1283
DEBUG - 2011-10-08 16:18:12 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:12 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Router Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Output Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Input Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:18:12 --> Language Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Loader Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Controller Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:18:12 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:18:13 --> Final output sent to browser
DEBUG - 2011-10-08 16:18:13 --> Total execution time: 0.6315
DEBUG - 2011-10-08 16:18:14 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:14 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:14 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:14 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:14 --> Router Class Initialized
ERROR - 2011-10-08 16:18:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 16:18:18 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:18 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Router Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Output Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Input Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:18:18 --> Language Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Loader Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Controller Class Initialized
ERROR - 2011-10-08 16:18:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-08 16:18:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 16:18:18 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:18:18 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 16:18:18 --> Helper loaded: url_helper
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 16:18:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 16:18:18 --> Final output sent to browser
DEBUG - 2011-10-08 16:18:18 --> Total execution time: 0.0321
DEBUG - 2011-10-08 16:18:19 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:19 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Router Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Output Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Input Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 16:18:19 --> Language Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Loader Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Controller Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Model Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 16:18:19 --> Database Driver Class Initialized
DEBUG - 2011-10-08 16:18:19 --> Final output sent to browser
DEBUG - 2011-10-08 16:18:19 --> Total execution time: 0.5723
DEBUG - 2011-10-08 16:18:21 --> Config Class Initialized
DEBUG - 2011-10-08 16:18:21 --> Hooks Class Initialized
DEBUG - 2011-10-08 16:18:21 --> Utf8 Class Initialized
DEBUG - 2011-10-08 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 16:18:21 --> URI Class Initialized
DEBUG - 2011-10-08 16:18:21 --> Router Class Initialized
ERROR - 2011-10-08 16:18:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 17:19:54 --> Config Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Hooks Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Utf8 Class Initialized
DEBUG - 2011-10-08 17:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 17:19:54 --> URI Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Router Class Initialized
DEBUG - 2011-10-08 17:19:54 --> No URI present. Default controller set.
DEBUG - 2011-10-08 17:19:54 --> Output Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Input Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 17:19:54 --> Language Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Loader Class Initialized
DEBUG - 2011-10-08 17:19:54 --> Controller Class Initialized
DEBUG - 2011-10-08 17:19:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 17:19:54 --> Helper loaded: url_helper
DEBUG - 2011-10-08 17:19:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 17:19:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 17:19:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 17:19:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 17:19:54 --> Final output sent to browser
DEBUG - 2011-10-08 17:19:54 --> Total execution time: 0.0544
DEBUG - 2011-10-08 18:52:30 --> Config Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Hooks Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Utf8 Class Initialized
DEBUG - 2011-10-08 18:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 18:52:30 --> URI Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Router Class Initialized
ERROR - 2011-10-08 18:52:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-08 18:52:30 --> Config Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Hooks Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Utf8 Class Initialized
DEBUG - 2011-10-08 18:52:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 18:52:30 --> URI Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Router Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Output Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Input Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 18:52:30 --> Language Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Loader Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Controller Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Model Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Model Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Model Class Initialized
DEBUG - 2011-10-08 18:52:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 18:52:30 --> Database Driver Class Initialized
DEBUG - 2011-10-08 18:52:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 18:52:31 --> Helper loaded: url_helper
DEBUG - 2011-10-08 18:52:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 18:52:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 18:52:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 18:52:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 18:52:31 --> Final output sent to browser
DEBUG - 2011-10-08 18:52:31 --> Total execution time: 0.9096
DEBUG - 2011-10-08 19:53:24 --> Config Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Hooks Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Utf8 Class Initialized
DEBUG - 2011-10-08 19:53:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 19:53:24 --> URI Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Router Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Output Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Input Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 19:53:24 --> Language Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Loader Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Controller Class Initialized
ERROR - 2011-10-08 19:53:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-08 19:53:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 19:53:24 --> Model Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Model Class Initialized
DEBUG - 2011-10-08 19:53:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 19:53:24 --> Database Driver Class Initialized
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-08 19:53:24 --> Helper loaded: url_helper
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 19:53:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 19:53:24 --> Final output sent to browser
DEBUG - 2011-10-08 19:53:24 --> Total execution time: 0.4029
DEBUG - 2011-10-08 19:53:25 --> Config Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Hooks Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Utf8 Class Initialized
DEBUG - 2011-10-08 19:53:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 19:53:25 --> URI Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Router Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Output Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Input Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 19:53:25 --> Language Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Loader Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Controller Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Model Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Model Class Initialized
DEBUG - 2011-10-08 19:53:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 19:53:25 --> Database Driver Class Initialized
DEBUG - 2011-10-08 19:53:26 --> Final output sent to browser
DEBUG - 2011-10-08 19:53:26 --> Total execution time: 0.8306
DEBUG - 2011-10-08 22:05:06 --> Config Class Initialized
DEBUG - 2011-10-08 22:05:06 --> Hooks Class Initialized
DEBUG - 2011-10-08 22:05:06 --> Utf8 Class Initialized
DEBUG - 2011-10-08 22:05:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 22:05:07 --> URI Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Router Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Output Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Input Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 22:05:07 --> Language Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Loader Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Controller Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Model Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Model Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Model Class Initialized
DEBUG - 2011-10-08 22:05:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-08 22:05:07 --> Database Driver Class Initialized
DEBUG - 2011-10-08 22:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-08 22:05:09 --> Helper loaded: url_helper
DEBUG - 2011-10-08 22:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 22:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 22:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 22:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 22:05:09 --> Final output sent to browser
DEBUG - 2011-10-08 22:05:09 --> Total execution time: 2.2732
DEBUG - 2011-10-08 22:05:10 --> Config Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Hooks Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Utf8 Class Initialized
DEBUG - 2011-10-08 22:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 22:05:10 --> URI Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Router Class Initialized
ERROR - 2011-10-08 22:05:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 22:05:10 --> Config Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Hooks Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Utf8 Class Initialized
DEBUG - 2011-10-08 22:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 22:05:10 --> URI Class Initialized
DEBUG - 2011-10-08 22:05:10 --> Router Class Initialized
ERROR - 2011-10-08 22:05:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 22:05:12 --> Config Class Initialized
DEBUG - 2011-10-08 22:05:12 --> Hooks Class Initialized
DEBUG - 2011-10-08 22:05:12 --> Utf8 Class Initialized
DEBUG - 2011-10-08 22:05:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 22:05:12 --> URI Class Initialized
DEBUG - 2011-10-08 22:05:12 --> Router Class Initialized
ERROR - 2011-10-08 22:05:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-08 23:20:19 --> Config Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Hooks Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Utf8 Class Initialized
DEBUG - 2011-10-08 23:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-08 23:20:19 --> URI Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Router Class Initialized
DEBUG - 2011-10-08 23:20:19 --> No URI present. Default controller set.
DEBUG - 2011-10-08 23:20:19 --> Output Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Input Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-08 23:20:19 --> Language Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Loader Class Initialized
DEBUG - 2011-10-08 23:20:19 --> Controller Class Initialized
DEBUG - 2011-10-08 23:20:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-08 23:20:19 --> Helper loaded: url_helper
DEBUG - 2011-10-08 23:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-08 23:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-08 23:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-08 23:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-08 23:20:19 --> Final output sent to browser
DEBUG - 2011-10-08 23:20:19 --> Total execution time: 0.0704

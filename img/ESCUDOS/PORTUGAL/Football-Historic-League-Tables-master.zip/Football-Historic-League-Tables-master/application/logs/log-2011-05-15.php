<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-05-15 02:35:50 --> Config Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Hooks Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Utf8 Class Initialized
DEBUG - 2011-05-15 02:35:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 02:35:50 --> URI Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Router Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Output Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Input Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 02:35:50 --> Language Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Loader Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Controller Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Model Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Model Class Initialized
DEBUG - 2011-05-15 02:35:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 02:35:50 --> Database Driver Class Initialized
DEBUG - 2011-05-15 02:35:53 --> Final output sent to browser
DEBUG - 2011-05-15 02:35:53 --> Total execution time: 2.8341
DEBUG - 2011-05-15 04:02:42 --> Config Class Initialized
DEBUG - 2011-05-15 04:02:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 04:02:43 --> Utf8 Class Initialized
DEBUG - 2011-05-15 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 04:02:43 --> URI Class Initialized
DEBUG - 2011-05-15 04:02:43 --> Router Class Initialized
DEBUG - 2011-05-15 04:02:43 --> Output Class Initialized
DEBUG - 2011-05-15 04:02:44 --> Input Class Initialized
DEBUG - 2011-05-15 04:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 04:02:44 --> Language Class Initialized
DEBUG - 2011-05-15 04:02:44 --> Loader Class Initialized
DEBUG - 2011-05-15 04:02:45 --> Controller Class Initialized
DEBUG - 2011-05-15 04:02:45 --> Model Class Initialized
DEBUG - 2011-05-15 04:02:45 --> Model Class Initialized
DEBUG - 2011-05-15 04:02:46 --> Model Class Initialized
DEBUG - 2011-05-15 04:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 04:02:47 --> Database Driver Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Config Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Hooks Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Utf8 Class Initialized
DEBUG - 2011-05-15 04:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 04:02:57 --> URI Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Router Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Output Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Input Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 04:02:57 --> Language Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Loader Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Controller Class Initialized
ERROR - 2011-05-15 04:02:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 04:02:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 04:02:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 04:02:57 --> Model Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Model Class Initialized
DEBUG - 2011-05-15 04:02:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 04:02:57 --> Database Driver Class Initialized
DEBUG - 2011-05-15 04:02:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 04:02:59 --> Helper loaded: url_helper
DEBUG - 2011-05-15 04:02:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 04:02:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 04:02:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 04:02:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 04:02:59 --> Final output sent to browser
DEBUG - 2011-05-15 04:02:59 --> Total execution time: 2.6953
DEBUG - 2011-05-15 04:03:00 --> Config Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 04:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 04:03:00 --> URI Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Router Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Output Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Input Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 04:03:00 --> Language Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Loader Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Controller Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Model Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Model Class Initialized
DEBUG - 2011-05-15 04:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 04:03:00 --> Database Driver Class Initialized
DEBUG - 2011-05-15 04:03:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 04:03:01 --> Helper loaded: url_helper
DEBUG - 2011-05-15 04:03:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 04:03:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 04:03:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 04:03:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 04:03:01 --> Final output sent to browser
DEBUG - 2011-05-15 04:03:01 --> Total execution time: 20.1927
DEBUG - 2011-05-15 04:03:02 --> Final output sent to browser
DEBUG - 2011-05-15 04:03:02 --> Total execution time: 2.0364
DEBUG - 2011-05-15 04:03:08 --> Config Class Initialized
DEBUG - 2011-05-15 04:03:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 04:03:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 04:03:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 04:03:08 --> URI Class Initialized
DEBUG - 2011-05-15 04:03:08 --> Router Class Initialized
ERROR - 2011-05-15 04:03:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:01:55 --> Config Class Initialized
DEBUG - 2011-05-15 09:01:55 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:01:55 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:01:55 --> URI Class Initialized
DEBUG - 2011-05-15 09:01:55 --> Router Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Output Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Input Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 09:01:56 --> Language Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Loader Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Controller Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Model Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Model Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Model Class Initialized
DEBUG - 2011-05-15 09:01:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 09:01:56 --> Database Driver Class Initialized
DEBUG - 2011-05-15 09:01:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 09:01:57 --> Helper loaded: url_helper
DEBUG - 2011-05-15 09:01:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 09:01:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 09:01:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 09:01:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 09:01:57 --> Final output sent to browser
DEBUG - 2011-05-15 09:01:57 --> Total execution time: 1.5477
DEBUG - 2011-05-15 09:02:00 --> Config Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:02:00 --> URI Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Router Class Initialized
ERROR - 2011-05-15 09:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:02:00 --> Config Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:02:00 --> URI Class Initialized
DEBUG - 2011-05-15 09:02:00 --> Router Class Initialized
ERROR - 2011-05-15 09:02:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:02:01 --> Config Class Initialized
DEBUG - 2011-05-15 09:02:01 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:02:01 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:02:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:02:01 --> URI Class Initialized
DEBUG - 2011-05-15 09:02:01 --> Router Class Initialized
ERROR - 2011-05-15 09:02:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:48:18 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:18 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Router Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Output Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Input Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 09:48:18 --> Language Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Loader Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Controller Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 09:48:18 --> Database Driver Class Initialized
DEBUG - 2011-05-15 09:48:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 09:48:19 --> Helper loaded: url_helper
DEBUG - 2011-05-15 09:48:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 09:48:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 09:48:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 09:48:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 09:48:19 --> Final output sent to browser
DEBUG - 2011-05-15 09:48:19 --> Total execution time: 0.5397
DEBUG - 2011-05-15 09:48:22 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:22 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:22 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:22 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:22 --> Router Class Initialized
ERROR - 2011-05-15 09:48:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:48:23 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:23 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Router Class Initialized
ERROR - 2011-05-15 09:48:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:48:23 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:23 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:23 --> Router Class Initialized
ERROR - 2011-05-15 09:48:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 09:48:32 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:32 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Router Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Output Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Input Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 09:48:32 --> Language Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Loader Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Controller Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 09:48:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 09:48:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 09:48:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 09:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 09:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 09:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 09:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 09:48:32 --> Final output sent to browser
DEBUG - 2011-05-15 09:48:32 --> Total execution time: 0.2757
DEBUG - 2011-05-15 09:48:34 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:34 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Router Class Initialized
ERROR - 2011-05-15 09:48:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-15 09:48:34 --> Config Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 09:48:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 09:48:34 --> URI Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Router Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Output Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Input Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 09:48:34 --> Language Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Loader Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Controller Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Model Class Initialized
DEBUG - 2011-05-15 09:48:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 09:48:34 --> Database Driver Class Initialized
DEBUG - 2011-05-15 09:48:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 09:48:34 --> Helper loaded: url_helper
DEBUG - 2011-05-15 09:48:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 09:48:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 09:48:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 09:48:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 09:48:34 --> Final output sent to browser
DEBUG - 2011-05-15 09:48:34 --> Total execution time: 0.0489
DEBUG - 2011-05-15 10:00:16 --> Config Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:00:16 --> URI Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Router Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Output Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Input Class Initialized
DEBUG - 2011-05-15 10:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 10:00:16 --> Language Class Initialized
DEBUG - 2011-05-15 10:00:17 --> Loader Class Initialized
DEBUG - 2011-05-15 10:00:17 --> Controller Class Initialized
DEBUG - 2011-05-15 10:00:17 --> Model Class Initialized
DEBUG - 2011-05-15 10:00:17 --> Model Class Initialized
DEBUG - 2011-05-15 10:00:18 --> Model Class Initialized
DEBUG - 2011-05-15 10:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 10:00:20 --> Database Driver Class Initialized
DEBUG - 2011-05-15 10:00:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 10:00:23 --> Helper loaded: url_helper
DEBUG - 2011-05-15 10:00:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 10:00:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 10:00:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 10:00:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 10:00:24 --> Final output sent to browser
DEBUG - 2011-05-15 10:00:24 --> Total execution time: 8.9760
DEBUG - 2011-05-15 10:44:07 --> Config Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:44:07 --> URI Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Router Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Output Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Input Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 10:44:07 --> Language Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Loader Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Controller Class Initialized
ERROR - 2011-05-15 10:44:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 10:44:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 10:44:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 10:44:07 --> Model Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Model Class Initialized
DEBUG - 2011-05-15 10:44:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 10:44:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 10:44:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 10:44:08 --> Helper loaded: url_helper
DEBUG - 2011-05-15 10:44:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 10:44:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 10:44:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 10:44:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 10:44:08 --> Final output sent to browser
DEBUG - 2011-05-15 10:44:08 --> Total execution time: 0.4313
DEBUG - 2011-05-15 10:44:09 --> Config Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:44:09 --> URI Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Router Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Output Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Input Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 10:44:09 --> Language Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Loader Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Controller Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Model Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Model Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 10:44:09 --> Database Driver Class Initialized
DEBUG - 2011-05-15 10:44:09 --> Final output sent to browser
DEBUG - 2011-05-15 10:44:09 --> Total execution time: 0.6923
DEBUG - 2011-05-15 10:44:11 --> Config Class Initialized
DEBUG - 2011-05-15 10:44:11 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:44:11 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:44:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:44:11 --> URI Class Initialized
DEBUG - 2011-05-15 10:44:11 --> Router Class Initialized
ERROR - 2011-05-15 10:44:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 10:57:51 --> Config Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:57:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:57:51 --> URI Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Router Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Output Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Input Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 10:57:51 --> Language Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Loader Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Controller Class Initialized
ERROR - 2011-05-15 10:57:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 10:57:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 10:57:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 10:57:51 --> Model Class Initialized
DEBUG - 2011-05-15 10:57:51 --> Model Class Initialized
DEBUG - 2011-05-15 10:57:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 10:57:52 --> Database Driver Class Initialized
DEBUG - 2011-05-15 10:57:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 10:57:52 --> Helper loaded: url_helper
DEBUG - 2011-05-15 10:57:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 10:57:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 10:57:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 10:57:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 10:57:52 --> Final output sent to browser
DEBUG - 2011-05-15 10:57:52 --> Total execution time: 0.6032
DEBUG - 2011-05-15 10:57:53 --> Config Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:57:53 --> URI Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Router Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Output Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Input Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 10:57:53 --> Language Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Loader Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Controller Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Model Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Model Class Initialized
DEBUG - 2011-05-15 10:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 10:57:53 --> Database Driver Class Initialized
DEBUG - 2011-05-15 10:57:54 --> Final output sent to browser
DEBUG - 2011-05-15 10:57:54 --> Total execution time: 0.8724
DEBUG - 2011-05-15 10:57:58 --> Config Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:57:58 --> URI Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Router Class Initialized
ERROR - 2011-05-15 10:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 10:57:58 --> Config Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 10:57:58 --> URI Class Initialized
DEBUG - 2011-05-15 10:57:58 --> Router Class Initialized
ERROR - 2011-05-15 10:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 11:06:11 --> Config Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:06:11 --> URI Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Router Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Output Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Input Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:06:11 --> Language Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Loader Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Controller Class Initialized
ERROR - 2011-05-15 11:06:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 11:06:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 11:06:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:06:11 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:06:11 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:06:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:06:12 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:06:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:06:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:06:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:06:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:06:12 --> Final output sent to browser
DEBUG - 2011-05-15 11:06:12 --> Total execution time: 1.0829
DEBUG - 2011-05-15 11:06:22 --> Config Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:06:22 --> URI Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Router Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Output Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Input Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:06:22 --> Language Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Loader Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Controller Class Initialized
ERROR - 2011-05-15 11:06:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 11:06:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:06:22 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:06:22 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:06:22 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:06:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:06:22 --> Final output sent to browser
DEBUG - 2011-05-15 11:06:22 --> Total execution time: 0.0377
DEBUG - 2011-05-15 11:06:52 --> Config Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:06:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:06:52 --> URI Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Router Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Output Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Input Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:06:52 --> Language Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Loader Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Controller Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Model Class Initialized
DEBUG - 2011-05-15 11:06:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:06:52 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:06:53 --> Final output sent to browser
DEBUG - 2011-05-15 11:06:53 --> Total execution time: 0.6806
DEBUG - 2011-05-15 11:08:14 --> Config Class Initialized
DEBUG - 2011-05-15 11:08:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:08:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:08:14 --> URI Class Initialized
DEBUG - 2011-05-15 11:08:14 --> Router Class Initialized
ERROR - 2011-05-15 11:08:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 11:19:51 --> Config Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:19:51 --> URI Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Router Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Output Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Input Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:19:51 --> Language Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Loader Class Initialized
DEBUG - 2011-05-15 11:19:51 --> Controller Class Initialized
ERROR - 2011-05-15 11:19:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 11:19:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:19:52 --> Model Class Initialized
DEBUG - 2011-05-15 11:19:52 --> Model Class Initialized
DEBUG - 2011-05-15 11:19:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:19:52 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:19:52 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:19:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:19:52 --> Final output sent to browser
DEBUG - 2011-05-15 11:19:52 --> Total execution time: 0.3402
DEBUG - 2011-05-15 11:19:53 --> Config Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:19:53 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:19:53 --> URI Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Router Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Output Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Input Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:19:53 --> Language Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Loader Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Controller Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Model Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Model Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:19:53 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:19:53 --> Final output sent to browser
DEBUG - 2011-05-15 11:19:53 --> Total execution time: 0.6553
DEBUG - 2011-05-15 11:19:54 --> Config Class Initialized
DEBUG - 2011-05-15 11:19:54 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:19:54 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:19:54 --> URI Class Initialized
DEBUG - 2011-05-15 11:19:54 --> Router Class Initialized
ERROR - 2011-05-15 11:19:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 11:19:55 --> Config Class Initialized
DEBUG - 2011-05-15 11:19:55 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:19:55 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:19:55 --> URI Class Initialized
DEBUG - 2011-05-15 11:19:55 --> Router Class Initialized
ERROR - 2011-05-15 11:19:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 11:19:56 --> Config Class Initialized
DEBUG - 2011-05-15 11:19:56 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:19:56 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:19:56 --> URI Class Initialized
DEBUG - 2011-05-15 11:19:56 --> Router Class Initialized
ERROR - 2011-05-15 11:19:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 11:20:47 --> Config Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:20:47 --> URI Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Router Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Output Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Input Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:20:47 --> Language Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Loader Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Controller Class Initialized
ERROR - 2011-05-15 11:20:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 11:20:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:20:47 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:20:47 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:20:47 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:20:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:20:47 --> Final output sent to browser
DEBUG - 2011-05-15 11:20:47 --> Total execution time: 0.0607
DEBUG - 2011-05-15 11:20:48 --> Config Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:20:48 --> URI Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Router Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Output Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Input Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:20:48 --> Language Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Loader Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Controller Class Initialized
ERROR - 2011-05-15 11:20:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 11:20:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:20:48 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:20:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 11:20:48 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:20:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:20:48 --> Final output sent to browser
DEBUG - 2011-05-15 11:20:48 --> Total execution time: 0.0290
DEBUG - 2011-05-15 11:20:48 --> Config Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:20:48 --> URI Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Router Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Output Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Input Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:20:48 --> Language Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Loader Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Controller Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Model Class Initialized
DEBUG - 2011-05-15 11:20:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:20:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:20:50 --> Final output sent to browser
DEBUG - 2011-05-15 11:20:50 --> Total execution time: 1.4772
DEBUG - 2011-05-15 11:57:10 --> Config Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Hooks Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Utf8 Class Initialized
DEBUG - 2011-05-15 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 11:57:10 --> URI Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Router Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Output Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Input Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 11:57:10 --> Language Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Loader Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Controller Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Model Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Model Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Model Class Initialized
DEBUG - 2011-05-15 11:57:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 11:57:10 --> Database Driver Class Initialized
DEBUG - 2011-05-15 11:57:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 11:57:10 --> Helper loaded: url_helper
DEBUG - 2011-05-15 11:57:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 11:57:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 11:57:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 11:57:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 11:57:10 --> Final output sent to browser
DEBUG - 2011-05-15 11:57:10 --> Total execution time: 0.8377
DEBUG - 2011-05-15 12:22:19 --> Config Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:22:19 --> URI Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Router Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Output Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Input Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:22:19 --> Language Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Loader Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Controller Class Initialized
ERROR - 2011-05-15 12:22:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:22:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:22:19 --> Model Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Model Class Initialized
DEBUG - 2011-05-15 12:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:22:19 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:22:19 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:22:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:22:19 --> Final output sent to browser
DEBUG - 2011-05-15 12:22:19 --> Total execution time: 0.2559
DEBUG - 2011-05-15 12:22:20 --> Config Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:22:20 --> URI Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Router Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Output Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Input Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:22:20 --> Language Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Loader Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Controller Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Model Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Model Class Initialized
DEBUG - 2011-05-15 12:22:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:22:21 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:22:21 --> Final output sent to browser
DEBUG - 2011-05-15 12:22:21 --> Total execution time: 0.6509
DEBUG - 2011-05-15 12:22:22 --> Config Class Initialized
DEBUG - 2011-05-15 12:22:22 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:22:22 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:22:22 --> URI Class Initialized
DEBUG - 2011-05-15 12:22:22 --> Router Class Initialized
ERROR - 2011-05-15 12:22:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 12:22:24 --> Config Class Initialized
DEBUG - 2011-05-15 12:22:24 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:22:24 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:22:24 --> URI Class Initialized
DEBUG - 2011-05-15 12:22:24 --> Router Class Initialized
ERROR - 2011-05-15 12:22:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 12:23:32 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:32 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:32 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:32 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:32 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:32 --> Total execution time: 0.0298
DEBUG - 2011-05-15 12:23:32 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:32 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:32 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Controller Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:33 --> Total execution time: 0.6028
DEBUG - 2011-05-15 12:23:33 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:33 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:33 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:33 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:33 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:33 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:33 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:33 --> Total execution time: 0.0298
DEBUG - 2011-05-15 12:23:48 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:48 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:48 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:48 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:48 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:48 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:48 --> Total execution time: 0.0481
DEBUG - 2011-05-15 12:23:49 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:49 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:49 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Controller Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:49 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:50 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:50 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:50 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:50 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:50 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:50 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:50 --> Total execution time: 0.0489
DEBUG - 2011-05-15 12:23:50 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:50 --> Total execution time: 1.3085
DEBUG - 2011-05-15 12:23:58 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:58 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:58 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:58 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:58 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:58 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:58 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:58 --> Total execution time: 0.1078
DEBUG - 2011-05-15 12:23:59 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:59 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:59 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Controller Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:59 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Config Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:23:59 --> URI Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Router Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Output Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Input Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:23:59 --> Language Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Loader Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Controller Class Initialized
ERROR - 2011-05-15 12:23:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 12:23:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:59 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Model Class Initialized
DEBUG - 2011-05-15 12:23:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:23:59 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 12:23:59 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:23:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:23:59 --> Final output sent to browser
DEBUG - 2011-05-15 12:23:59 --> Total execution time: 0.0672
DEBUG - 2011-05-15 12:24:00 --> Final output sent to browser
DEBUG - 2011-05-15 12:24:00 --> Total execution time: 0.7522
DEBUG - 2011-05-15 12:24:44 --> Config Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:24:44 --> URI Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Router Class Initialized
DEBUG - 2011-05-15 12:24:44 --> No URI present. Default controller set.
DEBUG - 2011-05-15 12:24:44 --> Output Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Input Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:24:44 --> Language Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Loader Class Initialized
DEBUG - 2011-05-15 12:24:44 --> Controller Class Initialized
DEBUG - 2011-05-15 12:24:45 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 12:24:45 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:24:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:24:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:24:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:24:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:24:45 --> Final output sent to browser
DEBUG - 2011-05-15 12:24:45 --> Total execution time: 0.1108
DEBUG - 2011-05-15 12:24:46 --> Config Class Initialized
DEBUG - 2011-05-15 12:24:46 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:24:46 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:24:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:24:46 --> URI Class Initialized
DEBUG - 2011-05-15 12:24:46 --> Router Class Initialized
ERROR - 2011-05-15 12:24:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 12:24:49 --> Config Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:24:49 --> URI Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Router Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Output Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Input Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 12:24:49 --> Language Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Loader Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Controller Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Model Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Model Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Model Class Initialized
DEBUG - 2011-05-15 12:24:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 12:24:49 --> Database Driver Class Initialized
DEBUG - 2011-05-15 12:24:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 12:24:50 --> Helper loaded: url_helper
DEBUG - 2011-05-15 12:24:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 12:24:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 12:24:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 12:24:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 12:24:50 --> Final output sent to browser
DEBUG - 2011-05-15 12:24:50 --> Total execution time: 0.3816
DEBUG - 2011-05-15 12:24:51 --> Config Class Initialized
DEBUG - 2011-05-15 12:24:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 12:24:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 12:24:51 --> URI Class Initialized
DEBUG - 2011-05-15 12:24:51 --> Router Class Initialized
ERROR - 2011-05-15 12:24:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:08:03 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:03 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:03 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Controller Class Initialized
ERROR - 2011-05-15 13:08:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:08:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:03 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:08:03 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:03 --> Total execution time: 0.3166
DEBUG - 2011-05-15 13:08:05 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:05 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:05 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Controller Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:05 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:06 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:06 --> Total execution time: 1.3014
DEBUG - 2011-05-15 13:08:07 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:07 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:07 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:07 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:07 --> Router Class Initialized
ERROR - 2011-05-15 13:08:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:08:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Controller Class Initialized
ERROR - 2011-05-15 13:08:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:08:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:08:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:17 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:17 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:08:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:08:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:08:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:08:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:08:17 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:17 --> Total execution time: 0.0314
DEBUG - 2011-05-15 13:08:17 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:17 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:17 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Controller Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:17 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:18 --> Total execution time: 0.5571
DEBUG - 2011-05-15 13:08:18 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:18 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:18 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Controller Class Initialized
ERROR - 2011-05-15 13:08:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:08:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:18 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:18 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:18 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:08:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:08:18 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:18 --> Total execution time: 0.0302
DEBUG - 2011-05-15 13:08:20 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:20 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:20 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:20 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:20 --> Router Class Initialized
ERROR - 2011-05-15 13:08:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:08:35 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:35 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:35 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Controller Class Initialized
ERROR - 2011-05-15 13:08:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:08:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:35 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:35 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:08:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:08:35 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:35 --> Total execution time: 0.0397
DEBUG - 2011-05-15 13:08:36 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:36 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:36 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Controller Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:36 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:37 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:37 --> Total execution time: 0.5388
DEBUG - 2011-05-15 13:08:38 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:38 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:38 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:38 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:38 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:38 --> Router Class Initialized
ERROR - 2011-05-15 13:08:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:08:40 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:40 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Router Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Output Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Input Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:08:40 --> Language Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Loader Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Controller Class Initialized
ERROR - 2011-05-15 13:08:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:08:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:40 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Model Class Initialized
DEBUG - 2011-05-15 13:08:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:08:40 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:08:40 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:08:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:08:40 --> Final output sent to browser
DEBUG - 2011-05-15 13:08:40 --> Total execution time: 0.0323
DEBUG - 2011-05-15 13:08:42 --> Config Class Initialized
DEBUG - 2011-05-15 13:08:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:08:42 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:08:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:08:42 --> URI Class Initialized
DEBUG - 2011-05-15 13:08:42 --> Router Class Initialized
ERROR - 2011-05-15 13:08:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:09:02 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:02 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:02 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Controller Class Initialized
ERROR - 2011-05-15 13:09:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:09:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:02 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:02 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:09:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:09:02 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:02 --> Total execution time: 0.0759
DEBUG - 2011-05-15 13:09:03 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:03 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:03 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Controller Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:04 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:04 --> Total execution time: 0.6792
DEBUG - 2011-05-15 13:09:06 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:06 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:06 --> Router Class Initialized
ERROR - 2011-05-15 13:09:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:09:34 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:34 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:34 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Controller Class Initialized
ERROR - 2011-05-15 13:09:34 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:09:34 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:34 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:34 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:34 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:09:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:09:34 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:34 --> Total execution time: 0.0295
DEBUG - 2011-05-15 13:09:35 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:35 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:35 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Controller Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:35 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:36 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:36 --> Total execution time: 0.5676
DEBUG - 2011-05-15 13:09:37 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:37 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:37 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:37 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:37 --> Router Class Initialized
ERROR - 2011-05-15 13:09:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:09:46 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:46 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:46 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Controller Class Initialized
ERROR - 2011-05-15 13:09:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:09:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:46 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:46 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:09:46 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:09:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:09:46 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:46 --> Total execution time: 0.0312
DEBUG - 2011-05-15 13:09:47 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:47 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Router Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Output Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Input Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:09:47 --> Language Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Loader Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Controller Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Model Class Initialized
DEBUG - 2011-05-15 13:09:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:09:47 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:09:48 --> Final output sent to browser
DEBUG - 2011-05-15 13:09:48 --> Total execution time: 0.7232
DEBUG - 2011-05-15 13:09:49 --> Config Class Initialized
DEBUG - 2011-05-15 13:09:49 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:09:49 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:09:49 --> URI Class Initialized
DEBUG - 2011-05-15 13:09:49 --> Router Class Initialized
ERROR - 2011-05-15 13:09:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:10:18 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:18 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Router Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Output Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Input Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:10:18 --> Language Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Loader Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Controller Class Initialized
ERROR - 2011-05-15 13:10:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:10:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:18 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:10:18 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:18 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:10:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:10:18 --> Final output sent to browser
DEBUG - 2011-05-15 13:10:18 --> Total execution time: 0.0298
DEBUG - 2011-05-15 13:10:19 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:19 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:19 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Router Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Output Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Input Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:10:19 --> Language Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Loader Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Controller Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:10:19 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:10:20 --> Final output sent to browser
DEBUG - 2011-05-15 13:10:20 --> Total execution time: 0.4826
DEBUG - 2011-05-15 13:10:21 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:21 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:21 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:21 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:21 --> Router Class Initialized
ERROR - 2011-05-15 13:10:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:10:29 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:29 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Router Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Output Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Input Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:10:29 --> Language Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Loader Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Controller Class Initialized
ERROR - 2011-05-15 13:10:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:10:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:29 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:10:29 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:29 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:10:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:10:29 --> Final output sent to browser
DEBUG - 2011-05-15 13:10:29 --> Total execution time: 0.0291
DEBUG - 2011-05-15 13:10:30 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:30 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Router Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Output Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Input Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:10:30 --> Language Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Loader Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Controller Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:10:30 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:10:30 --> Final output sent to browser
DEBUG - 2011-05-15 13:10:30 --> Total execution time: 0.6804
DEBUG - 2011-05-15 13:10:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Router Class Initialized
ERROR - 2011-05-15 13:10:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:10:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:10:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:10:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Router Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Output Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Input Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:10:32 --> Language Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Loader Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Controller Class Initialized
ERROR - 2011-05-15 13:10:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:10:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:10:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:10:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:10:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:10:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:10:32 --> Final output sent to browser
DEBUG - 2011-05-15 13:10:32 --> Total execution time: 0.0684
DEBUG - 2011-05-15 13:11:05 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:05 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:05 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Controller Class Initialized
ERROR - 2011-05-15 13:11:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:11:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:05 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:05 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:11:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:11:05 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:05 --> Total execution time: 0.0284
DEBUG - 2011-05-15 13:11:06 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:06 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:06 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Controller Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:06 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:07 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:07 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Controller Class Initialized
ERROR - 2011-05-15 13:11:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:11:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:07 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:07 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:07 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:11:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:11:07 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:07 --> Total execution time: 0.0316
DEBUG - 2011-05-15 13:11:07 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:07 --> Total execution time: 0.8193
DEBUG - 2011-05-15 13:11:08 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:08 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:08 --> Router Class Initialized
ERROR - 2011-05-15 13:11:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:11:23 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:23 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:23 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Controller Class Initialized
ERROR - 2011-05-15 13:11:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:11:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:11:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:23 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:24 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:24 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:11:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:11:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:11:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:11:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:11:24 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:24 --> Total execution time: 0.0326
DEBUG - 2011-05-15 13:11:24 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:24 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:24 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Controller Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:24 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:25 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:25 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:25 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Controller Class Initialized
ERROR - 2011-05-15 13:11:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:11:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:25 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:25 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:25 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:11:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:11:25 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:25 --> Total execution time: 0.0301
DEBUG - 2011-05-15 13:11:25 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:25 --> Total execution time: 0.5565
DEBUG - 2011-05-15 13:11:26 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:26 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:26 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:26 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:26 --> Router Class Initialized
ERROR - 2011-05-15 13:11:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:11:42 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:42 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:42 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Controller Class Initialized
ERROR - 2011-05-15 13:11:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:11:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:42 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:42 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:11:43 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:11:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:11:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:11:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:11:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:11:43 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:43 --> Total execution time: 0.0302
DEBUG - 2011-05-15 13:11:43 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:43 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Router Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Output Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Input Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:11:43 --> Language Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Loader Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Controller Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:11:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:11:43 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:11:44 --> Final output sent to browser
DEBUG - 2011-05-15 13:11:44 --> Total execution time: 0.5762
DEBUG - 2011-05-15 13:11:45 --> Config Class Initialized
DEBUG - 2011-05-15 13:11:45 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:11:45 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:11:45 --> URI Class Initialized
DEBUG - 2011-05-15 13:11:45 --> Router Class Initialized
ERROR - 2011-05-15 13:11:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:12:10 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:10 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:10 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:10 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:10 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:10 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:10 --> Total execution time: 0.0279
DEBUG - 2011-05-15 13:12:10 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:10 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:10 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Controller Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:10 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:10 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:10 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:10 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:10 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:10 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:10 --> Total execution time: 0.0277
DEBUG - 2011-05-15 13:12:11 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:11 --> Total execution time: 0.5307
DEBUG - 2011-05-15 13:12:12 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:12 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:12 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:12 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:12 --> Router Class Initialized
ERROR - 2011-05-15 13:12:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:12:27 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:27 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:27 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:27 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:27 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:27 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:27 --> Total execution time: 0.0297
DEBUG - 2011-05-15 13:12:27 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:27 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:27 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Controller Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:27 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:28 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:28 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:28 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:28 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:28 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:28 --> Total execution time: 0.0276
DEBUG - 2011-05-15 13:12:28 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:28 --> Total execution time: 1.1028
DEBUG - 2011-05-15 13:12:30 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:30 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:30 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:30 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:30 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:30 --> Router Class Initialized
ERROR - 2011-05-15 13:12:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:12:47 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:47 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:47 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:47 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:47 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:47 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:47 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:47 --> Total execution time: 0.0300
DEBUG - 2011-05-15 13:12:48 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:48 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:48 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Controller Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:48 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Router Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Output Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Input Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:12:48 --> Language Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Loader Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Controller Class Initialized
ERROR - 2011-05-15 13:12:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:12:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:48 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Model Class Initialized
DEBUG - 2011-05-15 13:12:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:12:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:12:48 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:12:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:12:48 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:48 --> Total execution time: 0.0313
DEBUG - 2011-05-15 13:12:48 --> Final output sent to browser
DEBUG - 2011-05-15 13:12:48 --> Total execution time: 0.6340
DEBUG - 2011-05-15 13:12:50 --> Config Class Initialized
DEBUG - 2011-05-15 13:12:50 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:12:50 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:12:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:12:50 --> URI Class Initialized
DEBUG - 2011-05-15 13:12:50 --> Router Class Initialized
ERROR - 2011-05-15 13:12:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:13:14 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:14 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:14 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Controller Class Initialized
ERROR - 2011-05-15 13:13:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:13:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:14 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:14 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:14 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:13:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:13:14 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:14 --> Total execution time: 0.0330
DEBUG - 2011-05-15 13:13:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Controller Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Controller Class Initialized
ERROR - 2011-05-15 13:13:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:13:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:16 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:13:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:13:16 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:16 --> Total execution time: 0.0412
DEBUG - 2011-05-15 13:13:17 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:17 --> Total execution time: 0.5664
DEBUG - 2011-05-15 13:13:18 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:18 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:18 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:18 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:18 --> Router Class Initialized
ERROR - 2011-05-15 13:13:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:13:35 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:35 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:35 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Controller Class Initialized
ERROR - 2011-05-15 13:13:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:13:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:35 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:35 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:13:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:13:35 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:35 --> Total execution time: 0.0307
DEBUG - 2011-05-15 13:13:36 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:36 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:36 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:36 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Controller Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:36 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:36 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:36 --> Total execution time: 0.4693
DEBUG - 2011-05-15 13:13:37 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:37 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:37 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:37 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:37 --> Router Class Initialized
ERROR - 2011-05-15 13:13:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:13:45 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:45 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:45 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Controller Class Initialized
ERROR - 2011-05-15 13:13:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:13:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:45 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:45 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:13:45 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:13:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:13:45 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:45 --> Total execution time: 0.0293
DEBUG - 2011-05-15 13:13:46 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:46 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Router Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Output Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Input Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:13:46 --> Language Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Loader Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Controller Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Model Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:13:46 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:13:46 --> Final output sent to browser
DEBUG - 2011-05-15 13:13:46 --> Total execution time: 0.4520
DEBUG - 2011-05-15 13:13:48 --> Config Class Initialized
DEBUG - 2011-05-15 13:13:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:13:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:13:48 --> URI Class Initialized
DEBUG - 2011-05-15 13:13:48 --> Router Class Initialized
ERROR - 2011-05-15 13:13:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:14:06 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:06 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:06 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Controller Class Initialized
ERROR - 2011-05-15 13:14:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:14:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:06 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:06 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:14:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:14:06 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:06 --> Total execution time: 0.0284
DEBUG - 2011-05-15 13:14:06 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:06 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:06 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Controller Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:06 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:07 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:07 --> Total execution time: 0.5546
DEBUG - 2011-05-15 13:14:08 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:08 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:08 --> Router Class Initialized
ERROR - 2011-05-15 13:14:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:14:27 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:27 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:27 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Controller Class Initialized
ERROR - 2011-05-15 13:14:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:14:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:27 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:27 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:14:27 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:27 --> Total execution time: 0.0337
DEBUG - 2011-05-15 13:14:31 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:31 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:31 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Controller Class Initialized
ERROR - 2011-05-15 13:14:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:14:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:31 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:31 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:31 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:14:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:14:31 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:31 --> Total execution time: 0.0299
DEBUG - 2011-05-15 13:14:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:32 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Controller Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Router Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Output Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Input Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:14:32 --> Language Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Loader Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Controller Class Initialized
ERROR - 2011-05-15 13:14:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:14:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:14:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:14:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:14:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:14:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:14:32 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:32 --> Total execution time: 0.0266
DEBUG - 2011-05-15 13:14:32 --> Final output sent to browser
DEBUG - 2011-05-15 13:14:32 --> Total execution time: 0.6188
DEBUG - 2011-05-15 13:14:34 --> Config Class Initialized
DEBUG - 2011-05-15 13:14:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:14:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:14:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:14:34 --> URI Class Initialized
DEBUG - 2011-05-15 13:14:34 --> Router Class Initialized
ERROR - 2011-05-15 13:14:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:15:02 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:02 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:02 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Controller Class Initialized
ERROR - 2011-05-15 13:15:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:15:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:02 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:02 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:15:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:15:02 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:02 --> Total execution time: 0.2205
DEBUG - 2011-05-15 13:15:02 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:02 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:02 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Controller Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:02 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:03 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:03 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Controller Class Initialized
ERROR - 2011-05-15 13:15:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:15:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:03 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:15:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:15:03 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:03 --> Total execution time: 0.0315
DEBUG - 2011-05-15 13:15:03 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:03 --> Total execution time: 0.6120
DEBUG - 2011-05-15 13:15:05 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:05 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:05 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:05 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:05 --> Router Class Initialized
ERROR - 2011-05-15 13:15:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:15:57 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:57 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:57 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Controller Class Initialized
ERROR - 2011-05-15 13:15:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:15:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:57 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:57 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:57 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:15:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:15:57 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:57 --> Total execution time: 0.0295
DEBUG - 2011-05-15 13:15:58 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:58 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:58 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Controller Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:58 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Config Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:15:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:15:59 --> URI Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Router Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Output Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Input Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:15:59 --> Language Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Loader Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Controller Class Initialized
ERROR - 2011-05-15 13:15:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:15:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:15:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:15:59 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:15:59 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:15:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:15:59 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:59 --> Total execution time: 0.0303
DEBUG - 2011-05-15 13:15:59 --> Final output sent to browser
DEBUG - 2011-05-15 13:15:59 --> Total execution time: 0.7790
DEBUG - 2011-05-15 13:16:00 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:00 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:00 --> Router Class Initialized
ERROR - 2011-05-15 13:16:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:12 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:12 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:12 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:12 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:12 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:12 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:12 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:12 --> Total execution time: 0.0682
DEBUG - 2011-05-15 13:16:13 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:13 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:13 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Controller Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:13 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:13 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:13 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:13 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:13 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:13 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:13 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:13 --> Total execution time: 0.0504
DEBUG - 2011-05-15 13:16:13 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:13 --> Total execution time: 0.5634
DEBUG - 2011-05-15 13:16:15 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:15 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:15 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:15 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:15 --> Router Class Initialized
ERROR - 2011-05-15 13:16:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:21 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:21 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:21 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:21 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:21 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:21 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:21 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:21 --> Total execution time: 0.0293
DEBUG - 2011-05-15 13:16:22 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:22 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:22 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Controller Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:22 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:22 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:22 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:22 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:22 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:22 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:22 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:22 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:22 --> Total execution time: 0.0277
DEBUG - 2011-05-15 13:16:23 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:23 --> Total execution time: 0.5622
DEBUG - 2011-05-15 13:16:24 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:24 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:24 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:24 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:24 --> Router Class Initialized
ERROR - 2011-05-15 13:16:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:31 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:31 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:31 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:31 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:31 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:31 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:31 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:31 --> Total execution time: 0.0454
DEBUG - 2011-05-15 13:16:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:32 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:32 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:32 --> Total execution time: 0.0355
DEBUG - 2011-05-15 13:16:32 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:32 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:32 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Controller Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:32 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:32 --> Total execution time: 0.5535
DEBUG - 2011-05-15 13:16:34 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:34 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:34 --> Router Class Initialized
ERROR - 2011-05-15 13:16:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:43 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:43 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:43 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:43 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:43 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:43 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:43 --> Total execution time: 0.0278
DEBUG - 2011-05-15 13:16:43 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:43 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:43 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Controller Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:43 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:44 --> Total execution time: 0.4962
DEBUG - 2011-05-15 13:16:44 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:44 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:44 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:44 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:44 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:44 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:44 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:44 --> Total execution time: 0.0283
DEBUG - 2011-05-15 13:16:45 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:45 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:45 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:45 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:45 --> Router Class Initialized
ERROR - 2011-05-15 13:16:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:51 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:51 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:51 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:51 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:51 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:51 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:51 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:51 --> Total execution time: 0.0282
DEBUG - 2011-05-15 13:16:52 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:52 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:52 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Controller Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:52 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:52 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:52 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:52 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:52 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:52 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:52 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:52 --> Total execution time: 0.0275
DEBUG - 2011-05-15 13:16:53 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:53 --> Total execution time: 0.6197
DEBUG - 2011-05-15 13:16:54 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:54 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:54 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:54 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:54 --> Router Class Initialized
ERROR - 2011-05-15 13:16:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:16:59 --> Config Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:16:59 --> URI Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Router Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Output Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Input Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:16:59 --> Language Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Loader Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Controller Class Initialized
ERROR - 2011-05-15 13:16:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:16:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:16:59 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:16:59 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:16:59 --> Final output sent to browser
DEBUG - 2011-05-15 13:16:59 --> Total execution time: 0.0315
DEBUG - 2011-05-15 13:17:00 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:00 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:00 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Controller Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:00 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:00 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:00 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Controller Class Initialized
ERROR - 2011-05-15 13:17:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:17:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:00 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:00 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:00 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:17:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:17:00 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:00 --> Total execution time: 0.0332
DEBUG - 2011-05-15 13:17:00 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:00 --> Total execution time: 0.5185
DEBUG - 2011-05-15 13:17:02 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:02 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:02 --> Router Class Initialized
ERROR - 2011-05-15 13:17:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:17:07 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:07 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:07 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:07 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Controller Class Initialized
ERROR - 2011-05-15 13:17:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:17:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:07 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:07 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:07 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:17:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:17:07 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:07 --> Total execution time: 0.0288
DEBUG - 2011-05-15 13:17:08 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:08 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:08 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Controller Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:08 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:08 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Controller Class Initialized
ERROR - 2011-05-15 13:17:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:17:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:08 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:08 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:17:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:17:08 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:08 --> Total execution time: 0.0306
DEBUG - 2011-05-15 13:17:08 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:08 --> Total execution time: 0.4863
DEBUG - 2011-05-15 13:17:09 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:09 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:09 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:09 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:09 --> Router Class Initialized
ERROR - 2011-05-15 13:17:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:17:15 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:15 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:15 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Controller Class Initialized
ERROR - 2011-05-15 13:17:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:17:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:15 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:15 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:15 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:17:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:17:15 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:15 --> Total execution time: 0.0301
DEBUG - 2011-05-15 13:17:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Controller Class Initialized
ERROR - 2011-05-15 13:17:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:17:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:17:16 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:17:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:17:16 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:16 --> Total execution time: 0.0285
DEBUG - 2011-05-15 13:17:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:17:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Controller Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:17:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:17:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:17:17 --> Final output sent to browser
DEBUG - 2011-05-15 13:17:17 --> Total execution time: 0.4881
DEBUG - 2011-05-15 13:17:18 --> Config Class Initialized
DEBUG - 2011-05-15 13:17:18 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:17:18 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:17:18 --> URI Class Initialized
DEBUG - 2011-05-15 13:17:18 --> Router Class Initialized
ERROR - 2011-05-15 13:17:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:18:13 --> Config Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:18:13 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:18:13 --> URI Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Router Class Initialized
DEBUG - 2011-05-15 13:18:13 --> No URI present. Default controller set.
DEBUG - 2011-05-15 13:18:13 --> Output Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Input Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:18:13 --> Language Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Loader Class Initialized
DEBUG - 2011-05-15 13:18:13 --> Controller Class Initialized
DEBUG - 2011-05-15 13:18:13 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 13:18:13 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:18:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:18:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:18:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:18:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:18:13 --> Final output sent to browser
DEBUG - 2011-05-15 13:18:13 --> Total execution time: 0.0701
DEBUG - 2011-05-15 13:18:14 --> Config Class Initialized
DEBUG - 2011-05-15 13:18:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:18:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:18:14 --> URI Class Initialized
DEBUG - 2011-05-15 13:18:14 --> Router Class Initialized
ERROR - 2011-05-15 13:18:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:24:39 --> Config Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:24:39 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:24:39 --> URI Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Router Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Output Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Input Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:24:39 --> Language Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Loader Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Controller Class Initialized
ERROR - 2011-05-15 13:24:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:24:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:24:39 --> Model Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Model Class Initialized
DEBUG - 2011-05-15 13:24:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:24:39 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:24:39 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:24:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:24:39 --> Final output sent to browser
DEBUG - 2011-05-15 13:24:39 --> Total execution time: 0.2072
DEBUG - 2011-05-15 13:24:42 --> Config Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:24:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:24:42 --> URI Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Router Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Output Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Input Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:24:42 --> Language Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Loader Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Controller Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Model Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Model Class Initialized
DEBUG - 2011-05-15 13:24:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:24:42 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:25:02 --> Config Class Initialized
DEBUG - 2011-05-15 13:25:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:25:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:25:02 --> URI Class Initialized
DEBUG - 2011-05-15 13:25:02 --> Router Class Initialized
ERROR - 2011-05-15 13:25:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 13:33:59 --> Config Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:33:59 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:33:59 --> URI Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Router Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Output Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Input Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:33:59 --> Language Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Loader Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Controller Class Initialized
ERROR - 2011-05-15 13:33:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:33:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:33:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Model Class Initialized
DEBUG - 2011-05-15 13:33:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:33:59 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:33:59 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:33:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:33:59 --> Final output sent to browser
DEBUG - 2011-05-15 13:33:59 --> Total execution time: 0.0306
DEBUG - 2011-05-15 13:34:05 --> Config Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:34:05 --> URI Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Router Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Output Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Input Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:34:05 --> Language Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Loader Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Controller Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:34:05 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:34:06 --> Final output sent to browser
DEBUG - 2011-05-15 13:34:06 --> Total execution time: 0.5643
DEBUG - 2011-05-15 13:34:49 --> Config Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:34:49 --> URI Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Router Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Output Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Input Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:34:49 --> Language Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Loader Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Controller Class Initialized
ERROR - 2011-05-15 13:34:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:34:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:34:49 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:34:49 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:34:49 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:34:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:34:49 --> Final output sent to browser
DEBUG - 2011-05-15 13:34:49 --> Total execution time: 0.0925
DEBUG - 2011-05-15 13:34:51 --> Config Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:34:51 --> URI Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Router Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Output Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Input Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:34:51 --> Language Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Loader Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Controller Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Model Class Initialized
DEBUG - 2011-05-15 13:34:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:34:51 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:34:52 --> Final output sent to browser
DEBUG - 2011-05-15 13:34:52 --> Total execution time: 0.7550
DEBUG - 2011-05-15 13:35:14 --> Config Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:35:14 --> URI Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Router Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Output Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Input Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:35:14 --> Language Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Loader Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Controller Class Initialized
ERROR - 2011-05-15 13:35:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:35:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:35:14 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:35:14 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:35:14 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:35:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:35:14 --> Final output sent to browser
DEBUG - 2011-05-15 13:35:14 --> Total execution time: 0.0309
DEBUG - 2011-05-15 13:35:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:35:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:35:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Controller Class Initialized
ERROR - 2011-05-15 13:35:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:35:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:35:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:35:16 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:35:16 --> Final output sent to browser
DEBUG - 2011-05-15 13:35:16 --> Total execution time: 0.0270
DEBUG - 2011-05-15 13:35:16 --> Config Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:35:16 --> URI Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Router Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Output Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Input Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:35:16 --> Language Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Loader Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Controller Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Model Class Initialized
DEBUG - 2011-05-15 13:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:35:16 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:35:18 --> Final output sent to browser
DEBUG - 2011-05-15 13:35:18 --> Total execution time: 1.3245
DEBUG - 2011-05-15 13:40:35 --> Config Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:40:35 --> URI Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Router Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Output Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Input Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:40:35 --> Language Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Loader Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Controller Class Initialized
ERROR - 2011-05-15 13:40:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 13:40:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:40:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Model Class Initialized
DEBUG - 2011-05-15 13:40:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:40:35 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 13:40:35 --> Helper loaded: url_helper
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 13:40:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 13:40:35 --> Final output sent to browser
DEBUG - 2011-05-15 13:40:35 --> Total execution time: 0.0376
DEBUG - 2011-05-15 13:40:37 --> Config Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:40:37 --> URI Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Router Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Output Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Input Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 13:40:37 --> Language Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Loader Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Controller Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Model Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Model Class Initialized
DEBUG - 2011-05-15 13:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 13:40:37 --> Database Driver Class Initialized
DEBUG - 2011-05-15 13:40:38 --> Final output sent to browser
DEBUG - 2011-05-15 13:40:38 --> Total execution time: 1.3930
DEBUG - 2011-05-15 13:40:40 --> Config Class Initialized
DEBUG - 2011-05-15 13:40:40 --> Hooks Class Initialized
DEBUG - 2011-05-15 13:40:40 --> Utf8 Class Initialized
DEBUG - 2011-05-15 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 13:40:40 --> URI Class Initialized
DEBUG - 2011-05-15 13:40:40 --> Router Class Initialized
ERROR - 2011-05-15 13:40:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 14:24:55 --> Config Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:24:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:24:55 --> URI Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Router Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Output Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Input Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:24:55 --> Language Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Loader Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Controller Class Initialized
ERROR - 2011-05-15 14:24:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 14:24:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 14:24:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:24:55 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:24:55 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:24:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:24:56 --> Helper loaded: url_helper
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 14:24:56 --> Final output sent to browser
DEBUG - 2011-05-15 14:24:56 --> Total execution time: 0.6364
DEBUG - 2011-05-15 14:24:56 --> Config Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:24:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:24:56 --> URI Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Router Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Output Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Input Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:24:56 --> Language Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Loader Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Controller Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:24:56 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 14:24:56 --> Helper loaded: url_helper
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 14:24:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 14:24:56 --> Final output sent to browser
DEBUG - 2011-05-15 14:24:56 --> Total execution time: 0.3344
DEBUG - 2011-05-15 14:24:58 --> Config Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:24:58 --> URI Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Router Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Output Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Input Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:24:58 --> Language Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Loader Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Controller Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Model Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:24:58 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Config Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:24:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:24:58 --> URI Class Initialized
DEBUG - 2011-05-15 14:24:58 --> Router Class Initialized
ERROR - 2011-05-15 14:24:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 14:24:58 --> Final output sent to browser
DEBUG - 2011-05-15 14:24:58 --> Total execution time: 0.9356
DEBUG - 2011-05-15 14:55:42 --> Config Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:55:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:55:42 --> URI Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Router Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Output Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Input Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:55:42 --> Language Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Loader Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Controller Class Initialized
ERROR - 2011-05-15 14:55:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 14:55:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:55:42 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:55:42 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:55:42 --> Helper loaded: url_helper
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 14:55:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 14:55:42 --> Final output sent to browser
DEBUG - 2011-05-15 14:55:42 --> Total execution time: 0.4438
DEBUG - 2011-05-15 14:55:48 --> Config Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:55:48 --> URI Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Router Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Output Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Input Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:55:48 --> Language Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Loader Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Controller Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:55:48 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:55:49 --> Final output sent to browser
DEBUG - 2011-05-15 14:55:49 --> Total execution time: 0.6940
DEBUG - 2011-05-15 14:55:51 --> Config Class Initialized
DEBUG - 2011-05-15 14:55:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:55:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:55:51 --> URI Class Initialized
DEBUG - 2011-05-15 14:55:51 --> Router Class Initialized
ERROR - 2011-05-15 14:55:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 14:55:57 --> Config Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:55:57 --> URI Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Router Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Output Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Input Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:55:57 --> Language Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Loader Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Controller Class Initialized
ERROR - 2011-05-15 14:55:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 14:55:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:55:57 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:55:57 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 14:55:57 --> Helper loaded: url_helper
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 14:55:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 14:55:57 --> Final output sent to browser
DEBUG - 2011-05-15 14:55:57 --> Total execution time: 0.0304
DEBUG - 2011-05-15 14:55:58 --> Config Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Hooks Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Utf8 Class Initialized
DEBUG - 2011-05-15 14:55:58 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 14:55:58 --> URI Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Router Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Output Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Input Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 14:55:58 --> Language Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Loader Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Controller Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Model Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 14:55:58 --> Database Driver Class Initialized
DEBUG - 2011-05-15 14:55:58 --> Final output sent to browser
DEBUG - 2011-05-15 14:55:58 --> Total execution time: 0.6034
DEBUG - 2011-05-15 15:17:01 --> Config Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:17:01 --> URI Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Router Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Output Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Input Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:17:01 --> Language Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Loader Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Controller Class Initialized
ERROR - 2011-05-15 15:17:01 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:17:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:17:01 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:17:01 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:17:01 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:17:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:17:01 --> Final output sent to browser
DEBUG - 2011-05-15 15:17:01 --> Total execution time: 0.4098
DEBUG - 2011-05-15 15:17:03 --> Config Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:17:03 --> URI Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Router Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Output Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Input Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:17:03 --> Language Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Loader Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Controller Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:17:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:17:04 --> Final output sent to browser
DEBUG - 2011-05-15 15:17:04 --> Total execution time: 0.6022
DEBUG - 2011-05-15 15:17:06 --> Config Class Initialized
DEBUG - 2011-05-15 15:17:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:17:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:17:06 --> URI Class Initialized
DEBUG - 2011-05-15 15:17:06 --> Router Class Initialized
ERROR - 2011-05-15 15:17:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 15:17:46 --> Config Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:17:46 --> URI Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Router Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Output Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Input Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:17:46 --> Language Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Loader Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Controller Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Model Class Initialized
DEBUG - 2011-05-15 15:17:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:17:46 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:17:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:17:46 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:17:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:17:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:17:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:17:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:17:46 --> Final output sent to browser
DEBUG - 2011-05-15 15:17:46 --> Total execution time: 0.2756
DEBUG - 2011-05-15 15:32:01 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:01 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:01 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:01 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:32:01 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:01 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:01 --> Total execution time: 0.4359
DEBUG - 2011-05-15 15:32:02 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:02 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:02 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Controller Class Initialized
ERROR - 2011-05-15 15:32:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:32:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:32:02 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:02 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:32:02 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:02 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:02 --> Total execution time: 0.1049
DEBUG - 2011-05-15 15:32:03 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:03 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:03 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:03 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:03 --> Total execution time: 0.5602
DEBUG - 2011-05-15 15:32:04 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:04 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:04 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:04 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:04 --> Router Class Initialized
ERROR - 2011-05-15 15:32:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 15:32:10 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:10 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:10 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:10 --> No URI present. Default controller set.
DEBUG - 2011-05-15 15:32:10 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:10 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:10 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 15:32:10 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:10 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:10 --> Total execution time: 0.1009
DEBUG - 2011-05-15 15:32:33 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:33 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:33 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:33 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:32:33 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:33 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:33 --> Total execution time: 0.2644
DEBUG - 2011-05-15 15:32:34 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:34 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:34 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:34 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:32:34 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:34 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:34 --> Total execution time: 0.0547
DEBUG - 2011-05-15 15:32:54 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:54 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:54 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:54 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:32:55 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:55 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:55 --> Total execution time: 0.2565
DEBUG - 2011-05-15 15:32:56 --> Config Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:32:56 --> URI Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Router Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Output Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Input Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:32:56 --> Language Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Loader Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Controller Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:32:56 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:32:56 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:32:56 --> Final output sent to browser
DEBUG - 2011-05-15 15:32:56 --> Total execution time: 0.0601
DEBUG - 2011-05-15 15:33:44 --> Config Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:33:44 --> URI Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Router Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Output Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Input Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:33:44 --> Language Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Loader Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Controller Class Initialized
ERROR - 2011-05-15 15:33:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:33:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:33:44 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:33:44 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:33:44 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:33:44 --> Final output sent to browser
DEBUG - 2011-05-15 15:33:44 --> Total execution time: 0.2003
DEBUG - 2011-05-15 15:33:44 --> Config Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:33:44 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:33:44 --> URI Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Router Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Output Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Input Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:33:44 --> Language Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Loader Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Controller Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:33:44 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:33:45 --> Final output sent to browser
DEBUG - 2011-05-15 15:33:45 --> Total execution time: 0.6194
DEBUG - 2011-05-15 15:33:56 --> Config Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:33:56 --> URI Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Router Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Output Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Input Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:33:56 --> Language Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Loader Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Controller Class Initialized
ERROR - 2011-05-15 15:33:56 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:33:56 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:33:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:33:56 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:33:56 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:33:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:33:56 --> Final output sent to browser
DEBUG - 2011-05-15 15:33:56 --> Total execution time: 0.0317
DEBUG - 2011-05-15 15:33:56 --> Config Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:33:56 --> URI Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Router Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Output Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Input Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:33:56 --> Language Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Loader Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Controller Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Model Class Initialized
DEBUG - 2011-05-15 15:33:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:33:56 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:33:57 --> Final output sent to browser
DEBUG - 2011-05-15 15:33:57 --> Total execution time: 0.6005
DEBUG - 2011-05-15 15:34:08 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:08 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:08 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Controller Class Initialized
ERROR - 2011-05-15 15:34:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:34:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:08 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:34:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:34:08 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:08 --> Total execution time: 0.0329
DEBUG - 2011-05-15 15:34:08 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:08 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:08 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Controller Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:09 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:09 --> Total execution time: 0.5760
DEBUG - 2011-05-15 15:34:32 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:32 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:32 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Controller Class Initialized
ERROR - 2011-05-15 15:34:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:34:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:32 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:32 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:34:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:34:32 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:32 --> Total execution time: 0.0328
DEBUG - 2011-05-15 15:34:33 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:33 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:33 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Controller Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:33 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:34 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:34 --> Total execution time: 0.5435
DEBUG - 2011-05-15 15:34:45 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:45 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:45 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Controller Class Initialized
ERROR - 2011-05-15 15:34:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 15:34:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:45 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:45 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 15:34:45 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:34:45 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:45 --> Total execution time: 0.0304
DEBUG - 2011-05-15 15:34:45 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:45 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:45 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Controller Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:45 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:46 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:46 --> Total execution time: 0.5080
DEBUG - 2011-05-15 15:34:52 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:52 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:52 --> No URI present. Default controller set.
DEBUG - 2011-05-15 15:34:52 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:52 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:52 --> Controller Class Initialized
DEBUG - 2011-05-15 15:34:52 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 15:34:52 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:34:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:34:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:34:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:34:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:34:52 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:52 --> Total execution time: 0.0139
DEBUG - 2011-05-15 15:34:55 --> Config Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Hooks Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Utf8 Class Initialized
DEBUG - 2011-05-15 15:34:55 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 15:34:55 --> URI Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Router Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Output Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Input Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 15:34:55 --> Language Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Loader Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Controller Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Model Class Initialized
DEBUG - 2011-05-15 15:34:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 15:34:55 --> Database Driver Class Initialized
DEBUG - 2011-05-15 15:34:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 15:34:55 --> Helper loaded: url_helper
DEBUG - 2011-05-15 15:34:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 15:34:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 15:34:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 15:34:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 15:34:55 --> Final output sent to browser
DEBUG - 2011-05-15 15:34:55 --> Total execution time: 0.0433
DEBUG - 2011-05-15 16:22:14 --> Config Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 16:22:14 --> URI Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Router Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Output Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Input Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 16:22:14 --> Language Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Loader Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Controller Class Initialized
ERROR - 2011-05-15 16:22:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 16:22:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 16:22:14 --> Model Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Model Class Initialized
DEBUG - 2011-05-15 16:22:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 16:22:14 --> Database Driver Class Initialized
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 16:22:14 --> Helper loaded: url_helper
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 16:22:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 16:22:14 --> Final output sent to browser
DEBUG - 2011-05-15 16:22:14 --> Total execution time: 0.3290
DEBUG - 2011-05-15 16:22:15 --> Config Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Hooks Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Utf8 Class Initialized
DEBUG - 2011-05-15 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 16:22:15 --> URI Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Router Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Output Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Input Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 16:22:15 --> Language Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Loader Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Controller Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Model Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Model Class Initialized
DEBUG - 2011-05-15 16:22:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 16:22:15 --> Database Driver Class Initialized
DEBUG - 2011-05-15 16:22:16 --> Final output sent to browser
DEBUG - 2011-05-15 16:22:16 --> Total execution time: 0.6984
DEBUG - 2011-05-15 16:22:17 --> Config Class Initialized
DEBUG - 2011-05-15 16:22:17 --> Hooks Class Initialized
DEBUG - 2011-05-15 16:22:17 --> Utf8 Class Initialized
DEBUG - 2011-05-15 16:22:17 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 16:22:17 --> URI Class Initialized
DEBUG - 2011-05-15 16:22:17 --> Router Class Initialized
ERROR - 2011-05-15 16:22:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 17:19:46 --> Config Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Hooks Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Utf8 Class Initialized
DEBUG - 2011-05-15 17:19:46 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 17:19:46 --> URI Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Router Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Output Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Input Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 17:19:46 --> Language Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Loader Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Controller Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Model Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Model Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Model Class Initialized
DEBUG - 2011-05-15 17:19:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 17:19:46 --> Database Driver Class Initialized
DEBUG - 2011-05-15 17:19:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 17:19:46 --> Helper loaded: url_helper
DEBUG - 2011-05-15 17:19:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 17:19:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 17:19:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 17:19:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 17:19:46 --> Final output sent to browser
DEBUG - 2011-05-15 17:19:46 --> Total execution time: 0.6196
DEBUG - 2011-05-15 17:19:51 --> Config Class Initialized
DEBUG - 2011-05-15 17:19:51 --> Hooks Class Initialized
DEBUG - 2011-05-15 17:19:51 --> Utf8 Class Initialized
DEBUG - 2011-05-15 17:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 17:19:51 --> URI Class Initialized
DEBUG - 2011-05-15 17:19:51 --> Router Class Initialized
ERROR - 2011-05-15 17:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 17:19:52 --> Config Class Initialized
DEBUG - 2011-05-15 17:19:52 --> Hooks Class Initialized
DEBUG - 2011-05-15 17:19:52 --> Utf8 Class Initialized
DEBUG - 2011-05-15 17:19:52 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 17:19:52 --> URI Class Initialized
DEBUG - 2011-05-15 17:19:52 --> Router Class Initialized
ERROR - 2011-05-15 17:19:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 17:57:21 --> Config Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Hooks Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Utf8 Class Initialized
DEBUG - 2011-05-15 17:57:21 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 17:57:21 --> URI Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Router Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Output Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Input Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 17:57:21 --> Language Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Loader Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Controller Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Model Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Model Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Model Class Initialized
DEBUG - 2011-05-15 17:57:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 17:57:21 --> Database Driver Class Initialized
DEBUG - 2011-05-15 17:57:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 17:57:22 --> Helper loaded: url_helper
DEBUG - 2011-05-15 17:57:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 17:57:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 17:57:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 17:57:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 17:57:22 --> Final output sent to browser
DEBUG - 2011-05-15 17:57:22 --> Total execution time: 0.5903
DEBUG - 2011-05-15 17:57:24 --> Config Class Initialized
DEBUG - 2011-05-15 17:57:24 --> Hooks Class Initialized
DEBUG - 2011-05-15 17:57:24 --> Utf8 Class Initialized
DEBUG - 2011-05-15 17:57:24 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 17:57:24 --> URI Class Initialized
DEBUG - 2011-05-15 17:57:24 --> Router Class Initialized
ERROR - 2011-05-15 17:57:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 18:58:41 --> Config Class Initialized
DEBUG - 2011-05-15 18:58:41 --> Hooks Class Initialized
DEBUG - 2011-05-15 18:58:41 --> Utf8 Class Initialized
DEBUG - 2011-05-15 18:58:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 18:58:41 --> URI Class Initialized
DEBUG - 2011-05-15 18:58:41 --> Router Class Initialized
ERROR - 2011-05-15 18:58:41 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-15 18:58:42 --> Config Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Hooks Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Utf8 Class Initialized
DEBUG - 2011-05-15 18:58:42 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 18:58:42 --> URI Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Router Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Output Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Input Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 18:58:42 --> Language Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Loader Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Controller Class Initialized
ERROR - 2011-05-15 18:58:42 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 18:58:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 18:58:42 --> Model Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Model Class Initialized
DEBUG - 2011-05-15 18:58:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 18:58:42 --> Database Driver Class Initialized
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 18:58:42 --> Helper loaded: url_helper
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 18:58:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 18:58:42 --> Final output sent to browser
DEBUG - 2011-05-15 18:58:42 --> Total execution time: 0.5751
DEBUG - 2011-05-15 19:48:31 --> Config Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Hooks Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Utf8 Class Initialized
DEBUG - 2011-05-15 19:48:31 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 19:48:31 --> URI Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Router Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Output Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Input Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 19:48:31 --> Language Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Loader Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Controller Class Initialized
ERROR - 2011-05-15 19:48:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 19:48:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 19:48:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 19:48:31 --> Model Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Model Class Initialized
DEBUG - 2011-05-15 19:48:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 19:48:31 --> Database Driver Class Initialized
DEBUG - 2011-05-15 19:48:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 19:48:32 --> Helper loaded: url_helper
DEBUG - 2011-05-15 19:48:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 19:48:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 19:48:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 19:48:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 19:48:32 --> Final output sent to browser
DEBUG - 2011-05-15 19:48:32 --> Total execution time: 0.9906
DEBUG - 2011-05-15 20:06:41 --> Config Class Initialized
DEBUG - 2011-05-15 20:06:41 --> Hooks Class Initialized
DEBUG - 2011-05-15 20:06:41 --> Utf8 Class Initialized
DEBUG - 2011-05-15 20:06:41 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 20:06:41 --> URI Class Initialized
DEBUG - 2011-05-15 20:06:41 --> Router Class Initialized
DEBUG - 2011-05-15 20:06:42 --> No URI present. Default controller set.
DEBUG - 2011-05-15 20:06:42 --> Output Class Initialized
DEBUG - 2011-05-15 20:06:42 --> Input Class Initialized
DEBUG - 2011-05-15 20:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 20:06:42 --> Language Class Initialized
DEBUG - 2011-05-15 20:06:42 --> Loader Class Initialized
DEBUG - 2011-05-15 20:06:42 --> Controller Class Initialized
DEBUG - 2011-05-15 20:06:42 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 20:06:42 --> Helper loaded: url_helper
DEBUG - 2011-05-15 20:06:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 20:06:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 20:06:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 20:06:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 20:06:42 --> Final output sent to browser
DEBUG - 2011-05-15 20:06:42 --> Total execution time: 0.2165
DEBUG - 2011-05-15 21:21:02 --> Config Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Hooks Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Utf8 Class Initialized
DEBUG - 2011-05-15 21:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 21:21:02 --> URI Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Router Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Output Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Input Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 21:21:02 --> Language Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Loader Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Controller Class Initialized
ERROR - 2011-05-15 21:21:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 21:21:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 21:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 21:21:02 --> Model Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Model Class Initialized
DEBUG - 2011-05-15 21:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 21:21:02 --> Database Driver Class Initialized
DEBUG - 2011-05-15 21:21:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 21:21:03 --> Helper loaded: url_helper
DEBUG - 2011-05-15 21:21:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 21:21:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 21:21:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 21:21:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 21:21:03 --> Final output sent to browser
DEBUG - 2011-05-15 21:21:03 --> Total execution time: 0.6866
DEBUG - 2011-05-15 21:21:03 --> Config Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 21:21:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 21:21:03 --> URI Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Router Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Output Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Input Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 21:21:03 --> Language Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Loader Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Controller Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Model Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Model Class Initialized
DEBUG - 2011-05-15 21:21:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 21:21:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 21:21:04 --> Final output sent to browser
DEBUG - 2011-05-15 21:21:04 --> Total execution time: 0.6671
DEBUG - 2011-05-15 21:21:05 --> Config Class Initialized
DEBUG - 2011-05-15 21:21:05 --> Hooks Class Initialized
DEBUG - 2011-05-15 21:21:05 --> Utf8 Class Initialized
DEBUG - 2011-05-15 21:21:05 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 21:21:05 --> URI Class Initialized
DEBUG - 2011-05-15 21:21:05 --> Router Class Initialized
ERROR - 2011-05-15 21:21:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 22:06:14 --> Config Class Initialized
DEBUG - 2011-05-15 22:06:14 --> Hooks Class Initialized
DEBUG - 2011-05-15 22:06:14 --> Utf8 Class Initialized
DEBUG - 2011-05-15 22:06:14 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 22:06:14 --> URI Class Initialized
DEBUG - 2011-05-15 22:06:14 --> Router Class Initialized
ERROR - 2011-05-15 22:06:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-15 22:37:00 --> Config Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Hooks Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Utf8 Class Initialized
DEBUG - 2011-05-15 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 22:37:00 --> URI Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Router Class Initialized
DEBUG - 2011-05-15 22:37:00 --> No URI present. Default controller set.
DEBUG - 2011-05-15 22:37:00 --> Output Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Input Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 22:37:00 --> Language Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Loader Class Initialized
DEBUG - 2011-05-15 22:37:00 --> Controller Class Initialized
DEBUG - 2011-05-15 22:37:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-05-15 22:37:00 --> Helper loaded: url_helper
DEBUG - 2011-05-15 22:37:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 22:37:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 22:37:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 22:37:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 22:37:00 --> Final output sent to browser
DEBUG - 2011-05-15 22:37:00 --> Total execution time: 0.2148
DEBUG - 2011-05-15 23:26:12 --> Config Class Initialized
DEBUG - 2011-05-15 23:26:12 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:26:12 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:26:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:26:12 --> URI Class Initialized
DEBUG - 2011-05-15 23:26:12 --> Router Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Output Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Input Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:26:13 --> Language Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Loader Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Controller Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Model Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Model Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Model Class Initialized
DEBUG - 2011-05-15 23:26:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:26:13 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:26:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 23:26:13 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:26:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:26:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:26:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:26:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:26:13 --> Final output sent to browser
DEBUG - 2011-05-15 23:26:13 --> Total execution time: 0.5727
DEBUG - 2011-05-15 23:26:15 --> Config Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:26:15 --> URI Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Router Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Output Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Input Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:26:15 --> Language Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Loader Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Controller Class Initialized
ERROR - 2011-05-15 23:26:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 23:26:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:26:15 --> Model Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Model Class Initialized
DEBUG - 2011-05-15 23:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:26:15 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:26:15 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:26:15 --> Final output sent to browser
DEBUG - 2011-05-15 23:26:15 --> Total execution time: 0.0824
DEBUG - 2011-05-15 23:37:08 --> Config Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:37:08 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:37:08 --> URI Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Router Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Output Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Input Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:37:08 --> Language Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Loader Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Controller Class Initialized
ERROR - 2011-05-15 23:37:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 23:37:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:37:08 --> Model Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Model Class Initialized
DEBUG - 2011-05-15 23:37:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:37:08 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:37:08 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:37:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:37:08 --> Final output sent to browser
DEBUG - 2011-05-15 23:37:08 --> Total execution time: 0.0299
DEBUG - 2011-05-15 23:37:09 --> Config Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:37:09 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:37:09 --> URI Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Router Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Output Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Input Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:37:09 --> Language Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Loader Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Controller Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Model Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Model Class Initialized
DEBUG - 2011-05-15 23:37:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:37:09 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:37:10 --> Final output sent to browser
DEBUG - 2011-05-15 23:37:10 --> Total execution time: 0.8445
DEBUG - 2011-05-15 23:37:12 --> Config Class Initialized
DEBUG - 2011-05-15 23:37:12 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:37:12 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:37:12 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:37:12 --> URI Class Initialized
DEBUG - 2011-05-15 23:37:12 --> Router Class Initialized
ERROR - 2011-05-15 23:37:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 23:38:03 --> Config Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:38:03 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:38:03 --> URI Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Router Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Output Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Input Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:38:03 --> Language Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Loader Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Controller Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Model Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Model Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Model Class Initialized
DEBUG - 2011-05-15 23:38:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:38:03 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:38:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 23:38:03 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:38:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:38:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:38:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:38:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:38:03 --> Final output sent to browser
DEBUG - 2011-05-15 23:38:03 --> Total execution time: 0.1491
DEBUG - 2011-05-15 23:48:57 --> Config Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:48:57 --> URI Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Router Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Output Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Input Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:48:57 --> Language Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Loader Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Controller Class Initialized
ERROR - 2011-05-15 23:48:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-05-15 23:48:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:48:57 --> Model Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Model Class Initialized
DEBUG - 2011-05-15 23:48:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:48:57 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-05-15 23:48:57 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:48:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:48:57 --> Final output sent to browser
DEBUG - 2011-05-15 23:48:57 --> Total execution time: 0.0300
DEBUG - 2011-05-15 23:49:01 --> Config Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:49:01 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:49:01 --> URI Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Router Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Output Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Input Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:49:01 --> Language Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Loader Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Controller Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Model Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Model Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:49:01 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:49:01 --> Final output sent to browser
DEBUG - 2011-05-15 23:49:01 --> Total execution time: 0.5924
DEBUG - 2011-05-15 23:49:06 --> Config Class Initialized
DEBUG - 2011-05-15 23:49:06 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:49:06 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:49:06 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:49:06 --> URI Class Initialized
DEBUG - 2011-05-15 23:49:06 --> Router Class Initialized
ERROR - 2011-05-15 23:49:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 23:49:47 --> Config Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:49:47 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:49:47 --> URI Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Router Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Output Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Input Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:49:47 --> Language Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Loader Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Controller Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Model Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Model Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Model Class Initialized
DEBUG - 2011-05-15 23:49:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:49:47 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:49:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 23:49:47 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:49:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:49:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:49:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:49:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:49:47 --> Final output sent to browser
DEBUG - 2011-05-15 23:49:47 --> Total execution time: 0.0564
DEBUG - 2011-05-15 23:49:50 --> Config Class Initialized
DEBUG - 2011-05-15 23:49:50 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:49:50 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:49:50 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:49:50 --> URI Class Initialized
DEBUG - 2011-05-15 23:49:50 --> Router Class Initialized
ERROR - 2011-05-15 23:49:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 23:51:20 --> Config Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:51:20 --> URI Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Router Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Output Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Input Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:51:20 --> Language Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Loader Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Controller Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:51:20 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:51:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 23:51:20 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:51:20 --> Final output sent to browser
DEBUG - 2011-05-15 23:51:20 --> Total execution time: 0.0476
DEBUG - 2011-05-15 23:51:23 --> Config Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:51:23 --> URI Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Router Class Initialized
ERROR - 2011-05-15 23:51:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-05-15 23:51:23 --> Config Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:51:23 --> URI Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Router Class Initialized
ERROR - 2011-05-15 23:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-05-15 23:51:23 --> Config Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Hooks Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Utf8 Class Initialized
DEBUG - 2011-05-15 23:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-05-15 23:51:23 --> URI Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Router Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Output Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Input Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-05-15 23:51:23 --> Language Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Loader Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Controller Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Model Class Initialized
DEBUG - 2011-05-15 23:51:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-05-15 23:51:23 --> Database Driver Class Initialized
DEBUG - 2011-05-15 23:51:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-05-15 23:51:23 --> Helper loaded: url_helper
DEBUG - 2011-05-15 23:51:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-05-15 23:51:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-05-15 23:51:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-05-15 23:51:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-05-15 23:51:23 --> Final output sent to browser
DEBUG - 2011-05-15 23:51:23 --> Total execution time: 0.0472

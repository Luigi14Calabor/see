<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-09 01:56:09 --> Config Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Hooks Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Utf8 Class Initialized
DEBUG - 2011-06-09 01:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 01:56:09 --> URI Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Router Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Output Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Input Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 01:56:09 --> Language Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Loader Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Controller Class Initialized
DEBUG - 2011-06-09 01:56:09 --> Model Class Initialized
DEBUG - 2011-06-09 01:56:10 --> Model Class Initialized
DEBUG - 2011-06-09 01:56:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 01:56:10 --> Database Driver Class Initialized
DEBUG - 2011-06-09 01:56:12 --> Final output sent to browser
DEBUG - 2011-06-09 01:56:12 --> Total execution time: 2.4586
DEBUG - 2011-06-09 02:18:00 --> Config Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Hooks Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Utf8 Class Initialized
DEBUG - 2011-06-09 02:18:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 02:18:00 --> URI Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Router Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Output Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Input Class Initialized
DEBUG - 2011-06-09 02:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 02:18:00 --> Language Class Initialized
DEBUG - 2011-06-09 02:18:01 --> Loader Class Initialized
DEBUG - 2011-06-09 02:18:01 --> Controller Class Initialized
DEBUG - 2011-06-09 02:18:01 --> Model Class Initialized
DEBUG - 2011-06-09 02:18:01 --> Model Class Initialized
DEBUG - 2011-06-09 02:18:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 02:18:01 --> Database Driver Class Initialized
DEBUG - 2011-06-09 02:18:04 --> Final output sent to browser
DEBUG - 2011-06-09 02:18:04 --> Total execution time: 3.8562
DEBUG - 2011-06-09 03:29:14 --> Config Class Initialized
DEBUG - 2011-06-09 03:29:14 --> Hooks Class Initialized
DEBUG - 2011-06-09 03:29:14 --> Utf8 Class Initialized
DEBUG - 2011-06-09 03:29:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 03:29:14 --> URI Class Initialized
DEBUG - 2011-06-09 03:29:14 --> Router Class Initialized
ERROR - 2011-06-09 03:29:14 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 03:55:05 --> Config Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Hooks Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Utf8 Class Initialized
DEBUG - 2011-06-09 03:55:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 03:55:05 --> URI Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Router Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Output Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Input Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 03:55:05 --> Language Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Loader Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Controller Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Model Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Model Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Model Class Initialized
DEBUG - 2011-06-09 03:55:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 03:55:05 --> Database Driver Class Initialized
DEBUG - 2011-06-09 03:55:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 03:55:06 --> Helper loaded: url_helper
DEBUG - 2011-06-09 03:55:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 03:55:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 03:55:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 03:55:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 03:55:06 --> Final output sent to browser
DEBUG - 2011-06-09 03:55:06 --> Total execution time: 1.1614
DEBUG - 2011-06-09 05:00:04 --> Config Class Initialized
DEBUG - 2011-06-09 05:00:04 --> Hooks Class Initialized
DEBUG - 2011-06-09 05:00:04 --> Utf8 Class Initialized
DEBUG - 2011-06-09 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 05:00:04 --> URI Class Initialized
DEBUG - 2011-06-09 05:00:04 --> Router Class Initialized
ERROR - 2011-06-09 05:00:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 05:53:13 --> Config Class Initialized
DEBUG - 2011-06-09 05:53:13 --> Hooks Class Initialized
DEBUG - 2011-06-09 05:53:13 --> Utf8 Class Initialized
DEBUG - 2011-06-09 05:53:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 05:53:13 --> URI Class Initialized
DEBUG - 2011-06-09 05:53:13 --> Router Class Initialized
ERROR - 2011-06-09 05:53:13 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 05:59:22 --> Config Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Hooks Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Utf8 Class Initialized
DEBUG - 2011-06-09 05:59:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 05:59:22 --> URI Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Router Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Output Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Input Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 05:59:22 --> Language Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Loader Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Controller Class Initialized
ERROR - 2011-06-09 05:59:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 05:59:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 05:59:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 05:59:22 --> Model Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Model Class Initialized
DEBUG - 2011-06-09 05:59:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 05:59:22 --> Database Driver Class Initialized
DEBUG - 2011-06-09 05:59:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 05:59:23 --> Helper loaded: url_helper
DEBUG - 2011-06-09 05:59:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 05:59:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 05:59:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 05:59:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 05:59:23 --> Final output sent to browser
DEBUG - 2011-06-09 05:59:23 --> Total execution time: 0.9893
DEBUG - 2011-06-09 05:59:26 --> Config Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Hooks Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Utf8 Class Initialized
DEBUG - 2011-06-09 05:59:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 05:59:26 --> URI Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Router Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Output Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Input Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 05:59:26 --> Language Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Loader Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Controller Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Model Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Model Class Initialized
DEBUG - 2011-06-09 05:59:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 05:59:26 --> Database Driver Class Initialized
DEBUG - 2011-06-09 05:59:27 --> Final output sent to browser
DEBUG - 2011-06-09 05:59:27 --> Total execution time: 1.4809
DEBUG - 2011-06-09 05:59:35 --> Config Class Initialized
DEBUG - 2011-06-09 05:59:35 --> Hooks Class Initialized
DEBUG - 2011-06-09 05:59:35 --> Utf8 Class Initialized
DEBUG - 2011-06-09 05:59:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 05:59:35 --> URI Class Initialized
DEBUG - 2011-06-09 05:59:35 --> Router Class Initialized
ERROR - 2011-06-09 05:59:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 06:43:18 --> Config Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Config Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Hooks Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Hooks Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Utf8 Class Initialized
DEBUG - 2011-06-09 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 06:43:18 --> Utf8 Class Initialized
DEBUG - 2011-06-09 06:43:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 06:43:18 --> URI Class Initialized
DEBUG - 2011-06-09 06:43:18 --> URI Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Router Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Router Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Output Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Output Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Input Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Input Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 06:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 06:43:18 --> Language Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Language Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Loader Class Initialized
DEBUG - 2011-06-09 06:43:18 --> Loader Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Controller Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Controller Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Model Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Model Class Initialized
ERROR - 2011-06-09 06:43:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 06:43:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 06:43:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 06:43:19 --> Model Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Model Class Initialized
DEBUG - 2011-06-09 06:43:19 --> Model Class Initialized
DEBUG - 2011-06-09 06:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 06:43:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 06:43:20 --> Database Driver Class Initialized
DEBUG - 2011-06-09 06:43:20 --> Database Driver Class Initialized
DEBUG - 2011-06-09 06:43:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 06:43:22 --> Helper loaded: url_helper
DEBUG - 2011-06-09 06:43:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 06:43:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 06:43:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 06:43:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 06:43:22 --> Final output sent to browser
DEBUG - 2011-06-09 06:43:22 --> Total execution time: 3.8283
DEBUG - 2011-06-09 06:43:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 06:43:31 --> Helper loaded: url_helper
DEBUG - 2011-06-09 06:43:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 06:43:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 06:43:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 06:43:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 06:43:31 --> Final output sent to browser
DEBUG - 2011-06-09 06:43:31 --> Total execution time: 12.9417
DEBUG - 2011-06-09 07:50:00 --> Config Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Hooks Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Utf8 Class Initialized
DEBUG - 2011-06-09 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 07:50:00 --> URI Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Router Class Initialized
ERROR - 2011-06-09 07:50:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 07:50:00 --> Config Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Hooks Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Utf8 Class Initialized
DEBUG - 2011-06-09 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 07:50:00 --> URI Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Router Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Output Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Input Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 07:50:00 --> Language Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Loader Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Controller Class Initialized
ERROR - 2011-06-09 07:50:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 07:50:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 07:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 07:50:00 --> Model Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Model Class Initialized
DEBUG - 2011-06-09 07:50:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 07:50:00 --> Database Driver Class Initialized
DEBUG - 2011-06-09 07:50:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 07:50:01 --> Helper loaded: url_helper
DEBUG - 2011-06-09 07:50:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 07:50:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 07:50:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 07:50:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 07:50:01 --> Final output sent to browser
DEBUG - 2011-06-09 07:50:01 --> Total execution time: 0.2772
DEBUG - 2011-06-09 08:08:01 --> Config Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:08:01 --> URI Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Router Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Output Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Input Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:08:01 --> Language Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Loader Class Initialized
DEBUG - 2011-06-09 08:08:01 --> Controller Class Initialized
DEBUG - 2011-06-09 08:08:02 --> Model Class Initialized
DEBUG - 2011-06-09 08:08:02 --> Model Class Initialized
DEBUG - 2011-06-09 08:08:02 --> Model Class Initialized
DEBUG - 2011-06-09 08:08:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:08:02 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:08:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:08:02 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:08:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:08:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:08:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:08:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:08:02 --> Final output sent to browser
DEBUG - 2011-06-09 08:08:02 --> Total execution time: 0.7025
DEBUG - 2011-06-09 08:08:03 --> Config Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:08:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:08:03 --> URI Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Router Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Output Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Input Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:08:03 --> Language Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Loader Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Controller Class Initialized
ERROR - 2011-06-09 08:08:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 08:08:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 08:08:03 --> Model Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Model Class Initialized
DEBUG - 2011-06-09 08:08:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:08:03 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 08:08:03 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:08:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:08:03 --> Final output sent to browser
DEBUG - 2011-06-09 08:08:03 --> Total execution time: 0.0989
DEBUG - 2011-06-09 08:36:22 --> Config Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:36:22 --> URI Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Router Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Output Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Input Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:36:22 --> Language Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Loader Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Controller Class Initialized
DEBUG - 2011-06-09 08:36:22 --> Model Class Initialized
DEBUG - 2011-06-09 08:36:23 --> Model Class Initialized
DEBUG - 2011-06-09 08:36:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:36:23 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:36:23 --> Final output sent to browser
DEBUG - 2011-06-09 08:36:23 --> Total execution time: 0.9828
DEBUG - 2011-06-09 08:37:24 --> Config Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:37:24 --> URI Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Router Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Output Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Input Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:37:24 --> Language Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Loader Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Controller Class Initialized
ERROR - 2011-06-09 08:37:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 08:37:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 08:37:24 --> Model Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Model Class Initialized
DEBUG - 2011-06-09 08:37:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:37:24 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 08:37:24 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:37:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:37:24 --> Final output sent to browser
DEBUG - 2011-06-09 08:37:24 --> Total execution time: 0.2176
DEBUG - 2011-06-09 08:37:27 --> Config Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:37:27 --> URI Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Router Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Output Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Input Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:37:27 --> Language Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Loader Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Controller Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Model Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Model Class Initialized
DEBUG - 2011-06-09 08:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:37:27 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:37:28 --> Final output sent to browser
DEBUG - 2011-06-09 08:37:28 --> Total execution time: 0.6731
DEBUG - 2011-06-09 08:37:35 --> Config Class Initialized
DEBUG - 2011-06-09 08:37:35 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:37:35 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:37:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:37:35 --> URI Class Initialized
DEBUG - 2011-06-09 08:37:35 --> Router Class Initialized
ERROR - 2011-06-09 08:37:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 08:57:43 --> Config Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:57:43 --> URI Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Router Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Output Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Input Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:57:43 --> Language Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Loader Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Controller Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Model Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Model Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Model Class Initialized
DEBUG - 2011-06-09 08:57:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:57:43 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:57:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:57:43 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:57:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:57:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:57:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:57:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:57:43 --> Final output sent to browser
DEBUG - 2011-06-09 08:57:43 --> Total execution time: 0.8221
DEBUG - 2011-06-09 08:57:49 --> Config Class Initialized
DEBUG - 2011-06-09 08:57:49 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:57:49 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:57:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:57:49 --> URI Class Initialized
DEBUG - 2011-06-09 08:57:49 --> Router Class Initialized
ERROR - 2011-06-09 08:57:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 08:58:12 --> Config Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:58:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:58:12 --> URI Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Router Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Output Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Input Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:58:12 --> Language Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Loader Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Controller Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:58:12 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:58:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:58:13 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:58:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:58:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:58:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:58:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:58:13 --> Final output sent to browser
DEBUG - 2011-06-09 08:58:13 --> Total execution time: 0.1968
DEBUG - 2011-06-09 08:58:15 --> Config Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:58:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:58:15 --> URI Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Router Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Output Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Input Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:58:15 --> Language Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Loader Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Controller Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:58:15 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:58:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:58:15 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:58:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:58:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:58:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:58:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:58:15 --> Final output sent to browser
DEBUG - 2011-06-09 08:58:15 --> Total execution time: 0.0688
DEBUG - 2011-06-09 08:58:17 --> Config Class Initialized
DEBUG - 2011-06-09 08:58:17 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:58:17 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:58:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:58:17 --> URI Class Initialized
DEBUG - 2011-06-09 08:58:17 --> Router Class Initialized
ERROR - 2011-06-09 08:58:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 08:58:24 --> Config Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:58:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:58:24 --> URI Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Router Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Output Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Input Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:58:24 --> Language Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Loader Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Controller Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:58:24 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:58:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:58:26 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:58:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:58:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:58:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:58:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:58:26 --> Final output sent to browser
DEBUG - 2011-06-09 08:58:26 --> Total execution time: 1.8709
DEBUG - 2011-06-09 08:58:36 --> Config Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Hooks Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Utf8 Class Initialized
DEBUG - 2011-06-09 08:58:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 08:58:36 --> URI Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Router Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Output Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Input Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 08:58:36 --> Language Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Loader Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Controller Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Model Class Initialized
DEBUG - 2011-06-09 08:58:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 08:58:36 --> Database Driver Class Initialized
DEBUG - 2011-06-09 08:58:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 08:58:36 --> Helper loaded: url_helper
DEBUG - 2011-06-09 08:58:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 08:58:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 08:58:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 08:58:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 08:58:36 --> Final output sent to browser
DEBUG - 2011-06-09 08:58:36 --> Total execution time: 0.2128
DEBUG - 2011-06-09 09:24:54 --> Config Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Hooks Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Utf8 Class Initialized
DEBUG - 2011-06-09 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 09:24:54 --> URI Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Router Class Initialized
DEBUG - 2011-06-09 09:24:54 --> No URI present. Default controller set.
DEBUG - 2011-06-09 09:24:54 --> Output Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Input Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 09:24:54 --> Language Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Loader Class Initialized
DEBUG - 2011-06-09 09:24:54 --> Controller Class Initialized
DEBUG - 2011-06-09 09:24:54 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-09 09:24:54 --> Helper loaded: url_helper
DEBUG - 2011-06-09 09:24:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 09:24:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 09:24:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 09:24:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 09:24:54 --> Final output sent to browser
DEBUG - 2011-06-09 09:24:54 --> Total execution time: 0.2080
DEBUG - 2011-06-09 09:29:55 --> Config Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Hooks Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Utf8 Class Initialized
DEBUG - 2011-06-09 09:29:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 09:29:55 --> URI Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Router Class Initialized
DEBUG - 2011-06-09 09:29:55 --> No URI present. Default controller set.
DEBUG - 2011-06-09 09:29:55 --> Output Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Input Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 09:29:55 --> Language Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Loader Class Initialized
DEBUG - 2011-06-09 09:29:55 --> Controller Class Initialized
DEBUG - 2011-06-09 09:29:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-09 09:29:55 --> Helper loaded: url_helper
DEBUG - 2011-06-09 09:29:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 09:29:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 09:29:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 09:29:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 09:29:55 --> Final output sent to browser
DEBUG - 2011-06-09 09:29:55 --> Total execution time: 0.0540
DEBUG - 2011-06-09 12:05:53 --> Config Class Initialized
DEBUG - 2011-06-09 12:05:53 --> Hooks Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Utf8 Class Initialized
DEBUG - 2011-06-09 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 12:05:54 --> URI Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Router Class Initialized
ERROR - 2011-06-09 12:05:54 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 12:05:54 --> Config Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Hooks Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Utf8 Class Initialized
DEBUG - 2011-06-09 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 12:05:54 --> URI Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Router Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Output Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Input Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 12:05:54 --> Language Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Loader Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Controller Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Model Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Model Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Model Class Initialized
DEBUG - 2011-06-09 12:05:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 12:05:54 --> Database Driver Class Initialized
DEBUG - 2011-06-09 12:05:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 12:05:55 --> Helper loaded: url_helper
DEBUG - 2011-06-09 12:05:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 12:05:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 12:05:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 12:05:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 12:05:55 --> Final output sent to browser
DEBUG - 2011-06-09 12:05:55 --> Total execution time: 1.3021
DEBUG - 2011-06-09 12:06:26 --> Config Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Hooks Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Utf8 Class Initialized
DEBUG - 2011-06-09 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 12:06:26 --> URI Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Router Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Output Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Input Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 12:06:26 --> Language Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Loader Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Controller Class Initialized
ERROR - 2011-06-09 12:06:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 12:06:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 12:06:26 --> Model Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Model Class Initialized
DEBUG - 2011-06-09 12:06:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 12:06:26 --> Database Driver Class Initialized
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 12:06:26 --> Helper loaded: url_helper
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 12:06:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 12:06:26 --> Final output sent to browser
DEBUG - 2011-06-09 12:06:26 --> Total execution time: 0.1057
DEBUG - 2011-06-09 13:59:02 --> Config Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Hooks Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Utf8 Class Initialized
DEBUG - 2011-06-09 13:59:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 13:59:02 --> URI Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Router Class Initialized
DEBUG - 2011-06-09 13:59:02 --> No URI present. Default controller set.
DEBUG - 2011-06-09 13:59:02 --> Output Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Input Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 13:59:02 --> Language Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Loader Class Initialized
DEBUG - 2011-06-09 13:59:02 --> Controller Class Initialized
DEBUG - 2011-06-09 13:59:02 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-09 13:59:02 --> Helper loaded: url_helper
DEBUG - 2011-06-09 13:59:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 13:59:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 13:59:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 13:59:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 13:59:02 --> Final output sent to browser
DEBUG - 2011-06-09 13:59:02 --> Total execution time: 0.2813
DEBUG - 2011-06-09 14:48:43 --> Config Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Hooks Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Utf8 Class Initialized
DEBUG - 2011-06-09 14:48:43 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 14:48:43 --> URI Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Router Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Output Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Input Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 14:48:43 --> Language Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Loader Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Controller Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Model Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Model Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Model Class Initialized
DEBUG - 2011-06-09 14:48:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 14:48:43 --> Database Driver Class Initialized
DEBUG - 2011-06-09 14:48:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 14:48:44 --> Helper loaded: url_helper
DEBUG - 2011-06-09 14:48:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 14:48:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 14:48:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 14:48:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 14:48:44 --> Final output sent to browser
DEBUG - 2011-06-09 14:48:44 --> Total execution time: 0.4909
DEBUG - 2011-06-09 14:48:55 --> Config Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Hooks Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Utf8 Class Initialized
DEBUG - 2011-06-09 14:48:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 14:48:55 --> URI Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Router Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Output Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Input Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 14:48:55 --> Language Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Loader Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Controller Class Initialized
ERROR - 2011-06-09 14:48:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 14:48:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 14:48:55 --> Model Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Model Class Initialized
DEBUG - 2011-06-09 14:48:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 14:48:55 --> Database Driver Class Initialized
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 14:48:55 --> Helper loaded: url_helper
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 14:48:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 14:48:55 --> Final output sent to browser
DEBUG - 2011-06-09 14:48:55 --> Total execution time: 0.0933
DEBUG - 2011-06-09 14:54:22 --> Config Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Hooks Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Utf8 Class Initialized
DEBUG - 2011-06-09 14:54:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 14:54:22 --> URI Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Router Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Output Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Input Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 14:54:22 --> Language Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Loader Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Controller Class Initialized
ERROR - 2011-06-09 14:54:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 14:54:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 14:54:22 --> Model Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Model Class Initialized
DEBUG - 2011-06-09 14:54:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 14:54:22 --> Database Driver Class Initialized
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 14:54:22 --> Helper loaded: url_helper
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 14:54:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 14:54:22 --> Final output sent to browser
DEBUG - 2011-06-09 14:54:22 --> Total execution time: 0.0277
DEBUG - 2011-06-09 14:54:23 --> Config Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Hooks Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Utf8 Class Initialized
DEBUG - 2011-06-09 14:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 14:54:23 --> URI Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Router Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Output Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Input Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 14:54:23 --> Language Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Loader Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Controller Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Model Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Model Class Initialized
DEBUG - 2011-06-09 14:54:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 14:54:23 --> Database Driver Class Initialized
DEBUG - 2011-06-09 14:54:24 --> Final output sent to browser
DEBUG - 2011-06-09 14:54:24 --> Total execution time: 0.6723
DEBUG - 2011-06-09 14:54:25 --> Config Class Initialized
DEBUG - 2011-06-09 14:54:25 --> Hooks Class Initialized
DEBUG - 2011-06-09 14:54:25 --> Utf8 Class Initialized
DEBUG - 2011-06-09 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 14:54:25 --> URI Class Initialized
DEBUG - 2011-06-09 14:54:25 --> Router Class Initialized
ERROR - 2011-06-09 14:54:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 15:13:17 --> Config Class Initialized
DEBUG - 2011-06-09 15:13:17 --> Hooks Class Initialized
DEBUG - 2011-06-09 15:13:17 --> Utf8 Class Initialized
DEBUG - 2011-06-09 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 15:13:17 --> URI Class Initialized
DEBUG - 2011-06-09 15:13:17 --> Router Class Initialized
ERROR - 2011-06-09 15:13:17 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 15:14:12 --> Config Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Hooks Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Utf8 Class Initialized
DEBUG - 2011-06-09 15:14:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 15:14:12 --> URI Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Router Class Initialized
DEBUG - 2011-06-09 15:14:12 --> No URI present. Default controller set.
DEBUG - 2011-06-09 15:14:12 --> Output Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Input Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 15:14:12 --> Language Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Loader Class Initialized
DEBUG - 2011-06-09 15:14:12 --> Controller Class Initialized
DEBUG - 2011-06-09 15:14:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-09 15:14:12 --> Helper loaded: url_helper
DEBUG - 2011-06-09 15:14:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 15:14:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 15:14:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 15:14:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 15:14:12 --> Final output sent to browser
DEBUG - 2011-06-09 15:14:12 --> Total execution time: 0.1119
DEBUG - 2011-06-09 15:41:48 --> Config Class Initialized
DEBUG - 2011-06-09 15:41:49 --> Hooks Class Initialized
DEBUG - 2011-06-09 15:41:49 --> Utf8 Class Initialized
DEBUG - 2011-06-09 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 15:41:49 --> URI Class Initialized
DEBUG - 2011-06-09 15:41:49 --> Router Class Initialized
ERROR - 2011-06-09 15:41:49 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 15:41:50 --> Config Class Initialized
DEBUG - 2011-06-09 15:41:50 --> Hooks Class Initialized
DEBUG - 2011-06-09 15:41:50 --> Utf8 Class Initialized
DEBUG - 2011-06-09 15:41:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 15:41:50 --> URI Class Initialized
DEBUG - 2011-06-09 15:41:50 --> Router Class Initialized
DEBUG - 2011-06-09 15:41:51 --> Output Class Initialized
DEBUG - 2011-06-09 15:41:51 --> Input Class Initialized
DEBUG - 2011-06-09 15:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 15:41:52 --> Language Class Initialized
DEBUG - 2011-06-09 15:41:53 --> Loader Class Initialized
DEBUG - 2011-06-09 15:41:53 --> Controller Class Initialized
ERROR - 2011-06-09 15:41:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 15:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 15:41:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 15:41:54 --> Model Class Initialized
DEBUG - 2011-06-09 15:41:54 --> Model Class Initialized
DEBUG - 2011-06-09 15:41:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 15:41:55 --> Database Driver Class Initialized
DEBUG - 2011-06-09 15:41:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 15:41:56 --> Helper loaded: url_helper
DEBUG - 2011-06-09 15:41:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 15:41:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 15:41:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 15:41:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 15:41:56 --> Final output sent to browser
DEBUG - 2011-06-09 15:41:56 --> Total execution time: 5.9046
DEBUG - 2011-06-09 16:37:34 --> Config Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Hooks Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Utf8 Class Initialized
DEBUG - 2011-06-09 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 16:37:34 --> URI Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Router Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Output Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Input Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 16:37:34 --> Language Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Loader Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Controller Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Model Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Model Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Model Class Initialized
DEBUG - 2011-06-09 16:37:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 16:37:34 --> Database Driver Class Initialized
DEBUG - 2011-06-09 16:37:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 16:37:34 --> Helper loaded: url_helper
DEBUG - 2011-06-09 16:37:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 16:37:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 16:37:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 16:37:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 16:37:34 --> Final output sent to browser
DEBUG - 2011-06-09 16:37:34 --> Total execution time: 0.5489
DEBUG - 2011-06-09 17:41:57 --> Config Class Initialized
DEBUG - 2011-06-09 17:41:57 --> Hooks Class Initialized
DEBUG - 2011-06-09 17:41:57 --> Utf8 Class Initialized
DEBUG - 2011-06-09 17:41:57 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 17:41:57 --> URI Class Initialized
DEBUG - 2011-06-09 17:41:57 --> Router Class Initialized
ERROR - 2011-06-09 17:41:57 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 17:41:59 --> Config Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Hooks Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Utf8 Class Initialized
DEBUG - 2011-06-09 17:41:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 17:41:59 --> URI Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Router Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Output Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Input Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 17:41:59 --> Language Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Loader Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Controller Class Initialized
ERROR - 2011-06-09 17:41:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 17:41:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 17:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 17:41:59 --> Model Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Model Class Initialized
DEBUG - 2011-06-09 17:41:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 17:41:59 --> Database Driver Class Initialized
DEBUG - 2011-06-09 17:41:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 17:42:00 --> Helper loaded: url_helper
DEBUG - 2011-06-09 17:42:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 17:42:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 17:42:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 17:42:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 17:42:00 --> Final output sent to browser
DEBUG - 2011-06-09 17:42:00 --> Total execution time: 0.2146
DEBUG - 2011-06-09 18:33:20 --> Config Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Hooks Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Utf8 Class Initialized
DEBUG - 2011-06-09 18:33:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 18:33:20 --> URI Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Router Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Output Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Input Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 18:33:20 --> Language Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Loader Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Controller Class Initialized
ERROR - 2011-06-09 18:33:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 18:33:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 18:33:20 --> Model Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Model Class Initialized
DEBUG - 2011-06-09 18:33:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 18:33:20 --> Database Driver Class Initialized
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 18:33:20 --> Helper loaded: url_helper
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 18:33:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 18:33:20 --> Final output sent to browser
DEBUG - 2011-06-09 18:33:20 --> Total execution time: 0.2533
DEBUG - 2011-06-09 19:32:19 --> Config Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Hooks Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Utf8 Class Initialized
DEBUG - 2011-06-09 19:32:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 19:32:19 --> URI Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Router Class Initialized
DEBUG - 2011-06-09 19:32:19 --> No URI present. Default controller set.
DEBUG - 2011-06-09 19:32:19 --> Output Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Input Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 19:32:19 --> Language Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Loader Class Initialized
DEBUG - 2011-06-09 19:32:19 --> Controller Class Initialized
DEBUG - 2011-06-09 19:32:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-09 19:32:19 --> Helper loaded: url_helper
DEBUG - 2011-06-09 19:32:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 19:32:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 19:32:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 19:32:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 19:32:19 --> Final output sent to browser
DEBUG - 2011-06-09 19:32:19 --> Total execution time: 0.3415
DEBUG - 2011-06-09 19:32:21 --> Config Class Initialized
DEBUG - 2011-06-09 19:32:21 --> Hooks Class Initialized
DEBUG - 2011-06-09 19:32:21 --> Utf8 Class Initialized
DEBUG - 2011-06-09 19:32:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 19:32:21 --> URI Class Initialized
DEBUG - 2011-06-09 19:32:21 --> Router Class Initialized
ERROR - 2011-06-09 19:32:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 19:32:22 --> Config Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Hooks Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Utf8 Class Initialized
DEBUG - 2011-06-09 19:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 19:32:22 --> URI Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Router Class Initialized
ERROR - 2011-06-09 19:32:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 19:32:22 --> Config Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Hooks Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Utf8 Class Initialized
DEBUG - 2011-06-09 19:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 19:32:22 --> URI Class Initialized
DEBUG - 2011-06-09 19:32:22 --> Router Class Initialized
ERROR - 2011-06-09 19:32:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-09 22:21:10 --> Config Class Initialized
DEBUG - 2011-06-09 22:21:10 --> Hooks Class Initialized
DEBUG - 2011-06-09 22:21:10 --> Utf8 Class Initialized
DEBUG - 2011-06-09 22:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 22:21:10 --> URI Class Initialized
DEBUG - 2011-06-09 22:21:10 --> Router Class Initialized
ERROR - 2011-06-09 22:21:10 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 23:18:45 --> Config Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:18:45 --> URI Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Router Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Output Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Input Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 23:18:45 --> Language Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Loader Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Controller Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Model Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Model Class Initialized
DEBUG - 2011-06-09 23:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 23:18:46 --> Database Driver Class Initialized
DEBUG - 2011-06-09 23:18:46 --> Final output sent to browser
DEBUG - 2011-06-09 23:18:46 --> Total execution time: 2.2008
DEBUG - 2011-06-09 23:29:34 --> Config Class Initialized
DEBUG - 2011-06-09 23:29:34 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:29:34 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:29:34 --> URI Class Initialized
DEBUG - 2011-06-09 23:29:34 --> Router Class Initialized
ERROR - 2011-06-09 23:29:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 23:38:40 --> Config Class Initialized
DEBUG - 2011-06-09 23:38:40 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:38:40 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:38:40 --> URI Class Initialized
DEBUG - 2011-06-09 23:38:40 --> Router Class Initialized
ERROR - 2011-06-09 23:38:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-09 23:39:58 --> Config Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:39:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:39:58 --> URI Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Router Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Output Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Input Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 23:39:58 --> Language Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Loader Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Controller Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Model Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Model Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Model Class Initialized
DEBUG - 2011-06-09 23:39:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 23:39:58 --> Database Driver Class Initialized
DEBUG - 2011-06-09 23:39:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-09 23:39:59 --> Helper loaded: url_helper
DEBUG - 2011-06-09 23:39:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 23:39:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 23:39:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 23:39:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 23:39:59 --> Final output sent to browser
DEBUG - 2011-06-09 23:39:59 --> Total execution time: 0.6994
DEBUG - 2011-06-09 23:41:11 --> Config Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:41:11 --> URI Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Router Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Output Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Input Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 23:41:11 --> Language Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Loader Class Initialized
DEBUG - 2011-06-09 23:41:11 --> Controller Class Initialized
ERROR - 2011-06-09 23:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 23:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 23:41:12 --> Model Class Initialized
DEBUG - 2011-06-09 23:41:12 --> Model Class Initialized
DEBUG - 2011-06-09 23:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 23:41:12 --> Database Driver Class Initialized
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 23:41:12 --> Helper loaded: url_helper
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 23:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 23:41:12 --> Final output sent to browser
DEBUG - 2011-06-09 23:41:12 --> Total execution time: 0.2365
DEBUG - 2011-06-09 23:57:53 --> Config Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Hooks Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Utf8 Class Initialized
DEBUG - 2011-06-09 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-09 23:57:53 --> URI Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Router Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Output Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Input Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-09 23:57:53 --> Language Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Loader Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Controller Class Initialized
ERROR - 2011-06-09 23:57:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-09 23:57:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 23:57:53 --> Model Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Model Class Initialized
DEBUG - 2011-06-09 23:57:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-09 23:57:53 --> Database Driver Class Initialized
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-09 23:57:53 --> Helper loaded: url_helper
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-09 23:57:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-09 23:57:53 --> Final output sent to browser
DEBUG - 2011-06-09 23:57:53 --> Total execution time: 0.2455

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-19 02:05:58 --> Config Class Initialized
DEBUG - 2011-06-19 02:05:58 --> Hooks Class Initialized
DEBUG - 2011-06-19 02:05:58 --> Utf8 Class Initialized
DEBUG - 2011-06-19 02:05:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 02:05:58 --> URI Class Initialized
DEBUG - 2011-06-19 02:05:58 --> Router Class Initialized
ERROR - 2011-06-19 02:05:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-19 02:06:01 --> Config Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Hooks Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Utf8 Class Initialized
DEBUG - 2011-06-19 02:06:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 02:06:01 --> URI Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Router Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Output Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Input Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 02:06:01 --> Language Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Loader Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Controller Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Model Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Model Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Model Class Initialized
DEBUG - 2011-06-19 02:06:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 02:06:01 --> Database Driver Class Initialized
DEBUG - 2011-06-19 02:06:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 02:06:02 --> Helper loaded: url_helper
DEBUG - 2011-06-19 02:06:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 02:06:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 02:06:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 02:06:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 02:06:02 --> Final output sent to browser
DEBUG - 2011-06-19 02:06:02 --> Total execution time: 1.6275
DEBUG - 2011-06-19 02:28:49 --> Config Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Hooks Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Utf8 Class Initialized
DEBUG - 2011-06-19 02:28:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 02:28:49 --> URI Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Router Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Output Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Input Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 02:28:49 --> Language Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Loader Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Controller Class Initialized
ERROR - 2011-06-19 02:28:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 02:28:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 02:28:49 --> Model Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Model Class Initialized
DEBUG - 2011-06-19 02:28:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 02:28:49 --> Database Driver Class Initialized
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 02:28:49 --> Helper loaded: url_helper
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 02:28:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 02:28:49 --> Final output sent to browser
DEBUG - 2011-06-19 02:28:49 --> Total execution time: 0.4308
DEBUG - 2011-06-19 04:00:48 --> Config Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Hooks Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Utf8 Class Initialized
DEBUG - 2011-06-19 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 04:00:49 --> URI Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Router Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Output Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Input Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 04:00:49 --> Language Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Loader Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Controller Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Model Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Model Class Initialized
DEBUG - 2011-06-19 04:00:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 04:00:49 --> Database Driver Class Initialized
DEBUG - 2011-06-19 04:00:50 --> Final output sent to browser
DEBUG - 2011-06-19 04:00:50 --> Total execution time: 1.5010
DEBUG - 2011-06-19 05:07:06 --> Config Class Initialized
DEBUG - 2011-06-19 05:07:06 --> Hooks Class Initialized
DEBUG - 2011-06-19 05:07:06 --> Utf8 Class Initialized
DEBUG - 2011-06-19 05:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 05:07:06 --> URI Class Initialized
DEBUG - 2011-06-19 05:07:06 --> Router Class Initialized
ERROR - 2011-06-19 05:07:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-19 06:38:10 --> Config Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 06:38:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 06:38:10 --> URI Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Router Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Output Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Input Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 06:38:10 --> Language Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Loader Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Controller Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Model Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Model Class Initialized
DEBUG - 2011-06-19 06:38:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 06:38:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 06:38:11 --> Final output sent to browser
DEBUG - 2011-06-19 06:38:11 --> Total execution time: 1.2483
DEBUG - 2011-06-19 07:38:30 --> Config Class Initialized
DEBUG - 2011-06-19 07:38:30 --> Hooks Class Initialized
DEBUG - 2011-06-19 07:38:30 --> Utf8 Class Initialized
DEBUG - 2011-06-19 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 07:38:30 --> URI Class Initialized
DEBUG - 2011-06-19 07:38:30 --> Router Class Initialized
ERROR - 2011-06-19 07:38:30 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-19 09:12:44 --> Config Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:12:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:12:44 --> URI Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Router Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Output Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Input Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 09:12:44 --> Language Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Loader Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Controller Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Model Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Model Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Model Class Initialized
DEBUG - 2011-06-19 09:12:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 09:12:44 --> Database Driver Class Initialized
DEBUG - 2011-06-19 09:12:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 09:12:45 --> Helper loaded: url_helper
DEBUG - 2011-06-19 09:12:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 09:12:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 09:12:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 09:12:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 09:12:46 --> Final output sent to browser
DEBUG - 2011-06-19 09:12:46 --> Total execution time: 1.2239
DEBUG - 2011-06-19 09:12:48 --> Config Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:12:48 --> URI Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Router Class Initialized
ERROR - 2011-06-19 09:12:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 09:12:48 --> Config Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:12:48 --> URI Class Initialized
DEBUG - 2011-06-19 09:12:48 --> Router Class Initialized
ERROR - 2011-06-19 09:12:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 09:12:49 --> Config Class Initialized
DEBUG - 2011-06-19 09:12:49 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:12:49 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:12:49 --> URI Class Initialized
DEBUG - 2011-06-19 09:12:49 --> Router Class Initialized
ERROR - 2011-06-19 09:12:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 09:15:18 --> Config Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:15:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:15:18 --> URI Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Router Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Output Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Input Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 09:15:18 --> Language Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Loader Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Controller Class Initialized
ERROR - 2011-06-19 09:15:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 09:15:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 09:15:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 09:15:18 --> Model Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Model Class Initialized
DEBUG - 2011-06-19 09:15:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 09:15:18 --> Database Driver Class Initialized
DEBUG - 2011-06-19 09:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 09:15:19 --> Helper loaded: url_helper
DEBUG - 2011-06-19 09:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 09:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 09:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 09:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 09:15:19 --> Final output sent to browser
DEBUG - 2011-06-19 09:15:19 --> Total execution time: 0.2308
DEBUG - 2011-06-19 09:15:20 --> Config Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 09:15:20 --> URI Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Router Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Output Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Input Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 09:15:20 --> Language Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Loader Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Controller Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Model Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Model Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 09:15:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 09:15:20 --> Final output sent to browser
DEBUG - 2011-06-19 09:15:20 --> Total execution time: 0.8841
DEBUG - 2011-06-19 12:21:17 --> Config Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Hooks Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Utf8 Class Initialized
DEBUG - 2011-06-19 12:21:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 12:21:17 --> URI Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Router Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Output Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Input Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 12:21:17 --> Language Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Loader Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Controller Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Model Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Model Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 12:21:17 --> Database Driver Class Initialized
DEBUG - 2011-06-19 12:21:17 --> Final output sent to browser
DEBUG - 2011-06-19 12:21:17 --> Total execution time: 0.9477
DEBUG - 2011-06-19 13:32:48 --> Config Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:32:48 --> URI Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Router Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Output Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Input Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 13:32:48 --> Language Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Loader Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Controller Class Initialized
ERROR - 2011-06-19 13:32:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 13:32:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 13:32:48 --> Model Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Model Class Initialized
DEBUG - 2011-06-19 13:32:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 13:32:48 --> Database Driver Class Initialized
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 13:32:48 --> Helper loaded: url_helper
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 13:32:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 13:32:48 --> Final output sent to browser
DEBUG - 2011-06-19 13:32:48 --> Total execution time: 0.3092
DEBUG - 2011-06-19 13:32:49 --> Config Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:32:49 --> URI Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Router Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Output Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Input Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 13:32:49 --> Language Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Loader Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Controller Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Model Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Model Class Initialized
DEBUG - 2011-06-19 13:32:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 13:32:49 --> Database Driver Class Initialized
DEBUG - 2011-06-19 13:32:50 --> Final output sent to browser
DEBUG - 2011-06-19 13:32:50 --> Total execution time: 0.6018
DEBUG - 2011-06-19 13:32:51 --> Config Class Initialized
DEBUG - 2011-06-19 13:32:51 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:32:51 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:32:51 --> URI Class Initialized
DEBUG - 2011-06-19 13:32:51 --> Router Class Initialized
ERROR - 2011-06-19 13:32:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 13:35:51 --> Config Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:35:51 --> URI Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Router Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Output Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Input Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 13:35:51 --> Language Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Loader Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Controller Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Model Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Model Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Model Class Initialized
DEBUG - 2011-06-19 13:35:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 13:35:51 --> Database Driver Class Initialized
DEBUG - 2011-06-19 13:35:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 13:35:51 --> Helper loaded: url_helper
DEBUG - 2011-06-19 13:35:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 13:35:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 13:35:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 13:35:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 13:35:51 --> Final output sent to browser
DEBUG - 2011-06-19 13:35:51 --> Total execution time: 0.2697
DEBUG - 2011-06-19 13:35:54 --> Config Class Initialized
DEBUG - 2011-06-19 13:35:54 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:35:54 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:35:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:35:54 --> URI Class Initialized
DEBUG - 2011-06-19 13:35:54 --> Router Class Initialized
ERROR - 2011-06-19 13:35:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 13:35:55 --> Config Class Initialized
DEBUG - 2011-06-19 13:35:55 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:35:55 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:35:55 --> URI Class Initialized
DEBUG - 2011-06-19 13:35:55 --> Router Class Initialized
ERROR - 2011-06-19 13:35:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 13:40:01 --> Config Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Hooks Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Utf8 Class Initialized
DEBUG - 2011-06-19 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 13:40:01 --> URI Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Router Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Output Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Input Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 13:40:01 --> Language Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Loader Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Controller Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Model Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Model Class Initialized
DEBUG - 2011-06-19 13:40:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 13:40:01 --> Database Driver Class Initialized
DEBUG - 2011-06-19 13:40:02 --> Final output sent to browser
DEBUG - 2011-06-19 13:40:02 --> Total execution time: 0.8116
DEBUG - 2011-06-19 15:13:22 --> Config Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:13:22 --> URI Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Router Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Output Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Input Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:13:22 --> Language Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Loader Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Controller Class Initialized
ERROR - 2011-06-19 15:13:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:13:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:13:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:13:22 --> Model Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Model Class Initialized
DEBUG - 2011-06-19 15:13:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:13:23 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:13:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:13:23 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:13:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:13:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:13:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:13:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:13:23 --> Final output sent to browser
DEBUG - 2011-06-19 15:13:23 --> Total execution time: 0.3652
DEBUG - 2011-06-19 15:13:41 --> Config Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:13:41 --> URI Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Router Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Output Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Input Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:13:41 --> Language Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Loader Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Controller Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Model Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Model Class Initialized
DEBUG - 2011-06-19 15:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:13:41 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:13:42 --> Final output sent to browser
DEBUG - 2011-06-19 15:13:42 --> Total execution time: 0.7267
DEBUG - 2011-06-19 15:14:06 --> Config Class Initialized
DEBUG - 2011-06-19 15:14:06 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:14:06 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:14:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:14:06 --> URI Class Initialized
DEBUG - 2011-06-19 15:14:06 --> Router Class Initialized
ERROR - 2011-06-19 15:14:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 15:15:14 --> Config Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:15:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:15:14 --> URI Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Router Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Output Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Input Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:15:14 --> Language Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Loader Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Controller Class Initialized
ERROR - 2011-06-19 15:15:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:15:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:15:14 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:15:14 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:15:14 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:15:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:15:14 --> Final output sent to browser
DEBUG - 2011-06-19 15:15:14 --> Total execution time: 0.0280
DEBUG - 2011-06-19 15:15:15 --> Config Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:15:15 --> URI Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Router Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Output Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Input Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:15:15 --> Language Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Loader Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Controller Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:15:15 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:15:16 --> Final output sent to browser
DEBUG - 2011-06-19 15:15:16 --> Total execution time: 0.6161
DEBUG - 2011-06-19 15:15:19 --> Config Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:15:19 --> URI Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Router Class Initialized
ERROR - 2011-06-19 15:15:19 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-19 15:15:19 --> Config Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:15:19 --> URI Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Router Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Output Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Input Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:15:19 --> Language Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Loader Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Controller Class Initialized
ERROR - 2011-06-19 15:15:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:15:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:15:19 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Model Class Initialized
DEBUG - 2011-06-19 15:15:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:15:19 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:15:19 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:15:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:15:19 --> Final output sent to browser
DEBUG - 2011-06-19 15:15:19 --> Total execution time: 0.0269
DEBUG - 2011-06-19 15:16:10 --> Config Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:16:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:16:10 --> URI Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Router Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Output Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Input Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:16:10 --> Language Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Loader Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Controller Class Initialized
ERROR - 2011-06-19 15:16:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:16:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:16:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:16:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:16:10 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:16:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:16:10 --> Final output sent to browser
DEBUG - 2011-06-19 15:16:10 --> Total execution time: 0.0297
DEBUG - 2011-06-19 15:16:21 --> Config Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:16:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:16:21 --> URI Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Router Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Output Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Input Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:16:21 --> Language Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Loader Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Controller Class Initialized
ERROR - 2011-06-19 15:16:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:16:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:16:21 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:16:21 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:16:21 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:16:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:16:21 --> Final output sent to browser
DEBUG - 2011-06-19 15:16:21 --> Total execution time: 0.0276
DEBUG - 2011-06-19 15:16:24 --> Config Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:16:24 --> URI Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Router Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Output Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Input Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:16:24 --> Language Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Loader Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Controller Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Model Class Initialized
DEBUG - 2011-06-19 15:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:16:24 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:16:25 --> Final output sent to browser
DEBUG - 2011-06-19 15:16:25 --> Total execution time: 0.5919
DEBUG - 2011-06-19 15:17:08 --> Config Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:17:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:17:08 --> URI Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Router Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Output Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Input Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:17:08 --> Language Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Loader Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Controller Class Initialized
ERROR - 2011-06-19 15:17:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:17:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:17:08 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:17:08 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:17:08 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:17:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:17:08 --> Final output sent to browser
DEBUG - 2011-06-19 15:17:08 --> Total execution time: 0.0276
DEBUG - 2011-06-19 15:17:10 --> Config Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:17:10 --> URI Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Router Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Output Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Input Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:17:10 --> Language Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Loader Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Controller Class Initialized
ERROR - 2011-06-19 15:17:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 15:17:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:17:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:17:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 15:17:10 --> Helper loaded: url_helper
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 15:17:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 15:17:10 --> Final output sent to browser
DEBUG - 2011-06-19 15:17:10 --> Total execution time: 0.0275
DEBUG - 2011-06-19 15:17:10 --> Config Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:17:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:17:10 --> URI Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Router Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Output Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Input Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 15:17:10 --> Language Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Loader Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Controller Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Model Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 15:17:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 15:17:10 --> Final output sent to browser
DEBUG - 2011-06-19 15:17:10 --> Total execution time: 0.5771
DEBUG - 2011-06-19 15:52:05 --> Config Class Initialized
DEBUG - 2011-06-19 15:52:05 --> Hooks Class Initialized
DEBUG - 2011-06-19 15:52:05 --> Utf8 Class Initialized
DEBUG - 2011-06-19 15:52:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 15:52:05 --> URI Class Initialized
DEBUG - 2011-06-19 15:52:05 --> Router Class Initialized
ERROR - 2011-06-19 15:52:05 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-19 16:29:36 --> Config Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:29:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:29:36 --> URI Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Router Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Output Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Input Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:29:36 --> Language Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Loader Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Controller Class Initialized
ERROR - 2011-06-19 16:29:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 16:29:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 16:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 16:29:36 --> Model Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Model Class Initialized
DEBUG - 2011-06-19 16:29:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:29:36 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:29:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 16:29:37 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:29:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:29:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:29:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:29:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:29:37 --> Final output sent to browser
DEBUG - 2011-06-19 16:29:37 --> Total execution time: 0.3502
DEBUG - 2011-06-19 16:29:38 --> Config Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:29:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:29:38 --> URI Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Router Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Output Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Input Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:29:38 --> Language Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Loader Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Controller Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Model Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Model Class Initialized
DEBUG - 2011-06-19 16:29:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:29:38 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:29:39 --> Final output sent to browser
DEBUG - 2011-06-19 16:29:39 --> Total execution time: 0.6930
DEBUG - 2011-06-19 16:29:41 --> Config Class Initialized
DEBUG - 2011-06-19 16:29:41 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:29:41 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:29:41 --> URI Class Initialized
DEBUG - 2011-06-19 16:29:41 --> Router Class Initialized
ERROR - 2011-06-19 16:29:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:30:08 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:08 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Router Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Output Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Input Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:30:08 --> Language Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Loader Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Controller Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:30:08 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:30:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:30:09 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:30:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:30:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:30:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:30:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:30:09 --> Final output sent to browser
DEBUG - 2011-06-19 16:30:09 --> Total execution time: 0.3114
DEBUG - 2011-06-19 16:30:12 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:12 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:12 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:12 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:12 --> Router Class Initialized
ERROR - 2011-06-19 16:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:30:17 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:17 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Router Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Output Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Input Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:30:17 --> Language Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Loader Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Controller Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:30:17 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:30:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:30:17 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:30:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:30:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:30:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:30:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:30:17 --> Final output sent to browser
DEBUG - 2011-06-19 16:30:17 --> Total execution time: 0.0458
DEBUG - 2011-06-19 16:30:19 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:19 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:19 --> Router Class Initialized
ERROR - 2011-06-19 16:30:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:30:32 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:32 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Router Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Output Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Input Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:30:32 --> Language Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Loader Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Controller Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:30:32 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:30:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:30:32 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:30:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:30:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:30:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:30:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:30:32 --> Final output sent to browser
DEBUG - 2011-06-19 16:30:32 --> Total execution time: 0.3430
DEBUG - 2011-06-19 16:30:34 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:34 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:34 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:34 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:34 --> Router Class Initialized
ERROR - 2011-06-19 16:30:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:30:51 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:51 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Router Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Output Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Input Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:30:51 --> Language Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Loader Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Controller Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Model Class Initialized
DEBUG - 2011-06-19 16:30:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:30:51 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:30:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:30:52 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:30:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:30:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:30:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:30:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:30:52 --> Final output sent to browser
DEBUG - 2011-06-19 16:30:52 --> Total execution time: 0.2963
DEBUG - 2011-06-19 16:30:53 --> Config Class Initialized
DEBUG - 2011-06-19 16:30:53 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:30:53 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:30:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:30:53 --> URI Class Initialized
DEBUG - 2011-06-19 16:30:53 --> Router Class Initialized
ERROR - 2011-06-19 16:30:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:31:11 --> Config Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:31:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:31:11 --> URI Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Router Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Output Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Input Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:31:11 --> Language Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Loader Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Controller Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:31:11 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:31:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:31:11 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:31:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:31:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:31:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:31:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:31:11 --> Final output sent to browser
DEBUG - 2011-06-19 16:31:11 --> Total execution time: 0.1143
DEBUG - 2011-06-19 16:31:13 --> Config Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:31:13 --> URI Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Router Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Output Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Input Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:31:13 --> Language Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Loader Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Controller Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:31:13 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:31:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:31:13 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:31:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:31:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:31:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:31:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:31:13 --> Final output sent to browser
DEBUG - 2011-06-19 16:31:13 --> Total execution time: 0.0509
DEBUG - 2011-06-19 16:31:19 --> Config Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:31:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:31:19 --> URI Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Router Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Output Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Input Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:31:19 --> Language Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Loader Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Controller Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:31:19 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:31:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:31:19 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:31:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:31:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:31:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:31:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:31:19 --> Final output sent to browser
DEBUG - 2011-06-19 16:31:19 --> Total execution time: 0.2175
DEBUG - 2011-06-19 16:31:21 --> Config Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:31:21 --> URI Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Router Class Initialized
ERROR - 2011-06-19 16:31:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 16:31:21 --> Config Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Hooks Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Utf8 Class Initialized
DEBUG - 2011-06-19 16:31:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 16:31:21 --> URI Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Router Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Output Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Input Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 16:31:21 --> Language Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Loader Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Controller Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Model Class Initialized
DEBUG - 2011-06-19 16:31:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 16:31:21 --> Database Driver Class Initialized
DEBUG - 2011-06-19 16:31:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 16:31:21 --> Helper loaded: url_helper
DEBUG - 2011-06-19 16:31:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 16:31:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 16:31:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 16:31:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 16:31:21 --> Final output sent to browser
DEBUG - 2011-06-19 16:31:21 --> Total execution time: 0.2298
DEBUG - 2011-06-19 17:49:02 --> Config Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Hooks Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Utf8 Class Initialized
DEBUG - 2011-06-19 17:49:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 17:49:02 --> URI Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Router Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Output Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Input Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 17:49:02 --> Language Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Loader Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Controller Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Model Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Model Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Model Class Initialized
DEBUG - 2011-06-19 17:49:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 17:49:02 --> Database Driver Class Initialized
DEBUG - 2011-06-19 17:49:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 17:49:03 --> Helper loaded: url_helper
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 17:49:03 --> Final output sent to browser
DEBUG - 2011-06-19 17:49:03 --> Total execution time: 0.5809
DEBUG - 2011-06-19 17:49:03 --> Config Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Hooks Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Utf8 Class Initialized
DEBUG - 2011-06-19 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 17:49:03 --> URI Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Router Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Output Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Input Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 17:49:03 --> Language Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Loader Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Controller Class Initialized
ERROR - 2011-06-19 17:49:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 17:49:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 17:49:03 --> Model Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Model Class Initialized
DEBUG - 2011-06-19 17:49:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 17:49:03 --> Database Driver Class Initialized
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 17:49:03 --> Helper loaded: url_helper
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 17:49:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 17:49:03 --> Final output sent to browser
DEBUG - 2011-06-19 17:49:03 --> Total execution time: 0.1085
DEBUG - 2011-06-19 18:09:27 --> Config Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Hooks Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Utf8 Class Initialized
DEBUG - 2011-06-19 18:09:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 18:09:27 --> URI Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Router Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Output Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Input Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 18:09:27 --> Language Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Loader Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Controller Class Initialized
DEBUG - 2011-06-19 18:09:27 --> Model Class Initialized
DEBUG - 2011-06-19 18:09:28 --> Model Class Initialized
DEBUG - 2011-06-19 18:09:28 --> Model Class Initialized
DEBUG - 2011-06-19 18:09:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 18:09:28 --> Database Driver Class Initialized
DEBUG - 2011-06-19 18:09:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 18:09:28 --> Helper loaded: url_helper
DEBUG - 2011-06-19 18:09:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 18:09:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 18:09:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 18:09:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 18:09:28 --> Final output sent to browser
DEBUG - 2011-06-19 18:09:28 --> Total execution time: 0.0977
DEBUG - 2011-06-19 19:56:40 --> Config Class Initialized
DEBUG - 2011-06-19 19:56:40 --> Hooks Class Initialized
DEBUG - 2011-06-19 19:56:40 --> Utf8 Class Initialized
DEBUG - 2011-06-19 19:56:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 19:56:40 --> URI Class Initialized
DEBUG - 2011-06-19 19:56:40 --> Router Class Initialized
DEBUG - 2011-06-19 19:56:40 --> No URI present. Default controller set.
DEBUG - 2011-06-19 19:56:40 --> Output Class Initialized
DEBUG - 2011-06-19 19:56:40 --> Input Class Initialized
DEBUG - 2011-06-19 19:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 19:56:40 --> Language Class Initialized
DEBUG - 2011-06-19 19:56:41 --> Loader Class Initialized
DEBUG - 2011-06-19 19:56:41 --> Controller Class Initialized
DEBUG - 2011-06-19 19:56:41 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-19 19:56:41 --> Helper loaded: url_helper
DEBUG - 2011-06-19 19:56:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 19:56:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 19:56:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 19:56:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 19:56:41 --> Final output sent to browser
DEBUG - 2011-06-19 19:56:41 --> Total execution time: 1.0146
DEBUG - 2011-06-19 19:58:32 --> Config Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Hooks Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Utf8 Class Initialized
DEBUG - 2011-06-19 19:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 19:58:32 --> URI Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Router Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Output Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Input Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 19:58:32 --> Language Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Loader Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Controller Class Initialized
ERROR - 2011-06-19 19:58:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 19:58:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 19:58:32 --> Model Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Model Class Initialized
DEBUG - 2011-06-19 19:58:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 19:58:32 --> Database Driver Class Initialized
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 19:58:32 --> Helper loaded: url_helper
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 19:58:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 19:58:32 --> Final output sent to browser
DEBUG - 2011-06-19 19:58:32 --> Total execution time: 0.2033
DEBUG - 2011-06-19 19:58:34 --> Config Class Initialized
DEBUG - 2011-06-19 19:58:34 --> Hooks Class Initialized
DEBUG - 2011-06-19 19:58:34 --> Utf8 Class Initialized
DEBUG - 2011-06-19 19:58:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 19:58:34 --> URI Class Initialized
DEBUG - 2011-06-19 19:58:34 --> Router Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Output Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Input Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 19:58:35 --> Language Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Loader Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Controller Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Model Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Model Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 19:58:35 --> Database Driver Class Initialized
DEBUG - 2011-06-19 19:58:35 --> Final output sent to browser
DEBUG - 2011-06-19 19:58:35 --> Total execution time: 0.8429
DEBUG - 2011-06-19 19:58:45 --> Config Class Initialized
DEBUG - 2011-06-19 19:58:45 --> Hooks Class Initialized
DEBUG - 2011-06-19 19:58:45 --> Utf8 Class Initialized
DEBUG - 2011-06-19 19:58:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 19:58:45 --> URI Class Initialized
DEBUG - 2011-06-19 19:58:45 --> Router Class Initialized
ERROR - 2011-06-19 19:58:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 20:01:36 --> Config Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:01:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:01:36 --> URI Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Router Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Output Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Input Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:01:36 --> Language Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Loader Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Controller Class Initialized
ERROR - 2011-06-19 20:01:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:01:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:01:36 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:01:36 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:01:36 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:01:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:01:36 --> Final output sent to browser
DEBUG - 2011-06-19 20:01:36 --> Total execution time: 0.0563
DEBUG - 2011-06-19 20:01:37 --> Config Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:01:37 --> URI Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Router Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Output Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Input Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:01:37 --> Language Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Loader Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Controller Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:01:37 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Final output sent to browser
DEBUG - 2011-06-19 20:01:38 --> Total execution time: 0.6589
DEBUG - 2011-06-19 20:01:38 --> Config Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:01:38 --> URI Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Router Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Output Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Input Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:01:38 --> Language Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Loader Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Controller Class Initialized
ERROR - 2011-06-19 20:01:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:01:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:01:38 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Model Class Initialized
DEBUG - 2011-06-19 20:01:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:01:38 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:01:38 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:01:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:01:38 --> Final output sent to browser
DEBUG - 2011-06-19 20:01:38 --> Total execution time: 0.0285
DEBUG - 2011-06-19 20:02:18 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:18 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:18 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Controller Class Initialized
ERROR - 2011-06-19 20:02:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:02:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:18 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:18 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:18 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:02:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:02:18 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:18 --> Total execution time: 0.0272
DEBUG - 2011-06-19 20:02:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Controller Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Controller Class Initialized
ERROR - 2011-06-19 20:02:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:20 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:02:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:20 --> Total execution time: 0.0303
DEBUG - 2011-06-19 20:02:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:20 --> Total execution time: 0.5296
DEBUG - 2011-06-19 20:02:38 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:38 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:38 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Controller Class Initialized
ERROR - 2011-06-19 20:02:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:02:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:38 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:38 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:38 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:02:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:02:38 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:38 --> Total execution time: 0.0344
DEBUG - 2011-06-19 20:02:39 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:39 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:39 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Controller Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:39 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:39 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:39 --> Total execution time: 0.5084
DEBUG - 2011-06-19 20:02:46 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:46 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:46 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Controller Class Initialized
ERROR - 2011-06-19 20:02:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:02:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:46 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:46 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:46 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:02:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:02:46 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:46 --> Total execution time: 0.0319
DEBUG - 2011-06-19 20:02:47 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:47 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:47 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Controller Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:47 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Config Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:02:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:02:47 --> URI Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Router Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Output Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Input Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:02:47 --> Language Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Loader Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Controller Class Initialized
ERROR - 2011-06-19 20:02:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:02:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:02:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:02:47 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:02:47 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:02:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:02:47 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:47 --> Total execution time: 0.0279
DEBUG - 2011-06-19 20:02:47 --> Final output sent to browser
DEBUG - 2011-06-19 20:02:47 --> Total execution time: 0.5713
DEBUG - 2011-06-19 20:03:01 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:01 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:01 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:01 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:02 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:02 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:02 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:02 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:02 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:02 --> Total execution time: 0.0295
DEBUG - 2011-06-19 20:03:03 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:03 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:03 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Controller Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:03 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:03 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:03 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:03 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:03 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:03 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:03 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:03 --> Total execution time: 0.0269
DEBUG - 2011-06-19 20:03:03 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:03 --> Total execution time: 0.5281
DEBUG - 2011-06-19 20:03:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:20 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:20 --> Total execution time: 0.0290
DEBUG - 2011-06-19 20:03:21 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:21 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:21 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:21 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Controller Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:21 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:22 --> Total execution time: 0.5210
DEBUG - 2011-06-19 20:03:22 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:22 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:22 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:22 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:22 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:22 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:22 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:22 --> Total execution time: 0.0282
DEBUG - 2011-06-19 20:03:44 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:44 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:44 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:44 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:44 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:44 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:44 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:44 --> Total execution time: 0.0294
DEBUG - 2011-06-19 20:03:45 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:45 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:45 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Controller Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:45 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:45 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:45 --> Total execution time: 0.5543
DEBUG - 2011-06-19 20:03:51 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:51 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:51 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:51 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:51 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:51 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:51 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:51 --> Total execution time: 0.0271
DEBUG - 2011-06-19 20:03:58 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:58 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:58 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:58 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:58 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:58 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:58 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:58 --> Total execution time: 0.0296
DEBUG - 2011-06-19 20:03:59 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:59 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:59 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:59 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:59 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:59 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:59 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:59 --> Total execution time: 0.0281
DEBUG - 2011-06-19 20:03:59 --> Config Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:03:59 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:03:59 --> URI Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Router Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Output Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Input Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:03:59 --> Language Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Loader Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Controller Class Initialized
ERROR - 2011-06-19 20:03:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:03:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:59 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Model Class Initialized
DEBUG - 2011-06-19 20:03:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:03:59 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:03:59 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:03:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:03:59 --> Final output sent to browser
DEBUG - 2011-06-19 20:03:59 --> Total execution time: 0.0282
DEBUG - 2011-06-19 20:04:00 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:00 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:00 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Controller Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:00 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:00 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:00 --> Total execution time: 0.5231
DEBUG - 2011-06-19 20:04:19 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:19 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:19 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:19 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:19 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:19 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:19 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:19 --> Total execution time: 0.0790
DEBUG - 2011-06-19 20:04:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Controller Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:20 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:20 --> Total execution time: 0.0261
DEBUG - 2011-06-19 20:04:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:20 --> Total execution time: 0.5200
DEBUG - 2011-06-19 20:04:36 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:36 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:36 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:36 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:36 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:36 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:36 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:36 --> Total execution time: 0.0292
DEBUG - 2011-06-19 20:04:37 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:37 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:37 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Controller Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:37 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:37 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:37 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:37 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:37 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:37 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:37 --> Total execution time: 0.0292
DEBUG - 2011-06-19 20:04:38 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:38 --> Total execution time: 0.5080
DEBUG - 2011-06-19 20:04:44 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:44 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:44 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:44 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:44 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:44 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:44 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:44 --> Total execution time: 0.0278
DEBUG - 2011-06-19 20:04:53 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:53 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:53 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:53 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:53 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:53 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:53 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:53 --> Total execution time: 0.0295
DEBUG - 2011-06-19 20:04:54 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:54 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:54 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Controller Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:54 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Config Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:04:54 --> URI Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Router Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Output Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Input Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:04:54 --> Language Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Loader Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Controller Class Initialized
ERROR - 2011-06-19 20:04:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:04:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:54 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Model Class Initialized
DEBUG - 2011-06-19 20:04:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:04:54 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:04:54 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:04:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:04:54 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:54 --> Total execution time: 0.0281
DEBUG - 2011-06-19 20:04:55 --> Final output sent to browser
DEBUG - 2011-06-19 20:04:55 --> Total execution time: 0.5094
DEBUG - 2011-06-19 20:05:10 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:10 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:10 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Controller Class Initialized
ERROR - 2011-06-19 20:05:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:05:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:10 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:10 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:05:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:05:10 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:10 --> Total execution time: 0.0289
DEBUG - 2011-06-19 20:05:11 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:11 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:11 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Controller Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:11 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:12 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:12 --> Total execution time: 0.5579
DEBUG - 2011-06-19 20:05:22 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:22 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:22 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Controller Class Initialized
ERROR - 2011-06-19 20:05:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:05:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:22 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:22 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:22 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:05:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:05:22 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:22 --> Total execution time: 0.0267
DEBUG - 2011-06-19 20:05:23 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:23 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:23 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Controller Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:23 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:24 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:24 --> Total execution time: 0.5041
DEBUG - 2011-06-19 20:05:35 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:35 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:35 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Controller Class Initialized
ERROR - 2011-06-19 20:05:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:05:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:35 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:35 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:35 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:05:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:05:35 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:35 --> Total execution time: 0.0264
DEBUG - 2011-06-19 20:05:37 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:37 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:37 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Controller Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:37 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:37 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:37 --> Total execution time: 0.5264
DEBUG - 2011-06-19 20:05:46 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:46 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:46 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Controller Class Initialized
ERROR - 2011-06-19 20:05:46 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:05:46 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:46 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:46 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:46 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:05:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:05:46 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:46 --> Total execution time: 0.0318
DEBUG - 2011-06-19 20:05:47 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:47 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:47 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Controller Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:47 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Config Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:05:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:05:47 --> URI Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Router Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Output Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Input Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:05:47 --> Language Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Loader Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Controller Class Initialized
ERROR - 2011-06-19 20:05:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:05:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Model Class Initialized
DEBUG - 2011-06-19 20:05:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:05:47 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:05:47 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:05:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:05:47 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:47 --> Total execution time: 0.0361
DEBUG - 2011-06-19 20:05:47 --> Final output sent to browser
DEBUG - 2011-06-19 20:05:47 --> Total execution time: 0.5504
DEBUG - 2011-06-19 20:06:06 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:06 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:06 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:06 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:06 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:06 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:06 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:06 --> Total execution time: 0.0303
DEBUG - 2011-06-19 20:06:07 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:07 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:07 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Controller Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:07 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:07 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:07 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:07 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:07 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:07 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:07 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:07 --> Total execution time: 0.0284
DEBUG - 2011-06-19 20:06:08 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:08 --> Total execution time: 0.6044
DEBUG - 2011-06-19 20:06:19 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:19 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:19 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:19 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:19 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:19 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:19 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:19 --> Total execution time: 0.0453
DEBUG - 2011-06-19 20:06:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Controller Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:20 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:20 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:20 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:20 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:20 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:20 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:20 --> Total execution time: 0.0448
DEBUG - 2011-06-19 20:06:21 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:21 --> Total execution time: 0.5695
DEBUG - 2011-06-19 20:06:24 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:24 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:24 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Controller Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:24 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 20:06:24 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:24 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:24 --> Total execution time: 0.2855
DEBUG - 2011-06-19 20:06:39 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:39 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:39 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:39 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:39 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:39 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:39 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:39 --> Total execution time: 0.0284
DEBUG - 2011-06-19 20:06:40 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:40 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:40 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Controller Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Config Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:06:40 --> URI Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Router Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Output Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Input Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:06:40 --> Language Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Loader Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Controller Class Initialized
ERROR - 2011-06-19 20:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:40 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Model Class Initialized
DEBUG - 2011-06-19 20:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:06:40 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:06:40 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:06:40 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:40 --> Total execution time: 0.0277
DEBUG - 2011-06-19 20:06:40 --> Final output sent to browser
DEBUG - 2011-06-19 20:06:40 --> Total execution time: 0.5193
DEBUG - 2011-06-19 20:30:05 --> Config Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:30:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:30:05 --> URI Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Router Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Output Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Input Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:30:05 --> Language Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Loader Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Controller Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Model Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Model Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Model Class Initialized
DEBUG - 2011-06-19 20:30:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:30:05 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:30:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 20:30:05 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:30:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:30:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:30:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:30:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:30:05 --> Final output sent to browser
DEBUG - 2011-06-19 20:30:05 --> Total execution time: 1.0342
DEBUG - 2011-06-19 20:30:10 --> Config Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:30:10 --> URI Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Router Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Output Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Input Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:30:10 --> Language Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Loader Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Controller Class Initialized
ERROR - 2011-06-19 20:30:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:30:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:30:10 --> Model Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Model Class Initialized
DEBUG - 2011-06-19 20:30:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:30:10 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:30:10 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:30:10 --> Final output sent to browser
DEBUG - 2011-06-19 20:30:10 --> Total execution time: 0.1177
DEBUG - 2011-06-19 20:48:23 --> Config Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Hooks Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Utf8 Class Initialized
DEBUG - 2011-06-19 20:48:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 20:48:23 --> URI Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Router Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Output Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Input Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 20:48:23 --> Language Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Loader Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Controller Class Initialized
ERROR - 2011-06-19 20:48:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 20:48:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Model Class Initialized
DEBUG - 2011-06-19 20:48:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 20:48:23 --> Database Driver Class Initialized
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 20:48:23 --> Helper loaded: url_helper
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 20:48:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 20:48:23 --> Final output sent to browser
DEBUG - 2011-06-19 20:48:23 --> Total execution time: 0.0600
DEBUG - 2011-06-19 22:07:32 --> Config Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:07:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:07:32 --> URI Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Router Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Output Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Input Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:07:32 --> Language Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Loader Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Controller Class Initialized
ERROR - 2011-06-19 22:07:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 22:07:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 22:07:32 --> Model Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Model Class Initialized
DEBUG - 2011-06-19 22:07:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:07:32 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 22:07:32 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:07:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:07:32 --> Final output sent to browser
DEBUG - 2011-06-19 22:07:32 --> Total execution time: 0.3013
DEBUG - 2011-06-19 22:07:33 --> Config Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:07:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:07:33 --> URI Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Router Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Output Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Input Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:07:33 --> Language Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Loader Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Controller Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Model Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Model Class Initialized
DEBUG - 2011-06-19 22:07:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:07:33 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:07:34 --> Final output sent to browser
DEBUG - 2011-06-19 22:07:34 --> Total execution time: 0.6780
DEBUG - 2011-06-19 22:07:38 --> Config Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:07:38 --> URI Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Router Class Initialized
ERROR - 2011-06-19 22:07:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:07:38 --> Config Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:07:38 --> URI Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Router Class Initialized
ERROR - 2011-06-19 22:07:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:07:38 --> Config Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:07:38 --> URI Class Initialized
DEBUG - 2011-06-19 22:07:38 --> Router Class Initialized
ERROR - 2011-06-19 22:07:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:29:05 --> Config Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:29:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:29:05 --> URI Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Router Class Initialized
DEBUG - 2011-06-19 22:29:05 --> No URI present. Default controller set.
DEBUG - 2011-06-19 22:29:05 --> Output Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Input Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:29:05 --> Language Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Loader Class Initialized
DEBUG - 2011-06-19 22:29:05 --> Controller Class Initialized
DEBUG - 2011-06-19 22:29:05 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-19 22:29:05 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:29:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:29:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:29:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:29:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:29:05 --> Final output sent to browser
DEBUG - 2011-06-19 22:29:05 --> Total execution time: 0.0812
DEBUG - 2011-06-19 22:56:09 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:09 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Router Class Initialized
DEBUG - 2011-06-19 22:56:09 --> No URI present. Default controller set.
DEBUG - 2011-06-19 22:56:09 --> Output Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Input Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:56:09 --> Language Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Loader Class Initialized
DEBUG - 2011-06-19 22:56:09 --> Controller Class Initialized
DEBUG - 2011-06-19 22:56:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-19 22:56:09 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:56:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:56:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:56:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:56:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:56:09 --> Final output sent to browser
DEBUG - 2011-06-19 22:56:09 --> Total execution time: 0.1264
DEBUG - 2011-06-19 22:56:10 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:10 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Router Class Initialized
DEBUG - 2011-06-19 22:56:10 --> No URI present. Default controller set.
DEBUG - 2011-06-19 22:56:10 --> Output Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Input Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:56:10 --> Language Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Loader Class Initialized
DEBUG - 2011-06-19 22:56:10 --> Controller Class Initialized
DEBUG - 2011-06-19 22:56:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-19 22:56:10 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:56:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:56:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:56:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:56:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:56:10 --> Final output sent to browser
DEBUG - 2011-06-19 22:56:10 --> Total execution time: 0.0117
DEBUG - 2011-06-19 22:56:11 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:11 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:11 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:11 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:11 --> Router Class Initialized
ERROR - 2011-06-19 22:56:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:56:46 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:46 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Router Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Output Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Input Class Initialized
DEBUG - 2011-06-19 22:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:56:46 --> Language Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Loader Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Controller Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:56:47 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:56:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 22:56:48 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:56:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:56:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:56:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:56:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:56:48 --> Final output sent to browser
DEBUG - 2011-06-19 22:56:48 --> Total execution time: 2.0550
DEBUG - 2011-06-19 22:56:50 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:50 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:50 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:50 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:50 --> Router Class Initialized
ERROR - 2011-06-19 22:56:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:56:56 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:56 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Router Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Output Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Input Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:56:56 --> Language Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Loader Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Controller Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Model Class Initialized
DEBUG - 2011-06-19 22:56:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:56:56 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:56:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 22:56:57 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:56:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:56:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:56:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:56:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:56:57 --> Final output sent to browser
DEBUG - 2011-06-19 22:56:57 --> Total execution time: 0.2086
DEBUG - 2011-06-19 22:56:58 --> Config Class Initialized
DEBUG - 2011-06-19 22:56:58 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:56:58 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:56:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:56:58 --> URI Class Initialized
DEBUG - 2011-06-19 22:56:58 --> Router Class Initialized
ERROR - 2011-06-19 22:56:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:57:08 --> Config Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:57:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:57:08 --> URI Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Router Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Output Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Input Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:57:08 --> Language Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Loader Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Controller Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:57:08 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 22:57:09 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:57:09 --> Final output sent to browser
DEBUG - 2011-06-19 22:57:09 --> Total execution time: 0.2140
DEBUG - 2011-06-19 22:57:09 --> Config Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:57:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:57:09 --> URI Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Router Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Output Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Input Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 22:57:09 --> Language Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Loader Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Controller Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Model Class Initialized
DEBUG - 2011-06-19 22:57:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 22:57:09 --> Database Driver Class Initialized
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 22:57:09 --> Helper loaded: url_helper
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 22:57:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 22:57:09 --> Final output sent to browser
DEBUG - 2011-06-19 22:57:09 --> Total execution time: 0.0466
DEBUG - 2011-06-19 22:57:10 --> Config Class Initialized
DEBUG - 2011-06-19 22:57:10 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:57:10 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:57:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:57:10 --> URI Class Initialized
DEBUG - 2011-06-19 22:57:10 --> Router Class Initialized
ERROR - 2011-06-19 22:57:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 22:57:38 --> Config Class Initialized
DEBUG - 2011-06-19 22:57:38 --> Hooks Class Initialized
DEBUG - 2011-06-19 22:57:38 --> Utf8 Class Initialized
DEBUG - 2011-06-19 22:57:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 22:57:38 --> URI Class Initialized
DEBUG - 2011-06-19 22:57:38 --> Router Class Initialized
ERROR - 2011-06-19 22:57:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 23:00:12 --> Config Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:00:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:00:12 --> URI Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Router Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Output Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Input Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:00:12 --> Language Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Loader Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Controller Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:00:12 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:00:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 23:00:12 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:00:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:00:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:00:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:00:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:00:12 --> Final output sent to browser
DEBUG - 2011-06-19 23:00:12 --> Total execution time: 0.2476
DEBUG - 2011-06-19 23:00:14 --> Config Class Initialized
DEBUG - 2011-06-19 23:00:14 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:00:14 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:00:14 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:00:14 --> URI Class Initialized
DEBUG - 2011-06-19 23:00:14 --> Router Class Initialized
ERROR - 2011-06-19 23:00:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 23:00:18 --> Config Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:00:18 --> URI Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Router Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Output Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Input Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:00:18 --> Language Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Loader Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Controller Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:00:18 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 23:00:18 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:00:18 --> Final output sent to browser
DEBUG - 2011-06-19 23:00:18 --> Total execution time: 0.0709
DEBUG - 2011-06-19 23:00:18 --> Config Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:00:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:00:18 --> URI Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Router Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Output Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Input Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:00:18 --> Language Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Loader Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Controller Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Model Class Initialized
DEBUG - 2011-06-19 23:00:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:00:18 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 23:00:18 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:00:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:00:18 --> Final output sent to browser
DEBUG - 2011-06-19 23:00:18 --> Total execution time: 0.0697
DEBUG - 2011-06-19 23:00:19 --> Config Class Initialized
DEBUG - 2011-06-19 23:00:19 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:00:19 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:00:19 --> URI Class Initialized
DEBUG - 2011-06-19 23:00:19 --> Router Class Initialized
ERROR - 2011-06-19 23:00:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 23:11:28 --> Config Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:11:28 --> URI Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Router Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Output Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Input Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:11:28 --> Language Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Loader Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Controller Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Model Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Model Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Model Class Initialized
DEBUG - 2011-06-19 23:11:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:11:28 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:11:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 23:11:28 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:11:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:11:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:11:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:11:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:11:28 --> Final output sent to browser
DEBUG - 2011-06-19 23:11:28 --> Total execution time: 0.0421
DEBUG - 2011-06-19 23:11:29 --> Config Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:11:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:11:29 --> URI Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Router Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Output Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Input Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:11:29 --> Language Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Loader Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Controller Class Initialized
ERROR - 2011-06-19 23:11:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-19 23:11:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 23:11:29 --> Model Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Model Class Initialized
DEBUG - 2011-06-19 23:11:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:11:29 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-19 23:11:29 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:11:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:11:29 --> Final output sent to browser
DEBUG - 2011-06-19 23:11:29 --> Total execution time: 0.0880
DEBUG - 2011-06-19 23:18:22 --> Config Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:18:22 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:18:22 --> URI Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Router Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Output Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Input Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-19 23:18:22 --> Language Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Loader Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Controller Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Model Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Model Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Model Class Initialized
DEBUG - 2011-06-19 23:18:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-19 23:18:22 --> Database Driver Class Initialized
DEBUG - 2011-06-19 23:18:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-19 23:18:22 --> Helper loaded: url_helper
DEBUG - 2011-06-19 23:18:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-19 23:18:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-19 23:18:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-19 23:18:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-19 23:18:22 --> Final output sent to browser
DEBUG - 2011-06-19 23:18:22 --> Total execution time: 0.0512
DEBUG - 2011-06-19 23:18:23 --> Config Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:18:23 --> URI Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Router Class Initialized
ERROR - 2011-06-19 23:18:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-19 23:18:23 --> Config Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Hooks Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Utf8 Class Initialized
DEBUG - 2011-06-19 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-19 23:18:23 --> URI Class Initialized
DEBUG - 2011-06-19 23:18:23 --> Router Class Initialized
ERROR - 2011-06-19 23:18:23 --> 404 Page Not Found --> favicon.ico

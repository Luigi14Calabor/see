<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-15 02:47:00 --> Config Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Hooks Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Utf8 Class Initialized
DEBUG - 2011-10-15 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 02:47:00 --> URI Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Router Class Initialized
DEBUG - 2011-10-15 02:47:00 --> No URI present. Default controller set.
DEBUG - 2011-10-15 02:47:00 --> Output Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Input Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 02:47:00 --> Language Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Loader Class Initialized
DEBUG - 2011-10-15 02:47:00 --> Controller Class Initialized
DEBUG - 2011-10-15 02:47:00 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 02:47:00 --> Helper loaded: url_helper
DEBUG - 2011-10-15 02:47:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 02:47:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 02:47:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 02:47:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 02:47:00 --> Final output sent to browser
DEBUG - 2011-10-15 02:47:00 --> Total execution time: 0.2235
DEBUG - 2011-10-15 05:07:10 --> Config Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Hooks Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Utf8 Class Initialized
DEBUG - 2011-10-15 05:07:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 05:07:10 --> URI Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Router Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Output Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Input Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 05:07:10 --> Language Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Loader Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Controller Class Initialized
DEBUG - 2011-10-15 05:07:10 --> Model Class Initialized
DEBUG - 2011-10-15 05:07:11 --> Model Class Initialized
DEBUG - 2011-10-15 05:07:11 --> Model Class Initialized
DEBUG - 2011-10-15 05:07:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 05:07:11 --> Database Driver Class Initialized
DEBUG - 2011-10-15 05:07:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 05:07:12 --> Helper loaded: url_helper
DEBUG - 2011-10-15 05:07:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 05:07:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 05:07:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 05:07:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 05:07:12 --> Final output sent to browser
DEBUG - 2011-10-15 05:07:12 --> Total execution time: 2.0237
DEBUG - 2011-10-15 05:07:20 --> Config Class Initialized
DEBUG - 2011-10-15 05:07:20 --> Hooks Class Initialized
DEBUG - 2011-10-15 05:07:20 --> Utf8 Class Initialized
DEBUG - 2011-10-15 05:07:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 05:07:20 --> URI Class Initialized
DEBUG - 2011-10-15 05:07:20 --> Router Class Initialized
ERROR - 2011-10-15 05:07:20 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-10-15 08:15:20 --> Config Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:15:20 --> URI Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Router Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Output Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Input Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:15:20 --> Language Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Loader Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Controller Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:15:20 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:15:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:15:20 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:15:20 --> Final output sent to browser
DEBUG - 2011-10-15 08:15:20 --> Total execution time: 0.5913
DEBUG - 2011-10-15 08:15:22 --> Config Class Initialized
DEBUG - 2011-10-15 08:15:22 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:15:22 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:15:22 --> URI Class Initialized
DEBUG - 2011-10-15 08:15:22 --> Router Class Initialized
ERROR - 2011-10-15 08:15:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:15:46 --> Config Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:15:46 --> URI Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Router Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Output Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Input Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:15:46 --> Language Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Loader Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Controller Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:15:46 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:15:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:15:47 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:15:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:15:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:15:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:15:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:15:47 --> Final output sent to browser
DEBUG - 2011-10-15 08:15:47 --> Total execution time: 0.6843
DEBUG - 2011-10-15 08:15:48 --> Config Class Initialized
DEBUG - 2011-10-15 08:15:48 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:15:48 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:15:48 --> URI Class Initialized
DEBUG - 2011-10-15 08:15:48 --> Router Class Initialized
ERROR - 2011-10-15 08:15:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:15:51 --> Config Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:15:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:15:51 --> URI Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Router Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Output Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Input Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:15:51 --> Language Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Loader Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Controller Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Model Class Initialized
DEBUG - 2011-10-15 08:15:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:15:51 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:15:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:15:51 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:15:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:15:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:15:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:15:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:15:51 --> Final output sent to browser
DEBUG - 2011-10-15 08:15:51 --> Total execution time: 0.0580
DEBUG - 2011-10-15 08:16:00 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:00 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Router Class Initialized
ERROR - 2011-10-15 08:16:00 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-15 08:16:00 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:00 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:00 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:00 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:00 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:00 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:00 --> Total execution time: 0.0490
DEBUG - 2011-10-15 08:16:14 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:14 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:14 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:14 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:14 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:14 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:14 --> Total execution time: 0.2632
DEBUG - 2011-10-15 08:16:15 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:15 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:15 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:15 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:15 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:15 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:15 --> Total execution time: 0.0490
DEBUG - 2011-10-15 08:16:16 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:16 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:16 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:16 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:16 --> Router Class Initialized
ERROR - 2011-10-15 08:16:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:19 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:19 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:19 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:19 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:19 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:19 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:19 --> Total execution time: 0.2668
DEBUG - 2011-10-15 08:16:20 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:20 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:20 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:20 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:20 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:20 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:20 --> Total execution time: 0.0482
DEBUG - 2011-10-15 08:16:20 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:20 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:20 --> Router Class Initialized
ERROR - 2011-10-15 08:16:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:23 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:23 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:23 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:23 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:23 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:23 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:23 --> Total execution time: 0.2446
DEBUG - 2011-10-15 08:16:24 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:24 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:24 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:24 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:24 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:24 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:24 --> Total execution time: 0.0543
DEBUG - 2011-10-15 08:16:24 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:24 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:24 --> Router Class Initialized
ERROR - 2011-10-15 08:16:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:29 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:29 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:29 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:29 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:29 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:29 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:29 --> Total execution time: 0.3819
DEBUG - 2011-10-15 08:16:30 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:30 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:30 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:30 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:30 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:30 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:30 --> Total execution time: 0.0521
DEBUG - 2011-10-15 08:16:30 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:30 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:30 --> Router Class Initialized
ERROR - 2011-10-15 08:16:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:35 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:35 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:35 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:35 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:35 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:35 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:35 --> Total execution time: 0.0539
DEBUG - 2011-10-15 08:16:36 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:36 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:36 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:36 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:36 --> Router Class Initialized
ERROR - 2011-10-15 08:16:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:40 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:40 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:40 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:40 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:40 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:40 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:40 --> Total execution time: 0.0471
DEBUG - 2011-10-15 08:16:41 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:41 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:41 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:41 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:41 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:41 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:41 --> Total execution time: 0.0484
DEBUG - 2011-10-15 08:16:41 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:41 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Router Class Initialized
ERROR - 2011-10-15 08:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:41 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:41 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:41 --> Router Class Initialized
ERROR - 2011-10-15 08:16:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:43 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:43 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:43 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:43 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:44 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:44 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:44 --> Total execution time: 0.2405
DEBUG - 2011-10-15 08:16:44 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:44 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:44 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:44 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:44 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:44 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:44 --> Total execution time: 0.0511
DEBUG - 2011-10-15 08:16:44 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:44 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:44 --> Router Class Initialized
ERROR - 2011-10-15 08:16:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:45 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:45 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:45 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:45 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:45 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:45 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:45 --> Total execution time: 0.0506
DEBUG - 2011-10-15 08:16:45 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:45 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:45 --> Router Class Initialized
ERROR - 2011-10-15 08:16:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:48 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:48 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:48 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:48 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:48 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:48 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:48 --> Total execution time: 0.4199
DEBUG - 2011-10-15 08:16:49 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:49 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:49 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:49 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:49 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:49 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:49 --> Total execution time: 0.0496
DEBUG - 2011-10-15 08:16:50 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:50 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:50 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:50 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:50 --> Router Class Initialized
ERROR - 2011-10-15 08:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:52 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:52 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:52 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:52 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:52 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:52 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:52 --> Total execution time: 0.3340
DEBUG - 2011-10-15 08:16:53 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:53 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:53 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:53 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:53 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:53 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:53 --> Total execution time: 0.0487
DEBUG - 2011-10-15 08:16:53 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:53 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:53 --> Router Class Initialized
ERROR - 2011-10-15 08:16:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 08:16:59 --> Config Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:16:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:16:59 --> URI Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Router Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Output Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Input Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:16:59 --> Language Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Loader Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Controller Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Model Class Initialized
DEBUG - 2011-10-15 08:16:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:16:59 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:16:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:16:59 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:16:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:16:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:16:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:16:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:16:59 --> Final output sent to browser
DEBUG - 2011-10-15 08:16:59 --> Total execution time: 0.0595
DEBUG - 2011-10-15 08:17:00 --> Config Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:17:00 --> URI Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Router Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Output Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Input Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 08:17:00 --> Language Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Loader Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Controller Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Model Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 08:17:00 --> Database Driver Class Initialized
DEBUG - 2011-10-15 08:17:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 08:17:00 --> Helper loaded: url_helper
DEBUG - 2011-10-15 08:17:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 08:17:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 08:17:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 08:17:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 08:17:00 --> Final output sent to browser
DEBUG - 2011-10-15 08:17:00 --> Total execution time: 0.0475
DEBUG - 2011-10-15 08:17:00 --> Config Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Hooks Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Utf8 Class Initialized
DEBUG - 2011-10-15 08:17:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 08:17:00 --> URI Class Initialized
DEBUG - 2011-10-15 08:17:00 --> Router Class Initialized
ERROR - 2011-10-15 08:17:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-15 09:24:27 --> Config Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Hooks Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Utf8 Class Initialized
DEBUG - 2011-10-15 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 09:24:27 --> URI Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Router Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Output Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Input Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 09:24:27 --> Language Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Loader Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Controller Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Model Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Model Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Model Class Initialized
DEBUG - 2011-10-15 09:24:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 09:24:28 --> Database Driver Class Initialized
DEBUG - 2011-10-15 09:24:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 09:24:28 --> Helper loaded: url_helper
DEBUG - 2011-10-15 09:24:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 09:24:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 09:24:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 09:24:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 09:24:28 --> Final output sent to browser
DEBUG - 2011-10-15 09:24:28 --> Total execution time: 0.2502
DEBUG - 2011-10-15 10:09:49 --> Config Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Hooks Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Utf8 Class Initialized
DEBUG - 2011-10-15 10:09:49 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 10:09:49 --> URI Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Router Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Output Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Input Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 10:09:49 --> Language Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Loader Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Controller Class Initialized
ERROR - 2011-10-15 10:09:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-15 10:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 10:09:49 --> Model Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Model Class Initialized
DEBUG - 2011-10-15 10:09:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 10:09:49 --> Database Driver Class Initialized
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 10:09:49 --> Helper loaded: url_helper
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 10:09:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 10:09:49 --> Final output sent to browser
DEBUG - 2011-10-15 10:09:49 --> Total execution time: 0.1624
DEBUG - 2011-10-15 13:34:12 --> Config Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Hooks Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Utf8 Class Initialized
DEBUG - 2011-10-15 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 13:34:12 --> URI Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Router Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Output Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Input Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 13:34:12 --> Language Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Loader Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Controller Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Model Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Model Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Model Class Initialized
DEBUG - 2011-10-15 13:34:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 13:34:12 --> Database Driver Class Initialized
DEBUG - 2011-10-15 13:34:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 13:34:12 --> Helper loaded: url_helper
DEBUG - 2011-10-15 13:34:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 13:34:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 13:34:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 13:34:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 13:34:12 --> Final output sent to browser
DEBUG - 2011-10-15 13:34:12 --> Total execution time: 0.4993
DEBUG - 2011-10-15 13:36:55 --> Config Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Hooks Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Utf8 Class Initialized
DEBUG - 2011-10-15 13:36:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 13:36:55 --> URI Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Router Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Output Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Input Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 13:36:55 --> Language Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Loader Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Controller Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Model Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Model Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Model Class Initialized
DEBUG - 2011-10-15 13:36:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 13:36:55 --> Database Driver Class Initialized
DEBUG - 2011-10-15 13:36:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 13:36:55 --> Helper loaded: url_helper
DEBUG - 2011-10-15 13:36:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 13:36:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 13:36:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 13:36:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 13:36:55 --> Final output sent to browser
DEBUG - 2011-10-15 13:36:55 --> Total execution time: 0.0597
DEBUG - 2011-10-15 16:42:43 --> Config Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Hooks Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Utf8 Class Initialized
DEBUG - 2011-10-15 16:42:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 16:42:43 --> URI Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Router Class Initialized
DEBUG - 2011-10-15 16:42:43 --> No URI present. Default controller set.
DEBUG - 2011-10-15 16:42:43 --> Output Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Input Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 16:42:43 --> Language Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Loader Class Initialized
DEBUG - 2011-10-15 16:42:43 --> Controller Class Initialized
DEBUG - 2011-10-15 16:42:43 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 16:42:43 --> Helper loaded: url_helper
DEBUG - 2011-10-15 16:42:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 16:42:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 16:42:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 16:42:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 16:42:43 --> Final output sent to browser
DEBUG - 2011-10-15 16:42:43 --> Total execution time: 0.0832
DEBUG - 2011-10-15 16:46:22 --> Config Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Hooks Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Utf8 Class Initialized
DEBUG - 2011-10-15 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 16:46:22 --> URI Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Router Class Initialized
DEBUG - 2011-10-15 16:46:22 --> No URI present. Default controller set.
DEBUG - 2011-10-15 16:46:22 --> Output Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Input Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 16:46:22 --> Language Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Loader Class Initialized
DEBUG - 2011-10-15 16:46:22 --> Controller Class Initialized
DEBUG - 2011-10-15 16:46:22 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 16:46:22 --> Helper loaded: url_helper
DEBUG - 2011-10-15 16:46:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 16:46:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 16:46:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 16:46:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 16:46:22 --> Final output sent to browser
DEBUG - 2011-10-15 16:46:22 --> Total execution time: 0.0271
DEBUG - 2011-10-15 17:53:29 --> Config Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Hooks Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Utf8 Class Initialized
DEBUG - 2011-10-15 17:53:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 17:53:29 --> URI Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Router Class Initialized
DEBUG - 2011-10-15 17:53:29 --> No URI present. Default controller set.
DEBUG - 2011-10-15 17:53:29 --> Output Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Input Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 17:53:29 --> Language Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Loader Class Initialized
DEBUG - 2011-10-15 17:53:29 --> Controller Class Initialized
DEBUG - 2011-10-15 17:53:29 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 17:53:29 --> Helper loaded: url_helper
DEBUG - 2011-10-15 17:53:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 17:53:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 17:53:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 17:53:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 17:53:29 --> Final output sent to browser
DEBUG - 2011-10-15 17:53:29 --> Total execution time: 0.0498
DEBUG - 2011-10-15 19:09:59 --> Config Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Hooks Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Utf8 Class Initialized
DEBUG - 2011-10-15 19:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 19:09:59 --> URI Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Router Class Initialized
ERROR - 2011-10-15 19:09:59 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-15 19:09:59 --> Config Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Hooks Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Utf8 Class Initialized
DEBUG - 2011-10-15 19:09:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 19:09:59 --> URI Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Router Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Output Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Input Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 19:09:59 --> Language Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Loader Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Controller Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Model Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Model Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Model Class Initialized
DEBUG - 2011-10-15 19:09:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 19:09:59 --> Database Driver Class Initialized
DEBUG - 2011-10-15 19:10:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 19:10:00 --> Helper loaded: url_helper
DEBUG - 2011-10-15 19:10:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 19:10:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 19:10:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 19:10:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 19:10:00 --> Final output sent to browser
DEBUG - 2011-10-15 19:10:00 --> Total execution time: 0.3553
DEBUG - 2011-10-15 20:06:55 --> Config Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Hooks Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Utf8 Class Initialized
DEBUG - 2011-10-15 20:06:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 20:06:55 --> URI Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Router Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Output Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Input Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 20:06:55 --> Language Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Loader Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Controller Class Initialized
ERROR - 2011-10-15 20:06:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-15 20:06:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 20:06:55 --> Model Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Model Class Initialized
DEBUG - 2011-10-15 20:06:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 20:06:55 --> Database Driver Class Initialized
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 20:06:55 --> Helper loaded: url_helper
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 20:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 20:06:55 --> Final output sent to browser
DEBUG - 2011-10-15 20:06:55 --> Total execution time: 0.1604
DEBUG - 2011-10-15 20:07:06 --> Config Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Hooks Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Utf8 Class Initialized
DEBUG - 2011-10-15 20:07:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 20:07:06 --> URI Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Router Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Output Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Input Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 20:07:06 --> Language Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Loader Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Controller Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Model Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Model Class Initialized
DEBUG - 2011-10-15 20:07:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 20:07:06 --> Database Driver Class Initialized
DEBUG - 2011-10-15 20:07:07 --> Final output sent to browser
DEBUG - 2011-10-15 20:07:07 --> Total execution time: 0.5888
DEBUG - 2011-10-15 20:14:27 --> Config Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Hooks Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Utf8 Class Initialized
DEBUG - 2011-10-15 20:14:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 20:14:27 --> URI Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Router Class Initialized
DEBUG - 2011-10-15 20:14:27 --> No URI present. Default controller set.
DEBUG - 2011-10-15 20:14:27 --> Output Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Input Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 20:14:27 --> Language Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Loader Class Initialized
DEBUG - 2011-10-15 20:14:27 --> Controller Class Initialized
DEBUG - 2011-10-15 20:14:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 20:14:27 --> Helper loaded: url_helper
DEBUG - 2011-10-15 20:14:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 20:14:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 20:14:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 20:14:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 20:14:27 --> Final output sent to browser
DEBUG - 2011-10-15 20:14:27 --> Total execution time: 0.0217
DEBUG - 2011-10-15 20:34:09 --> Config Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Hooks Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Utf8 Class Initialized
DEBUG - 2011-10-15 20:34:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 20:34:09 --> URI Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Router Class Initialized
DEBUG - 2011-10-15 20:34:09 --> No URI present. Default controller set.
DEBUG - 2011-10-15 20:34:09 --> Output Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Input Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 20:34:09 --> Language Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Loader Class Initialized
DEBUG - 2011-10-15 20:34:09 --> Controller Class Initialized
DEBUG - 2011-10-15 20:34:09 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-15 20:34:09 --> Helper loaded: url_helper
DEBUG - 2011-10-15 20:34:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 20:34:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 20:34:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 20:34:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 20:34:09 --> Final output sent to browser
DEBUG - 2011-10-15 20:34:09 --> Total execution time: 0.0162
DEBUG - 2011-10-15 22:29:34 --> Config Class Initialized
DEBUG - 2011-10-15 22:29:34 --> Hooks Class Initialized
DEBUG - 2011-10-15 22:29:34 --> Utf8 Class Initialized
DEBUG - 2011-10-15 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 22:29:34 --> URI Class Initialized
DEBUG - 2011-10-15 22:29:34 --> Router Class Initialized
ERROR - 2011-10-15 22:29:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-15 22:56:18 --> Config Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Hooks Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Utf8 Class Initialized
DEBUG - 2011-10-15 22:56:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 22:56:18 --> URI Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Router Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Output Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Input Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 22:56:18 --> Language Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Loader Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Controller Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 22:56:18 --> Database Driver Class Initialized
DEBUG - 2011-10-15 22:56:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-15 22:56:19 --> Helper loaded: url_helper
DEBUG - 2011-10-15 22:56:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 22:56:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 22:56:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 22:56:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 22:56:19 --> Final output sent to browser
DEBUG - 2011-10-15 22:56:19 --> Total execution time: 0.9196
DEBUG - 2011-10-15 22:56:39 --> Config Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Hooks Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Utf8 Class Initialized
DEBUG - 2011-10-15 22:56:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 22:56:39 --> URI Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Router Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Output Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Input Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 22:56:39 --> Language Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Loader Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Controller Class Initialized
ERROR - 2011-10-15 22:56:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-15 22:56:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 22:56:39 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 22:56:39 --> Database Driver Class Initialized
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 22:56:39 --> Helper loaded: url_helper
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 22:56:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 22:56:39 --> Final output sent to browser
DEBUG - 2011-10-15 22:56:39 --> Total execution time: 0.0310
DEBUG - 2011-10-15 22:56:41 --> Config Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Hooks Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Utf8 Class Initialized
DEBUG - 2011-10-15 22:56:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 22:56:41 --> URI Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Router Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Output Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Input Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 22:56:41 --> Language Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Loader Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Controller Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Model Class Initialized
DEBUG - 2011-10-15 22:56:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 22:56:41 --> Database Driver Class Initialized
DEBUG - 2011-10-15 22:56:42 --> Final output sent to browser
DEBUG - 2011-10-15 22:56:42 --> Total execution time: 0.6809
DEBUG - 2011-10-15 23:05:53 --> Config Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Hooks Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Utf8 Class Initialized
DEBUG - 2011-10-15 23:05:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-15 23:05:53 --> URI Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Router Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Output Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Input Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-15 23:05:53 --> Language Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Loader Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Controller Class Initialized
ERROR - 2011-10-15 23:05:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-15 23:05:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 23:05:53 --> Model Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Model Class Initialized
DEBUG - 2011-10-15 23:05:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-15 23:05:53 --> Database Driver Class Initialized
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-15 23:05:53 --> Helper loaded: url_helper
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-15 23:05:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-15 23:05:53 --> Final output sent to browser
DEBUG - 2011-10-15 23:05:53 --> Total execution time: 0.0460

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-04 02:25:12 --> Config Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Hooks Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Utf8 Class Initialized
DEBUG - 2011-07-04 02:25:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 02:25:12 --> URI Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Router Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Output Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Input Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 02:25:12 --> Language Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Loader Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Controller Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Model Class Initialized
DEBUG - 2011-07-04 02:25:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 02:25:13 --> Database Driver Class Initialized
DEBUG - 2011-07-04 02:25:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 02:25:19 --> Helper loaded: url_helper
DEBUG - 2011-07-04 02:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 02:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 02:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 02:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 02:25:19 --> Final output sent to browser
DEBUG - 2011-07-04 02:25:19 --> Total execution time: 6.3648
DEBUG - 2011-07-04 02:25:23 --> Config Class Initialized
DEBUG - 2011-07-04 02:25:23 --> Hooks Class Initialized
DEBUG - 2011-07-04 02:25:23 --> Utf8 Class Initialized
DEBUG - 2011-07-04 02:25:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 02:25:23 --> URI Class Initialized
DEBUG - 2011-07-04 02:25:23 --> Router Class Initialized
ERROR - 2011-07-04 02:25:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 02:33:40 --> Config Class Initialized
DEBUG - 2011-07-04 02:33:40 --> Hooks Class Initialized
DEBUG - 2011-07-04 02:33:40 --> Utf8 Class Initialized
DEBUG - 2011-07-04 02:33:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 02:33:40 --> URI Class Initialized
DEBUG - 2011-07-04 02:33:40 --> Router Class Initialized
ERROR - 2011-07-04 02:33:40 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 02:43:08 --> Config Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Hooks Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Utf8 Class Initialized
DEBUG - 2011-07-04 02:43:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 02:43:08 --> URI Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Router Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Output Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Input Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 02:43:08 --> Language Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Loader Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Controller Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Model Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Model Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Model Class Initialized
DEBUG - 2011-07-04 02:43:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 02:43:08 --> Database Driver Class Initialized
DEBUG - 2011-07-04 02:43:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 02:43:09 --> Helper loaded: url_helper
DEBUG - 2011-07-04 02:43:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 02:43:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 02:43:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 02:43:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 02:43:09 --> Final output sent to browser
DEBUG - 2011-07-04 02:43:09 --> Total execution time: 1.1221
DEBUG - 2011-07-04 03:06:34 --> Config Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Hooks Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Utf8 Class Initialized
DEBUG - 2011-07-04 03:06:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 03:06:34 --> URI Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Router Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Output Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Input Class Initialized
DEBUG - 2011-07-04 03:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 03:06:34 --> Language Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Loader Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Controller Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Model Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Model Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Model Class Initialized
DEBUG - 2011-07-04 03:06:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 03:06:35 --> Database Driver Class Initialized
DEBUG - 2011-07-04 03:06:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 03:06:36 --> Helper loaded: url_helper
DEBUG - 2011-07-04 03:06:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 03:06:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 03:06:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 03:06:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 03:06:36 --> Final output sent to browser
DEBUG - 2011-07-04 03:06:36 --> Total execution time: 1.6815
DEBUG - 2011-07-04 03:06:40 --> Config Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Hooks Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Utf8 Class Initialized
DEBUG - 2011-07-04 03:06:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 03:06:40 --> URI Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Router Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Output Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Input Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 03:06:40 --> Language Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Loader Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Controller Class Initialized
ERROR - 2011-07-04 03:06:40 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 03:06:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 03:06:40 --> Model Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Model Class Initialized
DEBUG - 2011-07-04 03:06:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 03:06:40 --> Database Driver Class Initialized
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 03:06:40 --> Helper loaded: url_helper
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 03:06:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 03:06:40 --> Final output sent to browser
DEBUG - 2011-07-04 03:06:40 --> Total execution time: 0.1224
DEBUG - 2011-07-04 05:37:15 --> Config Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Hooks Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Utf8 Class Initialized
DEBUG - 2011-07-04 05:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 05:37:15 --> URI Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Router Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Output Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Input Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 05:37:15 --> Language Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Loader Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Controller Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Model Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Model Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Model Class Initialized
DEBUG - 2011-07-04 05:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 05:37:15 --> Database Driver Class Initialized
DEBUG - 2011-07-04 05:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 05:37:16 --> Helper loaded: url_helper
DEBUG - 2011-07-04 05:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 05:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 05:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 05:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 05:37:16 --> Final output sent to browser
DEBUG - 2011-07-04 05:37:16 --> Total execution time: 1.2522
DEBUG - 2011-07-04 05:38:39 --> Config Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Hooks Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Utf8 Class Initialized
DEBUG - 2011-07-04 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 05:38:39 --> URI Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Router Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Output Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Input Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 05:38:39 --> Language Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Loader Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Controller Class Initialized
ERROR - 2011-07-04 05:38:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 05:38:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 05:38:39 --> Model Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Model Class Initialized
DEBUG - 2011-07-04 05:38:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 05:38:39 --> Database Driver Class Initialized
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 05:38:39 --> Helper loaded: url_helper
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 05:38:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 05:38:39 --> Final output sent to browser
DEBUG - 2011-07-04 05:38:39 --> Total execution time: 0.1597
DEBUG - 2011-07-04 07:54:44 --> Config Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Hooks Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Utf8 Class Initialized
DEBUG - 2011-07-04 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 07:54:44 --> URI Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Router Class Initialized
ERROR - 2011-07-04 07:54:44 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 07:54:44 --> Config Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Hooks Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Utf8 Class Initialized
DEBUG - 2011-07-04 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 07:54:44 --> URI Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Router Class Initialized
DEBUG - 2011-07-04 07:54:44 --> No URI present. Default controller set.
DEBUG - 2011-07-04 07:54:44 --> Output Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Input Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 07:54:44 --> Language Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Loader Class Initialized
DEBUG - 2011-07-04 07:54:44 --> Controller Class Initialized
DEBUG - 2011-07-04 07:54:44 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 07:54:44 --> Helper loaded: url_helper
DEBUG - 2011-07-04 07:54:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 07:54:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 07:54:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 07:54:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 07:54:45 --> Final output sent to browser
DEBUG - 2011-07-04 07:54:45 --> Total execution time: 0.1573
DEBUG - 2011-07-04 08:56:10 --> Config Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Hooks Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Utf8 Class Initialized
DEBUG - 2011-07-04 08:56:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 08:56:10 --> URI Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Router Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Output Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Input Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 08:56:10 --> Language Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Loader Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Controller Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Model Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Model Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Model Class Initialized
DEBUG - 2011-07-04 08:56:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 08:56:10 --> Database Driver Class Initialized
DEBUG - 2011-07-04 08:56:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 08:56:11 --> Helper loaded: url_helper
DEBUG - 2011-07-04 08:56:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 08:56:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 08:56:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 08:56:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 08:56:11 --> Final output sent to browser
DEBUG - 2011-07-04 08:56:11 --> Total execution time: 0.7187
DEBUG - 2011-07-04 09:22:04 --> Config Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:22:04 --> URI Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Router Class Initialized
ERROR - 2011-07-04 09:22:04 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 09:22:04 --> Config Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:22:04 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:22:04 --> URI Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Router Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Output Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Input Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:22:04 --> Language Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Loader Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Controller Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Model Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Model Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Model Class Initialized
DEBUG - 2011-07-04 09:22:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:22:04 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:22:07 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 09:22:07 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:22:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:22:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:22:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:22:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:22:07 --> Final output sent to browser
DEBUG - 2011-07-04 09:22:07 --> Total execution time: 2.8989
DEBUG - 2011-07-04 09:32:45 --> Config Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:32:45 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:32:45 --> URI Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Router Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Output Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Input Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:32:45 --> Language Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Loader Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Controller Class Initialized
ERROR - 2011-07-04 09:32:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 09:32:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 09:32:45 --> Model Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Model Class Initialized
DEBUG - 2011-07-04 09:32:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:32:45 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 09:32:45 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:32:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:32:45 --> Final output sent to browser
DEBUG - 2011-07-04 09:32:45 --> Total execution time: 0.2389
DEBUG - 2011-07-04 09:32:47 --> Config Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:32:47 --> URI Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Router Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Output Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Input Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:32:47 --> Language Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Loader Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Controller Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Model Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Model Class Initialized
DEBUG - 2011-07-04 09:32:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:32:47 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:32:48 --> Final output sent to browser
DEBUG - 2011-07-04 09:32:48 --> Total execution time: 0.7445
DEBUG - 2011-07-04 09:32:51 --> Config Class Initialized
DEBUG - 2011-07-04 09:32:51 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:32:51 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:32:51 --> URI Class Initialized
DEBUG - 2011-07-04 09:32:51 --> Router Class Initialized
ERROR - 2011-07-04 09:32:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 09:49:56 --> Config Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:49:56 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:49:56 --> URI Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Router Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Output Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Input Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:49:56 --> Language Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Loader Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Controller Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Model Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Model Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Model Class Initialized
DEBUG - 2011-07-04 09:49:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:49:56 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:49:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 09:49:56 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:49:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:49:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:49:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:49:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:49:56 --> Final output sent to browser
DEBUG - 2011-07-04 09:49:56 --> Total execution time: 0.7283
DEBUG - 2011-07-04 09:52:48 --> Config Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:52:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:52:48 --> URI Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Router Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Output Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Input Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:52:48 --> Language Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Loader Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Controller Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Model Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Model Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Model Class Initialized
DEBUG - 2011-07-04 09:52:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:52:48 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:52:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 09:52:48 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:52:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:52:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:52:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:52:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:52:48 --> Final output sent to browser
DEBUG - 2011-07-04 09:52:48 --> Total execution time: 0.3918
DEBUG - 2011-07-04 09:53:40 --> Config Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:53:40 --> URI Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Router Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Output Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Input Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:53:40 --> Language Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Loader Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Controller Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Model Class Initialized
DEBUG - 2011-07-04 09:53:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:53:40 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:53:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 09:53:40 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:53:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:53:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:53:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:53:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:53:40 --> Final output sent to browser
DEBUG - 2011-07-04 09:53:40 --> Total execution time: 0.2855
DEBUG - 2011-07-04 09:54:12 --> Config Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Hooks Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Utf8 Class Initialized
DEBUG - 2011-07-04 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 09:54:12 --> URI Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Router Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Output Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Input Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 09:54:12 --> Language Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Loader Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Controller Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Model Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Model Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Model Class Initialized
DEBUG - 2011-07-04 09:54:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 09:54:13 --> Database Driver Class Initialized
DEBUG - 2011-07-04 09:54:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 09:54:13 --> Helper loaded: url_helper
DEBUG - 2011-07-04 09:54:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 09:54:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 09:54:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 09:54:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 09:54:13 --> Final output sent to browser
DEBUG - 2011-07-04 09:54:13 --> Total execution time: 1.1189
DEBUG - 2011-07-04 11:11:34 --> Config Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:11:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:11:34 --> URI Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Router Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Output Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Input Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:11:34 --> Language Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Loader Class Initialized
DEBUG - 2011-07-04 11:11:34 --> Controller Class Initialized
ERROR - 2011-07-04 11:11:35 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 11:11:35 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 11:11:35 --> Model Class Initialized
DEBUG - 2011-07-04 11:11:35 --> Model Class Initialized
DEBUG - 2011-07-04 11:11:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:11:35 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 11:11:35 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:11:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:11:35 --> Final output sent to browser
DEBUG - 2011-07-04 11:11:35 --> Total execution time: 0.4349
DEBUG - 2011-07-04 11:11:36 --> Config Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:11:36 --> URI Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Router Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Output Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Input Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:11:36 --> Language Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Loader Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Controller Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Model Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Model Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:11:36 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:11:36 --> Final output sent to browser
DEBUG - 2011-07-04 11:11:36 --> Total execution time: 0.8094
DEBUG - 2011-07-04 11:13:12 --> Config Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:13:12 --> URI Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Router Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Output Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Input Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:13:12 --> Language Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Loader Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Controller Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:13:12 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:13:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:13:12 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:13:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:13:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:13:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:13:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:13:12 --> Final output sent to browser
DEBUG - 2011-07-04 11:13:12 --> Total execution time: 0.3648
DEBUG - 2011-07-04 11:13:41 --> Config Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:13:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:13:41 --> URI Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Router Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Output Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Input Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:13:41 --> Language Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Loader Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Controller Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:13:41 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:13:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:13:41 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:13:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:13:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:13:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:13:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:13:41 --> Final output sent to browser
DEBUG - 2011-07-04 11:13:41 --> Total execution time: 0.0570
DEBUG - 2011-07-04 11:13:42 --> Config Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:13:42 --> URI Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Router Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Output Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Input Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:13:42 --> Language Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Loader Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Controller Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Model Class Initialized
DEBUG - 2011-07-04 11:13:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:13:42 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:13:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:13:42 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:13:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:13:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:13:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:13:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:13:42 --> Final output sent to browser
DEBUG - 2011-07-04 11:13:42 --> Total execution time: 0.1107
DEBUG - 2011-07-04 11:14:17 --> Config Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:14:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:14:17 --> URI Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Router Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Output Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Input Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:14:17 --> Language Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Loader Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Controller Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:14:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:14:17 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:14:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:14:17 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:14:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:14:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:14:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:14:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:14:17 --> Final output sent to browser
DEBUG - 2011-07-04 11:14:17 --> Total execution time: 0.2230
DEBUG - 2011-07-04 11:15:17 --> Config Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:15:17 --> URI Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Router Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Output Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Input Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:15:17 --> Language Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Loader Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Controller Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Model Class Initialized
DEBUG - 2011-07-04 11:15:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:15:17 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:15:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:15:17 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:15:17 --> Final output sent to browser
DEBUG - 2011-07-04 11:15:17 --> Total execution time: 0.1002
DEBUG - 2011-07-04 11:34:24 --> Config Class Initialized
DEBUG - 2011-07-04 11:34:24 --> Hooks Class Initialized
DEBUG - 2011-07-04 11:34:24 --> Utf8 Class Initialized
DEBUG - 2011-07-04 11:34:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 11:34:24 --> URI Class Initialized
DEBUG - 2011-07-04 11:34:24 --> Router Class Initialized
DEBUG - 2011-07-04 11:34:24 --> Output Class Initialized
DEBUG - 2011-07-04 11:34:25 --> Input Class Initialized
DEBUG - 2011-07-04 11:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 11:34:25 --> Language Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Loader Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Controller Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Model Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Model Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Model Class Initialized
DEBUG - 2011-07-04 11:34:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 11:34:26 --> Database Driver Class Initialized
DEBUG - 2011-07-04 11:34:27 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 11:34:27 --> Helper loaded: url_helper
DEBUG - 2011-07-04 11:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 11:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 11:34:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 11:34:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 11:34:28 --> Final output sent to browser
DEBUG - 2011-07-04 11:34:28 --> Total execution time: 4.7428
DEBUG - 2011-07-04 13:05:35 --> Config Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Hooks Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Utf8 Class Initialized
DEBUG - 2011-07-04 13:05:35 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 13:05:35 --> URI Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Router Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Output Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Input Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 13:05:35 --> Language Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Loader Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Controller Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Model Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Model Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Model Class Initialized
DEBUG - 2011-07-04 13:05:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 13:05:35 --> Database Driver Class Initialized
DEBUG - 2011-07-04 13:05:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 13:05:38 --> Helper loaded: url_helper
DEBUG - 2011-07-04 13:05:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 13:05:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 13:05:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 13:05:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 13:05:38 --> Final output sent to browser
DEBUG - 2011-07-04 13:05:38 --> Total execution time: 2.8114
DEBUG - 2011-07-04 14:24:38 --> Config Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Hooks Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Utf8 Class Initialized
DEBUG - 2011-07-04 14:24:38 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 14:24:38 --> URI Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Router Class Initialized
DEBUG - 2011-07-04 14:24:38 --> No URI present. Default controller set.
DEBUG - 2011-07-04 14:24:38 --> Output Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Input Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 14:24:38 --> Language Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Loader Class Initialized
DEBUG - 2011-07-04 14:24:38 --> Controller Class Initialized
DEBUG - 2011-07-04 14:24:38 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 14:24:38 --> Helper loaded: url_helper
DEBUG - 2011-07-04 14:24:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 14:24:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 14:24:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 14:24:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 14:24:38 --> Final output sent to browser
DEBUG - 2011-07-04 14:24:38 --> Total execution time: 0.2935
DEBUG - 2011-07-04 14:30:03 --> Config Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Hooks Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Utf8 Class Initialized
DEBUG - 2011-07-04 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 14:30:03 --> URI Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Router Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Output Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Input Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 14:30:03 --> Language Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Loader Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Controller Class Initialized
ERROR - 2011-07-04 14:30:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 14:30:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 14:30:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 14:30:03 --> Model Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Model Class Initialized
DEBUG - 2011-07-04 14:30:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 14:30:03 --> Database Driver Class Initialized
DEBUG - 2011-07-04 14:30:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 14:30:04 --> Helper loaded: url_helper
DEBUG - 2011-07-04 14:30:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 14:30:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 14:30:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 14:30:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 14:30:04 --> Final output sent to browser
DEBUG - 2011-07-04 14:30:04 --> Total execution time: 0.3769
DEBUG - 2011-07-04 14:31:09 --> Config Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Hooks Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Utf8 Class Initialized
DEBUG - 2011-07-04 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 14:31:09 --> URI Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Router Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Output Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Input Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 14:31:09 --> Language Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Loader Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Controller Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Model Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Model Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Model Class Initialized
DEBUG - 2011-07-04 14:31:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 14:31:09 --> Database Driver Class Initialized
DEBUG - 2011-07-04 14:31:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 14:31:09 --> Helper loaded: url_helper
DEBUG - 2011-07-04 14:31:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 14:31:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 14:31:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 14:31:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 14:31:09 --> Final output sent to browser
DEBUG - 2011-07-04 14:31:09 --> Total execution time: 0.7594
DEBUG - 2011-07-04 16:07:30 --> Config Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:07:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:07:30 --> URI Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Router Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Output Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Input Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 16:07:30 --> Language Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Loader Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Controller Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Model Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Model Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Model Class Initialized
DEBUG - 2011-07-04 16:07:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 16:07:30 --> Database Driver Class Initialized
DEBUG - 2011-07-04 16:07:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 16:07:30 --> Helper loaded: url_helper
DEBUG - 2011-07-04 16:07:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 16:07:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 16:07:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 16:07:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 16:07:30 --> Final output sent to browser
DEBUG - 2011-07-04 16:07:30 --> Total execution time: 0.6594
DEBUG - 2011-07-04 16:07:31 --> Config Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:07:31 --> URI Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Router Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Output Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Input Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 16:07:31 --> Language Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Loader Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Controller Class Initialized
ERROR - 2011-07-04 16:07:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 16:07:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 16:07:31 --> Model Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Model Class Initialized
DEBUG - 2011-07-04 16:07:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 16:07:31 --> Database Driver Class Initialized
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 16:07:31 --> Helper loaded: url_helper
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 16:07:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 16:07:31 --> Final output sent to browser
DEBUG - 2011-07-04 16:07:31 --> Total execution time: 0.1068
DEBUG - 2011-07-04 16:11:18 --> Config Class Initialized
DEBUG - 2011-07-04 16:11:18 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:11:18 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:11:18 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:11:18 --> URI Class Initialized
DEBUG - 2011-07-04 16:11:18 --> Router Class Initialized
ERROR - 2011-07-04 16:11:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 16:11:19 --> Config Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:11:19 --> URI Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Router Class Initialized
DEBUG - 2011-07-04 16:11:19 --> No URI present. Default controller set.
DEBUG - 2011-07-04 16:11:19 --> Output Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Input Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 16:11:19 --> Language Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Loader Class Initialized
DEBUG - 2011-07-04 16:11:19 --> Controller Class Initialized
DEBUG - 2011-07-04 16:11:19 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 16:11:19 --> Helper loaded: url_helper
DEBUG - 2011-07-04 16:11:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 16:11:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 16:11:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 16:11:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 16:11:19 --> Final output sent to browser
DEBUG - 2011-07-04 16:11:19 --> Total execution time: 0.0870
DEBUG - 2011-07-04 16:11:20 --> Config Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:11:20 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:11:20 --> URI Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Router Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Output Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Input Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 16:11:20 --> Language Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Loader Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Controller Class Initialized
ERROR - 2011-07-04 16:11:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 16:11:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 16:11:20 --> Model Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Model Class Initialized
DEBUG - 2011-07-04 16:11:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 16:11:20 --> Database Driver Class Initialized
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 16:11:20 --> Helper loaded: url_helper
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 16:11:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 16:11:20 --> Final output sent to browser
DEBUG - 2011-07-04 16:11:20 --> Total execution time: 0.0268
DEBUG - 2011-07-04 16:11:21 --> Config Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Hooks Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Utf8 Class Initialized
DEBUG - 2011-07-04 16:11:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 16:11:21 --> URI Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Router Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Output Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Input Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 16:11:21 --> Language Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Loader Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Controller Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Model Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Model Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Model Class Initialized
DEBUG - 2011-07-04 16:11:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 16:11:21 --> Database Driver Class Initialized
DEBUG - 2011-07-04 16:11:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 16:11:21 --> Helper loaded: url_helper
DEBUG - 2011-07-04 16:11:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 16:11:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 16:11:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 16:11:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 16:11:21 --> Final output sent to browser
DEBUG - 2011-07-04 16:11:21 --> Total execution time: 0.0467
DEBUG - 2011-07-04 18:38:23 --> Config Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Hooks Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Utf8 Class Initialized
DEBUG - 2011-07-04 18:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 18:38:23 --> URI Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Router Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Output Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Input Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 18:38:23 --> Language Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Loader Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Controller Class Initialized
ERROR - 2011-07-04 18:38:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 18:38:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 18:38:23 --> Model Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Model Class Initialized
DEBUG - 2011-07-04 18:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 18:38:23 --> Database Driver Class Initialized
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 18:38:23 --> Helper loaded: url_helper
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 18:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 18:38:23 --> Final output sent to browser
DEBUG - 2011-07-04 18:38:23 --> Total execution time: 0.2967
DEBUG - 2011-07-04 18:38:24 --> Config Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Hooks Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Utf8 Class Initialized
DEBUG - 2011-07-04 18:38:24 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 18:38:24 --> URI Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Router Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Output Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Input Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 18:38:24 --> Language Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Loader Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Controller Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Model Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Model Class Initialized
DEBUG - 2011-07-04 18:38:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 18:38:24 --> Database Driver Class Initialized
DEBUG - 2011-07-04 18:38:25 --> Final output sent to browser
DEBUG - 2011-07-04 18:38:25 --> Total execution time: 0.5417
DEBUG - 2011-07-04 18:38:26 --> Config Class Initialized
DEBUG - 2011-07-04 18:38:26 --> Hooks Class Initialized
DEBUG - 2011-07-04 18:38:26 --> Utf8 Class Initialized
DEBUG - 2011-07-04 18:38:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 18:38:26 --> URI Class Initialized
DEBUG - 2011-07-04 18:38:26 --> Router Class Initialized
ERROR - 2011-07-04 18:38:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 19:13:08 --> Config Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Hooks Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Utf8 Class Initialized
DEBUG - 2011-07-04 19:13:08 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 19:13:08 --> URI Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Router Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Output Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Input Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 19:13:08 --> Language Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Loader Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Controller Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Model Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Model Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Model Class Initialized
DEBUG - 2011-07-04 19:13:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 19:13:08 --> Database Driver Class Initialized
DEBUG - 2011-07-04 19:13:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 19:13:08 --> Helper loaded: url_helper
DEBUG - 2011-07-04 19:13:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 19:13:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 19:13:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 19:13:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 19:13:08 --> Final output sent to browser
DEBUG - 2011-07-04 19:13:08 --> Total execution time: 0.4262
DEBUG - 2011-07-04 19:13:10 --> Config Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Hooks Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Utf8 Class Initialized
DEBUG - 2011-07-04 19:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 19:13:10 --> URI Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Router Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Output Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Input Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 19:13:10 --> Language Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Loader Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Controller Class Initialized
ERROR - 2011-07-04 19:13:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 19:13:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 19:13:10 --> Model Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Model Class Initialized
DEBUG - 2011-07-04 19:13:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 19:13:10 --> Database Driver Class Initialized
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 19:13:10 --> Helper loaded: url_helper
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 19:13:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 19:13:10 --> Final output sent to browser
DEBUG - 2011-07-04 19:13:10 --> Total execution time: 0.0389
DEBUG - 2011-07-04 19:35:16 --> Config Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Hooks Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Utf8 Class Initialized
DEBUG - 2011-07-04 19:35:16 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 19:35:16 --> URI Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Router Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Output Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Input Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 19:35:16 --> Language Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Loader Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Controller Class Initialized
ERROR - 2011-07-04 19:35:16 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 19:35:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 19:35:16 --> Model Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Model Class Initialized
DEBUG - 2011-07-04 19:35:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 19:35:16 --> Database Driver Class Initialized
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 19:35:16 --> Helper loaded: url_helper
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 19:35:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 19:35:16 --> Final output sent to browser
DEBUG - 2011-07-04 19:35:16 --> Total execution time: 0.3216
DEBUG - 2011-07-04 20:37:48 --> Config Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Hooks Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Utf8 Class Initialized
DEBUG - 2011-07-04 20:37:48 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 20:37:48 --> URI Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Router Class Initialized
DEBUG - 2011-07-04 20:37:48 --> No URI present. Default controller set.
DEBUG - 2011-07-04 20:37:48 --> Output Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Input Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 20:37:48 --> Language Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Loader Class Initialized
DEBUG - 2011-07-04 20:37:48 --> Controller Class Initialized
DEBUG - 2011-07-04 20:37:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 20:37:49 --> Helper loaded: url_helper
DEBUG - 2011-07-04 20:37:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 20:37:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 20:37:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 20:37:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 20:37:49 --> Final output sent to browser
DEBUG - 2011-07-04 20:37:49 --> Total execution time: 0.2281
DEBUG - 2011-07-04 22:22:55 --> Config Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:22:55 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:22:55 --> URI Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Router Class Initialized
DEBUG - 2011-07-04 22:22:55 --> No URI present. Default controller set.
DEBUG - 2011-07-04 22:22:55 --> Output Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Input Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 22:22:55 --> Language Class Initialized
DEBUG - 2011-07-04 22:22:55 --> Loader Class Initialized
DEBUG - 2011-07-04 22:22:56 --> Controller Class Initialized
DEBUG - 2011-07-04 22:22:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 22:22:56 --> Helper loaded: url_helper
DEBUG - 2011-07-04 22:22:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 22:22:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 22:22:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 22:22:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 22:22:56 --> Final output sent to browser
DEBUG - 2011-07-04 22:22:56 --> Total execution time: 0.2675
DEBUG - 2011-07-04 22:22:58 --> Config Class Initialized
DEBUG - 2011-07-04 22:22:58 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:22:58 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:22:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:22:58 --> URI Class Initialized
DEBUG - 2011-07-04 22:22:58 --> Router Class Initialized
ERROR - 2011-07-04 22:22:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 22:22:59 --> Config Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:22:59 --> URI Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Router Class Initialized
ERROR - 2011-07-04 22:22:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 22:22:59 --> Config Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:22:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:22:59 --> URI Class Initialized
DEBUG - 2011-07-04 22:22:59 --> Router Class Initialized
ERROR - 2011-07-04 22:22:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-04 22:23:11 --> Config Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:23:11 --> URI Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Router Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Output Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Input Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 22:23:11 --> Language Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Loader Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Controller Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 22:23:11 --> Database Driver Class Initialized
DEBUG - 2011-07-04 22:23:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 22:23:12 --> Helper loaded: url_helper
DEBUG - 2011-07-04 22:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 22:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 22:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 22:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 22:23:12 --> Final output sent to browser
DEBUG - 2011-07-04 22:23:12 --> Total execution time: 0.5373
DEBUG - 2011-07-04 22:23:26 --> Config Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:23:26 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:23:26 --> URI Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Router Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Output Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Input Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 22:23:26 --> Language Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Loader Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Controller Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 22:23:26 --> Database Driver Class Initialized
DEBUG - 2011-07-04 22:23:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 22:23:26 --> Helper loaded: url_helper
DEBUG - 2011-07-04 22:23:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 22:23:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 22:23:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 22:23:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 22:23:26 --> Final output sent to browser
DEBUG - 2011-07-04 22:23:26 --> Total execution time: 0.4517
DEBUG - 2011-07-04 22:23:28 --> Config Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:23:28 --> URI Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Router Class Initialized
ERROR - 2011-07-04 22:23:28 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 22:23:28 --> Config Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:23:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:23:28 --> URI Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Router Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Output Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Input Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 22:23:28 --> Language Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Loader Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Controller Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Model Class Initialized
DEBUG - 2011-07-04 22:23:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 22:23:28 --> Database Driver Class Initialized
DEBUG - 2011-07-04 22:23:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 22:23:28 --> Helper loaded: url_helper
DEBUG - 2011-07-04 22:23:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 22:23:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 22:23:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 22:23:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 22:23:28 --> Final output sent to browser
DEBUG - 2011-07-04 22:23:28 --> Total execution time: 0.0661
DEBUG - 2011-07-04 22:30:10 --> Config Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Hooks Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Utf8 Class Initialized
DEBUG - 2011-07-04 22:30:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 22:30:10 --> URI Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Router Class Initialized
DEBUG - 2011-07-04 22:30:10 --> No URI present. Default controller set.
DEBUG - 2011-07-04 22:30:10 --> Output Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Input Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 22:30:10 --> Language Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Loader Class Initialized
DEBUG - 2011-07-04 22:30:10 --> Controller Class Initialized
DEBUG - 2011-07-04 22:30:10 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-04 22:30:10 --> Helper loaded: url_helper
DEBUG - 2011-07-04 22:30:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 22:30:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 22:30:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 22:30:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 22:30:10 --> Final output sent to browser
DEBUG - 2011-07-04 22:30:10 --> Total execution time: 0.0135
DEBUG - 2011-07-04 23:36:58 --> Config Class Initialized
DEBUG - 2011-07-04 23:36:58 --> Hooks Class Initialized
DEBUG - 2011-07-04 23:36:58 --> Utf8 Class Initialized
DEBUG - 2011-07-04 23:36:58 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 23:36:58 --> URI Class Initialized
DEBUG - 2011-07-04 23:36:58 --> Router Class Initialized
ERROR - 2011-07-04 23:36:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-04 23:39:09 --> Config Class Initialized
DEBUG - 2011-07-04 23:39:09 --> Hooks Class Initialized
DEBUG - 2011-07-04 23:39:09 --> Utf8 Class Initialized
DEBUG - 2011-07-04 23:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 23:39:09 --> URI Class Initialized
DEBUG - 2011-07-04 23:39:09 --> Router Class Initialized
DEBUG - 2011-07-04 23:39:10 --> Output Class Initialized
DEBUG - 2011-07-04 23:39:10 --> Input Class Initialized
DEBUG - 2011-07-04 23:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 23:39:10 --> Language Class Initialized
DEBUG - 2011-07-04 23:39:10 --> Loader Class Initialized
DEBUG - 2011-07-04 23:39:11 --> Controller Class Initialized
DEBUG - 2011-07-04 23:39:11 --> Model Class Initialized
DEBUG - 2011-07-04 23:39:11 --> Model Class Initialized
DEBUG - 2011-07-04 23:39:11 --> Model Class Initialized
DEBUG - 2011-07-04 23:39:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 23:39:11 --> Database Driver Class Initialized
DEBUG - 2011-07-04 23:39:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-04 23:39:13 --> Helper loaded: url_helper
DEBUG - 2011-07-04 23:39:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 23:39:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 23:39:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 23:39:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 23:39:13 --> Final output sent to browser
DEBUG - 2011-07-04 23:39:13 --> Total execution time: 3.5356
DEBUG - 2011-07-04 23:39:14 --> Config Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Hooks Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Utf8 Class Initialized
DEBUG - 2011-07-04 23:39:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-04 23:39:14 --> URI Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Router Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Output Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Input Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-04 23:39:14 --> Language Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Loader Class Initialized
DEBUG - 2011-07-04 23:39:14 --> Controller Class Initialized
ERROR - 2011-07-04 23:39:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-04 23:39:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 23:39:15 --> Model Class Initialized
DEBUG - 2011-07-04 23:39:15 --> Model Class Initialized
DEBUG - 2011-07-04 23:39:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-04 23:39:15 --> Database Driver Class Initialized
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-04 23:39:15 --> Helper loaded: url_helper
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-04 23:39:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-04 23:39:15 --> Final output sent to browser
DEBUG - 2011-07-04 23:39:15 --> Total execution time: 1.0881

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-06-10 01:05:08 --> Config Class Initialized
DEBUG - 2011-06-10 01:05:08 --> Hooks Class Initialized
DEBUG - 2011-06-10 01:05:08 --> Utf8 Class Initialized
DEBUG - 2011-06-10 01:05:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 01:05:08 --> URI Class Initialized
DEBUG - 2011-06-10 01:05:08 --> Router Class Initialized
ERROR - 2011-06-10 01:05:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 01:05:09 --> Config Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Hooks Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Utf8 Class Initialized
DEBUG - 2011-06-10 01:05:09 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 01:05:09 --> URI Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Router Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Output Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Input Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 01:05:09 --> Language Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Loader Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Controller Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Model Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Model Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Model Class Initialized
DEBUG - 2011-06-10 01:05:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 01:05:09 --> Database Driver Class Initialized
DEBUG - 2011-06-10 01:05:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 01:05:09 --> Helper loaded: url_helper
DEBUG - 2011-06-10 01:05:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 01:05:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 01:05:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 01:05:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 01:05:09 --> Final output sent to browser
DEBUG - 2011-06-10 01:05:09 --> Total execution time: 0.4965
DEBUG - 2011-06-10 01:05:39 --> Config Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Hooks Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Utf8 Class Initialized
DEBUG - 2011-06-10 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 01:05:39 --> URI Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Router Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Output Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Input Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 01:05:39 --> Language Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Loader Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Controller Class Initialized
ERROR - 2011-06-10 01:05:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 01:05:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 01:05:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 01:05:39 --> Model Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Model Class Initialized
DEBUG - 2011-06-10 01:05:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 01:05:39 --> Database Driver Class Initialized
DEBUG - 2011-06-10 01:05:40 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 01:05:40 --> Helper loaded: url_helper
DEBUG - 2011-06-10 01:05:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 01:05:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 01:05:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 01:05:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 01:05:40 --> Final output sent to browser
DEBUG - 2011-06-10 01:05:40 --> Total execution time: 0.0957
DEBUG - 2011-06-10 01:49:24 --> Config Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 01:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 01:49:24 --> URI Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Router Class Initialized
ERROR - 2011-06-10 01:49:24 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 01:49:24 --> Config Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 01:49:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 01:49:24 --> URI Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Router Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Output Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Input Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 01:49:24 --> Language Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Loader Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Controller Class Initialized
ERROR - 2011-06-10 01:49:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 01:49:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 01:49:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 01:49:24 --> Model Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Model Class Initialized
DEBUG - 2011-06-10 01:49:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 01:49:25 --> Database Driver Class Initialized
DEBUG - 2011-06-10 01:49:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 01:49:25 --> Helper loaded: url_helper
DEBUG - 2011-06-10 01:49:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 01:49:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 01:49:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 01:49:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 01:49:25 --> Final output sent to browser
DEBUG - 2011-06-10 01:49:25 --> Total execution time: 0.5241
DEBUG - 2011-06-10 02:56:51 --> Config Class Initialized
DEBUG - 2011-06-10 02:56:51 --> Hooks Class Initialized
DEBUG - 2011-06-10 02:56:51 --> Utf8 Class Initialized
DEBUG - 2011-06-10 02:56:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 02:56:51 --> URI Class Initialized
DEBUG - 2011-06-10 02:56:51 --> Router Class Initialized
DEBUG - 2011-06-10 02:56:52 --> Output Class Initialized
DEBUG - 2011-06-10 02:56:53 --> Input Class Initialized
DEBUG - 2011-06-10 02:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 02:56:53 --> Language Class Initialized
DEBUG - 2011-06-10 02:56:54 --> Loader Class Initialized
DEBUG - 2011-06-10 02:56:54 --> Controller Class Initialized
DEBUG - 2011-06-10 02:56:54 --> Model Class Initialized
DEBUG - 2011-06-10 02:56:54 --> Model Class Initialized
DEBUG - 2011-06-10 02:56:55 --> Model Class Initialized
DEBUG - 2011-06-10 02:56:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 02:56:55 --> Database Driver Class Initialized
DEBUG - 2011-06-10 02:57:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 02:57:01 --> Helper loaded: url_helper
DEBUG - 2011-06-10 02:57:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 02:57:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 02:57:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 02:57:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 02:57:01 --> Final output sent to browser
DEBUG - 2011-06-10 02:57:01 --> Total execution time: 10.4840
DEBUG - 2011-06-10 02:57:02 --> Config Class Initialized
DEBUG - 2011-06-10 02:57:02 --> Hooks Class Initialized
DEBUG - 2011-06-10 02:57:02 --> Utf8 Class Initialized
DEBUG - 2011-06-10 02:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 02:57:02 --> URI Class Initialized
DEBUG - 2011-06-10 02:57:02 --> Router Class Initialized
ERROR - 2011-06-10 02:57:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 02:59:11 --> Config Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Hooks Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Utf8 Class Initialized
DEBUG - 2011-06-10 02:59:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 02:59:11 --> URI Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Router Class Initialized
DEBUG - 2011-06-10 02:59:11 --> No URI present. Default controller set.
DEBUG - 2011-06-10 02:59:11 --> Output Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Input Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 02:59:11 --> Language Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Loader Class Initialized
DEBUG - 2011-06-10 02:59:11 --> Controller Class Initialized
DEBUG - 2011-06-10 02:59:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 02:59:11 --> Helper loaded: url_helper
DEBUG - 2011-06-10 02:59:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 02:59:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 02:59:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 02:59:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 02:59:11 --> Final output sent to browser
DEBUG - 2011-06-10 02:59:11 --> Total execution time: 0.0994
DEBUG - 2011-06-10 03:00:54 --> Config Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Hooks Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Utf8 Class Initialized
DEBUG - 2011-06-10 03:00:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 03:00:54 --> URI Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Router Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Output Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Input Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 03:00:54 --> Language Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Loader Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Controller Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Model Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Model Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Model Class Initialized
DEBUG - 2011-06-10 03:00:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 03:00:54 --> Database Driver Class Initialized
DEBUG - 2011-06-10 03:00:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 03:00:58 --> Helper loaded: url_helper
DEBUG - 2011-06-10 03:00:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 03:00:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 03:00:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 03:00:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 03:00:58 --> Final output sent to browser
DEBUG - 2011-06-10 03:00:58 --> Total execution time: 4.3569
DEBUG - 2011-06-10 03:01:00 --> Config Class Initialized
DEBUG - 2011-06-10 03:01:00 --> Hooks Class Initialized
DEBUG - 2011-06-10 03:01:00 --> Utf8 Class Initialized
DEBUG - 2011-06-10 03:01:00 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 03:01:00 --> URI Class Initialized
DEBUG - 2011-06-10 03:01:00 --> Router Class Initialized
ERROR - 2011-06-10 03:01:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 03:22:23 --> Config Class Initialized
DEBUG - 2011-06-10 03:22:23 --> Hooks Class Initialized
DEBUG - 2011-06-10 03:22:23 --> Utf8 Class Initialized
DEBUG - 2011-06-10 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 03:22:23 --> URI Class Initialized
DEBUG - 2011-06-10 03:22:23 --> Router Class Initialized
ERROR - 2011-06-10 03:22:23 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 03:23:11 --> Config Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Hooks Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Utf8 Class Initialized
DEBUG - 2011-06-10 03:23:11 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 03:23:11 --> URI Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Router Class Initialized
DEBUG - 2011-06-10 03:23:11 --> No URI present. Default controller set.
DEBUG - 2011-06-10 03:23:11 --> Output Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Input Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 03:23:11 --> Language Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Loader Class Initialized
DEBUG - 2011-06-10 03:23:11 --> Controller Class Initialized
DEBUG - 2011-06-10 03:23:12 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 03:23:12 --> Helper loaded: url_helper
DEBUG - 2011-06-10 03:23:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 03:23:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 03:23:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 03:23:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 03:23:12 --> Final output sent to browser
DEBUG - 2011-06-10 03:23:12 --> Total execution time: 0.1987
DEBUG - 2011-06-10 04:58:27 --> Config Class Initialized
DEBUG - 2011-06-10 04:58:27 --> Hooks Class Initialized
DEBUG - 2011-06-10 04:58:27 --> Utf8 Class Initialized
DEBUG - 2011-06-10 04:58:27 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 04:58:27 --> URI Class Initialized
DEBUG - 2011-06-10 04:58:28 --> Router Class Initialized
DEBUG - 2011-06-10 04:58:28 --> No URI present. Default controller set.
DEBUG - 2011-06-10 04:58:28 --> Output Class Initialized
DEBUG - 2011-06-10 04:58:28 --> Input Class Initialized
DEBUG - 2011-06-10 04:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 04:58:28 --> Language Class Initialized
DEBUG - 2011-06-10 04:58:28 --> Loader Class Initialized
DEBUG - 2011-06-10 04:58:28 --> Controller Class Initialized
DEBUG - 2011-06-10 04:58:28 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 04:58:28 --> Helper loaded: url_helper
DEBUG - 2011-06-10 04:58:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 04:58:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 04:58:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 04:58:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 04:58:28 --> Final output sent to browser
DEBUG - 2011-06-10 04:58:28 --> Total execution time: 0.2522
DEBUG - 2011-06-10 04:58:32 --> Config Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Hooks Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Utf8 Class Initialized
DEBUG - 2011-06-10 04:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 04:58:32 --> URI Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Router Class Initialized
ERROR - 2011-06-10 04:58:32 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 04:58:32 --> Config Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Hooks Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Utf8 Class Initialized
DEBUG - 2011-06-10 04:58:32 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 04:58:32 --> URI Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Router Class Initialized
DEBUG - 2011-06-10 04:58:32 --> No URI present. Default controller set.
DEBUG - 2011-06-10 04:58:32 --> Output Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Input Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 04:58:32 --> Language Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Loader Class Initialized
DEBUG - 2011-06-10 04:58:32 --> Controller Class Initialized
DEBUG - 2011-06-10 04:58:32 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 04:58:32 --> Helper loaded: url_helper
DEBUG - 2011-06-10 04:58:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 04:58:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 04:58:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 04:58:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 04:58:32 --> Final output sent to browser
DEBUG - 2011-06-10 04:58:32 --> Total execution time: 0.0246
DEBUG - 2011-06-10 04:58:37 --> Config Class Initialized
DEBUG - 2011-06-10 04:58:37 --> Hooks Class Initialized
DEBUG - 2011-06-10 04:58:37 --> Utf8 Class Initialized
DEBUG - 2011-06-10 04:58:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 04:58:37 --> URI Class Initialized
DEBUG - 2011-06-10 04:58:37 --> Router Class Initialized
ERROR - 2011-06-10 04:58:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 04:58:40 --> Config Class Initialized
DEBUG - 2011-06-10 04:58:40 --> Hooks Class Initialized
DEBUG - 2011-06-10 04:58:40 --> Utf8 Class Initialized
DEBUG - 2011-06-10 04:58:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 04:58:40 --> URI Class Initialized
DEBUG - 2011-06-10 04:58:40 --> Router Class Initialized
ERROR - 2011-06-10 04:58:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 05:28:06 --> Config Class Initialized
DEBUG - 2011-06-10 05:28:06 --> Hooks Class Initialized
DEBUG - 2011-06-10 05:28:06 --> Utf8 Class Initialized
DEBUG - 2011-06-10 05:28:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 05:28:06 --> URI Class Initialized
DEBUG - 2011-06-10 05:28:06 --> Router Class Initialized
ERROR - 2011-06-10 05:28:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 05:33:23 --> Config Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Hooks Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Utf8 Class Initialized
DEBUG - 2011-06-10 05:33:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 05:33:23 --> URI Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Router Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Output Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Input Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 05:33:23 --> Language Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Loader Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Controller Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Model Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Model Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Model Class Initialized
DEBUG - 2011-06-10 05:33:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 05:33:24 --> Database Driver Class Initialized
DEBUG - 2011-06-10 05:33:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 05:33:25 --> Helper loaded: url_helper
DEBUG - 2011-06-10 05:33:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 05:33:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 05:33:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 05:33:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 05:33:25 --> Final output sent to browser
DEBUG - 2011-06-10 05:33:25 --> Total execution time: 2.0912
DEBUG - 2011-06-10 05:33:26 --> Config Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Hooks Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Utf8 Class Initialized
DEBUG - 2011-06-10 05:33:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 05:33:26 --> URI Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Router Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Output Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Input Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 05:33:26 --> Language Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Loader Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Controller Class Initialized
ERROR - 2011-06-10 05:33:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 05:33:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 05:33:26 --> Model Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Model Class Initialized
DEBUG - 2011-06-10 05:33:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 05:33:26 --> Database Driver Class Initialized
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 05:33:26 --> Helper loaded: url_helper
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 05:33:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 05:33:26 --> Final output sent to browser
DEBUG - 2011-06-10 05:33:26 --> Total execution time: 0.3053
DEBUG - 2011-06-10 06:40:33 --> Config Class Initialized
DEBUG - 2011-06-10 06:40:33 --> Hooks Class Initialized
DEBUG - 2011-06-10 06:40:33 --> Utf8 Class Initialized
DEBUG - 2011-06-10 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 06:40:33 --> URI Class Initialized
DEBUG - 2011-06-10 06:40:33 --> Router Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Output Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Input Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 06:40:34 --> Language Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Loader Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Controller Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Model Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Model Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 06:40:34 --> Database Driver Class Initialized
DEBUG - 2011-06-10 06:40:34 --> Final output sent to browser
DEBUG - 2011-06-10 06:40:34 --> Total execution time: 1.0482
DEBUG - 2011-06-10 07:08:50 --> Config Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:08:50 --> URI Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Router Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Output Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Input Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:08:50 --> Language Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Loader Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Controller Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Model Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Model Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Model Class Initialized
DEBUG - 2011-06-10 07:08:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:08:50 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:08:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:08:50 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:08:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:08:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:08:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:08:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:08:50 --> Final output sent to browser
DEBUG - 2011-06-10 07:08:50 --> Total execution time: 0.6315
DEBUG - 2011-06-10 07:08:52 --> Config Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:08:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:08:52 --> URI Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Router Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Output Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Input Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:08:52 --> Language Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Loader Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Controller Class Initialized
ERROR - 2011-06-10 07:08:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 07:08:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 07:08:52 --> Model Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Model Class Initialized
DEBUG - 2011-06-10 07:08:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:08:52 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 07:08:52 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:08:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:08:52 --> Final output sent to browser
DEBUG - 2011-06-10 07:08:52 --> Total execution time: 0.0893
DEBUG - 2011-06-10 07:17:01 --> Config Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:17:01 --> URI Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Router Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Output Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Input Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:17:01 --> Language Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Loader Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Controller Class Initialized
DEBUG - 2011-06-10 07:17:01 --> Model Class Initialized
DEBUG - 2011-06-10 07:17:02 --> Model Class Initialized
DEBUG - 2011-06-10 07:17:02 --> Model Class Initialized
DEBUG - 2011-06-10 07:17:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:17:02 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:17:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:17:02 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:17:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:17:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:17:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:17:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:17:02 --> Final output sent to browser
DEBUG - 2011-06-10 07:17:02 --> Total execution time: 0.1835
DEBUG - 2011-06-10 07:30:35 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:35 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:35 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:35 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:35 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:35 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:35 --> Total execution time: 0.2737
DEBUG - 2011-06-10 07:30:38 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:38 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:38 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:38 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:38 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:38 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:38 --> Total execution time: 0.0482
DEBUG - 2011-06-10 07:30:39 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:39 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:39 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:39 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:39 --> Router Class Initialized
ERROR - 2011-06-10 07:30:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 07:30:46 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:46 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:46 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:46 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:47 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:47 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:47 --> Total execution time: 1.0377
DEBUG - 2011-06-10 07:30:47 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:47 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:47 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:47 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:47 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:47 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:47 --> Total execution time: 0.0484
DEBUG - 2011-06-10 07:30:48 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:48 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:48 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:48 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:48 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:48 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:48 --> Total execution time: 0.0523
DEBUG - 2011-06-10 07:30:49 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:49 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Router Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Output Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Input Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:30:49 --> Language Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Loader Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Controller Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Model Class Initialized
DEBUG - 2011-06-10 07:30:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:30:49 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:30:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:30:49 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:30:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:30:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:30:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:30:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:30:49 --> Final output sent to browser
DEBUG - 2011-06-10 07:30:49 --> Total execution time: 0.0459
DEBUG - 2011-06-10 07:30:50 --> Config Class Initialized
DEBUG - 2011-06-10 07:30:50 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:30:50 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:30:50 --> URI Class Initialized
DEBUG - 2011-06-10 07:30:50 --> Router Class Initialized
ERROR - 2011-06-10 07:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 07:31:01 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:01 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:01 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:01 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:02 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:02 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:02 --> Total execution time: 1.6803
DEBUG - 2011-06-10 07:31:03 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:03 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:03 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:03 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:03 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:03 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:03 --> Total execution time: 0.0407
DEBUG - 2011-06-10 07:31:04 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:04 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:04 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:04 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:04 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:04 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:04 --> Total execution time: 0.0428
DEBUG - 2011-06-10 07:31:05 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:05 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:05 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:05 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:05 --> Router Class Initialized
ERROR - 2011-06-10 07:31:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 07:31:24 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:24 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:24 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:24 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:25 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:25 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:25 --> Total execution time: 0.2406
DEBUG - 2011-06-10 07:31:26 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:26 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:26 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:26 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:26 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:26 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:26 --> Total execution time: 0.0729
DEBUG - 2011-06-10 07:31:26 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:26 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:26 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Router Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Output Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Input Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:31:26 --> Language Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Loader Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Controller Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Model Class Initialized
DEBUG - 2011-06-10 07:31:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:31:26 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 07:31:26 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:31:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:31:26 --> Final output sent to browser
DEBUG - 2011-06-10 07:31:26 --> Total execution time: 0.0695
DEBUG - 2011-06-10 07:31:29 --> Config Class Initialized
DEBUG - 2011-06-10 07:31:29 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:31:29 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:31:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:31:29 --> URI Class Initialized
DEBUG - 2011-06-10 07:31:29 --> Router Class Initialized
ERROR - 2011-06-10 07:31:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 07:34:33 --> Config Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:34:33 --> URI Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Router Class Initialized
ERROR - 2011-06-10 07:34:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 07:34:33 --> Config Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Hooks Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Utf8 Class Initialized
DEBUG - 2011-06-10 07:34:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 07:34:33 --> URI Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Router Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Output Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Input Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 07:34:33 --> Language Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Loader Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Controller Class Initialized
ERROR - 2011-06-10 07:34:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 07:34:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 07:34:33 --> Model Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Model Class Initialized
DEBUG - 2011-06-10 07:34:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 07:34:33 --> Database Driver Class Initialized
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 07:34:33 --> Helper loaded: url_helper
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 07:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 07:34:33 --> Final output sent to browser
DEBUG - 2011-06-10 07:34:33 --> Total execution time: 0.0692
DEBUG - 2011-06-10 08:18:54 --> Config Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Hooks Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Utf8 Class Initialized
DEBUG - 2011-06-10 08:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 08:18:54 --> URI Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Router Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Output Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Input Class Initialized
DEBUG - 2011-06-10 08:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 08:18:54 --> Language Class Initialized
DEBUG - 2011-06-10 08:18:55 --> Loader Class Initialized
DEBUG - 2011-06-10 08:18:55 --> Controller Class Initialized
ERROR - 2011-06-10 08:18:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 08:18:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 08:18:55 --> Model Class Initialized
DEBUG - 2011-06-10 08:18:55 --> Model Class Initialized
DEBUG - 2011-06-10 08:18:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 08:18:55 --> Database Driver Class Initialized
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 08:18:55 --> Helper loaded: url_helper
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 08:18:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 08:18:55 --> Final output sent to browser
DEBUG - 2011-06-10 08:18:55 --> Total execution time: 0.4073
DEBUG - 2011-06-10 08:41:10 --> Config Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Hooks Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Utf8 Class Initialized
DEBUG - 2011-06-10 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 08:41:10 --> URI Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Router Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Output Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Input Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 08:41:10 --> Language Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Loader Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Controller Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Model Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Model Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Model Class Initialized
DEBUG - 2011-06-10 08:41:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 08:41:10 --> Database Driver Class Initialized
DEBUG - 2011-06-10 08:41:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 08:41:10 --> Helper loaded: url_helper
DEBUG - 2011-06-10 08:41:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 08:41:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 08:41:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 08:41:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 08:41:10 --> Final output sent to browser
DEBUG - 2011-06-10 08:41:10 --> Total execution time: 0.5117
DEBUG - 2011-06-10 08:41:12 --> Config Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Hooks Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Utf8 Class Initialized
DEBUG - 2011-06-10 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 08:41:12 --> URI Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Router Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Output Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Input Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 08:41:12 --> Language Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Loader Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Controller Class Initialized
ERROR - 2011-06-10 08:41:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 08:41:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 08:41:12 --> Model Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Model Class Initialized
DEBUG - 2011-06-10 08:41:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 08:41:12 --> Database Driver Class Initialized
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 08:41:12 --> Helper loaded: url_helper
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 08:41:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 08:41:12 --> Final output sent to browser
DEBUG - 2011-06-10 08:41:12 --> Total execution time: 0.0785
DEBUG - 2011-06-10 09:54:48 --> Config Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Hooks Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Utf8 Class Initialized
DEBUG - 2011-06-10 09:54:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 09:54:48 --> URI Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Router Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Output Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Input Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 09:54:48 --> Language Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Loader Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Controller Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Model Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Model Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Model Class Initialized
DEBUG - 2011-06-10 09:54:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 09:54:48 --> Database Driver Class Initialized
DEBUG - 2011-06-10 09:54:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 09:54:48 --> Helper loaded: url_helper
DEBUG - 2011-06-10 09:54:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 09:54:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 09:54:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 09:54:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 09:54:48 --> Final output sent to browser
DEBUG - 2011-06-10 09:54:48 --> Total execution time: 0.4893
DEBUG - 2011-06-10 09:54:51 --> Config Class Initialized
DEBUG - 2011-06-10 09:54:51 --> Hooks Class Initialized
DEBUG - 2011-06-10 09:54:51 --> Utf8 Class Initialized
DEBUG - 2011-06-10 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 09:54:51 --> URI Class Initialized
DEBUG - 2011-06-10 09:54:51 --> Router Class Initialized
ERROR - 2011-06-10 09:54:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 09:54:52 --> Config Class Initialized
DEBUG - 2011-06-10 09:54:52 --> Hooks Class Initialized
DEBUG - 2011-06-10 09:54:52 --> Utf8 Class Initialized
DEBUG - 2011-06-10 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 09:54:52 --> URI Class Initialized
DEBUG - 2011-06-10 09:54:52 --> Router Class Initialized
ERROR - 2011-06-10 09:54:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 10:14:47 --> Config Class Initialized
DEBUG - 2011-06-10 10:14:47 --> Hooks Class Initialized
DEBUG - 2011-06-10 10:14:47 --> Utf8 Class Initialized
DEBUG - 2011-06-10 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 10:14:48 --> URI Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Router Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Output Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Input Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 10:14:48 --> Language Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Loader Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Controller Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Model Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Model Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Model Class Initialized
DEBUG - 2011-06-10 10:14:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 10:14:48 --> Database Driver Class Initialized
DEBUG - 2011-06-10 10:14:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 10:14:50 --> Helper loaded: url_helper
DEBUG - 2011-06-10 10:14:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 10:14:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 10:14:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 10:14:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 10:14:50 --> Final output sent to browser
DEBUG - 2011-06-10 10:14:50 --> Total execution time: 3.2807
DEBUG - 2011-06-10 10:14:52 --> Config Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Hooks Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Utf8 Class Initialized
DEBUG - 2011-06-10 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 10:14:52 --> URI Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Router Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Output Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Input Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 10:14:52 --> Language Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Loader Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Controller Class Initialized
ERROR - 2011-06-10 10:14:52 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 10:14:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 10:14:52 --> Model Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Model Class Initialized
DEBUG - 2011-06-10 10:14:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 10:14:52 --> Database Driver Class Initialized
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 10:14:52 --> Helper loaded: url_helper
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 10:14:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 10:14:52 --> Final output sent to browser
DEBUG - 2011-06-10 10:14:52 --> Total execution time: 0.3901
DEBUG - 2011-06-10 10:52:50 --> Config Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Hooks Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Utf8 Class Initialized
DEBUG - 2011-06-10 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 10:52:51 --> URI Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Router Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Output Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Input Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 10:52:51 --> Language Class Initialized
DEBUG - 2011-06-10 10:52:51 --> Loader Class Initialized
DEBUG - 2011-06-10 10:52:52 --> Controller Class Initialized
DEBUG - 2011-06-10 10:52:52 --> Model Class Initialized
DEBUG - 2011-06-10 10:52:52 --> Model Class Initialized
DEBUG - 2011-06-10 10:52:52 --> Model Class Initialized
DEBUG - 2011-06-10 10:52:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 10:52:53 --> Database Driver Class Initialized
DEBUG - 2011-06-10 10:52:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 10:52:57 --> Helper loaded: url_helper
DEBUG - 2011-06-10 10:52:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 10:52:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 10:52:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 10:52:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 10:52:57 --> Final output sent to browser
DEBUG - 2011-06-10 10:52:57 --> Total execution time: 6.2244
DEBUG - 2011-06-10 11:12:17 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:17 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:17 --> No URI present. Default controller set.
DEBUG - 2011-06-10 11:12:17 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:17 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 11:12:17 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:17 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:17 --> Total execution time: 0.3062
DEBUG - 2011-06-10 11:12:17 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:17 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:17 --> No URI present. Default controller set.
DEBUG - 2011-06-10 11:12:17 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:17 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:17 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 11:12:17 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:17 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:17 --> Total execution time: 0.0122
DEBUG - 2011-06-10 11:12:19 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:19 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Router Class Initialized
ERROR - 2011-06-10 11:12:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 11:12:19 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:19 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Router Class Initialized
ERROR - 2011-06-10 11:12:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 11:12:19 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:19 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:19 --> Router Class Initialized
ERROR - 2011-06-10 11:12:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 11:12:23 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:23 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:23 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:12:23 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:12:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:12:23 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:23 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:23 --> Total execution time: 0.2636
DEBUG - 2011-06-10 11:12:37 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:37 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:37 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:12:37 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:12:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:12:38 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:38 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:38 --> Total execution time: 0.4629
DEBUG - 2011-06-10 11:12:40 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:40 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:40 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:12:40 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:12:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:12:40 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:40 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:40 --> Total execution time: 0.0588
DEBUG - 2011-06-10 11:12:51 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:51 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:51 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:51 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:12:51 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:12:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:12:51 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:51 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:51 --> Total execution time: 0.2539
DEBUG - 2011-06-10 11:12:53 --> Config Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:12:53 --> URI Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Router Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Output Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Input Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:12:53 --> Language Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Loader Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Controller Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Model Class Initialized
DEBUG - 2011-06-10 11:12:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:12:53 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:12:53 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:12:53 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:12:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:12:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:12:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:12:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:12:53 --> Final output sent to browser
DEBUG - 2011-06-10 11:12:53 --> Total execution time: 0.0443
DEBUG - 2011-06-10 11:13:02 --> Config Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:13:02 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:13:02 --> URI Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Router Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Output Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Input Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:13:02 --> Language Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Loader Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Controller Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:13:03 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:13:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:13:03 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:13:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:13:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:13:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:13:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:13:03 --> Final output sent to browser
DEBUG - 2011-06-10 11:13:03 --> Total execution time: 0.2441
DEBUG - 2011-06-10 11:13:04 --> Config Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:13:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:13:04 --> URI Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Router Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Output Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Input Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:13:04 --> Language Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Loader Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Controller Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:13:04 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:13:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:13:04 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:13:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:13:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:13:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:13:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:13:04 --> Final output sent to browser
DEBUG - 2011-06-10 11:13:04 --> Total execution time: 0.0587
DEBUG - 2011-06-10 11:13:05 --> Config Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:13:05 --> URI Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Router Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Output Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Input Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:13:05 --> Language Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Loader Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Controller Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:13:05 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:13:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:13:05 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:13:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:13:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:13:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:13:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:13:05 --> Final output sent to browser
DEBUG - 2011-06-10 11:13:05 --> Total execution time: 0.0470
DEBUG - 2011-06-10 11:13:16 --> Config Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:13:16 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:13:16 --> URI Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Router Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Output Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Input Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:13:16 --> Language Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Loader Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Controller Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:13:16 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:13:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:13:17 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:13:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:13:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:13:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:13:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:13:17 --> Final output sent to browser
DEBUG - 2011-06-10 11:13:17 --> Total execution time: 0.2888
DEBUG - 2011-06-10 11:13:18 --> Config Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:13:18 --> URI Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Router Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Output Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Input Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:13:18 --> Language Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Loader Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Controller Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Model Class Initialized
DEBUG - 2011-06-10 11:13:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:13:18 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:13:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:13:19 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:13:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:13:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:13:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:13:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:13:19 --> Final output sent to browser
DEBUG - 2011-06-10 11:13:19 --> Total execution time: 0.2039
DEBUG - 2011-06-10 11:49:17 --> Config Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:49:17 --> URI Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Router Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Output Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Input Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:49:17 --> Language Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Loader Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Controller Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Model Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Model Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Model Class Initialized
DEBUG - 2011-06-10 11:49:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:49:17 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:49:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 11:49:17 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:49:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:49:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:49:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:49:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:49:17 --> Final output sent to browser
DEBUG - 2011-06-10 11:49:17 --> Total execution time: 0.5789
DEBUG - 2011-06-10 11:49:18 --> Config Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Hooks Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Utf8 Class Initialized
DEBUG - 2011-06-10 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 11:49:18 --> URI Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Router Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Output Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Input Class Initialized
DEBUG - 2011-06-10 11:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 11:49:18 --> Language Class Initialized
DEBUG - 2011-06-10 11:49:19 --> Loader Class Initialized
DEBUG - 2011-06-10 11:49:19 --> Controller Class Initialized
ERROR - 2011-06-10 11:49:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 11:49:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 11:49:19 --> Model Class Initialized
DEBUG - 2011-06-10 11:49:19 --> Model Class Initialized
DEBUG - 2011-06-10 11:49:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 11:49:19 --> Database Driver Class Initialized
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 11:49:19 --> Helper loaded: url_helper
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 11:49:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 11:49:19 --> Final output sent to browser
DEBUG - 2011-06-10 11:49:19 --> Total execution time: 0.1108
DEBUG - 2011-06-10 12:12:58 --> Config Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:12:58 --> URI Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Router Class Initialized
ERROR - 2011-06-10 12:12:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 12:12:58 --> Config Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:12:58 --> URI Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Router Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Output Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Input Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 12:12:58 --> Language Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Loader Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Controller Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Model Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Model Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Model Class Initialized
DEBUG - 2011-06-10 12:12:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 12:12:58 --> Database Driver Class Initialized
DEBUG - 2011-06-10 12:12:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 12:12:59 --> Helper loaded: url_helper
DEBUG - 2011-06-10 12:12:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 12:12:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 12:12:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 12:12:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 12:12:59 --> Final output sent to browser
DEBUG - 2011-06-10 12:12:59 --> Total execution time: 0.6344
DEBUG - 2011-06-10 12:13:29 --> Config Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:13:29 --> URI Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Router Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Output Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Input Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 12:13:29 --> Language Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Loader Class Initialized
DEBUG - 2011-06-10 12:13:29 --> Controller Class Initialized
ERROR - 2011-06-10 12:13:30 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 12:13:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 12:13:30 --> Model Class Initialized
DEBUG - 2011-06-10 12:13:30 --> Model Class Initialized
DEBUG - 2011-06-10 12:13:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 12:13:30 --> Database Driver Class Initialized
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 12:13:30 --> Helper loaded: url_helper
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 12:13:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 12:13:30 --> Final output sent to browser
DEBUG - 2011-06-10 12:13:30 --> Total execution time: 0.1615
DEBUG - 2011-06-10 12:44:37 --> Config Class Initialized
DEBUG - 2011-06-10 12:44:37 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:44:37 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:44:37 --> URI Class Initialized
DEBUG - 2011-06-10 12:44:37 --> Router Class Initialized
ERROR - 2011-06-10 12:44:37 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 12:45:39 --> Config Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:45:39 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:45:39 --> URI Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Router Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Output Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Input Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 12:45:39 --> Language Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Loader Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Controller Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Model Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Model Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Model Class Initialized
DEBUG - 2011-06-10 12:45:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 12:45:39 --> Database Driver Class Initialized
DEBUG - 2011-06-10 12:45:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 12:45:40 --> Helper loaded: url_helper
DEBUG - 2011-06-10 12:45:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 12:45:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 12:45:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 12:45:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 12:45:40 --> Final output sent to browser
DEBUG - 2011-06-10 12:45:40 --> Total execution time: 1.7137
DEBUG - 2011-06-10 12:46:38 --> Config Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Hooks Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Utf8 Class Initialized
DEBUG - 2011-06-10 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 12:46:38 --> URI Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Router Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Output Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Input Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 12:46:38 --> Language Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Loader Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Controller Class Initialized
ERROR - 2011-06-10 12:46:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 12:46:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 12:46:38 --> Model Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Model Class Initialized
DEBUG - 2011-06-10 12:46:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 12:46:38 --> Database Driver Class Initialized
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 12:46:38 --> Helper loaded: url_helper
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 12:46:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 12:46:38 --> Final output sent to browser
DEBUG - 2011-06-10 12:46:38 --> Total execution time: 0.2457
DEBUG - 2011-06-10 13:17:03 --> Config Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:17:03 --> URI Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Router Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Output Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Input Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 13:17:03 --> Language Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Loader Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Controller Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Model Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Model Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Model Class Initialized
DEBUG - 2011-06-10 13:17:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 13:17:03 --> Database Driver Class Initialized
DEBUG - 2011-06-10 13:17:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 13:17:04 --> Helper loaded: url_helper
DEBUG - 2011-06-10 13:17:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 13:17:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 13:17:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 13:17:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 13:17:04 --> Final output sent to browser
DEBUG - 2011-06-10 13:17:04 --> Total execution time: 0.6882
DEBUG - 2011-06-10 13:17:06 --> Config Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:17:06 --> URI Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Router Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Output Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Input Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 13:17:06 --> Language Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Loader Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Controller Class Initialized
ERROR - 2011-06-10 13:17:06 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 13:17:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 13:17:06 --> Model Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Model Class Initialized
DEBUG - 2011-06-10 13:17:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 13:17:06 --> Database Driver Class Initialized
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 13:17:06 --> Helper loaded: url_helper
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 13:17:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 13:17:06 --> Final output sent to browser
DEBUG - 2011-06-10 13:17:06 --> Total execution time: 0.1007
DEBUG - 2011-06-10 13:29:08 --> Config Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:29:08 --> URI Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Router Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Output Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Input Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 13:29:08 --> Language Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Loader Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Controller Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Model Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Model Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Model Class Initialized
DEBUG - 2011-06-10 13:29:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 13:29:08 --> Database Driver Class Initialized
DEBUG - 2011-06-10 13:29:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 13:29:08 --> Helper loaded: url_helper
DEBUG - 2011-06-10 13:29:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 13:29:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 13:29:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 13:29:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 13:29:08 --> Final output sent to browser
DEBUG - 2011-06-10 13:29:08 --> Total execution time: 0.0800
DEBUG - 2011-06-10 13:29:13 --> Config Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:29:13 --> URI Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Router Class Initialized
ERROR - 2011-06-10 13:29:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 13:29:13 --> Config Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:29:13 --> URI Class Initialized
DEBUG - 2011-06-10 13:29:13 --> Router Class Initialized
ERROR - 2011-06-10 13:29:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 13:46:34 --> Config Class Initialized
DEBUG - 2011-06-10 13:46:34 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:46:34 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:46:34 --> URI Class Initialized
DEBUG - 2011-06-10 13:46:34 --> Router Class Initialized
ERROR - 2011-06-10 13:46:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 13:48:33 --> Config Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Hooks Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Utf8 Class Initialized
DEBUG - 2011-06-10 13:48:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 13:48:33 --> URI Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Router Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Output Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Input Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 13:48:33 --> Language Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Loader Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Controller Class Initialized
ERROR - 2011-06-10 13:48:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 13:48:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 13:48:33 --> Model Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Model Class Initialized
DEBUG - 2011-06-10 13:48:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 13:48:33 --> Database Driver Class Initialized
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 13:48:33 --> Helper loaded: url_helper
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 13:48:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 13:48:33 --> Final output sent to browser
DEBUG - 2011-06-10 13:48:33 --> Total execution time: 0.2405
DEBUG - 2011-06-10 14:06:54 --> Config Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:06:54 --> URI Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Router Class Initialized
DEBUG - 2011-06-10 14:06:54 --> No URI present. Default controller set.
DEBUG - 2011-06-10 14:06:54 --> Output Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Input Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:06:54 --> Language Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Loader Class Initialized
DEBUG - 2011-06-10 14:06:54 --> Controller Class Initialized
DEBUG - 2011-06-10 14:06:55 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 14:06:55 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:06:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:06:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:06:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:06:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:06:55 --> Final output sent to browser
DEBUG - 2011-06-10 14:06:55 --> Total execution time: 1.7878
DEBUG - 2011-06-10 14:16:38 --> Config Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:16:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:16:38 --> URI Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Router Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Output Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Input Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:16:38 --> Language Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Loader Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Controller Class Initialized
ERROR - 2011-06-10 14:16:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 14:16:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:16:38 --> Model Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Model Class Initialized
DEBUG - 2011-06-10 14:16:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 14:16:38 --> Database Driver Class Initialized
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:16:38 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:16:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:16:38 --> Final output sent to browser
DEBUG - 2011-06-10 14:16:38 --> Total execution time: 0.3330
DEBUG - 2011-06-10 14:30:55 --> Config Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:30:55 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:30:55 --> URI Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Router Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Output Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Input Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:30:55 --> Language Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Loader Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Controller Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Model Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Model Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Model Class Initialized
DEBUG - 2011-06-10 14:30:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 14:30:55 --> Database Driver Class Initialized
DEBUG - 2011-06-10 14:30:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 14:30:55 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:30:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:30:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:30:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:30:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:30:55 --> Final output sent to browser
DEBUG - 2011-06-10 14:30:55 --> Total execution time: 0.6327
DEBUG - 2011-06-10 14:30:56 --> Config Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:30:56 --> URI Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Router Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Output Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Input Class Initialized
DEBUG - 2011-06-10 14:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:30:56 --> Language Class Initialized
DEBUG - 2011-06-10 14:30:57 --> Loader Class Initialized
DEBUG - 2011-06-10 14:30:57 --> Controller Class Initialized
ERROR - 2011-06-10 14:30:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 14:30:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:30:57 --> Model Class Initialized
DEBUG - 2011-06-10 14:30:57 --> Model Class Initialized
DEBUG - 2011-06-10 14:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 14:30:57 --> Database Driver Class Initialized
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:30:57 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:30:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:30:57 --> Final output sent to browser
DEBUG - 2011-06-10 14:30:57 --> Total execution time: 0.0890
DEBUG - 2011-06-10 14:44:36 --> Config Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:44:36 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:44:36 --> URI Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Router Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Output Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Input Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:44:36 --> Language Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Loader Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Controller Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Model Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Model Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Model Class Initialized
DEBUG - 2011-06-10 14:44:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 14:44:36 --> Database Driver Class Initialized
DEBUG - 2011-06-10 14:44:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 14:44:36 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:44:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:44:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:44:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:44:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:44:36 --> Final output sent to browser
DEBUG - 2011-06-10 14:44:36 --> Total execution time: 0.1626
DEBUG - 2011-06-10 14:44:38 --> Config Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Hooks Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Utf8 Class Initialized
DEBUG - 2011-06-10 14:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 14:44:38 --> URI Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Router Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Output Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Input Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 14:44:38 --> Language Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Loader Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Controller Class Initialized
ERROR - 2011-06-10 14:44:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 14:44:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:44:38 --> Model Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Model Class Initialized
DEBUG - 2011-06-10 14:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 14:44:38 --> Database Driver Class Initialized
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 14:44:38 --> Helper loaded: url_helper
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 14:44:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 14:44:38 --> Final output sent to browser
DEBUG - 2011-06-10 14:44:38 --> Total execution time: 0.0471
DEBUG - 2011-06-10 15:14:45 --> Config Class Initialized
DEBUG - 2011-06-10 15:14:45 --> Hooks Class Initialized
DEBUG - 2011-06-10 15:14:45 --> Utf8 Class Initialized
DEBUG - 2011-06-10 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 15:14:45 --> URI Class Initialized
DEBUG - 2011-06-10 15:14:45 --> Router Class Initialized
ERROR - 2011-06-10 15:14:45 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 18:24:44 --> Config Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Hooks Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Utf8 Class Initialized
DEBUG - 2011-06-10 18:24:44 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 18:24:44 --> URI Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Router Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Output Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Input Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 18:24:44 --> Language Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Loader Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Controller Class Initialized
ERROR - 2011-06-10 18:24:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 18:24:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 18:24:44 --> Model Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Model Class Initialized
DEBUG - 2011-06-10 18:24:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 18:24:44 --> Database Driver Class Initialized
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 18:24:44 --> Helper loaded: url_helper
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 18:24:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 18:24:44 --> Final output sent to browser
DEBUG - 2011-06-10 18:24:44 --> Total execution time: 0.2911
DEBUG - 2011-06-10 18:24:45 --> Config Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Hooks Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Utf8 Class Initialized
DEBUG - 2011-06-10 18:24:45 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 18:24:45 --> URI Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Router Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Output Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Input Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 18:24:45 --> Language Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Loader Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Controller Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Model Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Model Class Initialized
DEBUG - 2011-06-10 18:24:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 18:24:45 --> Database Driver Class Initialized
DEBUG - 2011-06-10 18:24:46 --> Final output sent to browser
DEBUG - 2011-06-10 18:24:46 --> Total execution time: 0.6633
DEBUG - 2011-06-10 18:24:48 --> Config Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Hooks Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Utf8 Class Initialized
DEBUG - 2011-06-10 18:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 18:24:48 --> URI Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Router Class Initialized
ERROR - 2011-06-10 18:24:48 --> 404 Page Not Found --> crossdomain.xml
DEBUG - 2011-06-10 18:24:48 --> Config Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Hooks Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Utf8 Class Initialized
DEBUG - 2011-06-10 18:24:48 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 18:24:48 --> URI Class Initialized
DEBUG - 2011-06-10 18:24:48 --> Router Class Initialized
ERROR - 2011-06-10 18:24:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 18:24:49 --> Config Class Initialized
DEBUG - 2011-06-10 18:24:49 --> Hooks Class Initialized
DEBUG - 2011-06-10 18:24:49 --> Utf8 Class Initialized
DEBUG - 2011-06-10 18:24:49 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 18:24:49 --> URI Class Initialized
DEBUG - 2011-06-10 18:24:49 --> Router Class Initialized
ERROR - 2011-06-10 18:24:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-06-10 19:53:06 --> Config Class Initialized
DEBUG - 2011-06-10 19:53:06 --> Hooks Class Initialized
DEBUG - 2011-06-10 19:53:06 --> Utf8 Class Initialized
DEBUG - 2011-06-10 19:53:06 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 19:53:06 --> URI Class Initialized
DEBUG - 2011-06-10 19:53:06 --> Router Class Initialized
ERROR - 2011-06-10 19:53:06 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 19:54:05 --> Config Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Hooks Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Utf8 Class Initialized
DEBUG - 2011-06-10 19:54:05 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 19:54:05 --> URI Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Router Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Output Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Input Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 19:54:05 --> Language Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Loader Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Controller Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Model Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Model Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Model Class Initialized
DEBUG - 2011-06-10 19:54:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 19:54:05 --> Database Driver Class Initialized
DEBUG - 2011-06-10 19:54:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-06-10 19:54:05 --> Helper loaded: url_helper
DEBUG - 2011-06-10 19:54:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 19:54:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 19:54:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 19:54:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 19:54:05 --> Final output sent to browser
DEBUG - 2011-06-10 19:54:05 --> Total execution time: 0.5430
DEBUG - 2011-06-10 19:55:24 --> Config Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 19:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 19:55:24 --> Config Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 19:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 19:55:24 --> URI Class Initialized
DEBUG - 2011-06-10 19:55:24 --> URI Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Router Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Router Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Config Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Hooks Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Utf8 Class Initialized
DEBUG - 2011-06-10 19:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 19:55:24 --> URI Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Router Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Output Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Output Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Output Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Input Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 19:55:24 --> Input Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 19:55:24 --> Input Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Language Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 19:55:24 --> Language Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Language Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Loader Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Loader Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Loader Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Controller Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Controller Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Controller Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Model Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 19:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 19:55:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 19:55:24 --> Database Driver Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Database Driver Class Initialized
DEBUG - 2011-06-10 19:55:24 --> Database Driver Class Initialized
DEBUG - 2011-06-10 19:55:25 --> Final output sent to browser
DEBUG - 2011-06-10 19:55:25 --> Total execution time: 0.7376
DEBUG - 2011-06-10 19:55:25 --> Final output sent to browser
DEBUG - 2011-06-10 19:55:25 --> Total execution time: 0.8228
DEBUG - 2011-06-10 19:55:25 --> Final output sent to browser
DEBUG - 2011-06-10 19:55:25 --> Total execution time: 0.8321
DEBUG - 2011-06-10 20:18:46 --> Config Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Hooks Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Utf8 Class Initialized
DEBUG - 2011-06-10 20:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 20:18:46 --> URI Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Router Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Output Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Input Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 20:18:46 --> Language Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Loader Class Initialized
DEBUG - 2011-06-10 20:18:46 --> Controller Class Initialized
ERROR - 2011-06-10 20:18:47 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 20:18:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 20:18:47 --> Model Class Initialized
DEBUG - 2011-06-10 20:18:47 --> Model Class Initialized
DEBUG - 2011-06-10 20:18:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 20:18:47 --> Database Driver Class Initialized
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 20:18:47 --> Helper loaded: url_helper
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 20:18:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 20:18:47 --> Final output sent to browser
DEBUG - 2011-06-10 20:18:47 --> Total execution time: 0.1959
DEBUG - 2011-06-10 21:09:04 --> Config Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Hooks Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Utf8 Class Initialized
DEBUG - 2011-06-10 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 21:09:04 --> URI Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Router Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Output Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Input Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 21:09:04 --> Language Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Loader Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Controller Class Initialized
ERROR - 2011-06-10 21:09:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-06-10 21:09:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 21:09:04 --> Model Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Model Class Initialized
DEBUG - 2011-06-10 21:09:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-06-10 21:09:04 --> Database Driver Class Initialized
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-06-10 21:09:04 --> Helper loaded: url_helper
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 21:09:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 21:09:04 --> Final output sent to browser
DEBUG - 2011-06-10 21:09:04 --> Total execution time: 0.3580
DEBUG - 2011-06-10 21:49:33 --> Config Class Initialized
DEBUG - 2011-06-10 21:49:33 --> Hooks Class Initialized
DEBUG - 2011-06-10 21:49:33 --> Utf8 Class Initialized
DEBUG - 2011-06-10 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 21:49:33 --> URI Class Initialized
DEBUG - 2011-06-10 21:49:33 --> Router Class Initialized
ERROR - 2011-06-10 21:49:33 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-06-10 21:51:15 --> Config Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Hooks Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Utf8 Class Initialized
DEBUG - 2011-06-10 21:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 21:51:15 --> URI Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Router Class Initialized
DEBUG - 2011-06-10 21:51:15 --> No URI present. Default controller set.
DEBUG - 2011-06-10 21:51:15 --> Output Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Input Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 21:51:15 --> Language Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Loader Class Initialized
DEBUG - 2011-06-10 21:51:15 --> Controller Class Initialized
DEBUG - 2011-06-10 21:51:15 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 21:51:15 --> Helper loaded: url_helper
DEBUG - 2011-06-10 21:51:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 21:51:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 21:51:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 21:51:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 21:51:15 --> Final output sent to browser
DEBUG - 2011-06-10 21:51:15 --> Total execution time: 0.1629
DEBUG - 2011-06-10 22:38:23 --> Config Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Hooks Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Utf8 Class Initialized
DEBUG - 2011-06-10 22:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-06-10 22:38:23 --> URI Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Router Class Initialized
DEBUG - 2011-06-10 22:38:23 --> No URI present. Default controller set.
DEBUG - 2011-06-10 22:38:23 --> Output Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Input Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-06-10 22:38:23 --> Language Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Loader Class Initialized
DEBUG - 2011-06-10 22:38:23 --> Controller Class Initialized
DEBUG - 2011-06-10 22:38:23 --> File loaded: application/views/splash/main.php
DEBUG - 2011-06-10 22:38:23 --> Helper loaded: url_helper
DEBUG - 2011-06-10 22:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-06-10 22:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-06-10 22:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-06-10 22:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-06-10 22:38:23 --> Final output sent to browser
DEBUG - 2011-06-10 22:38:23 --> Total execution time: 0.4365

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-08-16 00:46:08 --> Config Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 00:46:08 --> URI Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Router Class Initialized
DEBUG - 2011-08-16 00:46:08 --> No URI present. Default controller set.
DEBUG - 2011-08-16 00:46:08 --> Output Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Input Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 00:46:08 --> Language Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Loader Class Initialized
DEBUG - 2011-08-16 00:46:08 --> Controller Class Initialized
DEBUG - 2011-08-16 00:46:08 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 00:46:08 --> Helper loaded: url_helper
DEBUG - 2011-08-16 00:46:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 00:46:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 00:46:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 00:46:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 00:46:08 --> Final output sent to browser
DEBUG - 2011-08-16 00:46:08 --> Total execution time: 0.0557
DEBUG - 2011-08-16 03:18:44 --> Config Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Hooks Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Utf8 Class Initialized
DEBUG - 2011-08-16 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 03:18:44 --> URI Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Router Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Output Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Input Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 03:18:44 --> Language Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Loader Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Controller Class Initialized
ERROR - 2011-08-16 03:18:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 03:18:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 03:18:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 03:18:44 --> Model Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Model Class Initialized
DEBUG - 2011-08-16 03:18:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 03:18:44 --> Database Driver Class Initialized
DEBUG - 2011-08-16 03:18:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 03:18:45 --> Helper loaded: url_helper
DEBUG - 2011-08-16 03:18:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 03:18:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 03:18:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 03:18:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 03:18:45 --> Final output sent to browser
DEBUG - 2011-08-16 03:18:45 --> Total execution time: 0.6064
DEBUG - 2011-08-16 04:11:06 --> Config Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Hooks Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Utf8 Class Initialized
DEBUG - 2011-08-16 04:11:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 04:11:06 --> URI Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Router Class Initialized
DEBUG - 2011-08-16 04:11:06 --> No URI present. Default controller set.
DEBUG - 2011-08-16 04:11:06 --> Output Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Input Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 04:11:06 --> Language Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Loader Class Initialized
DEBUG - 2011-08-16 04:11:06 --> Controller Class Initialized
DEBUG - 2011-08-16 04:11:06 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 04:11:06 --> Helper loaded: url_helper
DEBUG - 2011-08-16 04:11:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 04:11:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 04:11:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 04:11:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 04:11:06 --> Final output sent to browser
DEBUG - 2011-08-16 04:11:06 --> Total execution time: 0.1918
DEBUG - 2011-08-16 05:06:02 --> Config Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Hooks Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Utf8 Class Initialized
DEBUG - 2011-08-16 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 05:06:02 --> URI Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Router Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Output Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Input Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 05:06:02 --> Language Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Loader Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Controller Class Initialized
ERROR - 2011-08-16 05:06:02 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 05:06:02 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 05:06:02 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 05:06:02 --> Model Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Model Class Initialized
DEBUG - 2011-08-16 05:06:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 05:06:02 --> Database Driver Class Initialized
DEBUG - 2011-08-16 05:06:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 05:06:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 05:06:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 05:06:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 05:06:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 05:06:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 05:06:03 --> Final output sent to browser
DEBUG - 2011-08-16 05:06:03 --> Total execution time: 1.3497
DEBUG - 2011-08-16 05:06:07 --> Config Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Hooks Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Utf8 Class Initialized
DEBUG - 2011-08-16 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 05:06:07 --> URI Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Router Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Output Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Input Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 05:06:07 --> Language Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Loader Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Controller Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Model Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Model Class Initialized
DEBUG - 2011-08-16 05:06:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 05:06:07 --> Database Driver Class Initialized
DEBUG - 2011-08-16 05:06:08 --> Final output sent to browser
DEBUG - 2011-08-16 05:06:08 --> Total execution time: 0.8980
DEBUG - 2011-08-16 05:06:12 --> Config Class Initialized
DEBUG - 2011-08-16 05:06:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 05:06:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 05:06:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 05:06:12 --> URI Class Initialized
DEBUG - 2011-08-16 05:06:12 --> Router Class Initialized
ERROR - 2011-08-16 05:06:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:14:47 --> Config Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:14:47 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:14:47 --> URI Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Router Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Output Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Input Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:14:47 --> Language Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Loader Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Controller Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Model Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Model Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Model Class Initialized
DEBUG - 2011-08-16 06:14:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:14:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:14:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:14:49 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:14:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:14:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:14:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:14:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:14:49 --> Final output sent to browser
DEBUG - 2011-08-16 06:14:49 --> Total execution time: 1.6317
DEBUG - 2011-08-16 06:14:58 --> Config Class Initialized
DEBUG - 2011-08-16 06:14:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:14:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:14:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:14:58 --> URI Class Initialized
DEBUG - 2011-08-16 06:14:58 --> Router Class Initialized
ERROR - 2011-08-16 06:14:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:15:16 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:16 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Router Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Output Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Input Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:15:16 --> Language Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Loader Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Controller Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:15:16 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:15:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:15:17 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:15:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:15:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:15:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:15:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:15:17 --> Final output sent to browser
DEBUG - 2011-08-16 06:15:17 --> Total execution time: 1.2781
DEBUG - 2011-08-16 06:15:20 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:20 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Router Class Initialized
ERROR - 2011-08-16 06:15:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:15:20 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:20 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Router Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Output Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Input Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:15:20 --> Language Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Loader Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Controller Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:15:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:15:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:15:20 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:15:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:15:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:15:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:15:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:15:20 --> Final output sent to browser
DEBUG - 2011-08-16 06:15:20 --> Total execution time: 0.1016
DEBUG - 2011-08-16 06:15:23 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:23 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:23 --> Router Class Initialized
ERROR - 2011-08-16 06:15:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:15:31 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:31 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Router Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Output Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Input Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:15:31 --> Language Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Loader Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Controller Class Initialized
DEBUG - 2011-08-16 06:15:31 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:15:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:15:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:15:32 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:15:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:15:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:15:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:15:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:15:32 --> Final output sent to browser
DEBUG - 2011-08-16 06:15:32 --> Total execution time: 0.5267
DEBUG - 2011-08-16 06:15:34 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:34 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Router Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Output Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Input Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:15:34 --> Language Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Loader Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Controller Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 06:15:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:15:34 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:15:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:15:34 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:15:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:15:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:15:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:15:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:15:34 --> Final output sent to browser
DEBUG - 2011-08-16 06:15:34 --> Total execution time: 0.0484
DEBUG - 2011-08-16 06:15:36 --> Config Class Initialized
DEBUG - 2011-08-16 06:15:36 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:15:36 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:15:36 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:15:36 --> URI Class Initialized
DEBUG - 2011-08-16 06:15:36 --> Router Class Initialized
ERROR - 2011-08-16 06:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:16:03 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:03 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:03 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:03 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:04 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:04 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:04 --> Total execution time: 0.5377
DEBUG - 2011-08-16 06:16:05 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:05 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:05 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:05 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:05 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:05 --> Total execution time: 0.0805
DEBUG - 2011-08-16 06:16:11 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:11 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:11 --> Router Class Initialized
ERROR - 2011-08-16 06:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:16:32 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:32 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:32 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:33 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:33 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:33 --> Total execution time: 1.4060
DEBUG - 2011-08-16 06:16:35 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:35 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:35 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:35 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:35 --> Router Class Initialized
ERROR - 2011-08-16 06:16:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:16:39 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:39 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:40 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:40 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:40 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:40 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:40 --> Total execution time: 0.1178
DEBUG - 2011-08-16 06:16:44 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:44 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:44 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:44 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:44 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:44 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:44 --> Total execution time: 0.2709
DEBUG - 2011-08-16 06:16:46 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:46 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:46 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:46 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:46 --> Router Class Initialized
ERROR - 2011-08-16 06:16:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:16:50 --> Config Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:16:50 --> URI Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Router Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Output Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Input Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:16:50 --> Language Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Loader Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Controller Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Model Class Initialized
DEBUG - 2011-08-16 06:16:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:16:50 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:16:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:16:50 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:16:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:16:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:16:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:16:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:16:50 --> Final output sent to browser
DEBUG - 2011-08-16 06:16:50 --> Total execution time: 0.0459
DEBUG - 2011-08-16 06:17:40 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:40 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Router Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Output Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Input Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:17:40 --> Language Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Loader Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Controller Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:17:40 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:17:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:17:40 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:17:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:17:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:17:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:17:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:17:40 --> Final output sent to browser
DEBUG - 2011-08-16 06:17:40 --> Total execution time: 0.4932
DEBUG - 2011-08-16 06:17:42 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:42 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Router Class Initialized
ERROR - 2011-08-16 06:17:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:17:42 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:42 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Router Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Output Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Input Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:17:42 --> Language Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Loader Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Controller Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:17:42 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:17:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:17:42 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:17:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:17:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:17:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:17:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:17:42 --> Final output sent to browser
DEBUG - 2011-08-16 06:17:42 --> Total execution time: 0.0480
DEBUG - 2011-08-16 06:17:51 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:51 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Router Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Output Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Input Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:17:51 --> Language Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Loader Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Controller Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:17:51 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:17:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:17:52 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:17:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:17:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:17:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:17:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:17:52 --> Final output sent to browser
DEBUG - 2011-08-16 06:17:52 --> Total execution time: 0.2397
DEBUG - 2011-08-16 06:17:53 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:53 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:53 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:53 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:53 --> Router Class Initialized
ERROR - 2011-08-16 06:17:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:17:54 --> Config Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:17:54 --> URI Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Router Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Output Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Input Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:17:54 --> Language Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Loader Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Controller Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Model Class Initialized
DEBUG - 2011-08-16 06:17:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:17:54 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:17:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:17:54 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:17:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:17:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:17:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:17:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:17:54 --> Final output sent to browser
DEBUG - 2011-08-16 06:17:54 --> Total execution time: 0.0440
DEBUG - 2011-08-16 06:18:03 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:03 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:03 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:03 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:03 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:03 --> Total execution time: 0.2116
DEBUG - 2011-08-16 06:18:04 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:04 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:04 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:04 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:04 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:04 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:04 --> Total execution time: 0.0422
DEBUG - 2011-08-16 06:18:04 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:04 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:04 --> Router Class Initialized
ERROR - 2011-08-16 06:18:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:18:12 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:12 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:12 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:12 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:12 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:12 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:12 --> Total execution time: 0.6624
DEBUG - 2011-08-16 06:18:14 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:14 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Router Class Initialized
ERROR - 2011-08-16 06:18:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:18:14 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:14 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:14 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:14 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:14 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:14 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:14 --> Total execution time: 0.0457
DEBUG - 2011-08-16 06:18:28 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:28 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:28 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:28 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:28 --> Total execution time: 0.2942
DEBUG - 2011-08-16 06:18:30 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:30 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:30 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:30 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:30 --> Router Class Initialized
ERROR - 2011-08-16 06:18:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:18:32 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:32 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:32 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:32 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:32 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:32 --> Total execution time: 0.1114
DEBUG - 2011-08-16 06:18:39 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:39 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:39 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:39 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:40 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:40 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:40 --> Total execution time: 0.6359
DEBUG - 2011-08-16 06:18:41 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:41 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:41 --> Router Class Initialized
ERROR - 2011-08-16 06:18:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:18:58 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:58 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Router Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Output Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Input Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:18:58 --> Language Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Loader Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Controller Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Model Class Initialized
DEBUG - 2011-08-16 06:18:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:18:58 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:18:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:18:58 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:18:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:18:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:18:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:18:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:18:58 --> Final output sent to browser
DEBUG - 2011-08-16 06:18:58 --> Total execution time: 0.3107
DEBUG - 2011-08-16 06:18:59 --> Config Class Initialized
DEBUG - 2011-08-16 06:18:59 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:18:59 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:18:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:18:59 --> URI Class Initialized
DEBUG - 2011-08-16 06:18:59 --> Router Class Initialized
ERROR - 2011-08-16 06:18:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:02 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:02 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:02 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:02 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:02 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:02 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:02 --> Total execution time: 0.1242
DEBUG - 2011-08-16 06:19:05 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:05 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:05 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:05 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:05 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:05 --> Total execution time: 0.0552
DEBUG - 2011-08-16 06:19:10 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:10 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:10 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:10 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:10 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:10 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:10 --> Total execution time: 0.2819
DEBUG - 2011-08-16 06:19:12 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:12 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:12 --> Router Class Initialized
ERROR - 2011-08-16 06:19:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:13 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:13 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:13 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:13 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:13 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:13 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:13 --> Total execution time: 0.0706
DEBUG - 2011-08-16 06:19:21 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:21 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:21 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:21 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:22 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:22 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:22 --> Total execution time: 0.3630
DEBUG - 2011-08-16 06:19:23 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:23 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:23 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:23 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:23 --> Total execution time: 0.0674
DEBUG - 2011-08-16 06:19:23 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:23 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:23 --> Router Class Initialized
ERROR - 2011-08-16 06:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:29 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:29 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:29 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:29 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:29 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:29 --> Total execution time: 0.4835
DEBUG - 2011-08-16 06:19:31 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:31 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Router Class Initialized
ERROR - 2011-08-16 06:19:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:31 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:31 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:31 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:31 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:31 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:31 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:31 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:31 --> Total execution time: 0.0753
DEBUG - 2011-08-16 06:19:41 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:41 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:41 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:41 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:41 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:41 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:41 --> Total execution time: 0.2092
DEBUG - 2011-08-16 06:19:42 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:42 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:42 --> Router Class Initialized
ERROR - 2011-08-16 06:19:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:48 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:48 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:48 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:49 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:49 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:49 --> Total execution time: 0.3577
DEBUG - 2011-08-16 06:19:51 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:51 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:51 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:51 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:51 --> Router Class Initialized
ERROR - 2011-08-16 06:19:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:19:56 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:56 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Router Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Output Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Input Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:19:56 --> Language Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Loader Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Controller Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Model Class Initialized
DEBUG - 2011-08-16 06:19:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:19:56 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:19:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:19:56 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:19:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:19:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:19:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:19:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:19:56 --> Final output sent to browser
DEBUG - 2011-08-16 06:19:56 --> Total execution time: 0.0466
DEBUG - 2011-08-16 06:19:58 --> Config Class Initialized
DEBUG - 2011-08-16 06:19:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:19:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:19:58 --> URI Class Initialized
DEBUG - 2011-08-16 06:19:58 --> Router Class Initialized
ERROR - 2011-08-16 06:19:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:20:05 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:05 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:05 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:20:06 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:06 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:06 --> Total execution time: 0.9403
DEBUG - 2011-08-16 06:20:07 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:07 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:07 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:07 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:07 --> Router Class Initialized
ERROR - 2011-08-16 06:20:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:20:14 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:14 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:14 --> Router Class Initialized
ERROR - 2011-08-16 06:20:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:20:16 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:16 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:16 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:16 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:16 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:16 --> Router Class Initialized
ERROR - 2011-08-16 06:20:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:20:20 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:20 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:20 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:20:21 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:21 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:21 --> Total execution time: 0.0732
DEBUG - 2011-08-16 06:20:21 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:21 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:21 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Controller Class Initialized
ERROR - 2011-08-16 06:20:21 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 06:20:21 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 06:20:21 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:21 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 06:20:21 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:21 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:21 --> Total execution time: 0.0938
DEBUG - 2011-08-16 06:20:22 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:22 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:22 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:22 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:22 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:22 --> Total execution time: 0.6526
DEBUG - 2011-08-16 06:20:23 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:23 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:23 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:20:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:23 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:23 --> Total execution time: 0.0421
DEBUG - 2011-08-16 06:20:24 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:24 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Router Class Initialized
ERROR - 2011-08-16 06:20:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 06:20:24 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:24 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:24 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:24 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:20:24 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:24 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:24 --> Total execution time: 0.0467
DEBUG - 2011-08-16 06:20:26 --> Config Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Hooks Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Utf8 Class Initialized
DEBUG - 2011-08-16 06:20:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 06:20:26 --> URI Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Router Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Output Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Input Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 06:20:26 --> Language Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Loader Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Controller Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Model Class Initialized
DEBUG - 2011-08-16 06:20:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 06:20:26 --> Database Driver Class Initialized
DEBUG - 2011-08-16 06:20:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 06:20:26 --> Helper loaded: url_helper
DEBUG - 2011-08-16 06:20:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 06:20:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 06:20:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 06:20:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 06:20:26 --> Final output sent to browser
DEBUG - 2011-08-16 06:20:26 --> Total execution time: 0.0798
DEBUG - 2011-08-16 07:26:15 --> Config Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 07:26:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 07:26:15 --> URI Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Router Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Output Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Input Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 07:26:15 --> Language Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Loader Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Controller Class Initialized
ERROR - 2011-08-16 07:26:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 07:26:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 07:26:15 --> Model Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Model Class Initialized
DEBUG - 2011-08-16 07:26:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 07:26:15 --> Database Driver Class Initialized
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 07:26:15 --> Helper loaded: url_helper
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 07:26:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 07:26:15 --> Final output sent to browser
DEBUG - 2011-08-16 07:26:15 --> Total execution time: 0.3560
DEBUG - 2011-08-16 07:26:18 --> Config Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 07:26:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 07:26:18 --> URI Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Router Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Output Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Input Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 07:26:18 --> Language Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Loader Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Controller Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Model Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Model Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 07:26:18 --> Database Driver Class Initialized
DEBUG - 2011-08-16 07:26:18 --> Final output sent to browser
DEBUG - 2011-08-16 07:26:18 --> Total execution time: 0.8148
DEBUG - 2011-08-16 08:01:28 --> Config Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:01:28 --> URI Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Router Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Output Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Input Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:01:28 --> Language Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Loader Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Controller Class Initialized
ERROR - 2011-08-16 08:01:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:01:28 --> Model Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Model Class Initialized
DEBUG - 2011-08-16 08:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:01:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:01:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:01:28 --> Final output sent to browser
DEBUG - 2011-08-16 08:01:28 --> Total execution time: 0.3851
DEBUG - 2011-08-16 08:01:30 --> Config Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:01:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:01:30 --> URI Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Router Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Output Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Input Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:01:30 --> Language Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Loader Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Controller Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Model Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Model Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:01:30 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:01:30 --> Final output sent to browser
DEBUG - 2011-08-16 08:01:30 --> Total execution time: 0.6691
DEBUG - 2011-08-16 08:01:33 --> Config Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:01:33 --> URI Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Router Class Initialized
ERROR - 2011-08-16 08:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 08:01:33 --> Config Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:01:33 --> URI Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Router Class Initialized
ERROR - 2011-08-16 08:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 08:01:33 --> Config Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:01:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:01:33 --> URI Class Initialized
DEBUG - 2011-08-16 08:01:33 --> Router Class Initialized
ERROR - 2011-08-16 08:01:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 08:02:03 --> Config Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:02:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:02:03 --> URI Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Router Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Output Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Input Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:02:03 --> Language Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Loader Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Controller Class Initialized
ERROR - 2011-08-16 08:02:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:02:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:02:03 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:02:03 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:02:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:02:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:02:03 --> Final output sent to browser
DEBUG - 2011-08-16 08:02:03 --> Total execution time: 0.1210
DEBUG - 2011-08-16 08:02:04 --> Config Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:02:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:02:04 --> URI Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Router Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Output Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Input Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:02:04 --> Language Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Loader Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Controller Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:02:04 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:02:10 --> Final output sent to browser
DEBUG - 2011-08-16 08:02:10 --> Total execution time: 5.6567
DEBUG - 2011-08-16 08:02:37 --> Config Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:02:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:02:37 --> URI Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Router Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Output Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Input Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:02:37 --> Language Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Loader Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Controller Class Initialized
ERROR - 2011-08-16 08:02:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:02:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:02:37 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:02:37 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:02:37 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:02:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:02:37 --> Final output sent to browser
DEBUG - 2011-08-16 08:02:37 --> Total execution time: 0.0372
DEBUG - 2011-08-16 08:02:38 --> Config Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:02:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:02:38 --> URI Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Router Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Output Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Input Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:02:38 --> Language Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Loader Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Controller Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Model Class Initialized
DEBUG - 2011-08-16 08:02:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:02:38 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:02:39 --> Final output sent to browser
DEBUG - 2011-08-16 08:02:39 --> Total execution time: 0.6052
DEBUG - 2011-08-16 08:03:00 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:00 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:00 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Controller Class Initialized
ERROR - 2011-08-16 08:03:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:00 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:00 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:03:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:03:00 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:00 --> Total execution time: 0.0898
DEBUG - 2011-08-16 08:03:01 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:01 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:01 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Controller Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:01 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:02 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:02 --> Total execution time: 0.6291
DEBUG - 2011-08-16 08:03:23 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:23 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:23 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Controller Class Initialized
ERROR - 2011-08-16 08:03:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:03:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:23 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:03:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:03:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:03:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:03:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:03:24 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:24 --> Total execution time: 0.0397
DEBUG - 2011-08-16 08:03:25 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:25 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:25 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Controller Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:25 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:25 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:25 --> Total execution time: 0.6018
DEBUG - 2011-08-16 08:03:39 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:39 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:39 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:39 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Controller Class Initialized
ERROR - 2011-08-16 08:03:39 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:03:39 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:39 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:39 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:39 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:03:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:03:39 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:39 --> Total execution time: 0.0314
DEBUG - 2011-08-16 08:03:41 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:41 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:41 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:41 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:42 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Controller Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:42 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:42 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:42 --> Total execution time: 0.7280
DEBUG - 2011-08-16 08:03:48 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:48 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:48 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Controller Class Initialized
ERROR - 2011-08-16 08:03:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:03:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:48 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:48 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:03:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:03:48 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:48 --> Total execution time: 0.0436
DEBUG - 2011-08-16 08:03:49 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:49 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:49 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Controller Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:49 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:50 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:50 --> Total execution time: 1.4299
DEBUG - 2011-08-16 08:03:55 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:55 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:55 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Controller Class Initialized
ERROR - 2011-08-16 08:03:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:03:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:55 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:03:55 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:03:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:03:55 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:55 --> Total execution time: 0.1417
DEBUG - 2011-08-16 08:03:56 --> Config Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:03:56 --> URI Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Router Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Output Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Input Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:03:56 --> Language Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Loader Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Controller Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Model Class Initialized
DEBUG - 2011-08-16 08:03:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:03:56 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:03:57 --> Final output sent to browser
DEBUG - 2011-08-16 08:03:57 --> Total execution time: 0.7345
DEBUG - 2011-08-16 08:04:11 --> Config Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:04:11 --> URI Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Router Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Output Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Input Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:04:11 --> Language Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Loader Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Controller Class Initialized
ERROR - 2011-08-16 08:04:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:04:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:04:11 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:04:11 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:04:11 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:04:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:04:11 --> Final output sent to browser
DEBUG - 2011-08-16 08:04:11 --> Total execution time: 0.0303
DEBUG - 2011-08-16 08:04:12 --> Config Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:04:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:04:12 --> URI Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Router Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Output Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Input Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:04:12 --> Language Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Loader Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Controller Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:04:12 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:04:12 --> Final output sent to browser
DEBUG - 2011-08-16 08:04:12 --> Total execution time: 0.5764
DEBUG - 2011-08-16 08:04:19 --> Config Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:04:19 --> URI Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Router Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Output Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Input Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:04:19 --> Language Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Loader Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Controller Class Initialized
ERROR - 2011-08-16 08:04:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:04:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:04:19 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:04:19 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:04:19 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:04:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:04:19 --> Final output sent to browser
DEBUG - 2011-08-16 08:04:19 --> Total execution time: 0.0574
DEBUG - 2011-08-16 08:04:20 --> Config Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:04:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:04:20 --> URI Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Router Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Output Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Input Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:04:20 --> Language Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Loader Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Controller Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Model Class Initialized
DEBUG - 2011-08-16 08:04:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:04:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:04:21 --> Final output sent to browser
DEBUG - 2011-08-16 08:04:21 --> Total execution time: 0.4989
DEBUG - 2011-08-16 08:07:37 --> Config Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:07:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:07:37 --> URI Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Router Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Output Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Input Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:07:37 --> Language Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Loader Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Controller Class Initialized
ERROR - 2011-08-16 08:07:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:07:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:07:37 --> Model Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Model Class Initialized
DEBUG - 2011-08-16 08:07:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:07:37 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:07:37 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:07:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:07:37 --> Final output sent to browser
DEBUG - 2011-08-16 08:07:37 --> Total execution time: 0.0283
DEBUG - 2011-08-16 08:07:38 --> Config Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:07:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:07:38 --> URI Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Router Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Output Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Input Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:07:38 --> Language Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Loader Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Controller Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Model Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Model Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:07:38 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:07:38 --> Final output sent to browser
DEBUG - 2011-08-16 08:07:38 --> Total execution time: 0.4950
DEBUG - 2011-08-16 08:07:41 --> Config Class Initialized
DEBUG - 2011-08-16 08:07:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:07:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:07:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:07:41 --> URI Class Initialized
DEBUG - 2011-08-16 08:07:41 --> Router Class Initialized
ERROR - 2011-08-16 08:07:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 08:07:42 --> Config Class Initialized
DEBUG - 2011-08-16 08:07:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:07:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:07:42 --> URI Class Initialized
DEBUG - 2011-08-16 08:07:42 --> Router Class Initialized
ERROR - 2011-08-16 08:07:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 08:08:08 --> Config Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:08:08 --> URI Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Router Class Initialized
ERROR - 2011-08-16 08:08:08 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 08:08:08 --> Config Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:08:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:08:08 --> URI Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Router Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Output Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Input Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:08:08 --> Language Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Loader Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Controller Class Initialized
ERROR - 2011-08-16 08:08:08 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 08:08:08 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:08:08 --> Model Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Model Class Initialized
DEBUG - 2011-08-16 08:08:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:08:08 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 08:08:08 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:08:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:08:08 --> Final output sent to browser
DEBUG - 2011-08-16 08:08:08 --> Total execution time: 0.0446
DEBUG - 2011-08-16 08:08:10 --> Config Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:08:10 --> URI Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Router Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Output Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Input Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:08:10 --> Language Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Loader Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Controller Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Model Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Model Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:08:10 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:08:10 --> Final output sent to browser
DEBUG - 2011-08-16 08:08:10 --> Total execution time: 0.3261
DEBUG - 2011-08-16 08:20:27 --> Config Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 08:20:27 --> URI Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Router Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Output Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Input Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 08:20:27 --> Language Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Loader Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Controller Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Model Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Model Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Model Class Initialized
DEBUG - 2011-08-16 08:20:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 08:20:27 --> Database Driver Class Initialized
DEBUG - 2011-08-16 08:20:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 08:20:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 08:20:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 08:20:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 08:20:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 08:20:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 08:20:28 --> Final output sent to browser
DEBUG - 2011-08-16 08:20:28 --> Total execution time: 0.5763
DEBUG - 2011-08-16 09:05:21 --> Config Class Initialized
DEBUG - 2011-08-16 09:05:21 --> Hooks Class Initialized
DEBUG - 2011-08-16 09:05:21 --> Utf8 Class Initialized
DEBUG - 2011-08-16 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 09:05:21 --> URI Class Initialized
DEBUG - 2011-08-16 09:05:21 --> Router Class Initialized
ERROR - 2011-08-16 09:05:21 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 10:01:26 --> Config Class Initialized
DEBUG - 2011-08-16 10:01:26 --> Hooks Class Initialized
DEBUG - 2011-08-16 10:01:26 --> Utf8 Class Initialized
DEBUG - 2011-08-16 10:01:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 10:01:26 --> URI Class Initialized
DEBUG - 2011-08-16 10:01:26 --> Router Class Initialized
ERROR - 2011-08-16 10:01:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 10:01:27 --> Config Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 10:01:27 --> URI Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Router Class Initialized
DEBUG - 2011-08-16 10:01:27 --> No URI present. Default controller set.
DEBUG - 2011-08-16 10:01:27 --> Output Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Input Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 10:01:27 --> Language Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Loader Class Initialized
DEBUG - 2011-08-16 10:01:27 --> Controller Class Initialized
DEBUG - 2011-08-16 10:01:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 10:01:27 --> Helper loaded: url_helper
DEBUG - 2011-08-16 10:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 10:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 10:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 10:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 10:01:27 --> Final output sent to browser
DEBUG - 2011-08-16 10:01:27 --> Total execution time: 0.0890
DEBUG - 2011-08-16 10:01:28 --> Config Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 10:01:28 --> URI Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Router Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Output Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Input Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 10:01:28 --> Language Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Loader Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Controller Class Initialized
ERROR - 2011-08-16 10:01:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 10:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 10:01:28 --> Model Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Model Class Initialized
DEBUG - 2011-08-16 10:01:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 10:01:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 10:01:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 10:01:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 10:01:28 --> Final output sent to browser
DEBUG - 2011-08-16 10:01:28 --> Total execution time: 0.0692
DEBUG - 2011-08-16 10:01:29 --> Config Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 10:01:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 10:01:29 --> URI Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Router Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Output Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Input Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 10:01:29 --> Language Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Loader Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Controller Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Model Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Model Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Model Class Initialized
DEBUG - 2011-08-16 10:01:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 10:01:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 10:01:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 10:01:29 --> Helper loaded: url_helper
DEBUG - 2011-08-16 10:01:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 10:01:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 10:01:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 10:01:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 10:01:29 --> Final output sent to browser
DEBUG - 2011-08-16 10:01:29 --> Total execution time: 0.2652
DEBUG - 2011-08-16 11:13:48 --> Config Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 11:13:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 11:13:48 --> URI Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Router Class Initialized
DEBUG - 2011-08-16 11:13:48 --> No URI present. Default controller set.
DEBUG - 2011-08-16 11:13:48 --> Output Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Input Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 11:13:48 --> Language Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Loader Class Initialized
DEBUG - 2011-08-16 11:13:48 --> Controller Class Initialized
DEBUG - 2011-08-16 11:13:48 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 11:13:48 --> Helper loaded: url_helper
DEBUG - 2011-08-16 11:13:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 11:13:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 11:13:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 11:13:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 11:13:48 --> Final output sent to browser
DEBUG - 2011-08-16 11:13:48 --> Total execution time: 0.0271
DEBUG - 2011-08-16 11:56:44 --> Config Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Hooks Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Utf8 Class Initialized
DEBUG - 2011-08-16 11:56:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 11:56:44 --> URI Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Router Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Output Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Input Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 11:56:44 --> Language Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Loader Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Controller Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 11:56:45 --> Database Driver Class Initialized
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 11:56:45 --> Helper loaded: url_helper
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 11:56:45 --> Final output sent to browser
DEBUG - 2011-08-16 11:56:45 --> Total execution time: 0.3468
DEBUG - 2011-08-16 11:56:45 --> Config Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Hooks Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Utf8 Class Initialized
DEBUG - 2011-08-16 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 11:56:45 --> URI Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Router Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Output Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Input Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 11:56:45 --> Language Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Loader Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Controller Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Model Class Initialized
DEBUG - 2011-08-16 11:56:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 11:56:45 --> Database Driver Class Initialized
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 11:56:45 --> Helper loaded: url_helper
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 11:56:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 11:56:45 --> Final output sent to browser
DEBUG - 2011-08-16 11:56:45 --> Total execution time: 0.0455
DEBUG - 2011-08-16 12:12:26 --> Config Class Initialized
DEBUG - 2011-08-16 12:12:26 --> Hooks Class Initialized
DEBUG - 2011-08-16 12:12:26 --> Utf8 Class Initialized
DEBUG - 2011-08-16 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 12:12:26 --> URI Class Initialized
DEBUG - 2011-08-16 12:12:26 --> Router Class Initialized
ERROR - 2011-08-16 12:12:26 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 12:12:27 --> Config Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 12:12:27 --> URI Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Router Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Output Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Input Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 12:12:27 --> Language Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Loader Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Controller Class Initialized
ERROR - 2011-08-16 12:12:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 12:12:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 12:12:27 --> Model Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Model Class Initialized
DEBUG - 2011-08-16 12:12:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 12:12:27 --> Database Driver Class Initialized
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 12:12:27 --> Helper loaded: url_helper
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 12:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 12:12:27 --> Final output sent to browser
DEBUG - 2011-08-16 12:12:27 --> Total execution time: 0.7210
DEBUG - 2011-08-16 13:01:05 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:05 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:05 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Controller Class Initialized
ERROR - 2011-08-16 13:01:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:01:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:05 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:05 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:01:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:01:05 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:05 --> Total execution time: 0.1309
DEBUG - 2011-08-16 13:01:11 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:11 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:11 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Controller Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:11 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:12 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:12 --> Total execution time: 0.6465
DEBUG - 2011-08-16 13:01:17 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:17 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:17 --> Router Class Initialized
ERROR - 2011-08-16 13:01:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:01:19 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:19 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:19 --> Router Class Initialized
ERROR - 2011-08-16 13:01:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:01:49 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:49 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:49 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Controller Class Initialized
ERROR - 2011-08-16 13:01:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:01:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:49 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:49 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:01:49 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:49 --> Total execution time: 0.0271
DEBUG - 2011-08-16 13:01:51 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:51 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:51 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Controller Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:51 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:52 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:52 --> Total execution time: 0.6331
DEBUG - 2011-08-16 13:01:53 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:53 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Router Class Initialized
ERROR - 2011-08-16 13:01:53 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 13:01:53 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:53 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:53 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Controller Class Initialized
ERROR - 2011-08-16 13:01:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:01:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:53 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:53 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:53 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:01:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:01:53 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:53 --> Total execution time: 0.0294
DEBUG - 2011-08-16 13:01:56 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:56 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:56 --> Router Class Initialized
ERROR - 2011-08-16 13:01:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:01:59 --> Config Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:01:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:01:59 --> URI Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Router Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Output Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Input Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:01:59 --> Language Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Loader Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Controller Class Initialized
ERROR - 2011-08-16 13:01:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:59 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Model Class Initialized
DEBUG - 2011-08-16 13:01:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:01:59 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:01:59 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:01:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:01:59 --> Final output sent to browser
DEBUG - 2011-08-16 13:01:59 --> Total execution time: 0.0283
DEBUG - 2011-08-16 13:02:00 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:00 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Router Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Output Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Input Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:02:00 --> Language Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Loader Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Controller Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:02:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:02:01 --> Final output sent to browser
DEBUG - 2011-08-16 13:02:01 --> Total execution time: 0.7144
DEBUG - 2011-08-16 13:02:05 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:05 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:05 --> Router Class Initialized
ERROR - 2011-08-16 13:02:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:02:15 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:15 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Router Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Output Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Input Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:02:15 --> Language Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Loader Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Controller Class Initialized
ERROR - 2011-08-16 13:02:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:02:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:02:15 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:02:15 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:02:15 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:02:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:02:15 --> Final output sent to browser
DEBUG - 2011-08-16 13:02:15 --> Total execution time: 0.1007
DEBUG - 2011-08-16 13:02:17 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:17 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Router Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Output Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Input Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:02:17 --> Language Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Loader Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Controller Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:02:17 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:17 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Router Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Output Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Input Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:02:17 --> Language Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Loader Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Controller Class Initialized
ERROR - 2011-08-16 13:02:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:02:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:02:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:02:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:02:17 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:02:17 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:02:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:02:17 --> Final output sent to browser
DEBUG - 2011-08-16 13:02:17 --> Total execution time: 0.0286
DEBUG - 2011-08-16 13:02:17 --> Final output sent to browser
DEBUG - 2011-08-16 13:02:17 --> Total execution time: 0.5155
DEBUG - 2011-08-16 13:02:28 --> Config Class Initialized
DEBUG - 2011-08-16 13:02:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:02:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:02:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:02:28 --> URI Class Initialized
DEBUG - 2011-08-16 13:02:28 --> Router Class Initialized
ERROR - 2011-08-16 13:02:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:15:55 --> Config Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:15:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:15:55 --> URI Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Router Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Output Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Input Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:15:55 --> Language Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Loader Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Controller Class Initialized
ERROR - 2011-08-16 13:15:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:15:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:15:55 --> Model Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Model Class Initialized
DEBUG - 2011-08-16 13:15:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:15:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:15:55 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:15:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:15:55 --> Final output sent to browser
DEBUG - 2011-08-16 13:15:55 --> Total execution time: 0.0303
DEBUG - 2011-08-16 13:15:56 --> Config Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:15:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:15:56 --> URI Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Router Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Output Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Input Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:15:56 --> Language Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Loader Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Controller Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Model Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Model Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:15:56 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:15:56 --> Final output sent to browser
DEBUG - 2011-08-16 13:15:56 --> Total execution time: 0.5827
DEBUG - 2011-08-16 13:15:57 --> Config Class Initialized
DEBUG - 2011-08-16 13:15:57 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:15:57 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:15:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:15:57 --> URI Class Initialized
DEBUG - 2011-08-16 13:15:57 --> Router Class Initialized
ERROR - 2011-08-16 13:15:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:15:58 --> Config Class Initialized
DEBUG - 2011-08-16 13:15:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:15:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:15:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:15:58 --> URI Class Initialized
DEBUG - 2011-08-16 13:15:58 --> Router Class Initialized
ERROR - 2011-08-16 13:15:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:16:23 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:23 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:23 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Controller Class Initialized
ERROR - 2011-08-16 13:16:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:16:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:23 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:16:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:16:23 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:23 --> Total execution time: 0.1198
DEBUG - 2011-08-16 13:16:24 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:24 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:24 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Controller Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:24 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:24 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:24 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Controller Class Initialized
ERROR - 2011-08-16 13:16:24 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:16:24 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:16:24 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:24 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:25 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:25 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:16:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:16:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:16:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:16:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:16:25 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:25 --> Total execution time: 0.0891
DEBUG - 2011-08-16 13:16:25 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:25 --> Total execution time: 0.8390
DEBUG - 2011-08-16 13:16:25 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:25 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:25 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:25 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:25 --> Router Class Initialized
ERROR - 2011-08-16 13:16:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:16:43 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:43 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:43 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Controller Class Initialized
ERROR - 2011-08-16 13:16:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:16:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:43 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:43 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:43 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:16:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:16:43 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:43 --> Total execution time: 0.0596
DEBUG - 2011-08-16 13:16:44 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:44 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:44 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Controller Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:44 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:44 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:44 --> Total execution time: 0.5209
DEBUG - 2011-08-16 13:16:45 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:45 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:45 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:45 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:45 --> Router Class Initialized
ERROR - 2011-08-16 13:16:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:16:48 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:48 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:48 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Controller Class Initialized
ERROR - 2011-08-16 13:16:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:16:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:48 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:16:48 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:16:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:16:48 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:48 --> Total execution time: 0.0394
DEBUG - 2011-08-16 13:16:49 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:49 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Router Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Output Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Input Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:16:49 --> Language Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Loader Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Controller Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Model Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:16:49 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:16:49 --> Final output sent to browser
DEBUG - 2011-08-16 13:16:49 --> Total execution time: 0.6845
DEBUG - 2011-08-16 13:16:50 --> Config Class Initialized
DEBUG - 2011-08-16 13:16:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:16:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:16:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:16:50 --> URI Class Initialized
DEBUG - 2011-08-16 13:16:50 --> Router Class Initialized
ERROR - 2011-08-16 13:16:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:17:18 --> Config Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:17:18 --> URI Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Router Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Output Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Input Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:17:18 --> Language Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Loader Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Controller Class Initialized
ERROR - 2011-08-16 13:17:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:17:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:17:18 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:17:18 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:17:18 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:17:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:17:18 --> Final output sent to browser
DEBUG - 2011-08-16 13:17:18 --> Total execution time: 0.0269
DEBUG - 2011-08-16 13:17:18 --> Config Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:17:18 --> URI Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Router Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Output Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Input Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:17:18 --> Language Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Loader Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Controller Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:17:18 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:17:19 --> Final output sent to browser
DEBUG - 2011-08-16 13:17:19 --> Total execution time: 0.4886
DEBUG - 2011-08-16 13:17:19 --> Config Class Initialized
DEBUG - 2011-08-16 13:17:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:17:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:17:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:17:19 --> URI Class Initialized
DEBUG - 2011-08-16 13:17:19 --> Router Class Initialized
ERROR - 2011-08-16 13:17:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:17:31 --> Config Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:17:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:17:31 --> URI Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Router Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Output Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Input Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:17:31 --> Language Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Loader Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Controller Class Initialized
ERROR - 2011-08-16 13:17:31 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:17:31 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:17:31 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Model Class Initialized
DEBUG - 2011-08-16 13:17:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:17:31 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:17:31 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:17:31 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:17:31 --> Final output sent to browser
DEBUG - 2011-08-16 13:17:31 --> Total execution time: 0.0296
DEBUG - 2011-08-16 13:30:17 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:17 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Router Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Output Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Input Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:30:17 --> Language Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Loader Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Controller Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:30:17 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:30:17 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:30:17 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:30:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:30:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:30:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:30:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:30:17 --> Final output sent to browser
DEBUG - 2011-08-16 13:30:17 --> Total execution time: 0.2146
DEBUG - 2011-08-16 13:30:41 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:41 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Router Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Output Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Input Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:30:41 --> Language Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Loader Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Controller Class Initialized
ERROR - 2011-08-16 13:30:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 13:30:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:30:41 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:30:41 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 13:30:41 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:30:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:30:41 --> Final output sent to browser
DEBUG - 2011-08-16 13:30:41 --> Total execution time: 0.0308
DEBUG - 2011-08-16 13:30:42 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:42 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Router Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Output Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Input Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:30:42 --> Language Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Loader Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Controller Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:30:42 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:30:42 --> Final output sent to browser
DEBUG - 2011-08-16 13:30:42 --> Total execution time: 0.4989
DEBUG - 2011-08-16 13:30:45 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:45 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:45 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:45 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:45 --> Router Class Initialized
ERROR - 2011-08-16 13:30:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:30:50 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:50 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Router Class Initialized
ERROR - 2011-08-16 13:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:30:50 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:50 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:50 --> Router Class Initialized
ERROR - 2011-08-16 13:30:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:30:51 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:51 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:51 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:51 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:51 --> Router Class Initialized
ERROR - 2011-08-16 13:30:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 13:30:57 --> Config Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:30:57 --> URI Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Router Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Output Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Input Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:30:57 --> Language Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Loader Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Controller Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Model Class Initialized
DEBUG - 2011-08-16 13:30:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:30:57 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:30:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:30:57 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:30:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:30:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:30:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:30:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:30:57 --> Final output sent to browser
DEBUG - 2011-08-16 13:30:57 --> Total execution time: 0.3007
DEBUG - 2011-08-16 13:31:01 --> Config Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:31:01 --> URI Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Router Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Output Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Input Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:31:01 --> Language Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Loader Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Controller Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:31:01 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:31:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:31:02 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:31:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:31:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:31:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:31:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:31:02 --> Final output sent to browser
DEBUG - 2011-08-16 13:31:02 --> Total execution time: 0.6189
DEBUG - 2011-08-16 13:31:08 --> Config Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:31:08 --> URI Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Router Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Output Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Input Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:31:08 --> Language Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Loader Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Controller Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:31:08 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:31:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:31:08 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:31:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:31:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:31:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:31:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:31:08 --> Final output sent to browser
DEBUG - 2011-08-16 13:31:08 --> Total execution time: 0.2603
DEBUG - 2011-08-16 13:31:12 --> Config Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:31:12 --> URI Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Router Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Output Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Input Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:31:12 --> Language Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Loader Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Controller Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:31:12 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:31:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:31:12 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:31:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:31:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:31:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:31:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:31:12 --> Final output sent to browser
DEBUG - 2011-08-16 13:31:12 --> Total execution time: 0.0530
DEBUG - 2011-08-16 13:31:27 --> Config Class Initialized
DEBUG - 2011-08-16 13:31:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:31:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:31:27 --> URI Class Initialized
DEBUG - 2011-08-16 13:31:27 --> Router Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Output Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Input Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:31:28 --> Language Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Loader Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Controller Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Model Class Initialized
DEBUG - 2011-08-16 13:31:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:31:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:31:28 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:31:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:31:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:31:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:31:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:31:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:31:28 --> Final output sent to browser
DEBUG - 2011-08-16 13:31:28 --> Total execution time: 0.0622
DEBUG - 2011-08-16 13:32:05 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:05 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:05 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:05 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:05 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:05 --> Total execution time: 0.2008
DEBUG - 2011-08-16 13:32:08 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:08 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:08 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:08 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:08 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:08 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:08 --> Total execution time: 0.0775
DEBUG - 2011-08-16 13:32:22 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:22 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:22 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:22 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:23 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:23 --> Total execution time: 0.2736
DEBUG - 2011-08-16 13:32:25 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:25 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:25 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:25 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:25 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:25 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:25 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:25 --> Total execution time: 0.0899
DEBUG - 2011-08-16 13:32:52 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:52 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:52 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:52 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:52 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:52 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:52 --> Total execution time: 0.4994
DEBUG - 2011-08-16 13:32:56 --> Config Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:32:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:32:56 --> URI Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Router Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Output Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Input Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:32:56 --> Language Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Loader Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Controller Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Model Class Initialized
DEBUG - 2011-08-16 13:32:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:32:56 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:32:56 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:32:56 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:32:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:32:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:32:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:32:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:32:56 --> Final output sent to browser
DEBUG - 2011-08-16 13:32:56 --> Total execution time: 0.0483
DEBUG - 2011-08-16 13:43:15 --> Config Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:43:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:43:15 --> URI Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Router Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Output Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Input Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 13:43:15 --> Language Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Loader Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Controller Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Model Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Model Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Model Class Initialized
DEBUG - 2011-08-16 13:43:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 13:43:15 --> Database Driver Class Initialized
DEBUG - 2011-08-16 13:43:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 13:43:15 --> Helper loaded: url_helper
DEBUG - 2011-08-16 13:43:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 13:43:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 13:43:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 13:43:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 13:43:15 --> Final output sent to browser
DEBUG - 2011-08-16 13:43:15 --> Total execution time: 0.0687
DEBUG - 2011-08-16 13:43:26 --> Config Class Initialized
DEBUG - 2011-08-16 13:43:26 --> Hooks Class Initialized
DEBUG - 2011-08-16 13:43:26 --> Utf8 Class Initialized
DEBUG - 2011-08-16 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 13:43:26 --> URI Class Initialized
DEBUG - 2011-08-16 13:43:26 --> Router Class Initialized
ERROR - 2011-08-16 13:43:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:33:43 --> Config Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:33:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:33:43 --> URI Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Router Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Output Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Input Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:33:43 --> Language Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Loader Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Controller Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:33:43 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:33:44 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 14:33:44 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:33:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:33:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:33:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:33:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:33:44 --> Final output sent to browser
DEBUG - 2011-08-16 14:33:44 --> Total execution time: 0.3097
DEBUG - 2011-08-16 14:33:48 --> Config Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:33:48 --> URI Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Router Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Output Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Input Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:33:48 --> Language Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Loader Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Controller Class Initialized
ERROR - 2011-08-16 14:33:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 14:33:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:33:48 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:33:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:33:48 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:33:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:33:48 --> Final output sent to browser
DEBUG - 2011-08-16 14:33:48 --> Total execution time: 0.0290
DEBUG - 2011-08-16 14:33:48 --> Config Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:33:48 --> URI Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Router Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Output Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Input Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:33:48 --> Language Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Loader Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Controller Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Model Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:33:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Config Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:33:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:33:48 --> URI Class Initialized
DEBUG - 2011-08-16 14:33:48 --> Router Class Initialized
ERROR - 2011-08-16 14:33:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:33:49 --> Config Class Initialized
DEBUG - 2011-08-16 14:33:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:33:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:33:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:33:49 --> URI Class Initialized
DEBUG - 2011-08-16 14:33:49 --> Router Class Initialized
ERROR - 2011-08-16 14:33:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:33:49 --> Final output sent to browser
DEBUG - 2011-08-16 14:33:49 --> Total execution time: 0.9772
DEBUG - 2011-08-16 14:34:20 --> Config Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:34:20 --> URI Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Router Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Output Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Input Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:34:20 --> Language Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Loader Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Controller Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Model Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Model Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Model Class Initialized
DEBUG - 2011-08-16 14:34:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:34:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:34:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 14:34:21 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:34:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:34:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:34:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:34:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:34:21 --> Final output sent to browser
DEBUG - 2011-08-16 14:34:21 --> Total execution time: 0.3294
DEBUG - 2011-08-16 14:38:19 --> Config Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:38:19 --> URI Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Router Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Output Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Input Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:38:19 --> Language Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Loader Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Controller Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Model Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Model Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Model Class Initialized
DEBUG - 2011-08-16 14:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:38:19 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:38:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 14:38:19 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:38:19 --> Final output sent to browser
DEBUG - 2011-08-16 14:38:19 --> Total execution time: 0.0642
DEBUG - 2011-08-16 14:38:27 --> Config Class Initialized
DEBUG - 2011-08-16 14:38:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:38:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:38:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:38:27 --> URI Class Initialized
DEBUG - 2011-08-16 14:38:27 --> Router Class Initialized
ERROR - 2011-08-16 14:38:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:44:37 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:37 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:37 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Router Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Output Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Input Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:44:37 --> Language Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Loader Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Controller Class Initialized
ERROR - 2011-08-16 14:44:37 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 14:44:37 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:44:37 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:44:37 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:44:37 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:44:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:44:37 --> Final output sent to browser
DEBUG - 2011-08-16 14:44:37 --> Total execution time: 0.0296
DEBUG - 2011-08-16 14:44:38 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:38 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Router Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Output Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Input Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:44:38 --> Language Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Loader Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Controller Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:44:38 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:44:39 --> Final output sent to browser
DEBUG - 2011-08-16 14:44:39 --> Total execution time: 0.7705
DEBUG - 2011-08-16 14:44:40 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:40 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:40 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:40 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:40 --> Router Class Initialized
ERROR - 2011-08-16 14:44:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:44:53 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:53 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Router Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Output Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Input Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:44:53 --> Language Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Loader Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Controller Class Initialized
ERROR - 2011-08-16 14:44:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 14:44:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:44:53 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:44:53 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:44:53 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:44:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:44:53 --> Final output sent to browser
DEBUG - 2011-08-16 14:44:53 --> Total execution time: 0.0283
DEBUG - 2011-08-16 14:44:54 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:54 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:54 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Router Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Output Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Input Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:44:54 --> Language Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Loader Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Controller Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Model Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:44:54 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:44:54 --> Final output sent to browser
DEBUG - 2011-08-16 14:44:54 --> Total execution time: 0.8732
DEBUG - 2011-08-16 14:44:56 --> Config Class Initialized
DEBUG - 2011-08-16 14:44:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:44:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:44:56 --> URI Class Initialized
DEBUG - 2011-08-16 14:44:56 --> Router Class Initialized
ERROR - 2011-08-16 14:44:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 14:45:07 --> Config Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Hooks Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Utf8 Class Initialized
DEBUG - 2011-08-16 14:45:07 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 14:45:07 --> URI Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Router Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Output Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Input Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 14:45:07 --> Language Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Loader Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Controller Class Initialized
ERROR - 2011-08-16 14:45:07 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 14:45:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:45:07 --> Model Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Model Class Initialized
DEBUG - 2011-08-16 14:45:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 14:45:07 --> Database Driver Class Initialized
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 14:45:07 --> Helper loaded: url_helper
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 14:45:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 14:45:07 --> Final output sent to browser
DEBUG - 2011-08-16 14:45:07 --> Total execution time: 0.0297
DEBUG - 2011-08-16 15:00:28 --> Config Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:00:28 --> URI Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Router Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Output Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Input Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:00:28 --> Language Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Loader Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Controller Class Initialized
ERROR - 2011-08-16 15:00:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:00:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:00:28 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:00:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:00:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:00:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:00:28 --> Final output sent to browser
DEBUG - 2011-08-16 15:00:28 --> Total execution time: 0.0540
DEBUG - 2011-08-16 15:00:29 --> Config Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:00:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:00:29 --> URI Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Router Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Output Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Input Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:00:29 --> Language Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Loader Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Controller Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:00:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:00:30 --> Final output sent to browser
DEBUG - 2011-08-16 15:00:30 --> Total execution time: 1.0337
DEBUG - 2011-08-16 15:00:31 --> Config Class Initialized
DEBUG - 2011-08-16 15:00:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:00:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:00:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:00:31 --> URI Class Initialized
DEBUG - 2011-08-16 15:00:31 --> Router Class Initialized
ERROR - 2011-08-16 15:00:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:00:55 --> Config Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:00:55 --> URI Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Router Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Output Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Input Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:00:55 --> Language Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Loader Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Controller Class Initialized
ERROR - 2011-08-16 15:00:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:00:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:00:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:00:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:00:55 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:00:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:00:55 --> Final output sent to browser
DEBUG - 2011-08-16 15:00:55 --> Total execution time: 0.0329
DEBUG - 2011-08-16 15:00:55 --> Config Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:00:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:00:55 --> URI Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Router Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Output Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Input Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:00:55 --> Language Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Loader Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Controller Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:00:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:00:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:00:56 --> Final output sent to browser
DEBUG - 2011-08-16 15:00:56 --> Total execution time: 0.8081
DEBUG - 2011-08-16 15:01:04 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:04 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:04 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:04 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:04 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:04 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:04 --> Total execution time: 0.1290
DEBUG - 2011-08-16 15:01:05 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:05 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:05 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:05 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:05 --> Total execution time: 0.8234
DEBUG - 2011-08-16 15:01:09 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:09 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:09 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:09 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:09 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:09 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:09 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:09 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:09 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:09 --> Total execution time: 0.0295
DEBUG - 2011-08-16 15:01:10 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:10 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:10 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:10 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:11 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:11 --> Total execution time: 0.9907
DEBUG - 2011-08-16 15:01:14 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:14 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:14 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:14 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:14 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:14 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:14 --> Total execution time: 0.0311
DEBUG - 2011-08-16 15:01:14 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:14 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:14 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:14 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:15 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:15 --> Total execution time: 0.8411
DEBUG - 2011-08-16 15:01:17 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:17 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:17 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:17 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:17 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:17 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:17 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:17 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:17 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:17 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:17 --> Total execution time: 0.0275
DEBUG - 2011-08-16 15:01:18 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:18 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:18 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:18 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:19 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:19 --> Total execution time: 0.9209
DEBUG - 2011-08-16 15:01:27 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:27 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:27 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:27 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:27 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:27 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:27 --> Total execution time: 0.0309
DEBUG - 2011-08-16 15:01:27 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:27 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:27 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:27 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:28 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:28 --> Total execution time: 0.8849
DEBUG - 2011-08-16 15:01:32 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:32 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:32 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:32 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:32 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:32 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:32 --> Total execution time: 0.0288
DEBUG - 2011-08-16 15:01:32 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:32 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:32 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:33 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:33 --> Total execution time: 0.8433
DEBUG - 2011-08-16 15:01:49 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:49 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:49 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:49 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:49 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:49 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:49 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:49 --> Total execution time: 0.0395
DEBUG - 2011-08-16 15:01:49 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:49 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:49 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:49 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:49 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:50 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:50 --> Total execution time: 0.8977
DEBUG - 2011-08-16 15:01:55 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:55 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:55 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Controller Class Initialized
ERROR - 2011-08-16 15:01:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:01:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:01:55 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:01:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:01:55 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:55 --> Total execution time: 0.0295
DEBUG - 2011-08-16 15:01:55 --> Config Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:01:55 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:01:55 --> URI Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Router Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Output Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Input Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:01:55 --> Language Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Loader Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Controller Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Model Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:01:55 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:01:55 --> Final output sent to browser
DEBUG - 2011-08-16 15:01:55 --> Total execution time: 0.6027
DEBUG - 2011-08-16 15:02:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:02:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Router Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Output Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Input Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:02:00 --> Language Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Loader Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Controller Class Initialized
ERROR - 2011-08-16 15:02:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:02:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:02:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:02:00 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:02:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:02:00 --> Final output sent to browser
DEBUG - 2011-08-16 15:02:00 --> Total execution time: 0.0315
DEBUG - 2011-08-16 15:02:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:02:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Router Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Output Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Input Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:02:00 --> Language Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Loader Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Controller Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:02:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:02:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:02:01 --> Final output sent to browser
DEBUG - 2011-08-16 15:02:01 --> Total execution time: 0.8461
DEBUG - 2011-08-16 15:15:09 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:09 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:09 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:09 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:09 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:09 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:09 --> Total execution time: 0.3454
DEBUG - 2011-08-16 15:15:11 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:11 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:11 --> Router Class Initialized
ERROR - 2011-08-16 15:15:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:23 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:23 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:23 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:23 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:23 --> Total execution time: 0.2302
DEBUG - 2011-08-16 15:15:24 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:24 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:24 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:24 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:24 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:24 --> Router Class Initialized
ERROR - 2011-08-16 15:15:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:24 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:24 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:24 --> Total execution time: 0.0648
DEBUG - 2011-08-16 15:15:25 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:25 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:25 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:25 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:25 --> Router Class Initialized
ERROR - 2011-08-16 15:15:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:34 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:34 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:34 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:34 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:34 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:34 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:34 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:34 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:34 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:34 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:34 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:34 --> Total execution time: 0.4573
DEBUG - 2011-08-16 15:15:35 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:35 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:35 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:35 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:35 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:35 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:35 --> Total execution time: 0.1049
DEBUG - 2011-08-16 15:15:35 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:35 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:35 --> Router Class Initialized
ERROR - 2011-08-16 15:15:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:40 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:40 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:40 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:40 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:41 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:41 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:41 --> Total execution time: 0.2869
DEBUG - 2011-08-16 15:15:42 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:42 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:42 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:42 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:42 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:42 --> Router Class Initialized
ERROR - 2011-08-16 15:15:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:42 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:42 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:42 --> Total execution time: 0.1176
DEBUG - 2011-08-16 15:15:50 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:50 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:50 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:50 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:50 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:50 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:50 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:50 --> Total execution time: 0.2427
DEBUG - 2011-08-16 15:15:52 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:52 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Router Class Initialized
ERROR - 2011-08-16 15:15:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:15:52 --> Config Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:15:52 --> URI Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Router Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Output Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Input Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:15:52 --> Language Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Loader Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Controller Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Model Class Initialized
DEBUG - 2011-08-16 15:15:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:15:52 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:15:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:15:52 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:15:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:15:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:15:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:15:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:15:52 --> Final output sent to browser
DEBUG - 2011-08-16 15:15:52 --> Total execution time: 0.1041
DEBUG - 2011-08-16 15:16:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Router Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Output Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Input Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:16:00 --> Language Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Loader Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Controller Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:16:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:16:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:16:00 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:16:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:16:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:16:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:16:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:16:01 --> Final output sent to browser
DEBUG - 2011-08-16 15:16:01 --> Total execution time: 0.2846
DEBUG - 2011-08-16 15:16:02 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:02 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Router Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Output Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:02 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Router Class Initialized
ERROR - 2011-08-16 15:16:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:16:02 --> Input Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:16:02 --> Language Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Loader Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Controller Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:16:02 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:16:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:16:02 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:16:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:16:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:16:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:16:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:16:02 --> Final output sent to browser
DEBUG - 2011-08-16 15:16:02 --> Total execution time: 0.2694
DEBUG - 2011-08-16 15:16:11 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:11 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Router Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Output Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Input Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:16:11 --> Language Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Loader Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Controller Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:16:11 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:16:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:16:12 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:16:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:16:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:16:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:16:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:16:12 --> Final output sent to browser
DEBUG - 2011-08-16 15:16:12 --> Total execution time: 0.4312
DEBUG - 2011-08-16 15:16:13 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:13 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Router Class Initialized
ERROR - 2011-08-16 15:16:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:16:13 --> Config Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:16:13 --> URI Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Router Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Output Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Input Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:16:13 --> Language Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Loader Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Controller Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:16:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:16:13 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:16:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:16:13 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:16:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:16:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:16:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:16:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:16:13 --> Final output sent to browser
DEBUG - 2011-08-16 15:16:13 --> Total execution time: 0.0464
DEBUG - 2011-08-16 15:25:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:00 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:00 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:00 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:00 --> Total execution time: 0.0300
DEBUG - 2011-08-16 15:25:02 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:02 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:02 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:02 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:02 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:03 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:03 --> Total execution time: 0.9019
DEBUG - 2011-08-16 15:25:05 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:05 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:05 --> Router Class Initialized
ERROR - 2011-08-16 15:25:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:25:15 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:15 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:15 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:15 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:15 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:15 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:15 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:15 --> Total execution time: 0.0448
DEBUG - 2011-08-16 15:25:15 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:15 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:15 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:15 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:16 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:16 --> Total execution time: 0.6221
DEBUG - 2011-08-16 15:25:17 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:17 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:17 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:17 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:17 --> Router Class Initialized
ERROR - 2011-08-16 15:25:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:25:19 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:19 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:19 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:19 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:19 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:19 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:19 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:19 --> Total execution time: 0.0280
DEBUG - 2011-08-16 15:25:19 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:19 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:19 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:19 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:19 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:19 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:19 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:19 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:19 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:19 --> Total execution time: 0.0281
DEBUG - 2011-08-16 15:25:20 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:20 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:20 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:20 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:20 --> Total execution time: 0.5595
DEBUG - 2011-08-16 15:25:21 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:21 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:21 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:21 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:21 --> Router Class Initialized
ERROR - 2011-08-16 15:25:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:25:33 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:33 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:33 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:33 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:33 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:33 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:33 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:33 --> Total execution time: 0.0366
DEBUG - 2011-08-16 15:25:33 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:33 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:33 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:33 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:34 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:34 --> Total execution time: 0.5167
DEBUG - 2011-08-16 15:25:35 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:35 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:35 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:35 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:35 --> Router Class Initialized
ERROR - 2011-08-16 15:25:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:25:48 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:48 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:48 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:48 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:48 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:48 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:48 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:48 --> Total execution time: 0.0289
DEBUG - 2011-08-16 15:25:48 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:48 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:48 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:48 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:49 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:49 --> Total execution time: 0.5017
DEBUG - 2011-08-16 15:25:50 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:50 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:50 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:50 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:50 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:50 --> Router Class Initialized
ERROR - 2011-08-16 15:25:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:25:57 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:57 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:57 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Controller Class Initialized
ERROR - 2011-08-16 15:25:57 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:25:57 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:57 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:57 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:25:57 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:25:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:25:57 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:57 --> Total execution time: 0.0606
DEBUG - 2011-08-16 15:25:58 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:58 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Router Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Output Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Input Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:25:58 --> Language Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Loader Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Controller Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:25:58 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:25:58 --> Final output sent to browser
DEBUG - 2011-08-16 15:25:58 --> Total execution time: 0.5556
DEBUG - 2011-08-16 15:25:59 --> Config Class Initialized
DEBUG - 2011-08-16 15:25:59 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:25:59 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:25:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:25:59 --> URI Class Initialized
DEBUG - 2011-08-16 15:25:59 --> Router Class Initialized
ERROR - 2011-08-16 15:25:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:26:28 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:28 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:28 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Router Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Output Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Input Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:26:28 --> Language Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Loader Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Controller Class Initialized
ERROR - 2011-08-16 15:26:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:26:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:28 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:26:28 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:28 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:26:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:26:28 --> Final output sent to browser
DEBUG - 2011-08-16 15:26:28 --> Total execution time: 0.0294
DEBUG - 2011-08-16 15:26:29 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:29 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Router Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Output Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Input Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:26:29 --> Language Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Loader Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Controller Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:26:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:29 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Router Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Output Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Input Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:26:29 --> Language Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Loader Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Controller Class Initialized
ERROR - 2011-08-16 15:26:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:26:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:26:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:29 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:26:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:26:29 --> Final output sent to browser
DEBUG - 2011-08-16 15:26:29 --> Total execution time: 0.0285
DEBUG - 2011-08-16 15:26:30 --> Final output sent to browser
DEBUG - 2011-08-16 15:26:30 --> Total execution time: 0.5614
DEBUG - 2011-08-16 15:26:31 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:31 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:31 --> Router Class Initialized
ERROR - 2011-08-16 15:26:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:26:58 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:58 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Router Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Output Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Input Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:26:58 --> Language Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Loader Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Controller Class Initialized
ERROR - 2011-08-16 15:26:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:26:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:26:58 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:26:58 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:26:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:26:58 --> Final output sent to browser
DEBUG - 2011-08-16 15:26:58 --> Total execution time: 0.0283
DEBUG - 2011-08-16 15:26:59 --> Config Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:26:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:26:59 --> URI Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Router Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Output Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Input Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:26:59 --> Language Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Loader Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Controller Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Model Class Initialized
DEBUG - 2011-08-16 15:26:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:26:59 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:00 --> Total execution time: 0.6780
DEBUG - 2011-08-16 15:27:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:00 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:00 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:00 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:00 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:00 --> Total execution time: 0.0335
DEBUG - 2011-08-16 15:27:01 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:01 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:01 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:01 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:01 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:01 --> Router Class Initialized
ERROR - 2011-08-16 15:27:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:27:12 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:12 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:12 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:12 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:12 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:12 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:12 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:12 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:12 --> Total execution time: 0.0336
DEBUG - 2011-08-16 15:27:13 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:13 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:13 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Controller Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:13 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:13 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:13 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:13 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:13 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:13 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:13 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:13 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:13 --> Total execution time: 0.0904
DEBUG - 2011-08-16 15:27:13 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:13 --> Total execution time: 0.6760
DEBUG - 2011-08-16 15:27:15 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:15 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:15 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:15 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:15 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:15 --> Router Class Initialized
ERROR - 2011-08-16 15:27:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:27:23 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:23 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:23 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:23 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:23 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:23 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:23 --> Total execution time: 0.0415
DEBUG - 2011-08-16 15:27:24 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:24 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:24 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Controller Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:24 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:24 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:24 --> Total execution time: 0.4925
DEBUG - 2011-08-16 15:27:25 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:25 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:25 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:25 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:25 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:25 --> Router Class Initialized
ERROR - 2011-08-16 15:27:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:27:29 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:29 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:29 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:29 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:29 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:29 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:29 --> Total execution time: 0.0304
DEBUG - 2011-08-16 15:27:29 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:29 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:30 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:30 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Controller Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:30 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:30 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:30 --> Total execution time: 0.5609
DEBUG - 2011-08-16 15:27:31 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:31 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:31 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:31 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:31 --> Router Class Initialized
ERROR - 2011-08-16 15:27:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:27:41 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:41 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:41 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Controller Class Initialized
ERROR - 2011-08-16 15:27:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:27:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:41 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:41 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:27:41 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:27:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:27:41 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:41 --> Total execution time: 0.0287
DEBUG - 2011-08-16 15:27:41 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:41 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Router Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Output Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Input Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:27:41 --> Language Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Loader Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Controller Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Model Class Initialized
DEBUG - 2011-08-16 15:27:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:27:41 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:27:42 --> Final output sent to browser
DEBUG - 2011-08-16 15:27:42 --> Total execution time: 0.4950
DEBUG - 2011-08-16 15:27:43 --> Config Class Initialized
DEBUG - 2011-08-16 15:27:43 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:27:43 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:27:43 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:27:43 --> URI Class Initialized
DEBUG - 2011-08-16 15:27:43 --> Router Class Initialized
ERROR - 2011-08-16 15:27:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:28:05 --> Config Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:28:05 --> URI Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Router Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Output Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Input Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:28:05 --> Language Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Loader Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Controller Class Initialized
ERROR - 2011-08-16 15:28:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:28:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:28:05 --> Model Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Model Class Initialized
DEBUG - 2011-08-16 15:28:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:28:05 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:28:05 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:28:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:28:05 --> Final output sent to browser
DEBUG - 2011-08-16 15:28:05 --> Total execution time: 0.0426
DEBUG - 2011-08-16 15:28:20 --> Config Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:28:20 --> URI Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Router Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Output Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Input Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:28:20 --> Language Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Loader Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Controller Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:28:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:28:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:28:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:28:20 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:28:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:28:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:28:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:28:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:28:20 --> Final output sent to browser
DEBUG - 2011-08-16 15:28:20 --> Total execution time: 0.0434
DEBUG - 2011-08-16 15:28:21 --> Config Class Initialized
DEBUG - 2011-08-16 15:28:21 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:28:21 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:28:21 --> URI Class Initialized
DEBUG - 2011-08-16 15:28:21 --> Router Class Initialized
ERROR - 2011-08-16 15:28:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:34:27 --> Config Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:34:27 --> URI Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Router Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Output Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Input Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:34:27 --> Language Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Loader Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Controller Class Initialized
ERROR - 2011-08-16 15:34:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:34:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:34:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:34:27 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:34:27 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:34:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:34:27 --> Final output sent to browser
DEBUG - 2011-08-16 15:34:27 --> Total execution time: 0.0484
DEBUG - 2011-08-16 15:34:32 --> Config Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:34:32 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:34:32 --> URI Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Router Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Output Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Input Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:34:32 --> Language Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Loader Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Controller Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:34:32 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:34:32 --> Final output sent to browser
DEBUG - 2011-08-16 15:34:32 --> Total execution time: 0.4674
DEBUG - 2011-08-16 15:34:34 --> Config Class Initialized
DEBUG - 2011-08-16 15:34:34 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:34:34 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:34:34 --> URI Class Initialized
DEBUG - 2011-08-16 15:34:34 --> Router Class Initialized
ERROR - 2011-08-16 15:34:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:34:58 --> Config Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:34:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:34:58 --> URI Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Router Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Output Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Input Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:34:58 --> Language Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Loader Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Controller Class Initialized
ERROR - 2011-08-16 15:34:58 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:34:58 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:34:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:34:58 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:34:58 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:34:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:34:58 --> Final output sent to browser
DEBUG - 2011-08-16 15:34:58 --> Total execution time: 0.0371
DEBUG - 2011-08-16 15:34:59 --> Config Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:34:59 --> URI Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Router Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Output Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Input Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:34:59 --> Language Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Loader Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Controller Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Model Class Initialized
DEBUG - 2011-08-16 15:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:34:59 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:35:00 --> Final output sent to browser
DEBUG - 2011-08-16 15:35:00 --> Total execution time: 0.4418
DEBUG - 2011-08-16 15:35:00 --> Config Class Initialized
DEBUG - 2011-08-16 15:35:00 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:35:00 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:35:00 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:35:00 --> URI Class Initialized
DEBUG - 2011-08-16 15:35:00 --> Router Class Initialized
ERROR - 2011-08-16 15:35:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:35:04 --> Config Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:35:04 --> URI Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Router Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Output Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Input Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:35:04 --> Language Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Loader Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Controller Class Initialized
ERROR - 2011-08-16 15:35:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:35:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:35:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:35:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:35:04 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:35:04 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:35:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:35:04 --> Final output sent to browser
DEBUG - 2011-08-16 15:35:04 --> Total execution time: 0.0622
DEBUG - 2011-08-16 15:35:08 --> Config Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:35:08 --> URI Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Router Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Output Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Input Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:35:08 --> Language Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Loader Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Controller Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Model Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Model Class Initialized
DEBUG - 2011-08-16 15:35:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:35:08 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:35:09 --> Final output sent to browser
DEBUG - 2011-08-16 15:35:09 --> Total execution time: 0.5818
DEBUG - 2011-08-16 15:35:11 --> Config Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:35:11 --> URI Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Router Class Initialized
ERROR - 2011-08-16 15:35:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:35:11 --> Config Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:35:11 --> URI Class Initialized
DEBUG - 2011-08-16 15:35:11 --> Router Class Initialized
ERROR - 2011-08-16 15:35:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:42:03 --> Config Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:42:03 --> URI Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Router Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Config Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:42:03 --> URI Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Output Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Router Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Input Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:42:03 --> Language Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Output Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Input Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:42:03 --> Language Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Loader Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Controller Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Model Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Model Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Model Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Loader Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:42:03 --> Controller Class Initialized
ERROR - 2011-08-16 15:42:03 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:42:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:42:03 --> Model Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Model Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:42:03 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:42:03 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:42:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:42:03 --> Final output sent to browser
DEBUG - 2011-08-16 15:42:03 --> Total execution time: 0.0309
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:42:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:42:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:42:03 --> Final output sent to browser
DEBUG - 2011-08-16 15:42:03 --> Total execution time: 0.0518
DEBUG - 2011-08-16 15:45:04 --> Config Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:45:04 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:45:04 --> URI Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Router Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Output Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Input Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:45:04 --> Language Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Loader Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Controller Class Initialized
ERROR - 2011-08-16 15:45:04 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 15:45:04 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:45:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Model Class Initialized
DEBUG - 2011-08-16 15:45:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:45:04 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 15:45:04 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:45:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:45:04 --> Final output sent to browser
DEBUG - 2011-08-16 15:45:04 --> Total execution time: 0.0374
DEBUG - 2011-08-16 15:45:06 --> Config Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:45:06 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:45:06 --> URI Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Router Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Output Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Input Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:45:06 --> Language Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Loader Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Controller Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Model Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Model Class Initialized
DEBUG - 2011-08-16 15:45:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:45:06 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:45:07 --> Final output sent to browser
DEBUG - 2011-08-16 15:45:07 --> Total execution time: 1.0733
DEBUG - 2011-08-16 15:45:09 --> Config Class Initialized
DEBUG - 2011-08-16 15:45:09 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:45:09 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:45:09 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:45:09 --> URI Class Initialized
DEBUG - 2011-08-16 15:45:09 --> Router Class Initialized
ERROR - 2011-08-16 15:45:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:45:13 --> Config Class Initialized
DEBUG - 2011-08-16 15:45:13 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:45:13 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:45:13 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:45:13 --> URI Class Initialized
DEBUG - 2011-08-16 15:45:13 --> Router Class Initialized
ERROR - 2011-08-16 15:45:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:45:14 --> Config Class Initialized
DEBUG - 2011-08-16 15:45:14 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:45:14 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:45:14 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:45:14 --> URI Class Initialized
DEBUG - 2011-08-16 15:45:14 --> Router Class Initialized
ERROR - 2011-08-16 15:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 15:51:20 --> Config Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Hooks Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Utf8 Class Initialized
DEBUG - 2011-08-16 15:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 15:51:20 --> URI Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Router Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Output Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Input Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 15:51:20 --> Language Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Loader Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Controller Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Model Class Initialized
DEBUG - 2011-08-16 15:51:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 15:51:20 --> Database Driver Class Initialized
DEBUG - 2011-08-16 15:51:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 15:51:20 --> Helper loaded: url_helper
DEBUG - 2011-08-16 15:51:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 15:51:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 15:51:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 15:51:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 15:51:20 --> Final output sent to browser
DEBUG - 2011-08-16 15:51:20 --> Total execution time: 0.1044
DEBUG - 2011-08-16 16:20:18 --> Config Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:20:18 --> URI Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Router Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Output Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Input Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 16:20:18 --> Language Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Loader Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Controller Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 16:20:18 --> Database Driver Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Config Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:20:18 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:20:18 --> URI Class Initialized
DEBUG - 2011-08-16 16:20:18 --> Router Class Initialized
ERROR - 2011-08-16 16:20:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 16:20:18 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 16:20:18 --> Helper loaded: url_helper
DEBUG - 2011-08-16 16:20:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 16:20:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 16:20:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 16:20:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 16:20:18 --> Final output sent to browser
DEBUG - 2011-08-16 16:20:18 --> Total execution time: 0.2043
DEBUG - 2011-08-16 16:20:19 --> Config Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:20:19 --> URI Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Router Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Output Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Input Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 16:20:19 --> Language Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Loader Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Controller Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Model Class Initialized
DEBUG - 2011-08-16 16:20:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 16:20:19 --> Database Driver Class Initialized
DEBUG - 2011-08-16 16:20:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 16:20:19 --> Helper loaded: url_helper
DEBUG - 2011-08-16 16:20:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 16:20:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 16:20:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 16:20:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 16:20:19 --> Final output sent to browser
DEBUG - 2011-08-16 16:20:19 --> Total execution time: 0.2592
DEBUG - 2011-08-16 16:34:45 --> Config Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:34:45 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:34:45 --> URI Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Router Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Output Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Input Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 16:34:45 --> Language Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Loader Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Controller Class Initialized
ERROR - 2011-08-16 16:34:45 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 16:34:45 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 16:34:45 --> Model Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Model Class Initialized
DEBUG - 2011-08-16 16:34:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 16:34:45 --> Database Driver Class Initialized
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 16:34:45 --> Helper loaded: url_helper
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 16:34:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 16:34:45 --> Final output sent to browser
DEBUG - 2011-08-16 16:34:45 --> Total execution time: 0.0608
DEBUG - 2011-08-16 16:34:46 --> Config Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:34:46 --> URI Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Router Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Output Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Input Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 16:34:46 --> Language Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Loader Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Controller Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Model Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Model Class Initialized
DEBUG - 2011-08-16 16:34:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 16:34:46 --> Database Driver Class Initialized
DEBUG - 2011-08-16 16:34:47 --> Final output sent to browser
DEBUG - 2011-08-16 16:34:47 --> Total execution time: 0.8415
DEBUG - 2011-08-16 16:34:48 --> Config Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:34:48 --> URI Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Router Class Initialized
ERROR - 2011-08-16 16:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 16:34:48 --> Config Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:34:48 --> URI Class Initialized
DEBUG - 2011-08-16 16:34:48 --> Router Class Initialized
ERROR - 2011-08-16 16:34:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 16:34:49 --> Config Class Initialized
DEBUG - 2011-08-16 16:34:49 --> Hooks Class Initialized
DEBUG - 2011-08-16 16:34:49 --> Utf8 Class Initialized
DEBUG - 2011-08-16 16:34:49 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 16:34:49 --> URI Class Initialized
DEBUG - 2011-08-16 16:34:49 --> Router Class Initialized
ERROR - 2011-08-16 16:34:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 17:06:30 --> Config Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Hooks Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Utf8 Class Initialized
DEBUG - 2011-08-16 17:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 17:06:30 --> URI Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Router Class Initialized
DEBUG - 2011-08-16 17:06:30 --> No URI present. Default controller set.
DEBUG - 2011-08-16 17:06:30 --> Output Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Input Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 17:06:30 --> Language Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Loader Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Controller Class Initialized
DEBUG - 2011-08-16 17:06:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 17:06:30 --> Helper loaded: url_helper
DEBUG - 2011-08-16 17:06:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 17:06:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 17:06:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 17:06:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 17:06:30 --> Final output sent to browser
DEBUG - 2011-08-16 17:06:30 --> Total execution time: 0.0899
DEBUG - 2011-08-16 17:06:30 --> Config Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Hooks Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Utf8 Class Initialized
DEBUG - 2011-08-16 17:06:30 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 17:06:30 --> URI Class Initialized
DEBUG - 2011-08-16 17:06:30 --> Router Class Initialized
ERROR - 2011-08-16 17:06:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-08-16 17:38:23 --> Config Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Hooks Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Utf8 Class Initialized
DEBUG - 2011-08-16 17:38:23 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 17:38:23 --> URI Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Router Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Output Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Input Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 17:38:23 --> Language Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Loader Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Controller Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Model Class Initialized
DEBUG - 2011-08-16 17:38:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 17:38:23 --> Database Driver Class Initialized
DEBUG - 2011-08-16 17:38:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-08-16 17:38:23 --> Helper loaded: url_helper
DEBUG - 2011-08-16 17:38:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 17:38:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 17:38:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 17:38:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 17:38:23 --> Final output sent to browser
DEBUG - 2011-08-16 17:38:23 --> Total execution time: 0.2640
DEBUG - 2011-08-16 18:11:27 --> Config Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Hooks Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Utf8 Class Initialized
DEBUG - 2011-08-16 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 18:11:27 --> URI Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Router Class Initialized
DEBUG - 2011-08-16 18:11:27 --> No URI present. Default controller set.
DEBUG - 2011-08-16 18:11:27 --> Output Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Input Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 18:11:27 --> Language Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Loader Class Initialized
DEBUG - 2011-08-16 18:11:27 --> Controller Class Initialized
DEBUG - 2011-08-16 18:11:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 18:11:27 --> Helper loaded: url_helper
DEBUG - 2011-08-16 18:11:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 18:11:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 18:11:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 18:11:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 18:11:27 --> Final output sent to browser
DEBUG - 2011-08-16 18:11:27 --> Total execution time: 0.0905
DEBUG - 2011-08-16 21:18:56 --> Config Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Hooks Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Utf8 Class Initialized
DEBUG - 2011-08-16 21:18:56 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 21:18:56 --> URI Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Router Class Initialized
DEBUG - 2011-08-16 21:18:56 --> No URI present. Default controller set.
DEBUG - 2011-08-16 21:18:56 --> Output Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Input Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 21:18:56 --> Language Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Loader Class Initialized
DEBUG - 2011-08-16 21:18:56 --> Controller Class Initialized
DEBUG - 2011-08-16 21:18:56 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 21:18:56 --> Helper loaded: url_helper
DEBUG - 2011-08-16 21:18:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 21:18:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 21:18:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 21:18:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 21:18:56 --> Final output sent to browser
DEBUG - 2011-08-16 21:18:56 --> Total execution time: 0.1719
DEBUG - 2011-08-16 21:27:58 --> Config Class Initialized
DEBUG - 2011-08-16 21:27:58 --> Hooks Class Initialized
DEBUG - 2011-08-16 21:27:58 --> Utf8 Class Initialized
DEBUG - 2011-08-16 21:27:58 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 21:27:58 --> URI Class Initialized
DEBUG - 2011-08-16 21:27:58 --> Router Class Initialized
ERROR - 2011-08-16 21:27:58 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 21:33:35 --> Config Class Initialized
DEBUG - 2011-08-16 21:33:35 --> Hooks Class Initialized
DEBUG - 2011-08-16 21:33:35 --> Utf8 Class Initialized
DEBUG - 2011-08-16 21:33:35 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 21:33:35 --> URI Class Initialized
DEBUG - 2011-08-16 21:33:35 --> Router Class Initialized
ERROR - 2011-08-16 21:33:35 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 22:31:03 --> Config Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Hooks Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Utf8 Class Initialized
DEBUG - 2011-08-16 22:31:03 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 22:31:03 --> URI Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Router Class Initialized
DEBUG - 2011-08-16 22:31:03 --> No URI present. Default controller set.
DEBUG - 2011-08-16 22:31:03 --> Output Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Input Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 22:31:03 --> Language Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Loader Class Initialized
DEBUG - 2011-08-16 22:31:03 --> Controller Class Initialized
DEBUG - 2011-08-16 22:31:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-08-16 22:31:03 --> Helper loaded: url_helper
DEBUG - 2011-08-16 22:31:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 22:31:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 22:31:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 22:31:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 22:31:03 --> Final output sent to browser
DEBUG - 2011-08-16 22:31:03 --> Total execution time: 0.0483
DEBUG - 2011-08-16 22:34:38 --> Config Class Initialized
DEBUG - 2011-08-16 22:34:38 --> Hooks Class Initialized
DEBUG - 2011-08-16 22:34:38 --> Utf8 Class Initialized
DEBUG - 2011-08-16 22:34:38 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 22:34:38 --> URI Class Initialized
DEBUG - 2011-08-16 22:34:38 --> Router Class Initialized
ERROR - 2011-08-16 22:34:38 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-08-16 22:34:41 --> Config Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Hooks Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Utf8 Class Initialized
DEBUG - 2011-08-16 22:34:41 --> UTF-8 Support Enabled
DEBUG - 2011-08-16 22:34:41 --> URI Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Router Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Output Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Input Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-08-16 22:34:41 --> Language Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Loader Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Controller Class Initialized
ERROR - 2011-08-16 22:34:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-08-16 22:34:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 22:34:41 --> Model Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Model Class Initialized
DEBUG - 2011-08-16 22:34:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-08-16 22:34:41 --> Database Driver Class Initialized
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-08-16 22:34:41 --> Helper loaded: url_helper
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-08-16 22:34:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-08-16 22:34:41 --> Final output sent to browser
DEBUG - 2011-08-16 22:34:41 --> Total execution time: 0.1826
